function _0x3f8e13() {
  return new Promise((_0x3d3bdc) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x3d3bdc();
      });
    });
  });
}
function _0x4d2dae() {
  return new Promise((_0x33c558) => {
    requestIdleCallback(() => {
      _0x33c558();
    });
  });
}
function _0xde6da1(_0x2a3acc = 0x3e8) {
  return new Promise((_0x58e55f, _0x3af355) => {
    let _0x3edff0,
      _0x4a1f9c = Date["now"](),
      _0x962b38 = !0x1;
    function _0x30f5d6() {
      if (Date["now"]() - _0x4a1f9c > _0x2a3acc)
        (_0x962b38 && _0x3edff0["disconnect"](), _0x58e55f());
      else setTimeout(_0x30f5d6, _0x2a3acc);
    }
    const _0x553724 = () => {
        _0x4a1f9c = Date["now"]();
      },
      _0x5d0a1b = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x3edff0 = new MutationObserver(_0x553724)),
        _0x3edff0["observe"](document["body"], _0x5d0a1b),
        (_0x962b38 = !0x0),
        setTimeout(_0x30f5d6, _0x2a3acc));
    else
      window["onload"] = () => {
        ((_0x3edff0 = new MutationObserver(_0x553724)),
          _0x3edff0["observe"](document["body"], _0x5d0a1b),
          (_0x962b38 = !0x0),
          setTimeout(_0x30f5d6, _0x2a3acc));
      };
  });
}
async function _0xf9a0ae() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0xde6da1(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
console["log"]("ebay/error/content.js\x20loaded");
var _0x411c21;
chrome["runtime"]["onMessage"]["addListener"](
  (_0x86ea76, _0x19f935, _0x4a0653) => {
    (console["log"](
      _0x19f935["tab"]
        ? "From\x20a\x20content\x20script:" + _0x19f935["tab"]["url"]
        : "From\x20the\x20extension\x20request.type\x20ebay.js" +
            _0x86ea76["type"],
    ),
      console["log"]("request", _0x86ea76),
      (_0x411c21 = _0x86ea76));
  },
);
async function _0x2a1ec1() {
  await _0x3f8e13();
  for (; !_0x411c21; )
    await new Promise((_0x52e551) => setTimeout(_0x52e551, 0x3e8));
  chrome["runtime"]["sendMessage"]({
    type: "error",
    error:
      "Error\x20Occured\x20on\x20page.\x20Please\x20check\x20the\x20page\x20and\x20try\x20again.",
  });
}
_0x2a1ec1();
