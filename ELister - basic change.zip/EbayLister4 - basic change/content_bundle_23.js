console["log"]("ebay/promoted_listings/functions.js");
var _0x231319 = 0x0;
async function _0x595ed5() {
  var _0x4174e0 = document["querySelector"](".pagination__next.icon-btn"),
    _0x654662 = document["createElement"]("button");
  return (
    (_0x654662["innerHTML"] = "Add\x201000"),
    (_0x654662["id"] = "nextButton"),
    (_0x654662["className"] = "next-button"),
    (_0x654662["style"]["backgroundColor"] =
      _0x4174e0["style"]["backgroundColor"]),
    (_0x654662["onclick"] = function () {
      (console["log"]("next\x20page"), _0x4174e0["click"](), _0x231319++);
    }),
    _0x654662
  );
}
console["log"]("ebay/promoted_listings/content.js");
var _0x211390 = ".item-count-summary";
async function _0x1c8677() {
  (console["log"]("Element\x20added!"), setInterval(_0x1c5268, 0x3e8));
}
async function _0x1c5268() {
  if (!(_0x3d68cc = document["querySelector"](".next-button"))) {
    var _0x11f5ef = document["querySelector"](_0x211390),
      _0x3d68cc = await _0x595ed5();
    (_0x11f5ef["parentElement"]["parentElement"]["appendChild"](_0x3d68cc),
      document["querySelector"](
        "input[aria-label=\x27Select\x20all\x20listings\x20for\x20performing\x20bulk\x20action\x27]",
      )["click"]());
  }
  _0x231319 > 0x0 &&
    _0x231319 < 0xc &&
    (console["log"]("next\x20page\x20counter\x20", _0x231319),
    _0x3d68cc["click"]());
}
const _0xd07f44 = new MutationObserver((_0x21f6e8, _0x45a05f) => {
  for (let _0x2ea89d of _0x21f6e8)
    if (
      "childList" === _0x2ea89d["type"] &&
      document["querySelector"](_0x211390)
    ) {
      (console["log"]("Element\x20found"),
        _0x1c8677(),
        _0x45a05f["disconnect"]());
      break;
    }
});
_0xd07f44["observe"](document["body"], { childList: !0x0, subtree: !0x0 });
