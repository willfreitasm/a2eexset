function _0x532abf() {
  return new Promise((_0x42303c) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x42303c();
      });
    });
  });
}
function _0x4676e8() {
  return new Promise((_0x437d59) => {
    requestIdleCallback(() => {
      _0x437d59();
    });
  });
}
function _0x3cd25a(_0x484ad9 = 0x3e8) {
  return new Promise((_0x496462, _0x35e4eb) => {
    let _0x2d430d,
      _0x1c7c46 = Date["now"](),
      _0x4d2690 = !0x1;
    function _0x319c1e() {
      if (Date["now"]() - _0x1c7c46 > _0x484ad9)
        (_0x4d2690 && _0x2d430d["disconnect"](), _0x496462());
      else setTimeout(_0x319c1e, _0x484ad9);
    }
    const _0x44d4e2 = () => {
        _0x1c7c46 = Date["now"]();
      },
      _0x4d31ed = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x2d430d = new MutationObserver(_0x44d4e2)),
        _0x2d430d["observe"](document["body"], _0x4d31ed),
        (_0x4d2690 = !0x0),
        setTimeout(_0x319c1e, _0x484ad9));
    else
      window["onload"] = () => {
        ((_0x2d430d = new MutationObserver(_0x44d4e2)),
          _0x2d430d["observe"](document["body"], _0x4d31ed),
          (_0x4d2690 = !0x0),
          setTimeout(_0x319c1e, _0x484ad9));
      };
  });
}
async function _0xfe6d81() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x3cd25a(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
console["log"]("home\x20depot\x20search\x20functions.js\x20loaded");
function _0x26b068() {
  return document["querySelectorAll"](
    "[id*=\x22browse-search-pods-\x22]\x20[class*=\x22browse-search__pod\x22]",
  );
}
function _0x350651(_0x562727) {
  const _0x22ffd8 = _0x562727["querySelector"](
    "[data-testid=\x22attribute-product-label\x22]",
  );
  return _0x22ffd8 ? _0x22ffd8["textContent"]["trim"]() : null;
}
function _0x1b2749(_0x5614f3) {
  const _0x2e2ec9 = _0x5614f3["querySelector"](
    "[data-testid=\x22attribute-brandname-above\x22]",
  );
  return _0x2e2ec9 ? _0x2e2ec9["textContent"]["trim"]() : null;
}
function _0x517aac(_0x3cba5b) {
  var _0x564132 = _0x3cba5b["querySelector"](
    "[data-testid=\x22price-simple\x22]",
  );
  if (!_0x564132) return null;
  var _0x5ec8b7 = _0x564132["textContent"]["trim"]();
  return (
    _0x5ec8b7["includes"]("Was") &&
      (_0x5ec8b7 = _0x5ec8b7["split"]("Was")[0x0]),
    (_0x5ec8b7 = (_0x5ec8b7 = _0x5ec8b7["split"]("$")[0x1])["replace"](
      /[^0-9.-]+/g,
      "",
    ))["includes"]("-") && (_0x5ec8b7 = _0x5ec8b7["split"]("-")[0x0]),
    (_0x5ec8b7 = Number(_0x5ec8b7)),
    isNaN(_0x5ec8b7) ? 0x0 : _0x5ec8b7
  );
}
function _0x19d8a6(_0x5f4fa9) {
  const _0xd7c688 = _0x5f4fa9["querySelector"](
    "[data-component=\x22podMessageDelivery\x22]",
  );
  if (!_0xd7c688) return null;
  const _0x3687d3 = _0xd7c688["querySelector"](".sui-text-success");
  return _0x3687d3
    ? _0x3687d3["textContent"]["trim"]()
    : _0xd7c688["textContent"]["trim"]();
}
function _0x4f1d27(_0x133bab) {
  const _0x2fee1c = _0x133bab["querySelector"]("a[aria-label=\x22Link\x22]");
  if (!_0x2fee1c) return null;
  const _0x7a6dba = _0x2fee1c["getAttribute"]("href");
  return (_0x7a6dba && _0x7a6dba["split"]("/")["pop"]()) || null;
}
function _0x796376(_0x18e745) {
  var _0x1c0232 = _0x18e745["querySelector"](
    "[data-testid=\x22product-image__wrapper\x22]\x20img",
  );
  return _0x1c0232 ? _0x1c0232["getAttribute"]("src") : null;
}
function _0x521f1e(_0x8e62cf) {
  return {
    title: _0x350651(_0x8e62cf),
    brand: _0x1b2749(_0x8e62cf),
    price: _0x517aac(_0x8e62cf),
    delivery: _0x19d8a6(_0x8e62cf),
    asin: _0x4f1d27(_0x8e62cf),
    image: _0x796376(_0x8e62cf),
  };
}
function _0x1d1380() {
  return document["querySelector"](
    ".browse-search__pod-col-no-padding\x20[aria-label=\x22Skip\x20to\x20Next\x20Page\x22]",
  );
}
function _0xb78863() {
  _0x1d1380()["click"]();
}
function _0x17f1a7() {
  var _0x4a83c7 = _0x1d1380();
  return !(
    !_0x4a83c7 ||
    _0x4a83c7["disabled"] ||
    "true" === _0x4a83c7["getAttribute"]("aria-disabled")
  );
}
function _0x119663(_0x1f4a3e = 0x3e8, _0x2ebf7e = 0x2710) {
  return new Promise((_0x82a6c3, _0x4c8735) => {
    let _0x4d2f7a = null;
    const _0x2fd268 = setTimeout(() => {
        (_0x5a66e8["disconnect"](),
          console["log"]("Max\x20wait\x20reached.\x20Proceeding."),
          _0x82a6c3());
      }, _0x2ebf7e),
      _0x5a66e8 = new MutationObserver(() => {
        (_0x4d2f7a && clearTimeout(_0x4d2f7a),
          (_0x4d2f7a = setTimeout(() => {
            (_0x5a66e8["disconnect"](),
              clearTimeout(_0x2fd268),
              console["log"]("Page\x20stabilized."),
              _0x82a6c3());
          }, _0x1f4a3e)));
      });
    _0x5a66e8["observe"](document["body"], {
      childList: !0x0,
      subtree: !0x0,
      attributes: !0x0,
      characterData: !0x0,
    });
  });
}
async function _0x19b01d() {
  let _0x3f1d98 = 0x0,
    _0xe7d2d2 = document["body"]["scrollHeight"];
  for (; _0xe7d2d2 > _0x3f1d98; ) {
    (window["scrollTo"](0x0, _0xe7d2d2),
      await new Promise((_0x2837db) => setTimeout(_0x2837db, 0x3e8)),
      (_0x3f1d98 = _0xe7d2d2),
      (_0xe7d2d2 = document["body"]["scrollHeight"]));
  }
  console["log"]("All\x20products\x20are\x20loaded.");
}
console["log"]("home\x20depot\x20search\x20content.js\x20loaded.");
async function _0x5283a2() {
  await _0x3cd25a();
  var _0x597d50 = await _0xe2f9ff();
  (console["log"]("Total\x20products:\x20" + _0x597d50["length"]),
    console["log"](_0x597d50));
}
chrome["runtime"]["onMessage"]["addListener"](
  function (_0x5c90ed, _0x2f4ba9, _0x4c885b) {
    if ("get-top-items" === _0x5c90ed["type"]) {
      _0x4c885b({
        type: "get-top-items",
        message: "get-top-items\x20message\x20received.",
      });
      var _0x5234b8 = [];
      (_0x5c90ed["products"] && (_0x5234b8 = _0x5c90ed["products"]),
        console["log"]("getProducts\x20message\x20received."),
        _0xe2f9ff(_0x5234b8));
    }
    return !0x0;
  },
);
async function _0xe2f9ff(_0x1c1356) {
  var _0x57b470 = _0x26b068();
  ((document["title"] = "Found\x20" + _0x57b470["length"] + "\x20products."),
    await _0x3cd25a(),
    (_0x57b470 = _0x26b068()),
    (document["title"] = "Found\x20" + _0x57b470["length"] + "\x20products."),
    await _0x19b01d(),
    (document["title"] = "Loading\x20products..."),
    (_0x57b470 = _0x26b068()),
    (document["title"] = "Found\x20" + _0x57b470["length"] + "\x20products."),
    await _0x3cd25a(),
    (document["title"] = "Products\x20loaded."),
    (_0x57b470 = _0x26b068()),
    (document["title"] = "Found\x20" + _0x57b470["length"] + "\x20products."));
  for (;;) {
    ((_0x57b470 = _0x26b068()),
      console["log"]("Scraping\x20" + _0x57b470["length"] + "\x20products."),
      (document["title"] = "Found\x20" + _0x57b470["length"] + "\x20products."),
      _0x57b470["forEach"]((_0x27b141) => {
        const _0x3a51dc = _0x521f1e(_0x27b141);
        _0x1c1356["push"](_0x3a51dc);
      }));
    if (!_0x17f1a7()) {
      console["log"](
        "No\x20next\x20page\x20available.\x20Scraping\x20complete.",
      );
      break;
    }
    var _0x364474 = { type: "get-top-items", products: _0x1c1356 };
    (chrome["runtime"]["sendMessage"]({
      type: "resend_message_to_tab_on_update",
      message: _0x364474,
    }),
      _0xb78863(),
      await _0x3cd25a(),
      await _0x19b01d(),
      await _0x3cd25a());
    break;
  }
  return (
    chrome["runtime"]["sendMessage"]({
      type: "found_home_depot_items",
      products: _0x1c1356,
    }),
    _0x1c1356
  );
}
