function _0x3b99a4() {
  return new Promise((_0x18108d) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x18108d();
      });
    });
  });
}
function _0x58a77c() {
  return new Promise((_0x5e34f2) => {
    requestIdleCallback(() => {
      _0x5e34f2();
    });
  });
}
function _0x2fba5f(_0x44e621 = 0x3e8) {
  return new Promise((_0x240286, _0x30d59f) => {
    let _0x46a541,
      _0x244f8f = Date["now"](),
      _0x3a71ee = !0x1;
    function _0x2dcd26() {
      if (Date["now"]() - _0x244f8f > _0x44e621)
        (_0x3a71ee && _0x46a541["disconnect"](), _0x240286());
      else setTimeout(_0x2dcd26, _0x44e621);
    }
    const _0x2557fd = () => {
        _0x244f8f = Date["now"]();
      },
      _0x2a4a30 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x46a541 = new MutationObserver(_0x2557fd)),
        _0x46a541["observe"](document["body"], _0x2a4a30),
        (_0x3a71ee = !0x0),
        setTimeout(_0x2dcd26, _0x44e621));
    else
      window["onload"] = () => {
        ((_0x46a541 = new MutationObserver(_0x2557fd)),
          _0x46a541["observe"](document["body"], _0x2a4a30),
          (_0x3a71ee = !0x0),
          setTimeout(_0x2dcd26, _0x44e621));
      };
  });
}
async function _0x593ff1() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x2fba5f(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
console["log"]("ebay\x20contact\x20functions.js\x20loaded");
var _0x7cd3f7,
  _0x106426 = 0x0,
  _0x223aef = 0x9,
  _0xc0fa5e;
function _0x338917() {
  document["querySelectorAll"](".quick_chat_button")["forEach"](
    (_0x4967bf, _0x126b20) => {
      _0x4967bf["style"]["display"] =
        _0x126b20 >= _0x106426 * _0x223aef &&
        _0x126b20 < (_0x106426 + 0x1) * _0x223aef
          ? "block"
          : "none";
    },
  );
}
function _0x4f97a6(_0x5110f0) {
  var _0x3166cb = document["createElement"]("button");
  return (
    (_0x3166cb["textContent"] = "left" === _0x5110f0 ? "<" : ">"),
    (_0x3166cb["className"] = "navigation-button"),
    (_0x3166cb["onclick"] = function (_0xadecc0) {
      (_0xadecc0["preventDefault"](),
        (_0x106426 =
          "left" === _0x5110f0
            ? Math["max"](0x0, _0x106426 - 0x1)
            : Math["min"](
                _0x106426 + 0x1,
                Math["ceil"](_0xc0fa5e["length"] / _0x223aef) - 0x1,
              )),
        _0x338917());
    }),
    _0x3166cb
  );
}
async function _0x25683f(_0x2a7c5a, _0x8ece30) {
  _0x7cd3f7 = _0x2a7c5a;
  var _0x4a97b9 = await chrome["storage"]["local"]["get"]("quick_chat_buttons");
  _0xc0fa5e = _0x4a97b9["quick_chat_buttons"];
  var _0x674ac = document["createElement"]("div");
  _0x674ac["className"] = "main-container";
  var _0x1ae6e1 = document["createElement"]("div");
  _0x1ae6e1["className"] = "button-grid";
  for (var _0x966329 = 0x0; _0x966329 < _0xc0fa5e["length"]; _0x966329++) {
    var _0x42baad = _0x2cc761(
      _0xc0fa5e[_0x966329]["name"],
      _0xc0fa5e[_0x966329]["messages"],
      _0xc0fa5e[_0x966329]["color"],
    );
    _0x1ae6e1["append"](_0x42baad);
  }
  var _0xa7efcd = document["createElement"]("div");
  _0xa7efcd["className"] = "nav-container";
  var _0x22bb5e = _0x4f97a6("left"),
    _0xb38eeb = _0x4f97a6("right");
  (_0xa7efcd["append"](_0x22bb5e),
    _0xa7efcd["append"](_0xb38eeb),
    _0x674ac["append"](_0x1ae6e1),
    _0x674ac["append"](_0xa7efcd),
    _0x8ece30["append"](_0x674ac),
    _0x338917());
}
function _0x2cc761(_0x4e7aac, _0x1aec5a, _0x51a6a3) {
  var _0x1629be = document["createElement"]("button");
  ((_0x1629be["innerHTML"] = _0x4e7aac),
    (_0x1629be["style"]["backgroundColor"] = _0x51a6a3),
    (_0x1629be["className"] = "quick_chat_button"),
    _0x1629be["classList"]["add"]("draggable"));
  for (var _0x417c6e = 0x0; _0x417c6e < _0x1aec5a["length"]; _0x417c6e++) {
    var _0x2cc00b = document["createAttribute"]("data-message-" + _0x417c6e);
    ((_0x2cc00b["value"] = _0x1aec5a[_0x417c6e]),
      _0x1629be["setAttributeNode"](_0x2cc00b),
      0x0 === _0x417c6e && _0x1629be["setAttribute"]("data-checked", "0"));
  }
  return (
    (_0x1629be["onclick"] = function (_0x3d05bc) {
      _0x3d05bc["preventDefault"]();
      var _0x19861c = parseInt(this["getAttribute"]("data-checked")),
        _0x2eaf84 = (_0x19861c + 0x1) % _0x1aec5a["length"];
      (_0x92db6e(this["getAttribute"]("data-message-" + _0x19861c), _0x7cd3f7),
        this["setAttribute"]("data-checked", _0x2eaf84["toString"]()));
    }),
    _0x1629be
  );
}
function _0x551bc2(_0x386e56) {
  return document["querySelector"](_0x386e56);
}
function _0x92db6e(_0xd3161e, _0x254a2d) {
  var _0x305c61 = _0x254a2d;
  setTimeout(() => {
    ((_0x305c61["value"] = _0xd3161e),
      _0x305c61["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
      _0x5c748d(_0x254a2d));
  }, 0x64);
}
function _0x5c748d(_0x8eb1d9) {
  var _0x159a71 = _0x8eb1d9["value"]["length"];
  if (_0x8eb1d9["setSelectionRange"])
    (_0x8eb1d9["focus"](),
      _0x8eb1d9["setSelectionRange"](_0x159a71, _0x159a71));
  else {
    if (_0x8eb1d9["createTextRange"]) {
      var _0x234369 = _0x8eb1d9["createTextRange"]();
      (_0x234369["collapse"](!0x0),
        _0x234369["moveEnd"]("character", _0x159a71),
        _0x234369["moveStart"]("character", _0x159a71),
        _0x234369["select"]());
    }
  }
}
console["log"]("ebay\x20contact\x20content.js\x20loaded");
var _0x581f5f, _0x64ba42, _0x82610d;
document["addEventListener"]("DOMContentLoaded", async function () {
  (console["log"]("ebay\x20contact\x20content.js\x20DOMContentLoaded"),
    await _0x2fba5f(),
    console["log"](
      "ebay\x20contact\x20content.js\x20DOMContentLoaded\x20onPageLoadAndStable",
    ));
  var { quick_chat_switch: _0x48ebe4 } =
    await chrome["storage"]["local"]["get"]("quick_chat_switch");
  if (_0x48ebe4) {
    var _0x384691 = window["location"]["href"];
    (_0x384691["includes"]("/contact/") &&
      (console["log"]("ebay\x20contact\x20content.js\x20loaded"),
      (_0x64ba42 = document["querySelector"]("#msg_cnt_cnt")),
      (_0x581f5f =
        _0x64ba42["parentElement"]["parentElement"]["nextElementSibling"])),
      _0x384691["includes"]("/viewMessage?") &&
        (console["log"]("ebay\x20viewMessage\x20content.js\x20loaded"),
        (_0x64ba42 = document["querySelector"](
          "#imageupload__sendmessage--textbox",
        )),
        (_0x581f5f =
          _0x64ba42["parentElement"]["parentElement"]["parentElement"][
            "parentElement"
          ]["parentElement"])),
      _0x384691["includes"]("/cnt/ReplyToMessages") &&
        (console["log"]("ebay\x20cnt/ReplyToMessages\x20content.js\x20loaded"),
        (_0x64ba42 = document["querySelector"]("#app-page-form-message-0")),
        (_0x581f5f =
          _0x64ba42["parentElement"]["parentElement"]["parentElement"][
            "nextElementSibling"
          ])),
      await _0x25683f(_0x64ba42, _0x581f5f),
      _0x64ba42["addEventListener"]("input", _0x2d45d3(_0x323c6e, 0x12c)));
  } else console["log"]("quick_chat_switch\x20is\x20off");
});
function _0x2d45d3(_0x1beaca, _0x5c4edf) {
  return function () {
    const _0x4a2e2d = this,
      _0x5167d6 = arguments;
    (clearTimeout(_0x82610d),
      (_0x82610d = setTimeout(
        () => _0x1beaca["apply"](_0x4a2e2d, _0x5167d6),
        _0x5c4edf,
      )));
  };
}
async function _0x323c6e(_0x3f7c6c) {
  console["log"]("Chat\x20box\x20changed");
  var _0x722db8 = _0x64ba42["value"];
  const _0x115adb = /{{(.*?)}}/g;
  let _0x223e10;
  for (; null !== (_0x223e10 = _0x115adb["exec"](_0x722db8)); ) {
    let _0x32ea29 = _0x223e10[0x0],
      _0xa32bb2 = _0x223e10[0x1],
      _0x296788 = prompt(
        "Please\x20enter\x20a\x20value\x20for\x20" + _0xa32bb2 + ":",
      );
    if (null === _0x296788) {
      alert(
        "You\x20cancelled\x20the\x20input.\x20Placeholder\x20will\x20remain\x20unchanged.",
      );
      break;
    }
    _0x92db6e(
      (_0x722db8 = _0x722db8["replace"](_0x32ea29, _0x296788)),
      _0x64ba42,
    );
  }
}
