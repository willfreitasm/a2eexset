function _0x531dee() {
  return new Promise((_0x430888) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x430888();
      });
    });
  });
}
function _0x42ef43() {
  return new Promise((_0x1d5b75) => {
    requestIdleCallback(() => {
      _0x1d5b75();
    });
  });
}
function _0x54f470(_0x1c25fd = 0x3e8) {
  return new Promise((_0x4cda25, _0xa41918) => {
    let _0xc7be78,
      _0x5b77ab = Date["now"](),
      _0x3a8604 = !0x1;
    function _0x4727d8() {
      if (Date["now"]() - _0x5b77ab > _0x1c25fd)
        (_0x3a8604 && _0xc7be78["disconnect"](), _0x4cda25());
      else setTimeout(_0x4727d8, _0x1c25fd);
    }
    const _0x9eab2c = () => {
        _0x5b77ab = Date["now"]();
      },
      _0x12ea8e = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0xc7be78 = new MutationObserver(_0x9eab2c)),
        _0xc7be78["observe"](document["body"], _0x12ea8e),
        (_0x3a8604 = !0x0),
        setTimeout(_0x4727d8, _0x1c25fd));
    else
      window["onload"] = () => {
        ((_0xc7be78 = new MutationObserver(_0x9eab2c)),
          _0xc7be78["observe"](document["body"], _0x12ea8e),
          (_0x3a8604 = !0x0),
          setTimeout(_0x4727d8, _0x1c25fd));
      };
  });
}
async function _0x4918b8() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x54f470(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x2b3cb7(_0x4b2667) {
  try {
    try {
      var _0x32e69f = new Date(_0x4b2667);
      if (!isNaN(_0x32e69f)) return _0x32e69f;
    } catch (_0x5de69a) {}
    var _0x3bb79e = _0x4b2667["split"](",")[0x0]
      ["trim"]()
      ["match"](/(\d+)\.? ?(\w+)[.]? ?(\d+)/);
    if (!_0x3bb79e)
      return (
        console["error"]("Date\x20string\x20not\x20recognized:", _0x4b2667),
        null
      );
    console["log"]("match:\x20", _0x3bb79e);
    const _0x2862e1 = _0x3bb79e[0x1],
      _0x4cadaa = _0x3bb79e[0x2]["toLowerCase"](),
      _0x13bb8f = _0x3bb79e[0x3],
      _0x735129 = _0x1471bf[_0x4cadaa];
    if (!_0x735129)
      return (console["error"]("Month\x20not\x20recognized:", _0x4cadaa), null);
    const _0x1ca590 = _0x13bb8f + "-" + _0x735129 + "-" + _0x2862e1,
      _0x35628a = new Date(_0x1ca590);
    if (isNaN(_0x35628a))
      return (console["error"]("Invalid\x20date\x20parsed:", _0x1ca590), null);
    return _0x35628a;
  } catch (_0x3a18f9) {
    return (
      console["error"]("Error\x20parsing\x20date:", _0x4b2667, _0x3a18f9),
      null
    );
  }
}
const _0x1471bf = {
  gen: "01",
  genn: "01",
  feb: "02",
  febb: "02",
  mar: "03",
  apr: "04",
  mag: "05",
  magg: "05",
  giu: "06",
  lug: "07",
  ago: "08",
  set: "09",
  sett: "09",
  ott: "10",
  nov: "11",
  dic: "12",
  ene: "01",
  feb: "02",
  mar: "03",
  abr: "04",
  may: "05",
  jun: "06",
  jul: "07",
  ago: "08",
  sep: "09",
  oct: "10",
  nov: "11",
  dic: "12",
  janv: "01",
  févr: "02",
  mars: "03",
  avr: "04",
  mai: "05",
  juin: "06",
  juil: "07",
  août: "08",
  sept: "09",
  oct: "10",
  nov: "11",
  déc: "12",
  jan: "01",
  feb: "02",
  märz: "03",
  mrz: "03",
  apr: "04",
  mai: "05",
  juni: "06",
  juli: "07",
  aug: "08",
  sept: "09",
  okt: "10",
  nov: "11",
  dez: "12",
  jan: "01",
  feb: "02",
  mar: "03",
  apr: "04",
  may: "05",
  jun: "06",
  jul: "07",
  aug: "08",
  sep: "09",
  oct: "10",
  nov: "11",
  dec: "12",
};
var _0x3be030 = _0x2b3cb7("Aug\x2030\x202024");
(console["log"](_0x3be030),
  console["log"]("ebay/purchase_history/functions.js\x20loaded"));
function _0x355878(_0x27dd0a) {
  console["log"]("get\x20total\x20sold\x20-----------------\x0a\x0a");
  var _0x1e07ca = new Date();
  let _0x2d82d5 = 0x0;
  var _0x2c05d9 = null;
  document["querySelectorAll"](".app-table__table")["forEach"]((_0x1e7aa7) => {
    _0x1e7aa7["querySelectorAll"]("thead\x20th\x20span\x20span")["forEach"](
      (_0x567637, _0x4635cd) => {
        ("Date\x20of\x20purchase" !== _0x567637["textContent"] &&
          "Data\x20di\x20acquisto" !== _0x567637["textContent"] &&
          "Fecha\x20de\x20compra" !== _0x567637["textContent"] &&
          "Date\x20d\x27achat" !== _0x567637["textContent"] &&
          "Kaufdatum" !== _0x567637["textContent"] &&
          "Date\x20de\x20l\x27achat" !== _0x567637["textContent"]) ||
          (_0x2c05d9 = _0x1e7aa7);
      },
    );
  });
  if (!_0x2c05d9)
    return (console["error"]("Purchase\x20table\x20not\x20found."), 0x0);
  var _0x1391a5 = _0x2c05d9["querySelectorAll"]("thead\x20th\x20span\x20span");
  let _0x2332ef = -0x1,
    _0x126e77 = -0x1;
  _0x1391a5["forEach"]((_0x465df9, _0x4cfdc1) => {
    if (
      "Quantity" === _0x465df9["textContent"] ||
      "Quantità" === _0x465df9["textContent"] ||
      "Cantidad" === _0x465df9["textContent"] ||
      "Quantité" === _0x465df9["textContent"] ||
      "Menge" === _0x465df9["textContent"] ||
      "Stückzahl" === _0x465df9["textContent"]
    ) {
      if (_0x2332ef > -0x1) {
        console["log"]("quantityIndex\x20already\x20found");
        return;
      }
      _0x2332ef = _0x4cfdc1;
    } else {
      if (
        "Date\x20of\x20purchase" === _0x465df9["textContent"] ||
        "Data\x20di\x20acquisto" === _0x465df9["textContent"] ||
        "Fecha\x20de\x20compra" === _0x465df9["textContent"] ||
        "Date\x20d\x27achat" === _0x465df9["textContent"] ||
        "Kaufdatum" === _0x465df9["textContent"] ||
        "Date\x20de\x20l\x27achat" === _0x465df9["textContent"]
      ) {
        if (_0x126e77 > -0x1) {
          console["log"]("dateIndex\x20already\x20found");
          return;
        }
        _0x126e77 = _0x4cfdc1;
      }
    }
  });
  if (-0x1 === _0x2332ef || -0x1 === _0x126e77)
    return (
      console["error"](
        "Quantity\x20or\x20Date\x20of\x20Purchase\x20column\x20not\x20found.",
      ),
      0x0
    );
  var _0x30692b = _0x2c05d9["querySelectorAll"]("tbody\x20tr");
  return (
    _0x30692b[0x0],
    _0x30692b["forEach"]((_0x3c5baf) => {
      var _0x15668d = _0x3c5baf["querySelectorAll"]("td");
      console["log"]("dateIndex\x20getTotalSoldInLastXDays:\x20", _0x126e77);
      var _0x47805a = _0x15668d[_0x126e77]["textContent"];
      (parseInt(_0x15668d[_0x2332ef]["textContent"], 0xa),
        console["log"]("dateString:\x20", _0x47805a));
      var _0x486a82 = _0x2b3cb7(_0x47805a);
      console["log"]("purchaseDate:\x20", _0x486a82);
      var _0x52f2cc = Math["abs"](_0x1e07ca - _0x486a82);
      Math["ceil"](_0x52f2cc / 0x5265c00) <= _0x27dd0a && (_0x2d82d5 += 0x1);
    }),
    console["log"]("end\x20of\x20total\x20sold\x20-----------------\x0a\x0a"),
    _0x2d82d5
  );
}
function _0x117906(_0xa57f80) {
  var _0x19a951 = new Date();
  let _0x39d14a = 0x0;
  var _0x5164c0 = document["querySelectorAll"](".app-table__table"),
    _0x2e6c77 = null;
  _0x5164c0["forEach"]((_0x3c3541) => {
    _0x3c3541["querySelectorAll"]("thead\x20th\x20span\x20span")["forEach"](
      (_0x334245, _0x2c4034) => {
        ("Date\x20of\x20offer" !== _0x334245["textContent"] &&
          "Data\x20di\x20offerta" !== _0x334245["textContent"] &&
          "Fecha\x20de\x20oferta" !== _0x334245["textContent"] &&
          "Date\x20d\x27offre" !== _0x334245["textContent"] &&
          "Angebotsdatum" !== _0x334245["textContent"] &&
          "Datum\x20des\x20Preisvorschlags" !== _0x334245["textContent"] &&
          "Data\x20della\x20proposta" !== _0x334245["textContent"] &&
          "Date\x20de\x20l\x27offre" !== _0x334245["textContent"]) ||
          (_0x2e6c77 = _0x3c3541);
      },
    );
  });
  if (!_0x2e6c77)
    return (console["error"]("Offer\x20table\x20not\x20found."), 0x0);
  var _0x18ae64 = _0x2e6c77["querySelectorAll"]("thead\x20th\x20span\x20span");
  let _0x21f521 = -0x1,
    _0xe7d27b = -0x1;
  _0x18ae64["forEach"]((_0x49f74c, _0x4a6b5c) => {
    if (
      "Quantity" === _0x49f74c["textContent"] ||
      "Quantità" === _0x49f74c["textContent"] ||
      "Cantidad" === _0x49f74c["textContent"] ||
      "Quantité" === _0x49f74c["textContent"] ||
      "Menge" === _0x49f74c["textContent"] ||
      "Stückzahl" === _0x49f74c["textContent"]
    ) {
      if (_0x21f521 > -0x1) {
        console["log"]("quantityIndex\x20already\x20found");
        return;
      }
      _0x21f521 = _0x4a6b5c;
    } else {
      if (
        "Date\x20of\x20offer" === _0x49f74c["textContent"] ||
        "Data\x20di\x20offerta" === _0x49f74c["textContent"] ||
        "Fecha\x20de\x20oferta" === _0x49f74c["textContent"] ||
        "Date\x20d\x27offre" === _0x49f74c["textContent"] ||
        "Angebotsdatum" === _0x49f74c["textContent"] ||
        "Datum\x20des\x20Preisvorschlags" === _0x49f74c["textContent"] ||
        "Data\x20della\x20proposta" === _0x49f74c["textContent"]
      ) {
        if (_0xe7d27b > -0x1) {
          console["log"]("dateIndex\x20already\x20found");
          return;
        }
        _0xe7d27b = _0x4a6b5c;
      }
    }
  });
  if (-0x1 === _0x21f521 || -0x1 === _0xe7d27b)
    return (
      console["error"](
        "Quantity\x20or\x20Date\x20of\x20Purchase\x20column\x20not\x20found.",
      ),
      0x0
    );
  return (
    _0x2e6c77["querySelectorAll"]("tbody\x20tr")["forEach"]((_0x17c781) => {
      (console["log"]("row:\x20", _0x17c781),
        console["log"]("dateIndex:\x20", _0xe7d27b));
      var _0x2cf93f = _0x17c781["querySelectorAll"]("td"),
        _0x42e660 = _0x2cf93f[_0xe7d27b]["textContent"];
      (parseInt(_0x2cf93f[_0x21f521]["textContent"], 0xa),
        console["log"]("dateString:\x20", _0x42e660));
      var _0x28ff81 = _0x2b3cb7(_0x42e660),
        _0x1147d3 = Math["abs"](_0x19a951 - _0x28ff81);
      Math["ceil"](_0x1147d3 / 0x5265c00) <= _0xa57f80 && (_0x39d14a += 0x1);
    }),
    _0x39d14a
  );
}
console["log"]("ebay/purchase_history/content.js\x20loaded");
async function _0x1c7881() {
  (console["log"](
    "Waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x54f470(),
    console["log"]("Page\x20is\x20loaded\x20and\x20stable"),
    console["log"](
      "Total\x20sold\x20in\x20last\x2030\x20days:\x20",
      _0x355878(0x1e),
    ));
  var _0x26bd63 = _0x117906(0x1e);
  console["log"](
    "Total\x20offered\x20in\x20last\x2030\x20days:\x20",
    _0x26bd63,
  );
}
(_0x1c7881(),
  chrome["runtime"]["onMessage"]["addListener"](
    function (_0x3ed5f5, _0x54398f, _0x44cff0) {
      console["log"]("request", _0x3ed5f5);
      if ("get-total-sold" === _0x3ed5f5["type"])
        return (
          console["log"]("get-total-sold\x20message\x20received"),
          _0x54f470()["then"](() => {
            console["log"]("onPageLoadAndStable\x20callback");
            var _0x1cc001 = _0x355878(0x1);
            _0x1cc001 += _0x117906(0x1);
            var _0x1b63e0 = _0x355878(0x3);
            _0x1b63e0 += _0x117906(0x3);
            var _0x35057c = _0x355878(0x7);
            _0x35057c += _0x117906(0x7);
            var _0x1f01df = _0x355878(0xe);
            _0x1f01df += _0x117906(0xe);
            var _0x77c60e = _0x355878(0x1e);
            _0x77c60e += _0x117906(0x1e);
            var _0x59c427 = _0x355878(0x3c);
            _0x59c427 += _0x117906(0x3c);
            var _0x21676b = _0x355878(0x5a),
              _0x498475 = {
                totalSoldIn1: _0x1cc001,
                totalSoldIn3: _0x1b63e0,
                totalSoldIn7: _0x35057c,
                totalSoldIn14: _0x1f01df,
                totalSoldIn30: _0x77c60e,
                totalSoldIn60: _0x59c427,
                totalSoldIn90: (_0x21676b += _0x117906(0x5a)),
              };
            (console["log"]("completed\x20totalSold:\x20", _0x498475),
              chrome["runtime"]["sendMessage"]({
                type: "total-sold",
                totalSold: _0x498475,
              }));
          }),
          !0x0
        );
      return !0x0;
    },
  ));
