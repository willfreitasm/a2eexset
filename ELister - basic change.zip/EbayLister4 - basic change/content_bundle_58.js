function _0x587d15() {
  return new Promise((_0x208dc4) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x208dc4();
      });
    });
  });
}
function _0x12372b() {
  return new Promise((_0x196438) => {
    requestIdleCallback(() => {
      _0x196438();
    });
  });
}
function _0x49d42f(_0x43e2e5 = 0x3e8) {
  return new Promise((_0x59ab6c, _0x21a490) => {
    let _0x3123b7,
      _0xa12a09 = Date["now"](),
      _0x402da3 = !0x1;
    function _0x282e9e() {
      if (Date["now"]() - _0xa12a09 > _0x43e2e5)
        (_0x402da3 && _0x3123b7["disconnect"](), _0x59ab6c());
      else setTimeout(_0x282e9e, _0x43e2e5);
    }
    const _0x28fc8d = () => {
        _0xa12a09 = Date["now"]();
      },
      _0x4e8281 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x3123b7 = new MutationObserver(_0x28fc8d)),
        _0x3123b7["observe"](document["body"], _0x4e8281),
        (_0x402da3 = !0x0),
        setTimeout(_0x282e9e, _0x43e2e5));
    else
      window["onload"] = () => {
        ((_0x3123b7 = new MutationObserver(_0x28fc8d)),
          _0x3123b7["observe"](document["body"], _0x4e8281),
          (_0x402da3 = !0x0),
          setTimeout(_0x282e9e, _0x43e2e5));
      };
  });
}
async function _0x22c931() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x49d42f(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
(!(function () {
  var _0x28f9de = "iframe_utils";
  function _0x4391af(_0x2487df, _0x163296, _0x39a597, _0x519bd1) {
    (_0x519bd1 || (_0x519bd1 = "*"),
      _0x2487df["postMessage"](
        { namespace: _0x28f9de, type: _0x163296, payload: _0x39a597 || {} },
        _0x519bd1,
      ));
  }
  function _0x216928(_0x3bee83, _0x3b2dea) {
    window["addEventListener"]("message", function (_0xcb2486) {
      var _0x5a2499 = _0xcb2486 && _0xcb2486["data"];
      _0x5a2499 &&
        _0x5a2499["namespace"] === _0x28f9de &&
        (("*" !== _0x3bee83 && _0x5a2499["type"] !== _0x3bee83) ||
          _0x3b2dea(_0x5a2499["payload"], _0xcb2486));
    });
  }
  function _0x4317a1(_0x1f6b09, _0x61d77f, _0xea78fa) {
    return (
      "number" != typeof _0xea78fa && (_0xea78fa = 0x2710),
      new Promise(function (_0x53df7b, _0x43b5bc) {
        function _0x2f613d(_0x7601f1) {
          var _0x41e9e9 = _0x7601f1 && _0x7601f1["data"];
          _0x41e9e9 &&
            _0x7601f1["source"] === _0x1f6b09 &&
            _0x41e9e9["namespace"] === _0x28f9de &&
            _0x41e9e9["type"] === _0x61d77f &&
            (window["removeEventListener"]("message", _0x2f613d),
            _0x53df7b(_0x41e9e9["payload"]));
        }
        (window["addEventListener"]("message", _0x2f613d),
          _0xea78fa &&
            setTimeout(function () {
              (window["removeEventListener"]("message", _0x2f613d),
                _0x43b5bc(
                  new Error(
                    "Timed\x20out\x20waiting\x20for\x20message\x20from\x20source:\x20" +
                      _0x61d77f,
                  ),
                ));
            }, _0xea78fa));
      })
    );
  }
  var parent = {
      waitForIframe: function (_0x526723, _0x5be43b) {
        return (
          "number" != typeof _0x5be43b && (_0x5be43b = 0x2710),
          new Promise(function (_0x253f2d, _0x198414) {
            var _0x4efb84 =
              "string" == typeof _0x526723
                ? document["querySelector"](_0x526723)
                : _0x526723;
            function _0x939f4(_0x4aad3c) {
              if (
                _0x4aad3c &&
                "IFRAME" === _0x4aad3c["tagName"] &&
                _0x4aad3c["contentWindow"]
              ) {
                if (
                  _0x4aad3c["contentDocument"] &&
                  "complete" === _0x4aad3c["contentDocument"]["readyState"]
                )
                  return (_0x253f2d(_0x4aad3c), !0x0);
                return (
                  _0x4aad3c["addEventListener"](
                    "load",
                    function () {
                      _0x253f2d(_0x4aad3c);
                    },
                    { once: !0x0 },
                  ),
                  !0x0
                );
              }
              return !0x1;
            }
            if (!_0x939f4(_0x4efb84)) {
              var _0x5c94c7 = new MutationObserver(function () {
                _0x939f4(
                  (_0x4efb84 =
                    "string" == typeof _0x526723
                      ? document["querySelector"](_0x526723)
                      : _0x526723),
                ) && _0x5c94c7["disconnect"]();
              });
              (_0x5c94c7["observe"](document["body"], {
                childList: !0x0,
                subtree: !0x0,
              }),
                setTimeout(function () {
                  try {
                    _0x5c94c7["disconnect"]();
                  } catch (_0x2ddead) {}
                  _0x198414(new Error("Timeout\x20waiting\x20for\x20iframe"));
                }, _0x5be43b));
            }
          })
        );
      },
      waitForIframeReady: function (_0x580c79, _0xd0d2c5) {
        return (
          "number" != typeof _0xd0d2c5 && (_0xd0d2c5 = 0x3a98),
          new Promise(function (_0x29db42, _0xa87837) {
            parent["waitForIframe"](_0x580c79, _0xd0d2c5)
              ["then"](function (_0x5552ea) {
                var _0x325b65 = _0x5552ea && _0x5552ea["contentWindow"];
                _0x325b65
                  ? (function (_0x14c1e1, _0x2dd097) {
                      "number" != typeof _0x2dd097 && (_0x2dd097 = 0x3a98);
                      var _0x1981c8 = Math["max"](
                        0xbb8,
                        Math["floor"](_0x2dd097 / 0x2),
                      );
                      return new Promise(function (_0x5665e5, _0x2f01a4) {
                        _0x4317a1(_0x14c1e1, "iframe_ready", _0x1981c8)
                          ["then"](function () {
                            _0x5665e5(!0x0);
                          })
                          ["catch"](function () {
                            try {
                              _0x4391af(
                                _0x14c1e1,
                                "ping_iframe_ready",
                                { ts: Date["now"]() },
                                "*",
                              );
                            } catch (_0x493f19) {}
                            _0x4317a1(_0x14c1e1, "iframe_ready", _0x1981c8)
                              ["then"](function () {
                                _0x5665e5(!0x0);
                              })
                              ["catch"](function () {
                                _0x2f01a4(
                                  new Error(
                                    "Timed\x20out\x20waiting\x20for\x20targeted\x20iframe_ready",
                                  ),
                                );
                              });
                          });
                      });
                    })(_0x325b65, _0xd0d2c5)
                      ["then"](function () {
                        _0x29db42(_0x5552ea);
                      })
                      ["catch"](function (_0x5e9f42) {
                        _0xa87837(_0x5e9f42);
                      })
                  : _0xa87837(
                      new Error("Iframe\x20has\x20no\x20contentWindow"),
                    );
              })
              ["catch"](function (_0x228a70) {
                _0xa87837(_0x228a70);
              });
          })
        );
      },
      sendMessage: function (_0x542c39, _0x4720f6, _0x43e71e) {
        if (!_0x542c39 || !_0x542c39["contentWindow"])
          throw new Error("iframe\x20element\x20not\x20ready");
        _0x4391af(_0x542c39["contentWindow"], _0x4720f6, _0x43e71e || {}, "*");
      },
      askIframe: function (_0x4cc1f1, _0x4fa131, _0x1b5fef, _0x34b82f) {
        return (
          _0x1b5fef || (_0x1b5fef = {}),
          "number" != typeof _0x34b82f && (_0x34b82f = 0x2710),
          parent["sendMessage"](_0x4cc1f1, _0x4fa131, _0x1b5fef),
          _0x4317a1(_0x4cc1f1["contentWindow"], _0x4fa131 + ":reply", _0x34b82f)
        );
      },
    },
    _0x203bb1 = {
      sendMessage: function (_0x190e03, _0x3e8474) {
        _0x4391af(window["parent"], _0x190e03, _0x3e8474 || {}, "*");
      },
      askParent: function (_0x7d28e7, _0xbc91cd, _0x226ce6) {
        return (
          _0xbc91cd || (_0xbc91cd = {}),
          "number" != typeof _0x226ce6 && (_0x226ce6 = 0x2710),
          _0x203bb1["sendMessage"](_0x7d28e7, _0xbc91cd),
          _0x4317a1(window["parent"], _0x7d28e7 + ":reply", _0x226ce6)
        );
      },
      announceReady: function () {
        _0x203bb1["sendMessage"]("iframe_ready", { ready: !0x0 });
      },
    };
  (_0x216928("ping_iframe_ready", function (_0x30c5e6, _0x3612ee) {
    try {
      _0x3612ee["source"]["postMessage"](
        {
          namespace: _0x28f9de,
          type: "iframe_ready",
          payload: { ready: !0x0 },
        },
        "*",
      );
    } catch (_0x2ae5a9) {}
  }),
    (window["iframeUtils"] = {
      core: {
        onMessage: _0x216928,
        waitForMessage: function (_0x1692b5, _0x27eaeb) {
          return (
            "number" != typeof _0x27eaeb && (_0x27eaeb = 0x2710),
            new Promise(function (_0x2b1d64, _0x1a60cc) {
              function _0x5ee50f(_0x55dd03) {
                var _0x330986 = _0x55dd03 && _0x55dd03["data"];
                _0x330986 &&
                  _0x330986["namespace"] === _0x28f9de &&
                  _0x330986["type"] === _0x1692b5 &&
                  (window["removeEventListener"]("message", _0x5ee50f),
                  _0x2b1d64(_0x330986["payload"]));
              }
              (window["addEventListener"]("message", _0x5ee50f),
                _0x27eaeb &&
                  setTimeout(function () {
                    (window["removeEventListener"]("message", _0x5ee50f),
                      _0x1a60cc(
                        new Error(
                          "Timed\x20out\x20waiting\x20for\x20message:\x20" +
                            _0x1692b5,
                        ),
                      ));
                  }, _0x27eaeb));
            })
          );
        },
        waitForMessageFrom: _0x4317a1,
      },
      parent: parent,
      child: _0x203bb1,
      responders: {
        handleRequest: function (_0x5c579b, _0x2c93dc) {
          _0x216928(_0x5c579b, function (_0x1fa378, _0x2fe2bb) {
            Promise["resolve"]()
              ["then"](function () {
                return _0x2c93dc(_0x1fa378, _0x2fe2bb);
              })
              ["then"](function (_0x45bbca) {
                _0x2fe2bb["source"]["postMessage"](
                  {
                    namespace: _0x28f9de,
                    type: _0x5c579b + ":reply",
                    payload: _0x45bbca,
                  },
                  "*",
                );
              })
              ["catch"](function (_0x42c94b) {
                _0x2fe2bb["source"]["postMessage"](
                  {
                    namespace: _0x28f9de,
                    type: _0x5c579b + ":reply",
                    payload: {
                      error:
                        _0x42c94b && _0x42c94b["message"]
                          ? _0x42c94b["message"]
                          : String(_0x42c94b),
                    },
                  },
                  "*",
                );
              });
          });
        },
      },
    }));
  if (window["self"] !== window["top"])
    try {
      _0x203bb1["announceReady"]();
    } catch (_0x36c34e) {}
})(),
  console["log"](
    "content/ebay/mesh_order_details/view_message_iframe/functions.js",
  ));
function _0x4974b3(_0x2dce59) {
  return new Promise(function (_0x4251b8) {
    setTimeout(_0x4251b8, _0x2dce59);
  });
}
function _0x3c5cb4(_0x4712c5) {
  return new Promise(function (_0x1bd556) {
    var _0x2ef713 = document["querySelector"](
      "#imageupload__sendmessage--textbox",
    );
    if (_0x2ef713) {
      _0x2ef713["focus"]();
      var _0x2cc49d =
          ((_0x19b1ed = _0x2ef713),
          (_0x844930 = Object["getPrototypeOf"](_0x19b1ed)),
          (_0x1aa252 = Object["getOwnPropertyDescriptor"](
            _0x844930,
            "value",
          )) && _0x1aa252["set"]
            ? _0x1aa252["set"]
            : null),
        _0x19b1ed,
        _0x844930,
        _0x1aa252;
      try {
        (_0x2ef713["select"] && _0x2ef713["select"](),
          _0x3c2668(_0x2ef713, "keydown", "Backspace"),
          _0x2cc49d
            ? _0x2cc49d["call"](_0x2ef713, "")
            : (_0x2ef713["value"] = ""),
          _0x404a21(_0x2ef713, ""),
          _0x2b43fd(_0x2ef713, ""),
          _0x3c2668(_0x2ef713, "keyup", "Backspace"),
          _0x52bbdb(_0x2ef713));
      } catch (_0x37faad) {
        (_0x2cc49d
          ? _0x2cc49d["call"](_0x2ef713, "")
          : (_0x2ef713["value"] = ""),
          _0x2ef713["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
      }
      var _0x54f8ae = 0x0;
      !(function _0x195fc6() {
        if (_0x54f8ae >= _0x4712c5["length"])
          !(function () {
            _0x2ef713["dispatchEvent"](new Event("change", { bubbles: !0x0 }));
            try {
              (_0x2ef713["blur"](),
                setTimeout(function () {
                  (_0x2ef713["focus"](),
                    _0x2ef713["dispatchEvent"](
                      new Event("input", { bubbles: !0x0 }),
                    ),
                    _0x1bd556(!0x0));
                }, 0x0));
            } catch (_0x4d03e5) {
              _0x1bd556(!0x0);
            }
          })();
        else {
          var _0x39d8da = _0x4712c5["charAt"](_0x54f8ae);
          (_0x3c2668(_0x2ef713, "keydown", _0x39d8da),
            _0x404a21(_0x2ef713, _0x39d8da));
          var _0x3a039a = (_0x2ef713["value"] || "") + _0x39d8da;
          (_0x2cc49d
            ? _0x2cc49d["call"](_0x2ef713, _0x3a039a)
            : (_0x2ef713["value"] = _0x3a039a),
            _0x52bbdb(_0x2ef713),
            _0x2b43fd(_0x2ef713, _0x39d8da),
            _0x3c2668(_0x2ef713, "keyup", _0x39d8da),
            (_0x54f8ae += 0x1),
            setTimeout(_0x195fc6, 0x0));
        }
      })();
    } else _0x1bd556(!0x1);
    function _0x3c2668(_0x1398aa, _0x3aa1d5, _0x4af504) {
      try {
        var _0x234c26 = new KeyboardEvent(_0x3aa1d5, {
          bubbles: !0x0,
          cancelable: !0x0,
          key: _0x4af504 || "a",
        });
        _0x1398aa["dispatchEvent"](_0x234c26);
      } catch (_0x210bed) {
        _0x1398aa["dispatchEvent"](
          new Event(_0x3aa1d5, { bubbles: !0x0, cancelable: !0x0 }),
        );
      }
    }
    function _0x404a21(_0x1cf9e0, _0x544844) {
      try {
        var _0xd29d87 = new InputEvent("beforeinput", {
          bubbles: !0x0,
          cancelable: !0x0,
          inputType: "insertText",
          data: _0x544844 || "",
        });
        _0x1cf9e0["dispatchEvent"](_0xd29d87);
      } catch (_0x1383c8) {
        _0x1cf9e0["dispatchEvent"](
          new Event("beforeinput", { bubbles: !0x0, cancelable: !0x0 }),
        );
      }
    }
    function _0x2b43fd(_0x14193a, _0x3ec90f) {
      try {
        var _0x583c7c = new InputEvent("input", {
          bubbles: !0x0,
          cancelable: !0x1,
          inputType: "insertText",
          data: _0x3ec90f || "",
        });
        _0x14193a["dispatchEvent"](_0x583c7c);
      } catch (_0x4fbcbb) {
        _0x14193a["dispatchEvent"](new Event("input", { bubbles: !0x0 }));
      }
    }
    function _0x52bbdb(_0x437448) {
      try {
        var _0x26f6e7 = _0x437448["value"]["length"];
        ((_0x437448["selectionStart"] = _0x26f6e7),
          (_0x437448["selectionEnd"] = _0x26f6e7));
      } catch (_0x2d9064) {}
    }
  });
}
async function _0x27f112(_0xb1fe95, _0xe2cebc) {
  var _0x23288b = Date["now"](),
    _0x14d1b3 = document["querySelector"](_0xb1fe95);
  if (!_0x14d1b3)
    throw new Error("Send\x20button\x20not\x20found:\x20" + _0xb1fe95);
  for (;;) {
    var _0x38a3e1 = _0x14d1b3["hasAttribute"]("disabled"),
      _0x90dfb2 = "true" === _0x14d1b3["getAttribute"]("aria-disabled"),
      _0x493a10 = /\bdisabled\b|\bis-disabled\b/["test"](
        _0x14d1b3["className"],
      );
    if (!_0x38a3e1 && !_0x90dfb2 && !_0x493a10) return _0x14d1b3;
    if (Date["now"]() - _0x23288b > (_0xe2cebc || 0x2710))
      throw new Error("Send\x20button\x20did\x20not\x20enable\x20in\x20time");
    await _0x4974b3(0x64);
  }
}
function _0x2336cc() {
  var _0x36206f = document["querySelectorAll"](
    "[data-testid=\x22message-bubble__wrapper\x22]",
  );
  return _0x36206f ? _0x36206f["length"] : 0x0;
}
function _0x4156f7() {
  var _0xe09d61 = document["querySelector"](
    ".lightbox-dialog.lightbox-dialog--mask-fade",
  );
  if (!_0xe09d61) return !0x1;
  if (_0xe09d61["hasAttribute"]("hidden")) return !0x1;
  var _0x1a711b = _0xe09d61["textContent"] || "";
  return /Message not sent|Not delivered|Try Again/i["test"](_0x1a711b);
}
async function _0x5992c7(_0x3ed354, _0x13c2af) {
  var _0x3f67ff = Date["now"]();
  for (;;) {
    if (_0x4156f7())
      throw new Error(
        "eBay\x20shows\x20\x27Message\x20not\x20sent\x27\x20—\x20a\x20retry\x20is\x20offered.",
      );
    if (_0x2336cc() > _0x3ed354) return !0x0;
    if (Date["now"]() - _0x3f67ff > (_0x13c2af || 0x3a98))
      throw new Error(
        "Message\x20did\x20not\x20appear\x20in\x20chat\x20within\x20the\x20time\x20limit",
      );
    await _0x4974b3(0xc8);
  }
}
async function _0x4cb113(_0xb48dac = 0x2710, _0x135689 = 0x64) {
  const _0x23e2f9 = Date["now"]() + _0xb48dac,
    _0x847c3d = [
      "#imageupload__sendmessage--textbox",
      "[data-testid=\x22send-message-textbox\x22]",
      "textarea[name=\x22message\x22]",
      "textarea#message",
      "textarea",
    ];
  function _0x2c24e0(_0x40a9bc) {
    if (!_0x40a9bc || !_0x40a9bc["isConnected"]) return !0x1;
    const _0x25ca66 = getComputedStyle(_0x40a9bc);
    return !(
      "none" === _0x25ca66["display"] ||
      "hidden" === _0x25ca66["visibility"] ||
      "0" === _0x25ca66["opacity"] ||
      _0x40a9bc["hasAttribute"]("disabled") ||
      "true" === _0x40a9bc["getAttribute"]("aria-disabled") ||
      _0x40a9bc["readOnly"]
    );
  }
  function findInRoot(_0x5f4896) {
    for (const _0x287262 of _0x847c3d) {
      const _0xf607f9 = _0x5f4896["querySelector"](_0x287262);
      if (_0x2c24e0(_0xf607f9)) return _0xf607f9;
    }
    return null;
  }
  function* _0x348677() {
    const _0x1f9af7 = Array["from"](document["querySelectorAll"]("iframe"));
    for (const _0x86cde of _0x1f9af7)
      try {
        const _0x33b525 = getComputedStyle(_0x86cde);
        if (
          "none" === _0x33b525["display"] ||
          "hidden" === _0x33b525["visibility"] ||
          "0" === _0x33b525["opacity"]
        )
          continue;
        if (!_0x86cde["contentDocument"]) continue;
        yield _0x86cde["contentDocument"];
      } catch (_0x5386ea) {}
  }
  for (; Date["now"]() < _0x23e2f9; ) {
    let _0x486708 = findInRoot(document);
    if (_0x486708) return _0x486708;
    for (const _0x354b05 of _0x348677()) {
      _0x486708 = findInRoot(_0x354b05);
      if (_0x486708) return _0x486708;
    }
    await _0x4974b3(_0x135689);
  }
  throw new Error("Message\x20textbox\x20did\x20not\x20appear\x20in\x20time");
}
async function _0x3731df(_0x355fd5) {
  await _0x4cb113(0x7530);
  if (!(await _0x3c5cb4(_0x355fd5)))
    throw new Error("Could\x20not\x20find\x20the\x20message\x20textbox");
  var _0x59f2e1 = _0x2336cc();
  return (
    (await _0x27f112("#imageupload__send--button", 0x2710))["click"](),
    await _0x5992c7(_0x59f2e1, 0x3a98),
    !0x0
  );
}
(console["log"](
  "content/ebay/mesh_order_details/view_message_iframe/content.js",
),
  iframeUtils["responders"]["handleRequest"](
    "send_message_to_buyer",
    async (_0x2655f7) => {
      return (
        console["log"](
          "Iframe\x20was\x20asked\x20to\x20send\x20message:",
          _0x2655f7,
        ),
        await _0x3731df(_0x2655f7["message"]),
        { status: "sent" }
      );
    },
  ));
