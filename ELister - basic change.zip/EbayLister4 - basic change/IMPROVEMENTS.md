# Code Improvements & Changes Documentation

This document tracks all improvements, bug fixes, and features added to the eBay Lister extension.

---

## Summary of Changes (Bullet Points)

### Major Features Developed:
- **Bulk Snipe Tool** - Complete automation system for bulk listing from eBay items
- **Copy Data Button on eBay Items** - Extract price, title, and item number from eBay listings
- **Gemini API Title Generator Integration** - Replaced old API with custom Gemini-powered title generation

### Improvements & Bug Fixes:
- **Fixed eBay item price extraction bug** (fix_ebay_item_price.js) - Prevented grabbing seller feedback score instead of actual price
- **Fixed delivery time message error** (content_bundle_0.js) - Resolved duplicate function name collision
- **Fixed free shipping validation bug** (content_bundle_0.js) - Corrected function call in bulk snipe validation
- **Added popup shortcut button** for Bulk Snipe feature (popup.html, popup.bundle.js)
- **Implemented low stock filtering** (optional checkbox) for Bulk Snipe validation
- **Created Stealth Listing feature** to optionally hide SKU from eBay listings
- **Updated restricted words list** (restricted_words.txt) - Added 204 new VERO/restricted brand words (now 354 total)
- **Beautified obfuscated code** (content_bundle files) - Deminified ~60 JS files for better readability and maintenance

---

## Detailed Technical Documentation

### 1. Bulk Snipe Tool Development

**Location**: `bulk_snipe/` directory

**Purpose**: Automated bulk listing tool that processes multiple eBay items, extracts their SKUs, validates Amazon products, and creates eBay listings in sequence.

**Files Created**:
1. `bulk_snipe/bulk_snipe_settings.html` - User interface for bulk operations
2. `bulk_snipe/bulk_snipe_settings.js` - Main automation logic
3. `bulk_snipe/styles.css` - Styling for the interface

**Key Features**:
- **Sequential Processing**: Processes items one at a time to avoid rate limiting
- **Background Listing Management**: Allows multiple eBay listings to complete in background (configurable 1-10)
- **Validation System**: 7-point validation (availability, low stock, extended delivery, Prime, free shipping, VERO, duplicates)
- **Challenge Screen Handling**: Automatically waits for eBay rate limit redirects
- **Progress Tracking**: Real-time progress bar, success/skip/fail counters
- **State Persistence**: Saves position and progress across page reloads
- **Pause/Resume**: Can pause and resume operations mid-process
- **Tab Management**: Optional auto-close of completed tabs

**Workflow** (bulk_snipe_settings.js:264-342):
1. Open eBay item page
2. Wait for page load
3. Check for "Look up this SKU" button (verify item is from extension)
4. Click "Copy Data" button to extract item data
5. Click "Look up this SKU" to open Amazon page
6. Validate Amazon item (Prime, free shipping, availability, etc.)
7. Click "Import" button
8. Click "Snipe-List" button
9. Wait for eBay listing tab to open
10. Continue in background while next item starts

**Settings Available**:
- Close tabs after completion (checkbox)
- Delay between items (0-60 seconds)
- Max items per session (0 = unlimited)
- Max background listings (1-10)
- Skip VERO protected items (checkbox)
- Skip duplicate items (checkbox)
- Skip low stock items (checkbox)

**Challenge Screen Detection** (bulk_snipe_settings.js:505-548):
```javascript
// Check if we hit the challenge/rate limit screen
if (tab.url.includes("/splashui/challenge")) {
  if (!challengeTabId) {
    challengeTabId = tabId;
    this.log("eBay challenge screen detected on tab: " + tabId + " - waiting for auto-redirect...");
  }
  return; // Don't resolve yet, wait for redirect
}
```

**How to Use**:
1. Open Bulk Snipe from popup or directly
2. Paste eBay item links (one per line)
3. Configure settings (background listings, skip options, etc.)
4. Click "Start Bulk Snipe"
5. Monitor progress in real-time
6. Use Pause/Resume as needed

---

### 2. Gemini API Title Generator Integration

**Location**: `content_bundle_3.js`, `gemini-title-api/` directory

**Purpose**: Replaced old title generation API with custom Gemini-powered API for better quality and control over title generation for eBay listings.

**API Endpoint Changed From**:
- Old: `https://ebaysnipertitlebuilder.ngrok.io/api/TitleBuilder/BuildTitle`

**API Endpoint Changed To**:
- New: `https://suggest-optimized-titles-2-djybcnnsgq-uc.a.run.app`
- Fallback: `https://gemini-title-api-791896956785.us-central1.run.app`

**Implementation** (content_bundle_3.js:6620-6627):
```javascript
var _0x2ee415 = await _0xb0be35(
  "https://suggest-optimized-titles-2-djybcnnsgq-uc.a.run.app",
  {
    request_type: "generate_10_titles",
    product_description: _0x578901,
    product_title: _0x901d3d,
  },
);
```

**Request Format**:
```json
{
  "request_type": "generate_10_titles",
  "product_description": "Full product description text",
  "product_title": "Original product title",
  "language": "english"
}
```

**Response Format**:
```json
[
  "Optimized Title 1 - With Keywords",
  "Optimized Title 2 - Alternative Version",
  "Optimized Title 3 - Another Variation",
  ...
]
```

**Features**:
- Generates 10 optimized title variations
- Uses Gemini AI for better SEO optimization
- Filters out empty titles automatically
- Language support (English, German, Italian, Spanish)
- Character limit enforcement (80 chars for eBay)

**API Deployment**:
Located in `gemini-title-api/` directory with:
- Cloud Run deployment configuration
- Gemini API integration
- Environment variable management
- Error handling and logging

**How to Replicate in Obfuscated Code**:
1. Search for the old API endpoint URL
2. Replace with new Gemini API endpoint
3. Ensure request format matches: `{request_type, product_description, product_title, language}`
4. Verify response handling for array of title strings
5. Test with various products to ensure quality

---

### 3. eBay Item Price Extraction Fix

**Location**: `fix_ebay_item_price.js`

**Purpose**: Fixes critical bug where the extension was grabbing the seller's feedback score (e.g., "99.8%") instead of the actual item price when using the "Copy Data" button on eBay item pages.

**Problem Identified**:
The original price extraction logic was using generic selectors that matched the seller feedback percentage before finding the actual price element. This caused incorrect pricing data to be copied and used in listings.

**Solution Implemented**:
Created `fix_ebay_item_price.js` as a content script that:
1. Tries multiple specific price selectors in priority order
2. Validates extracted prices to ensure they're valid numbers > 0
3. Handles both US format (1,234.56) and European format (1.234,56)
4. Patches the "Copy Data" button with correct price extraction
5. Uses MutationObserver to catch dynamically loaded elements

**Price Extraction Logic** (fix_ebay_item_price.js:10-59):
```javascript
function extractCorrectPrice() {
  // Try multiple selectors to find the actual price
  const priceSelectors = [
    ".x-price-primary span.ux-textspans",      // New eBay layout (highest priority)
    ".x-price-primary .ux-textspans--BOLD",
    '[itemprop="price"]',                       // Schema.org markup
    ".x-price-approx__price",                   // Approximate price
    ".vi-VR-cvipPrice",                         // Legacy layout
    "#prcIsum",                                 // Old price ID
    "#mm-saleDscPrc",                          // Sale price
    ".notranslate.vi-VR-cvipPrice",            // Non-translatable price
  ];

  for (const selector of priceSelectors) {
    const priceElement = document.querySelector(selector);
    if (priceElement) {
      let priceText = priceElement.textContent || priceElement.innerText;

      // Extract numeric value (remove currency symbols, text, etc.)
      priceText = priceText.replace(/[^0-9.,]/g, "");

      // Handle different decimal/thousand separators
      const lastComma = priceText.lastIndexOf(",");
      const lastDot = priceText.lastIndexOf(".");

      if (lastComma > lastDot) {
        // European format: 1.234,56 -> 1234.56
        priceText = priceText.replace(/\./g, "").replace(",", ".");
      } else {
        // US format: 1,234.56 -> 1234.56
        priceText = priceText.replace(/,/g, "");
      }

      const price = parseFloat(priceText);
      if (!isNaN(price) && price > 0) {
        return price.toFixed(2);  // Return validated price
      }
    }
  }
  return null;  // No valid price found
}
```

**Button Patching Logic** (fix_ebay_item_price.js:62-129):
```javascript
function patchCopyDataButton() {
  const observer = new MutationObserver((mutations) => {
    const copyButton = document.querySelector("#copyDataLink");

    // Only patch once per button
    if (copyButton && !copyButton.dataset.pricePatched) {
      copyButton.dataset.pricePatched = "true";

      const correctPrice = extractCorrectPrice();
      if (correctPrice) {
        // Replace click handler with correct price extraction
        copyButton.addEventListener("click", async function (e) {
          e.preventDefault();

          const title = document.querySelector("h1.x-item-title__mainTitle span")?.textContent ||
                       document.querySelector(".it-ttl")?.textContent ||
                       document.title.split("|")[0].trim();

          const itemNumber = window.location.pathname.match(/\/itm\/(\d+)/)?.[1] ||
                            document.querySelector("[data-itemid]")?.dataset.itemid;

          const data = {
            title: title,
            price: correctPrice,        // Using correct price!
            itemNumber: itemNumber,
          };

          // Copy to clipboard as JSON
          const jsonString = JSON.stringify(data);
          const textarea = document.createElement("textarea");
          document.body.appendChild(textarea);
          textarea.value = jsonString;
          textarea.select();
          document.execCommand("copy");
          document.body.removeChild(textarea);

          console.log("Copied data with correct price:", data);
        });
      }
    }
  });

  // Watch for button to appear
  observer.observe(document.body, { childList: true, subtree: true });

  // Stop watching after 10 seconds to avoid memory leaks
  setTimeout(() => observer.disconnect(), 10000);
}
```

**Data Format**:
```json
{
  "title": "Wireless Bluetooth Headphones - Noise Cancelling",
  "price": "29.99",
  "itemNumber": "123456789012"
}
```

**Integration**:
The script is loaded as a content script on eBay item pages via the manifest:
```json
{
  "matches": ["*://*.ebay.com/itm/*", "*://*.ebay.co.uk/itm/*"],
  "js": ["fix_ebay_item_price.js"],
  "run_at": "document_end"
}
```

**Testing**:
1. Navigate to any eBay item page
2. Wait for "Copy Data" button to appear (from extension)
3. Click the button
4. Check clipboard for JSON data
5. Verify price matches the displayed item price (not seller feedback)
6. Test with various price formats (US, EU, with/without decimals)

**Benefits**:
- Prevents incorrect pricing in bulk listings
- Handles multiple eBay layouts (new and legacy)
- Supports international price formats
- Validates extracted prices
- No manual price entry needed

**How to Replicate**:
1. Create content script file
2. Implement multi-selector price extraction
3. Add price validation (must be number > 0)
4. Handle international number formats
5. Use MutationObserver to patch buttons
6. Register script in manifest.json for eBay item pages

---

### 4. Delivery Time Error Fix

**Location**: `content_bundle_0.js`

**Problem Identified**:
Two functions with identical names `_0x109e52()` existed at different locations:
- **Line 60057**: Returns delivery DATE from `data-csa-c-delivery-time` attribute
- **Line 60266**: Returns delivery MESSAGE text from `#delivery-message` element

JavaScript only keeps the last definition, causing the first function to be overwritten. When the extended delivery check called `_0x109e52()`, it received text like "Arrives tomorrow" instead of a date like "2025-10-20", causing `new Date()` to fail.

**Files Modified**:
- `content_bundle_0.js:60266` - Renamed second function to `_0x109e52_text()`
- `content_bundle_0.js:60298` - Updated reference to use `_0x109e52_text()` for deliveryTimeMessage
- `content_bundle_0.js:71200` - Updated bulk snipe validation to pass skipLowStock parameter

**Code Changes**:
```javascript
// Line 60266 - Renamed function
function _0x109e52_text() {  // Was: function _0x109e52()
  var _0x140006 = "No\x20Delivery\x20Message";
  return (
    document["querySelectorAll"]("#delivery-message")["length"] &&
      (_0x140006 = document["getElementById"]("delivery-message")["innerText"]["replace"](/^\s+|\s+$|\s+(?=\s)/g, "")),
    _0x140006
  );
}

// Line 60298 - Updated function call
deliveryTimeMessage: _0x109e52_text(),  // Was: _0x109e52(_0x5af0ec)
```

**How to Replicate in Obfuscated Code**:
1. Search for duplicate function names by looking for `function [name]()` patterns
2. Identify which function returns what data by examining return values
3. Rename the second occurrence to avoid collision
4. Update all references to use the correct function name

---

### 5. Free Shipping Validation Bug Fix

**Location**: `content_bundle_0.js:71127`

**Problem Identified**:
The bulk snipe validation was using the wrong function for free shipping check. It called `_0x109e52()` (delivery date function) instead of `_0x1c757f()` (free shipping function).

**Code Changes**:
```javascript
// Line 71127 - Fixed function call
const hasFreeShipping = _0x1c757f(document);  // Was: _0x109e52(document)
```

**How to Identify in Obfuscated Code**:
1. Search for `hasFreeShipping` variable assignments
2. Cross-reference with other instances to find the correct function (line 60302 shows correct usage)
3. Ensure consistency across all validation checks

---

### 6. Popup Button for Bulk Snipe

**Location**: `popup/popup.html`, `popup/popup.bundle.js`

**Purpose**: Added quick access button to open Bulk Snipe Lister from the extension popup.

**Files Modified**:
- `popup/popup.html` - Added button after "Open Bulk Lister" button
- `popup/popup.bundle.js` - Added event listener to open bulk_snipe_settings.html

**Code Added (popup.html)**:
```html
<button id="open_bulk_snipe">Open Bulk Snipe</button>
```

**Code Added (popup.bundle.js)**:
```javascript
document.getElementById('open_bulk_snipe').addEventListener('click', function() {
  chrome.tabs.create({ url: chrome.runtime.getURL('bulk_snipe/bulk_snipe_settings.html') });
});
```

**How to Replicate**:
1. Add button element in HTML with unique ID
2. Add event listener that uses `chrome.tabs.create()` with `chrome.runtime.getURL()` to open extension page

---

### 7. Low Stock Filtering Feature (Bulk Snipe)

**Location**: Multiple files

**Purpose**: Optional checkbox to skip items with only 1-3 units in stock during bulk snipe operations.

**Files Modified**:
1. `bulk_snipe/bulk_snipe_settings.html:98-101` - Added checkbox UI
2. `bulk_snipe/bulk_snipe_settings.js` - Added setting persistence logic
3. `content_bundle_0.js:71078-71123` - Added validation check

**Validation Logic Added (content_bundle_0.js:71110-71123)**:
```javascript
// Check 2: Low stock check (conditional - skip items with 1, 2, or 3 in stock)
if (skipLowStock) {
  if (
    availabilityMsg.includes("only 1 left") ||
    availabilityMsg.includes("only 2 left") ||
    availabilityMsg.includes("only 3 left")
  ) {
    console.log("[Bulk Snipe] SKIP: Low stock detected (1-3 items)");
    return {
      valid: false,
      reason: "Low stock: " + availabilityMsg,
    };
  }
}
```

**Settings Persistence (bulk_snipe_settings.js)**:
```javascript
// Constructor - Line 23
this.skipLowStock = false;

// Save settings - Line 90
skipLowStock: this.skipLowStock,

// Load settings - Line 105
this.skipLowStock = settings.skipLowStock || false;

// Update UI - Line 118
this.skipLowStockCheckbox.checked = this.skipLowStock;

// Pass to validation - Line 470
skipLowStock: this.skipLowStock,
```

**Complete Validation Checks** (7 total):
1. **Item Availability** (always) - Blocks unavailable items
2. **Low Stock** (optional) - Blocks items with 1-3 in stock
3. **Extended Delivery** (always) - Blocks slow shipping
4. **Prime Eligibility** (always) - Blocks non-FBA items
5. **Free Shipping** (always) - Blocks items without free shipping
6. **VERO Protection** (optional) - Blocks trademarked brands
7. **Duplicate Detection** (optional) - Blocks duplicate ASINs

**How to Replicate in Obfuscated Code**:
1. Add checkbox to HTML with unique ID
2. In settings JS: Add property to constructor, save/load functions, event listener
3. In validation: Add conditional check using `includes()` on availability message
4. Pass setting as parameter through message passing system

---

### 8. Stealth Listing Feature (Hide SKU)

**Location**: Multiple files

**Purpose**: Optional setting to prevent embedding SKU in eBay listing descriptions for privacy/stealth operations.

**Files Modified**:
1. `popup/popup.html:428-434` - Added checkbox toggle
2. `popup/popup.html:550-571` - Added inline script for setting persistence
3. `content_bundle_9.js:15969-16005` - Modified SKU embedding logic

**UI Implementation (popup.html:428-434)**:
```html
<div>
  <span>Stealth Listing (Hide SKU)</span>
  <label class="switch">
    <input type="checkbox" id="stealth_listing_switch" />
    <span class="slider round"></span>
  </label>
</div>
```

**Setting Persistence (popup.html:550-571)**:
```javascript
document.addEventListener('DOMContentLoaded', function() {
  const stealthSwitch = document.getElementById('stealth_listing_switch');

  // Load saved setting
  chrome.storage.local.get(['stealthListing'], function(result) {
    if (result.stealthListing !== undefined) {
      stealthSwitch.checked = result.stealthListing;
    }
  });

  // Save setting when changed
  stealthSwitch.addEventListener('change', function() {
    chrome.storage.local.set({
      stealthListing: this.checked
    }, function() {
      console.log('Stealth listing setting saved:', stealthSwitch.checked);
    });
  });
});
```

**SKU Embedding Logic (content_bundle_9.js:15969-16005)**:
```javascript
// Line 15970 - Load stealth setting
var { stealthListing: _0x5e8a12 } = await chrome["storage"]["local"]["get"]("stealthListing");

// Lines 15984-15990 - Conditionally embed footer
if (!_0x5e8a12) {  // Only if NOT in stealth mode
  var _0x4245c2 = document["createElement"]("div");
  ((_0x4245c2["className"] = "footerss"),
    _0x4245c2["setAttribute"]("data-label", "{{SKU}}"),
    (_0x4245c2["style"]["display"] = "none"),
    (_0x421338 += _0x4245c2["outerHTML"]));
}

// Lines 16000-16005 - Conditionally replace SKU placeholder
if (!_0x5e8a12) {  // Only if NOT in stealth mode
  var _0xc89363 = btoa(_0x4a480a["sku"]);
  return _0x421338["replace"]("{{SKU}}", _0xc89363);
}

return _0x421338;
```

**How It Works**:
- **Normal Mode (stealth OFF)**: Hidden `<div class="footerss" data-label="[base64_sku]">` is embedded in description HTML
- **Stealth Mode (stealth ON)**: No SKU footer is added; description remains clean without tracking data

**SKU Extraction Method** (for reference):
Located in `content_bundle_18.js:3249-3252`:
```javascript
var _0x5b5a92 = _0x4aaccb["querySelector"](".footerss");
return (
  _0x5b5a92 && (_0x53eb1c = _0x5b5a92["getAttribute"]("data-label")),
  _0x53eb1c
);
```

**How to Replicate in Obfuscated Code**:
1. Add checkbox toggle in HTML (use existing switch pattern)
2. Add inline script in HTML for chrome.storage persistence (avoid modifying minified bundle.js)
3. In description building code:
   - Add `await chrome["storage"]["local"]["get"]("stealthListing")` before SKU embedding
   - Wrap SKU footer creation in `if (!stealthListing)` condition
   - Wrap SKU replacement in `if (!stealthListing)` condition
   - Return description without SKU if stealth mode is enabled

**Important Notes**:
- Setting is stored in `chrome.storage.local` with key `stealthListing`
- Default value is `false` (stealth OFF, SKU embedded)
- SKU is base64 encoded before embedding: `btoa(sku)`
- SKU footer has class `.footerss` and attribute `data-label` containing the encoded SKU
- Footer is hidden with `display: none` so it's invisible but parseable

---

### 9. Restricted Words List Update

**Location**: `restricted_words.txt`

**Purpose**: Expanded VERO/restricted brand list to prevent listing trademarked items that could result in account suspension or legal issues.

**Update Details**:
- **Previous Count**: ~150 words
- **New Count**: 354 words
- **Added**: 204 new restricted brand names and trademarked terms

**File Format**:
The file contains one brand/term per line (case-insensitive matching):
```
nike
adidas
apple
disney
louis vuitton
...
```

**How It's Used**:
The restricted words list is checked during bulk snipe validation when the "Skip VERO protected items" option is enabled. Items containing any restricted words in their title or description are automatically skipped to protect the seller account.

**Validation Integration** (content_bundle_0.js):
```javascript
// Check 6: VERO/Restricted brands check (conditional)
if (skipVero) {
  const restrictedWords = await loadRestrictedWords();
  const titleLower = productTitle.toLowerCase();

  for (const word of restrictedWords) {
    if (titleLower.includes(word.toLowerCase())) {
      console.log("[Bulk Snipe] SKIP: VERO/Restricted brand detected: " + word);
      return {
        valid: false,
        reason: "VERO/Restricted brand: " + word,
      };
    }
  }
}
```

**Related Files**:
- `VeroList.txt` - Alternative VERO list
- `VeroListNew.txt` - Extended VERO list (5831 entries)
- `VeroList_All_UnKempt.txt` - Unfiltered comprehensive list
- `libraries/safety-lib/safety_restricted_words.txt` - Library copy
- `libraries/safety-lib/safety_restricted_prefixes.txt` - Prefix-based matching

**Benefits**:
- Reduces risk of eBay account suspension
- Prevents listing of trademarked items
- Automated protection during bulk operations
- Regularly updated with new brands/trademarks

**How to Update**:
1. Add new brands/terms to `restricted_words.txt` (one per line)
2. Keep all entries lowercase for consistent matching
3. No special formatting needed - plain text only
4. Reload extension or restart bulk snipe for changes to take effect

**Common Categories Covered**:
- Fashion brands (Nike, Adidas, Gucci, etc.)
- Tech brands (Apple, Samsung, Sony, etc.)
- Entertainment brands (Disney, Marvel, etc.)
- Luxury brands (Louis Vuitton, Rolex, etc.)
- Sports brands (NFL, NBA, FIFA, etc.)

---

### 10. Code Beautification (Deminification)

**Location**: Multiple `content_bundle_*.js` files

**Purpose**: Improved code readability and maintainability by beautifying/deminifying obfuscated JavaScript files.

**Files Beautified** (~60 files total):
All `content_bundle_*.js` files in the root directory were processed through a code beautifier/formatter.

**Before Beautification**:
```javascript
!(function(_0x5e4c1d,_0x2e2e0a){"object"==typeof exports&&"undefined"!=typeof module?module["exports"]=_0x2e2e0a():"function"==typeof define&&define["amd"]?define(_0x2e2e0a):((_0x5e4c1d=_0x5e4c1d||self)["Sortable"]=_0x2e2e0a());})(this,function(){"use strict";function _0x196cd7(_0x337765,_0x106ec6){var _0x2e0233,_0x4c3c85=Object["keys"](_0x337765);return(Object["getOwnPropertySymbols"]&&...
```

**After Beautification**:
```javascript
!(function (_0x5e4c1d, _0x2e2e0a) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module["exports"] = _0x2e2e0a())
    : "function" == typeof define && define["amd"]
      ? define(_0x2e2e0a)
      : ((_0x5e4c1d = _0x5e4c1d || self)["Sortable"] = _0x2e2e0a());
})(this, function () {
  "use strict";
  function _0x196cd7(_0x337765, _0x106ec6) {
    var _0x2e0233,
      _0x4c3c85 = Object["keys"](_0x337765);
    return (
      Object["getOwnPropertySymbols"] &&
        ((_0x2e0233 = Object["getOwnPropertySymbols"](_0x337765)),
        _0x106ec6 &&
          (_0x2e0233 = _0x2e0233["filter"](function (_0x1c9131) {
            return Object["getOwnPropertyDescriptor"](_0x337765, _0x1c9131)[
              "enumerable"
            ];
          })),
        _0x4c3c85["push"]["apply"](_0x4c3c85, _0x2e0233)),
      _0x4c3c85
    );
  }
  // ... rest of code with proper indentation
});
```

**Improvements Gained**:
1. **Proper Indentation**: Consistent 2-space indentation for nested blocks
2. **Line Breaks**: Each statement on its own line for clarity
3. **Block Formatting**: Opening/closing braces clearly visible
4. **Function Separation**: Clear boundaries between function definitions
5. **Conditional Formatting**: Ternary operators and if/else properly formatted

**Tools Used**:
Likely used Prettier, js-beautify, or similar JavaScript formatter with standard settings:
- 2-space indentation
- Line width limit (80-100 characters)
- Consistent quote style
- Proper bracket placement

**Benefits**:
- **Easier Debugging**: Can set breakpoints and step through code more easily
- **Better Code Search**: Can use grep/search tools to find patterns across lines
- **Improved Readability**: Easier to understand code structure and logic flow
- **Simpler Modifications**: Can edit code without reformatting entire lines
- **Version Control**: Git diffs show actual changes instead of entire file modifications

**Files Affected**:
Based on modification timestamps, the following were beautified on 2025-10-14:
- content_bundle_0.js through content_bundle_59.js
- background.bundle.js (potentially)
- Other bundle files as needed

**Important Notes**:
- Variable names remain obfuscated (`_0x5e4c1d`, etc.) - only formatting was improved
- Functionality is identical to original minified code
- File sizes increased due to added whitespace and line breaks
- Performance impact is negligible (Chrome's V8 optimizes regardless of formatting)

**How to Replicate**:
```bash
# Using Prettier (recommended)
npx prettier --write "content_bundle_*.js"

# Using js-beautify
npm install -g js-beautify
for file in content_bundle_*.js; do
  js-beautify -r "$file" --indent-size 2
done
```

**Before/After Comparison**:
- **Minified**: Single long line, ~500KB, unreadable
- **Beautified**: Properly formatted, ~600-700KB, readable and maintainable

---

## Testing & Verification

### To Test eBay Price Extraction Fix:
1. Navigate to any eBay item page
2. Wait for the "Copy Data" button to appear (added by extension)
3. Click the "Copy Data" button
4. Paste clipboard contents and verify it's valid JSON
5. Check that the price field matches the actual item price (not seller feedback like "99.8")
6. Test with items in different formats: US prices ($1,234.56), EU prices (1.234,56€)
7. Verify console log shows "Copied data with correct price: {title, price, itemNumber}"

### To Test Delivery Time Fix:
1. List an item with extended delivery time
2. Check console for "deliveryTimeMessage" and "deliveryTimeDate" logs
3. Verify no "Invalid delivery time date" errors

### To Test Free Shipping Validation:
1. Enable bulk snipe with validation
2. Process items with and without free shipping
3. Check logs for "[Bulk Snipe] Free shipping check: true/false"
4. Verify items without free shipping are skipped

### To Test Low Stock Filter:
1. Open Bulk Snipe settings
2. Check "Skip low stock items (1-3 in stock)"
3. Process items with various stock levels
4. Verify items with "only 1/2/3 left in stock" are skipped

### To Test Stealth Listing:
1. Open extension popup
2. Toggle "Stealth Listing (Hide SKU)" on
3. Create a new listing
4. View eBay listing description HTML
5. Search for class="footerss" - should NOT be found
6. Toggle off and create another listing - footer should be present

### To Test Restricted Words List:
1. Open Bulk Snipe settings
2. Enable "Skip VERO protected items"
3. Add eBay items with restricted brand names (Nike, Apple, Disney, etc.)
4. Start bulk snipe
5. Verify items with restricted words are skipped with reason "VERO/Restricted brand: [brand]"
6. Check console logs for validation messages

### To Verify Code Beautification:
1. Open any `content_bundle_*.js` file in a text editor
2. Verify proper indentation (2 spaces per level)
3. Check that functions are separated by line breaks
4. Confirm code is readable and not on a single long line
5. Test extension functionality to ensure beautification didn't break anything

---

## Troubleshooting Guide

### Price Extraction Issues:
- **Symptom**: Incorrect price copied (shows seller feedback, shipping cost, or wrong value)
- **Check**:
  1. Open console and look for "Copied data with correct price" log
  2. Verify `fix_ebay_item_price.js` is loaded (check Sources tab in DevTools)
  3. Check if button has `data-price-patched="true"` attribute
  4. Test price extraction: Run `document.querySelector(".x-price-primary span.ux-textspans")?.textContent` in console
- **Fix**:
  - Ensure `fix_ebay_item_price.js` is registered in manifest.json for eBay item pages
  - Reload extension and refresh eBay page
  - If eBay layout changed, add new price selector to `priceSelectors` array
  - Verify MutationObserver is running (timeout is 10 seconds)

### Delivery Time Errors:
- **Symptom**: "Invalid delivery time date" errors in console
- **Check**: Search for duplicate `function _0x109e52()` definitions
- **Fix**: Ensure text version is renamed to `_0x109e52_text()` and references are updated

### Low Stock Filter Not Working:
- **Symptom**: Items with low stock not being skipped
- **Check**: Verify `skipLowStock` checkbox state in chrome.storage
- **Fix**: Clear storage and re-enable checkbox, or manually set `chrome.storage.local.set({bulk_snipe_settings: {skipLowStock: true}})`

### Stealth Mode Not Working:
- **Symptom**: SKU still appearing in descriptions despite stealth mode being on
- **Check**:
  1. Verify checkbox state: `chrome.storage.local.get(['stealthListing'])`
  2. Check if `_0x5e8a12` variable is being loaded at line 15970
  3. Verify conditional checks at lines 15984 and 16000
- **Fix**: Ensure storage key is exactly `stealthListing` (case-sensitive)

### SKU Not Being Found in Existing Listings:
- **Symptom**: Cannot extract SKU from old listings
- **Check**:
  1. View listing description HTML source
  2. Search for `class="footerss"`
  3. Check if `data-label` attribute exists
- **Possible Causes**:
  - Listing was created with stealth mode ON
  - Listing was created before SKU embedding feature
  - Description template was modified manually

### Restricted Words Not Blocking Items:
- **Symptom**: Items with restricted brands are not being skipped
- **Check**:
  1. Verify "Skip VERO protected items" checkbox is enabled
  2. Check `restricted_words.txt` contains the brand name (lowercase)
  3. Verify brand name appears in product title
  4. Check console for VERO validation logs
- **Fix**:
  - Add missing brand to `restricted_words.txt` (one per line, lowercase)
  - Reload extension to pick up new words
  - Ensure no extra spaces or special characters in word list

### Code Formatting Issues After Beautification:
- **Symptom**: Extension breaks or functions incorrectly after beautification
- **Check**:
  1. Verify beautifier didn't change string literals or regex patterns
  2. Check that all files use consistent formatting (2-space indentation)
  3. Test extension in dev mode before deployment
  4. Compare file sizes - should increase but not drastically (20-30%)
- **Fix**:
  - Re-beautify with correct settings
  - Use Prettier with default JavaScript settings
  - Keep backups of working minified versions

---

## Version Compatibility

These changes are compatible with:
- Chrome Extension Manifest V2/V3
- eBay listing pages (current layout as of 2025)
- Amazon product pages (current layout as of 2025)

If replicating to another obfuscated version:
1. Search for similar patterns rather than exact variable names
2. Use function behavior (return values, parameters) to identify equivalents
3. Test thoroughly with console logging before production use
4. Keep backups of working code before modifications

---

## File Reference Summary

### Modified Files:
1. `fix_ebay_item_price.js` - **New file** - eBay price extraction fix (prevents grabbing seller feedback score)
2. `content_bundle_0.js` - Delivery time fix, validation fixes, beautified
3. `content_bundle_9.js` - Stealth listing implementation, beautified
4. `content_bundle_3.js` - Gemini API title generator integration
5. `content_bundle_*.js` (all 60 files) - Beautified/deminified for readability
6. `popup/popup.html` - UI for bulk snipe button and stealth toggle
7. `popup/popup.bundle.js` - Bulk snipe button handler
8. `bulk_snipe/bulk_snipe_settings.html` - Low stock checkbox
9. `bulk_snipe/bulk_snipe_settings.js` - Low stock settings logic
10. `restricted_words.txt` - Updated with 204 new VERO/restricted brands (now 354 total)
11. `background.bundle.js` - Potentially beautified

### Key Code Locations:
- **Price extraction fix**: fix_ebay_item_price.js:10-59 (extractCorrectPrice function)
- **Copy Data button patching**: fix_ebay_item_price.js:62-129 (patchCopyDataButton function)
- **Gemini API title generator**: content_bundle_3.js:6620-6627
- **Delivery date extraction**: content_bundle_0.js:60057
- **Delivery message extraction**: content_bundle_0.js:60266
- **Bulk snipe validation**: content_bundle_0.js:71078-71189
- **SKU footer embedding**: content_bundle_9.js:15984-15990
- **SKU replacement**: content_bundle_9.js:16000-16005
- **SKU extraction**: content_bundle_18.js:3249-3252
- **Restricted words list**: restricted_words.txt (354 entries)
- **VERO list extended**: VeroListNew.txt (5831 entries)

---

*Last Updated: 2025-10-15*
*Latest Changes: Restricted words list expansion (+204 words), Code beautification (60 files)*
