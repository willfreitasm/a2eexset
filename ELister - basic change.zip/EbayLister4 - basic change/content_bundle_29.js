function _0x279b21() {
  return new Promise((_0x38c000) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x38c000();
      });
    });
  });
}
function _0x251f65() {
  return new Promise((_0x40d36a) => {
    requestIdleCallback(() => {
      _0x40d36a();
    });
  });
}
function _0x3561cf(_0x30e132 = 0x3e8) {
  return new Promise((_0x2172b8, _0x18ed1b) => {
    let _0x40f01f,
      _0x5520d4 = Date["now"](),
      _0x367b9c = !0x1;
    function _0x457958() {
      if (Date["now"]() - _0x5520d4 > _0x30e132)
        (_0x367b9c && _0x40f01f["disconnect"](), _0x2172b8());
      else setTimeout(_0x457958, _0x30e132);
    }
    const _0x30316f = () => {
        _0x5520d4 = Date["now"]();
      },
      _0x382893 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x40f01f = new MutationObserver(_0x30316f)),
        _0x40f01f["observe"](document["body"], _0x382893),
        (_0x367b9c = !0x0),
        setTimeout(_0x457958, _0x30e132));
    else
      window["onload"] = () => {
        ((_0x40f01f = new MutationObserver(_0x30316f)),
          _0x40f01f["observe"](document["body"], _0x382893),
          (_0x367b9c = !0x0),
          setTimeout(_0x457958, _0x30e132));
      };
  });
}
async function _0x2f4ef1() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x3561cf(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
(console["log"]("ebay/splashui/content.js"),
  console["log"]("ebay/splashui/content.js"));
var _0x1edc68;
chrome["runtime"]["onMessage"]["addListener"](
  (_0x3fa8a6, _0x2df4bc, _0x1a2811) => {
    (console["log"](
      _0x2df4bc["tab"]
        ? "From\x20a\x20content\x20script:" + _0x2df4bc["tab"]["url"]
        : "From\x20the\x20extension\x20request.type\x20ebay.js" +
            _0x3fa8a6["type"],
    ),
      console["log"]("request", _0x3fa8a6),
      (_0x1edc68 = _0x3fa8a6),
      chrome["runtime"]["sendMessage"]({
        type: "resend_message_to_tab_on_update",
        message: _0x1edc68,
      }));
  },
);
