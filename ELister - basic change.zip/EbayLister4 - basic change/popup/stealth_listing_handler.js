// Stealth Listing toggle persistence handler
console.log('[Stealth Listing] Handler script loaded');

function initStealthListing() {
  console.log('[Stealth Listing] Initializing...');

  const stealthSwitch = document.getElementById('stealth_listing_switch');

  if (!stealthSwitch) {
    console.error('[Stealth Listing] Switch element not found!');
    setTimeout(initStealthListing, 100); // Try again in 100ms
    return;
  }

  console.log('[Stealth Listing] Switch element found:', stealthSwitch);

  // Mark as initialized to prevent double initialization
  stealthSwitch.dataset.initialized = 'true';

  // Load saved setting
  chrome.storage.local.get(['stealthListing'], function(result) {
    console.log('[Stealth Listing] Loaded from storage:', result);
    if (result.stealthListing !== undefined) {
      stealthSwitch.checked = result.stealthListing;
      console.log('[Stealth Listing] Set checkbox to:', result.stealthListing);
    } else {
      console.log('[Stealth Listing] No saved setting, defaulting to unchecked');
      stealthSwitch.checked = false;
    }
  });

  // Save setting when changed
  stealthSwitch.addEventListener('change', function() {
    const newValue = this.checked;
    console.log('[Stealth Listing] Switch changed to:', newValue);

    chrome.storage.local.set({
      stealthListing: newValue
    }, function() {
      if (chrome.runtime.lastError) {
        console.error('[Stealth Listing] Error saving:', chrome.runtime.lastError);
      } else {
        console.log('[Stealth Listing] Successfully saved:', newValue);
        // Verify it was saved
        chrome.storage.local.get(['stealthListing'], function(result) {
          console.log('[Stealth Listing] Verification - stored value is now:', result.stealthListing);
        });
      }
    });
  });
}

// Try multiple initialization methods to ensure it runs
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initStealthListing);
} else {
  // DOM already loaded
  initStealthListing();
}

// Also try after window load as fallback
window.addEventListener('load', function() {
  console.log('[Stealth Listing] Window loaded, checking if initialized...');
  const stealthSwitch = document.getElementById('stealth_listing_switch');
  if (stealthSwitch && !stealthSwitch.dataset.initialized) {
    console.log('[Stealth Listing] Not initialized yet, running init...');
    initStealthListing();
  }
});
