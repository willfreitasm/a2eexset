function _0x1026c4() {
  return new Promise((_0x4994fa) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x4994fa();
      });
    });
  });
}
function _0xd43a7e() {
  return new Promise((_0x3a9b2e) => {
    requestIdleCallback(() => {
      _0x3a9b2e();
    });
  });
}
function _0x4fdac5(_0x2c9c1f = 0x3e8) {
  return new Promise((_0xd019e7, _0x19364b) => {
    let _0x2e44c7,
      _0x189d2f = Date["now"](),
      _0x30d8a1 = !0x1;
    function _0x16eb0e() {
      if (Date["now"]() - _0x189d2f > _0x2c9c1f)
        (_0x30d8a1 && _0x2e44c7["disconnect"](), _0xd019e7());
      else setTimeout(_0x16eb0e, _0x2c9c1f);
    }
    const _0x5e02c2 = () => {
        _0x189d2f = Date["now"]();
      },
      _0x590530 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x2e44c7 = new MutationObserver(_0x5e02c2)),
        _0x2e44c7["observe"](document["body"], _0x590530),
        (_0x30d8a1 = !0x0),
        setTimeout(_0x16eb0e, _0x2c9c1f));
    else
      window["onload"] = () => {
        ((_0x2e44c7 = new MutationObserver(_0x5e02c2)),
          _0x2e44c7["observe"](document["body"], _0x590530),
          (_0x30d8a1 = !0x0),
          setTimeout(_0x16eb0e, _0x2c9c1f));
      };
  });
}
async function _0x320228() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x4fdac5(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x55854d() {
  return await new Promise(function (_0x895b4f, _0x2e8b51) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x25919f) {
        (console["log"]("result:\x20", _0x25919f["membership"]),
          _0x895b4f(_0x25919f["membership"]));
      },
    );
  });
}
async function _0x1c64a0() {
  return await new Promise(function (_0x165f42, _0x5ec261) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x4bd9c3) {
        (console["log"]("result:\x20", _0x4bd9c3["creditsAvailable"]),
          _0x165f42(_0x4bd9c3["creditsAvailable"]));
      },
    );
  });
}
async function _0x5df2a3(_0x170c3a) {
  if ("ultimate" != (await _0x55854d()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x1c64a0()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
console["log"]("content/ebay/uploads/content.js\x20loaded");
const _0xd3929b = (_0x4becd4) =>
  new Promise((_0x3fa73d) => setTimeout(_0x3fa73d, _0x4becd4));
async function _0x429b60(
  _0x4a8f1b,
  _0x1fe418,
  _0x392960 = 0x1f4,
  _0xc662c7 = 0x3a98,
) {
  const _0x4997bc = Date["now"]();
  let _0x5d59c7;
  for (; !(_0x5d59c7 = _0x4a8f1b()); ) {
    if (Date["now"]() - _0x4997bc > _0xc662c7)
      throw new Error("Timed\x20out\x20waiting\x20for\x20" + _0x1fe418);
    await _0xd3929b(_0x392960);
  }
  return (console["log"](_0x1fe418 + "\x20found"), _0x5d59c7);
}
chrome["runtime"]["onMessage"]["addListener"](
  (_0x565ccf, _0x5af820, _0x50b4df) => {
    if ("upload_csv" === _0x565ccf["type"])
      return (
        console["log"]("Request\x20received:\x20upload_csv"),
        _0x410c83(_0x565ccf["csvData"], _0x565ccf["filename"])
          ["then"](() => _0x50b4df({ success: !0x0 }))
          ["catch"]((_0x2d16df) => {
            (console["error"]("Upload\x20flow\x20error:", _0x2d16df),
              (document["title"] = "❌\x20Upload\x20failed"),
              _0x50b4df({ success: !0x1, error: _0x2d16df["message"] }));
          }),
        !0x0
      );
  },
);
async function _0x410c83(_0x26bf99, _0x5b7dc4 = "upload.csv") {
  try {
    ((document["title"] = "⏳\x20Starting\x20upload"),
      (document["title"] = "🔍\x20Find\x20Upload\x20button"),
      (
        await _0x429b60(
          () =>
            [...document["querySelectorAll"]("button")]["find"](
              (_0x3f4e16) =>
                "Upload\x20template" === _0x3f4e16["textContent"]["trim"]() ||
                "Vorlage\x20hochladen" === _0x3f4e16["textContent"]["trim"](),
            ),
          "Upload\x20template\x20button",
        )
      )["click"](),
      console["log"]("Upload\x20dialog\x20opened"),
      (document["title"] = "📂\x20Opening\x20dialog…"),
      (document["title"] = "🔍\x20Waiting\x20for\x20file\x20input"));
    const _0xb2f29b = await _0x429b60(
      () =>
        document["querySelector"](
          "input[type=\x22file\x22][accept=\x22.xlsm,.xlsx,.txt,.csv\x22]",
        ),
      "Hidden\x20file\x20input",
    );
    (await _0x429b60(
      () =>
        [...document["querySelectorAll"]("button")]["find"](
          (_0x1834f0) =>
            "Choose\x20file" === _0x1834f0["textContent"]["trim"]() ||
            "Datei\x20auswählen" === _0x1834f0["textContent"]["trim"](),
        ),
      "Choose\x20file\x20button",
    ),
      (document["title"] = "⚙️\x20Preparing\x20CSV…"));
    const _0x199b4a = _0x2085a7(_0x26bf99),
      _0x1fa0f0 = new File([_0x199b4a], _0x5b7dc4, { type: "text/csv" });
    document["title"] = "📤\x20Injecting\x20CSV…";
    const _0x1b796e = new DataTransfer();
    (_0x1b796e["items"]["add"](_0x1fa0f0),
      (_0xb2f29b["files"] = _0x1b796e["files"]),
      _0xb2f29b["dispatchEvent"](new Event("change", { bubbles: !0x0 })),
      console["log"]("CSV\x20injected\x20and\x20file\x20input\x20triggered"),
      (document["title"] = "📤\x20Uploading\x20file…"));
    const _0xa33be2 = Array["from"](
      document["querySelectorAll"]("tbody\x20tr.grid-row"),
    )
      ["map"](
        (_0x495b26) =>
          _0x495b26["getAttribute"]("data-request-id") ||
          _0x495b26["querySelector"](".shui-dt-column__requestId\x20div")?.[
            "textContent"
          ]["trim"]() ||
          _0x495b26["querySelector"](".shui-dt-column__fileName\x20div")?.[
            "textContent"
          ]["trim"](),
      )
      ["filter"](Boolean);
    (console["log"]("Existing\x20upload\x20IDs:", _0xa33be2),
      (document["title"] = "🔍\x20Waiting\x20for\x20new\x20row"));
    const _0x6c9e70 = await _0x429b60(
      () =>
        Array["from"](document["querySelectorAll"]("tbody\x20tr.grid-row"))[
          "find"
        ]((_0x1045b0) => {
          const _0x525d32 =
            _0x1045b0["getAttribute"]("data-request-id") ||
            _0x1045b0["querySelector"](".shui-dt-column__requestId\x20div")?.[
              "textContent"
            ]["trim"]() ||
            _0x1045b0["querySelector"](".shui-dt-column__fileName\x20div")?.[
              "textContent"
            ]["trim"]();
          return _0x525d32 && !_0xa33be2["includes"](_0x525d32);
        }) || null,
      "New\x20upload\x20row\x20to\x20appear",
      0x3e8,
      0x57e40,
    );
    console["log"]("New\x20row\x20detected:", _0x6c9e70);
    const _0xb9f86a = ["🔄", "⏳", "⌛"];
    let _0x2fba91 = 0x0;
    const _0xa4c445 = "\x20Waiting\x20for\x20results";
    document["title"] = "" + _0xb9f86a[0x0] + _0xa4c445;
    const _0x612a7e = setInterval(() => {
      ((_0x2fba91 = (_0x2fba91 + 0x1) % _0xb9f86a["length"]),
        (document["title"] = "" + _0xb9f86a[_0x2fba91] + _0xa4c445));
    }, 0x258);
    (console["log"]("Waiting\x20for\x20\x27Download\x20results\x27\x20link…"),
      await _0x429b60(
        () => {
          const _0x229a7d = _0x6c9e70["querySelector"](
            "td.shui-dt-column__uploadAction",
          );
          if (!_0x229a7d) return !0x1;
          const _0x573b2c = _0x229a7d["querySelector"](
            "a[href*=\x22getfiledetails\x22][href*=\x22filetype=output\x22]",
          );
          return Boolean(_0x573b2c);
        },
        "Download\x20results\x20link\x20to\x20appear",
        0x3e8,
        0x107ac0,
      ),
      clearInterval(_0x612a7e),
      (document["title"] = "✅\x20Upload\x20complete!"),
      console["log"](
        "Upload\x20complete—‘Download\x20results’\x20is\x20available.",
      ));
  } catch (_0x47222e) {
    console["error"]("Error\x20during\x20upload\x20flow:", _0x47222e);
    try {
      clearInterval(spinnerInterval);
    } catch {}
    document["title"] = "❌\x20Upload\x20failed";
    throw _0x47222e;
  }
}
function _0x2085a7(_0x1215f1) {
  const [_0x1f3607, _0x4079e4] = _0x1215f1["split"](","),
    _0x1349b3 = _0x1f3607["match"](/:(.*?);/),
    _0x585694 = _0x1349b3 ? _0x1349b3[0x1] : "application/octet-stream",
    _0xd8274f = atob(_0x4079e4),
    _0x33b6db = _0xd8274f["length"],
    _0x41f191 = new Uint8Array(_0x33b6db);
  for (let _0x5b2baf = 0x0; _0x5b2baf < _0x33b6db; ++_0x5b2baf)
    _0x41f191[_0x5b2baf] = _0xd8274f["charCodeAt"](_0x5b2baf);
  return new Blob([_0x41f191], { type: _0x585694 });
}
