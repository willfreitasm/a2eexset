function _0x243ca8() {
  return new Promise((_0x56daff) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x56daff();
      });
    });
  });
}
function _0x539e2a() {
  return new Promise((_0x115628) => {
    requestIdleCallback(() => {
      _0x115628();
    });
  });
}
function _0x7ed109(_0xc212a1 = 0x3e8) {
  return new Promise((_0x1ee9da, _0x5ee8f6) => {
    let _0x33b960,
      _0x48a956 = Date["now"](),
      _0x1949e9 = !0x1;
    function _0x45e29f() {
      if (Date["now"]() - _0x48a956 > _0xc212a1)
        (_0x1949e9 && _0x33b960["disconnect"](), _0x1ee9da());
      else setTimeout(_0x45e29f, _0xc212a1);
    }
    const _0x83dac7 = () => {
        _0x48a956 = Date["now"]();
      },
      _0x4396cc = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x33b960 = new MutationObserver(_0x83dac7)),
        _0x33b960["observe"](document["body"], _0x4396cc),
        (_0x1949e9 = !0x0),
        setTimeout(_0x45e29f, _0xc212a1));
    else
      window["onload"] = () => {
        ((_0x33b960 = new MutationObserver(_0x83dac7)),
          _0x33b960["observe"](document["body"], _0x4396cc),
          (_0x1949e9 = !0x0),
          setTimeout(_0x45e29f, _0xc212a1));
      };
  });
}
async function _0x40bcf3() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x7ed109(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x326bc7(
  _0x231394 = null,
  _0x38ee49 = null,
  _0x50de8b = null,
  _0x5f1008 = null,
) {
  var _0x18d619 = document["createElement"]("a");
  (_0x18d619["setAttribute"]("class", "a-link-text"),
    _0x18d619["classList"]["add"]("icon"),
    _0x18d619["classList"]["add"]("amazonSearchLink"),
    _0x18d619["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x519870 = document["createElement"]("img");
  return (
    _0x519870["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x519870["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x18d619["appendChild"](_0x519870),
    _0x18d619["addEventListener"]("click", async function (_0x44685d) {
      (_0x44685d["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x231394) {
        var _0x13e14e = _0x534705(_0x44685d);
        if (!_0x13e14e) return;
        var _0x32b567 = extractItemData(_0x13e14e);
        ((_0x231394 = _0x32b567["title"])["endsWith"]("...") &&
          (_0x231394 = _0x231394["substring"](
            0x0,
            _0x231394["lastIndexOf"]("\x20"),
          )),
          _0x231394["length"] > 0x4b &&
            (_0x231394 = _0x231394["substring"](
              0x0,
              _0x231394["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x552ef2 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x552ef2),
        _0x552ef2 || (_0x552ef2 = "reviews"),
        console["log"]("amazonSortType", _0x552ef2),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x5b4427 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x231394["length"] > 0x50; )
        _0x231394 = _0x231394["substring"](
          0x0,
          _0x231394["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x4e6661 } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x15a6f4 = _0x231394;
      "keywords" == _0x4e6661 && (_0x15a6f4 = await _0x282c94(_0x231394));
      try {
        _0x32b567 = extractItemData(_0x13e14e);
      } catch (_0x50dba4) {
        console["log"]("error", _0x50dba4);
      }
      (_0x32b567 ||
        (_0x32b567 = {
          title: _0x231394,
          price: _0x38ee49,
          itemNumber: _0x50de8b,
          image: _0x5f1008,
        }),
        console["log"]("itemData", _0x32b567),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x15a6f4,
          options: { isTabActive: !0x0, sort: _0x552ef2 },
          itemData: _0x32b567,
        }));
    }),
    _0x18d619
  );
}
function _0x3bee84(_0x136ac4) {
  var _0x4d6e44 = document["createElement"]("a");
  (_0x4d6e44["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x4d6e44["setAttribute"]("class", "a-link-text"),
    _0x4d6e44["classList"]["add"]("icon"),
    _0x4d6e44["classList"]["add"]("amazonSearchLink"),
    _0x4d6e44["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x233040 = document["createElement"]("img");
  return (
    _0x233040["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x233040["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4d6e44["appendChild"](_0x233040),
    _0x4d6e44["addEventListener"]("click", async function (_0x441ca4) {
      (_0x441ca4["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x136ac4),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x136ac4,
        }));
    }),
    _0x4d6e44
  );
}
function _0x400840(_0x529578) {
  var _0x39e56b = document["createElement"]("a");
  (_0x39e56b["setAttribute"]("id", "amazonLink"),
    _0x39e56b["setAttribute"]("class", "a-link-text"),
    _0x39e56b["classList"]["add"]("icon"),
    _0x39e56b["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0xadf6fa = document["createElement"]("img");
  return (
    _0xadf6fa["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0xadf6fa["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x39e56b["appendChild"](_0xadf6fa),
    _0x39e56b["addEventListener"]("click", async function (_0x293449) {
      (_0x293449["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x8308b5 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x16a4e2 =
          "https://www.amazon." +
          _0x8308b5 +
          "/dp/" +
          _0x529578 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x16a4e2 });
    }),
    _0x39e56b
  );
}
function _0x509f37(_0x703953) {
  var _0x5a661e = document["createElement"]("a");
  (_0x5a661e["setAttribute"]("id", "amazonLink"),
    _0x5a661e["setAttribute"]("class", "a-link-text"),
    _0x5a661e["classList"]["add"]("icon"),
    _0x5a661e["classList"]["add"]("amazonLink"),
    _0x5a661e["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x4b2455 = document["createElement"]("img");
  return (
    _0x4b2455["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4b2455["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5a661e["appendChild"](_0x4b2455),
    _0x5a661e["addEventListener"]("click", async function (_0x8eac8) {
      (_0x8eac8["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x703953(_0x8eac8);
      } catch (_0x18ebfc) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x18ebfc);
      }
    }),
    _0x5a661e
  );
}
function _0x97e263(
  _0x21527b = null,
  _0x5b601b,
  _0x527e77 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x21527b, _0x5b601b);
  var _0x245876 = document["createElement"]("a");
  (_0x245876["setAttribute"]("id", "ebayLink"),
    _0x245876["setAttribute"]("class", "a-link-text"),
    _0x245876["classList"]["add"]("icon"),
    _0x5b601b && _0x5b601b["soldItems"]
      ? _0x245876["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x245876["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x22fe06 = document["createElement"]("img");
  return (
    _0x22fe06["setAttribute"]("src", chrome["runtime"]["getURL"](_0x527e77)),
    _0x22fe06["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x245876["appendChild"](_0x22fe06),
    _0x245876["addEventListener"]("click", async function (_0x42b9d5) {
      (_0x42b9d5["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x21527b) console["log"]("title\x20found", _0x21527b);
      else {
        console["log"]("title\x20not\x20found");
        var _0x53cb19 = _0x534705(_0x42b9d5);
        if (!_0x53cb19) return;
        var _0x4fb2ac = extractItemData(_0x53cb19);
        _0x21527b = _0x4fb2ac["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x46861b } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x21527b["length"] > 0x50; )
        _0x21527b = _0x21527b["substring"](
          0x0,
          _0x21527b["lastIndexOf"]("\x20"),
        );
      var _0x5d6130 =
        "https://www.ebay." +
        _0x46861b +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x21527b) +
        "&_odkw=" +
        encodeURIComponent(_0x21527b);
      (_0x5b601b && _0x5b601b["soldItems"] && (_0x5d6130 += "&LH_Sold=1"),
        _0x5b601b && _0x5b601b["sortLowToHigh"] && (_0x5d6130 += "&_sop=15"),
        _0x5b601b && _0x5b601b["endedRecently"] && (_0x5d6130 += "&_sop=13"),
        (_0x5d6130 += "&LH_ItemCondition=1000"),
        (_0x5d6130 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x5d6130,
        }));
    }),
    _0x245876
  );
}
function _0x6bc5ba(_0x59f33f = null) {
  var _0x3bb753 = document["createElement"]("a");
  (_0x3bb753["setAttribute"]("id", "googleLink"),
    _0x3bb753["setAttribute"]("class", "a-link-text"),
    _0x3bb753["classList"]["add"]("icon"),
    _0x3bb753["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x8eabb9 = document["createElement"]("img");
  return (
    _0x8eabb9["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x8eabb9["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3bb753["appendChild"](_0x8eabb9),
    _0x3bb753["addEventListener"]("click", async function (_0x4dd67a) {
      (_0x4dd67a["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x59f33f) {
        var _0x1b4e3b = _0x534705(_0x4dd67a);
        if (!_0x1b4e3b) return;
        var _0x43fa00 = extractItemData(_0x1b4e3b);
        _0x59f33f = _0x43fa00["image"];
      }
      var { domain: _0x4592f7 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x54e0a0(_0x4592f7),
        encodeURIComponent(_0x59f33f),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x59f33f,
        }));
    }),
    _0x3bb753
  );
}
function _0x1489cc(_0x47e4a = null) {
  var _0x451d49 = document["createElement"]("a");
  (_0x451d49["setAttribute"]("id", "googleLink"),
    _0x451d49["setAttribute"]("class", "a-link-text"),
    _0x451d49["classList"]["add"]("icon"),
    _0x451d49["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x2d4110 = document["createElement"]("img");
  return (
    _0x2d4110["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x2d4110["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x451d49["appendChild"](_0x2d4110),
    _0x451d49["addEventListener"]("click", async function (_0x110700) {
      (_0x110700["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x47e4a) {
        var _0x5d267a = _0x534705(_0x110700);
        if (!_0x5d267a) return;
        var _0x31022d = extractItemData(_0x5d267a);
        _0x47e4a = _0x31022d["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x47e4a,
      });
    }),
    _0x451d49
  );
}
function _0x38dba2(_0x29b047) {
  var _0x163ce1 = document["createElement"]("a");
  (_0x163ce1["setAttribute"]("id", "lookUpSkuLink"),
    _0x163ce1["setAttribute"]("class", "a-link-text"),
    _0x163ce1["classList"]["add"]("icon"),
    _0x163ce1["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x37a4e5 = document["createElement"]("img");
  return (
    _0x37a4e5["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x37a4e5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x163ce1["appendChild"](_0x37a4e5),
    _0x163ce1["addEventListener"]("click", async function (_0x29ad1a) {
      (_0x29ad1a["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x54c30d } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x1bec35 =
          "https://www.amazon." +
          _0x54c30d +
          "/dp/" +
          _0x29b047 +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x1bec35,
        options: { active: !0x0 },
      });
    }),
    _0x163ce1
  );
}
function _0x81745c(_0x41f9ba = null) {
  var _0x2ff4fd = document["createElement"]("a");
  (_0x2ff4fd["setAttribute"]("id", "productHunterLink"),
    _0x2ff4fd["setAttribute"]("class", "a-link-text"),
    _0x2ff4fd["classList"]["add"]("icon"),
    _0x2ff4fd["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x3bbba3 = document["createElement"]("img");
  return (
    _0x3bbba3["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x3bbba3["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2ff4fd["appendChild"](_0x3bbba3),
    _0x2ff4fd["addEventListener"]("click", async function (_0x3efa71) {
      (_0x3efa71["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x41f9ba) {
        var _0x51dc46 = _0x534705(_0x3efa71);
        if (!_0x51dc46) return;
        var _0x9ac695 = extractItemData(_0x51dc46);
        _0x41f9ba = _0x9ac695["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x41f9ba),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x41f9ba,
        }));
    }),
    _0x2ff4fd
  );
}
function _0x54e0a0(_0x1485ad) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x1485ad] || "en-US";
}
function _0x5d640b(_0x5c3fbb = null) {
  console["log"]("createSearchTerapeakButton", _0x5c3fbb);
  var _0x43c080 = document["createElement"]("a");
  (_0x43c080["setAttribute"]("class", "a-link-text"),
    _0x43c080["classList"]["add"]("terapeakLink"),
    _0x43c080["classList"]["add"]("icon"),
    _0x43c080["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x5c3fbb && _0x43c080["setAttribute"]("item_title", _0x5c3fbb));
  var _0x54df3d = document["createElement"]("img");
  return (
    _0x54df3d["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x54df3d["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x43c080["appendChild"](_0x54df3d),
    _0x43c080["addEventListener"]("click", async function (_0x5112a9) {
      (_0x5112a9["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x5ab56d = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x5ab56d),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x5ab56d) {
        var _0x2bc903 = _0x534705(_0x5112a9);
        if (!_0x2bc903) return;
        _0x5ab56d = extractItemData(_0x2bc903)["title"];
      }
      console["log"]("title", _0x5ab56d);
      var { convertToKeywords: _0x505e9c } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x505e9c) var _0x5ab56d = await _0x282c94(_0x5ab56d);
      var { domain: _0x2d6a0d } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x10e412 = _0x548b32(_0x5ab56d, _0x2d6a0d);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x10e412 });
    }),
    _0x43c080
  );
}
async function _0x282c94(_0x15a837) {
  var _0x2ac1d7 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x1084c6) => _0x1084c6["json"]());
  ((_0x2ac1d7["user_input"] = _0x15a837),
    console["log"]("jsonPrompt", _0x2ac1d7));
  var _0x3ceb92 = await new Promise((_0x372dfe, _0x494ee3) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x2ac1d7,
      },
      function (_0x4817e5) {
        _0x372dfe(_0x4817e5["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x3ceb92),
    (_0x3ceb92 = JSON["parse"](_0x3ceb92))["output"]
  );
}
function _0x548b32(
  _0x4bed46,
  _0xd42531 = "ca",
  _0x502281 = 0x1e,
  _0x1e9ad5 = 0x0,
  _0x50143e = 0x0,
  _0x36965e = 0x32,
  _0x2a5c70 = "-itemssold",
  _0x4f7da3 = "SOLD",
  _0x58631b = "EBAY-CA",
  _0x32f9ff = "America/Toronto",
  _0x1ad5df = "BuyerLocation:::CA",
  _0x3782d1 = 0x0,
) {
  _0x58631b = "";
  switch (_0xd42531) {
    case "ca":
    default:
      _0x58631b = "EBAY-CA";
      break;
    case "com":
      _0x58631b = "EBAY-US";
      break;
    case "co.uk":
      _0x58631b = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0xd42531 +
    "/sh/research?" +
    [
      "keywords=" + _0x4bed46,
      "dayRange=" + _0x502281,
      "categoryId=" + _0x1e9ad5,
      "offset=" + _0x50143e,
      "limit=" + _0x36965e,
      "sorting=" + _0x2a5c70,
      "tabName=" + _0x4f7da3,
      "marketplace=" + _0x58631b,
      "tz=" + encodeURIComponent(_0x32f9ff),
      "minPrice=" + _0x3782d1,
    ]["join"]("&")
  );
}
async function _0x1c4b89(_0x44fcf0) {
  var { domain: _0x5d6017 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x54e4c6 =
      "https://www.ebay." +
      _0x5d6017 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x44fcf0 +
      "&store_name=" +
      _0x44fcf0 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x54e4c6 });
}
async function _0x4fbff2(_0x838662) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x838662,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x838662));
}
async function _0x29a636(_0x5e568b) {
  var { response: _0x160f06 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x5e568b,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x160f06), _0x160f06);
}
function _0x12e501(_0x3826de = null) {
  console["log"]("createOpenSellerItemsButton", _0x3826de);
  var _0x4ff53f = document["createElement"]("a");
  (_0x4ff53f["setAttribute"]("id", "sellerItemsLink"),
    _0x4ff53f["setAttribute"]("class", "a-link-text"),
    _0x4ff53f["classList"]["add"]("icon"),
    _0x4ff53f["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x4d71fb = document["createElement"]("img");
  return (
    _0x4d71fb["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x4d71fb["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4ff53f["appendChild"](_0x4d71fb),
    _0x4ff53f["addEventListener"]("click", async function (_0x58bfbb) {
      (_0x58bfbb["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x3826de),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x3826de));
      var _0x782f2f;
      if (!_0x3826de) {
        console["log"]("username\x20not\x20found");
        var _0x5dc8ab = _0x534705(_0x58bfbb);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x5dc8ab,
        );
        if (!_0x5dc8ab) return;
        var _0x5683f2 = extractItemData(_0x5dc8ab);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x5683f2,
        ),
          (_0x3826de = _0x5683f2["username"]),
          (_0x782f2f = _0x5683f2["itemNumber"]));
      }
      if (
        _0x3826de["includes"]("\x20") ||
        _0x3826de !== _0x3826de["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x3826de,
        );
        if (!_0x782f2f) {
          if (!(_0x5dc8ab = _0x534705(_0x58bfbb))) return;
          _0x782f2f = (_0x5683f2 = extractItemData(_0x5dc8ab))["itemNumber"];
        }
        _0x4fbff2(_0x782f2f);
      } else
        ((_0x3826de = _0x3826de["toLowerCase"]()),
          console["log"]("username", _0x3826de),
          _0x1c4b89(_0x3826de));
    }),
    _0x4ff53f
  );
}
function _0x50dcc1(_0x28cbeb) {
  for (
    ;
    _0x28cbeb &&
    !_0x28cbeb["classList"]["contains"]("s-item") &&
    !_0x28cbeb["classList"]["contains"]("su-card-container");

  )
    _0x28cbeb = _0x28cbeb["parentElement"];
  return _0x28cbeb;
}
function _0x2e3af7(_0x4e9918 = null) {
  var _0x862417 = document["createElement"]("a");
  (_0x862417["setAttribute"]("id", "purchaseHistoryLink"),
    _0x862417["setAttribute"]("class", "a-link-text"),
    _0x862417["classList"]["add"]("icon"),
    _0x862417["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x4e0768 = document["createElement"]("img");
  return (
    _0x4e0768["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x4e0768["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x862417["appendChild"](_0x4e0768),
    _0x862417["addEventListener"]("click", async function (_0x464ee7) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x4e9918),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x464ee7["preventDefault"]());
      var _0x292331 = _0x534705(_0x464ee7);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x292331,
      );
      if (_0x292331) {
        var { selectedFilter: _0x59855b } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x59855b &&
          ((_0x59855b = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x59855b,
          }));
        var _0xb54801 = _0x59855b,
          _0x52e1b0 = await checkPurchaseHistoryAndAddToItem(
            _0x292331,
            _0xb54801,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x52e1b0);
      } else
        try {
          var _0x5c48d6 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x4e9918,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x5c48d6),
            (_0x52e1b0 = _0x5c48d6["totalSold"]));
        } catch (_0x15098d) {
          (console["log"]("error", _0x15098d), (_0x52e1b0 = -0x3e7));
        }
    }),
    _0x862417
  );
}
function _0x534705(_0x59b46d) {
  var _0x244ab6 = _0x59b46d["target"];
  return (
    (_0x244ab6 = _0x50dcc1(_0x244ab6)),
    console["log"]("found\x20s-item", _0x244ab6),
    _0x244ab6
  );
}
function _0x578639(_0x4cca76 = null, _0x3b3f82 = null, _0x10e7c2 = null) {
  var _0xe2f77f = document["createElement"]("a");
  (_0xe2f77f["setAttribute"]("id", "copyDataLink"),
    _0xe2f77f["setAttribute"]("class", "a-link-text"),
    _0xe2f77f["classList"]["add"]("icon"),
    _0xe2f77f["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x9979a2 = document["createElement"]("img");
  return (
    _0x9979a2["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x9979a2["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xe2f77f["appendChild"](_0x9979a2),
    _0xe2f77f["addEventListener"]("click", async function (_0x2f6837) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x4cca76,
        _0x3b3f82,
        _0x10e7c2,
      ),
        _0x2f6837["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x4cca76 && _0x3b3f82 && _0x10e7c2)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x4cca76,
          _0x3b3f82,
          _0x10e7c2,
        ),
          isNaN(_0x3b3f82) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x3b3f82),
            (_0x3b3f82 = _0x3b3f82["replace"](/[^0-9.]/g, ""))),
          _0x2d5490(
            JSON["stringify"]({
              title: _0x4cca76,
              price: _0x3b3f82,
              itemNumber: _0x10e7c2,
            }),
          ));
      else {
        if (!_0x4cca76 || !_0x3b3f82 || !_0x10e7c2) {
          var _0x2faf8f = _0x534705(_0x2f6837);
          if (!_0x2faf8f) return;
        }
        var _0x30f86e = extractItemData(_0x2faf8f);
        (console["log"]("itemData", _0x30f86e),
          _0x2d5490(JSON["stringify"](_0x30f86e)));
      }
    }),
    _0xe2f77f
  );
}
function _0x2d5490(_0x34ecdd) {
  var _0x424d56 = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x424d56),
    (_0x424d56["value"] = _0x34ecdd),
    _0x424d56["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x424d56));
}
async function _0x113263(_0x35f0b5 = null) {
  console["log"]("price", _0x35f0b5);
  if (_0x35f0b5) {
    try {
      _0x35f0b5 = _0x35f0b5["replace"](/[^0-9.]/g, "");
    } catch (_0x439f2d) {}
    _0x35f0b5 = parseFloat(_0x35f0b5);
  }
  var _0x3a5772 = await _0x5e47a4(_0x35f0b5),
    _0x4ead01 = document["createElement"]("div");
  return (
    _0x4ead01["setAttribute"]("id", "breakEvenPrice"),
    _0x4ead01["setAttribute"]("class", "break-even-price"),
    (_0x4ead01["textContent"] =
      "Break-even\x20price:\x20$" + _0x3a5772["toFixed"](0x2)),
    _0x4ead01
  );
}
async function _0x364d4b(_0x232c52) {
  var _0x3bbfa1 = !0x1,
    _0x53fa5c = !0x1,
    { includeCurrencyConversion: _0x53fa5c } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x3bbfa1 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x2e513a =
    0.1325 * _0x232c52 +
    0.021 * _0x232c52 +
    _0x232c52 * (_0x3bbfa1 ? 0.004 : 0x0) +
    0.4;
  return (_0x53fa5c && (_0x2e513a += 0.035 * _0x232c52), _0x232c52 - _0x2e513a);
}
async function _0x5e47a4(_0x5bf705) {
  var { isInternational: _0xc976c2 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0xecb457 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0xc976c2 || (_0xc976c2 = !0x1), _0xecb457 || (_0xecb457 = !0x0));
  var _0x30e542 = 13.25;
  _0xecb457 && (_0x30e542 = 12.35);
  var _0x5dc1f1 = _0x5bf705 + 0.0725 * _0x5bf705,
    _0x28f173 =
      _0x5dc1f1 * (_0x30e542 / 0x64) +
      0.4 +
      (_0xc976c2 ? 0.004 * _0x5dc1f1 : 0x0),
    _0x3f57cf =
      _0x5bf705 -
      (_0x28f173 + (_0xc976c2 ? 0.05 * _0x28f173 : 0x0)) -
      (_0xc976c2 ? 0.035 * _0x5dc1f1 : 0x0),
    { isUserTaxExempt: _0x319e89 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x319e89 || (_0x319e89 = !0x1),
    _0x319e89 || (_0x3f57cf /= 1.0725),
    _0xc976c2 && (_0x3f57cf -= (3.5 * _0x3f57cf) / 0x64),
    _0x3f57cf
  );
}
function _0x25ef0d(_0x49a712 = null) {
  console["log"]("createButtonToSaveSeller", _0x49a712);
  var _0x46612f = document["createElement"]("a");
  (_0x46612f["setAttribute"]("id", "saveSellerLink"),
    _0x46612f["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x46612f["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x4a5951 = document["createElement"]("img");
  return (
    _0x4a5951["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x4a5951["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x46612f["appendChild"](_0x4a5951),
    _0x46612f["addEventListener"]("click", async function (_0x4e046d) {
      (_0x4e046d["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x49a712));
      var _0x39b910;
      if (!_0x49a712) {
        var _0x50fa58 = _0x534705(_0x4e046d);
        if (!_0x50fa58) return;
        var _0x3b5b28 = extractItemData(_0x50fa58);
        ((_0x49a712 = _0x3b5b28["username"]),
          (_0x39b910 = _0x3b5b28["itemNumber"]));
      }
      if (
        _0x49a712["includes"]("\x20") ||
        _0x49a712 !== _0x49a712["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x49a712,
        ),
          (_0x49a712 = await _0x29a636(_0x39b910)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x49a712,
          ));
      else _0x49a712 = _0x49a712["toLowerCase"]();
      _0x46612f["setAttribute"]("data-seller-name", _0x49a712);
      var { ebayCompetitors: _0x13e91c } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x21ed7c = (_0x13e91c = _0x13e91c || [])["indexOf"](_0x49a712);
      console["log"]("ebayCompetitors", _0x13e91c);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x21ed7c
            ? (console["log"]("save-seller\x20clicked\x20username", _0x49a712),
              _0x13e91c["push"](_0x49a712),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x4a5951["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x49a712,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x4a5951["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x21ed7c)
            (console["log"]("remove-seller\x20clicked\x20username", _0x49a712),
              _0x13e91c["splice"](_0x21ed7c, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x4a5951["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x49a712,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x13e91c });
    }),
    _0x46612f
  );
}
async function _0x4d19f4(_0x54e2e2, _0x503c73) {
  var { ebayCompetitors: _0x1682bb } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x29f4f3 = (_0x1682bb = _0x1682bb || [])["indexOf"](_0x503c73),
    _0x39266f = _0x54e2e2["querySelector"]("img");
  -0x1 !== _0x29f4f3
    ? (_0x54e2e2["classList"]["replace"]("save-seller", "remove-seller"),
      _0x39266f["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x54e2e2["classList"]["replace"]("remove-seller", "save-seller"),
      _0x39266f["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x362253(
  _0x1a45d2 = null,
  _0x3d97da = null,
  _0x5c0a3e = null,
  _0x43ce7d = !0x0,
  _0x4d16e2 = null,
  _0x1ae248 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x1a45d2));
  var _0x9606c0 = _0x25ef0d(_0x3d97da),
    _0x3cd976 = _0x5d640b(_0x1a45d2),
    _0x2f432b = _0x2e3af7(_0x4d16e2),
    _0x2a5ed1 = _0x97e263(_0x1a45d2),
    _0x5645fe = _0x326bc7(_0x1a45d2, _0x1ae248, _0x4d16e2, _0x5c0a3e),
    _0x48f735 = _0x97e263(
      _0x1a45d2,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x1fc852 = _0x6bc5ba(_0x5c0a3e),
    _0x9c579f = _0x1489cc(_0x4d16e2),
    _0x2beb65 = _0x12e501(_0x3d97da),
    _0x3c73bd = document["createElement"]("div");
  _0x3c73bd["setAttribute"]("id", "search-div");
  var _0x5e0ee6 = document["createElement"]("label");
  ((_0x5e0ee6["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x3c73bd["appendChild"](_0x5e0ee6),
    _0x3c73bd["appendChild"](_0x5645fe),
    _0x3c73bd["appendChild"](_0x2a5ed1),
    _0x3c73bd["appendChild"](_0x3cd976),
    _0x3c73bd["appendChild"](_0x1fc852),
    _0x3c73bd["appendChild"](_0x9c579f),
    _0x3c73bd["appendChild"](_0x48f735),
    console["log"]("CopyDataButton", _0x1a45d2, _0x1ae248, _0x4d16e2));
  var _0x4ce08f = _0x578639(_0x1a45d2, _0x1ae248, _0x4d16e2),
    _0xe56e2b = document["createElement"]("div");
  _0xe56e2b["setAttribute"]("id", "item-buttons-div");
  var _0x8f16e4 = document["createElement"]("div");
  (_0x8f16e4["setAttribute"]("id", "main-buttons-div"),
    _0x8f16e4["appendChild"](_0x2beb65),
    _0x8f16e4["appendChild"](_0x2f432b),
    _0x8f16e4["appendChild"](_0x4ce08f),
    _0x8f16e4["appendChild"](_0x9606c0),
    _0xe56e2b["appendChild"](_0x8f16e4));
  if (_0x43ce7d) {
    var _0x41bdcf = createButtonListToEbay();
    _0xe56e2b["appendChild"](_0x41bdcf);
  }
  return (_0xe56e2b["appendChild"](_0x3c73bd), _0xe56e2b);
}
var _0x20886f = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x57e83a) => {
        (console["log"](
          _0x57e83a,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x20886f, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x5b8ad2) => {
        (console["log"](
          _0x5b8ad2,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x20886f, "search-type", "keywords"));
      },
    },
  },
];
async function _0x12a12a() {
  var { convertToKeywords: _0x17f748 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x17f748 &&
    ((_0x17f748 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x20886f,
      "search-type",
      _0x17f748 ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x20886f })[
      "init"
    ]());
}
var _0x3a38fa = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x1671e2) => {
        (console["log"](_0x1671e2, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x3a38fa, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x1dae06) => {
        (console["log"](_0x1dae06, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x3a38fa, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x5c8231) => {
        (console["log"](
          _0x5c8231,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x3a38fa, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x1db624) => {
        (console["log"](
          _0x1db624,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x3a38fa, "search-type", "keywords"));
      },
    },
  },
];
async function _0x1da832() {
  var { amazonSortType: _0x1694ab } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x41f350 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x41f350 &&
    ((_0x41f350 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x1694ab &&
      ((_0x1694ab = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x3a38fa, "sort-type", _0x1694ab),
    updateContextMenu(_0x3a38fa, "search-type", _0x41f350),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x3a38fa })[
      "init"
    ]());
}
_0x3a38fa = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x4c594d) => {
        (console["log"](_0x4c594d, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x3a38fa, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x2881b5) => {
        (console["log"](_0x2881b5, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x3a38fa, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x38e1e1 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x4e7d61) => {
        (console["log"](_0x4e7d61, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0x38e1e1, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x25a9e7) => {
        (console["log"](_0x25a9e7, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0x38e1e1, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x1253d0) => {
        (console["log"](_0x1253d0, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0x38e1e1, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x129393) => {
        (console["log"](_0x129393, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0x38e1e1, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x54fdbc) => {
        (console["log"](_0x54fdbc, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0x38e1e1, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5eeae8) => {
        (console["log"](_0x5eeae8, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0x38e1e1, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5427ba) => {
        (console["log"](_0x5427ba, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0x38e1e1, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2bdb5b) => {
        (console["log"](_0x2bdb5b, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0x38e1e1, "filter-type", "90"));
      },
    },
  },
];
async function _0x43b0d9() {
  var { selectedFilter: _0x305348 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x305348 &&
    ((_0x305348 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0x38e1e1, "filter-type", _0x305348),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0x38e1e1 })[
      "init"
    ]());
}
function _0x26f26c() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x4c7a4c() {
  const _0x57cf15 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x14cd48 = 0x0;
  const _0x24dfcc = () =>
    new Promise((_0x3ae688, _0x4936e2) => {
      const _0x4d3dee = new MutationObserver((_0x224a03, _0x293626) => {
        const _0x37052a = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x37052a &&
          (console["log"]("Details\x20form\x20found!"),
          _0x293626["disconnect"](),
          _0x3ae688(_0x37052a));
      });
      (_0x4d3dee["observe"](_0x57cf15, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x4d3dee["disconnect"]();
          if (_0x14cd48 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x14cd48 + 0x1) +
                "/3)",
            ),
              _0x14cd48++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x3ae688(_0x24dfcc()), 0x1388));
          else
            _0x4936e2(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x26130c = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x26130c) {
    (_0x26130c["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x24dfcc(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x400c59) {
      console["error"](_0x400c59["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x52934f(_0x471e9b = null, _0x92af51 = null, _0x757f1a = null) {
  var _0x326d99 = document["createElement"]("a");
  (_0x326d99["setAttribute"]("id", "copyDataLink"),
    _0x326d99["setAttribute"]("class", "a-link-text"),
    _0x326d99["classList"]["add"]("icon"),
    _0x326d99["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x5939f3 = document["createElement"]("img");
  return (
    _0x5939f3["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x5939f3["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x326d99["appendChild"](_0x5939f3),
    _0x326d99["addEventListener"]("click", async function (_0x335db3) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x471e9b,
        _0x92af51,
        _0x757f1a,
      ),
        _0x335db3["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x471e9b && _0x92af51 && _0x757f1a) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x471e9b,
          _0x92af51,
          _0x757f1a,
        );
        isNaN(_0x92af51) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x92af51),
          (_0x92af51 = _0x92af51["replace"](/[^0-9.]/g, "")));
        var _0x1dc6e2 = JSON["stringify"]({
          title: _0x471e9b,
          price: _0x92af51,
          itemNumber: _0x757f1a,
        });
        (_0x4dd6ed(
          (_0x315502 = await findSimiliarProducts(_0x1dc6e2))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x315502),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x471e9b || !_0x92af51 || !_0x757f1a) {
          var _0x525735 = _0x534705(_0x335db3);
          if (!_0x525735) return;
        }
        var _0xb94547 = extractItemData(_0x525735);
        (console["log"]("itemData", _0xb94547),
          (_0x1dc6e2 = JSON["stringify"](_0xb94547)));
        var _0x315502;
        (_0x4dd6ed(
          (_0x315502 = await findSimiliarProducts(_0x1dc6e2))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x315502),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x326d99
  );
}
async function findSimiliarProducts(_0x226eb6) {
  console["log"]("findSimiliarProducts", _0x226eb6);
  var _0x4eb0f4 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x226eb6,
  });
  return (console["log"]("response", _0x4eb0f4), _0x4eb0f4["productLinks"]);
}
function _0x4dd6ed(_0x291a6a) {
  const _0x795968 = document["getElementById"]("productLinksModalOverlay");
  _0x795968 && _0x795968["remove"]();
  const _0x4cdd87 = document["createElement"]("div");
  ((_0x4cdd87["id"] = "productLinksModalOverlay"),
    _0x4cdd87["classList"]["add"]("product-links-modal-overlay"));
  const _0x11fca7 = document["createElement"]("div");
  _0x11fca7["classList"]["add"]("product-links-modal");
  const _0x2173eb = document["createElement"]("div");
  _0x2173eb["classList"]["add"]("modal-button-container");
  const _0x56a663 = document["createElement"]("button");
  (_0x56a663["classList"]["add"]("close-button"),
    (_0x56a663["innerText"] = "Close"),
    _0x56a663["addEventListener"]("click", () => {
      _0x4cdd87["remove"]();
    }));
  const _0x27a908 = document["createElement"]("button");
  (_0x27a908["classList"]["add"]("copy-button"),
    (_0x27a908["innerText"] = "Copy"),
    _0x27a908["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x291a6a),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x5f0f6c) {
        console["error"]("Failed\x20to\x20copy:", _0x5f0f6c);
      }
    }));
  const _0x4e6ff7 = document["createElement"]("h2");
  _0x4e6ff7["innerText"] = "Similar\x20Product\x20Links";
  const _0x10e8b2 = document["createElement"]("textarea");
  ((_0x10e8b2["value"] = _0x291a6a),
    _0x10e8b2["setAttribute"]("readonly", !0x0),
    (_0x10e8b2["style"]["width"] = "100%"),
    (_0x10e8b2["style"]["height"] = "300px"),
    _0x2173eb["appendChild"](_0x27a908),
    _0x2173eb["appendChild"](_0x56a663),
    _0x11fca7["appendChild"](_0x2173eb),
    _0x11fca7["appendChild"](_0x4e6ff7),
    _0x11fca7["appendChild"](_0x10e8b2),
    _0x4cdd87["appendChild"](_0x11fca7),
    document["body"]["appendChild"](_0x4cdd87));
}
console["log"]("ebay/mesh_order_details/functions.js");
var _0x349b7a;
function _0x156bb4() {
  return document["querySelector"](".lineItemCardInfo__itemId.spaceTop");
}
async function _0x4328cd() {
  console["log"]("createSkuElementButton");
  var _0x2d5d26 = await _0x521c36();
  console["log"]("skuTest", _0x2d5d26);
  if (_0x2d5d26 && _0x2d5d26["endsWith"]("=="))
    (console["log"]("skuTest", _0x2d5d26),
      console["log"](
        "No\x20need\x20to\x20create\x20SKU\x20button.\x20SKU\x20ends\x20with\x20\x22==\x22.",
      ));
  else {
    var _0x4ef73e = document["querySelector"](
      ".lineItemCardInfo__content\x20.details",
    );
    _0x4ef73e || (_0x4ef73e = document["body"]);
    var _0x5e7b47 = document["createElement"]("button");
    ((_0x5e7b47["textContent"] = "Get\x20SKU"),
      _0x4ef73e["insertBefore"](_0x5e7b47, _0x4ef73e["children"][0x1]),
      _0x5e7b47["addEventListener"]("click", async function (_0x33ee72) {
        _0x33ee72["preventDefault"]();
        var _0x1555d7 = document["createElement"]("div");
        _0x1555d7["classList"]["add"]("lineItemCardInfo__sku", "spaceTop");
        var _0x24f0dd = document["createElement"]("span");
        (_0x24f0dd["classList"]["add"]("sh-secondary"),
          (_0x24f0dd["textContent"] = "Custom\x20label\x20(SKU):\x20"));
        var _0x491b34 = document["createElement"]("span");
        _0x491b34["classList"]["add"]("sh-secondary");
        var _0x5553d9 = _0x2bfa2b(),
          _0x42b9f7 = await _0x119815(_0x5553d9);
        ((_0x491b34["textContent"] = _0x42b9f7),
          _0x1555d7["appendChild"](_0x24f0dd),
          _0x1555d7["appendChild"](_0x491b34),
          _0x4ef73e["replaceChild"](_0x1555d7, _0x5e7b47));
      }));
  }
}
async function _0x165f90() {
  var _0x722f47 = document["createElement"]("button");
  return (
    (_0x722f47["innerText"] = "Copy"),
    _0x722f47["classList"]["add"]("amazon-copy-link-button"),
    _0x722f47["addEventListener"]("click", async function () {
      var _0x5266bf = await _0x521c36();
      if (!_0x5266bf) return null;
      console["log"]("sku", _0x5266bf);
      var _0x22317b = await _0x52edf8(_0x5266bf);
      (navigator["clipboard"]["writeText"](_0x22317b),
        _0x722f47["classList"]["add"]("amazon-copy-link-button-clicked"),
        (_0x722f47["innerText"] = "Copied"));
    }),
    _0x722f47
  );
}
async function _0x1d260b(_0x5bf695 = !0x1, _0xd6344a) {
  console["log"]("copyOrderDetails");
  var _0x589b61 = await _0x218212();
  (console["log"]("orderDetails", _0x589b61),
    await chrome["storage"]["local"]["set"]({ orderDetails: _0x589b61 }));
  var _0x5adc88 = JSON["stringify"](_0x589b61);
  console["log"]("stringified\x20orderDetails", _0x5adc88);
  if (_0x5bf695) {
    console["log"]("orderDetailsString", _0x5adc88);
    var _0x94610e = {
      clipKey: _0xd6344a,
      content: JSON["stringify"](_0x589b61),
    };
    console["log"]("data", _0x94610e);
    try {
      console["log"]("making\x20request");
      var _0x115dc9 = await fetch(
        "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/virtualClipboard/",
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON["stringify"](_0x94610e),
        },
      );
      console["log"]("response", _0x115dc9);
      if (!_0x115dc9["ok"])
        throw new Error("Failed\x20to\x20save\x20order\x20details");
      var _0x22359d = await _0x115dc9["json"]();
      return (
        console["log"]("Order\x20details\x20saved\x20successfully:", _0x22359d),
        _0x22359d
      );
    } catch (_0x438fdb) {
      console["error"]("Error\x20saving\x20order\x20details:", _0x438fdb);
      throw _0x438fdb;
    }
  } else navigator["clipboard"]["writeText"](_0x5adc88);
}
async function _0x17a6fa() {
  var { shouldCopyAddress: _0x2a9e02 } =
    await chrome["storage"]["local"]["get"]("shouldCopyAddress");
  void 0x0 === _0x2a9e02 &&
    ((_0x2a9e02 = !0x0),
    await chrome["storage"]["local"]["set"]({ shouldCopyAddress: _0x2a9e02 }));
  var _0x10f5a2 = document["createElement"]("input");
  (_0x10f5a2["setAttribute"]("type", "checkbox"),
    _0x10f5a2["classList"]["add"]("amazon-copy-address-field"),
    _0x10f5a2["setAttribute"]("id", "amazon-copy-address-field"));
  var _0x5c8826 = document["createElement"]("label");
  ((_0x5c8826["innerText"] = "Copy\x20Address"),
    _0x5c8826["setAttribute"]("for", "amazon-copy-address-field"),
    _0x5c8826["classList"]["add"]("amazon-copy-address-label"));
  var _0x2e61fe = document["createElement"]("div");
  return (
    (_0x2e61fe["id"] = "amazon-copy-address-div"),
    _0x2e61fe["appendChild"](_0x5c8826),
    _0x2e61fe["appendChild"](_0x10f5a2),
    (_0x10f5a2["checked"] = _0x2a9e02),
    _0x10f5a2["addEventListener"]("change", async function () {
      await chrome["storage"]["local"]["set"]({
        shouldCopyAddress: _0x10f5a2["checked"],
      });
    }),
    _0x2e61fe
  );
}
function _0x3a6c29() {
  var _0x37be4a = document["createElement"]("div");
  _0x37be4a["classList"]["add"]("amazon-quantity-container");
  var _0x3c88fc = document["createElement"]("label");
  ((_0x3c88fc["innerText"] = "Increase\x20Quantity"),
    _0x3c88fc["classList"]["add"]("amazon-quantity-label"),
    _0x37be4a["appendChild"](_0x3c88fc));
  var _0x1d30aa = document["createElement"]("button");
  ((_0x1d30aa["innerText"] = "Increase\x20Quantity"),
    _0x1d30aa["classList"]["add"]("amazon-update-quantity-button"),
    _0x37be4a["appendChild"](_0x1d30aa),
    _0x1d30aa["addEventListener"]("click", async function () {
      _0x1d30aa["classList"]["add"]("amazon-update-quantity-button-working");
      var _0x19bbd8 = document["querySelector"](
        ".lineItemCardInfo__itemId.spaceTop",
      )["querySelectorAll"](".sh-secondary")[0x1]["innerText"];
      _0x1d30aa["innerText"] = "In\x20Progress";
      try {
        var _0x845a0b = await new Promise((_0x901b4e) => {
          chrome["runtime"]["sendMessage"](
            { type: "increaseQuantityOfItem", itemNumber: _0x19bbd8 },
            function (_0x35b3e2) {
              (console["log"](_0x35b3e2), _0x901b4e(_0x35b3e2));
            },
          );
        });
        _0x1d30aa["classList"]["remove"](
          "amazon-update-quantity-button-working",
        );
        if (!_0x845a0b || !_0x845a0b["response"])
          throw new Error("Response\x20Error");
        (_0x1d30aa["classList"]["add"]("amazon-update-quantity-button-success"),
          (_0x1d30aa["innerText"] = "Updated"),
          _0x1d30aa["dispatchEvent"](
            new CustomEvent("increase:done", {
              detail: { ok: !0x0, response: _0x845a0b },
            }),
          ));
      } catch (_0x1f5a29) {
        (_0x1d30aa["classList"]["remove"](
          "amazon-update-quantity-button-working",
        ),
          _0x1d30aa["classList"]["add"]("amazon-update-quantity-button-error"),
          (_0x1d30aa["innerText"] = "Error"),
          console["log"]("error", _0x1f5a29),
          _0x1d30aa["dispatchEvent"](
            new CustomEvent("increase:done", {
              detail: { ok: !0x1, error: _0x1f5a29 },
            }),
          ));
      }
    }));
  var _0x441749 = document["createElement"]("select");
  _0x441749["classList"]["add"]("amazon-quantity-select");
  for (var _0x536477 = 0x0; _0x536477 <= 0xa; _0x536477++) {
    var _0xd10a0a = document["createElement"]("option");
    ((_0xd10a0a["value"] = _0x536477),
      (_0xd10a0a["text"] = _0x536477),
      _0x441749["appendChild"](_0xd10a0a));
  }
  return (
    chrome["storage"]["local"]["get"]("quantityToUpdate", function (_0x2f07e0) {
      if (_0x2f07e0["quantityToUpdate"])
        _0x441749["value"] = _0x2f07e0["quantityToUpdate"];
      else
        ((_0x441749["value"] = 0x1),
          chrome["storage"]["local"]["set"]({ quantityToUpdate: 0x1 }));
    }),
    _0x441749["addEventListener"]("change", function () {
      var _0x1790ae = _0x441749["value"];
      chrome["storage"]["local"]["set"]({ quantityToUpdate: _0x1790ae });
    }),
    _0x37be4a["appendChild"](_0x441749),
    _0x37be4a
  );
}
function _0x4db571() {
  var _0xc1e064 = document["createElement"]("button");
  return (
    (_0xc1e064["innerText"] = "Copy\x20ETA\x20Message"),
    _0xc1e064["classList"]["add"]("amazon-copy-eta-button"),
    _0xc1e064["addEventListener"]("click", async function () {
      var _0x3bf0ac = _0x541e4e(),
        { etaMessage: _0x153772 } =
          await chrome["storage"]["local"]["get"]("etaMessage");
      !_0x153772 &&
        ((_0x153772 = await fetch(
          chrome["runtime"]["getURL"](
            "content/ebay/mesh_order_details/eta_options/eta_message_default.txt",
          ),
        )),
        (_0x153772 = await _0x153772["text"]()));
      var _0x150b8c = document["querySelectorAll"](
        ".shipping-address\x20.tooltip",
      )[0x1]["innerText"];
      ((_0x150b8c =
        (_0x150b8c = _0x150b8c["split"]("\x20")[0x0])
          ["charAt"](0x0)
          ["toUpperCase"]() + _0x150b8c["slice"](0x1)["toLowerCase"]()),
        (_0x153772 = (_0x153772 = _0x153772["replace"](
          "{{Customer_Name}}",
          _0x150b8c,
        ))["replace"]("{{Delivery_Date}}", _0x3bf0ac)),
        navigator["clipboard"]["writeText"](_0x153772),
        _0xc1e064["classList"]["add"]("amazon-copy-eta-button-clicked"),
        (_0xc1e064["innerText"] = "Copied"));
    }),
    _0xc1e064
  );
}
function _0x93938b() {
  var _0x5a4523 = document["createElement"]("button");
  return (
    (_0x5a4523["innerText"] = "Copy\x20Feedback\x20Message"),
    _0x5a4523["classList"]["add"]("amazon-copy-feedback-button"),
    _0x5a4523["addEventListener"]("click", async function () {
      var { feedbackMessage: _0x21a190 } =
        await chrome["storage"]["local"]["get"]("feedbackMessage");
      !_0x21a190 &&
        ((_0x21a190 = await fetch(
          chrome["runtime"]["getURL"](
            "content/ebay/mesh_order_details/feedback_options/feedback_message_default.txt",
          ),
        )),
        (_0x21a190 = await _0x21a190["text"]()));
      var _0x322ea6 = (await _0x218212())["customer"]["name"]["split"](
          "\x20",
        )[0x0],
        _0x291523 = _0x21a190["replace"]("{{Customer_Name}}", _0x322ea6);
      navigator["clipboard"]["writeText"](_0x291523);
    }),
    _0x5a4523
  );
}
function _0x526b17() {
  var _0x3e2803 = document["createElement"]("input");
  (_0x3e2803["setAttribute"]("type", "date"),
    _0x3e2803["classList"]["add"]("amazon-eta-field"));
  var _0x168260 = document["createElement"]("label");
  ((_0x168260["innerText"] = "ETA"),
    _0x168260["setAttribute"]("for", "amazon-eta-field"),
    _0x168260["classList"]["add"]("amazon-eta-label"));
  var _0x4b47df = document["createElement"]("div");
  (_0x4b47df["appendChild"](_0x168260), _0x4b47df["appendChild"](_0x3e2803));
  var _0x3a764d = document["createElement"]("a");
  return (
    (_0x3a764d["innerText"] = "Change\x20ETA\x20Message"),
    _0x3a764d["classList"]["add"]("amazon-eta-link"),
    _0x3a764d["setAttribute"]("target", "_blank"),
    _0x3a764d["setAttribute"](
      "href",
      chrome["runtime"]["getURL"](
        "content/ebay/mesh_order_details/eta_options/eta_options.html",
      ),
    ),
    _0x4b47df["appendChild"](_0x3a764d),
    _0x4b47df
  );
}
function _0x422eaa() {
  var _0x291f50 = document["createElement"]("div"),
    _0x2569ef = document["createElement"]("a");
  return (
    (_0x2569ef["innerText"] = "Change\x20Feedback\x20Message"),
    _0x2569ef["classList"]["add"]("amazon-feedback-link"),
    _0x2569ef["setAttribute"]("target", "_blank"),
    _0x2569ef["setAttribute"](
      "href",
      chrome["runtime"]["getURL"](
        "content/ebay/mesh_order_details/feedback_options/feedback_options.html",
      ),
    ),
    _0x291f50["appendChild"](_0x2569ef),
    _0x291f50
  );
}
function _0x541e4e() {
  var _0x277851 = document["querySelector"](".amazon-eta-field"),
    _0x37f203 = new Date(_0x277851["value"]);
  return (
    _0x37f203["setDate"](_0x37f203["getDate"]() + 0x1),
    _0x37f203["toLocaleDateString"]("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  );
}
async function _0x52edf8(_0x4aaa83) {
  var { domain: _0x4ca6f7 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x40342c =
      "https://www.amazon." +
      _0x4ca6f7 +
      "/dp/" +
      atob(_0x4aaa83) +
      "?th=1&psc=1",
    { applyAmazonAffiliateTag: _0x2bd6db } = await chrome["storage"]["local"][
      "get"
    ]("applyAmazonAffiliateTag");
  return (_0x2bd6db && (_0x40342c += "&tag=bestbatteri00-20"), _0x40342c);
}
async function _0x333c7b(_0xfb949b) {
  var { email: _0x5d2062 } = await chrome["storage"]["local"]["get"]("email");
  _0xfb949b["email"] = _0x5d2062;
  try {
    var _0x1dbe93 = await fetch(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/ebayOrders",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON["stringify"](_0xfb949b),
      },
    );
    if (!_0x1dbe93["ok"])
      throw new Error("Failed\x20to\x20submit\x20eBay\x20order");
    var _0x3a40c5 = await _0x1dbe93["json"]();
    return (
      console["log"]("eBay\x20order\x20submitted\x20successfully:", _0x3a40c5),
      _0x3a40c5
    );
  } catch (_0x381444) {
    console["error"]("Error\x20submitting\x20eBay\x20order:", _0x381444);
    throw _0x381444;
  }
}
function _0x3b1a6d() {
  var _0x16177c = document["querySelector"](".shipping-address\x20.address");
  console["log"]("shippingAddressElement:", _0x16177c);
  var _0x4f9bac = _0x16177c["childNodes"];
  console["log"]("children:", _0x4f9bac);
  var _0x22f541 = _0x4f9bac[0x0]["innerText"];
  console["log"]("name:", _0x22f541);
  var _0x2a94c9, _0x250168, _0x378fab, _0x3faf2b, _0xf963fd, _0x37ac64;
  if (0x5 == _0x4f9bac["length"])
    ((_0x2a94c9 = _0x4f9bac[0x1]["innerText"]),
      console["log"]("line_1:", _0x2a94c9),
      (_0x250168 = _0x4f9bac[0x2]["innerText"]),
      console["log"]("line_2:", _0x250168),
      (_0x378fab = (_0x35a0b9 =
        _0x4f9bac[0x3]["querySelectorAll"](".copy-to-clipboard"))[0x0][
        "innerText"
      ]),
      console["log"]("city:", _0x378fab),
      (_0x3faf2b = _0x35a0b9[0x1]["innerText"]),
      console["log"]("state:", _0x3faf2b),
      (_0xf963fd = _0x35a0b9[0x2]["innerText"]),
      console["log"]("zip:", _0xf963fd),
      (_0x37ac64 = _0x4f9bac[0x4]["innerText"]),
      console["log"]("country:", _0x37ac64));
  else {
    if (0x4 == _0x4f9bac["length"]) {
      ((_0x2a94c9 = _0x4f9bac[0x1]["innerText"]),
        console["log"]("line_1:", _0x2a94c9));
      var _0x35a0b9;
      ((_0x378fab = (_0x35a0b9 =
        _0x4f9bac[0x2]["querySelectorAll"](".copy-to-clipboard"))[0x0][
        "innerText"
      ]),
        console["log"]("city:", _0x378fab),
        (_0x3faf2b = _0x35a0b9[0x1]["innerText"]),
        console["log"]("state:", _0x3faf2b),
        (_0xf963fd = _0x35a0b9[0x2]["innerText"]),
        console["log"]("zip:", _0xf963fd),
        (_0x37ac64 = _0x4f9bac[0x3]["innerText"]),
        console["log"]("country:", _0x37ac64));
    }
  }
  var _0x18b02e = document["querySelector"](".phone.ship-itm");
  console["log"]("phoneNumberElement:", _0x18b02e);
  var _0x3e1f1f = "";
  _0x18b02e &&
    ((_0x3e1f1f = _0x18b02e["querySelector"](".info-value")["innerText"]),
    console["log"]("phone:", _0x3e1f1f));
  var _0x137110 = {
    name: _0x22f541,
    phone: _0x3e1f1f,
    address: {
      line_1: _0x2a94c9,
      line_2: _0x250168,
      city: _0x378fab,
      state: _0x3faf2b,
      zip: _0xf963fd,
      country: _0x37ac64,
    },
  };
  return (console["log"]("customer:", _0x137110), _0x137110);
}
function _0x5c4599() {
  var _0x1ed48d = document["querySelector"](".note-content");
  return _0x1ed48d ? _0x1ed48d["innerText"] : null;
}
function _0x5901c8() {
  var _0x2f4dd7 =
      document["querySelector"]("#amazonOrderNumber")?.["innerText"],
    _0x389ead = document["querySelector"]("#totalBeforeTax")?.["innerText"],
    _0x1fb0aa = document["querySelector"]("#totalTax")?.["innerText"],
    _0x50d2ea = document["querySelector"]("#estimatedDeliveryDate")?.[
      "innerText"
    ],
    _0x2aac4b = document["querySelector"]("#amazonEmail")?.["innerText"],
    _0x5e50be = document["querySelector"]("#fulfillmentDate")?.["innerText"],
    _0xd5ded3 = document["querySelector"]("#amazonSku")?.["innerText"],
    _0x21f8c8 = document["querySelector"]("#amazonDomain")?.["innerText"];
  if (
    _0x2f4dd7 &&
    _0x389ead &&
    _0x1fb0aa &&
    _0x50d2ea &&
    _0x2aac4b &&
    _0x5e50be
  )
    return {
      amazonOrderNumber: _0x2f4dd7,
      totalBeforeTax: _0x389ead,
      totalTax: _0x1fb0aa,
      estimatedDeliveryDate: _0x50d2ea,
      amazonEmail: _0x2aac4b,
      fulfillmentDate: _0x5e50be,
      amazonSku: _0xd5ded3,
      amazonDomain: _0x21f8c8,
    };
}
function _0x1abefc() {
  var _0x582fe6 = document["createElement"]("button");
  return (
    (_0x582fe6["innerText"] = "Export\x20to\x20EcomSniper"),
    _0x582fe6["classList"]["add"]("ebay-submit-order-details-button"),
    _0x582fe6["addEventListener"]("click", async function () {
      _0x582fe6["classList"]["add"]("ebay-submit-order-details-button-working");
      var _0x17b4b3 = await _0x218212();
      console["log"]("orderDetails", _0x17b4b3);
      try {
        var _0x24770d = await _0x333c7b(_0x17b4b3);
        (console["log"]("response", _0x24770d),
          _0x582fe6["classList"]["remove"](
            "ebay-submit-order-details-button-working",
          ),
          _0x582fe6["classList"]["add"](
            "ebay-submit-order-details-button-success",
          ),
          (_0x582fe6["innerText"] = "Exported!"));
      } catch (_0x5d6452) {
        (_0x582fe6["classList"]["remove"](
          "ebay-submit-order-details-button-working",
        ),
          _0x582fe6["classList"]["add"](
            "ebay-submit-order-details-button-error",
          ),
          (_0x582fe6["innerText"] = "Error\x20Exporting\x20Data"),
          console["log"]("error", _0x5d6452));
      }
    }),
    _0x582fe6
  );
}
async function _0x1e5d80() {
  var _0x416119 = await _0x218212();
  console["log"]("orderDetails", _0x416119);
  try {
    var _0x3310a0 = await _0x333c7b(_0x416119);
    console["log"]("response", _0x3310a0);
  } catch (_0x4ded9c) {
    console["log"]("error", _0x4ded9c);
  }
}
async function _0x38c509() {
  var _0x39fc2f = await _0x218212();
  console["log"]("orderDetails", _0x39fc2f);
  var _0x408b29 = [
    null,
    null,
    "7999",
    _0x39fc2f["ebayOrderNumber"],
    _0x39fc2f["ebaySku"],
    _0x39fc2f["customer"]["name"],
    _0x39fc2f["customer"]["address"]["line_1"],
    _0x39fc2f["customer"]["address"]["line_2"],
    _0x39fc2f["customer"]["address"]["city"],
    _0x39fc2f["customer"]["address"]["state"],
    _0x39fc2f["customer"]["address"]["zip"],
    _0x39fc2f["customer"]["phone"],
    _0x39fc2f["quantitySold"],
    _0x39fc2f["dateOfSale"],
    _0x39fc2f["itemName"],
    _0x39fc2f["soldPrice"],
    _0x39fc2f["ebayFees"],
    _0x39fc2f["addFee"],
  ];
  console["log"]("rowValues", _0x408b29);
  var _0x490906 = await new Promise((_0x32da15) => {
    chrome["runtime"]["sendMessage"](
      { type: "createSheetRow", rowValues: _0x408b29 },
      function (_0x139295) {
        (console["log"](_0x139295), _0x32da15(_0x139295));
      },
    );
  });
  console["log"]("response", _0x490906);
  if (_0x490906 && "success" == _0x490906["result"]) {
    var _0x5805da = _0x490906["rowNumber"],
      _0xc222de = document["createElement"]("div");
    ((_0xc222de["id"] = "googleSheetRowNumber"),
      (_0xc222de["value"] = _0x5805da),
      (_0xc222de["innerHTML"] = "Row\x20Number:\x20" + _0x5805da),
      (_0xc222de["style"]["color"] = "green"),
      (_0xc222de["style"]["fontWeight"] = "bold"),
      _0x156bb4()["appendChild"](_0xc222de));
  }
  return _0x490906;
}
async function _0x49037e() {
  document["querySelectorAll"](".actions\x20a")["forEach"]((_0x1f4a91) => {
    _0x1f4a91["setAttribute"]("target", "_blank");
  });
}
function _0x29ef48() {
  var _0x2750dc = document["createElement"]("button");
  return (
    (_0x2750dc["innerHTML"] = "Import\x20Fulfillment\x20Details"),
    (_0x2750dc["className"] = "importButton"),
    (_0x2750dc["onclick"] = async function () {
      _0xfbaeac();
    }),
    _0x2750dc
  );
}
async function _0xfbaeac(_0x56e8b2 = !0x1, _0x27648c) {
  try {
    if (_0x56e8b2) {
      var _0x1b3e66 = await fetch(
        "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/virtualClipboard/" +
          _0x27648c,
      );
      ((_0x1b3e66 = await _0x1b3e66["json"]()),
        console["log"]("response", _0x1b3e66),
        console["log"](_0x1b3e66["data"]["content"]),
        (fullfilmentData = JSON["parse"](_0x1b3e66["data"]["content"])),
        console["log"]("fullfilmentData", fullfilmentData));
    } else {
      const _0x47a298 = await navigator["clipboard"]["readText"]();
      fullfilmentData = JSON["parse"](_0x47a298);
    }
    await _0x3189f4(fullfilmentData);
  } catch (_0xe24c6) {
    console["error"]("Error\x20importing\x20fulfillment\x20details:", _0xe24c6);
    throw _0xe24c6;
  }
}
async function _0x3189f4(_0x236240) {
  const _0x435537 =
      "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22fulfillmentDetails\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h2>Fulfillment\x20Details</h2>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Customer\x20Address:</strong>\x20<span\x20id=\x22customerAddress\x22>" +
      _0x236240["customerAddress"]["replace"](/\n/g, "<br>") +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Order\x20Number:</strong>\x20<span\x20id=\x22amazonOrderNumber\x22>" +
      _0x236240["amazonOrderNumber"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Total\x20Before\x20Tax:</strong>\x20<span\x20id=\x22totalBeforeTax\x22>" +
      _0x236240["totalBeforeTax"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Total\x20Tax:</strong>\x20<span\x20id=\x22totalTax\x22>" +
      _0x236240["totalTax"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Estimated\x20Delivery\x20Date:</strong>\x20<span\x20id=\x22estimatedDeliveryDate\x22>" +
      _0x236240["estimatedDeliveryDate"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Amazon\x20Email:</strong>\x20<span\x20id=\x22amazonEmail\x22>" +
      _0x236240["amazonEmail"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>fulfillment\x20Date:</strong>\x20<span\x20id=\x22fulfillmentDate\x22>" +
      _0x236240["fulfillmentDate"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Amazon\x20SKU:</strong>\x20<span\x20id=\x22amazonSku\x22>" +
      _0x236240["amazonSku"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Amazon\x20Domain:</strong>\x20<span\x20id=\x22amazonDomain\x22>" +
      _0x236240["amazonDomain"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20",
    _0x2e39c6 = document["createElement"]("div");
  ((_0x2e39c6["innerHTML"] = _0x435537),
    document["querySelector"](".soldPrice")["parentElement"]["parentElement"][
      "appendChild"
    ](_0x2e39c6));
  var _0x4810a8 = await _0x218212();
  _0x14fb32(
    _0x4810a8["customer"]["name"],
    _0x236240["customerAddress"]["split"]("\x0a")[0x0],
    atob(_0x4810a8["ebaySku"]),
    _0x236240["amazonSku"],
  );
  var _0x1ff58b = _0x1f1aaa(
    document["querySelector"]("#estimatedDeliveryDate")["innerText"],
  );
  if (_0x1ff58b)
    (console["log"]("Date\x20found:", _0x1ff58b), _0x306a9b(_0x1ff58b));
  else console["log"]("No\x20date\x20found");
  var _0x4b9eb5 = await _0x1a1041(
    _0x4810a8["orderEarnings"],
    _0x236240["totalBeforeTax"],
    _0x236240["totalTax"],
    _0x236240["amazonDomain"],
  );
  console["log"]("Profit:", _0x4b9eb5);
}
function _0x14fb32(_0x2a461f, _0x296a4d, _0x4a7287, _0xb86aed) {
  (_0x296a4d !== _0x2a461f &&
    alert(
      "WARNING:\x20Customer\x20name\x20does\x20not\x20match!\x20Please\x20verify\x20the\x20fulfillment\x20details.",
    ),
    _0x4a7287 !== _0xb86aed &&
      alert(
        "WARNING:\x20SKU\x20does\x20not\x20match!\x20Please\x20verify\x20the\x20fulfillment\x20details.",
      ));
}
function _0x1f1aaa(_0x2a2fd8) {
  const _0xb1391f = new Date(),
    _0x1fb644 = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
  function _0x1ec2c7(_0x1a7c1e, _0x558351) {
    const _0x353957 = new Date(_0x1a7c1e);
    return (
      _0x353957["setDate"](_0x353957["getDate"]() + _0x558351),
      _0x353957
    );
  }
  function _0x285706(_0x2efa69, _0x2077ad) {
    let [_0xa20584, _0x98abb0] = _0x2077ad["split"]("\x20"),
      [_0x3c146e, _0x416d52] = _0xa20584["split"](":");
    return (
      "PM" === _0x98abb0 &&
        _0x3c146e < 0xc &&
        (_0x3c146e = parseInt(_0x3c146e) + 0xc),
      _0x2efa69["setHours"](_0x3c146e, _0x416d52 || 0x0, 0x0, 0x0),
      _0x2efa69
    );
  }
  const _0x5e4da3 = [
    { regex: /Delivered today/, date: new Date(_0xb1391f) },
    { regex: /Arriving today/, date: new Date(_0xb1391f) },
    { regex: /Arriving tomorrow/, date: _0x1ec2c7(new Date(_0xb1391f), 0x1) },
    {
      regex: /Delivered (\w+ \d+)/,
      dateFunction: (_0x142b1b) =>
        new Date(_0x142b1b[0x1] + ",\x20" + _0xb1391f["getFullYear"]()),
    },
    {
      regex: /Arriving (\w+)$/,
      dateFunction: (_0x3bc572) =>
        (function (_0x213b3f, _0x1bd044) {
          const _0x59a8ce = _0x1fb644["indexOf"](_0x1bd044),
            _0x43c12f = new Date(_0x213b3f);
          return (
            _0x43c12f["setDate"](
              _0x43c12f["getDate"]() +
                ((0x7 + _0x59a8ce - _0x213b3f["getDay"]()) % 0x7),
            ),
            _0x43c12f
          );
        })(_0xb1391f, _0x3bc572[0x1]),
    },
    {
      regex: /Now expected by (\w+ \d+)/,
      dateFunction: (_0x5d2428) =>
        new Date(_0x5d2428[0x1] + ",\x20" + _0xb1391f["getFullYear"]()),
    },
    {
      regex: /Arriving tomorrow by (\d+ [AP]M)/,
      dateFunction: (_0x165514) =>
        _0x285706(_0x1ec2c7(new Date(_0xb1391f), 0x1), _0x165514[0x1]),
    },
    {
      regex: /Arriving today by (\d+ [AP]M)/,
      dateFunction: (_0x4111ae) =>
        _0x285706(new Date(_0xb1391f), _0x4111ae[0x1]),
    },
    {
      regex: /Arriving by (\w+ \d+)/,
      dateFunction: (_0x13e1bd) =>
        new Date(_0x13e1bd[0x1] + ",\x20" + _0xb1391f["getFullYear"]()),
    },
    {
      regex: /Delivered (\w+ \d+),/,
      dateFunction: (_0x2ec01f) =>
        new Date(_0x2ec01f[0x1] + ",\x20" + _0xb1391f["getFullYear"]()),
    },
    {
      regex: /Expected by (\w+ \d+)/,
      dateFunction: (_0x4bd92f) =>
        new Date(_0x4bd92f[0x1] + ",\x20" + _0xb1391f["getFullYear"]()),
    },
    {
      regex: /Arriving (\w+, \d+ \w+)/,
      dateFunction: (_0xb03ef9) =>
        (function (_0x5d01a6) {
          const [_0x409ce3, _0x5c88f9] = _0x5d01a6["split"](",\x20"),
            [_0xd0c19, _0x656e5b] = _0x5c88f9["split"]("\x20"),
            _0x52cb12 = [
              "Jan",
              "Feb",
              "Mar",
              "Apr",
              "May",
              "Jun",
              "Jul",
              "Aug",
              "Sep",
              "Oct",
              "Nov",
              "Dec",
            ]["indexOf"](_0x656e5b);
          if (-0x1 === _0x52cb12) return null;
          const _0x2faa55 =
            _0xb1391f["getMonth"]() > _0x52cb12
              ? _0xb1391f["getFullYear"]() + 0x1
              : _0xb1391f["getFullYear"]();
          return new Date(_0x2faa55, _0x52cb12, _0xd0c19);
        })(_0xb03ef9[0x1]),
    },
  ];
  for (let _0x5119f2 of _0x5e4da3) {
    const {
        regex: _0x21c621,
        date: _0x3f1f12,
        dateFunction: _0x37de6c,
      } = _0x5119f2,
      _0xec4f10 = _0x2a2fd8["match"](_0x21c621);
    if (_0xec4f10) return _0x37de6c ? _0x37de6c(_0xec4f10) : _0x3f1f12;
  }
  return null;
}
function _0x306a9b(_0x1bc040) {
  if (_0x1bc040 instanceof Date && !isNaN(_0x1bc040)) {
    var _0x8c71a6 = [
      _0x1bc040["getFullYear"](),
      ("0" + (_0x1bc040["getMonth"]() + 0x1))["slice"](-0x2),
      ("0" + _0x1bc040["getDate"]())["slice"](-0x2),
    ]["join"]("-");
    console["log"]("updateEta:\x20Formatted\x20date", _0x8c71a6);
    var _0x53e1d6 = document["querySelector"](".amazon-eta-field");
    if (_0x53e1d6) {
      if (_0x53e1d6["disabled"] || _0x53e1d6["readOnly"])
        console["error"](
          "updateEta:\x20.amazon-eta-field\x20is\x20disabled\x20or\x20read-only",
        );
      else
        ((_0x53e1d6["value"] = _0x8c71a6),
          console["log"]("updateEta:\x20ETA\x20updated\x20successfully"));
    } else
      console["error"](
        "updateEta:\x20.amazon-eta-field\x20element\x20not\x20found",
      );
  } else
    console["error"]("updateEta:\x20Invalid\x20date\x20provided", _0x1bc040);
}
const _0x2f8a92 = {
  CAD_TO_USD: 0x1 / 1.3507,
  USD_TO_CAD: 1.3507,
  GBP_TO_USD: 0x1 / 0.789173,
  USD_TO_GBP: 0.789173,
  AUD_TO_USD: 0x1 / 1.64866,
  USD_TO_AUD: 1.64866,
  EUR_TO_USD: 0x1 / 1.0821,
  USD_TO_EUR: 1.0821,
};
function _0x32b319(_0x11f1a3) {
  let _0x587730 = _0x11f1a3["match"](/(C \$|\$|£|A \$|€)/);
  return {
    currencySymbol: _0x587730 ? _0x587730[0x0] : null,
    amount: parseFloat(_0x11f1a3["replace"](/[^\d.-]/g, "")),
  };
}
function _0xa87607(_0x2ff9f8) {
  switch (_0x2ff9f8) {
    case "www.amazon.ca":
      return "CAD";
    case "www.amazon.com":
      return "USD";
    case "www.amazon.co.uk":
      return "GBP";
    case "www.amazon.com.au":
      return "AUD";
    case "www.amazon.de":
      return "EUR";
    default:
      return "UNKNOWN";
  }
}
function _0x12ee55(_0x3041ee) {
  return parseFloat(_0x3041ee["replace"](/[^\d.-]/g, ""));
}
async function _0x1a1041(_0x1fea52, _0x23d294, _0x825c3c, _0x17f593) {
  console["log"]("Raw\x20Order\x20Earnings:", _0x1fea52);
  var { currencySymbol: _0x3ab838, amount: _0x240491 } = _0x32b319(_0x1fea52);
  (console["log"]("Currency\x20Symbol:", _0x3ab838),
    console["log"]("Order\x20Earnings:", _0x240491),
    console["log"]("Total\x20Before\x20Tax:", _0x23d294),
    console["log"]("Total\x20Tax:", _0x825c3c),
    console["log"]("Amazon\x20Domain:", _0x17f593));
  var _0x21d81f = _0xa87607(_0x17f593);
  console["log"]("Domain\x20Currency:", _0x21d81f);
  if ("UNKNOWN" === _0x21d81f)
    return (
      console["error"]("Unsupported\x20Amazon\x20domain"),
      "Unsupported\x20domain"
    );
  var _0x34626a =
    (_0x23d294 = _0x12ee55(_0x23d294)) + (_0x825c3c = _0x12ee55(_0x825c3c));
  console["log"]("Total\x20Cost:", _0x34626a);
  var _0x33271c = _0x34626a;
  let _0x4433ca =
    { "C\x20$": "CAD", $: "USD", "£": "GBP", "A\x20$": "AUD", "€": "EUR" }[
      _0x3ab838
    ] || "USD";
  console["log"]("Earnings\x20Currency:", _0x4433ca);
  if (_0x4433ca !== _0x21d81f) {
    let _0x477584 = _0x21d81f + "_TO_" + _0x4433ca,
      _0x48cb74 = _0x2f8a92[_0x477584] || 0x1;
    ((_0x33271c = _0x34626a * _0x48cb74),
      console["log"]("Conversion\x20Key:", _0x477584),
      console["log"]("Conversion\x20Rate:", _0x48cb74),
      console["log"]("Converted\x20Cost:", _0x33271c));
  }
  let _0x1fd4be = _0x240491 - _0x33271c;
  console["log"]("Profit:", _0x1fd4be);
  let _0x1bce68 = "" + _0x3ab838 + _0x1fd4be["toFixed"](0x2);
  return (console["log"]("Formatted\x20Profit:", _0x1bce68), _0x1bce68);
}
async function _0x22aa43() {
  var _0x13fb12 = document["querySelector"](
    ".vod-dialog\x20\x20button.lightbox-dialog__close",
  );
  _0x13fb12 && _0x13fb12["click"]();
}
async function _0x1a7c9c(_0x1e9170) {
  var _0x195b75 = document["querySelector"](".edit-note");
  console["log"]("editNoteElement", _0x195b75);
  if (_0x195b75) _0x195b75["click"]();
  else {
    var _0x4f508d = document["querySelector"](
      "[data-action-id=\x22ADD_NOTE\x22]",
    );
    (console["log"]("addNote", _0x4f508d), _0x4f508d["click"]());
  }
  var _0x5b61fb = await waitForElementVanillaJs(
    "textarea[name=\x22note-content\x22]",
  );
  ((_0x5b61fb["value"] = _0x1e9170),
    _0x5b61fb["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    _0x5b61fb["dispatchEvent"](new Event("change", { bubbles: !0x0 })),
    await new Promise((_0x309e50) => setTimeout(_0x309e50, 0x3e8)));
  var _0x45c901 = _0x5b61fb["closest"](".lightbox-dialog__window")[
    "querySelector"
  ](".btn.btn--primary");
  (console["log"]("saveButton", _0x45c901),
    _0x45c901["dispatchEvent"](new MouseEvent("click", { bubbles: !0x0 })),
    await new Promise((_0x5d9b51) => setTimeout(_0x5d9b51, 0x3e8)),
    await _0x22aa43());
}
function _0x1af051() {
  var _0x331b0f = document["createElement"]("button");
  return (
    (_0x331b0f["innerText"] = "Add\x20Note"),
    _0x331b0f["classList"]["add"]("add-note-button"),
    _0x331b0f["addEventListener"]("click", async function () {
      await createAndAppendNote();
    }),
    _0x331b0f
  );
}
async function _0x59009f() {
  var _0x359020 = _0x48f9c6(),
    _0x38ca93 = await _0x382873(),
    _0x5a3877 = _0x359020 ? _0x359020 + "\x0a" + _0x38ca93 : _0x38ca93;
  await _0x1a7c9c(_0x5a3877);
}
function _0x48f9c6() {
  var _0x28d0aa = document["querySelector"](".note-content");
  return _0x28d0aa ? _0x28d0aa["innerText"] : null;
}
async function _0x382873() {
  var _0x235e22 = document["querySelector"]("#amazonEmail")["innerText"],
    _0x4d2cf0 = document["querySelector"]("#estimatedDeliveryDate")[
      "innerText"
    ],
    _0x30f932 = document["querySelector"]("#fulfillmentDate")["innerText"],
    { agentName: _0x131507 } =
      await chrome["storage"]["local"]["get"]("agentName");
  return (
    "SS/" + _0x235e22 + "/" + _0x4d2cf0 + "/" + _0x30f932 + "-" + _0x131507
  );
}
const _0x18ee3c = (() => {
  let _0xa8653c = null,
    _0x1e0996 = null,
    _0x3f7506 = null;
  function _0x19847f() {
    return (
      !_0xa8653c &&
        ((_0xa8653c = document["createElement"]("div")),
        (_0xa8653c["className"] = "sniper-help-popover-portal"),
        _0xa8653c["setAttribute"]("hidden", ""),
        document["body"]["appendChild"](_0xa8653c),
        _0xa8653c["addEventListener"]("mouseenter", () => {
          _0x3f7506 && (clearTimeout(_0x3f7506), (_0x3f7506 = null));
        }),
        _0xa8653c["addEventListener"]("mouseleave", () => _0x438d6(0x78)),
        _0xa8653c["addEventListener"]("click", (_0x3294a5) =>
          _0x3294a5["stopPropagation"](),
        )),
      _0xa8653c
    );
  }
  function _0x1e158a(_0x2575fc) {
    const _0x37c580 = _0x19847f(),
      _0x451c3c = _0x2575fc["getBoundingClientRect"](),
      _0xd9374f = window["innerWidth"],
      _0x565fec = window["innerHeight"];
    ((_0x37c580["style"]["visibility"] = "hidden"),
      _0x37c580["removeAttribute"]("hidden"));
    const _0x1d8980 = _0x37c580["offsetWidth"],
      _0x2051af = _0x37c580["offsetHeight"];
    let _0x1fd6c7 = Math["min"](
        Math["max"](_0x451c3c["left"], 0x8),
        _0xd9374f - _0x1d8980 - 0x8,
      ),
      _0x440261 = _0x451c3c["bottom"] + 0x8;
    (_0x440261 + _0x2051af > _0x565fec - 0x8 &&
      (_0x440261 = Math["max"](_0x451c3c["top"] - 0x8 - _0x2051af, 0x8)),
      _0x1fd6c7 + _0x1d8980 > _0xd9374f - 0x8 &&
        (_0x1fd6c7 = _0xd9374f - _0x1d8980 - 0x8),
      _0x1fd6c7 < 0x8 && (_0x1fd6c7 = 0x8),
      (_0x37c580["style"]["left"] = _0x1fd6c7 + "px"),
      (_0x37c580["style"]["top"] = _0x440261 + "px"),
      (_0x37c580["style"]["visibility"] = "visible"));
  }
  function _0x1a7222(_0x34359e, _0x2a3394) {
    (_0x3f7506 && (clearTimeout(_0x3f7506), (_0x3f7506 = null)),
      (_0x19847f()["textContent"] = String(_0x2a3394 || "")),
      (_0x1e0996 = _0x34359e),
      _0x1e158a(_0x34359e),
      document["addEventListener"]("click", _0x88591d, !0x0),
      document["addEventListener"]("keydown", _0x512e3c, !0x0),
      window["addEventListener"]("scroll", _0x7ceadf, !0x0),
      window["addEventListener"]("resize", _0x7ceadf));
  }
  function _0xb812cc() {
    (_0x19847f()["setAttribute"]("hidden", ""),
      (_0x1e0996 = null),
      document["removeEventListener"]("click", _0x88591d, !0x0),
      document["removeEventListener"]("keydown", _0x512e3c, !0x0),
      window["removeEventListener"]("scroll", _0x7ceadf, !0x0),
      window["removeEventListener"]("resize", _0x7ceadf));
  }
  function _0x4801b4(_0x57c083, _0x5a92bb) {
    _0x1e0996 === _0x57c083 ? _0xb812cc() : _0x1a7222(_0x57c083, _0x5a92bb);
  }
  function _0x438d6(_0x24845e) {
    _0x3f7506 = setTimeout(_0xb812cc, _0x24845e);
  }
  function _0x88591d(_0xf62ea6) {
    const _0x13dd34 = _0x19847f();
    _0x1e0996 &&
      (_0x1e0996["contains"](_0xf62ea6["target"]) ||
        _0x13dd34["contains"](_0xf62ea6["target"]) ||
        _0xb812cc());
  }
  function _0x512e3c(_0x3a8c17) {
    "Escape" === _0x3a8c17["key"] && _0xb812cc();
  }
  function _0x7ceadf() {
    _0x1e0996 && _0x1e158a(_0x1e0996);
  }
  return {
    makeIcon(_0xfb8005) {
      const _0xd83f8a = document["createElement"]("span");
      return (
        (_0xd83f8a["className"] = "sniper-help-icon"),
        (_0xd83f8a["tabIndex"] = 0x0),
        _0xd83f8a["setAttribute"]("role", "button"),
        _0xd83f8a["setAttribute"]("aria-label", "More\x20info"),
        (_0xd83f8a["textContent"] = "i"),
        _0xd83f8a["addEventListener"]("click", (_0x19481a) => {
          (_0x19481a["stopPropagation"](), _0x4801b4(_0xd83f8a, _0xfb8005));
        }),
        _0xd83f8a["addEventListener"]("mouseenter", () =>
          _0x1a7222(_0xd83f8a, _0xfb8005),
        ),
        _0xd83f8a["addEventListener"]("mouseleave", () => _0x438d6(0x78)),
        _0xd83f8a["addEventListener"]("keydown", (_0x328600) => {
          ("Enter" === _0x328600["key"] || "\x20" === _0x328600["key"]) &&
            (_0x328600["preventDefault"](), _0x4801b4(_0xd83f8a, _0xfb8005));
        }),
        _0xd83f8a
      );
    },
  };
})();
async function _0x350e1c() {
  var _0x35e9a6 = [
    {
      key: "shouldGetLinkInstead",
      type: "checkbox",
      label: "Copy\x20Auto\x20Link\x20instead\x20of\x20Auto\x20Order",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
      help: "Copies\x20a\x20special\x20Amazon\x20checkout\x20link\x20with\x20your\x20order\x20details\x20so\x20you\x20can\x20place\x20the\x20order\x20from\x20another\x20Chrome\x20profile/device.\x20That\x20other\x20browser\x20must\x20have\x20EcomSniper\x20installed.\x20Tip:\x20set\x20the\x20Amazon\x20email\x20in\x20that\x20profile’s\x20Options\x20→\x20Order\x20Settings\x20so\x20EcomSniper\x20can\x20attribute/track\x20the\x20order\x20to\x20the\x20right\x20Amazon\x20account.\x20No\x20auto\x20order\x20happens\x20in\x20this\x20browser.",
    },
    {
      key: "shouldUseGiftOption",
      type: "checkbox",
      label: "Checkout\x20as\x20Gift",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Uses\x20Amazon’s\x20gift\x20checkout\x20option.\x20This\x20hides\x20the\x20item\x20price\x20and\x20lets\x20you\x20include\x20your\x20own\x20Gift\x20Message.",
    },
    {
      key: "giftMessage",
      type: "textarea",
      label: "Gift\x20Message",
      defaultValue: "-",
      includeInOrderDetails: !0x0,
      help: "Text\x20shown\x20on\x20Amazon’s\x20gift\x20slip\x20when\x20you\x20use\x20‘Checkout\x20as\x20Gift’.",
    },
    {
      key: "giftMessageSender",
      type: "text",
      label: "Gift\x20Message\x20Sender",
      defaultValue: "-",
      includeInOrderDetails: !0x0,
      help: "Name\x20shown\x20as\x20the\x20sender\x20on\x20the\x20gift\x20slip.",
    },
    {
      key: "autoConfirmPurchase",
      type: "checkbox",
      label: "Place\x20order\x20automatically\x20(skip\x20final\x20click)",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Automatically\x20places\x20the\x20order\x20on\x20Amazon’s\x20final\x20review\x20page,\x20skipping\x20the\x20last\x20manual\x20click.\x20Make\x20sure\x20your\x20payment\x20details\x20are\x20correct\x20in\x20Amazon\x20beforehand.",
    },
    {
      key: "sendToSpreadsheet",
      type: "checkbox",
      label: "Auto\x20Bookkeeping\x20(Spreadsheet)",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Automatically\x20logs\x20each\x20order\x20into\x20your\x20connected\x20EcomSniper\x20bookkeeping\x20spreadsheet.\x20Saves\x20all\x20sales,\x20fees,\x20costs,\x20and\x20profit\x20data\x20—\x20no\x20more\x20manual\x20entry.",
    },
    {
      key: "shouldSendETAWithAI",
      type: "checkbox",
      label: "Send\x20ETA\x20message\x20(AI)",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
      help: "Generates\x20a\x20short,\x20friendly\x20delivery\x20update\x20and\x20sends\x20it\x20to\x20the\x20buyer\x20on\x20eBay.\x20Language\x20is\x20inferred\x20from\x20the\x20site/country.\x20You\x20can\x20customize\x20the\x20tone/prompt\x20in\x20Options\x20→\x20Order\x20Settings.",
    },
    {
      key: "shouldMarkAsShipped",
      type: "checkbox",
      label: "Mark\x20eBay\x20order\x20as\x20shipped\x20automatically",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
    },
    {
      key: "shouldIncreaseQuantity",
      type: "checkbox",
      label: "Increase\x20quantity\x20of\x20eBay\x20order\x20automatically",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
    },
    {
      key: "shouldWriteNote",
      type: "checkbox",
      label: "Write\x20note\x20on\x20eBay\x20order",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
      help: "Adds\x20a\x20note\x20to\x20the\x20eBay\x20order\x20(e.g.,\x20Amazon\x20email,\x20ETA,\x20date,\x20your\x20agent\x20name).\x20You\x20can\x20switch\x20to\x20a\x20custom\x20template\x20in\x20Options\x20→\x20Custom\x20Note\x20Template;\x20tokens\x20like\x20{{amazonEmail}},\x20{{eta}},\x20{{date}},\x20{{agent}}\x20are\x20supported.",
    },
    {
      key: "autoCloseAmazonTabAfterOrder",
      type: "checkbox",
      label: "Auto-close\x20Amazon\x20tab\x20after\x20order",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Closes\x20the\x20Amazon\x20tab\x20a\x20few\x20seconds\x20after\x20the\x20order\x20completes—useful\x20for\x20multi-tasking\x20or\x20if\x20you\x20place\x20many\x20orders\x20at\x20once.",
    },
    {
      key: "agentName",
      type: "text",
      label: "Your\x20Name\x20(for\x20notes)",
      defaultValue: "Agent",
      includeInOrderDetails: !0x1,
      help: "Used\x20in\x20eBay\x20order\x20notes\x20(e.g.,\x20“–\x20Aug\x2029,\x202025\x20Sammy”).\x20Useful\x20if\x20you\x20have\x20VAs\x20or\x20team\x20members\x20placing\x20orders.",
    },
  ];
  function _0xd60870() {
    var _0x3d6e12 = {};
    for (var _0x31f792 = 0x0; _0x31f792 < _0x35e9a6["length"]; _0x31f792++) {
      var _0x32289d = _0x35e9a6[_0x31f792];
      _0x3d6e12[_0x32289d["key"]] = _0x32289d["defaultValue"];
    }
    return _0x3d6e12;
  }
  var _0xcab93a = {
      currentValues: _0xd60870(),
      loadFromChromeStorage: async function () {
        var _0x4e51e8 = _0xd60870(),
          _0x25d0de = await chrome["storage"]["local"]["get"](_0x4e51e8);
        for (var _0x19dd59 in _0x4e51e8)
          Object["prototype"]["hasOwnProperty"]["call"](_0x25d0de, _0x19dd59) &&
            (this["currentValues"][_0x19dd59] = _0x25d0de[_0x19dd59]);
        return (_0x5e4575(), this["getSnapshot"]());
      },
      saveSingleSettingToChromeStorage: async function (_0x49f0ed, _0x44e597) {
        this["currentValues"][_0x49f0ed] = _0x44e597;
        var _0x580b9f = {};
        ((_0x580b9f[_0x49f0ed] = _0x44e597),
          await chrome["storage"]["local"]["set"](_0x580b9f),
          _0x5e4575());
      },
      getSnapshot: function () {
        return JSON["parse"](JSON["stringify"](this["currentValues"]));
      },
    },
    _0x38e86f = [];
  function _0x5e4575() {
    var _0x45430f = _0xcab93a["getSnapshot"]();
    _0x38e86f["forEach"](function (_0x11f299) {
      try {
        _0x11f299(_0x45430f);
      } catch (_0x53c5f8) {}
    });
  }
  function _0xffdc60(_0x2023b9, _0x542659) {
    for (var _0x30d633 = 0x0; _0x30d633 < _0x35e9a6["length"]; _0x30d633++) {
      var _0x3e5fae = _0x35e9a6[_0x30d633];
      if (_0x3e5fae["includeInOrderDetails"]) {
        var _0x3d4dfc = _0x3e5fae["key"];
        _0x2023b9[_0x3e5fae["orderDetailsKey"] || _0x3e5fae["key"]] =
          _0x542659[_0x3d4dfc];
      }
    }
    return _0x2023b9;
  }
  await _0xcab93a["loadFromChromeStorage"]();
  var _0x3d91d0 = document["createElement"]("div");
  _0x3d91d0["className"] = "auto-order-container";
  var _0x5c09b7 = (function (_0x9bf2db) {
      var _0x50d62c = document["createElement"]("button");
      return (
        (_0x50d62c["className"] = "auto-order-button"),
        (_0x50d62c["id"] = "autoOrderButton"),
        (_0x50d62c["textContent"] = _0x9bf2db["shouldGetLinkInstead"]
          ? "Copy\x20Auto\x20Link"
          : "Auto\x20Order"),
        _0x38e86f["push"](function (_0x53d1ce) {
          _0x50d62c["textContent"] = _0x53d1ce["shouldGetLinkInstead"]
            ? "Copy\x20Auto\x20Link"
            : "Auto\x20Order";
        }),
        _0x50d62c["addEventListener"]("click", async function (_0x25ba0f) {
          (_0x25ba0f["preventDefault"](), (_0x50d62c["disabled"] = !0x0));
          try {
            var _0xea28b2 = _0xcab93a["getSnapshot"]();
            if (_0xea28b2["shouldGetLinkInstead"]) {
              var _0x456525 = await _0x521c36();
              if (!_0x456525) {
                alert(
                  "SKU\x20not\x20found.\x20Please\x20enter\x20the\x20SKU\x20manually.",
                );
                return;
              }
              var _0x2c458e = await _0x52edf8(_0x456525),
                _0x340c31 = await _0x218212();
              (_0xffdc60(_0x340c31, _0xea28b2),
                (_0x2c458e =
                  _0x2c458e +
                  "?autoOrder=true&orderDetails=" +
                  encodeURIComponent(JSON["stringify"](_0x340c31))),
                await navigator["clipboard"]["writeText"](_0x2c458e),
                _0x50d62c["classList"]["add"](
                  "amazon-copy-link-button-clicked",
                ),
                setTimeout(function () {
                  _0x50d62c["classList"]["remove"](
                    "amazon-copy-link-button-clicked",
                  );
                }, 0x4b0),
                _0xea28b2["sendToSpreadsheet"] && (await _0x301211(_0x340c31)),
                _0x50d62c["dispatchEvent"](
                  new CustomEvent("order:done", {
                    detail: {
                      ok: !0x0,
                      profit: document["querySelector"](
                        ".profit-final\x20.value-visible",
                      )?.["innerText"],
                    },
                  }),
                ));
            } else {
              var _0x1602c2 = await _0x218212();
              (_0xffdc60(_0x1602c2, _0xea28b2),
                await _0x1741b3(_0x1602c2),
                _0xea28b2["sendToSpreadsheet"] && (await _0x301211(_0x1602c2)),
                _0x50d62c["dispatchEvent"](
                  new CustomEvent("order:done", {
                    detail: {
                      ok: !0x0,
                      profit: document["querySelector"](
                        ".profit-final\x20.value-visible",
                      )?.["innerText"],
                    },
                  }),
                ));
            }
          } catch (_0x4caa1e) {
            (console["error"]("Auto\x20order\x20action\x20error:", _0x4caa1e),
              _0x50d62c["dispatchEvent"](
                new CustomEvent("order:done", { detail: { ok: !0x1 } }),
              ));
          } finally {
            _0x50d62c["disabled"] = !0x1;
          }
        }),
        _0x50d62c
      );
    })(_0xcab93a["getSnapshot"]()),
    _0x5297dd = (function () {
      var _0x474def = document["createElement"]("div");
      ((_0x474def["className"] = "settings-modal"),
        _0x474def["setAttribute"]("hidden", ""));
      var _0x28f81e = document["createElement"]("div");
      _0x28f81e["className"] = "settings-modal-content";
      var _0x4d2f33 = document["createElement"]("span");
      return (
        (_0x4d2f33["className"] = "settings-modal-close"),
        (_0x4d2f33["textContent"] = "×"),
        _0x4d2f33["addEventListener"]("click", function () {
          _0x474def["setAttribute"]("hidden", "");
        }),
        _0x28f81e["appendChild"](_0x4d2f33),
        _0x474def["appendChild"](_0x28f81e),
        _0x474def["addEventListener"]("click", function (_0x38af70) {
          _0x38af70["target"] === _0x474def &&
            _0x474def["setAttribute"]("hidden", "");
        }),
        { overlay: _0x474def, content: _0x28f81e }
      );
    })(),
    _0x8829c6 = (function () {
      var _0x5a6745 = document["createElement"]("div");
      ((_0x5a6745["style"]["display"] = "grid"),
        (_0x5a6745["style"]["gridTemplateColumns"] = "1fr"),
        (_0x5a6745["style"]["rowGap"] = "10px"));
      for (var _0x6c9775 = 0x0; _0x6c9775 < _0x35e9a6["length"]; _0x6c9775++) {
        var _0x1befaf = _0x35e9a6[_0x6c9775];
        if ("checkbox" === _0x1befaf["type"]) {
          var _0x50320b = document["createElement"]("div");
          ((_0x50320b["style"]["display"] = "flex"),
            (_0x50320b["style"]["alignItems"] = "center"),
            (_0x50320b["style"]["gap"] = "8px"));
          var _0x3d8366 = document["createElement"]("label");
          ((_0x3d8366["style"]["display"] = "inline-flex"),
            (_0x3d8366["style"]["alignItems"] = "center"),
            (_0x3d8366["style"]["gap"] = "8px"),
            (_0x3d8366["style"]["flex"] = "1\x201\x20auto"));
          var _0x4837b9 = document["createElement"]("input");
          ((_0x4837b9["type"] = "checkbox"),
            (_0x4837b9["checked"] =
              !!_0xcab93a["currentValues"][_0x1befaf["key"]]),
            (function (_0x3ec545, _0x43352c) {
              _0x43352c["addEventListener"]("change", async function () {
                await _0xcab93a["saveSingleSettingToChromeStorage"](
                  _0x3ec545,
                  _0x43352c["checked"],
                );
              });
            })(_0x1befaf["key"], _0x4837b9));
          var _0x4999fd = document["createElement"]("span");
          ((_0x4999fd["textContent"] = _0x1befaf["label"]),
            _0x3d8366["appendChild"](_0x4837b9),
            _0x3d8366["appendChild"](_0x4999fd));
          if (_0x1befaf["help"]) {
            const _0x1f1c76 = _0x18ee3c["makeIcon"](_0x1befaf["help"]);
            ((_0x1f1c76["style"]["marginLeft"] = "2px"),
              _0x50320b["appendChild"](_0x3d8366),
              _0x50320b["appendChild"](_0x1f1c76));
          } else _0x50320b["appendChild"](_0x3d8366);
          _0x5a6745["appendChild"](_0x50320b);
        } else {
          if ("text" === _0x1befaf["type"]) {
            (((_0x301faa = document["createElement"]("div"))["style"][
              "display"
            ] = "grid"),
              (_0x301faa["style"]["rowGap"] = "6px"),
              ((_0x3c8597 = document["createElement"]("div"))["style"][
                "display"
              ] = "flex"),
              (_0x3c8597["style"]["alignItems"] = "center"),
              (_0x3c8597["style"]["gap"] = "6px"));
            var _0x4ef624 = document["createElement"]("div");
            ((_0x4ef624["textContent"] = _0x1befaf["label"]),
              (_0x4ef624["style"]["fontWeight"] = "600"),
              _0x3c8597["appendChild"](_0x4ef624));
            if (_0x1befaf["help"]) {
              const _0x1af87e = _0x18ee3c["makeIcon"](_0x1befaf["help"]);
              _0x3c8597["appendChild"](_0x1af87e);
            }
            var _0x5d5a71 = document["createElement"]("input");
            ((_0x5d5a71["type"] = "text"),
              (_0x5d5a71["value"] =
                _0xcab93a["currentValues"][_0x1befaf["key"]] || ""),
              _0x1befaf["placeholder"] &&
                (_0x5d5a71["placeholder"] = _0x1befaf["placeholder"]),
              (_0x5d5a71["style"]["width"] = "100%"),
              (function (_0x50fec9, _0x124be1) {
                _0x124be1["addEventListener"]("input", async function () {
                  await _0xcab93a["saveSingleSettingToChromeStorage"](
                    _0x50fec9,
                    _0x124be1["value"],
                  );
                });
              })(_0x1befaf["key"], _0x5d5a71),
              _0x301faa["appendChild"](_0x3c8597),
              _0x301faa["appendChild"](_0x5d5a71),
              _0x5a6745["appendChild"](_0x301faa));
          } else {
            if ("textarea" === _0x1befaf["type"]) {
              var _0x301faa;
              (((_0x301faa = document["createElement"]("div"))["style"][
                "display"
              ] = "grid"),
                (_0x301faa["style"]["rowGap"] = "6px"));
              var _0x3c8597;
              (((_0x3c8597 = document["createElement"]("div"))["style"][
                "display"
              ] = "flex"),
                (_0x3c8597["style"]["alignItems"] = "center"),
                (_0x3c8597["style"]["gap"] = "6px"));
              var _0x1fd61a = document["createElement"]("div");
              ((_0x1fd61a["textContent"] = _0x1befaf["label"]),
                (_0x1fd61a["style"]["fontWeight"] = "600"),
                _0x3c8597["appendChild"](_0x1fd61a));
              if (_0x1befaf["help"]) {
                const _0x1103ca = _0x18ee3c["makeIcon"](_0x1befaf["help"]);
                _0x3c8597["appendChild"](_0x1103ca);
              }
              var _0x3f7d73 = document["createElement"]("textarea");
              ((_0x3f7d73["rows"] = _0x1befaf["rows"] || 0x3),
                (_0x3f7d73["value"] =
                  _0xcab93a["currentValues"][_0x1befaf["key"]] || ""),
                _0x1befaf["placeholder"] &&
                  (_0x3f7d73["placeholder"] = _0x1befaf["placeholder"]),
                (_0x3f7d73["style"]["width"] = "100%"),
                (function (_0x459767, _0x770db6) {
                  _0x770db6["addEventListener"]("input", async function () {
                    await _0xcab93a["saveSingleSettingToChromeStorage"](
                      _0x459767,
                      _0x770db6["value"],
                    );
                  });
                })(_0x1befaf["key"], _0x3f7d73),
                _0x301faa["appendChild"](_0x3c8597),
                _0x301faa["appendChild"](_0x3f7d73),
                _0x5a6745["appendChild"](_0x301faa));
            }
          }
        }
      }
      return _0x5a6745;
    })();
  return (
    _0x5297dd["content"]["appendChild"](_0x8829c6),
    _0x3d91d0["appendChild"](_0x5c09b7),
    _0x3d91d0["appendChild"](
      (function (_0x12b2d9) {
        var _0x254ae1 = document["createElement"]("span");
        return (
          (_0x254ae1["className"] = "settings-icon"),
          (_0x254ae1["textContent"] = "⚙"),
          (_0x254ae1["title"] = "Auto\x20Order\x20Settings"),
          _0x254ae1["addEventListener"]("click", function (_0x159968) {
            (_0x159968["preventDefault"](),
              _0x12b2d9["removeAttribute"]("hidden"));
          }),
          _0x254ae1
        );
      })(_0x5297dd["overlay"]),
    ),
    _0x3d91d0["appendChild"](_0x5297dd["overlay"]),
    _0x3d91d0
  );
}
async function _0x1741b3(_0x11c30b) {
  chrome["runtime"]["sendMessage"]({
    type: "order_item_same_browser",
    orderDetails: _0x11c30b,
  });
}
function _0x2bfa2b() {
  return document["querySelector"](".lineItemCardInfo__itemId")[
    "querySelectorAll"
  ](".sh-secondary")[0x1]["innerText"];
}
async function _0x119815(_0x43d01a) {
  var _0x5c623f = await new Promise((_0x16d30b) => {
    chrome["runtime"]["sendMessage"](
      { type: "get_sku_from_description", itemNumber: _0x43d01a },
      function (_0x410046) {
        _0x16d30b(_0x410046);
      },
    );
  });
  return _0x5c623f?.["sku"];
}
async function _0x2f407f(_0x5e337d, _0xaad53e, _0x1fdc14) {
  const _0x1a7d2c = {
    spreadsheetId: _0x5e337d,
    range: _0xaad53e,
    values: _0x1fdc14,
  };
  try {
    const _0x48ed52 = await fetch(
        "https://script.google.com/macros/s/AKfycbwTOktup4oRvsKGNPtMSwUTNX41Z93HZt_PqFDzzgu0jPysi9Tmmrcs-LPf86z2nc8tnQ/exec",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON["stringify"](_0x1a7d2c),
        },
      ),
      _0x57e874 = await _0x48ed52["json"]();
    console["log"]("Update\x20result:", _0x57e874);
  } catch (_0x857dd3) {
    console["error"]("Error\x20updating\x20sheet:", _0x857dd3);
  }
}
async function _0x5be025() {
  const _0x1e5eed = document["createElement"]("div");
  _0x1e5eed["classList"]["add"]("utility-buttons");
  var _0x5573c9 = await _0x165f90(),
    _0x2e9aa2 = await _0x350e1c();
  if (_0x5573c9) {
    var _0xbd445 = document["createElement"]("div");
    (_0xbd445["classList"]["add"]("automation-div"),
      _0xbd445["appendChild"](_0x5573c9),
      _0xbd445["appendChild"](_0x2e9aa2),
      _0x1e5eed["appendChild"](_0xbd445));
  }
  return (_0x1e5eed["appendChild"](_0x3a6c29()), _0x1e5eed);
}
async function _0x301211(_0x3e1478) {
  (console["log"]("order\x20details", _0x3e1478),
    (_0x349b7a = createButtonTextQueue("autoOrderBtn", 0x4b0, {
      titlePrefix: "Auto\x20Order",
      mount: "body",
      autoShowHud: !0x0,
      fadeOutMs: 0x5dc,
    })),
    (document["title"] = "Auto\x20Order\x20Begins"),
    (document["getElementById"]("autoOrderButton")["disabled"] = !0x0),
    _0x349b7a["update"]("Ordering..."));
  var _0x49dc9d = 0x0,
    _0x317ac4 = !0x1,
    _0x1a5a09;
  for (; !_0x317ac4 && _0x49dc9d < 0x3; ) {
    if (++_0x49dc9d > 0x1) {
      _0x349b7a["update"](
        "Failed\x20to\x20submit\x20order\x20details,\x20retrying\x20(" +
          _0x49dc9d +
          "/3)...",
      );
      var _0x538e2a = _0x45f407(_0x3e1478["domain"]);
      ((_0x3e1478["orderEarningsCurrency"] = _0x538e2a),
        (_0x3e1478["grandTotalCurrency"] = _0x538e2a),
        await new Promise((_0x312f55) => setTimeout(_0x312f55, 0x1388)));
    }
    try {
      ((_0x1a5a09 = await _0x333c7b(_0x3e1478)),
        console["log"]("submissionResponse", _0x1a5a09),
        (_0x317ac4 = !0x0));
    } catch (_0x251596) {
      console["error"]("Error\x20submitting\x20eBay\x20order:", _0x251596);
    }
  }
  (console["log"]("orderDetails:", _0x3e1478),
    console["log"]("Submission\x20response:", _0x1a5a09));
  if (
    "success" === _0x1a5a09?.["code"] ||
    "duplicate" === _0x1a5a09?.["code"] ||
    "updated" === _0x1a5a09?.["code"] ||
    "created" === _0x1a5a09?.["code"]
  ) {
    var _0x48065b;
    try {
      (_0x349b7a["update"](
        "Waiting\x20For\x20Amazon\x20Order\x20To\x20Be\x20Placed...",
      ),
        (_0x48065b = await _0x1596f8(_0x3e1478["ebayOrderNumber"])),
        _0x349b7a["update"]("Order\x20Placed!"));
    } catch (_0x5cbeb4) {
      (console["error"](
        "Error\x20looking\x20up\x20Amazon\x20order:",
        _0x5cbeb4,
      ),
        _0x349b7a["error"](_0x5cbeb4));
      return;
    }
    if (_0x48065b?.["error"]) {
      (_0x349b7a["error"](_0x48065b?.["error"]),
        console["error"](
          "Error\x20looking\x20up\x20Amazon\x20order:",
          _0x48065b["error"],
        ));
      var _0x18c45e = "" + _0x48065b["error"],
        _0x16ab33 = _0x48f9c6();
      (_0x16ab33 && (_0x18c45e = _0x16ab33 + "\x20-\x20" + _0x18c45e),
        await _0x1a7c9c(_0x18c45e));
    } else {
      console["log"]("fullOrderDetails:", _0x48065b);
      var { shouldWriteNote: _0xf1dc78 } = await chrome["storage"]["local"][
        "get"
      ]({ shouldWriteNote: !0x1 });
      if (_0xf1dc78) {
        _0x349b7a["update"]("Creating\x20note...");
        var { useCustomNoteTemplate: _0x19d6de } = await chrome["storage"][
            "local"
          ]["get"]({ useCustomNoteTemplate: !0x1 }),
          _0x1d8497;
        ((_0x1d8497 = _0x19d6de
          ? await _0x49a448(_0x48065b)
          : await _0x5f186e(_0x48065b)),
          await _0x1a7c9c(_0x1d8497));
      }
      var { shouldSendETAWithAI: _0x453157 } = await chrome["storage"]["local"][
        "get"
      ]({ shouldSendETAWithAI: !0x1 });
      if (_0x453157) {
        var _0x5088c9 = _0x1f1aaa(_0x48065b["estimatedDeliveryDate"]);
        if (_0x5088c9)
          (_0x349b7a["update"]("ETA:\x20" + _0x5088c9),
            console["log"]("Date\x20found:", _0x5088c9),
            _0x306a9b(_0x5088c9),
            _0x349b7a["update"]("ETA\x20Updated"));
        else console["log"]("No\x20date\x20found");
        _0x349b7a["update"]("Building\x20ETA\x20message...");
        var { useCustomEtaMessagePrompt: _0x2c4157 } = await chrome["storage"][
            "local"
          ]["get"]({ useCustomEtaMessagePrompt: !0x1 }),
          _0x1f22ae;
        if (
          !(_0x1f22ae = _0x2c4157
            ? await _0x1e4e4d(_0x48065b)
            : await _0x45c710(_0x48065b))["ok"]
        ) {
          console["error"]("ETA\x20error:", _0x1f22ae["error"]);
          return;
        }
        console["log"]("ETA\x20message:", _0x1f22ae["data"]);
        var _0xb531e4 = _0x1f22ae["data"];
        (_0x349b7a["update"]("Sending\x20ETA\x20to\x20eBay\x20buyer..."),
          await _0x1c9f3f(_0xb531e4),
          _0x349b7a["update"]("ETA\x20Sent"));
      }
      var { shouldMarkAsShipped: _0x566659 } = await chrome["storage"]["local"][
        "get"
      ]({ shouldMarkAsShipped: !0x1 });
      _0x566659 &&
        (_0x349b7a["update"]("Marking\x20item\x20as\x20shipped..."),
        (await _0x486268())
          ? (_0x349b7a["update"]("Item\x20marked\x20as\x20shipped"),
            await _0x59fbe1())
          : (_0x349b7a["update"](
              "Failed\x20to\x20mark\x20item\x20as\x20shipped",
            ),
            await new Promise((_0x1d320f) => setTimeout(_0x1d320f, 0xbb8))));
      var _0x165643 = parseFloat(_0x48065b["orderEarnings"]) || 0x0,
        _0x4408a0 = parseFloat(_0x48065b["grandTotal"]) || 0x0;
      _0x1ce61b(
        _0x48065b["orderEarningsCurrency"],
        _0x48065b["grandTotalCurrency"],
      ) &&
        (_0x349b7a["update"](
          "Converting\x20" +
            _0x48065b["grandTotalCurrency"] +
            "\x20to\x20" +
            _0x48065b["orderEarningsCurrency"] +
            "...",
        ),
        (_0x4408a0 = await _0x27888b(
          _0x48065b["grandTotal"],
          _0x48065b["grandTotalCurrency"],
          _0x48065b["orderEarningsCurrency"],
        )));
      _0x349b7a["update"]("Calculating\x20profit...");
      var _0x4d314c = _0x1a1041(_0x165643, _0x4408a0);
      await _0x177529(_0x4d314c);
      var { shouldIncreaseQuantity: _0x21b233 } = await chrome["storage"][
        "local"
      ]["get"]({ shouldIncreaseQuantity: !0x1 });
      if (_0x21b233) {
        _0x349b7a["update"]("Updating\x20quantity...");
        var _0x282e3a = document["querySelector"](
          ".amazon-update-quantity-button",
        );
        (await _0x2a8282(_0x282e3a, "increase"))["ok"] &&
          _0x349b7a["update"]("Quantity\x20Increased");
      }
      _0x349b7a["finish"]("Order\x20placed");
    }
  } else
    (console["error"](
      "Failed\x20to\x20submit\x20eBay\x20order:",
      _0x1a5a09?.["error"],
    ),
      _0x349b7a["error"]("Failed\x20to\x20submit\x20order\x20details"));
}
function _0x45f407(_0x442220) {
  switch (_0x442220) {
    case "com":
    default:
      return "USD";
    case "co.uk":
      return "GBP";
    case "ca":
      return "CAD";
    case "de":
    case "fr":
    case "it":
    case "es":
    case "nl":
      return "EUR";
    case "com.mx":
      return "MXN";
    case "com.au":
      return "AUD";
    case "se":
      return "SEK";
    case "pl":
      return "PLN";
    case "in":
      return "INR";
  }
}
async function _0x177529(_0x4eb1e3, _0x1d97ed = {}) {
  try {
    const {
        durationMs: _0x3d94e5,
        scrollMs: scrollMs = 0x12c,
        minMs: minMs = 0x64,
        maxMs: maxMs = 0x320,
      } = _0x1d97ed,
      _0x5e9152 =
        document["querySelector"](".payment-info\x20.earnings\x20.total") ||
        document["querySelector"](".payment-info\x20.total") ||
        document["querySelector"](".payment-info\x20[class*=\x27total\x27]");
    if (!_0x5e9152)
      return (
        console["warn"]("Order\x20earnings\x20row\x20not\x20found"),
        !0x1
      );
    let _0x6a114e = document["querySelector"](".profit-inline");
    !_0x6a114e &&
      ((_0x6a114e = document["createElement"]("div")),
      (_0x6a114e["className"] = "profit-inline"),
      (_0x6a114e["innerHTML"] =
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22label\x22>Profit</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22value\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22value-sign\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22value-int\x22>0</span><span\x20class=\x22value-sep\x22>.</span><span\x20class=\x22value-dec\x22>00</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22profit-inline__halo\x22\x20aria-hidden=\x22true\x22></div>\x0a\x20\x20\x20\x20\x20\x20"),
      _0x5e9152["parentNode"]["insertBefore"](
        _0x6a114e,
        _0x5e9152["nextSibling"],
      ));
    const _0x241edf = _0x6a114e["querySelector"](".value-sign"),
      _0x100df7 = _0x6a114e["querySelector"](".value-int"),
      _0x215c15 = _0x6a114e["querySelector"](".value-dec"),
      _0x4cde19 = _0x6a114e["querySelector"](".value"),
      _0x16347c = Number(_0x4eb1e3) || 0x0,
      _0x3cbddb = _0x16347c < 0x0,
      _0x5cccab = Math["abs"](_0x16347c);
    (_0x6a114e["classList"]["toggle"]("profit-inline--neg", _0x3cbddb),
      (_0x241edf["textContent"] = _0x3cbddb ? "-" : ""),
      _0x6a114e["classList"]["remove"]("profit-final"),
      _0x6a114e["classList"]["add"]("profit-rolling"),
      _0x4cde19["classList"]["add"]("value-visible"),
      await (async function (_0x47f305) {
        const _0x4b1c73 = window["scrollY"],
          _0x2ebbac =
            Math["max"](
              document["documentElement"]["scrollHeight"] -
                window["innerHeight"],
              0x0,
            ) - _0x4b1c73;
        if (Math["abs"](_0x2ebbac) < 0x6) return;
        const _0x54c7ca = performance["now"]();
        await new Promise((_0xc710f8) => {
          const _0x5902fe = (_0x2194bf) => {
            const _0x481417 = Math["min"](
              0x1,
              (_0x2194bf - _0x54c7ca) / _0x47f305,
            );
            window["scrollTo"](
              0x0,
              _0x4b1c73 +
                _0x2ebbac *
                  ((_0x289209 = _0x481417) < 0.5
                    ? 0x2 * _0x289209 * _0x289209
                    : 0x1 - Math["pow"](-0x2 * _0x289209 + 0x2, 0x2) / 0x2),
            );
            var _0x289209;
            _0x481417 < 0x1 ? requestAnimationFrame(_0x5902fe) : _0xc710f8();
          };
          requestAnimationFrame(_0x5902fe);
        });
      })(scrollMs),
      _0x6a114e["scrollIntoView"]({ behavior: "auto", block: "center" }));
    const _0x2d11a0 =
      ((_0x3d4061 =
        _0x3d94e5 ??
        0x708 + 0x384 * Math["log10"](Math["max"](0xa, _0x5cccab + 0x1))),
      (_0x3090e5 = minMs),
      (_0x34137c = maxMs),
      Math["max"](_0x3090e5, Math["min"](_0x34137c, _0x3d4061)));
    await (async function (_0x361516, _0x3a769f, _0xc24699) {
      const _0x1e1a68 = performance["now"]();
      return new Promise((_0x173d6c) => {
        const _0x9dd41c = (_0x3fd21b) => {
          const _0x1cc770 = _0x3fd21b - _0x1e1a68,
            _0x4081ec = Math["min"](0x1, _0x1cc770 / _0xc24699),
            _0x38f0c3 = ((_0x2076f1) => _0x2076f1 * _0x2076f1 * _0x2076f1)(
              _0x4081ec,
            );
          (((_0x27ca9, _0x4520ab) => {
            const _0x342a9e = Math["floor"](_0x27ca9),
              _0x1db91a = Math["floor"](0x64 * (_0x27ca9 - _0x342a9e));
            ((_0x100df7["textContent"] = _0x342a9e["toLocaleString"]()),
              (_0x215c15["textContent"] = _0x1db91a["toString"]()["padStart"](
                0x2,
                "0",
              )),
              _0x6a114e["style"]["setProperty"](
                "--sniper-intensity",
                (_0x4520ab * _0x4520ab)["toFixed"](0x3),
              ));
          })(0x0 + (_0x3a769f - 0x0) * _0x38f0c3, _0x4081ec),
            _0x4081ec < 0x1 ? requestAnimationFrame(_0x9dd41c) : _0x173d6c());
        };
        requestAnimationFrame(_0x9dd41c);
      });
    })(0x0, _0x5cccab, _0x2d11a0);
    const _0x3562f3 = Math["floor"](_0x5cccab),
      _0x10cafb = Math["round"](0x64 * (_0x5cccab - _0x3562f3));
    return (
      (_0x100df7["textContent"] = _0x3562f3["toLocaleString"]()),
      (_0x215c15["textContent"] = _0x10cafb["toString"]()["padStart"](
        0x2,
        "0",
      )),
      _0x6a114e["classList"]["remove"]("profit-rolling"),
      _0x6a114e["classList"]["add"]("profit-final"),
      await new Promise((_0x5a7c9c) => setTimeout(_0x5a7c9c, 0x12c)),
      !0x0
    );
  } catch (_0x3f77a5) {
    return (
      console["error"](
        "Failed\x20to\x20insert\x20profit\x20inline:",
        _0x3f77a5,
      ),
      !0x1
    );
  }
  var _0x3d4061, _0x3090e5, _0x34137c;
}
async function _0x1e4e4d(_0x84a25a) {
  try {
    const { customEtaMessagePrompt: _0x4a93e3 } = await chrome["storage"][
        "local"
      ]["get"]({ customEtaMessagePrompt: "" }),
      _0x3814eb = _0x84a25a?.["customer"]?.["name"] || "",
      _0x8658f8 = _0x3814eb ? _0x3814eb["split"]("\x20")[0x0] : "",
      _0x85db75 = _0x84a25a?.["itemName"] ? String(_0x84a25a["itemName"]) : "",
      _0x2d808a = _0x84a25a?.["estimatedDeliveryDate"]
        ? String(_0x84a25a["estimatedDeliveryDate"])
        : "",
      _0x450b45 = String(_0x4a93e3 || ""),
      _0x4a04f7 = JSON["stringify"]({
        buyer_first_name: _0x8658f8,
        item_name: _0x85db75,
        raw_eta_text: _0x2d808a,
      }),
      _0x1930a2 = await openaiLibrary["requestStructuredField"]({
        system: _0x450b45,
        user: _0x4a04f7,
        name: "eta_message",
        type: "string",
        model: "gpt-4o-mini",
      });
    return _0x1930a2 && _0x1930a2["ok"]
      ? { ok: !0x0, data: (_0x1930a2["data"] || "")["trim"]() }
      : {
          ok: !0x1,
          error:
            _0x1930a2?.["error"] ||
            "Failed\x20to\x20build\x20custom\x20ETA\x20message",
        };
  } catch (_0x13fc0f) {
    return { ok: !0x1, error: _0x13fc0f?.["message"] || String(_0x13fc0f) };
  }
}
async function _0x45c710(_0x452b5d) {
  try {
    var _0xf79474 =
        (_0x452b5d && _0x452b5d["customer"] && _0x452b5d["customer"]["name"]) ||
        "",
      _0x3a6a34 = _0xf79474 ? _0xf79474["split"]("\x20")[0x0] : "there",
      _0x219d7a =
        _0x452b5d && _0x452b5d["itemName"] ? String(_0x452b5d["itemName"]) : "",
      _0x5262d7 =
        _0x452b5d && _0x452b5d["estimatedDeliveryDate"]
          ? String(_0x452b5d["estimatedDeliveryDate"])
          : "",
      _0x28d8c1 =
        "language_code:\x20" +
        (function (_0x26ce3e, _0x5c4481) {
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.de")) return "de";
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.fr")) return "fr";
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.es")) return "es";
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.it")) return "it";
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.com")) return "en";
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.ca")) return "en";
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.co.uk")) return "en";
          if (-0x1 !== _0x26ce3e["indexOf"]("ebay.com.au")) return "en";
          if (_0x5c4481) {
            var _0x36839b = _0x5c4481["toLowerCase"]();
            if (-0x1 !== _0x36839b["indexOf"]("germany") || "de" === _0x36839b)
              return "de";
            if (-0x1 !== _0x36839b["indexOf"]("france") || "fr" === _0x36839b)
              return "fr";
            if (-0x1 !== _0x36839b["indexOf"]("spain") || "es" === _0x36839b)
              return "es";
            if (-0x1 !== _0x36839b["indexOf"]("italy") || "it" === _0x36839b)
              return "it";
            if (-0x1 !== _0x36839b["indexOf"]("canada") || "ca" === _0x36839b)
              return "en";
            if (
              -0x1 !== _0x36839b["indexOf"]("united\x20kingdom") ||
              "uk" === _0x36839b ||
              "gb" === _0x36839b
            )
              return "en";
            if (
              -0x1 !== _0x36839b["indexOf"]("australia") ||
              "au" === _0x36839b
            )
              return "en";
            if (
              -0x1 !== _0x36839b["indexOf"]("united\x20states") ||
              "us" === _0x36839b
            )
              return "en";
          }
          return "en";
        })(
          window["location"]["hostname"] || "",
          (_0x452b5d &&
            _0x452b5d["customer"] &&
            _0x452b5d["customer"]["address"] &&
            _0x452b5d["customer"]["address"]["country"]) ||
            "",
        ) +
        "\x0abuyer_first_name:\x20" +
        _0x3a6a34 +
        "\x0aitem_name:\x20" +
        _0x219d7a +
        "\x0araw_eta_text:\x20" +
        _0x5262d7 +
        "\x0anotes:\x0a-\x20raw_eta_text\x20can\x20be\x20a\x20date\x20or\x20a\x20phrase\x20like\x20\x27Arriving\x20today\x27\x20or\x20\x27Arriving\x20tomorrow\x27.\x0a-\x20Do\x20not\x20include\x20sender\x20name\x20or\x20store\x20name.\x0a-\x20Keep\x20the\x20tone\x20friendly\x20and\x20brief.\x0a",
      _0x5a245f = await openaiLibrary["requestStructuredField"]({
        system:
          "You\x20are\x20writing\x20a\x20short,\x20casual,\x20friendly\x20order\x20update\x20for\x20an\x20eBay\x20buyer.\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20Tone\x20rules:\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Write\x20like\x20you\x27re\x20texting\x20a\x20friend,\x20not\x20a\x20customer.\x20Warm,\x20human,\x20and\x20easygoing.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Always\x20thank\x20them\x20for\x20supporting\x20a\x20small\x20family\x20business.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Never\x20apologize,\x20never\x20say\x20sorry.\x20We\x20elevate\x20ourselves,\x20not\x20lower\x20status.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Mention\x20their\x20first\x20name\x20if\x20provided,\x20otherwise\x20use\x20a\x20friendly\x20greeting.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Simplify\x20the\x20product\x20name\x20so\x20it\x20sounds\x20natural.\x20Do\x20not\x20repeat\x20long\x20or\x20clunky\x20catalog\x20titles.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20State\x20clearly\x20when\x20they\x20can\x20expect\x20the\x20order,\x20using\x20the\x20provided\x20ETA\x20text,\x20but\x20keep\x20it\x20conversational\x20(e.g.,\x20\x22Your\x20treadmill\x20should\x20be\x20at\x20your\x20door\x20tomorrow\x22).\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Keep\x20it\x20short,\x20cheerful,\x20and\x20memorable.\x20No\x20emojis,\x20no\x20signatures,\x20no\x20store\x20names.\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20Your\x20only\x20output\x20is\x20the\x20exact\x20message\x20text\x20to\x20send.\x0a\x20\x20\x20\x20\x20\x20\x20\x20",
        user: _0x28d8c1,
        name: "eta_message",
        type: "string",
        model: "gpt-4o-mini",
      });
    return _0x5a245f && _0x5a245f["ok"]
      ? { ok: !0x0, data: _0x5a245f["data"] }
      : {
          ok: !0x1,
          error:
            _0x5a245f && _0x5a245f["error"]
              ? _0x5a245f["error"]
              : "Failed\x20to\x20build\x20ETA\x20message",
        };
  } catch (_0x3e2a98) {
    return {
      ok: !0x1,
      error:
        _0x3e2a98 && _0x3e2a98["message"]
          ? _0x3e2a98["message"]
          : String(_0x3e2a98),
    };
  }
}
async function _0x5f186e(_0x4bb5ff) {
  var { agentName: _0x5b6096 } =
      await chrome["storage"]["local"]["get"]("agentName"),
    _0x4e5816 = new Date()["toLocaleDateString"](),
    _0x40a9f5 = "SS";
  ((_0x40a9f5 += "\x20" + _0x4bb5ff["amazonEmail"]),
    (_0x40a9f5 += "\x20-\x20ETA:\x20" + _0x4bb5ff["estimatedDeliveryDate"]),
    (_0x40a9f5 += "\x20-\x20" + _0x4e5816 + "\x20" + _0x5b6096));
  var _0x44ea29 = _0x48f9c6();
  return (
    _0x44ea29 && (_0x40a9f5 = _0x44ea29 + "\x20-\x20" + _0x40a9f5),
    _0x40a9f5
  );
}
async function _0x49a448(_0x35a99d) {
  const { customNoteTemplate: customNoteTemplate = "" } = await chrome[
      "storage"
    ]["local"]["get"]({ customNoteTemplate: "" }),
    { agentName: agentName = "" } = await chrome["storage"]["local"]["get"]({
      agentName: "",
    });
  let _0x1c7cee = (customNoteTemplate ||
    "SS\x20{{amazonEmail}}\x20-\x20#{{amazonOrderNumber}}\x20-\x20ETA:\x20{{eta}}\x20-\x20{{date}}\x20{{agent}}")[
    "trim"
  ]();
  const _0x279e0c = {
    agent: agentName,
    agentname: agentName,
    date: new Date()["toLocaleDateString"]("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }),
    ebayordernumber: _0x35a99d["ebayOrderNumber"] || "",
    amazonordernumber: _0x35a99d["amazonOrderNumber"] || "",
    itemname: _0x35a99d["itemName"] || "",
    quantitysold: _0x35a99d["quantitySold"] || "",
    customername: _0x35a99d["customer"]?.["name"] || "",
    customerfirstname:
      (_0x35a99d["customer"]?.["name"] || "")["split"]("\x20")[0x0] || "",
    customeraddress: _0x35a99d["customerAddress"] || "",
    customercity: _0x35a99d["customer"]?.["address"]?.["city"] || "",
    customerstate: _0x35a99d["customer"]?.["address"]?.["state"] || "",
    customerzip: _0x35a99d["customer"]?.["address"]?.["zip"] || "",
    customercountry: _0x35a99d["customer"]?.["address"]?.["country"] || "",
    customerphone: _0x35a99d["customer"]?.["phone"] || "",
    eta: _0x35a99d["estimatedDeliveryDate"] || "",
    estimateddeliverydate: _0x35a99d["estimatedDeliveryDate"] || "",
    fulfillmentdate: _0x35a99d["fulfillmentDate"] || "",
    trackingnumber: _0x35a99d["trackingNumber"] || "",
    soldprice: _0x35a99d["soldPrice"] || "",
    grandtotal: _0x35a99d["grandTotal"] || "",
    orderearnings: _0x35a99d["orderEarnings"] || "",
    profit: _0x35a99d["profit"] || "",
    orderearningscurrency: _0x35a99d["orderEarningsCurrency"] || "",
    grandtotalcurrency: _0x35a99d["grandTotalCurrency"] || "",
    domain: _0x35a99d["domain"] || "",
    ebayusername: _0x35a99d["ebayUsername"] || "",
    amazonemail: _0x35a99d["amazonEmail"] || "",
    amazondomain: _0x35a99d["amazonDomain"] || "",
  };
  _0x1c7cee = _0x1c7cee["replace"](
    /\{\{\s*([^}]+)\s*\}\}/gi,
    (_0x2ff495, _0x497d87) => {
      const _0x505110 = _0x497d87["trim"]()["toLowerCase"]();
      return void 0x0 !== _0x279e0c[_0x505110]
        ? String(_0x279e0c[_0x505110])
        : "";
    },
  );
  const _0x2e5b1c = ("function" == typeof _0x48f9c6 && _0x48f9c6()) || "";
  return (
    _0x2e5b1c && (_0x1c7cee = _0x2e5b1c + "\x20-\x20" + _0x1c7cee),
    _0x1c7cee["trim"]()
  );
}
async function _0x1596f8(_0x1253ca, _0x4c591d = 0x493e0, _0x39181 = 0x1388) {
  const _0x4fde67 = (_0x3d6c57) =>
      new Promise((_0x3abe08) => setTimeout(_0x3abe08, _0x3d6c57)),
    _0x5292d6 =
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/ebayOrders/check/" +
      _0x1253ca,
    _0x3bba27 = Date["now"]() + _0x4c591d;
  for (; Date["now"]() < _0x3bba27; ) {
    console["log"]("polling\x20for\x20Amazon\x20order");
    const _0x3d5c2e = await fetch(_0x5292d6, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    });
    if (!_0x3d5c2e["ok"]) return { error: "HTTP\x20" + _0x3d5c2e["status"] };
    const _0xcb8d3f = await _0x3d5c2e["json"]();
    console["log"]("Amazon\x20order\x20lookup\x20response:", _0xcb8d3f);
    if (_0xcb8d3f?.["data"]?.["remarks"]?.["includes"]("ERROR"))
      return { error: _0xcb8d3f["data"]["remarks"] };
    if (
      _0xcb8d3f?.["data"]?.["amazonOrderNumber"] ||
      _0xcb8d3f?.["data"]?.["amazonOrderDetails"]
    )
      return (
        console["log"](
          "Polling\x20for\x20Amazon\x20order\x20was\x20successful",
        ),
        _0xcb8d3f["data"]
      );
    await _0x4fde67(_0x39181);
  }
  return {
    error:
      "Couldn\x27t\x20find\x20the\x20supplier\x20order\x20after\x20checking\x20for\x20a\x20while.",
  };
}
async function _0x486268() {
  try {
    const _0xe85c1c = document["querySelector"](
      "[data-action-id=\x22MARK_SHIPPED\x22]\x20a",
    );
    if (!_0xe85c1c) return !0x1;
    const _0x5b8862 = _0xe85c1c["getAttribute"]("href");
    if (!_0x5b8862) return !0x1;
    const _0x2c98bb = await fetch(_0x5b8862, {
        method: "GET",
        credentials: "include",
      }),
      _0x307ab9 = await _0x2c98bb["text"]();
    let _0x5deef0;
    try {
      _0x5deef0 = JSON["parse"](_0x307ab9);
    } catch {
      _0x5deef0 = null;
    }
    return (
      !(!_0x5deef0 || "SUCCESS" !== _0x5deef0["ack"]) ||
      !(
        "string" != typeof _0x307ab9 ||
        !_0x307ab9["includes"]("Update\x20Shipment\x20operation\x20success")
      )
    );
  } catch (_0x3f7dc2) {
    return (
      console["error"]("❌\x20Error\x20marking\x20as\x20shipped:", _0x3f7dc2),
      !0x1
    );
  }
}
async function _0x59fbe1() {
  if (!document["getElementById"]("sniper-power-css")) {
    const _0x20de60 = document["createElement"]("style");
    ((_0x20de60["id"] = "sniper-power-css"),
      (_0x20de60["textContent"] =
        "\x0a:root{\x0a\x20\x20--sniper-ink:#0b0f13;\x0a\x20\x20--sniper-sub:#5b626a;\x0a\x20\x20--sniper-card:#ffffff;\x0a\x20\x20--sniper-border:rgba(0,0,0,.08);\x0a\x20\x20--sniper-green:#16a34a;\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20brand\x20accent\x20*/\x0a\x20\x20--sniper-green-rgb:22,163,74;\x0a\x20\x20--sniper-steel-1:#eef1f4;\x0a\x20\x20--sniper-steel-2:#dfe5ea;\x0a}\x0a\x0a/*\x20host\x20prep\x20*/\x0a.sniper-power-host{\x20position:relative\x20!important;\x20overflow:hidden\x20!important;\x20border-radius:12px\x20!important;\x20}\x0a.sniper-mask-all\x20\x20\x20>\x20*:not(.sniper-power-replace){\x20visibility:hidden\x20!important;\x20pointer-events:none\x20!important;\x20}\x0a\x0a/*\x20FULL\x20replacement\x20*/\x0a.sniper-power-replace{\x0a\x20\x20position:absolute;\x20inset:-1px;\x20border-radius:inherit;\x20z-index:5;\x20pointer-events:auto;\x0a\x20\x20background:\x20var(--sniper-card);\x0a\x20\x20box-shadow:\x20inset\x200\x200\x200\x201px\x20var(--sniper-border);\x0a\x20\x20display:grid;\x20grid-template-rows:auto\x201fr;\x20opacity:0;\x0a}\x0a\x0a/*\x20Forged\x20gradient\x20border\x20(power\x20feel)\x20*/\x0a.sniper-power-replace::before{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20inset:-2px;\x20border-radius:inherit;\x20pointer-events:none;\x0a\x20\x20background:\x20linear-gradient(135deg,\x20rgba(var(--sniper-green-rgb),.45),\x20rgba(0,0,0,.0)\x2035%,\x20rgba(0,110,255,.35)\x2065%,\x20rgba(0,0,0,.0));\x0a\x20\x20mask:\x20linear-gradient(#000\x200\x200)\x20content-box,\x20linear-gradient(#000\x200\x200);\x0a\x20\x20-webkit-mask:\x20linear-gradient(#000\x200\x200)\x20content-box,\x20linear-gradient(#000\x200\x200);\x0a\x20\x20padding:2px;\x20-webkit-mask-composite:\x20xor;\x20mask-composite:\x20exclude;\x0a\x20\x20filter:\x20blur(.2px);\x0a\x20\x20opacity:.85;\x0a}\x0a\x0a/*\x20Header:\x20icon\x20+\x20titles\x20*/\x0a.sniper-power-head{\x0a\x20\x20position:relative;\x20display:grid;\x20grid-template-columns:auto\x201fr;\x20align-items:center;\x20column-gap:14px;\x0a\x20\x20padding:18px;\x0a\x20\x20background:\x20linear-gradient(180deg,\x20#fff,\x20#fafbfc);\x0a\x20\x20border-bottom:1px\x20solid\x20var(--sniper-border);\x0a}\x0a\x0a/*\x20Command\x20sweep\x20bar\x20(charges\x20fast,\x20conveys\x20power)\x20*/\x0a.sniper-power-head::after{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20left:0;\x20right:0;\x20top:0;\x20height:3px;\x20pointer-events:none;\x0a\x20\x20background:\x20linear-gradient(90deg,\x20rgba(var(--sniper-green-rgb),.0)\x200%,\x20rgba(var(--sniper-green-rgb),.85)\x2020%,\x20rgba(var(--sniper-green-rgb),.0)\x20100%);\x0a\x20\x20transform-origin:left;\x20transform:\x20scaleX(0);\x0a}\x0a\x0a/*\x20Body\x20*/\x0a.sniper-power-body{\x20padding:16px\x2018px\x2018px;\x20display:flex;\x20flex-wrap:wrap;\x20gap:10px;\x20align-content:start;\x20}\x0a\x0a/*\x20Halo\x20crest\x20check\x20(decisive,\x20not\x20cutesy)\x20*/\x0a.sniper-power-crest{\x0a\x20\x20position:relative;\x20width:46px;\x20height:46px;\x20display:grid;\x20place-items:center;\x0a}\x0a.sniper-power-crest::before{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20inset:-6px;\x20border-radius:999px;\x0a\x20\x20background:\x20radial-gradient(circle\x20at\x2050%\x2050%,\x20rgba(var(--sniper-green-rgb),.35),\x20rgba(var(--sniper-green-rgb),0)\x2060%);\x0a\x20\x20transform:\x20scale(.85);\x20opacity:0;\x0a}\x0a.sniper-power-crest::after{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20inset:0;\x20border-radius:999px;\x0a\x20\x20background:\x20conic-gradient(from\x200deg,\x20rgba(var(--sniper-green-rgb),.0),\x20rgba(var(--sniper-green-rgb),.6),\x20rgba(var(--sniper-green-rgb),.0)\x2070%);\x0a\x20\x20filter:\x20blur(10px);\x20opacity:0;\x20transform:\x20rotate(-12deg);\x0a}\x0a.sniper-power-crest\x20.tick{\x0a\x20\x20width:34px;\x20height:34px;\x20border-radius:999px;\x20display:grid;\x20place-items:center;\x0a\x20\x20background:\x20var(--sniper-green);\x20color:#fff;\x20font-weight:900;\x20box-shadow:0\x206px\x2016px\x20rgba(var(--sniper-green-rgb),.35);\x0a}\x0a\x0a/*\x20Titles\x20*/\x0a.sniper-power-title{\x20font:800\x2018px/1.2\x20system-ui,-apple-system,Segoe\x20UI,Roboto,Arial,sans-serif;\x20color:var(--sniper-ink);\x20}\x0a.sniper-power-sub\x20\x20{\x20font:600\x2012px/1.2\x20system-ui,-apple-system,Segoe\x20UI,Roboto,Arial,sans-serif;\x20color:var(--sniper-sub);\x20margin-top:2px;\x20}\x0a\x0a/*\x20Chips\x20*/\x0a.sniper-chip{\x0a\x20\x20display:inline-flex;\x20align-items:center;\x20gap:8px;\x20padding:8px\x2012px;\x20border-radius:999px;\x0a\x20\x20font:700\x2012px/1\x20system-ui,-apple-system,Segoe\x20UI,Roboto,Arial,sans-serif;\x20color:var(--sniper-ink);\x0a\x20\x20background:\x20linear-gradient(180deg,\x20var(--sniper-steel-1),\x20var(--sniper-steel-2));\x0a\x20\x20border:1px\x20solid\x20rgba(0,0,0,.08);\x0a}\x0a.sniper-chip--ok{\x0a\x20\x20background:\x20linear-gradient(180deg,\x20rgba(var(--sniper-green-rgb),.14),\x20rgba(var(--sniper-green-rgb),.10));\x0a\x20\x20border-color:\x20rgba(var(--sniper-green-rgb),.35);\x0a}\x0a\x0a/*\x20Subtle\x20tech\x20grid\x20(barely\x20there,\x20conveys\x20control)\x20*/\x0a.sniper-power-grid{\x0a\x20\x20position:absolute;\x20inset:0;\x20pointer-events:none;\x20opacity:.045;\x0a\x20\x20background:\x0a\x20\x20\x20\x20repeating-linear-gradient(0deg,\x20#000\x200\x201px,\x20transparent\x201px\x2024px),\x0a\x20\x20\x20\x20repeating-linear-gradient(90deg,\x20#000\x200\x201px,\x20transparent\x201px\x2024px);\x0a}\x0a\x0a/*\x20ARM\x20=\x20start\x20the\x20show\x20(we\x20add\x20this\x20after\x20centering)\x20*/\x0a.sniper-armed\x20.sniper-power-replace{\x20animation:\x20power-fade\x20.18s\x20ease-out\x20forwards;\x20}\x0a.sniper-armed\x20.sniper-power-head::after{\x20animation:\x20power-sweep\x20.7s\x20cubic-bezier(.2,.8,.2,1)\x20.05s\x20forwards;\x20}\x0a.sniper-armed\x20.sniper-power-crest::before{\x20animation:\x20halo-pulse\x20.7s\x20ease-out\x20.06s\x20forwards;\x20}\x0a.sniper-armed\x20.sniper-power-crest::after{\x20animation:\x20halo-arc\x201.1s\x20ease-out\x20.08s\x20forwards;\x20}\x0a\x0a/*\x20Animations\x20*/\x0a@keyframes\x20power-fade\x20{\x20from{opacity:0}\x20to{opacity:1}\x20}\x0a@keyframes\x20power-sweep\x20{\x0a\x20\x200%{\x20transform:scaleX(0)\x20}\x0a\x20\x2060%{\x20transform:scaleX(1.06)\x20}\x0a\x20\x20100%{\x20transform:scaleX(1)\x20}\x0a}\x0a@keyframes\x20halo-pulse\x20{\x0a\x20\x200%{\x20opacity:0;\x20transform:scale(.85)\x20}\x0a\x20\x2060%{\x20opacity:1;\x20transform:scale(1.05)\x20}\x0a\x20\x20100%{\x20opacity:.85;\x20transform:scale(1)\x20}\x0a}\x0a@keyframes\x20halo-arc\x20{\x0a\x20\x200%{\x20opacity:0;\x20transform:rotate(-12deg)\x20}\x0a\x20\x20100%{\x20opacity:.85;\x20transform:rotate(0deg)\x20}\x0a}\x0a\x0a/*\x20Reduced\x20motion:\x20keep\x20the\x20authority,\x20skip\x20motion\x20*/\x0a@media\x20(prefers-reduced-motion:reduce){\x0a\x20\x20.sniper-armed\x20.sniper-power-replace,\x0a\x20\x20.sniper-armed\x20.sniper-power-head::after,\x0a\x20\x20.sniper-armed\x20.sniper-power-crest::before,\x0a\x20\x20.sniper-armed\x20.sniper-power-crest::after\x20{\x20animation:none\x20!important;\x20opacity:1\x20!important;\x20transform:none\x20!important;\x20}\x0a}\x0a\x20\x20\x20\x20"),
      document["head"]["appendChild"](_0x20de60));
  }
  const _0x31e4da =
    document["querySelector"]("[data-action-id=\x22MARK_SHIPPED\x22]") ||
    document["querySelector"]("[data-action-id=\x22ADD_TRACKING_NUMBER\x22]") ||
    document["querySelector"]("[data-action-id]");
  if (!_0x31e4da) return !0x1;
  const _0x50d9ac =
    _0x31e4da["closest"](".status-summary.widget") ||
    _0x31e4da["closest"](".status-summary") ||
    _0x31e4da["closest"]("[class*=\x22status-summary\x22]") ||
    _0x31e4da["closest"](".widget");
  if (!_0x50d9ac) return !0x1;
  (_0x50d9ac["classList"]["add"]("sniper-power-host", "sniper-mask-all"),
    _0x50d9ac["querySelectorAll"]("[data-action-id=\x22MARK_SHIPPED\x22]")[
      "forEach"
    ]((_0x5b5b0b) => {
      _0x5b5b0b["style"]["display"] = "none";
    }),
    _0x50d9ac["querySelector"](".sniper-power-replace")?.["remove"]());
  const _0x216d98 = document["createElement"]("div");
  return (
    (_0x216d98["className"] = "sniper-power-replace"),
    (_0x216d98["innerHTML"] =
      "\x0a\x20\x20\x20\x20<div\x20class=\x22sniper-power-grid\x22\x20aria-hidden=\x22true\x22></div>\x0a\x20\x20\x20\x20<div\x20class=\x22sniper-power-head\x22>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22sniper-power-crest\x22><div\x20class=\x22tick\x22>✔</div></div>\x0a\x20\x20\x20\x20\x20\x20<div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22sniper-power-title\x22>Marked\x20as\x20Shipped</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22sniper-power-sub\x22>Updated\x20by\x20EcomSniper</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20<div\x20class=\x22sniper-power-body\x22>\x0a\x20\x20\x20\x20\x20\x20<span\x20class=\x22sniper-chip\x20sniper-chip--ok\x22>Status:\x20Shipped</span>\x0a\x20\x20\x20\x20\x20\x20<span\x20class=\x22sniper-chip\x22>You\x20can\x20add\x20tracking\x20anytime</span>\x0a\x20\x20\x20\x20</div>\x0a\x20\x20"),
    _0x50d9ac["appendChild"](_0x216d98),
    window["scrollTo"](0x0, 0x0),
    await new Promise((_0x537fb3) =>
      requestAnimationFrame(() => requestAnimationFrame(_0x537fb3)),
    ),
    _0x50d9ac["scrollIntoView"]({ behavior: "auto", block: "center" }),
    document["documentElement"]["classList"]["add"]("sniper-armed"),
    await new Promise((_0x1e96c5) => setTimeout(_0x1e96c5, 0x320)),
    !0x0
  );
}
async function _0x1c9f3f(_0x5c03d9) {
  chrome["runtime"]["sendMessage"]({
    type: "makeTabActive",
    shouldSwitchBack: !0x0,
  });
  function findMessageButton() {
    return document["querySelector"](
      ".order-info\x20.actions\x20.btn--secondary",
    );
  }
  function _0xe7cf2b() {
    var _0x4476b3 = document["querySelector"](".panel-dialog__close");
    _0x4476b3 && _0x4476b3["click"]();
  }
  for (let _0x559ad7 = 0x1; _0x559ad7 <= 0x4; _0x559ad7++)
    try {
      const _0x146543 = findMessageButton();
      if (!_0x146543)
        throw new Error(
          "Unable\x20to\x20find\x20\x27Message\x20Buyer\x27\x20button",
        );
      (_0x146543["scrollIntoView"]({ block: "center" }), _0x146543["click"]());
      const _0x4d36b8 = await iframeUtils["parent"]["waitForIframeReady"](
          ".ordui-m2m-panel__iframe",
          0x4e20,
        ),
        _0x381cb3 = await iframeUtils["parent"]["askIframe"](
          _0x4d36b8,
          "send_message_to_buyer",
          { message: _0x5c03d9 },
          0x4e20,
        );
      return (console["log"]("Iframe\x20reply:", _0x381cb3), _0xe7cf2b(), !0x0);
    } catch (_0x5db7e1) {
      console["warn"](
        "sendEbayBuyerETA\x20attempt\x20" + _0x559ad7 + "\x20failed:",
        _0x5db7e1 && _0x5db7e1["message"] ? _0x5db7e1["message"] : _0x5db7e1,
      );
      if (0x4 === _0x559ad7) throw _0x5db7e1;
      (_0xe7cf2b(),
        await new Promise((_0x33e4cb) => setTimeout(_0x33e4cb, 0x1388)));
    }
}
function _0x1a1041(_0x224e5f, _0x4660e5) {
  function _0x3323a4(_0x27c1d3) {
    if (null == _0x27c1d3) return 0x0;
    return (
      (_0x27c1d3 = _0x27c1d3["toString"]()["trim"]())["includes"](",") &&
        /,\d{1,2}$/["test"](_0x27c1d3) &&
        (_0x27c1d3 = (_0x27c1d3 = _0x27c1d3["replace"](/\./g, ""))["replace"](
          /,/g,
          ".",
        )),
      (_0x27c1d3 = _0x27c1d3["replace"](/[^0-9.-]/g, "")),
      parseFloat(_0x27c1d3) || 0x0
    );
  }
  return +(_0x3323a4(_0x224e5f) - _0x3323a4(_0x4660e5))["toFixed"](0x2);
}
function _0x27888b(_0x2a36e1, _0x2efb76, _0x41b929) {
  const _0x33c08c = {
      CAD_TO_USD: 0.727,
      USD_TO_CAD: 0x1 / 0.727,
      EUR_TO_USD: 1.1712,
      USD_TO_EUR: 0x1 / 1.1712,
      GBP_TO_USD: 1.3,
      USD_TO_GBP: 0x1 / 1.3,
    },
    _0x353355 = (_0x2efb76 || "")["trim"]()["toUpperCase"](),
    _0xd35c49 = (_0x41b929 || "")["trim"]()["toUpperCase"](),
    _0xc93309 = _0x353355 + "_TO_" + _0xd35c49;
  if (!_0x33c08c[_0xc93309])
    return (
      console["warn"](
        "No\x20conversion\x20rate\x20available\x20for\x20" +
          _0x353355 +
          "\x20to\x20" +
          _0xd35c49 +
          ".\x20Returning\x20original\x20amount.",
      ),
      Number(_0x2a36e1["toFixed"](0x2))
    );
  return Number((_0x2a36e1 * _0x33c08c[_0xc93309])["toFixed"](0x2));
}
function _0x1ce61b(_0x50c1b4, _0x1b4783) {
  const _0x4a987e = (_0x50c1b4 || "")["trim"]()["toUpperCase"](),
    _0x1d9cca = (_0x1b4783 || "")["trim"]()["toUpperCase"]();
  return !(!_0x4a987e || !_0x1d9cca) && _0x4a987e !== _0x1d9cca;
}
function _0x2a8282(_0x764474, _0x2de40b = "increase") {
  return new Promise((_0x2ec365) => {
    (_0x764474["addEventListener"](
      _0x2de40b + ":done",
      (_0x902384) => _0x2ec365(_0x902384["detail"]),
      { once: !0x0 },
    ),
      _0x764474["click"]());
  });
}
console["log"]("Poshmark\x20Order\x20Functions\x20Loaded");
function _0x521c36() {
  const _0x3315aa = document["querySelectorAll"](".order-items__item-info");
  for (const _0xbdc029 of _0x3315aa)
    if (_0xbdc029["textContent"]["includes"]("SKU:")) {
      const _0x5d7a64 = _0xbdc029["textContent"]
        ["replace"]("SKU:", "")
        ["trim"]();
      return (console["log"]("SKU:", _0x5d7a64), _0x5d7a64);
    }
  return null;
}
function _0x5b56e9() {
  const _0x2894e8 = document["querySelector"](
    ".order-items__item-title.fw--med",
  );
  if (_0x2894e8) {
    const _0x4eeb81 = _0x2894e8["textContent"]["trim"]();
    return (console["log"]("Item\x20Name:", _0x4eeb81), _0x4eeb81);
  }
  return null;
}
function _0x32ea06() {
  const _0x4b5750 = document["querySelector"](".listing-info__detail");
  if (_0x4b5750) {
    const _0x2e763e = _0x4b5750["textContent"]["trim"]();
    return (console["log"]("Date\x20of\x20Sale:", _0x2e763e), _0x2e763e);
  }
  return null;
}
function _0x709e31() {
  const _0x37457f = document["querySelectorAll"](".listing-info__detail");
  if (_0x37457f["length"] > 0x1) {
    const _0x59ef03 = _0x37457f[0x1]["textContent"]["trim"]();
    return (console["log"]("eBay\x20Order\x20Number:", _0x59ef03), _0x59ef03);
  }
  return null;
}
function _0x32c504() {
  return 0x1;
}
function _0x20d09a() {
  var _0x52bc52 = document["querySelector"](".tc--b.m--t--1.fw--med\x20span");
  if (_0x52bc52) {
    const _0x9353cd = _0x52bc52["textContent"]["trim"](),
      _0x20ae1c = parseFloat(_0x9353cd["replace"](/[$,]/g, ""));
    return (console["log"]("Order\x20Earnings:", _0x20ae1c), _0x20ae1c);
  }
  return null;
}
function _0x786709() {
  var _0x4af9bc = document["querySelector"](".order-items__item-price.fw--med");
  if (_0x4af9bc) {
    const _0x9def4e = _0x4af9bc["textContent"]["trim"](),
      _0x1819ed = parseFloat(_0x9def4e["replace"](/[$,]/g, ""));
    return (console["log"]("Sold\x20Price:", _0x1819ed), _0x1819ed);
  }
  return null;
}
async function _0x218212(_0x327510 = document) {
  var _0x25bb50 = {};
  (console["log"]("Initialized\x20orderDetails:", _0x25bb50),
    (_0x25bb50["itemName"] = _0x5b56e9(_0x327510)),
    console["log"]("Item\x20Name:", _0x25bb50["itemName"]),
    (_0x25bb50["dateOfSale"] = _0x32ea06(_0x327510)),
    console["log"]("Date\x20of\x20Sale:", _0x25bb50["dateOfSale"]),
    (_0x25bb50["ebayOrderNumber"] = _0x709e31(_0x327510)),
    console["log"]("eBay\x20Order\x20Number:", _0x25bb50["ebayOrderNumber"]),
    (_0x25bb50["quantitySold"] = _0x32c504(_0x327510)),
    console["log"]("Quantity\x20Sold:", _0x25bb50["quantitySold"]),
    (_0x25bb50["orderEarnings"] = _0x20d09a(_0x327510)),
    console["log"]("Order\x20Earnings:", _0x25bb50["orderEarnings"]),
    (_0x25bb50["soldPrice"] = _0x786709(_0x327510)),
    (_0x25bb50["ebayFees"] =
      _0x25bb50["soldPrice"] - _0x25bb50["orderEarnings"]),
    (_0x25bb50["addFee"] = 0x0));
  var _0x52d70b = await _0x521c36(_0x327510);
  ((_0x25bb50["ebaySku"] = _0x52d70b),
    console["log"]("eBay\x20SKU:", _0x25bb50["ebaySku"]));
  var _0x1e1dac = await _0x3b1a6d(_0x327510);
  ((_0x25bb50["customer"] = _0x1e1dac),
    console["log"]("Customer:", _0x25bb50["customer"]));
  var { domain: _0x349036 } = await chrome["storage"]["local"]["get"]("domain");
  return (
    (_0x25bb50["domain"] = _0x349036),
    console["log"]("Domain:", _0x25bb50["domain"]),
    _0x25bb50
  );
}
(console["log"]("Poshmark\x20Order\x20Content\x20Loaded"), _0x35e179());
async function _0x35e179() {
  await _0x7ed109();
  var _0x5a3476 = document["querySelector"](".order-details__title.all-caps");
  console["log"]("Order\x20Title:", _0x5a3476?.["textContent"]);
  var _0x5ec5f7 = _0x3c0b87();
  (_0x5a3476["parentElement"]["appendChild"](_0x5ec5f7),
    await populateUSAddressForm());
  var _0x3b85ef = await _0x5be025(),
    _0x5b8491 = document["querySelector"](".order-info__container.m--b--5");
  _0x5b8491 && _0x5b8491["appendChild"](_0x3b85ef);
}
function _0x3c0b87() {
  const _0x5b6666 = document["createElement"]("div");
  Object["assign"](_0x5b6666["style"], {
    fontFamily: "Arial,\x20sans-serif",
    fontSize: "14px",
    border: "1px\x20solid\x20#ccc",
    padding: "12px",
    margin: "12px\x200",
    maxWidth: "320px",
    background: "#f9f9f9",
    borderRadius: "6px",
  });
  const _0x3458d6 = document["createElement"]("div");
  _0x3458d6["className"] = "shipping-address";
  const _0x2ac471 = document["createElement"]("div");
  _0x2ac471["className"] = "address";
  function _0x1dd862(_0x4cc7bb, _0x5d257e) {
    const _0x42bac8 = document["createElement"]("div");
    return (
      (_0x42bac8["id"] = _0x4cc7bb),
      (_0x42bac8["contentEditable"] = "true"),
      (_0x42bac8["innerText"] = _0x5d257e),
      Object["assign"](_0x42bac8["style"], {
        border: "1px\x20solid\x20#ccc",
        borderRadius: "4px",
        padding: "6px",
        marginBottom: "6px",
        minHeight: "18px",
        color: "#666",
      }),
      _0x42bac8["addEventListener"]("focus", () => {
        _0x42bac8["innerText"] === _0x5d257e &&
          ((_0x42bac8["innerText"] = ""),
          (_0x42bac8["style"]["color"] = "#000"));
      }),
      _0x42bac8["addEventListener"]("blur", () => {
        "" === _0x42bac8["innerText"]["trim"]() &&
          ((_0x42bac8["innerText"] = _0x5d257e),
          (_0x42bac8["style"]["color"] = "#666"));
      }),
      _0x42bac8
    );
  }
  const _0x268029 = _0x1dd862("name", "Full\x20Name"),
    _0x37f174 = _0x1dd862("line_1", "Address\x20Line\x201"),
    _0x5ad4be = _0x1dd862("line_2", ""),
    _0x288bbc = _0x1dd862("country", "Country"),
    _0x4b435a = document["createElement"]("div");
  Object["assign"](_0x4b435a["style"], { marginBottom: "6px" });
  function _0x5e9d30(_0x83301c) {
    const _0x51fa49 = document["createElement"]("span");
    return (
      (_0x51fa49["className"] = "copy-to-clipboard"),
      (_0x51fa49["contentEditable"] = "true"),
      (_0x51fa49["innerText"] = _0x83301c),
      Object["assign"](_0x51fa49["style"], {
        border: "1px\x20solid\x20#ccc",
        borderRadius: "4px",
        padding: "4px",
        marginRight: "6px",
        minWidth: "40px",
        display: "inline-block",
        color: "#666",
      }),
      _0x51fa49["addEventListener"]("focus", () => {
        _0x51fa49["innerText"] === _0x83301c &&
          ((_0x51fa49["innerText"] = ""),
          (_0x51fa49["style"]["color"] = "#000"));
      }),
      _0x51fa49["addEventListener"]("blur", () => {
        "" === _0x51fa49["innerText"]["trim"]() &&
          ((_0x51fa49["innerText"] = _0x83301c),
          (_0x51fa49["style"]["color"] = "#666"));
      }),
      _0x51fa49
    );
  }
  const _0x2f72ab = _0x5e9d30("City"),
    _0x1df99c = _0x5e9d30("State"),
    _0x3bd316 = _0x5e9d30("ZIP\x20Code");
  _0x4b435a["append"](_0x2f72ab, _0x1df99c, _0x3bd316);
  const _0x1fcade = document["createElement"]("div");
  _0x1fcade["className"] = "phone\x20ship-itm";
  const _0x7a2994 = document["createElement"]("div");
  ((_0x7a2994["className"] = "info-value"),
    (_0x7a2994["contentEditable"] = "true"),
    (_0x7a2994["innerText"] = "Phone"),
    Object["assign"](_0x7a2994["style"], {
      border: "1px\x20solid\x20#ccc",
      borderRadius: "4px",
      padding: "6px",
      minHeight: "18px",
      color: "#666",
    }),
    _0x7a2994["addEventListener"]("focus", () => {
      "Phone" === _0x7a2994["innerText"] &&
        ((_0x7a2994["innerText"] = ""), (_0x7a2994["style"]["color"] = "#000"));
    }),
    _0x7a2994["addEventListener"]("blur", () => {
      "" === _0x7a2994["innerText"]["trim"]() &&
        ((_0x7a2994["innerText"] = "Phone"),
        (_0x7a2994["style"]["color"] = "#666"));
    }),
    _0x1fcade["appendChild"](_0x7a2994),
    _0x2ac471["append"](_0x268029, _0x37f174, _0x5ad4be, _0x4b435a, _0x288bbc),
    _0x3458d6["appendChild"](_0x2ac471),
    _0x3458d6["appendChild"](_0x1fcade),
    _0x5b6666["appendChild"](_0x3458d6));
  const _0xe93404 = document["createElement"]("button");
  return (
    (_0xe93404["textContent"] = "Save"),
    Object["assign"](_0xe93404["style"], {
      padding: "8px\x2012px",
      background: "#28a745",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
      marginTop: "6px",
    }),
    _0xe93404["addEventListener"]("click", () => {
      const _0x2c6d30 = _0x3b1a6d();
      chrome["storage"]["local"]["set"](
        { poshmark_ship_to_address: _0x2c6d30 },
        () => {
          (console["log"]("Saved\x20to\x20storage:", _0x2c6d30),
            alert("Address\x20saved!"));
        },
      );
    }),
    _0x5b6666["appendChild"](_0xe93404),
    _0x5b6666
  );
}
async function populateUSAddressForm() {
  const { poshmark_ship_to_address: _0x552dea } = await chrome["storage"][
    "local"
  ]["get"]("poshmark_ship_to_address");
  if (!_0x552dea) return;
  const _0xf9e470 = document["querySelector"](".shipping-address\x20.address");
  if (!_0xf9e470) return;
  const _0x48dc56 = Array["from"](_0xf9e470["childNodes"]);
  ((_0x48dc56[0x0]["innerText"] = _0x552dea["name"] || ""),
    (_0x48dc56[0x1]["innerText"] = _0x552dea["address"]["line_1"] || ""),
    (_0x48dc56[0x2]["innerText"] = _0x552dea["address"]["line_2"] || ""));
  const _0x538b73 = _0x48dc56[0x3]["querySelectorAll"](".copy-to-clipboard");
  _0x538b73["length"] >= 0x3 &&
    ((_0x538b73[0x0]["innerText"] = _0x552dea["address"]["city"] || ""),
    (_0x538b73[0x1]["innerText"] = _0x552dea["address"]["state"] || ""),
    (_0x538b73[0x2]["innerText"] = _0x552dea["address"]["zip"] || ""));
  _0x48dc56[0x4]["innerText"] = _0x552dea["address"]["country"] || "";
  const _0x447dd9 = document["querySelector"](".phone.ship-itm\x20.info-value");
  _0x447dd9 && (_0x447dd9["innerText"] = _0x552dea["phone"] || "");
}
