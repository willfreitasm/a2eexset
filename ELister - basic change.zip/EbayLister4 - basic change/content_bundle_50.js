(console["log"]("EcomSniper\x20content\x20script\x20loaded"),
  window["addEventListener"]("message", (_0x3f638d) => {
    (console["log"](
      "EcomSniper\x20content\x20script\x20received\x20message",
      _0x3f638d["data"],
    ),
      _0x3f638d["source"] === window &&
        _0x3f638d["data"] &&
        "FROM_PAGE" === _0x3f638d["data"]["type"] &&
        (console["log"](
          "EcomSniper\x20content\x20script\x20received\x20message",
          _0x3f638d["data"]["payload"],
        ),
        chrome["runtime"]["sendMessage"](
          _0x3f638d["data"]["payload"],
          (_0x10d98e) => {
            window["postMessage"](
              { type: "FROM_EXTENSION", payload: _0x10d98e },
              "*",
            );
          },
        )));
  }));
