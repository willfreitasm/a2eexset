// Bulk Snipe Lister - Main Automation Logic

class BulkSnipeLister {
  constructor() {
    this.ebayLinks = [];
    this.currentPosition = 0;
    this.isRunning = false;
    this.isPaused = false;
    this.stats = {
      successful: 0,
      skipped: 0,
      failed: 0,
    };
    this.currentTab = null;
    this.amazonTab = null;
    this.delayBetweenItems = 0; // milliseconds (0 = no delay, start immediately)
    this.closeTabs = true;
    this.maxItemsPerSession = 0; // 0 = unlimited
    this.maxBackgroundListings = 4; // Max eBay listings completing in background
    this.backgroundListings = 0; // Track how many eBay listings are finishing in background
    this.skipVero = false; // Skip VERO protected items
    this.skipDuplicate = false; // Skip duplicate items
    this.skipLowStock = false; // Skip low stock items (1-3 in stock)
    this.markdownPercentage = 10; // Markdown sale percentage (default 10%)
    this.listingFeePercentage = 15; // eBay listing fee percentage (default 15%)
    this.salesTaxPercentage = 6.5; // Amazon sales tax percentage (default 6.5%)

    this.initializeUI();
    this.loadSettings();
    this.loadSavedState();
    this.loadFromStorage();
  }

  initializeUI() {
    // Get UI elements
    this.textarea = document.getElementById("ebay-links");
    this.startBtn = document.getElementById("start-btn");
    this.clearBtn = document.getElementById("clear-btn");
    this.resetBtn = document.getElementById("reset-btn");
    this.pauseBtn = document.getElementById("pause_button");
    this.resumeBtn = document.getElementById("resume_button");
    this.positionInput = document.getElementById("position-input");
    this.totalLabel = document.getElementById("total-links-label");
    this.statusBtn = document.getElementById("status-report");
    this.closeTabsCheckbox = document.getElementById("close-tabs");
    this.delayInput = document.getElementById("skip-delay");
    this.maxItemsInput = document.getElementById("max-items-per-session");
    this.maxSimultaneousInput = document.getElementById("max-simultaneous");
    this.skipVeroCheckbox = document.getElementById("skip-vero");
    this.skipDuplicateCheckbox = document.getElementById("skip-duplicate");
    this.skipLowStockCheckbox = document.getElementById("skip-low-stock");
    this.markdownInput = document.getElementById("markdown-percentage");
    this.listingFeeInput = document.getElementById("listing-fee-percentage");
    this.salesTaxInput = document.getElementById("sales-tax-percentage");
    this.logOutput = document.getElementById("log-output");

    // Set up event listeners
    this.startBtn.addEventListener("click", () => this.start());
    this.clearBtn.addEventListener("click", () => this.clear());
    this.resetBtn.addEventListener("click", () => this.reset());
    this.pauseBtn.addEventListener("click", () => this.pause());
    this.resumeBtn.addEventListener("click", () => this.resume());
    this.statusBtn.addEventListener("click", () => this.showStatus());
    this.closeTabsCheckbox.addEventListener("change", (e) => {
      this.closeTabs = e.target.checked;
    });
    this.delayInput.addEventListener("change", (e) => {
      this.delayBetweenItems = parseInt(e.target.value) * 1000;
    });
    this.maxItemsInput.addEventListener("change", (e) => {
      this.maxItemsPerSession = parseInt(e.target.value) || 0;
    });
    this.maxSimultaneousInput.addEventListener("change", (e) => {
      this.maxBackgroundListings = parseInt(e.target.value) || 1;
      this.saveSettings();
    });
    this.skipVeroCheckbox.addEventListener("change", (e) => {
      this.skipVero = e.target.checked;
      this.saveSettings();
    });
    this.skipDuplicateCheckbox.addEventListener("change", (e) => {
      this.skipDuplicate = e.target.checked;
      this.saveSettings();
    });
    this.skipLowStockCheckbox.addEventListener("change", (e) => {
      this.skipLowStock = e.target.checked;
      this.saveSettings();
    });
    this.markdownInput.addEventListener("change", (e) => {
      this.markdownPercentage = parseFloat(e.target.value) || 0;
      this.saveSettings();
    });
    this.listingFeeInput.addEventListener("change", (e) => {
      this.listingFeePercentage = parseFloat(e.target.value) || 0;
      this.saveSettings();
    });
    this.salesTaxInput.addEventListener("change", (e) => {
      this.salesTaxPercentage = parseFloat(e.target.value) || 0;
      this.saveSettings();
    });
  }

  saveSettings() {
    chrome.storage.local.set({
      bulk_snipe_settings: {
        skipVero: this.skipVero,
        skipDuplicate: this.skipDuplicate,
        skipLowStock: this.skipLowStock,
        maxBackgroundListings: this.maxBackgroundListings,
        delayBetweenItems: this.delayBetweenItems,
        closeTabs: this.closeTabs,
        maxItemsPerSession: this.maxItemsPerSession,
        markdownPercentage: this.markdownPercentage,
        listingFeePercentage: this.listingFeePercentage,
        salesTaxPercentage: this.salesTaxPercentage,
      },
    });
  }

  loadSettings() {
    chrome.storage.local.get(["bulk_snipe_settings"], (result) => {
      if (result.bulk_snipe_settings) {
        const settings = result.bulk_snipe_settings;
        this.skipVero = settings.skipVero || false;
        this.skipDuplicate = settings.skipDuplicate || false;
        this.skipLowStock = settings.skipLowStock || false;
        this.maxBackgroundListings = settings.maxBackgroundListings || 4;
        this.delayBetweenItems =
          settings.delayBetweenItems !== undefined
            ? settings.delayBetweenItems
            : 0;
        this.closeTabs =
          settings.closeTabs !== undefined ? settings.closeTabs : true;
        this.maxItemsPerSession = settings.maxItemsPerSession || 0;
        this.markdownPercentage =
          settings.markdownPercentage !== undefined
            ? settings.markdownPercentage
            : 10;
        this.listingFeePercentage =
          settings.listingFeePercentage !== undefined
            ? settings.listingFeePercentage
            : 15;
        this.salesTaxPercentage =
          settings.salesTaxPercentage !== undefined
            ? settings.salesTaxPercentage
            : 6.5;

        // Update UI
        this.skipVeroCheckbox.checked = this.skipVero;
        this.skipDuplicateCheckbox.checked = this.skipDuplicate;
        this.skipLowStockCheckbox.checked = this.skipLowStock;
        this.maxSimultaneousInput.value = this.maxBackgroundListings;
        this.delayInput.value = this.delayBetweenItems / 1000;
        this.closeTabsCheckbox.checked = this.closeTabs;
        this.maxItemsInput.value = this.maxItemsPerSession;
        this.markdownInput.value = this.markdownPercentage;
        this.listingFeeInput.value = this.listingFeePercentage;
        this.salesTaxInput.value = this.salesTaxPercentage;
      }
    });
  }

  async loadFromStorage() {
    // Check if items were passed from Sort_Ebay_Items
    chrome.storage.local.get(
      ["bulk_snipe_items", "bulk_snipe_auto_load"],
      (result) => {
        if (result.bulk_snipe_auto_load && result.bulk_snipe_items) {
          this.log(
            "Loaded " +
              result.bulk_snipe_items.length +
              " items from Sort_Ebay_Items",
          );
          this.textarea.value = result.bulk_snipe_items.join("\n");

          // Clear the auto-load flag
          chrome.storage.local.remove(["bulk_snipe_auto_load"]);
        }
      },
    );
  }

  loadSavedState() {
    chrome.storage.local.get(["bulk_snipe_state"], (result) => {
      if (result.bulk_snipe_state) {
        const state = result.bulk_snipe_state;
        this.currentPosition = state.position || 0;
        this.stats = state.stats || { successful: 0, skipped: 0, failed: 0 };
        this.ebayLinks = state.links || [];

        // Restore links to textarea if available
        if (this.ebayLinks.length > 0) {
          this.textarea.value = this.ebayLinks.join("\n");
          this.totalLabel.textContent = this.ebayLinks.length;
        }

        this.updateUI();
        this.log(
          "Loaded saved state - Position: " +
            this.currentPosition +
            "/" +
            this.ebayLinks.length,
        );
      }
    });
  }

  saveState() {
    const state = {
      position: this.currentPosition,
      stats: this.stats,
      links: this.ebayLinks,
    };
    chrome.storage.local.set({ bulk_snipe_state: state });
  }

  start() {
    // Parse links from textarea
    const links = this.textarea.value
      .split("\n")
      .map((link) => link.trim())
      .filter((link) => link.length > 0);

    if (links.length === 0) {
      alert("Please enter at least one eBay item link.");
      return;
    }

    this.ebayLinks = links;
    this.totalLabel.textContent = this.ebayLinks.length;
    this.isRunning = true;
    this.isPaused = false;

    this.log("Starting bulk snipe with " + this.ebayLinks.length + " items");
    this.log("Starting from position: " + this.currentPosition);

    this.processNextItem();
  }

  async processNextItem() {
    if (!this.isRunning || this.isPaused) {
      return;
    }

    // Wait if too many background listings are finishing up
    while (this.backgroundListings >= this.maxBackgroundListings) {
      this.log(
        `Waiting... ${this.backgroundListings} background listings finishing (max: ${this.maxBackgroundListings})`,
      );
      await this.sleep(1000);

      // Check if we should still be running
      if (!this.isRunning || this.isPaused) {
        return;
      }
    }

    // Check if max items per session reached
    if (
      this.maxItemsPerSession > 0 &&
      this.currentPosition >= this.maxItemsPerSession
    ) {
      this.log(
        "Max items per session reached (" + this.maxItemsPerSession + ")",
      );
      this.complete();
      return;
    }

    // Check if all items are done
    if (this.currentPosition >= this.ebayLinks.length) {
      this.log(
        "All items processed! Waiting for background listings to finish...",
      );
      this.complete();
      return;
    }

    // Process one item at a time (sequential)
    const position = this.currentPosition;
    const ebayUrl = this.ebayLinks[position];

    this.currentPosition++;
    this.updateUI();
    this.saveState();

    this.log("-----------------------------------");
    this.log(
      `Starting item ${position + 1}/${this.ebayLinks.length} (Background: ${this.backgroundListings}/${this.maxBackgroundListings})`,
    );
    this.log("eBay URL: " + ebayUrl);

    try {
      await this.processItem(ebayUrl);
    } catch (error) {
      this.log(`ERROR on item ${position + 1}: ${error.message}`);
      this.stats.failed++;
    }

    // Add delay before starting next item (if configured)
    if (this.delayBetweenItems > 0) {
      await this.sleep(this.delayBetweenItems);
    }

    // Immediately start next item (recursive call)
    this.processNextItem();
  }

  async processItem(ebayUrl) {
    // Step 1: Open eBay item page
    this.log("Step 1: Opening eBay item page...");
    const tabId = await this.openEbayTab(ebayUrl);
    this.currentTab = tabId;

    // Step 2: Wait for page load and check for SKU button (combined check)
    this.log("Step 2: Waiting for page to load...");
    const hasSkuButton = await this.waitForSkuButton(tabId);

    if (!hasSkuButton) {
      this.log('SKIPPED: Page did not load properly (Copy Data button not found)');
      this.stats.skipped++;
      if (this.closeTabs) {
        await this.closeTab(tabId);
      }
      return;
    }
    this.log('✓ Page loaded successfully (Copy Data button found)!');

    // Step 4: Click "Copy Data" button
    this.log('Step 4: Clicking "Copy Data" button...');
    await this.clickCopyDataButton(tabId);
    await this.sleep(1000); // Increased from 500ms to 1000ms

    // Step 5: Click "Look up this SKU" button (opens Amazon)
    this.log('Step 5: Clicking "Look up this SKU" button...');
    const amazonTabId = await this.clickLookupSkuButton(tabId);
    this.amazonTab = amazonTabId;

    // Step 6: Wait for Import button to appear (indicates Amazon page is ready)
    this.log("Step 6: Waiting for Amazon page to load...");
    const importReady = await this.waitForImportButton(amazonTabId);
    if (!importReady) {
      this.log("ERROR: Import button not found on Amazon page");
      this.stats.failed++;
      if (this.closeTabs) {
        await this.closeTab(tabId);
        await this.closeTab(amazonTabId);
      }
      return;
    }
    this.log("✓ Amazon page ready!");

    // Step 7: Validate item before importing
    this.log("Step 7: Validating item...");
    const validation = await this.validateItem(amazonTabId);
    if (!validation.valid) {
      this.log(`SKIPPED: ${validation.reason}`);
      this.stats.skipped++;
      if (this.closeTabs) {
        await this.closeTab(tabId);
        await this.closeTab(amazonTabId);
      }
      return;
    }
    this.log("✓ Item passed validation checks");

    // Step 8: Click "Import" button with retry logic
    this.log('Step 8: Clicking "Import" button...');
    const maxImportRetries = 2;
    let importSuccess = false;

    for (let retry = 0; retry <= maxImportRetries; retry++) {
      if (retry > 0) {
        this.log(`Import retry ${retry}/${maxImportRetries}...`);
      }

      await this.clickImportButton(amazonTabId);
      await this.sleep(1000); // Reduced from 3s to 1s since import should be fast

      // Step 9: Check profit margin
      this.log("Step 9: Checking profit margin...");
      const profitCheck = await this.checkProfitMargin(amazonTabId);
      if (!profitCheck.valid) {
        this.log(`SKIPPED: ${profitCheck.reason}`);
        this.stats.skipped++;
        if (this.closeTabs) {
          await this.closeTab(tabId);
          await this.closeTab(amazonTabId);
        }
        return;
      }
      this.log("✓ Item passed profit margin check");

      // Step 10: Check if Snipe-List button becomes enabled (5 second check - import should be fast)
      this.log('Step 10: Waiting for Snipe-List button to be enabled...');
      const buttonEnabled = await this.waitForSnipeListEnabled(amazonTabId, 5000);

      if (buttonEnabled) {
        importSuccess = true;
        this.log("✓ Snipe-List button is enabled!");
        break;
      } else {
        this.log("✗ Snipe-List button did not become enabled");
        if (retry < maxImportRetries) {
          this.log("Will retry Import button...");
        }
      }
    }

    if (!importSuccess) {
      this.log("ERROR: Import failed after " + (maxImportRetries + 1) + " attempts");
      this.stats.failed++;
      if (this.closeTabs) {
        await this.closeTab(tabId);
        await this.closeTab(amazonTabId);
      }
      return;
    }

    // Step 11: Click "Snipe-List" button
    this.log('Step 11: Clicking "Snipe-List" button...');
    await this.clickSnipeListButton(amazonTabId);
    await this.sleep(1000); // Added delay to ensure button click is processed

    // Step 12: Wait for eBay listing tab to be created
    this.log("Step 12: Waiting for eBay listing tab to be created...");
    const ebayListingTabId = await this.waitForEbayListingTab();

    // ✅ AT THIS POINT: eBay listing page is open, safe to start next item!
    this.log("✅ eBay listing page opened! Starting background cleanup...");
    this.stats.successful++;

    // Increment background listing count
    this.backgroundListings++;
    this.updateUI();
    this.log(
      `Background listings count: ${this.backgroundListings}/${this.maxBackgroundListings}`,
    );

    // Continue in background: wait for completion and cleanup
    this.cleanupItemAsync(tabId, amazonTabId, ebayListingTabId);
  }

  async cleanupItemAsync(ebayItemTabId, amazonTabId, ebayListingTabId) {
    // This runs in background while next item starts
    try {
      // Wait for eBay listing to be FULLY COMPLETE before closing Amazon
      if (ebayListingTabId) {
        this.log("Background: Waiting for eBay listing to be fully saved...");
        await this.waitForEbayListingComplete(ebayListingTabId);
        this.log("Background: eBay listing is complete!");
      } else {
        this.log(
          "Background: Could not detect eBay listing tab, waiting extra time before cleanup...",
        );
        await this.sleep(30000); // Wait 30 seconds if tab not detected (increased from 10s)
      }

      // Now that eBay listing is COMPLETE, we can close Amazon page
      this.log("Background: Closing tabs...");

      // Close tabs if enabled
      if (this.closeTabs) {
        await this.closeTab(ebayItemTabId); // Close eBay item page
        await this.closeTab(amazonTabId); // Close Amazon page
        if (ebayListingTabId) {
          await this.closeTab(ebayListingTabId); // Close eBay listing page
        }
      }
    } catch (error) {
      this.log("Background cleanup error: " + error.message);
    } finally {
      // Decrement background listing count
      this.backgroundListings--;
      this.updateUI();
      this.log(
        `Background cleanup finished. Background listings: ${this.backgroundListings}/${this.maxBackgroundListings}`,
      );
    }
  }

  // Helper methods for automation steps

  openEbayTab(url) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          type: "bulk_snipe_open_ebay_item",
          url: url,
        },
        (response) => {
          if (response && response.tabId) {
            resolve(response.tabId);
          } else {
            reject(new Error("Failed to open eBay tab"));
          }
        },
      );
    });
  }

  waitForPageLoad(tabId) {
    return new Promise((resolve) => {
      let checkCount = 0;
      const maxChecks = 240; // 120 seconds max wait
      let stableCount = 0;
      let loadingCount = 0; // Track how long page has been loading
      let hasReloaded = false; // Track if we've already reloaded once

      const checkLoaded = () => {
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            this.log("Page load: Tab closed or error");
            resolve();
            return;
          }

          if (tab.status === "complete") {
            stableCount++;
            loadingCount = 0; // Reset loading counter when complete
            // Wait for status to be stable for at least 2 checks (1 second)
            if (stableCount >= 2) {
              this.log("Page load: Complete and stable");
              resolve();
              return;
            }
          } else if (tab.status === "loading") {
            stableCount = 0;
            loadingCount++;

            // If page has been loading for 30 seconds (60 checks * 500ms) and we haven't reloaded yet
            if (loadingCount >= 60 && !hasReloaded) {
              this.log(
                "Page load: Page stuck loading for 30 seconds, reloading once...",
              );
              hasReloaded = true;
              loadingCount = 0;

              // Reload the page
              chrome.tabs.reload(tabId, {}, () => {
                if (chrome.runtime.lastError) {
                  this.log(
                    "Page load: Reload failed - " +
                      chrome.runtime.lastError.message,
                  );
                } else {
                  this.log("Page load: Page reloaded, waiting for it to load...");
                }
                // Continue checking after reload
                setTimeout(checkLoaded, 500);
              });
              return;
            }
          } else {
            stableCount = 0;
            loadingCount = 0;
          }

          checkCount++;
          if (checkCount >= maxChecks) {
            this.log("Page load: Timeout reached, assuming loaded");
            resolve();
            return;
          }

          setTimeout(checkLoaded, 500);
        });
      };
      checkLoaded();
    });
  }

  waitForSkuButton(tabId) {
    return new Promise((resolve) => {
      let checkCount = 0;
      const maxChecks = 60; // 30 seconds max (check every 500ms)
      let hasReloaded = false;

      const checkButton = () => {
        // First check if tab still exists
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            this.log("Page load: Tab closed or error");
            resolve(false);
            return;
          }

          // Check if page is stuck loading for 30 seconds
          if (tab.status === "loading" && checkCount >= 60 && !hasReloaded) {
            this.log("Page load: Page stuck loading for 30 seconds, reloading once...");
            hasReloaded = true;
            checkCount = 0;
            chrome.tabs.reload(tabId, {}, () => {
              if (chrome.runtime.lastError) {
                this.log("Page load: Reload failed - " + chrome.runtime.lastError.message);
              } else {
                this.log("Page load: Page reloaded, waiting for it to load...");
              }
              setTimeout(checkButton, 500);
            });
            return;
          }

          // Check for the Copy Data button (always present when page loads)
          chrome.tabs.sendMessage(
            tabId,
            { type: "bulk_snipe_check_sku" },
            (response) => {
              if (chrome.runtime.lastError) {
                // Content script not ready yet, continue checking
                checkCount++;
                if (checkCount >= 120) {
                  // 60 seconds total timeout
                  this.log("Timeout: Copy Data button not found after 60 seconds");
                  resolve(false);
                  return;
                }
                setTimeout(checkButton, 500);
                return;
              }

              if (response && response.exists) {
                // Found the button - page is ready!
                resolve(true);
                return;
              }

              // Button not found yet, keep checking
              checkCount++;
              if (checkCount >= 120) {
                // 60 seconds total timeout
                this.log("Timeout: Copy Data button not found after 60 seconds");
                resolve(false);
                return;
              }

              setTimeout(checkButton, 500);
            },
          );
        });
      };

      checkButton();
    });
  }

  checkForSkuButton(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_check_sku" },
        (response) => {
          resolve(response && response.exists);
        },
      );
    });
  }

  waitForImportButton(tabId) {
    return new Promise((resolve) => {
      let checkCount = 0;
      const maxChecks = 60; // 30 seconds max (check every 500ms)

      const checkButton = () => {
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            this.log("Amazon page: Tab closed or error");
            resolve(false);
            return;
          }

          // Check for the Import button
          chrome.tabs.sendMessage(
            tabId,
            { type: "bulk_snipe_check_import_exists" },
            (response) => {
              if (chrome.runtime.lastError) {
                // Content script not ready yet, continue checking
                checkCount++;
                if (checkCount >= maxChecks) {
                  this.log("Timeout: Import button not found after 30 seconds");
                  resolve(false);
                  return;
                }
                setTimeout(checkButton, 500);
                return;
              }

              if (response && response.exists) {
                // Found the button - page is ready!
                resolve(true);
                return;
              }

              // Button not found yet, keep checking
              checkCount++;
              if (checkCount >= maxChecks) {
                this.log("Timeout: Import button not found after 30 seconds");
                resolve(false);
                return;
              }

              setTimeout(checkButton, 500);
            },
          );
        });
      };

      checkButton();
    });
  }

  clickCopyDataButton(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, { type: "bulk_snipe_click_copy" }, () => {
        resolve();
      });
    });
  }

  clickLookupSkuButton(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_click_lookup" },
        (response) => {
          if (response && response.amazonTabId) {
            resolve(response.amazonTabId);
          } else {
            reject(new Error("Failed to get Amazon tab ID"));
          }
        },
      );
    });
  }

  validateItem(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tabId,
        {
          type: "bulk_snipe_validate_item",
          skipVero: this.skipVero,
          skipDuplicate: this.skipDuplicate,
          skipLowStock: this.skipLowStock,
        },
        (response) => {
          if (response) {
            resolve(response);
          } else {
            // If validation fails, assume valid to not block processing
            resolve({ valid: true, reason: null });
          }
        },
      );
    });
  }

  checkProfitMargin(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tabId,
        {
          type: "bulk_snipe_check_profit",
          markdownPercentage: this.markdownPercentage,
          listingFeePercentage: this.listingFeePercentage,
          salesTaxPercentage: this.salesTaxPercentage,
        },
        (response) => {
          if (chrome.runtime.lastError) {
            this.log(
              "Profit check error: " + chrome.runtime.lastError.message,
            );
            // If check fails, assume valid to not block processing
            resolve({ valid: true, reason: null });
            return;
          }

          if (response) {
            resolve(response);
          } else {
            // If response is empty, assume valid
            resolve({ valid: true, reason: null });
          }
        },
      );
    });
  }

  waitForSnipeListEnabled(tabId, timeout = 5000) {
    return new Promise((resolve) => {
      const startTime = Date.now();
      const checkInterval = 500; // Check every 500ms for faster detection

      const checkEnabled = () => {
        chrome.tabs.sendMessage(
          tabId,
          { type: "bulk_snipe_check_snipe_enabled" },
          (response) => {
            if (chrome.runtime.lastError) {
              // Tab might be closed or content script not ready
              resolve(false);
              return;
            }

            if (response && response.enabled) {
              // Button is enabled!
              resolve(true);
              return;
            }

            // Check if timeout reached
            if (Date.now() - startTime >= timeout) {
              resolve(false);
              return;
            }

            // Continue checking
            setTimeout(checkEnabled, checkInterval);
          },
        );
      };

      checkEnabled();
    });
  }

  clickImportButton(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_click_import" },
        (response) => {
          if (chrome.runtime.lastError) {
            this.log(
              "Import button click error: " + chrome.runtime.lastError.message,
            );
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success) {
            this.log("✓ Import button clicked successfully");
            resolve();
          } else {
            const reason = response?.reason || "Unknown error";
            this.log("✗ Failed to click Import button: " + reason);
            reject(new Error("Failed to click Import button: " + reason));
          }
        },
      );
    });
  }

  clickSnipeListButton(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_click_snipe" },
        (response) => {
          if (chrome.runtime.lastError) {
            this.log(
              "Snipe-List button click error: " +
                chrome.runtime.lastError.message,
            );
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success) {
            this.log("✓ Snipe-List button clicked successfully");
            resolve();
          } else {
            const reason = response?.reason || "Unknown error";
            this.log("✗ Failed to click Snipe-List button: " + reason);
            reject(new Error("Failed to click Snipe-List button: " + reason));
          }
        },
      );
    });
  }

  waitForEbayListingTab() {
    return new Promise((resolve) => {
      let ebayListingTabId = null;
      let challengeTabId = null; // Track tab that hits challenge screen
      let timeoutId = null;

      // Listen for new tabs
      const tabListener = (tabId, changeInfo, tab) => {
        if (!tab.url || !tab.url.includes("ebay.")) return;

        // Check if we hit the challenge/rate limit screen
        if (tab.url.includes("/splashui/challenge")) {
          if (!challengeTabId) {
            challengeTabId = tabId;
            this.log(
              "eBay challenge screen detected on tab: " +
                tabId +
                " - waiting for auto-redirect...",
            );
          }
          return; // Don't resolve yet, wait for redirect
        }

        // Check if this is the listing page (or the challenge tab redirected to listing)
        if (
          tab.url.includes("/sl/") ||
          tab.url.includes("/lstng") ||
          (challengeTabId === tabId &&
            tab.url.includes("/itm/") &&
            !tab.url.includes("/splashui/"))
        ) {
          // Found the eBay listing tab (or challenge resolved to listing)
          if (!ebayListingTabId) {
            ebayListingTabId = tabId;
            this.log(
              "Found eBay listing tab: " + tabId + " (URL: " + tab.url + ")",
            );

            // Remove listener and resolve immediately
            chrome.tabs.onUpdated.removeListener(tabListener);
            if (timeoutId) clearTimeout(timeoutId);
            resolve(ebayListingTabId);
          }
        }
      };

      chrome.tabs.onUpdated.addListener(tabListener);

      // Timeout after 180 seconds (3 minutes) - increased to handle challenge screens and slow listings
      timeoutId = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(tabListener);
        this.log(
          "Background: Timeout waiting for eBay listing tab after 180 seconds",
        );
        // If we tracked a challenge tab but never saw it resolve, return it anyway
        resolve(ebayListingTabId || challengeTabId);
      }, 180000);
    });
  }

  waitForEbayListingComplete(ebayTabId) {
    return new Promise((resolve) => {
      let messageReceived = false;
      let timeoutId = null;

      // Set up message listener for itemListed/itemFailed (same as bulk list tool)
      const messageListener = (message, sender, sendResponse) => {
        // Only listen to messages from the eBay listing tab
        if (sender.tab && sender.tab.id === ebayTabId) {
          if (message.type === "itemListed") {
            this.log(
              "Background: ✓ Received itemListed message - listing submitted successfully!",
            );
            messageReceived = true;
            chrome.runtime.onMessage.removeListener(messageListener);
            if (timeoutId) clearTimeout(timeoutId);
            resolve();
          } else if (message.type === "itemFailed") {
            this.log(
              "Background: ✗ Received itemFailed message - listing failed: " +
                (message.message || "Unknown error"),
            );
            messageReceived = true;
            chrome.runtime.onMessage.removeListener(messageListener);
            if (timeoutId) clearTimeout(timeoutId);
            resolve(); // Still resolve to allow cleanup
          }
        }
      };

      chrome.runtime.onMessage.addListener(messageListener);

      // Fallback: if no message received after 5 minutes, assume complete
      timeoutId = setTimeout(() => {
        if (!messageReceived) {
          this.log(
            "Background: Timeout waiting for listing completion message (5 minutes), assuming complete",
          );
          chrome.runtime.onMessage.removeListener(messageListener);
          resolve();
        }
      }, 300000); // 5 minutes

      // Also monitor tab closure as a completion signal
      const checkTabClosed = () => {
        chrome.tabs.get(ebayTabId, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            if (!messageReceived) {
              this.log(
                "Background: eBay listing tab closed, assuming complete",
              );
              chrome.runtime.onMessage.removeListener(messageListener);
              if (timeoutId) clearTimeout(timeoutId);
              resolve();
            }
          } else if (!messageReceived) {
            // Tab still exists and no message yet, check again
            setTimeout(checkTabClosed, 2000);
          }
        });
      };

      // Start monitoring tab closure
      setTimeout(checkTabClosed, 2000);
    });
  }

  waitForListingComplete(tabId) {
    return new Promise((resolve) => {
      // Wait up to 30 seconds for completion
      let attempts = 0;
      const maxAttempts = 60;

      const checkComplete = () => {
        chrome.tabs.sendMessage(
          tabId,
          { type: "bulk_snipe_check_complete" },
          (response) => {
            if (response && response.complete) {
              resolve();
            } else if (attempts++ < maxAttempts) {
              setTimeout(checkComplete, 500);
            } else {
              // Timeout - assume complete
              resolve();
            }
          },
        );
      };
      checkComplete();
    });
  }

  closeTab(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.remove(tabId, () => {
        resolve();
      });
    });
  }

  sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // UI Control methods

  pause() {
    this.isPaused = true;
    this.log("PAUSED");
  }

  resume() {
    if (this.isPaused) {
      this.isPaused = false;
      this.log("RESUMED");
      this.processNextItem();
    }
  }

  clear() {
    this.textarea.value = "";
    this.ebayLinks = [];
    this.totalLabel.textContent = "0";
    this.log("Cleared all links");
  }

  reset() {
    this.isRunning = false;
    this.isPaused = false;
    this.currentPosition = 0;
    this.stats = { successful: 0, skipped: 0, failed: 0 };
    this.updateUI();
    this.saveState();
    this.log("RESET: All progress cleared");

    // Close current tab if exists
    if (this.currentTab) {
      this.closeTab(this.currentTab);
      this.currentTab = null;
    }
  }

  complete() {
    this.isRunning = false;

    // Check every second if all background listings are done
    const checkComplete = () => {
      if (this.backgroundListings === 0) {
        this.log("===============================");
        this.log("BULK SNIPE COMPLETED!");
        this.log("Total: " + this.ebayLinks.length);
        this.log("Successful: " + this.stats.successful);
        this.log("Skipped: " + this.stats.skipped);
        this.log("Failed: " + this.stats.failed);
        this.log("===============================");
        alert(
          "Bulk Snipe Complete!\nSuccessful: " +
            this.stats.successful +
            "\nSkipped: " +
            this.stats.skipped +
            "\nFailed: " +
            this.stats.failed,
        );
      } else {
        this.log(
          "Waiting for " +
            this.backgroundListings +
            " background listings to finish...",
        );
        setTimeout(checkComplete, 1000);
      }
    };

    checkComplete();
  }

  showStatus() {
    alert(
      `Current Status:\nPosition: ${this.currentPosition}/${this.ebayLinks.length}\nSuccessful: ${this.stats.successful}\nSkipped: ${this.stats.skipped}\nFailed: ${this.stats.failed}\nRunning: ${this.isRunning}\nPaused: ${this.isPaused}`,
    );
  }

  updateUI() {
    this.positionInput.value = this.currentPosition;
    document.getElementById("successful-listings").textContent =
      this.stats.successful;
    document.getElementById("skipped-listings").textContent =
      this.stats.skipped;
    document.getElementById("failed-listings").textContent = this.stats.failed;
    document.getElementById("currently-processing").textContent =
      this.backgroundListings;

    // Update progress bar
    const progress =
      this.ebayLinks.length > 0
        ? (this.currentPosition / this.ebayLinks.length) * 100
        : 0;
    const progressBar = document.getElementById("progress-bar");
    const progressPercentages = document.querySelectorAll(
      ".progress-percentage",
    );

    progressBar.style.width = progress + "%";
    progressPercentages.forEach((el) => {
      el.textContent = Math.round(progress) + "%";
    });
  }

  log(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}`;
    console.log(logEntry);

    if (this.logOutput) {
      this.logOutput.innerHTML += logEntry + "<br>";
      this.logOutput.scrollTop = this.logOutput.scrollHeight;
    }
  }
}

// Initialize when page loads
document.addEventListener("DOMContentLoaded", () => {
  window.bulkSnipeLister = new BulkSnipeLister();
});
