// Bulk Snipe Lister - Main Automation Logic

class BulkSnipeLister {
  constructor() {
    this.ebayLinks = [];
    this.currentPosition = 0;
    this.isRunning = false;
    this.isPaused = false;
    this.stats = {
      successful: 0,
      skipped: 0,
      failed: 0,
    };
    this.currentTab = null;
    this.amazonTab = null;
    this.delayBetweenItems = 0; // milliseconds (0 = no delay, start immediately)
    this.closeTabs = true;
    this.maxItemsPerSession = 0; // 0 = unlimited
    this.maxBackgroundListings = 4; // Max eBay listings completing in background
    this.backgroundListings = 0; // Track how many eBay listings are finishing in background
    this.skipVero = false; // Skip VERO protected items
    this.skipDuplicate = false; // Skip duplicate items
    this.skipLowStock = false; // Skip low stock items (1-3 in stock)

    this.initializeUI();
    this.loadSettings();
    this.loadSavedState();
    this.loadFromStorage();
  }

  initializeUI() {
    // Get UI elements
    this.textarea = document.getElementById("ebay-links");
    this.startBtn = document.getElementById("start-btn");
    this.clearBtn = document.getElementById("clear-btn");
    this.resetBtn = document.getElementById("reset-btn");
    this.pauseBtn = document.getElementById("pause_button");
    this.resumeBtn = document.getElementById("resume_button");
    this.positionInput = document.getElementById("position-input");
    this.totalLabel = document.getElementById("total-links-label");
    this.statusBtn = document.getElementById("status-report");
    this.closeTabsCheckbox = document.getElementById("close-tabs");
    this.delayInput = document.getElementById("skip-delay");
    this.maxItemsInput = document.getElementById("max-items-per-session");
    this.maxSimultaneousInput = document.getElementById("max-simultaneous");
    this.skipVeroCheckbox = document.getElementById("skip-vero");
    this.skipDuplicateCheckbox = document.getElementById("skip-duplicate");
    this.skipLowStockCheckbox = document.getElementById("skip-low-stock");
    this.logOutput = document.getElementById("log-output");

    // Set up event listeners
    this.startBtn.addEventListener("click", () => this.start());
    this.clearBtn.addEventListener("click", () => this.clear());
    this.resetBtn.addEventListener("click", () => this.reset());
    this.pauseBtn.addEventListener("click", () => this.pause());
    this.resumeBtn.addEventListener("click", () => this.resume());
    this.statusBtn.addEventListener("click", () => this.showStatus());
    this.closeTabsCheckbox.addEventListener("change", (e) => {
      this.closeTabs = e.target.checked;
    });
    this.delayInput.addEventListener("change", (e) => {
      this.delayBetweenItems = parseInt(e.target.value) * 1000;
    });
    this.maxItemsInput.addEventListener("change", (e) => {
      this.maxItemsPerSession = parseInt(e.target.value) || 0;
    });
    this.maxSimultaneousInput.addEventListener("change", (e) => {
      this.maxBackgroundListings = parseInt(e.target.value) || 1;
      this.saveSettings();
    });
    this.skipVeroCheckbox.addEventListener("change", (e) => {
      this.skipVero = e.target.checked;
      this.saveSettings();
    });
    this.skipDuplicateCheckbox.addEventListener("change", (e) => {
      this.skipDuplicate = e.target.checked;
      this.saveSettings();
    });
    this.skipLowStockCheckbox.addEventListener("change", (e) => {
      this.skipLowStock = e.target.checked;
      this.saveSettings();
    });
  }

  saveSettings() {
    chrome.storage.local.set({
      bulk_snipe_settings: {
        skipVero: this.skipVero,
        skipDuplicate: this.skipDuplicate,
        skipLowStock: this.skipLowStock,
        maxBackgroundListings: this.maxBackgroundListings,
        delayBetweenItems: this.delayBetweenItems,
        closeTabs: this.closeTabs,
        maxItemsPerSession: this.maxItemsPerSession,
      },
    });
  }

  loadSettings() {
    chrome.storage.local.get(["bulk_snipe_settings"], (result) => {
      if (result.bulk_snipe_settings) {
        const settings = result.bulk_snipe_settings;
        this.skipVero = settings.skipVero || false;
        this.skipDuplicate = settings.skipDuplicate || false;
        this.skipLowStock = settings.skipLowStock || false;
        this.maxBackgroundListings = settings.maxBackgroundListings || 4;
        this.delayBetweenItems =
          settings.delayBetweenItems !== undefined
            ? settings.delayBetweenItems
            : 0;
        this.closeTabs =
          settings.closeTabs !== undefined ? settings.closeTabs : true;
        this.maxItemsPerSession = settings.maxItemsPerSession || 0;

        // Update UI
        this.skipVeroCheckbox.checked = this.skipVero;
        this.skipDuplicateCheckbox.checked = this.skipDuplicate;
        this.skipLowStockCheckbox.checked = this.skipLowStock;
        this.maxSimultaneousInput.value = this.maxBackgroundListings;
        this.delayInput.value = this.delayBetweenItems / 1000;
        this.closeTabsCheckbox.checked = this.closeTabs;
        this.maxItemsInput.value = this.maxItemsPerSession;
      }
    });
  }

  async loadFromStorage() {
    // Check if items were passed from Sort_Ebay_Items
    chrome.storage.local.get(
      ["bulk_snipe_items", "bulk_snipe_auto_load"],
      (result) => {
        if (result.bulk_snipe_auto_load && result.bulk_snipe_items) {
          this.log(
            "Loaded " +
              result.bulk_snipe_items.length +
              " items from Sort_Ebay_Items",
          );
          this.textarea.value = result.bulk_snipe_items.join("\n");

          // Clear the auto-load flag
          chrome.storage.local.remove(["bulk_snipe_auto_load"]);
        }
      },
    );
  }

  loadSavedState() {
    chrome.storage.local.get(["bulk_snipe_state"], (result) => {
      if (result.bulk_snipe_state) {
        const state = result.bulk_snipe_state;
        this.currentPosition = state.position || 0;
        this.stats = state.stats || { successful: 0, skipped: 0, failed: 0 };
        this.ebayLinks = state.links || [];

        // Restore links to textarea if available
        if (this.ebayLinks.length > 0) {
          this.textarea.value = this.ebayLinks.join("\n");
          this.totalLabel.textContent = this.ebayLinks.length;
        }

        this.updateUI();
        this.log(
          "Loaded saved state - Position: " +
            this.currentPosition +
            "/" +
            this.ebayLinks.length,
        );
      }
    });
  }

  saveState() {
    const state = {
      position: this.currentPosition,
      stats: this.stats,
      links: this.ebayLinks,
    };
    chrome.storage.local.set({ bulk_snipe_state: state });
  }

  start() {
    // Parse links from textarea
    const links = this.textarea.value
      .split("\n")
      .map((link) => link.trim())
      .filter((link) => link.length > 0);

    if (links.length === 0) {
      alert("Please enter at least one eBay item link.");
      return;
    }

    this.ebayLinks = links;
    this.totalLabel.textContent = this.ebayLinks.length;
    this.isRunning = true;
    this.isPaused = false;

    this.log("Starting bulk snipe with " + this.ebayLinks.length + " items");
    this.log("Starting from position: " + this.currentPosition);

    this.processNextItem();
  }

  async processNextItem() {
    if (!this.isRunning || this.isPaused) {
      return;
    }

    // Wait if too many background listings are finishing up
    while (this.backgroundListings >= this.maxBackgroundListings) {
      this.log(
        `Waiting... ${this.backgroundListings} background listings finishing (max: ${this.maxBackgroundListings})`,
      );
      await this.sleep(1000);

      // Check if we should still be running
      if (!this.isRunning || this.isPaused) {
        return;
      }
    }

    // Check if max items per session reached
    if (
      this.maxItemsPerSession > 0 &&
      this.currentPosition >= this.maxItemsPerSession
    ) {
      this.log(
        "Max items per session reached (" + this.maxItemsPerSession + ")",
      );
      this.complete();
      return;
    }

    // Check if all items are done
    if (this.currentPosition >= this.ebayLinks.length) {
      this.log(
        "All items processed! Waiting for background listings to finish...",
      );
      this.complete();
      return;
    }

    // Process one item at a time (sequential)
    const position = this.currentPosition;
    const ebayUrl = this.ebayLinks[position];

    this.currentPosition++;
    this.updateUI();
    this.saveState();

    this.log("-----------------------------------");
    this.log(
      `Starting item ${position + 1}/${this.ebayLinks.length} (Background: ${this.backgroundListings}/${this.maxBackgroundListings})`,
    );
    this.log("eBay URL: " + ebayUrl);

    try {
      await this.processItem(ebayUrl);
    } catch (error) {
      this.log(`ERROR on item ${position + 1}: ${error.message}`);
      this.stats.failed++;
    }

    // Add delay before starting next item (if configured)
    if (this.delayBetweenItems > 0) {
      await this.sleep(this.delayBetweenItems);
    }

    // Immediately start next item (recursive call)
    this.processNextItem();
  }

  async processItem(ebayUrl) {
    // Step 1: Open eBay item page
    this.log("Step 1: Opening eBay item page...");
    const tabId = await this.openEbayTab(ebayUrl);
    this.currentTab = tabId;

    // Step 2: Wait for page load
    this.log("Step 2: Waiting for page load...");
    await this.waitForPageLoad(tabId);

    // Step 3: Check for "Look up this SKU" button
    this.log('Step 3: Checking for "Look up this SKU" button...');
    const hasSkuButton = await this.checkForSkuButton(tabId);

    if (!hasSkuButton) {
      this.log('SKIPPED: No "Look up this SKU" button found (not from tool)');
      this.stats.skipped++;
      if (this.closeTabs) {
        await this.closeTab(tabId);
      }
      return;
    }

    // Step 4: Click "Copy Data" button
    this.log('Step 4: Clicking "Copy Data" button...');
    await this.clickCopyDataButton(tabId);
    await this.sleep(1000); // Increased from 500ms to 1000ms

    // Step 5: Click "Look up this SKU" button (opens Amazon)
    this.log('Step 5: Clicking "Look up this SKU" button...');
    const amazonTabId = await this.clickLookupSkuButton(tabId);
    this.amazonTab = amazonTabId;

    // Step 6: Wait for Amazon page load
    this.log("Step 6: Waiting for Amazon page load...");
    await this.waitForPageLoad(amazonTabId);
    await this.sleep(2000); // Increased from 1000ms to 2000ms to ensure page is fully loaded

    // Step 7: Validate item before importing
    this.log("Step 7: Validating item...");
    const validation = await this.validateItem(amazonTabId);
    if (!validation.valid) {
      this.log(`SKIPPED: ${validation.reason}`);
      this.stats.skipped++;
      if (this.closeTabs) {
        await this.closeTab(tabId);
        await this.closeTab(amazonTabId);
      }
      return;
    }
    this.log("✓ Item passed validation checks");

    // Step 8: Click "Import" button
    this.log('Step 8: Clicking "Import" button...');
    await this.clickImportButton(amazonTabId);
    await this.sleep(3000); // Increased from 2000ms to 3000ms to allow import to complete

    // Step 9: Click "Snipe-List" button
    this.log('Step 9: Clicking "Snipe-List" button...');
    await this.clickSnipeListButton(amazonTabId);
    await this.sleep(1000); // Added delay to ensure button click is processed

    // Step 10: Wait for eBay listing tab to be created
    this.log("Step 10: Waiting for eBay listing tab to be created...");
    const ebayListingTabId = await this.waitForEbayListingTab();

    // ✅ AT THIS POINT: eBay listing page is open, safe to start next item!
    this.log("✅ eBay listing page opened! Starting background cleanup...");
    this.stats.successful++;

    // Increment background listing count
    this.backgroundListings++;
    this.updateUI();
    this.log(
      `Background listings count: ${this.backgroundListings}/${this.maxBackgroundListings}`,
    );

    // Continue in background: wait for completion and cleanup
    this.cleanupItemAsync(tabId, amazonTabId, ebayListingTabId);
  }

  async cleanupItemAsync(ebayItemTabId, amazonTabId, ebayListingTabId) {
    // This runs in background while next item starts
    try {
      // Wait for eBay listing to be FULLY COMPLETE before closing Amazon
      if (ebayListingTabId) {
        this.log("Background: Waiting for eBay listing to be fully saved...");
        await this.waitForEbayListingComplete(ebayListingTabId);
        this.log("Background: eBay listing is complete!");
      } else {
        this.log(
          "Background: Could not detect eBay listing tab, waiting extra time before cleanup...",
        );
        await this.sleep(30000); // Wait 30 seconds if tab not detected (increased from 10s)
      }

      // Now that eBay listing is COMPLETE, we can close Amazon page
      this.log("Background: Closing tabs...");

      // Close tabs if enabled
      if (this.closeTabs) {
        await this.closeTab(ebayItemTabId); // Close eBay item page
        await this.closeTab(amazonTabId); // Close Amazon page
        if (ebayListingTabId) {
          await this.closeTab(ebayListingTabId); // Close eBay listing page
        }
      }
    } catch (error) {
      this.log("Background cleanup error: " + error.message);
    } finally {
      // Decrement background listing count
      this.backgroundListings--;
      this.updateUI();
      this.log(
        `Background cleanup finished. Background listings: ${this.backgroundListings}/${this.maxBackgroundListings}`,
      );
    }
  }

  // Helper methods for automation steps

  openEbayTab(url) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          type: "bulk_snipe_open_ebay_item",
          url: url,
        },
        (response) => {
          if (response && response.tabId) {
            resolve(response.tabId);
          } else {
            reject(new Error("Failed to open eBay tab"));
          }
        },
      );
    });
  }

  waitForPageLoad(tabId) {
    return new Promise((resolve) => {
      let checkCount = 0;
      const maxChecks = 240; // 120 seconds max wait
      let stableCount = 0;

      const checkLoaded = () => {
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            this.log("Page load: Tab closed or error");
            resolve();
            return;
          }

          if (tab.status === "complete") {
            stableCount++;
            // Wait for status to be stable for at least 2 checks (1 second)
            if (stableCount >= 2) {
              this.log("Page load: Complete and stable");
              resolve();
              return;
            }
          } else {
            stableCount = 0;
          }

          checkCount++;
          if (checkCount >= maxChecks) {
            this.log("Page load: Timeout reached, assuming loaded");
            resolve();
            return;
          }

          setTimeout(checkLoaded, 500);
        });
      };
      checkLoaded();
    });
  }

  checkForSkuButton(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_check_sku" },
        (response) => {
          resolve(response && response.exists);
        },
      );
    });
  }

  clickCopyDataButton(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, { type: "bulk_snipe_click_copy" }, () => {
        resolve();
      });
    });
  }

  clickLookupSkuButton(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_click_lookup" },
        (response) => {
          if (response && response.amazonTabId) {
            resolve(response.amazonTabId);
          } else {
            reject(new Error("Failed to get Amazon tab ID"));
          }
        },
      );
    });
  }

  validateItem(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(
        tabId,
        {
          type: "bulk_snipe_validate_item",
          skipVero: this.skipVero,
          skipDuplicate: this.skipDuplicate,
          skipLowStock: this.skipLowStock,
        },
        (response) => {
          if (response) {
            resolve(response);
          } else {
            // If validation fails, assume valid to not block processing
            resolve({ valid: true, reason: null });
          }
        },
      );
    });
  }

  clickImportButton(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_click_import" },
        (response) => {
          if (chrome.runtime.lastError) {
            this.log(
              "Import button click error: " + chrome.runtime.lastError.message,
            );
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success) {
            this.log("✓ Import button clicked successfully");
            resolve();
          } else {
            const reason = response?.reason || "Unknown error";
            this.log("✗ Failed to click Import button: " + reason);
            reject(new Error("Failed to click Import button: " + reason));
          }
        },
      );
    });
  }

  clickSnipeListButton(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(
        tabId,
        { type: "bulk_snipe_click_snipe" },
        (response) => {
          if (chrome.runtime.lastError) {
            this.log(
              "Snipe-List button click error: " +
                chrome.runtime.lastError.message,
            );
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success) {
            this.log("✓ Snipe-List button clicked successfully");
            resolve();
          } else {
            const reason = response?.reason || "Unknown error";
            this.log("✗ Failed to click Snipe-List button: " + reason);
            reject(new Error("Failed to click Snipe-List button: " + reason));
          }
        },
      );
    });
  }

  waitForEbayListingTab() {
    return new Promise((resolve) => {
      let ebayListingTabId = null;
      let challengeTabId = null; // Track tab that hits challenge screen
      let timeoutId = null;

      // Listen for new tabs
      const tabListener = (tabId, changeInfo, tab) => {
        if (!tab.url || !tab.url.includes("ebay.")) return;

        // Check if we hit the challenge/rate limit screen
        if (tab.url.includes("/splashui/challenge")) {
          if (!challengeTabId) {
            challengeTabId = tabId;
            this.log(
              "eBay challenge screen detected on tab: " +
                tabId +
                " - waiting for auto-redirect...",
            );
          }
          return; // Don't resolve yet, wait for redirect
        }

        // Check if this is the listing page (or the challenge tab redirected to listing)
        if (
          tab.url.includes("/sl/") ||
          tab.url.includes("/lstng") ||
          (challengeTabId === tabId &&
            tab.url.includes("/itm/") &&
            !tab.url.includes("/splashui/"))
        ) {
          // Found the eBay listing tab (or challenge resolved to listing)
          if (!ebayListingTabId) {
            ebayListingTabId = tabId;
            this.log(
              "Found eBay listing tab: " + tabId + " (URL: " + tab.url + ")",
            );

            // Remove listener and resolve immediately
            chrome.tabs.onUpdated.removeListener(tabListener);
            if (timeoutId) clearTimeout(timeoutId);
            resolve(ebayListingTabId);
          }
        }
      };

      chrome.tabs.onUpdated.addListener(tabListener);

      // Timeout after 180 seconds (3 minutes) - increased to handle challenge screens and slow listings
      timeoutId = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(tabListener);
        this.log(
          "Background: Timeout waiting for eBay listing tab after 180 seconds",
        );
        // If we tracked a challenge tab but never saw it resolve, return it anyway
        resolve(ebayListingTabId || challengeTabId);
      }, 180000);
    });
  }

  waitForEbayListingComplete(ebayTabId) {
    return new Promise((resolve) => {
      let checkCount = 0;
      const maxChecks = 600; // 300 seconds / 5 minutes (check every 500ms) - increased to prevent premature closing
      let urlStableCount = 0;
      let lastUrl = null;

      const checkStatus = () => {
        chrome.tabs.get(ebayTabId, (tab) => {
          if (chrome.runtime.lastError || !tab) {
            // Tab closed or error - assume complete
            this.log(
              "Background: eBay listing tab closed or error, assuming complete",
            );
            resolve();
            return;
          }

          // Check if we're on the challenge/splash screen - DON'T close, wait for redirect
          if (tab.url && tab.url.includes("/splashui/challenge")) {
            this.log(
              "Background: eBay challenge screen detected, waiting for auto-redirect...",
            );
            checkCount = 0; // Reset counter while on challenge screen
            urlStableCount = 0;
            setTimeout(checkStatus, 2000); // Check every 2 seconds on challenge screen
            return;
          }

          // Check if page is still loading
          if (tab.status === "loading") {
            checkCount = 0; // Reset counter while loading
            urlStableCount = 0;
            this.log("Background: eBay listing still loading...");
            setTimeout(checkStatus, 1000);
            return;
          }

          // Track URL stability - wait for URL to remain stable for several checks
          if (lastUrl === tab.url) {
            urlStableCount++;
          } else {
            urlStableCount = 0;
            lastUrl = tab.url;
            this.log("Background: eBay listing URL changed to: " + tab.url);
          }

          // Check if URL has changed from /sl/ or /lstng to final listing
          // AND the URL has been stable for at least 5 checks (2.5 seconds)
          if (
            tab.url &&
            !tab.url.includes("/sl/") &&
            !tab.url.includes("/lstng") &&
            tab.url.includes("/itm/") &&
            urlStableCount >= 5 &&
            tab.status === "complete"
          ) {
            // Additional wait to ensure page is fully rendered
            this.log(
              "Background: eBay listing appears complete. Waiting additional 5 seconds to ensure page is fully rendered...",
            );
            setTimeout(() => {
              this.log("Background: eBay listing confirmed complete!");
              resolve();
            }, 5000);
            return;
          }

          checkCount++;
          if (checkCount >= maxChecks) {
            this.log(
              "Background: eBay listing timeout reached (" +
                maxChecks / 2 +
                " seconds), assuming complete",
            );
            resolve();
            return;
          }

          // Continue checking
          setTimeout(checkStatus, 500);
        });
      };

      // Start checking after initial delay
      setTimeout(checkStatus, 2000);
    });
  }

  waitForListingComplete(tabId) {
    return new Promise((resolve) => {
      // Wait up to 30 seconds for completion
      let attempts = 0;
      const maxAttempts = 60;

      const checkComplete = () => {
        chrome.tabs.sendMessage(
          tabId,
          { type: "bulk_snipe_check_complete" },
          (response) => {
            if (response && response.complete) {
              resolve();
            } else if (attempts++ < maxAttempts) {
              setTimeout(checkComplete, 500);
            } else {
              // Timeout - assume complete
              resolve();
            }
          },
        );
      };
      checkComplete();
    });
  }

  closeTab(tabId) {
    return new Promise((resolve) => {
      chrome.tabs.remove(tabId, () => {
        resolve();
      });
    });
  }

  sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // UI Control methods

  pause() {
    this.isPaused = true;
    this.log("PAUSED");
  }

  resume() {
    if (this.isPaused) {
      this.isPaused = false;
      this.log("RESUMED");
      this.processNextItem();
    }
  }

  clear() {
    this.textarea.value = "";
    this.ebayLinks = [];
    this.totalLabel.textContent = "0";
    this.log("Cleared all links");
  }

  reset() {
    this.isRunning = false;
    this.isPaused = false;
    this.currentPosition = 0;
    this.stats = { successful: 0, skipped: 0, failed: 0 };
    this.updateUI();
    this.saveState();
    this.log("RESET: All progress cleared");

    // Close current tab if exists
    if (this.currentTab) {
      this.closeTab(this.currentTab);
      this.currentTab = null;
    }
  }

  complete() {
    this.isRunning = false;

    // Check every second if all background listings are done
    const checkComplete = () => {
      if (this.backgroundListings === 0) {
        this.log("===============================");
        this.log("BULK SNIPE COMPLETED!");
        this.log("Total: " + this.ebayLinks.length);
        this.log("Successful: " + this.stats.successful);
        this.log("Skipped: " + this.stats.skipped);
        this.log("Failed: " + this.stats.failed);
        this.log("===============================");
        alert(
          "Bulk Snipe Complete!\nSuccessful: " +
            this.stats.successful +
            "\nSkipped: " +
            this.stats.skipped +
            "\nFailed: " +
            this.stats.failed,
        );
      } else {
        this.log(
          "Waiting for " +
            this.backgroundListings +
            " background listings to finish...",
        );
        setTimeout(checkComplete, 1000);
      }
    };

    checkComplete();
  }

  showStatus() {
    alert(
      `Current Status:\nPosition: ${this.currentPosition}/${this.ebayLinks.length}\nSuccessful: ${this.stats.successful}\nSkipped: ${this.stats.skipped}\nFailed: ${this.stats.failed}\nRunning: ${this.isRunning}\nPaused: ${this.isPaused}`,
    );
  }

  updateUI() {
    this.positionInput.value = this.currentPosition;
    document.getElementById("successful-listings").textContent =
      this.stats.successful;
    document.getElementById("skipped-listings").textContent =
      this.stats.skipped;
    document.getElementById("failed-listings").textContent = this.stats.failed;
    document.getElementById("currently-processing").textContent =
      this.backgroundListings;

    // Update progress bar
    const progress =
      this.ebayLinks.length > 0
        ? (this.currentPosition / this.ebayLinks.length) * 100
        : 0;
    const progressBar = document.getElementById("progress-bar");
    const progressPercentages = document.querySelectorAll(
      ".progress-percentage",
    );

    progressBar.style.width = progress + "%";
    progressPercentages.forEach((el) => {
      el.textContent = Math.round(progress) + "%";
    });
  }

  log(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}`;
    console.log(logEntry);

    if (this.logOutput) {
      this.logOutput.innerHTML += logEntry + "<br>";
      this.logOutput.scrollTop = this.logOutput.scrollHeight;
    }
  }
}

// Initialize when page loads
document.addEventListener("DOMContentLoaded", () => {
  window.bulkSnipeLister = new BulkSnipeLister();
});
