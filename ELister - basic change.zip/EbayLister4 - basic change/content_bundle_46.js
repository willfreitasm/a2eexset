console["log"](
  "Amazon\x20Auto\x20Order\x20Cart\x20functions\x20Script\x20Loaded",
);
function _0x229dce() {
  return document["querySelector"]("#sw-gtc\x20a");
}
function _0xb1aa0f() {
  return document["querySelector"](
    "input[name=\x22proceedToRetailCheckout\x22]",
  );
}
async function _0x3afee6(_0x46426d) {
  for (;;) {
    var _0x41073f = [
      ...document["querySelectorAll"]("#sc-active-cart\x20.sc-action-delete"),
    ];
    if (0x0 === _0x41073f["length"]) {
      console["log"]("No\x20more\x20cart\x20items\x20found.");
      break;
    }
    let _0x2c96f5 = !0x1;
    for (const _0x3c817b of _0x41073f) {
      if (
        ![
          ..._0x3c817b["parentElement"]["parentElement"]["parentElement"][
            "parentElement"
          ]["querySelectorAll"]("a"),
        ]["some"](
          (_0x2bf8b3) =>
            !!_0x2bf8b3["href"] &&
            _0x46426d["some"]((_0x10e110) =>
              _0x2bf8b3["href"]["includes"](_0x10e110),
            ),
        )
      ) {
        (console["log"]("Removing\x20Cart\x20Item:", _0x3c817b),
          _0x3c817b["querySelector"]("input")["click"](),
          await new Promise((_0x582c1c) => setTimeout(_0x582c1c, 0x1f4)),
          (_0x2c96f5 = !0x0));
        break;
      }
      console["log"](
        "Skipping\x20item\x20with\x20an\x20exception:\x20",
        _0x3c817b,
      );
    }
    if (!_0x2c96f5) {
      console["log"](
        "No\x20items\x20removed\x20in\x20this\x20pass.\x20Likely\x20all\x20items\x20have\x20exceptions.",
      );
      break;
    }
  }
}
async function _0x3139aa() {
  if ((_0x213920 = document["querySelector"](".sc-gift-option\x20input")))
    (_0x213920["click"](),
      await new Promise((_0xb31321) => setTimeout(_0xb31321, 0x3e8)));
  else {
    var _0x213920;
    (_0x213920 = document["querySelector"]("#sc-buy-box-gift-checkbox")) &&
      (_0x213920["click"](),
      await new Promise((_0x281513) => setTimeout(_0x281513, 0x3e8)));
  }
}
async function _0x4a4f35(_0x262f46, _0x11c2ed) {
  const _0x41e38a = document["querySelector"](
    "[data-asin=\x22" + _0x262f46 + "\x22]",
  );
  if (!_0x41e38a) {
    console["warn"](
      "Could\x20not\x20find\x20cart\x20item\x20with\x20data-asin=\x22" +
        _0x262f46 +
        "\x22",
    );
    return;
  }
  const _0x57cd1a = _0x32d7f7(_0x41e38a);
  if (null !== _0x57cd1a && _0x57cd1a === _0x11c2ed) {
    console["log"](
      "[ASIN=" +
        _0x262f46 +
        "]\x20Quantity\x20already\x20" +
        _0x11c2ed +
        ".\x20Skipping\x20update.",
    );
    return;
  }
  const _0x7d83cb = _0x41e38a["querySelector"](
    ".sc-quantity-textfield-input-group",
  );
  if (!_0x7d83cb) {
    console["warn"](
      "Could\x20not\x20find\x20.sc-quantity-textfield-input-group\x20for\x20ASIN=" +
        _0x262f46,
    );
    return;
  }
  _0x7d83cb["classList"]["remove"]("sc-hidden");
  const _0x756c28 = _0x41e38a["querySelector"](".sc-update-link.sc-hidden");
  _0x756c28 && _0x756c28["classList"]["remove"]("sc-hidden");
  const _0xb5cefa = _0x7d83cb["querySelector"](".sc-quantity-textfield");
  if (_0xb5cefa)
    ((_0xb5cefa["value"] = _0x11c2ed),
      await _0x49a919(_0x41e38a),
      await _0x32dfc7(_0x262f46, _0x11c2ed, 0x1388),
      console["log"](
        "[ASIN=" +
          _0x262f46 +
          "]\x20Successfully\x20set\x20quantity\x20to\x20" +
          _0x11c2ed +
          "!",
      ));
  else
    console["warn"](
      "Could\x20not\x20find\x20.sc-quantity-textfield\x20for\x20ASIN=" +
        _0x262f46,
    );
}
function _0x32d7f7(_0x1951ed) {
  const _0x30a9f5 = _0x1951ed["querySelector"](
    "[name=\x22sc-quantity\x22]\x20[data-a-selector=\x22spinbutton\x22]",
  );
  if (_0x30a9f5) {
    const _0x40e925 = parseInt(
      _0x30a9f5["getAttribute"]("aria-valuenow") || "",
      0xa,
    );
    if (!isNaN(_0x40e925)) return _0x40e925;
  }
  const _0x5d6e6b = parseInt(
    _0x1951ed["getAttribute"]("data-quantity") || "",
    0xa,
  );
  if (!isNaN(_0x5d6e6b)) return _0x5d6e6b;
  const _0x178b86 = _0x1951ed["querySelector"](".sc-quantity-textfield");
  if (_0x178b86) {
    const _0x166d19 = parseInt(_0x178b86["value"] || "", 0xa);
    if (!isNaN(_0x166d19)) return _0x166d19;
  }
  return null;
}
async function _0x49a919(_0x123f2d) {
  let _0x221071 = 0x0,
    _0x4c5a51 = null;
  for (; _0x221071 < 0x1388; ) {
    _0x4c5a51 = _0x123f2d["querySelector"](
      ".sc-quantity-update-button\x20a[data-action=\x22update\x22]",
    );
    if (_0x4c5a51) break;
    (await new Promise((_0x4abf7b) => setTimeout(_0x4abf7b, 0x190)),
      (_0x221071 += 0x190));
  }
  if (!_0x4c5a51)
    throw new Error(
      "Update\x20button\x20never\x20appeared\x20in\x20the\x20DOM.",
    );
  for (let _0x4e3324 = 0x1; _0x4e3324 <= 0x3; _0x4e3324++) {
    (console["log"](
      "Clicking\x20Update\x20button\x20(attempt\x20#" + _0x4e3324 + ")...",
    ),
      _0x4c5a51["click"](),
      await new Promise((_0x21176f) => setTimeout(_0x21176f, 0x320)),
      (_0x4c5a51 = _0x123f2d["querySelector"](
        ".sc-quantity-update-button\x20a[data-action=\x22update\x22]",
      )));
    if (!_0x4c5a51) {
      console["log"](
        "Update\x20button\x20disappeared\x20after\x20click\x20—\x20likely\x20successful.",
      );
      return;
    }
  }
  console["warn"](
    "Update\x20button\x20is\x20still\x20present\x20after\x20several\x20clicks\x20—\x20continuing\x20anyway.",
  );
}
function _0x32dfc7(_0x447a19, _0x3d572a, _0x46d4b0 = 0x1388) {
  let _0x1f4fea = 0x0;
  return new Promise((_0x1266ec, _0x1ddad9) => {
    const _0x195d48 = setInterval(() => {
      const _0x55aac3 = document["querySelector"](
        "[data-asin=\x22" + _0x447a19 + "\x22]",
      );
      if (_0x55aac3) {
        if (_0x32d7f7(_0x55aac3) === _0x3d572a)
          return (clearInterval(_0x195d48), _0x1266ec(!0x0));
        ((_0x1f4fea += 0x190),
          _0x1f4fea >= _0x46d4b0 &&
            (clearInterval(_0x195d48),
            _0x1ddad9(
              new Error(
                "Timed\x20out\x20waiting\x20for\x20quantity=" +
                  _0x3d572a +
                  "\x20on\x20ASIN=" +
                  _0x447a19 +
                  ".",
              ),
            )));
      } else
        ((_0x1f4fea += 0x190),
          _0x1f4fea >= _0x46d4b0 &&
            (clearInterval(_0x195d48),
            _0x1ddad9(
              new Error(
                "Item\x20[ASIN=" +
                  _0x447a19 +
                  "]\x20not\x20found\x20in\x20DOM\x20after\x20re-render.",
              ),
            )));
    }, 0x190);
  });
}
console["log"](
  "Amazon\x20Auto\x20Order\x20Cart\x20Content\x20Script\x20Loaded",
);
var _0x44eb1e = !0x1;
chrome["runtime"]["onMessage"]["addListener"](
  (_0x50b59f, _0x16c2f9, _0x3ce6a6) => {
    (console["log"]("Message\x20received", _0x50b59f),
      "autoOrder" === _0x50b59f["type"] &&
        "proceed_to_checkout" === _0x50b59f["action"] &&
        !_0x44eb1e &&
        ((_0x44eb1e = !0x0), _0x4b7982(_0x50b59f["orderDetails"])));
  },
);
async function _0x4b7982(_0x10c93b) {
  console["log"]("Proceeding\x20to\x20checkout");
  var _0x188eb4 = _0x229dce();
  console["log"](_0x188eb4);
  if (_0x188eb4)
    (console["log"]("Clicking\x20on\x20cart\x20button"), _0x188eb4["click"]());
  else {
    var _0x395eb3 = _0xb1aa0f();
    console["log"]("proceedButton", _0x395eb3);
    if (_0x395eb3) {
      var _0xc0615b = atob(_0x10c93b["ebaySku"]);
      await _0x3afee6([_0xc0615b]);
      var _0x330839 = _0x10c93b["quantitySold"];
      ((_0x330839 = parseInt(_0x330839)),
        await _0x4a4f35(_0xc0615b, _0x330839),
        _0x10c93b["shouldUseGiftOption"] && (await _0x3139aa()),
        (_0x395eb3 = _0xb1aa0f())["click"]());
    }
  }
}
