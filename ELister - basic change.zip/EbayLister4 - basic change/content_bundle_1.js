var _0x5a64f6 = async function (_0x19cfae = "sniper-mark") {
  var _0xe80a98 = document["createElement"]("img");
  return (
    (_0xe80a98["id"] = _0x19cfae),
    _0xe80a98["classList"]["add"]("sniper-mark"),
    (_0xe80a98["src"] = await chrome["runtime"]["getURL"](
      "libraries/target-spin/target.png",
    )),
    _0xe80a98
  );
};
function _0x2f5124() {
  var _0x4ea93f = document["querySelectorAll"](".sniper-mark");
  for (var _0xf395ea = 0x0; _0xf395ea < _0x4ea93f["length"]; _0xf395ea++)
    _0x4ea93f[_0xf395ea]["classList"]["add"]("spin");
}
function _0x4c9954() {
  var _0x20861b = document["querySelectorAll"](".sniper-mark");
  for (var _0x2eb5a0 = 0x0; _0x2eb5a0 < _0x20861b["length"]; _0x2eb5a0++)
    _0x20861b[_0x2eb5a0]["classList"]["remove"]("spin");
}
function _0x2ea127() {
  var _0x3a4392 = document["querySelectorAll"](".sniper-mark");
  for (var _0x27a652 = 0x0; _0x27a652 < _0x3a4392["length"]; _0x27a652++)
    _0x3a4392[_0x27a652]["classList"]["add"]("flash");
}
function _0x13b0f3() {
  var _0x27cbce = document["querySelectorAll"](".sniper-mark");
  for (var _0x5e776b = 0x0; _0x5e776b < _0x27cbce["length"]; _0x5e776b++)
    _0x27cbce[_0x5e776b]["classList"]["remove"]("flash");
}
function _0x2001ca(_0x42dcd2) {
  _0x42dcd2["classList"]["add"]("spin");
}
function _0x4cb1eb(_0x39d642) {
  _0x39d642["classList"]["remove"]("spin");
}
function _0x3f0777(_0x20d889) {
  _0x20d889["classList"]["add"]("flash");
}
function _0xe9453f(_0x311436) {
  _0x311436["classList"]["remove"]("flash");
}
function _0x5db7b7(
  _0xac3344 = null,
  _0x59a6ab = null,
  _0x474a6e = null,
  _0x2783d6 = null,
) {
  var _0xdf9e46 = document["createElement"]("a");
  (_0xdf9e46["setAttribute"]("class", "a-link-text"),
    _0xdf9e46["classList"]["add"]("icon"),
    _0xdf9e46["classList"]["add"]("amazonSearchLink"),
    _0xdf9e46["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x4ae68e = document["createElement"]("img");
  return (
    _0x4ae68e["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4ae68e["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xdf9e46["appendChild"](_0x4ae68e),
    _0xdf9e46["addEventListener"]("click", async function (_0x55b237) {
      (_0x55b237["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0xac3344) {
        var _0x3ed8cc = _0x448a04(_0x55b237);
        if (!_0x3ed8cc) return;
        var _0x152687 = extractItemData(_0x3ed8cc);
        ((_0xac3344 = _0x152687["title"])["endsWith"]("...") &&
          (_0xac3344 = _0xac3344["substring"](
            0x0,
            _0xac3344["lastIndexOf"]("\x20"),
          )),
          _0xac3344["length"] > 0x4b &&
            (_0xac3344 = _0xac3344["substring"](
              0x0,
              _0xac3344["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x19e5b6 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x19e5b6),
        _0x19e5b6 || (_0x19e5b6 = "reviews"),
        console["log"]("amazonSortType", _0x19e5b6),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x259a18 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0xac3344["length"] > 0x50; )
        _0xac3344 = _0xac3344["substring"](
          0x0,
          _0xac3344["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x4a362b } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x29b2d7 = _0xac3344;
      "keywords" == _0x4a362b && (_0x29b2d7 = await _0x2600b1(_0xac3344));
      try {
        _0x152687 = extractItemData(_0x3ed8cc);
      } catch (_0x3e9d8c) {
        console["log"]("error", _0x3e9d8c);
      }
      (_0x152687 ||
        (_0x152687 = {
          title: _0xac3344,
          price: _0x59a6ab,
          itemNumber: _0x474a6e,
          image: _0x2783d6,
        }),
        console["log"]("itemData", _0x152687),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x29b2d7,
          options: { isTabActive: !0x0, sort: _0x19e5b6 },
          itemData: _0x152687,
        }));
    }),
    _0xdf9e46
  );
}
function _0x3f6bc7(_0x5ab8d6) {
  var _0x19d855 = document["createElement"]("a");
  (_0x19d855["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x19d855["setAttribute"]("class", "a-link-text"),
    _0x19d855["classList"]["add"]("icon"),
    _0x19d855["classList"]["add"]("amazonSearchLink"),
    _0x19d855["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x2da5ee = document["createElement"]("img");
  return (
    _0x2da5ee["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x2da5ee["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x19d855["appendChild"](_0x2da5ee),
    _0x19d855["addEventListener"]("click", async function (_0x41bad7) {
      (_0x41bad7["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x5ab8d6),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x5ab8d6,
        }));
    }),
    _0x19d855
  );
}
function openAmazonSkuButton(_0x493099) {
  var _0x10cb08 = document["createElement"]("a");
  (_0x10cb08["setAttribute"]("id", "amazonLink"),
    _0x10cb08["setAttribute"]("class", "a-link-text"),
    _0x10cb08["classList"]["add"]("icon"),
    _0x10cb08["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x1a5c90 = document["createElement"]("img");
  return (
    _0x1a5c90["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x1a5c90["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x10cb08["appendChild"](_0x1a5c90),
    _0x10cb08["addEventListener"]("click", async function (_0x36a7d0) {
      (_0x36a7d0["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x1fdd82 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x28fd6c =
          "https://www.amazon." +
          _0x1fdd82 +
          "/dp/" +
          _0x493099 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x28fd6c });
    }),
    _0x10cb08
  );
}
function _0x135a24(openAmazonItem) {
  var _0xe06375 = document["createElement"]("a");
  (_0xe06375["setAttribute"]("id", "amazonLink"),
    _0xe06375["setAttribute"]("class", "a-link-text"),
    _0xe06375["classList"]["add"]("icon"),
    _0xe06375["classList"]["add"]("amazonLink"),
    _0xe06375["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x42c971 = document["createElement"]("img");
  return (
    _0x42c971["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x42c971["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xe06375["appendChild"](_0x42c971),
    _0xe06375["addEventListener"]("click", async function (_0x5e99c0) {
      (_0x5e99c0["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        openAmazonItem(_0x5e99c0);
      } catch (_0x5bd5bc) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x5bd5bc);
      }
    }),
    _0xe06375
  );
}
function _0x1bf04c(
  _0x1aee30 = null,
  _0x1662ad,
  _0x3a7c10 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x1aee30, _0x1662ad);
  var _0x11ea65 = document["createElement"]("a");
  (_0x11ea65["setAttribute"]("id", "ebayLink"),
    _0x11ea65["setAttribute"]("class", "a-link-text"),
    _0x11ea65["classList"]["add"]("icon"),
    _0x1662ad && _0x1662ad["soldItems"]
      ? _0x11ea65["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x11ea65["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x341db9 = document["createElement"]("img");
  return (
    _0x341db9["setAttribute"]("src", chrome["runtime"]["getURL"](_0x3a7c10)),
    _0x341db9["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x11ea65["appendChild"](_0x341db9),
    _0x11ea65["addEventListener"]("click", async function (_0x1d0442) {
      (_0x1d0442["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x1aee30) console["log"]("title\x20found", _0x1aee30);
      else {
        console["log"]("title\x20not\x20found");
        var _0x242cbe = _0x448a04(_0x1d0442);
        if (!_0x242cbe) return;
        var _0x5c5d30 = extractItemData(_0x242cbe);
        _0x1aee30 = _0x5c5d30["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x37add3 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x1aee30["length"] > 0x50; )
        _0x1aee30 = _0x1aee30["substring"](
          0x0,
          _0x1aee30["lastIndexOf"]("\x20"),
        );
      var _0x42c45a =
        "https://www.ebay." +
        _0x37add3 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x1aee30) +
        "&_odkw=" +
        encodeURIComponent(_0x1aee30);
      (_0x1662ad && _0x1662ad["soldItems"] && (_0x42c45a += "&LH_Sold=1"),
        _0x1662ad && _0x1662ad["sortLowToHigh"] && (_0x42c45a += "&_sop=15"),
        _0x1662ad && _0x1662ad["endedRecently"] && (_0x42c45a += "&_sop=13"),
        (_0x42c45a += "&LH_ItemCondition=1000"),
        (_0x42c45a += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x42c45a,
        }));
    }),
    _0x11ea65
  );
}
function _0x1e8dc4(_0x499191 = null) {
  var _0x3923c9 = document["createElement"]("a");
  (_0x3923c9["setAttribute"]("id", "googleLink"),
    _0x3923c9["setAttribute"]("class", "a-link-text"),
    _0x3923c9["classList"]["add"]("icon"),
    _0x3923c9["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x4a12f6 = document["createElement"]("img");
  return (
    _0x4a12f6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x4a12f6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3923c9["appendChild"](_0x4a12f6),
    _0x3923c9["addEventListener"]("click", async function (_0x44fb14) {
      (_0x44fb14["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x499191) {
        var _0x18d519 = _0x448a04(_0x44fb14);
        if (!_0x18d519) return;
        var _0x12e1d8 = extractItemData(_0x18d519);
        _0x499191 = _0x12e1d8["image"];
      }
      var { domain: _0x569a70 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x56534a(_0x569a70),
        encodeURIComponent(_0x499191),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x499191,
        }));
    }),
    _0x3923c9
  );
}
function _0x234506(_0x15b3c5 = null) {
  var _0x51c07d = document["createElement"]("a");
  (_0x51c07d["setAttribute"]("id", "googleLink"),
    _0x51c07d["setAttribute"]("class", "a-link-text"),
    _0x51c07d["classList"]["add"]("icon"),
    _0x51c07d["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x3dfb0f = document["createElement"]("img");
  return (
    _0x3dfb0f["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x3dfb0f["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x51c07d["appendChild"](_0x3dfb0f),
    _0x51c07d["addEventListener"]("click", async function (_0x4c8ce4) {
      (_0x4c8ce4["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x15b3c5) {
        var _0x5114da = _0x448a04(_0x4c8ce4);
        if (!_0x5114da) return;
        var _0x49621f = extractItemData(_0x5114da);
        _0x15b3c5 = _0x49621f["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x15b3c5,
      });
    }),
    _0x51c07d
  );
}
function _0x90904(_0xda8c7d) {
  var _0xbc6914 = document["createElement"]("a");
  (_0xbc6914["setAttribute"]("id", "lookUpSkuLink"),
    _0xbc6914["setAttribute"]("class", "a-link-text"),
    _0xbc6914["classList"]["add"]("icon"),
    _0xbc6914["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x63f9f6 = document["createElement"]("img");
  return (
    _0x63f9f6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x63f9f6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xbc6914["appendChild"](_0x63f9f6),
    _0xbc6914["addEventListener"]("click", async function (_0x16742f) {
      (_0x16742f["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x146166 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x49707f =
          "https://www.amazon." +
          _0x146166 +
          "/dp/" +
          _0xda8c7d +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x49707f,
        options: { active: !0x0 },
      });
    }),
    _0xbc6914
  );
}
function _0x18d428(_0x38f520 = null) {
  var _0x55554f = document["createElement"]("a");
  (_0x55554f["setAttribute"]("id", "productHunterLink"),
    _0x55554f["setAttribute"]("class", "a-link-text"),
    _0x55554f["classList"]["add"]("icon"),
    _0x55554f["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0xd8a404 = document["createElement"]("img");
  return (
    _0xd8a404["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0xd8a404["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x55554f["appendChild"](_0xd8a404),
    _0x55554f["addEventListener"]("click", async function (_0x20ce90) {
      (_0x20ce90["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x38f520) {
        var _0x4bc0c7 = _0x448a04(_0x20ce90);
        if (!_0x4bc0c7) return;
        var _0xb09b36 = extractItemData(_0x4bc0c7);
        _0x38f520 = _0xb09b36["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x38f520),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x38f520,
        }));
    }),
    _0x55554f
  );
}
function _0x56534a(_0x2ded16) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x2ded16] || "en-US";
}
function _0x44cff4(_0x7e2211 = null) {
  console["log"]("createSearchTerapeakButton", _0x7e2211);
  var _0x2b8468 = document["createElement"]("a");
  (_0x2b8468["setAttribute"]("class", "a-link-text"),
    _0x2b8468["classList"]["add"]("terapeakLink"),
    _0x2b8468["classList"]["add"]("icon"),
    _0x2b8468["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x7e2211 && _0x2b8468["setAttribute"]("item_title", _0x7e2211));
  var _0x31b9a9 = document["createElement"]("img");
  return (
    _0x31b9a9["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x31b9a9["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2b8468["appendChild"](_0x31b9a9),
    _0x2b8468["addEventListener"]("click", async function (_0x5d060e) {
      (_0x5d060e["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x274872 = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x274872),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x274872) {
        var _0xc22937 = _0x448a04(_0x5d060e);
        if (!_0xc22937) return;
        _0x274872 = extractItemData(_0xc22937)["title"];
      }
      console["log"]("title", _0x274872);
      var { convertToKeywords: _0x3d5e4e } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x3d5e4e) var _0x274872 = await _0x2600b1(_0x274872);
      var { domain: _0x22d6f3 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x4b5084 = _0x9e1fe2(_0x274872, _0x22d6f3);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x4b5084 });
    }),
    _0x2b8468
  );
}
async function _0x2600b1(_0x5cb7ec) {
  var _0x1c623b = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x5a935c) => _0x5a935c["json"]());
  ((_0x1c623b["user_input"] = _0x5cb7ec),
    console["log"]("jsonPrompt", _0x1c623b));
  var _0x3bce90 = await new Promise((_0x2e2989, _0x445db6) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x1c623b,
      },
      function (_0x49605a) {
        _0x2e2989(_0x49605a["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x3bce90),
    (_0x3bce90 = JSON["parse"](_0x3bce90))["output"]
  );
}
function _0x9e1fe2(
  _0x251003,
  _0x3e613b = "ca",
  _0xdae0c0 = 0x1e,
  _0x31e001 = 0x0,
  _0x462cfb = 0x0,
  _0x2735f9 = 0x32,
  _0x56b3d8 = "-itemssold",
  _0x45903f = "SOLD",
  _0x2dbdb7 = "EBAY-CA",
  _0x56a9ab = "America/Toronto",
  _0x27f015 = "BuyerLocation:::CA",
  _0x271875 = 0x0,
) {
  _0x2dbdb7 = "";
  switch (_0x3e613b) {
    case "ca":
    default:
      _0x2dbdb7 = "EBAY-CA";
      break;
    case "com":
      _0x2dbdb7 = "EBAY-US";
      break;
    case "co.uk":
      _0x2dbdb7 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x3e613b +
    "/sh/research?" +
    [
      "keywords=" + _0x251003,
      "dayRange=" + _0xdae0c0,
      "categoryId=" + _0x31e001,
      "offset=" + _0x462cfb,
      "limit=" + _0x2735f9,
      "sorting=" + _0x56b3d8,
      "tabName=" + _0x45903f,
      "marketplace=" + _0x2dbdb7,
      "tz=" + encodeURIComponent(_0x56a9ab),
      "minPrice=" + _0x271875,
    ]["join"]("&")
  );
}
async function openSellerItemsPage(_0x3712ef) {
  var { domain: _0x379c31 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x1f84f9 =
      "https://www.ebay." +
      _0x379c31 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x3712ef +
      "&store_name=" +
      _0x3712ef +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x1f84f9 });
}
async function openItemPageThenSellerItemsPage(_0x5b5b6c) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x5b5b6c,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x5b5b6c));
}
async function openItemPageThenGetSeller(_0x573704) {
  var { response: _0x5aa3c7 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x573704,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x5aa3c7), _0x5aa3c7);
}
function _0xeaa4bc(_0x392f8c = null) {
  console["log"]("createOpenSellerItemsButton", _0x392f8c);
  var _0x1ff84e = document["createElement"]("a");
  (_0x1ff84e["setAttribute"]("id", "sellerItemsLink"),
    _0x1ff84e["setAttribute"]("class", "a-link-text"),
    _0x1ff84e["classList"]["add"]("icon"),
    _0x1ff84e["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x5bea96 = document["createElement"]("img");
  return (
    _0x5bea96["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x5bea96["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1ff84e["appendChild"](_0x5bea96),
    _0x1ff84e["addEventListener"]("click", async function (_0x41127f) {
      (_0x41127f["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x392f8c),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x392f8c));
      var _0x4a0992;
      if (!_0x392f8c) {
        console["log"]("username\x20not\x20found");
        var _0x182aa8 = _0x448a04(_0x41127f);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x182aa8,
        );
        if (!_0x182aa8) return;
        var _0x615363 = extractItemData(_0x182aa8);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x615363,
        ),
          (_0x392f8c = _0x615363["username"]),
          (_0x4a0992 = _0x615363["itemNumber"]));
      }
      if (
        _0x392f8c["includes"]("\x20") ||
        _0x392f8c !== _0x392f8c["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x392f8c,
        );
        if (!_0x4a0992) {
          if (!(_0x182aa8 = _0x448a04(_0x41127f))) return;
          _0x4a0992 = (_0x615363 = extractItemData(_0x182aa8))["itemNumber"];
        }
        openItemPageThenSellerItemsPage(_0x4a0992);
      } else
        ((_0x392f8c = _0x392f8c["toLowerCase"]()),
          console["log"]("username", _0x392f8c),
          openSellerItemsPage(_0x392f8c));
    }),
    _0x1ff84e
  );
}
function _0x1b426(_0x2e5f22) {
  for (
    ;
    _0x2e5f22 &&
    !_0x2e5f22["classList"]["contains"]("s-item") &&
    !_0x2e5f22["classList"]["contains"]("su-card-container");

  )
    _0x2e5f22 = _0x2e5f22["parentElement"];
  return _0x2e5f22;
}
function _0x32f28a(_0x3a29c7 = null) {
  var _0x4a1ea8 = document["createElement"]("a");
  (_0x4a1ea8["setAttribute"]("id", "purchaseHistoryLink"),
    _0x4a1ea8["setAttribute"]("class", "a-link-text"),
    _0x4a1ea8["classList"]["add"]("icon"),
    _0x4a1ea8["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x2ac366 = document["createElement"]("img");
  return (
    _0x2ac366["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x2ac366["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4a1ea8["appendChild"](_0x2ac366),
    _0x4a1ea8["addEventListener"]("click", async function (_0x21c4a5) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x3a29c7),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x21c4a5["preventDefault"]());
      var _0x4bfc19 = _0x448a04(_0x21c4a5);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x4bfc19,
      );
      if (_0x4bfc19) {
        var { selectedFilter: _0x4d5c55 } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x4d5c55 &&
          ((_0x4d5c55 = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x4d5c55,
          }));
        var _0x2e0b13 = _0x4d5c55,
          _0x377170 = await checkPurchaseHistoryAndAddToItem(
            _0x4bfc19,
            _0x2e0b13,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x377170);
      } else
        try {
          var _0x420b9e = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x3a29c7,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x420b9e),
            (_0x377170 = _0x420b9e["totalSold"]));
        } catch (_0x98a8c6) {
          (console["log"]("error", _0x98a8c6), (_0x377170 = -0x3e7));
        }
    }),
    _0x4a1ea8
  );
}
function _0x448a04(_0x49ddb2) {
  var _0x3ede8b = _0x49ddb2["target"];
  return (
    (_0x3ede8b = _0x1b426(_0x3ede8b)),
    console["log"]("found\x20s-item", _0x3ede8b),
    _0x3ede8b
  );
}
function _0x9d8c14(_0x12b90c = null, _0x3143e9 = null, _0x41b7f7 = null) {
  var _0x1376d0 = document["createElement"]("a");
  (_0x1376d0["setAttribute"]("id", "copyDataLink"),
    _0x1376d0["setAttribute"]("class", "a-link-text"),
    _0x1376d0["classList"]["add"]("icon"),
    _0x1376d0["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x5940a5 = document["createElement"]("img");
  return (
    _0x5940a5["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x5940a5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1376d0["appendChild"](_0x5940a5),
    _0x1376d0["addEventListener"]("click", async function (_0x522c64) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x12b90c,
        _0x3143e9,
        _0x41b7f7,
      ),
        _0x522c64["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x12b90c && _0x3143e9 && _0x41b7f7)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x12b90c,
          _0x3143e9,
          _0x41b7f7,
        ),
          isNaN(_0x3143e9) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x3143e9),
            (_0x3143e9 = _0x3143e9["replace"](/[^0-9.]/g, ""))),
          _0x5e2972(
            JSON["stringify"]({
              title: _0x12b90c,
              price: _0x3143e9,
              itemNumber: _0x41b7f7,
            }),
          ));
      else {
        if (!_0x12b90c || !_0x3143e9 || !_0x41b7f7) {
          var _0x47e944 = _0x448a04(_0x522c64);
          if (!_0x47e944) return;
        }
        var _0x2de1e5 = extractItemData(_0x47e944);
        (console["log"]("itemData", _0x2de1e5),
          _0x5e2972(JSON["stringify"](_0x2de1e5)));
      }
    }),
    _0x1376d0
  );
}
function _0x5e2972(_0x583c91) {
  var _0x5390ed = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x5390ed),
    (_0x5390ed["value"] = _0x583c91),
    _0x5390ed["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x5390ed));
}
async function _0xe72ac8(_0x476919 = null) {
  console["log"]("price", _0x476919);
  if (_0x476919) {
    try {
      _0x476919 = _0x476919["replace"](/[^0-9.]/g, "");
    } catch (_0x1f06c4) {}
    _0x476919 = parseFloat(_0x476919);
  }
  var _0x1d916e = await _0x5c97e2(_0x476919),
    _0x1ccb28 = document["createElement"]("div");
  return (
    _0x1ccb28["setAttribute"]("id", "breakEvenPrice"),
    _0x1ccb28["setAttribute"]("class", "break-even-price"),
    (_0x1ccb28["textContent"] =
      "Break-even\x20price:\x20$" + _0x1d916e["toFixed"](0x2)),
    _0x1ccb28
  );
}
async function _0x14851b(_0xbd0160) {
  var _0x338534 = !0x1,
    _0x6bbcea = !0x1,
    { includeCurrencyConversion: _0x6bbcea } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x338534 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x424909 =
    0.1325 * _0xbd0160 +
    0.021 * _0xbd0160 +
    _0xbd0160 * (_0x338534 ? 0.004 : 0x0) +
    0.4;
  return (_0x6bbcea && (_0x424909 += 0.035 * _0xbd0160), _0xbd0160 - _0x424909);
}
async function _0x5c97e2(_0x472116) {
  var { isInternational: _0xcd477 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x1403b1 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0xcd477 || (_0xcd477 = !0x1), _0x1403b1 || (_0x1403b1 = !0x0));
  var _0x154d0b = 13.25;
  _0x1403b1 && (_0x154d0b = 12.35);
  var _0x539bee = _0x472116 + 0.0725 * _0x472116,
    _0x449b20 =
      _0x539bee * (_0x154d0b / 0x64) +
      0.4 +
      (_0xcd477 ? 0.004 * _0x539bee : 0x0),
    _0x147391 =
      _0x472116 -
      (_0x449b20 + (_0xcd477 ? 0.05 * _0x449b20 : 0x0)) -
      (_0xcd477 ? 0.035 * _0x539bee : 0x0),
    { isUserTaxExempt: _0x35d48e } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x35d48e || (_0x35d48e = !0x1),
    _0x35d48e || (_0x147391 /= 1.0725),
    _0xcd477 && (_0x147391 -= (3.5 * _0x147391) / 0x64),
    _0x147391
  );
}
function _0x23402d(_0x42a750 = null) {
  console["log"]("createButtonToSaveSeller", _0x42a750);
  var _0x7c3890 = document["createElement"]("a");
  (_0x7c3890["setAttribute"]("id", "saveSellerLink"),
    _0x7c3890["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x7c3890["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x296bba = document["createElement"]("img");
  return (
    _0x296bba["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x296bba["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x7c3890["appendChild"](_0x296bba),
    _0x7c3890["addEventListener"]("click", async function (_0x1f10b6) {
      (_0x1f10b6["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x42a750));
      var _0x5c8675;
      if (!_0x42a750) {
        var _0x1c12ce = _0x448a04(_0x1f10b6);
        if (!_0x1c12ce) return;
        var _0x4c47f8 = extractItemData(_0x1c12ce);
        ((_0x42a750 = _0x4c47f8["username"]),
          (_0x5c8675 = _0x4c47f8["itemNumber"]));
      }
      if (
        _0x42a750["includes"]("\x20") ||
        _0x42a750 !== _0x42a750["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x42a750,
        ),
          (_0x42a750 = await openItemPageThenGetSeller(_0x5c8675)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x42a750,
          ));
      else _0x42a750 = _0x42a750["toLowerCase"]();
      _0x7c3890["setAttribute"]("data-seller-name", _0x42a750);
      var { ebayCompetitors: _0x5f0f4e } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x5d9eb6 = (_0x5f0f4e = _0x5f0f4e || [])["indexOf"](_0x42a750);
      console["log"]("ebayCompetitors", _0x5f0f4e);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x5d9eb6
            ? (console["log"]("save-seller\x20clicked\x20username", _0x42a750),
              _0x5f0f4e["push"](_0x42a750),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x296bba["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x42a750,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x296bba["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x5d9eb6)
            (console["log"]("remove-seller\x20clicked\x20username", _0x42a750),
              _0x5f0f4e["splice"](_0x5d9eb6, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x296bba["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x42a750,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x5f0f4e });
    }),
    _0x7c3890
  );
}
async function _0x109ea5(_0x244833, _0x276bbe) {
  var { ebayCompetitors: _0x507bb3 } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x40f3e8 = (_0x507bb3 = _0x507bb3 || [])["indexOf"](_0x276bbe),
    _0x505422 = _0x244833["querySelector"]("img");
  -0x1 !== _0x40f3e8
    ? (_0x244833["classList"]["replace"]("save-seller", "remove-seller"),
      _0x505422["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x244833["classList"]["replace"]("remove-seller", "save-seller"),
      _0x505422["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x14d4bb(
  _0x11c462 = null,
  _0x3df2c9 = null,
  _0x463ba2 = null,
  _0x38d799 = !0x0,
  _0x21f4a7 = null,
  _0x581038 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x11c462));
  var _0x2f6d26 = _0x23402d(_0x3df2c9),
    _0x1175dd = _0x44cff4(_0x11c462),
    _0x5693e3 = _0x32f28a(_0x21f4a7),
    _0xb0153d = _0x1bf04c(_0x11c462),
    _0x42108b = _0x5db7b7(_0x11c462, _0x581038, _0x21f4a7, _0x463ba2),
    _0xf9f82 = _0x1bf04c(
      _0x11c462,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x2b3eeb = _0x1e8dc4(_0x463ba2),
    _0x33bac2 = _0x234506(_0x21f4a7),
    openSellerItemsButton = _0xeaa4bc(_0x3df2c9),
    _0x36804c = document["createElement"]("div");
  _0x36804c["setAttribute"]("id", "search-div");
  var _0x3bcb3a = document["createElement"]("label");
  ((_0x3bcb3a["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x36804c["appendChild"](_0x3bcb3a),
    _0x36804c["appendChild"](_0x42108b),
    _0x36804c["appendChild"](_0xb0153d),
    _0x36804c["appendChild"](_0x1175dd),
    _0x36804c["appendChild"](_0x2b3eeb),
    _0x36804c["appendChild"](_0x33bac2),
    _0x36804c["appendChild"](_0xf9f82),
    console["log"]("CopyDataButton", _0x11c462, _0x581038, _0x21f4a7));
  var _0x4c53a2 = _0x9d8c14(_0x11c462, _0x581038, _0x21f4a7),
    _0x15e46d = document["createElement"]("div");
  _0x15e46d["setAttribute"]("id", "item-buttons-div");
  var _0x245e61 = document["createElement"]("div");
  (_0x245e61["setAttribute"]("id", "main-buttons-div"),
    _0x245e61["appendChild"](openSellerItemsButton),
    _0x245e61["appendChild"](_0x5693e3),
    _0x245e61["appendChild"](_0x4c53a2),
    _0x245e61["appendChild"](_0x2f6d26),
    _0x15e46d["appendChild"](_0x245e61));
  if (_0x38d799) {
    var _0x4ac3b2 = createButtonListToEbay();
    _0x15e46d["appendChild"](_0x4ac3b2);
  }
  return (_0x15e46d["appendChild"](_0x36804c), _0x15e46d);
}
var _0x3a726c = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x256724) => {
        (console["log"](
          _0x256724,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x3a726c, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x40d6f2) => {
        (console["log"](
          _0x40d6f2,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x3a726c, "search-type", "keywords"));
      },
    },
  },
];
async function _0x519ca9() {
  var { convertToKeywords: _0x363f98 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x363f98 &&
    ((_0x363f98 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x3a726c,
      "search-type",
      _0x363f98 ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x3a726c })[
      "init"
    ]());
}
var _0x1c2b81 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x3c1ff1) => {
        (console["log"](_0x3c1ff1, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x1c2b81, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x219967) => {
        (console["log"](_0x219967, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x1c2b81, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x26301d) => {
        (console["log"](
          _0x26301d,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x1c2b81, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x16f796) => {
        (console["log"](
          _0x16f796,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x1c2b81, "search-type", "keywords"));
      },
    },
  },
];
async function _0x481f13() {
  var { amazonSortType: _0x3f33cb } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x2e30d8 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x2e30d8 &&
    ((_0x2e30d8 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x3f33cb &&
      ((_0x3f33cb = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x1c2b81, "sort-type", _0x3f33cb),
    updateContextMenu(_0x1c2b81, "search-type", _0x2e30d8),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x1c2b81 })[
      "init"
    ]());
}
_0x1c2b81 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x3d2e69) => {
        (console["log"](_0x3d2e69, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x1c2b81, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x28e485) => {
        (console["log"](_0x28e485, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x1c2b81, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x77ac28 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x53349) => {
        (console["log"](_0x53349, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0x77ac28, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x370382) => {
        (console["log"](_0x370382, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0x77ac28, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3f381b) => {
        (console["log"](_0x3f381b, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0x77ac28, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2ffc81) => {
        (console["log"](_0x2ffc81, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0x77ac28, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x408b2d) => {
        (console["log"](_0x408b2d, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0x77ac28, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3e9ea2) => {
        (console["log"](_0x3e9ea2, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0x77ac28, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x1b29d9) => {
        (console["log"](_0x1b29d9, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0x77ac28, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5af8a8) => {
        (console["log"](_0x5af8a8, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0x77ac28, "filter-type", "90"));
      },
    },
  },
];
async function _0x4bdbec() {
  var { selectedFilter: _0x2d981e } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x2d981e &&
    ((_0x2d981e = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0x77ac28, "filter-type", _0x2d981e),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0x77ac28 })[
      "init"
    ]());
}
function _0x5eeb70() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x24962a() {
  const _0x4c9887 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x40f1e2 = 0x0;
  const _0x496ec5 = () =>
    new Promise((_0x5cb3f8, _0x21e66c) => {
      const _0x4d7d5d = new MutationObserver((_0x206e4c, _0x4410f5) => {
        const _0x28d009 = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x28d009 &&
          (console["log"]("Details\x20form\x20found!"),
          _0x4410f5["disconnect"](),
          _0x5cb3f8(_0x28d009));
      });
      (_0x4d7d5d["observe"](_0x4c9887, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x4d7d5d["disconnect"]();
          if (_0x40f1e2 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x40f1e2 + 0x1) +
                "/3)",
            ),
              _0x40f1e2++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x5cb3f8(_0x496ec5()), 0x1388));
          else
            _0x21e66c(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x56bf01 = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x56bf01) {
    (_0x56bf01["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x496ec5(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x329bc2) {
      console["error"](_0x329bc2["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x33fd3e(_0x55e40b = null, _0xfbbc74 = null, _0x31d33b = null) {
  var _0x234dba = document["createElement"]("a");
  (_0x234dba["setAttribute"]("id", "copyDataLink"),
    _0x234dba["setAttribute"]("class", "a-link-text"),
    _0x234dba["classList"]["add"]("icon"),
    _0x234dba["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x9e552d = document["createElement"]("img");
  return (
    _0x9e552d["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x9e552d["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x234dba["appendChild"](_0x9e552d),
    _0x234dba["addEventListener"]("click", async function (_0x553b19) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x55e40b,
        _0xfbbc74,
        _0x31d33b,
      ),
        _0x553b19["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x55e40b && _0xfbbc74 && _0x31d33b) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x55e40b,
          _0xfbbc74,
          _0x31d33b,
        );
        isNaN(_0xfbbc74) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0xfbbc74),
          (_0xfbbc74 = _0xfbbc74["replace"](/[^0-9.]/g, "")));
        var _0xc0aa2d = JSON["stringify"]({
          title: _0x55e40b,
          price: _0xfbbc74,
          itemNumber: _0x31d33b,
        });
        (_0x3bb877(
          (_0x5ae5ea = await findSimiliarProducts(_0xc0aa2d))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x5ae5ea),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x55e40b || !_0xfbbc74 || !_0x31d33b) {
          var _0x54df3f = _0x448a04(_0x553b19);
          if (!_0x54df3f) return;
        }
        var _0x158bdf = extractItemData(_0x54df3f);
        (console["log"]("itemData", _0x158bdf),
          (_0xc0aa2d = JSON["stringify"](_0x158bdf)));
        var _0x5ae5ea;
        (_0x3bb877(
          (_0x5ae5ea = await findSimiliarProducts(_0xc0aa2d))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x5ae5ea),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x234dba
  );
}
async function findSimiliarProducts(_0x4aa9f4) {
  console["log"]("findSimiliarProducts", _0x4aa9f4);
  var _0x3a24b5 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x4aa9f4,
  });
  return (console["log"]("response", _0x3a24b5), _0x3a24b5["productLinks"]);
}
function _0x3bb877(_0x3719bb) {
  const _0x4ce069 = document["getElementById"]("productLinksModalOverlay");
  _0x4ce069 && _0x4ce069["remove"]();
  const _0x3ffcb3 = document["createElement"]("div");
  ((_0x3ffcb3["id"] = "productLinksModalOverlay"),
    _0x3ffcb3["classList"]["add"]("product-links-modal-overlay"));
  const _0x4e77cb = document["createElement"]("div");
  _0x4e77cb["classList"]["add"]("product-links-modal");
  const _0x4f693b = document["createElement"]("div");
  _0x4f693b["classList"]["add"]("modal-button-container");
  const _0x27ace5 = document["createElement"]("button");
  (_0x27ace5["classList"]["add"]("close-button"),
    (_0x27ace5["innerText"] = "Close"),
    _0x27ace5["addEventListener"]("click", () => {
      _0x3ffcb3["remove"]();
    }));
  const _0x487731 = document["createElement"]("button");
  (_0x487731["classList"]["add"]("copy-button"),
    (_0x487731["innerText"] = "Copy"),
    _0x487731["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x3719bb),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x80ffbc) {
        console["error"]("Failed\x20to\x20copy:", _0x80ffbc);
      }
    }));
  const _0x5526d5 = document["createElement"]("h2");
  _0x5526d5["innerText"] = "Similar\x20Product\x20Links";
  const _0x5dab45 = document["createElement"]("textarea");
  ((_0x5dab45["value"] = _0x3719bb),
    _0x5dab45["setAttribute"]("readonly", !0x0),
    (_0x5dab45["style"]["width"] = "100%"),
    (_0x5dab45["style"]["height"] = "300px"),
    _0x4f693b["appendChild"](_0x487731),
    _0x4f693b["appendChild"](_0x27ace5),
    _0x4e77cb["appendChild"](_0x4f693b),
    _0x4e77cb["appendChild"](_0x5526d5),
    _0x4e77cb["appendChild"](_0x5dab45),
    _0x3ffcb3["appendChild"](_0x4e77cb),
    document["body"]["appendChild"](_0x3ffcb3));
}
function _0x3d3d0d(_0x430658) {
  try {
    return atob(_0x430658);
  } catch (_0x48203c) {
    return null;
  }
}
async function _0x4844e4() {
  return new Promise((_0x4dfd5a, _0x5eab00) => {
    chrome["storage"]["local"]["get"]("skuList", async (_0x5941a2) => {
      const _0x3c07ae = _0x5941a2["skuList"] || [],
        _0x50d407 = [];
      for (let _0x2b1c1b = 0x0; _0x2b1c1b < _0x3c07ae["length"]; _0x2b1c1b++) {
        const _0x2f18a1 = _0x3c07ae[_0x2b1c1b],
          _0x5d15de = await _0x3d3d0d(_0x2f18a1);
        _0x5d15de && _0x50d407["push"](_0x5d15de);
      }
      _0x4dfd5a(_0x50d407);
    });
  });
}
async function _0x1dcf2c(_0x9e357e) {
  var _0x19d220 = await _0x4844e4();
  return (
    console["log"]("listedItems", _0x19d220),
    _0x19d220["indexOf"](_0x9e357e) > -0x1
  );
}
function _0x1132a1(_0x6af2fb) {
  return new Promise((_0x4919e4, _0x33e69d) => {
    const _0x158aaf = btoa(_0x6af2fb);
    chrome["storage"]["local"]["get"]("skuList", (_0x1a6963) => {
      let _0x48dccc = _0x1a6963["skuList"] || [];
      if (_0x48dccc["some"]((_0x2ec75a) => _0x2ec75a === _0x158aaf))
        _0x33e69d("SKU\x20already\x20exists\x20in\x20list");
      else
        (_0x48dccc["push"](_0x158aaf),
          chrome["storage"]["local"]["set"]({ skuList: _0x48dccc }, () => {
            _0x4919e4();
          }));
    });
  });
}
function _0x44dcf3() {
  chrome["storage"]["local"]["get"]("skuList", (_0x57bfa7) => {
    console["log"]("skulist\x20check:\x20", _0x57bfa7["skuList"]);
  });
}
function _0x1578b6(_0x4b260c) {
  chrome["storage"]["local"]["get"]("skuList", (_0x2edd9e) => {
    var _0x3d348c = [],
      _0x10fd8b = _0x2edd9e["skuList"];
    for (var _0x3561b9 = 0x0; _0x3561b9 < _0x10fd8b["length"]; _0x3561b9++) {
      var _0xaaf034 = _0x10fd8b[_0x3561b9];
      _0x3d348c["push"](atob(_0xaaf034["SKU"]));
    }
    return _0x3d348c["indexOf"](_0x4b260c) > -0x1;
  });
}
function _0x18a9e6() {
  var _0x147575 = document["createElement"]("select");
  ((_0x147575["id"] = "color_id"),
    _0x147575["appendChild"](new Option("black", "black")),
    _0x147575["appendChild"](new Option("red", "red")),
    _0x147575["appendChild"](new Option("blue", "blue")),
    _0x147575["appendChild"](new Option("green", "green")),
    _0x147575["appendChild"](new Option("purple", "purple")),
    _0x147575["appendChild"](new Option("orange", "orange")),
    _0x147575["appendChild"](new Option("yellow", "yellow")),
    (_0x147575["style"]["display"] = "none"),
    document["body"]["prepend"](_0x147575),
    (document["getElementById"]("color_id")["onchange"] = function () {
      var _0x5b05b1 = document["getElementById"]("color_id")["value"];
      document["getElementById"]("the-textarea")["style"]["color"] = _0x5b05b1;
    }));
}
function _0x67abfd() {
  const _0x50b7ae = document["createElement"]("div"),
    _0x2be4c2 = document["createElement"]("label");
  ((_0x2be4c2["textContent"] = "Similar\x20Item\x20Number:"),
    (_0x2be4c2["style"]["marginRight"] = "8px"));
  const _0x3c15bc = document["createElement"]("input");
  return (
    (_0x3c15bc["type"] = "text"),
    (_0x3c15bc["id"] = "similar-item-number"),
    (_0x3c15bc["style"]["border"] = "1px\x20solid\x20#ccc"),
    (_0x3c15bc["style"]["borderRadius"] = "4px"),
    (_0x3c15bc["style"]["padding"] = "8px"),
    (_0x3c15bc["style"]["fontSize"] = "16px"),
    _0x50b7ae["appendChild"](_0x2be4c2),
    _0x50b7ae["appendChild"](_0x3c15bc),
    (_0x50b7ae["style"]["display"] = "inline-block"),
    (_0x50b7ae["style"]["marginLeft"] = "16px"),
    _0x50b7ae
  );
}
function _0x377b99() {
  const _0x45b360 = document["createElement"]("div");
  _0x45b360["classList"]["add"]("optional-promoted-listing");
  const _0x9577ff = document["createElement"]("label");
  ((_0x9577ff["textContent"] = "Promoted\x20Listing\x20Percentage\x20%:"),
    (_0x9577ff["style"]["marginRight"] = "8px"));
  const _0x471013 = document["createElement"]("input");
  return (
    (_0x471013["type"] = "number"),
    (_0x471013["id"] = "promoted-listing"),
    (_0x471013["style"]["border"] = "1px\x20solid\x20#ccc"),
    (_0x471013["style"]["borderRadius"] = "4px"),
    (_0x471013["style"]["padding"] = "8px"),
    (_0x471013["style"]["fontSize"] = "16px"),
    (_0x471013["min"] = "2"),
    (_0x471013["max"] = "99"),
    (_0x471013["step"] = "0.1"),
    _0x45b360["appendChild"](_0x9577ff),
    _0x45b360["appendChild"](_0x471013),
    (_0x45b360["style"]["display"] = "inline-block"),
    (_0x45b360["style"]["marginLeft"] = "16px"),
    chrome["storage"]["local"]["get"](
      "promoted_listing_ad_rate",
      async function (_0x1780d5) {
        var _0x1e7e45 = _0x1780d5["promoted_listing_ad_rate"];
        ((void 0x0 === _0x1e7e45 || isNaN(_0x1e7e45)) &&
          ((_0x1e7e45 = 2.1),
          chrome["storage"]["local"]["set"]({
            promoted_listing_ad_rate: _0x1e7e45,
          })),
          (_0x471013["value"] = _0x1e7e45));
      },
    ),
    _0x45b360
  );
}
function _0x371599() {
  const _0x474fc4 = document["createElement"]("div"),
    _0x475b70 = document["createElement"]("label");
  _0x475b70["textContent"] = "Sell\x20it\x20for:";
  const _0x47f877 = document["createElement"]("input");
  return (
    (_0x47f877["type"] = "number"),
    (_0x47f877["min"] = "0"),
    (_0x47f877["step"] = "0.01"),
    (_0x47f877["id"] = "sell-price"),
    (_0x47f877["style"]["border"] = "1px\x20solid\x20#ccc"),
    (_0x47f877["style"]["borderRadius"] = "4px"),
    (_0x47f877["style"]["padding"] = "8px"),
    (_0x47f877["style"]["fontSize"] = "16px"),
    chrome["storage"]["local"]["get"](
      "markupPrice",
      async function (_0x5d69df) {
        const _0x45c264 = _0x5d69df["markupPrice"];
        if (void 0x0 !== _0x45c264) {
          var _0x2491f3 = getAmazonPrice();
          _0x2491f3 < 0x0 && (_0x2491f3 = product_data["price"]);
          let _0x441791 = _0x2491f3 * (0x1 + _0x45c264 / 0x64);
          _0x441791 = Math["ceil"](_0x441791);
          var _0x1432b3 = await chrome["storage"]["local"]["get"]("end_price"),
            _0x5733ac = 0x1 - (_0x1432b3 = parseFloat(_0x1432b3["end_price"]));
          (0x1 == _0x5733ac && (_0x5733ac = 0x0),
            (_0x441791 -= _0x5733ac),
            (_0x47f877["value"] = _0x441791));
        }
      },
    ),
    _0x474fc4["appendChild"](_0x475b70),
    _0x474fc4["appendChild"](_0x47f877),
    (_0x474fc4["style"]["display"] = "inline-block"),
    (_0x474fc4["style"]["marginLeft"] = "16px"),
    _0x474fc4
  );
}
function _0x11db40(_0x3d9f4b, _0x4da31c, _0x3cc518) {
  var _0x444b65 = document["querySelectorAll"](_0x3d9f4b);
  for (let _0x18ab75 = 0x0; _0x18ab75 < _0x444b65["length"]; _0x18ab75++) {
    var _0x226583 = _0x444b65[_0x18ab75],
      _0x25cedc = _0x226583["innerText"]["split"]("\x20"),
      _0x5842f7 = "";
    for (let _0x29a811 = 0x0; _0x29a811 < _0x25cedc["length"]; _0x29a811++) {
      var _0x44a8b2 = _0x25cedc[_0x29a811];
      ((_0x5842f7 +=
        "\x20" +
        (_0x44a8b2 =
          "<" +
          _0x4da31c +
          "\x20class=\x22" +
          _0x3cc518 +
          "\x22>" +
          _0x44a8b2 +
          "</" +
          _0x4da31c +
          ">")),
        console["log"](_0x5842f7));
    }
    (console["log"](_0x5842f7), (_0x226583["innerHTML"] = _0x5842f7));
  }
}
function _0xe97be9() {
  (_0x11db40("#productTitle", "div", "word"),
    $("#productTitle")["sortable"](),
    console["log"]("made\x20sortable"));
}
function _0x4fcdbb() {
  $("#the-textarea")["highlightWithinTextarea"]({
    highlight: [0x0, 0x50],
    className: "green",
  });
  var _0x164843 = document["getElementById"]("the-textarea");
  ((_0x164843["cols"] = "200"), (_0x164843["rows"] = "3"));
}
async function _0x508d36() {
  try {
    var _0x144414 = document["getElementById"]("skiplink");
    _0x144414["parentNode"]["removeChild"](_0x144414);
  } catch (_0x1f1610) {
    console["log"]("error:\x20", _0x1f1610);
  }
  _0x18a9e6();
  var _0x18a369 = _0x371599(),
    _0x265fea = _0x67abfd(),
    _0xa44c5b = _0x377b99(),
    _0x441b7e = await _0x3ecec2(),
    _0x3325ba = await _0x4bba3f(),
    _0x7c00e1 = _0x40b08f(),
    _0x14425f = _0x11e2c5(),
    _0x2569e7 = await _0x400837();
  (_0xc37410 = document["createElement"]("div"))["id"] =
    "sniper-action-buttons";
  var _0x137413 = await _0x5a64f6();
  (console["log"]("spinner:\x20", _0x137413),
    _0xc37410["appendChild"](_0x3325ba),
    _0xc37410["appendChild"](_0x441b7e),
    _0xc37410["appendChild"](_0x137413),
    _0xc37410["appendChild"](_0x14425f),
    _0xc37410["appendChild"](_0x2569e7),
    _0xc37410["appendChild"](_0x7c00e1),
    _0xc37410["appendChild"](_0x18a369),
    _0xc37410["appendChild"](_0x265fea));
  var _0x30372d = _0x146dc6();
  (_0xc37410["appendChild"](_0x30372d), _0xc37410["appendChild"](_0xa44c5b));
  var { useReviewImages: _0x549a45 } =
    await chrome["storage"]["local"]["get"]("useReviewImages");
  if (_0x549a45) {
    var _0x5bf910 = _0x343201();
    _0xc37410["appendChild"](_0x5bf910);
  }
  var { useCustomImagePrompt: _0x753aac } = await chrome["storage"]["local"][
    "get"
  ]("useCustomImagePrompt");
  if (_0x753aac) {
    var _0x61559b = await createGenerateImageDivV2();
    _0xc37410["appendChild"](_0x61559b);
  }
  (await new Promise((_0x363f13) => {
    const _0x2ffe8b = setInterval(() => {
      document["querySelector"]("#listingToEbayUiButtons") &&
        (clearInterval(_0x2ffe8b), _0x363f13());
    }, 0x64);
  }),
    document["querySelector"]("#listingToEbayUiButtons")["appendChild"](
      _0xc37410,
    ));
  var _0x5c7cfc = document["querySelector"]("#listingToEbayUiStatus"),
    _0x8e27de = document["createElement"]("span");
  ((_0x8e27de["className"] = "counted"),
    (_0x8e27de["id"] = "maximum"),
    (_0x8e27de["text"] = "/\x2080"));
  var _0xadaa61 = document["createElement"]("span");
  ((_0xadaa61["className"] = "counted"),
    (_0xadaa61["id"] = "current"),
    (_0xadaa61["text"] = "0"));
  var _0x2d127b = document["createElement"]("textarea");
  ((_0x2d127b["id"] = "the-textarea"),
    (_0x2d127b["cols"] = "20"),
    (_0x2d127b["rows"] = "3"));
  var _0x27a533 = "";
  for (let _0x3e59ce = 0x0; _0x3e59ce < 0x50; _0x3e59ce++) _0x27a533 += "a";
  _0x2d127b["value"] = _0x27a533;
  var _0xc37410;
  (((_0xc37410 = document["createElement"]("div"))["id"] = "divDroppedFields"),
    _0xc37410["appendChild"](_0x2d127b),
    _0x5c7cfc["appendChild"](_0xc37410),
    _0x5c7cfc["appendChild"](_0xadaa61),
    _0x5c7cfc["appendChild"](_0x8e27de),
    _0x4fcdbb());
  try {
    _0x2d127b["value"] = getFilteredTitle();
  } catch (_0x1c36fd) {
    _0x2d127b["value"] = product_data["title"];
  }
  (_0x1e94d7(),
    $("textarea")["keyup"](function () {
      _0x1e94d7();
    }));
  function _0x1e94d7() {
    var _0x2ad6af = $("#the-textarea")["val"]()["length"],
      _0x11376c = $("#current"),
      _0x50748a = $("#maximum");
    ($("#the-count"),
      _0x11376c["text"](_0x2ad6af),
      _0x50748a["text"]("/\x2080"));
  }
}
window["location"]["href"]["indexOf"]("/dp/") > -0x1 &&
  _0x508d36()["catch"]((_0x457293) => console["error"](_0x457293));
function _0x4828c7() {
  return new Promise((_0x34ed5d) => {
    const _0x58a1a6 = setInterval(() => {
      document["querySelectorAll"]("[class*=\x27media-gallery-item\x27]")[
        "length"
      ] > 0x0 &&
        (console["log"](
          "Media\x20items\x20found,\x20proceeding\x20with\x20adding\x20event\x20listeners",
        ),
        clearInterval(_0x58a1a6),
        _0x34ed5d());
    }, 0x1f4);
  });
}
var _0x1d61f7 = [];
function _0x343201() {
  var _0x17f6da = document["createElement"]("button");
  ((_0x17f6da["id"] = "import-review-images-button"),
    (_0x17f6da["textContent"] = "Load\x20Review\x20Images"),
    _0x17f6da["classList"]["add"]("rainbow-button"));
  if (0x0 === product_data["main_hd_images"]["length"]) {
    var _0x9442df = document["createElement"]("div");
    ((_0x9442df["innerHTML"] = "No\x20Review\x20Images\x20Found"),
      (_0x9442df["style"]["color"] = "red"),
      (_0x9442df["style"]["fontWeight"] = "bold"),
      (_0x9442df["style"]["fontSize"] = "20px"),
      (_0x9442df["style"]["padding"] = "10px"),
      document["getElementById"]("imagesContainer")["appendChild"](_0x9442df),
      (_0x17f6da = _0x9442df));
  } else
    _0x17f6da["onclick"] = async function () {
      console["log"]("Button\x20clicked");
      var _0x2967c8 = document["querySelector"](
        "[data-csa-c-slot-id*=\x22see_all_image\x22]",
      );
      if (_0x2967c8)
        (_0x2967c8["click"](),
          console["log"]("Carousel\x20clicked"),
          await _0x4828c7(),
          _0x572d14());
      else console["log"]("Carousel\x20element\x20not\x20found");
    };
  return _0x17f6da;
}
function _0x572d14() {
  function addEventListeners(_0x350fcc) {
    _0x350fcc["forEach"]((_0x3a8669) => {
      !_0x3a8669["hasAttribute"]("data-listener-attached") &&
        (_0x3a8669["setAttribute"]("data-listener-attached", "true"),
        _0x3a8669["addEventListener"]("click", async function (_0x43395c) {
          (_0x43395c["preventDefault"](),
            _0x43395c["stopPropagation"](),
            console["log"]("Media\x20item\x20clicked"),
            (_0x3a8669["style"]["border"] = "5px\x20solid\x20red"));
          var _0x16a015 = _0x3a8669["querySelector"]("img");
          if (_0x16a015) {
            var _0x944783 = _0x16a015["src"];
            _0x944783 = enlargeAmazonImage(_0x944783);
            var _0x10b00c = await urlToImage(_0x944783);
            (createImageAndAppend(_0x10b00c, !0x0),
              _0x24859c("Picture\x20added!"));
          } else
            console["log"](
              "No\x20image\x20found\x20in\x20the\x20clicked\x20item.",
            );
        }));
    });
  }
  addEventListeners(
    document["querySelectorAll"]("[class*=\x27media-gallery-item\x27]"),
  );
  var _0x327d94 = document["querySelectorAll"](".a-popover-wrapper")[0x3];
  _0x327d94
    ? new MutationObserver(function (_0x3bf4cf) {
        _0x3bf4cf["forEach"]((_0xfda0c4) => {
          _0xfda0c4["addedNodes"]["forEach"]((_0x56d423) => {
            _0x56d423["nodeType"] === Node["ELEMENT_NODE"] &&
              _0x56d423["matches"]("[class*=\x27media-gallery-item\x27]") &&
              addEventListeners([_0x56d423]);
          });
        });
      })["observe"](_0x327d94, { childList: !0x0, subtree: !0x0 })
    : console["error"](
        "Failed\x20to\x20find\x20the\x20container\x20to\x20observe.\x20Check\x20the\x20selector.",
      );
}
function _0x24859c(_0x13020b) {
  const _0x2913a1 = document["createElement"]("div");
  ((_0x2913a1["className"] = "popup-notification"),
    (_0x2913a1["textContent"] = _0x13020b),
    document["body"]["appendChild"](_0x2913a1));
  var _0x4ef5d3 = _0x1d61f7["length"];
  ((_0x2913a1["style"]["right"] = 0x14 + ((0x5 * _0x4ef5d3) % 0x64) + "px"),
    (_0x2913a1["style"]["top"] = 0x32 + ((0x5 * _0x4ef5d3) % 0x64) + "px"),
    _0x1d61f7["push"](_0x2913a1),
    setTimeout(() => {
      ((_0x2913a1["style"]["opacity"] = "0"),
        setTimeout(() => {
          const _0x378418 = _0x1d61f7["indexOf"](_0x2913a1);
          (-0x1 !== _0x378418 && _0x1d61f7["splice"](_0x378418, 0x1),
            _0x2913a1["remove"]());
        }, 0x1f4));
    }, 0xbb8));
}
function _0xe90aaf() {
  var _0x887c81 = document["createElement"]("button");
  ((_0x887c81["id"] = "replace-and-button"),
    (_0x887c81["textContent"] = "Replace\x20\x27and\x27\x20with\x20\x27&\x27"),
    (_0x887c81["onclick"] = function () {
      console["log"]("clicked\x20button");
      var _0x5458d9 = document["getElementById"]("the-textarea"),
        _0x293555 = _0x5458d9["value"];
      (console["log"]("text:\x20" + _0x293555),
        (_0x293555 = _0x293555["replace"](/\band\b/gi, "&")),
        (_0x5458d9["value"] = _0x293555),
        updateCharacterCount());
    }),
    document["body"]["prepend"](_0x887c81));
}
function _0x4ebf81() {
  var _0xee8e73 = document["createElement"]("button");
  ((_0xee8e73["id"] = "replace-with-button"),
    (_0xee8e73["textContent"] =
      "Replace\x20\x27with\x27\x20with\x20\x27/w\x27"),
    (_0xee8e73["onclick"] = function () {
      console["log"]("clicked\x20button");
      var _0x584c63 = document["getElementById"]("the-textarea"),
        _0x10d84e = _0x584c63["value"];
      (console["log"]("text:\x20" + _0x10d84e),
        (_0x10d84e = _0x10d84e["replace"](/\bwith\b/gi, "w/")),
        (_0x584c63["value"] = _0x10d84e),
        updateCharacterCount());
    }),
    document["body"]["prepend"](_0xee8e73));
}
function _0x5d2716() {
  var _0x2a4e44 = document["createElement"]("button");
  ((_0x2a4e44["id"] = "replace-unnecessary-button"),
    (_0x2a4e44["textContent"] = "Lower\x20Case\x20Unnecessary\x20Words"),
    (_0x2a4e44["onclick"] = function () {
      console["log"]("clicked\x20button");
      var _0x41ce83 = document["getElementById"]("the-textarea"),
        _0x4b64d8 = _0x41ce83["value"];
      (console["log"]("text:\x20" + _0x4b64d8),
        (_0x4b64d8 = (_0x4b64d8 = (_0x4b64d8 = (_0x4b64d8 = (_0x4b64d8 =
          (_0x4b64d8 = (_0x4b64d8 = (_0x4b64d8 = (_0x4b64d8 = (_0x4b64d8 =
            _0x4b64d8["toLowerCase"]())["replace"](
            /\b([a-z])/gi,
            function (_0x46b041) {
              return _0x46b041["toUpperCase"]();
            },
          ))["replace"](/\band\b/gi, "&"))["replace"](/\bwith\b/gi, "with"))[
            "replace"
          ](/\band\b/gi, "and"))["replace"](/\bfor\b/gi, "for"))["replace"](
          /\bin\b/gi,
          "in",
        ))["replace"](/\bor\b/gi, "or"))["replace"](/\bof\b/gi, "of"))[
          "replace"
        ](/\bupto\b/gi, "upto")),
        (_0x41ce83["value"] = _0x4b64d8),
        updateCharacterCount());
    }),
    document["body"]["prepend"](_0x2a4e44));
}
function _0x5b186b() {
  var _0x5de723 = document["createElement"]("button");
  ((_0x5de723["id"] = "save-title-button"),
    (_0x5de723["textContent"] = "Save\x20The\x20Title\x20To\x20Top"),
    (_0x5de723["onclick"] = function () {
      console["log"]("clicked\x20button");
      var _0x398c91 = document["getElementById"]("the-textarea")["value"];
      console["log"]("text:\x20" + _0x398c91);
      var _0x1c4087 = document["getElementById"]("listing-data-table"),
        _0x4d9d5c = createRow(_0x1c4087);
      (createCell(_0x1c4087, {
        rowNumber: _0x4d9d5c,
        cellValue: _0x4d9d5c,
        headerName: "Rank",
      }),
        createCell(_0x1c4087, {
          rowNumber: _0x4d9d5c,
          cellValue: _0x398c91,
          headerName: "Title",
        }),
        createCell(_0x1c4087, {
          rowNumber: _0x4d9d5c,
          cellValue: "Manuel",
          headerName: "Type",
        }),
        createCell(_0x1c4087, {
          rowNumber: _0x4d9d5c,
          cellValue: _0x398c91["length"],
          headerName: "Total\x20Characters",
        }));
      var _0x312dff = createButtonToUpdateTextArea({
        buttonInnerText: "Change",
        textAreaSelector: "#the-textarea",
        valueToSet: _0x398c91,
        callback: updateTheCharacterCountOnTextArea,
      });
      createCellWithButton(_0x1c4087, {
        button: _0x312dff,
        rowNumber: _0x4d9d5c,
        headerName: "Action",
      });
    }),
    document["body"]["prepend"](_0x5de723));
}
function _0x9110c9() {
  var _0x30221e = document["createElement"]("button");
  ((_0x30221e["id"] = "update-google-sheets-button"),
    (_0x30221e["textContent"] = "Update\x20Google\x20Sheets"),
    (_0x30221e["onclick"] = function () {
      console["log"]("clicked\x20button");
      var _0x580eda = [],
        _0x1f1f77 = getProductDescriptionAndFeatures(),
        _0x39edf3 = getProductTitle(),
        _0x181188 = getTheAsinFromHref(),
        _0x4559be = document["getElementById"]("the-textarea")["value"];
      (_0x580eda["push"]({ key: "description", value: _0x1f1f77 }),
        _0x580eda["push"]({ key: "title", value: _0x39edf3 }),
        _0x580eda["push"]({ key: "asin", value: _0x181188 }),
        _0x580eda["push"]({ key: "customTitle", value: _0x4559be }),
        updateGoogleSheets(
          _0x580eda,
          "https://script.google.com/macros/s/AKfycby6JkD3JFSzYZhreDcB1SOcJ1gMiQjSd7gsX7y619hvnvILuUHOC0pcS7f3qspaIvrP/exec?",
        ));
    }),
    document["body"]["prepend"](_0x30221e));
}
async function _0x96c330() {
  var _0x4a1ea5 = document["createElement"]("button");
  ((_0x4a1ea5["id"] = "create-title-from-openai-button"),
    (_0x4a1ea5["textContent"] = "Create\x20Title"),
    (_0x4a1ea5["onclick"] = async function () {
      console["log"]("clicked\x20button");
      var _0x15838d = getProductDescriptionAndFeatures();
      console["log"]("text\x20to\x20feed\x20openAI", _0x15838d);
      var _0x462e0a = { title: getFilteredTitle(), description: _0x15838d },
        _0x3d5938 = await createOneTitle(_0x462e0a),
        _0x47c852 = document["getElementById"]("listing-data-table"),
        _0x23580a = createRow(_0x47c852);
      (createCell(_0x47c852, {
        rowNumber: _0x23580a,
        cellValue: _0x23580a,
        headerName: "Rank",
      }),
        createCell(_0x47c852, {
          rowNumber: _0x23580a,
          cellValue: _0x3d5938,
          headerName: "Title",
        }),
        createCell(_0x47c852, {
          rowNumber: _0x23580a,
          cellValue: "myAi",
          headerName: "Type",
        }),
        createCell(_0x47c852, {
          rowNumber: _0x23580a,
          cellValue: _0x3d5938["length"],
          headerName: "Total\x20Characters",
        }));
      var _0x30b332 = createButtonToUpdateTextArea({
        buttonInnerText: "Change",
        textAreaSelector: "#the-textarea",
        valueToSet: _0x3d5938,
        callback: updateTheCharacterCountOnTextArea,
      });
      createCellWithButton(_0x47c852, {
        button: _0x30b332,
        rowNumber: _0x23580a,
        headerName: "Action",
      });
    }),
    document["body"]["prepend"](_0x4a1ea5));
}
async function _0x28a622() {
  var _0x490d29 = document["createElement"]("button");
  ((_0x490d29["id"] = "create-10-title-from-openai-button"),
    (_0x490d29["textContent"] = "Create\x2010\x20Titles"),
    (_0x490d29["onclick"] = async function () {
      console["log"]("clicked\x20button");
      var _0x3d877d = getProductDescriptionAndFeatures();
      console["log"]("text\x20to\x20feed\x20openAI", _0x3d877d);
      var _0x3d3228 = { title: getFilteredTitle(), description: _0x3d877d },
        _0x1054d5 = await create10Titles(_0x3d3228);
      for (var _0x1aa196 = 0x0; _0x1aa196 < _0x1054d5["length"]; _0x1aa196++) {
        var _0x4ac039 = _0x1054d5[_0x1aa196],
          _0x177ea4 = document["getElementById"]("listing-data-table"),
          _0x35dc16 = createRow(_0x177ea4);
        (createCell(_0x177ea4, {
          rowNumber: _0x35dc16,
          cellValue: _0x35dc16,
          headerName: "Rank",
        }),
          createCell(_0x177ea4, {
            rowNumber: _0x35dc16,
            cellValue: _0x4ac039,
            headerName: "Title",
          }),
          createCell(_0x177ea4, {
            rowNumber: _0x35dc16,
            cellValue: "Multi-myAi-" + _0x1aa196,
            headerName: "Type",
          }),
          createCell(_0x177ea4, {
            rowNumber: _0x35dc16,
            cellValue: _0x4ac039["length"],
            headerName: "Total\x20Characters",
          }));
        var _0x18f947 = createButtonToUpdateTextArea({
          buttonInnerText: "Change",
          textAreaSelector: "#the-textarea",
          valueToSet: _0x4ac039,
          callback: updateTheCharacterCountOnTextArea,
        });
        createCellWithButton(_0x177ea4, {
          button: _0x18f947,
          rowNumber: _0x35dc16,
          headerName: "Action",
        });
      }
    }),
    document["body"]["prepend"](_0x490d29));
}
async function _0x2ee9e8() {
  var _0x2cc5ce = document["createElement"]("button");
  ((_0x2cc5ce["id"] = "create-simple-title-from-openai-button"),
    (_0x2cc5ce["textContent"] = "Create\x20Title\x20V3"),
    (_0x2cc5ce["onclick"] = async function () {
      console["log"]("clicked\x20button");
      var _0x22f62b = getProductDescriptionAndFeatures(),
        _0x2284a8 = getFilteredTitle(),
        _0x5d6b57 = await fetchPrompt("text_prompts/simple-prompt-title.txt");
      (console["log"]("prompt:\x20", _0x5d6b57),
        (_0x5d6b57 = (_0x5d6b57 = _0x5d6b57["replace"](
          "{{productTitle}}",
          _0x2284a8,
        ))["replace"]("{{productDescription}}", _0x22f62b)),
        console["log"]("prompt:\x20", _0x5d6b57));
      var _0x34caf4 =
        await receiveOpenAiResponseFromBackgroundScript(_0x5d6b57);
      _0x34caf4["error"]
        ? alert(
            "OpenAI:\x20" +
              _0x34caf4["error"]["message"] +
              "\x0aENTER\x20IN\x20NEW\x20API\x20KEY",
          )
        : _0xfc3a7f(_0x34caf4);
    }),
    document["body"]["prepend"](_0x2cc5ce));
}
function _0x4f9d9b() {
  let _0x5c0698,
    _0x1169b1,
    _0x336b9b = "";
  for (_0x5c0698 = 0x0; _0x5c0698 < 0x20; _0x5c0698++) {
    ((_0x1169b1 = (0x10 * Math["random"]()) | 0x0),
      (0x8 !== _0x5c0698 &&
        0xc !== _0x5c0698 &&
        0x10 !== _0x5c0698 &&
        0x14 !== _0x5c0698) ||
        (_0x336b9b += "-"),
      (_0x336b9b += (
        0xc === _0x5c0698
          ? 0x4
          : 0x10 === _0x5c0698
            ? (0x3 & _0x1169b1) | 0x8
            : _0x1169b1
      )["toString"](0x10)));
  }
  return _0x336b9b;
}
async function _0x45c67b() {
  var _0x9738c0 = getProductDescriptionAndFeatures(),
    _0x33b2c4 = getFilteredTitle() + "\x0a\x0a" + _0x9738c0;
  console["log"]("combinedTitleAndDescription:\x20", _0x33b2c4);
  var _0x1876da = await postToServer(
    "https://ebaysnipertitlebuilder.ngrok.io/api/TitleBuilder/BuildTitle",
    { request_type: "build_title", product_description: _0x33b2c4 },
  );
  return (
    console["log"]("getAiTitleFromApi\x20data:\x20", _0x1876da),
    _0x1876da["title"]
  );
}
async function _0x3ecec2() {
  const _0x65b17a = document["createElement"]("button");
  ((_0x65b17a["innerHTML"] = "<b>Snipe\x20Title\x20(1\x20credit)</b>"),
    (_0x65b17a["id"] = "create-title-v4"),
    _0x65b17a["classList"]["add"]("create-title-v4"));
  if ("ultimate" != (await checkMembership()))
    return (
      (_0x65b17a["disabled"] = !0x0),
      (_0x65b17a["innerHTML"] =
        "<b>Snipe\x20Title</b>\x20(Upgrade\x20for\x20access)"),
      (_0x65b17a["style"]["backgroundColor"] = "grey"),
      _0x65b17a
    );
  chrome["runtime"]["sendMessage"](
    { type: "checkCredits" },
    function (_0x5a6202) {
      console["log"]("createSnipeTitleButton\x20response:\x20", _0x5a6202);
      if (_0x5a6202["creditsAvailable"])
        _0x65b17a["onclick"] = function () {
          (console["log"]("clicked\x20button"),
            chrome["runtime"]["sendMessage"](
              { type: "checkCredits" },
              async function (_0x36ed68) {
                console["log"]("response:\x20", _0x36ed68);
                if (_0x36ed68["creditsAvailable"]) {
                  var { useCustomTitleGenerator: _0xf0a72b } = await chrome[
                    "storage"
                  ]["local"]["get"](["useCustomTitleGenerator"]);
                  if (_0xf0a72b) _0x27589f = await _0x4832af();
                  else {
                    var _0x27589f = await _0x2460f0();
                    _0x27589f &&
                      chrome["runtime"]["sendMessage"]({
                        type: "deductCredits",
                        amount: 0,
                      });
                  }
                } else
                  alert(
                    "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits.",
                  );
              },
            ));
        };
      else
        ((_0x65b17a["disabled"] = !0x0),
          (_0x65b17a["innerHTML"] = "<b>Snipe\x20Title</b>\x20(No\x20Credits)"),
          (_0x65b17a["style"]["backgroundColor"] = "grey"));
    },
  );
  var _0x5b6ab2 = createContextMenu("snipe-title-context-menu");
  return (
    _0x5b6ab2["addMenuItem"]("Customize\x20Your\x20Titles", function () {
      var _0x2e58cd = chrome["runtime"]["getURL"](
        "Prompt_Tester_page/index.html",
      );
      window["open"](_0x2e58cd, "_blank");
    }),
    _0x65b17a["addEventListener"]("contextmenu", function (_0x16f145) {
      (_0x16f145["preventDefault"](), _0x5b6ab2["showMenu"](_0x16f145));
    }),
    _0x65b17a
  );
}
async function _0x2a71f1() {
  var _0x4927f1 = document["createElement"]("button");
  ((_0x4927f1["id"] = "great_title_chat_gpt_web_version"),
    _0x4927f1["classList"]["add"]("list-button"));
  var _0x438ab1 = chrome["runtime"]["getURL"]("Favicons/OpenAi/icon.png"),
    _0x1e35bc = document["createElement"]("img");
  ((_0x1e35bc["src"] = _0x438ab1),
    (_0x1e35bc["style"]["width"] = "25px"),
    (_0x1e35bc["style"]["height"] = "25px"),
    (_0x1e35bc["style"]["marginRight"] = "5px"),
    _0x4927f1["appendChild"](_0x1e35bc));
  var _0xa656fe = await checkMembership();
  return (
    console["log"]("membership:\x20", _0xa656fe),
    "ultimate" == _0xa656fe
      ? ((_0x4927f1["disabled"] = !0x1),
        (_0x4927f1["innerHTML"] += "<b>Chat\x20Title\x20(1\x20Credit)</b>"))
      : ((_0x4927f1["disabled"] = !0x0),
        (_0x4927f1["innerHTML"] +=
          "<b>Chat\x20Title</b>\x20(No\x20Membership)"),
        (_0x4927f1["style"]["backgroundColor"] = "grey")),
    (_0x4927f1["onclick"] = async function () {
      ((_0x4927f1["disabled"] = !0x0),
        (_0x4927f1["style"]["backgroundColor"] = "grey"),
        (_0x4927f1["innerHTML"] = "<b>Chatting\x20Title...</b>"),
        await _0x1a5a31(),
        (_0x4927f1["innerHTML"] = "<b>Chatted\x20Title!</b>"),
        setTimeout(function () {
          ((_0x4927f1["innerHTML"] = ""),
            _0x4927f1["appendChild"](_0x1e35bc),
            (_0x4927f1["innerHTML"] +=
              "<b>Chat\x20Title\x20(0.5\x20Credit)</b>"),
            (_0x4927f1["disabled"] = !0x1),
            (_0x4927f1["style"]["backgroundColor"] = "#10a37f"));
        }, 0x7d0));
    }),
    _0x4927f1
  );
}
async function _0x4bba3f() {
  var _0x25a890 = document["createElement"]("button");
  ((_0x25a890["id"] = "clean-title-button"),
    _0x25a890["classList"]["add"]("list-button"),
    (_0x25a890["disabled"] = !0x0));
  var _0x3d47f0 = chrome["runtime"]["getURL"]("Favicons/addons/sparkle.png"),
    _0xdc45aa = document["createElement"]("img");
  ((_0xdc45aa["src"] = _0x3d47f0),
    (_0xdc45aa["style"]["width"] = "25px"),
    (_0xdc45aa["style"]["height"] = "25px"),
    (_0xdc45aa["style"]["marginRight"] = "5px"),
    _0x25a890["appendChild"](_0xdc45aa));
  var _0xa04d1 = await checkMembership();
  console["log"]("membership:\x20", _0xa04d1);
  if ("ultimate" == _0xa04d1) _0x25a890["innerHTML"] += "<b>Clean\x20Title</b>";
  else
    ((_0x25a890["disabled"] = !0x0),
      (_0x25a890["innerHTML"] += "<b>Clean\x20Title</b>\x20(No\x20Membership)"),
      (_0x25a890["style"]["backgroundColor"] = "grey"));
  return (
    (_0x25a890["onclick"] = async function () {
      ((_0x25a890["disabled"] = !0x0),
        (_0x25a890["innerHTML"] = "<b>Cleaning\x20Title...</b>"),
        await _0x47ae9f(),
        (_0x25a890["innerHTML"] = "<b>Cleaned\x20Title!</b>"),
        setTimeout(function () {
          ((_0x25a890["innerHTML"] = "<b>Clean\x20Title</b>"),
            (_0x25a890["disabled"] = !0x1));
        }, 0x7d0));
    }),
    _0x25a890
  );
}
async function _0x4066b4(_0x150efa, _0x325863) {
  var _0x4ccd15 = await fetch(
    chrome["runtime"]["getURL"]("text_prompts/CleanTitlePrompts/v1.txt"),
  )["then"]((_0x3b4f6f) => _0x3b4f6f["text"]());
  ((_0x4ccd15 = (_0x4ccd15 = _0x4ccd15["replace"](
    "{{Competitor_title}}",
    _0x325863,
  ))["replace"]("{{Our_title}}", _0x150efa)),
    console["log"]("textPrompt", _0x4ccd15));
  var _0x3370d8 = {
      model: "o1-preview",
      messages: [{ role: "user", content: _0x4ccd15 }],
    },
    _0x2ac475 = await new Promise((_0x2b8594, _0x4362dd) => {
      chrome["runtime"]["sendMessage"](
        {
          type: "fetchData",
          url: "https://openai-chat-completion-djybcnnsgq-uc.a.run.app",
          data: _0x3370d8,
        },
        function (_0x48d2b8) {
          _0x2b8594(_0x48d2b8["data"]);
        },
      );
    });
  console["log"]("data", _0x2ac475);
  if (!_0x2ac475) return "Error:\x20No\x20data\x20returned";
  return (
    (_0x2ac475 = (_0x2ac475 = _0x2ac475["content"])["substring"](
      _0x2ac475["indexOf"]("{"),
      _0x2ac475["lastIndexOf"]("}") + 0x1,
    )),
    (_0x2ac475 = JSON["parse"](_0x2ac475)),
    console["log"]("reasoning", _0x2ac475["reasoning"]),
    _0x2ac475["restructured_title"]
  );
}
async function _0x1b648a(_0x2d05fb, _0x36c8e6) {
  var _0x5950d6 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/clean_title.json"),
  )["then"]((_0x2351f3) => _0x2351f3["json"]());
  ((_0x5950d6["user_input"] =
    "Unfiltered\x20Title\x20To\x20Mimic:\x20" +
    _0x2d05fb +
    "\x20\x0a\x0a\x0aItem\x20Details:\x0a" +
    _0x36c8e6),
    console["log"]("jsonPrompt", _0x5950d6));
  var _0x9b05ed = await new Promise((_0x717bef, _0x1092b2) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x5950d6,
      },
      function (_0x40ab1f) {
        _0x717bef(_0x40ab1f["data"]);
      },
    );
  });
  (console["log"]("data", _0x9b05ed),
    (_0x9b05ed = JSON["parse"](_0x9b05ed)),
    console["log"]("data", _0x9b05ed));
  var _0x4ada0f = _0x9b05ed["optimized_title"];
  try {
    var _0x2bbfdc = _0x9b05ed["brand"];
    _0x4ada0f = (_0x4ada0f = _0x4ada0f["replace"](
      new RegExp(_0x2bbfdc, "gi"),
      "",
    ))["trim"]();
  } catch (_0x57eb42) {
    console["log"]("error:\x20", _0x57eb42);
  }
  return _0x4ada0f;
}
async function _0xed5311() {
  var _0x2cea30 = document["createElement"]("button");
  ((_0x2cea30["id"] = "create-seo-title-v4"),
    _0x2cea30["classList"]["add"]("list-button"));
  var _0x138f22 = chrome["runtime"]["getURL"]("Favicons/OpenAi/icon.png"),
    _0x32d0d9 = document["createElement"]("img");
  ((_0x32d0d9["src"] = _0x138f22),
    (_0x32d0d9["style"]["width"] = "25px"),
    (_0x32d0d9["style"]["height"] = "25px"),
    (_0x32d0d9["style"]["marginRight"] = "5px"),
    _0x2cea30["appendChild"](_0x32d0d9));
  var _0x2ddfc6 = await checkMembership();
  return (
    console["log"]("membership:\x20", _0x2ddfc6),
    "ultimate" == _0x2ddfc6
      ? ((_0x2cea30["disabled"] = !0x1),
        (_0x2cea30["innerHTML"] += "<b>SEO\x20Title</b>"))
      : ((_0x2cea30["disabled"] = !0x0),
        (_0x2cea30["innerHTML"] += "<b>SEO\x20Title</b>\x20(No\x20Membership)"),
        (_0x2cea30["style"]["backgroundColor"] = "grey")),
    (_0x2cea30["onclick"] = async function () {
      ((_0x2cea30["disabled"] = !0x0),
        (_0x2cea30["style"]["backgroundColor"] = "grey"),
        (_0x2cea30["innerHTML"] = "<b>Sniping\x20SEO\x20Title...</b>"),
        await _0x4ee7c9(),
        (_0x2cea30["innerHTML"] = "<b>Sniped\x20SEO\x20Title!</b>"),
        setTimeout(function () {
          ((_0x2cea30["innerHTML"] = "<b>SEO\x20Title</b>"),
            (_0x2cea30["disabled"] = !0x1),
            (_0x2cea30["style"]["backgroundColor"] = "#3a86ff"));
        }, 0x7d0));
    }),
    _0x2cea30
  );
}
async function _0x47ae9f() {
  (turnOffFavicon(), _0x2f5124());
  var _0x27713a = getTheAsinFromHref();
  ((document["title"] =
    "Cleaning\x20The\x20Perfect\x20Title\x20-\x20" +
    _0x27713a +
    "please\x20wait..."),
    changeFaviconToSniper(),
    console["log"]("clicked\x20button"));
  var _0x2faf18 = getProductDescriptionAndFeatures(),
    _0x113f14 =
      "(Product\x20Title):\x20" +
      getFilteredTitle() +
      "\x0a\x0a(Product\x20Description):\x20" +
      _0x2faf18,
    _0x22d8bd = await _0x1b648a(
      document["querySelector"]("#the-textarea")["value"],
      _0x113f14,
    );
  (console["log"]("cleanedTitle:\x20", _0x22d8bd),
    changeFaviconOfPage(
      chrome["runtime"]["getURL"]("Favicons/Completed/received.png"),
    ),
    _0xe22f66(_0x22d8bd, "Cleaned\x20Title"));
  var _0x4d919e = document["getElementById"]("listing-data-table"),
    _0x23d76d =
      _0x4d919e["rows"][_0x4d919e["rows"]["length"] - 0x1]["querySelector"](
        ".title-cell",
      );
  return (
    flyInText(_0x22d8bd, _0x23d76d),
    _0x2ea127(),
    await new Promise((_0x3a885e) => setTimeout(_0x3a885e, 0x12c)),
    _0x13b0f3(),
    _0x4c9954(),
    (document["querySelector"]("#the-textarea")["value"] = _0x22d8bd),
    updateTheCharacterCountOnTextArea(),
    _0x22d8bd
  );
}
async function _0x4ee7c9(_0x150531 = !0x1) {
  (turnOffFavicon(), _0x2f5124());
  var _0x47ba60 = getTheAsinFromHref();
  ((document["title"] =
    "Creating\x20The\x20Perfect\x20Title\x20-\x20" +
    _0x47ba60 +
    "please\x20wait..."),
    changeFaviconToSniper(),
    console["log"]("clicked\x20button"));
  var _0x5364e5 = getProductDescriptionAndFeatures(),
    _0x27ca50 = getFilteredTitle(),
    _0x787981 = getHighResProductPictures(),
    _0x4988dc = getProductPictures(),
    _0x36df5a;
  _0x36df5a = _0x787981["length"] > 0x0 ? _0x787981[0x0] : _0x4988dc[0x0];
  if (_0x150531) var _0x31c9b0 = await buildTheSeoTitles(_0x27ca50, _0x5364e5);
  else {
    var _0x13f409 = {
      title: _0x27ca50,
      description: _0x5364e5,
      imageUrl: _0x36df5a,
    };
    _0x31c9b0 = await new Promise((_0x3a85f0, _0x3e0a41) => {
      chrome["runtime"]["sendMessage"](
        { type: "ask_bg_build_the_seo_titles", options: _0x13f409 },
        function (_0x29926b) {
          _0x3a85f0(_0x29926b["seoTitles"]);
        },
      );
    });
  }
  (console["log"]("titles:\x20", _0x31c9b0),
    changeFaviconOfPage(
      chrome["runtime"]["getURL"]("Favicons/Completed/received.png"),
    ));
  var _0x1ec6f1 = "";
  for (var _0x4ba26f = 0x0; _0x4ba26f < _0x31c9b0["length"]; _0x4ba26f++)
    (_0x27ca50 = _0x31c9b0[_0x4ba26f])["length"] > _0x1ec6f1["length"] &&
      _0x27ca50["length"] <= 0x50 &&
      (_0x1ec6f1 = _0x27ca50);
  0x0 == _0x1ec6f1["length"] && (_0x1ec6f1 = _0x31c9b0[0x0]);
  for (_0x4ba26f = 0x0; _0x4ba26f < _0x31c9b0["length"]; _0x4ba26f++) {
    var _0x4b0713 = _0x31c9b0[_0x4ba26f];
    _0xe22f66(
      _0x4b0713,
      _0x1ec6f1 == _0x4b0713
        ? "Perfect\x20SEO\x20Title"
        : "Great\x20SEO\x20Title",
    );
    var _0x3f294e = document["getElementById"]("listing-data-table"),
      _0x117033 =
        _0x3f294e["rows"][_0x3f294e["rows"]["length"] - 0x1]["querySelector"](
          ".title-cell",
        );
    (flyInText(_0x4b0713, _0x117033),
      _0x2ea127(),
      await new Promise((_0x3a178e) => setTimeout(_0x3a178e, 0x12c)),
      _0x13b0f3());
  }
  return (
    _0x4c9954(),
    _0x2ea127(),
    await new Promise((_0x488426) => setTimeout(_0x488426, 0x7d0)),
    _0x13b0f3(),
    (document["querySelector"]("#the-textarea")["value"] = _0x1ec6f1),
    updateTheCharacterCountOnTextArea(),
    _0x1ec6f1
  );
}
async function _0x1a5a31() {
  (turnOffFavicon(), _0x2f5124());
  var _0x5ece3b = getTheAsinFromHref();
  ((document["title"] =
    "Creating\x20The\x20Perfect\x20Title\x20-\x20" +
    _0x5ece3b +
    "please\x20wait..."),
    changeFaviconToSniper(),
    console["log"]("clicked\x20button"));
  var _0x2f9233 = getProductDescriptionAndFeatures(),
    _0x3e34ab = getFilteredTitle(),
    _0x1853cf = await askChatGptForHighQualityTitles(_0x3e34ab, _0x2f9233);
  (console["log"]("titles:\x20", _0x1853cf),
    changeFaviconOfPage(
      chrome["runtime"]["getURL"]("Favicons/Completed/received.png"),
    ));
  var _0x1984a1 = "";
  for (var _0x437100 = 0x0; _0x437100 < _0x1853cf["length"]; _0x437100++)
    (_0x3e34ab = _0x1853cf[_0x437100])["length"] > _0x1984a1["length"] &&
      _0x3e34ab["length"] <= 0x50 &&
      (_0x1984a1 = _0x3e34ab);
  0x0 == _0x1984a1["length"] && (_0x1984a1 = _0x1853cf[0x0]);
  for (_0x437100 = 0x0; _0x437100 < _0x1853cf["length"]; _0x437100++) {
    var _0x5ade85 = _0x1853cf[_0x437100];
    _0xe22f66(
      _0x5ade85,
      _0x1984a1 == _0x5ade85 ? "Perfect\x20Title" : "Great\x20Title",
    );
    var _0x39579a = document["getElementById"]("listing-data-table"),
      _0xb45700 =
        _0x39579a["rows"][_0x39579a["rows"]["length"] - 0x1]["querySelector"](
          ".title-cell",
        );
    (flyInText(_0x5ade85, _0xb45700),
      _0x2ea127(),
      await new Promise((_0x378a40) => setTimeout(_0x378a40, 0x12c)),
      _0x13b0f3());
  }
  return (
    _0x4c9954(),
    _0x2ea127(),
    await new Promise((_0xb72b4b) => setTimeout(_0xb72b4b, 0x7d0)),
    _0x13b0f3(),
    (document["querySelector"]("#the-textarea")["value"] = _0x1984a1),
    updateTheCharacterCountOnTextArea(),
    _0x1984a1
  );
}
async function _0x577afb() {
  var _0x1d22bb = document["createElement"]("button");
  return (
    (_0x1d22bb["innerHTML"] = "Snipe\x20Title\x20🎯"),
    chrome["runtime"]["getURL"]("icons/Sniper.png"),
    (_0x1d22bb["id"] = "create-title-v4"),
    _0x1d22bb["classList"]["add"]("create-title-v4"),
    (_0x1d22bb["onclick"] = async function () {
      (console["log"]("clicked\x20button"),
        chrome["runtime"]["sendMessage"](
          { type: "checkCredits" },
          function (_0x1d1987) {
            console["log"]("response:\x20", _0x1d1987);
            if (_0x1d1987["creditsAvailable"])
              (chrome["runtime"]["sendMessage"]({
                type: "deductCredits",
                amount: 0,
              }),
                _0x151a59());
            else
              alert(
                "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits.",
              );
          },
        ));
    }),
    _0x1d22bb
  );
}
async function _0x151a59() {
  var _0x448c89 = document["querySelector"]("#create-title-v4");
  ((_0x448c89["disabled"] = !0x0),
    (_0x448c89["style"]["backgroundColor"] = "grey"),
    (_0x448c89["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    turnOffFavicon(),
    _0x2f5124());
  var _0x316ff0 = getTheAsinFromHref();
  ((document["title"] =
    "Creating\x20The\x20Perfect\x20Title\x20-\x20" +
    _0x316ff0 +
    "please\x20wait..."),
    changeFaviconToSniper());
  var _0x52f45f = await _0x45c67b();
  (console["log"](
    "\x20createTitleV4AndAppendToTable\x20ai_title:\x20",
    _0x52f45f,
  ),
    changeFaviconOfPage(
      chrome["runtime"]["getURL"]("Favicons/Completed/received.png"),
    ),
    await new Promise((_0xc23716) => setTimeout(_0xc23716, 0x3e8)),
    console["log"]("finished\x20waiting\x201\x20second"),
    (document["title"] = "Received\x20Title:\x20\x22" + _0x52f45f + "\x22"),
    _0xe22f66(_0x52f45f, "Perfect\x20Title"),
    console["log"]("finished\x20createCellWithTitle"));
  var _0xbb0dd5 = document["getElementById"]("listing-data-table"),
    _0x2701c6 =
      _0xbb0dd5["rows"][_0xbb0dd5["rows"]["length"] - 0x1]["querySelector"](
        ".title-cell",
      );
  return (
    console["log"]("finished\x20tableRow.querySelector(.title-cell);"),
    _0x52f45f || (_0x52f45f = "undefined"),
    flyInText(_0x52f45f, _0x2701c6),
    console["log"]("finished\x20flyInText"),
    (document["querySelector"]("#the-textarea")["value"] = _0x52f45f),
    console["log"]("finished\x20textArea.value\x20=\x20ai_title;"),
    _0x4c9954(),
    _0x2ea127(),
    await new Promise((_0x400667) => setTimeout(_0x400667, 0x7d0)),
    _0x13b0f3(),
    (_0x448c89["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x448c89["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x448c89["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x448c89["disabled"] = !0x1));
    }, 0x7d0),
    _0x52f45f
  );
}
async function _0x2460f0(_0x278d39, _0x5184d1) {
  var _0x441fec = document["querySelector"]("#create-title-v4");
  ((_0x441fec["disabled"] = !0x0),
    (_0x441fec["style"]["backgroundColor"] = "grey"),
    (_0x441fec["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    turnOffFavicon(),
    _0x2f5124(),
    console["log"]("create10TitlesV3AndAppendToTable"));
  if (!_0x278d39)
    try {
      _0x278d39 = getFilteredTitle();
    } catch (_0x4e4880) {
      if (!product_data["filteredTitle"])
        throw new Error("No\x20title\x20found");
      ((_0x278d39 = product_data["filteredTitle"]),
        (_0x5184d1 = product_data["descriptionText"]));
    }
  _0x5184d1 || (_0x5184d1 = getProductDescriptionAndFeatures());
  var { domain: _0x3c2111 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x57f546 = (function (_0x6c09e9) {
      return "de" == _0x6c09e9
        ? "german"
        : "com" == _0x6c09e9 || "co.uk" == _0x6c09e9
          ? "english"
          : "fr" == _0x6c09e9
            ? "french"
            : "it" == _0x6c09e9
              ? "italian"
              : "es" == _0x6c09e9
                ? "spanish"
                : "english";
    })(_0x3c2111),
    { email: _0x5a5c56 } = await chrome["storage"]["local"]["get"](["email"]),
    _0x3edf3b = await postToServer(
      "https://gemini-title-api-791896956785.us-central1.run.app",
      {
        request_type: "generate_10_titles",
        product_description: _0x5184d1,
        product_title: _0x278d39,
        language: _0x57f546,
        email: _0x5a5c56,
      },
    );
  console["log"]("create10TitlesV3AndAppendToTable\x20data:\x20", _0x3edf3b);
  var _0x41090b = _0x3edf3b;
  if (!_0x41090b)
    return (
      _0xe22f66("Error\x20-\x20Try\x20Again", "Perfect\x20Title"),
      _0x4c9954(),
      _0x2ea127(),
      await new Promise((_0xc81f4f) => setTimeout(_0xc81f4f, 0x7d0)),
      _0x13b0f3(),
      (_0x441fec["innerHTML"] = "<b>Sniped\x20Title!</b>"),
      (_0x441fec["style"]["backgroundColor"] = "#3a86ff"),
      setTimeout(function () {
        ((_0x441fec["innerHTML"] = "<b>Snipe\x20Title</b>"),
          (_0x441fec["disabled"] = !0x1));
      }, 0x7d0),
      null
    );
  (Array["isArray"](_0x41090b) || (_0x41090b = [_0x41090b]),
    (_0x41090b = _0x41090b["filter"](function (_0x23b254) {
      return _0x23b254["trim"]()["length"] > 0x0;
    })["map"](function (_0x2d1fc8) {
      return _0x2d1fc8["trim"]();
    })));
  var _0x5caa06 = "";
  for (var _0x106500 = 0x0; _0x106500 < _0x41090b["length"]; _0x106500++)
    (_0x278d39 = _0x41090b[_0x106500])["length"] > _0x5caa06["length"] &&
      _0x278d39["length"] <= 0x50 &&
      (_0x5caa06 = _0x278d39);
  0x0 == _0x5caa06["length"] && (_0x5caa06 = _0x41090b[0x0]);
  for (_0x106500 = 0x0; _0x106500 < _0x41090b["length"]; _0x106500++) {
    ((_0x278d39 = _0x41090b[_0x106500]),
      console["log"]("title:\x20", _0x278d39));
    if (!(_0x278d39["length"] > 0x5a)) {
      _0xe22f66(
        _0x278d39,
        _0x5caa06 == _0x278d39 ? "Perfect\x20Title" : "Great\x20Title",
      );
      var _0x5dc5de = document["getElementById"]("listing-data-table"),
        _0x56859b =
          _0x5dc5de["rows"][_0x5dc5de["rows"]["length"] - 0x1]["querySelector"](
            ".title-cell",
          );
      (flyInText(_0x278d39, _0x56859b),
        _0x2ea127(),
        await new Promise((_0x49a141) => setTimeout(_0x49a141, 0x12c)),
        _0x13b0f3());
    }
  }
  var _0x47e244 = document["querySelector"]("#the-textarea");
  (_0x47e244 || (_0x47e244 = document["querySelector"]("#listTitle")),
    (_0x47e244["value"] = _0x5caa06));
  try {
    updateTheCharacterCountOnTextArea();
  } catch (_0x1c84cf) {}
  return (
    _0x4c9954(),
    _0x2ea127(),
    await new Promise((_0x2edd99) => setTimeout(_0x2edd99, 0x7d0)),
    _0x13b0f3(),
    (_0x441fec["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x441fec["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x441fec["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x441fec["disabled"] = !0x1));
    }, 0x7d0),
    _0x5caa06
  );
}
async function _0x4832af(_0x1531cd, _0x5662be) {
  var _0x25e045 = document["querySelector"]("#create-title-v4");
  ((_0x25e045["disabled"] = !0x0),
    (_0x25e045["style"]["backgroundColor"] = "grey"),
    (_0x25e045["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    turnOffFavicon(),
    _0x2f5124(),
    console["log"]("create10TitlesV3AndAppendToTable"));
  if (!_0x1531cd)
    try {
      _0x1531cd = getFilteredTitle();
    } catch (_0x3d7e31) {
      if (!product_data["filteredTitle"])
        throw new Error("No\x20title\x20found");
      ((_0x1531cd = product_data["filteredTitle"]),
        (_0x5662be = product_data["descriptionText"]));
    }
  _0x5662be || (_0x5662be = getProductDescriptionAndFeatures());
  var _0xee56af = _0x1531cd + "\x0a\x0a" + _0x5662be,
    _0x30c031 = await _0x23ecd4(_0xee56af);
  if (!_0x30c031 || _0x30c031["includes"]("Error"))
    return (
      _0xe22f66("Error\x20-\x20Try\x20Again", "Custom\x20Title"),
      _0x4c9954(),
      _0x2ea127(),
      await new Promise((_0x4459c3) => setTimeout(_0x4459c3, 0x7d0)),
      _0x13b0f3(),
      (_0x25e045["innerHTML"] = "<b>Sniped\x20Title!</b>"),
      (_0x25e045["style"]["backgroundColor"] = "#3a86ff"),
      setTimeout(function () {
        ((_0x25e045["innerHTML"] = "<b>Snipe\x20Title</b>"),
          (_0x25e045["disabled"] = !0x1));
      }, 0x7d0),
      null
    );
  (Array["isArray"](_0x30c031) || (_0x30c031 = [_0x30c031]),
    (_0x30c031 = _0x30c031["filter"](function (_0x42cb33) {
      return _0x42cb33["trim"]()["length"] > 0x0;
    })["map"](function (_0x36a9a6) {
      return _0x36a9a6["trim"]();
    })));
  var _0x369a60 = "";
  for (var _0x44e0e0 = 0x0; _0x44e0e0 < _0x30c031["length"]; _0x44e0e0++)
    (_0x1531cd = _0x30c031[_0x44e0e0])["length"] > _0x369a60["length"] &&
      _0x1531cd["length"] <= 0x50 &&
      (_0x369a60 = _0x1531cd);
  (0x0 == _0x369a60["length"] && (_0x369a60 = _0x30c031[0x0]),
    _0xe22f66((_0x1531cd = _0x30c031[0x0]), "Custom\x20Title"));
  var _0x1856aa = document["getElementById"]("listing-data-table"),
    _0x25f143 =
      _0x1856aa["rows"][_0x1856aa["rows"]["length"] - 0x1]["querySelector"](
        ".title-cell",
      );
  (flyInText(_0x1531cd, _0x25f143),
    _0x2ea127(),
    await new Promise((_0xca8a23) => setTimeout(_0xca8a23, 0x12c)),
    _0x13b0f3());
  var _0x7baee = document["querySelector"]("#the-textarea");
  (_0x7baee || (_0x7baee = document["querySelector"]("#listTitle")),
    (_0x7baee["value"] = _0x1531cd));
  try {
    updateTheCharacterCountOnTextArea();
  } catch (_0x4fcb37) {}
  return (
    _0x4c9954(),
    _0x2ea127(),
    await new Promise((_0x120ced) => setTimeout(_0x120ced, 0x7d0)),
    _0x13b0f3(),
    (_0x25e045["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x25e045["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x25e045["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x25e045["disabled"] = !0x1));
    }, 0x7d0),
    _0x369a60
  );
}
async function _0x23ecd4(_0x44b697, _0x5f5876 = null) {
  if (!_0x5f5876) {
    var { custom_title_prompt: _0x35ee70 } = await chrome["storage"]["local"][
      "get"
    ]("custom_title_prompt");
    !(_0x5f5876 = _0x35ee70) &&
      ((_0x5f5876 = "Make\x20a\x20optimized,\x20clear\x20eBay\x20title."),
      await chrome["storage"]["local"]["set"]({
        custom_title_prompt: _0x5f5876,
      }));
  }
  var { email: _0x517771 } = await chrome["storage"]["local"]["get"](["email"]);
  const _0x340d21 = {
    system_message: _0x5f5876,
    openai_model: "gpt-4.1-nano",
    model_definition: { title: "str" },
    email: _0x517771,
    user_message: _0x44b697,
  };
  console["log"]("payload:\x20", _0x340d21);
  try {
    var _0x2b9533 = await postToServer(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/structured_output",
      _0x340d21,
    );
    return (
      console["log"]("Response\x20from\x20server:", _0x2b9533),
      _0x2b9533["success"]
        ? _0x2b9533["result"]["title"]
        : "Error\x20-\x20" + _0x2b9533["errorMessage"]
    );
  } catch (_0x52af04) {
    return "Error\x20-\x20" + _0x52af04["message"];
  }
}
function _0xfc3a7f(_0x45f3a7) {
  var _0x22a182 = _0x45f3a7["choices"][0x0]["text"];
  ((_0x22a182 = (_0x22a182 = _0x22a182["trim"]())["replace"](/\n/g, "\x20")),
    console["log"]("titleFromAi:\x20", _0x22a182));
  var _0x4f5865 = document["getElementById"]("listing-data-table"),
    _0x29a5ca = createRow(_0x4f5865);
  (createCell(_0x4f5865, {
    rowNumber: _0x29a5ca,
    cellValue: _0x29a5ca,
    headerName: "Rank",
  }),
    createCell(_0x4f5865, {
      rowNumber: _0x29a5ca,
      cellValue: _0x22a182,
      headerName: "Title",
    }),
    createCell(_0x4f5865, {
      rowNumber: _0x29a5ca,
      cellValue: "myAi-v3",
      headerName: "Type",
    }),
    createCell(_0x4f5865, {
      rowNumber: _0x29a5ca,
      cellValue: _0x22a182["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x297d06 = createButtonToUpdateTextArea({
    buttonInnerText: "Change",
    textAreaSelector: "#the-textarea",
    valueToSet: _0x22a182,
    callback: updateTheCharacterCountOnTextArea,
  });
  createCellWithButton(_0x4f5865, {
    button: _0x297d06,
    rowNumber: _0x29a5ca,
    headerName: "Action",
  });
}
async function _0xe22f66(_0x5de611, _0x42d5eb) {
  var _0x39a93f = document["getElementById"]("listing-data-table"),
    _0x412dde = createRow(_0x39a93f);
  (createCell(_0x39a93f, {
    rowNumber: _0x412dde,
    cellValue: _0x412dde,
    headerName: "Rank",
  }),
    createCell(_0x39a93f, {
      rowNumber: _0x412dde,
      cellValue: _0x5de611,
      headerName: "Title",
    }),
    createCell(_0x39a93f, {
      rowNumber: _0x412dde,
      cellValue: _0x42d5eb,
      headerName: "Type",
    }),
    createCell(_0x39a93f, {
      rowNumber: _0x412dde,
      cellValue: _0x5de611["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x336c68 = createButtonToUpdateTextArea({
    buttonInnerText: "Change",
    textAreaSelector: "#the-textarea",
    valueToSet: _0x5de611,
    callback: updateTheCharacterCountOnTextArea,
  });
  createCellWithButton(_0x39a93f, {
    button: _0x336c68,
    rowNumber: _0x412dde,
    headerName: "Action",
  });
}
async function _0x4c7335(_0x41496e) {
  return new Promise((_0x2df476, _0x3d8ca6) => {
    chrome["runtime"]["sendMessage"](
      { type: "getAiGeneratedTitle", data: _0x41496e },
      function (_0x149e02) {
        (console["log"]("response:\x20", _0x149e02), _0x2df476(_0x149e02));
      },
    );
  });
}
async function _0x5e875d(_0x489eaa) {
  var _0x150984 = document["createElement"]("button");
  ((_0x150984["innerHTML"] = "List\x20it\x20now\x20on\x20" + _0x489eaa),
    (_0x150984["id"] = "list" + _0x489eaa),
    _0x150984["classList"]["add"]("list-button"),
    _0x577afb(),
    document["body"]["prepend"](_0x150984),
    _0x150984["addEventListener"]("click", function () {
      (console["log"]("listing\x20to\x20ebay"),
        _0x1132a1(product_data["sku"]),
        (product_data["custom_title"] =
          document["getElementById"]("the-textarea")["value"]),
        console["log"]("Listed\x20Data", product_data),
        (product_data["selected_image"] = selectedImage),
        (product_data["custom_price"] =
          document["getElementById"]("sell-price")["value"]),
        (product_data["promoted_listing_ad_rate"] =
          document["getElementById"]("promoted-listing")["value"]));
      var _0x3298d3 = chrome["runtime"]["getURL"](
        "Favicons/Completed/right_arrow.png",
      );
      (chrome["runtime"]["sendMessage"](
        { type: "list_to_" + _0x489eaa, product_data: product_data },
        function (_0x585cbe) {
          console["log"](_0x585cbe["farewell"]);
        },
      ),
        changeFaviconOfPage(_0x3298d3));
    }));
}
async function _0x5e6f1c() {
  (await _0x1cebf3(),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x32c3a8) {
        console["log"]("response:\x20", _0x32c3a8);
        if (_0x32c3a8["creditsAvailable"])
          (chrome["runtime"]["sendMessage"]({
            type: "deductCredits",
            amount: 0,
          }),
            (product_data["listingType"] = "free"),
            chrome["runtime"]["sendMessage"](
              { type: "list_to_ebay", product_data: product_data },
              function (_0xe18c12) {
                console["log"](_0xe18c12["farewell"]);
              },
            ));
        else
          alert(
            "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20a\x20membership\x20to\x20continue\x20listing.",
          );
      },
    ));
}
async function _0x355840() {
  (await _0x1cebf3(),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x3b1e0d) {
        console["log"]("response:\x20", _0x3b1e0d);
        if (_0x3b1e0d["creditsAvailable"])
          (chrome["runtime"]["sendMessage"]({
            type: "deductCredits",
            amount: 0,
          }),
            (product_data["listingType"] = "chatGpt"),
            chrome["runtime"]["sendMessage"](
              { type: "list_to_ebay", product_data: product_data },
              function (_0xb958ad) {
                console["log"](_0xb958ad["farewell"]);
              },
            ));
        else
          alert(
            "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20a\x20membership\x20to\x20continue\x20listing.",
          );
      },
    ));
}
async function _0x49665c() {
  (await _0x1cebf3(),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x5b3059) {
        console["log"]("response:\x20", _0x5b3059);
        if (_0x5b3059["creditsAvailable"])
          (chrome["runtime"]["sendMessage"]({
            type: "deductCredits",
            amount: 0,
          }),
            (product_data["listingType"] = "paid"),
            chrome["runtime"]["sendMessage"](
              { type: "list_to_ebay", product_data: product_data },
              function (_0x31fff9) {
                console["log"](_0x31fff9["farewell"]);
              },
            ),
            _0x1132a1(product_data["sku"]));
        else
          alert(
            "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits\x20to\x20continue\x20listing.",
          );
      },
    ));
}
async function _0x1cebf3() {
  (_0x1132a1(product_data["sku"]),
    (product_data["custom_title"] =
      document["getElementById"]("the-textarea")["value"]),
    console["log"]("Listed\x20Data", product_data));
  for (; !selectedImage; )
    await new Promise((_0x1aabdc) => setTimeout(_0x1aabdc, 0x3e8));
  ((product_data["selected_image"] = selectedImage),
    (product_data["custom_price"] =
      document["getElementById"]("sell-price")["value"]),
    (product_data["promoted_listing_ad_rate"] =
      document["getElementById"]("promoted-listing")["value"]));
  var _0x3a4dfd = chrome["runtime"]["getURL"](
    "Favicons/Completed/right_arrow.png",
  );
  changeFaviconOfPage(_0x3a4dfd);
  var { shouldGetGspr: _0x287b51 } =
    await chrome["storage"]["local"]["get"]("shouldGetGspr");
  if (_0x287b51 && !product_data["manufacturerInfo"]) {
    console["log"]("shouldGetGspr:\x20", _0x287b51);
    var {
      manufacturerInfo: _0x5b2513,
      responsiblePersonEU: _0x4510e0,
      manufacturerInfoText: _0x34d834,
      responsiblePersonEUText: _0x5590b9,
    } = await fetchGSPR();
    (console["log"]("manufacturerInfo:\x20", _0x5b2513),
      console["log"]("responsiblePersonEU:\x20", _0x4510e0));
    if ("" == _0x5b2513["country"] || null == _0x5b2513["country"]) {
      document["title"] = "ERROR!\x20Manufacturer\x20country\x20is\x20empty!";
      throw new Error("Manufacturer\x20country\x20is\x20empty!");
    }
    ((product_data["manufacturerInfo"] = _0x5b2513),
      (product_data["responsiblePersonEU"] = _0x4510e0),
      (product_data["manufacturerInfoText"] = _0x34d834),
      (product_data["responsiblePersonEUText"] = _0x5590b9),
      await new Promise((_0x95f617) => setTimeout(_0x95f617, 0x3e8)));
  }
}
function _0x40b08f() {
  var _0x1a5164 = document["createElement"]("button");
  ((_0x1a5164["innerHTML"] = "Basic-List"),
    (_0x1a5164["id"] = "standard-listing-button"),
    _0x1a5164["classList"]["add"]("list-button"),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x136e31) {
        console["log"]("createSnipeTitleButton\x20response:\x20", _0x136e31);
        if (_0x136e31["creditsAvailable"])
          _0x1a5164["addEventListener"]("click", function () {
            _0x5e6f1c();
          });
        else
          ((_0x1a5164["disabled"] = !0x0),
            (_0x1a5164["innerHTML"] =
              "Basic-List\x20(Please\x20Purchase\x20Membership)"),
            (_0x1a5164["style"]["backgroundColor"] = "grey"));
      },
    ));
  var _0x1bcf1e = createContextMenu("my-custom-context-menu");
  return (
    _0x1bcf1e["addMenuItem"]("List\x20To\x20Poshmark", function () {
      _0x4e26ea("standard");
    }),
    _0x1a5164["addEventListener"]("contextmenu", function (_0x94272f) {
      (_0x94272f["preventDefault"](), _0x1bcf1e["showMenu"](_0x94272f));
    }),
    _0x1a5164
  );
}
function _0x146dc6() {
  var _0x25e3d7 = document["createElement"]("button");
  return (
    (_0x25e3d7["innerHTML"] = "Import"),
    (_0x25e3d7["id"] = "import-button"),
    _0x25e3d7["classList"]["add"]("list-button"),
    _0x25e3d7["addEventListener"]("click", async function () {
      var clipboardData = navigator["clipboard"]["readText"]();
      ((clipboardData = await navigator["clipboard"]["readText"]()),
        console["log"]("clipboardData:\x20", clipboardData));
      var _0x16f0f3 = JSON["parse"](clipboardData);
      console["log"]("data:\x20", _0x16f0f3);
      var _0x3a3f32 = _0x16f0f3["price"];
      try {
        _0x3a3f32 = _0x3a3f32["replace"](/[^0-9.]/g, "");
      } catch (_0x5d4dc3) {
        console["log"]("error:\x20", _0x5d4dc3);
      }
      var { sniper_price_markdown: _0x4496c8 } = await chrome["storage"][
        "local"
      ]["get"](["sniper_price_markdown"]);
      ((_0x3a3f32 = (_0x3a3f32 -= _0x4496c8)["toFixed"](0x2)),
        (document["getElementById"]("sell-price")["value"] = _0x3a3f32),
        _0xe22f66(_0x16f0f3["title"], "Sniped"),
        (document["getElementById"]("similar-item-number")["value"] =
          _0x16f0f3["itemNumber"]));
      var _0x3bac43 = document["getElementById"]("listing-data-table"),
        _0x381873 =
          _0x3bac43["rows"][_0x3bac43["rows"]["length"] - 0x1]["querySelector"](
            ".title-cell",
          );
      (flyInText(_0x16f0f3["title"], _0x381873),
        _0x2ea127(),
        await new Promise((_0x25f069) => setTimeout(_0x25f069, 0x12c)),
        _0x13b0f3(),
        (document["querySelector"]("#the-textarea")["value"] =
          _0x16f0f3["title"]));
      var _0x1f8238 = await checkMembership();
      (console["log"]("membership:\x20", _0x1f8238),
        "ultimate" == _0x1f8238 &&
          ((document["getElementById"]("snipe-listing-button")["disabled"] =
            !0x1),
          (document["getElementById"]("clean-title-button")["disabled"] = !0x1),
          (document["getElementById"]("paid-listing-button")["disabled"] =
            !0x0)));
    }),
    _0x25e3d7
  );
}
function _0x3edee7() {
  var _0x376910 = document["createElement"]("button");
  ((_0x376910["id"] = "chat-listing-button"),
    _0x376910["classList"]["add"]("list-button"));
  var _0x19a9c3 = chrome["runtime"]["getURL"]("Favicons/OpenAi/icon.png"),
    _0x272945 = document["createElement"]("img");
  return (
    (_0x272945["src"] = _0x19a9c3),
    (_0x272945["style"]["width"] = "25px"),
    (_0x272945["style"]["height"] = "25px"),
    (_0x272945["style"]["marginRight"] = "5px"),
    _0x376910["appendChild"](_0x272945),
    (_0x376910["innerHTML"] += "Chat-List"),
    chrome["runtime"]["sendMessage"](
      { type: "checkFreeCredits" },
      function (_0x4c221a) {
        console["log"]("createSnipeTitleButton\x20response:\x20", _0x4c221a);
        if (_0x4c221a["creditsAvailable"])
          _0x376910["addEventListener"]("click", function () {
            _0x355840();
          });
        else
          ((_0x376910["disabled"] = !0x0),
            (_0x376910["innerHTML"] =
              "Chat-List\x20(Please\x20Purchase\x20Membership)"),
            (_0x376910["style"]["backgroundColor"] = "grey"));
      },
    ),
    _0x376910
  );
}
function _0x11e2c5() {
  var _0x1cebba = document["createElement"]("button");
  return (
    (_0x1cebba["innerHTML"] = "Snipe-List"),
    (_0x1cebba["id"] = "snipe-listing-button"),
    _0x1cebba["classList"]["add"]("list-button"),
    (_0x1cebba["disabled"] = !0x0),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0xdaf4de) {
        console["log"]("createSnipeTitleButton\x20response:\x20", _0xdaf4de);
        if (_0xdaf4de["creditsAvailable"])
          _0x1cebba["addEventListener"]("click", async function () {
            (await _0x1cebf3(), (product_data["listingType"] = "paid"));
            var _0x4161c8 = document["getElementById"]("similar-item-number")[
              "value"
            ];
            (chrome["runtime"]["sendMessage"]({
              type: "deductCredits",
              amount: 0,
            }),
              chrome["runtime"]["sendMessage"](
                {
                  type: "list_similar_item",
                  productData: product_data,
                  similarItemNumber: _0x4161c8,
                },
                function (_0x49e84f) {
                  console["log"](_0x49e84f["farewell"]);
                },
              ));
          });
        else
          ((_0x1cebba["disabled"] = !0x0),
            (_0x1cebba["innerHTML"] =
              "Snipe-List\x20(Please\x20Purchase\x20Membership)"),
            (_0x1cebba["style"]["backgroundColor"] = "grey"));
      },
    ),
    _0x1cebba
  );
}
async function _0x400837() {
  var _0x13097a = document["createElement"]("button");
  ((_0x13097a["innerHTML"] = "<b>Opti-List</b>"),
    (_0x13097a["id"] = "paid-listing-button"),
    _0x13097a["classList"]["add"]("list-button"));
  if ("ultimate" != (await checkMembership()))
    return (
      (_0x13097a["disabled"] = !0x0),
      (_0x13097a["innerHTML"] =
        "<b>Opti-List</b>\x20(Please\x20Purchase\x20Membership)"),
      (_0x13097a["style"]["backgroundColor"] = "grey"),
      _0x13097a
    );
  chrome["runtime"]["sendMessage"](
    { type: "checkCredits" },
    function (_0x2c801f) {
      console["log"]("createSnipeTitleButton\x20response:\x20", _0x2c801f);
      if (_0x2c801f["creditsAvailable"])
        _0x13097a["addEventListener"]("click", function () {
          _0x49665c();
        });
      else
        ((_0x13097a["disabled"] = !0x0),
          (_0x13097a["innerHTML"] = "<b>Opti-List</b>\x20(No\x20Credits)"),
          (_0x13097a["style"]["backgroundColor"] = "grey"));
    },
  );
  var _0x264dd1 = createContextMenu("my-custom-context-menu-opti");
  return (
    _0x264dd1["addMenuItem"](
      "List\x20To\x20Poshmark\x20with\x20AI",
      function () {
        _0x4e26ea("opti");
      },
    ),
    _0x13097a["addEventListener"]("contextmenu", function (_0x44c1a2) {
      (_0x44c1a2["preventDefault"](), _0x264dd1["showMenu"](_0x44c1a2));
    }),
    _0x13097a
  );
}
async function _0xfdc213() {
  (await chrome["storage"]["local"]["remove"]("shopify_store_url"),
    await chrome["storage"]["local"]["remove"]("shopify_admin_access_token"),
    alert("Shopify\x20credentials\x20removed\x20successfully!"));
}
async function _0x13ca84() {
  (console["log"]("listItemToShopify"), await _0x1cebf3());
  if ("ultimate" == (await checkMembership())) {
    if (await checkIfCreditsAreAvailable()) {
      var { shopify_store_url: _0x41c355 } =
          await chrome["storage"]["local"]["get"]("shopify_store_url"),
        { shopify_admin_access_token: _0x74ca26 } = await chrome["storage"][
          "local"
        ]["get"]("shopify_admin_access_token");
      (!_0x41c355 || !_0x74ca26) &&
        (alert(
          "Please\x20set\x20your\x20Shopify\x20store\x20URL\x20and\x20admin\x20access\x20token\x20in\x20the\x20extension\x20settings.",
        ),
        await _0x3c2e1c());
      chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 });
      var { response: _0x10866c } = await new Promise(
        (_0x10eec9, _0x55d256) => {
          chrome["runtime"]["sendMessage"](
            { type: "list_to_shopify", product_data: product_data },
            function (_0x20771a) {
              _0x10eec9(_0x20771a);
            },
          );
        },
      );
      (console["log"]("response:\x20", _0x10866c), alert(_0x10866c["message"]));
    } else
      alert("Please\x20purchase\x20credits\x20to\x20list\x20to\x20Poshmark");
  } else
    alert(
      "Please\x20upgrade\x20to\x20Ultimate\x20membership\x20to\x20list\x20to\x20Poshmark",
    );
}
async function _0x3c2e1c() {
  return new Promise((_0x5e95ad) => {
    const _0x3c47cc = document["createElement"]("div");
    ((_0x3c47cc["style"]["position"] = "fixed"),
      (_0x3c47cc["style"]["top"] = "50%"),
      (_0x3c47cc["style"]["left"] = "50%"),
      (_0x3c47cc["style"]["transform"] = "translate(-50%,\x20-50%)"),
      (_0x3c47cc["style"]["padding"] = "20px"),
      (_0x3c47cc["style"]["backgroundColor"] = "white"),
      (_0x3c47cc["style"]["border"] = "1px\x20solid\x20black"),
      (_0x3c47cc["style"]["zIndex"] = "10000"));
    const _0x2a59cb = document["createElement"]("label");
    _0x2a59cb["textContent"] = "Shopify\x20Store\x20URL:";
    const _0x1a2ec3 = document["createElement"]("input");
    ((_0x1a2ec3["type"] = "text"),
      (_0x1a2ec3["placeholder"] = "your-store.myshopify.com"),
      (_0x1a2ec3["style"]["width"] = "100%"),
      (_0x1a2ec3["style"]["marginBottom"] = "10px"));
    const _0x70560f = document["createElement"]("label");
    _0x70560f["textContent"] = "Admin\x20Access\x20Token:";
    const _0x499816 = document["createElement"]("input");
    ((_0x499816["type"] = "password"),
      (_0x499816["placeholder"] = "Your\x20admin\x20access\x20token"),
      (_0x499816["style"]["width"] = "100%"),
      (_0x499816["style"]["marginBottom"] = "10px"));
    const _0x43bf23 = document["createElement"]("button");
    ((_0x43bf23["textContent"] = "Save"),
      (_0x43bf23["style"]["display"] = "block"),
      (_0x43bf23["style"]["marginTop"] = "10px"),
      _0x43bf23["addEventListener"]("click", async () => {
        const _0x29dacf = _0x1a2ec3["value"]["trim"](),
          _0x4afff2 = _0x499816["value"]["trim"]();
        if (_0x29dacf && _0x4afff2)
          (await chrome["storage"]["local"]["set"]({
            shopify_store_url: _0x29dacf,
            shopify_admin_access_token: _0x4afff2,
          }),
            alert("Shopify\x20credentials\x20saved\x20successfully!"),
            document["body"]["removeChild"](_0x3c47cc),
            _0x5e95ad());
        else alert("Both\x20fields\x20are\x20required.");
      }),
      _0x3c47cc["appendChild"](_0x2a59cb),
      _0x3c47cc["appendChild"](_0x1a2ec3),
      _0x3c47cc["appendChild"](_0x70560f),
      _0x3c47cc["appendChild"](_0x499816),
      _0x3c47cc["appendChild"](_0x43bf23),
      document["body"]["appendChild"](_0x3c47cc));
  });
}
async function _0x4e26ea(_0x11499e = "standard") {
  await _0x1cebf3();
  if ("ultimate" == (await checkMembership())) {
    if (await checkIfCreditsAreAvailable())
      ((product_data["listingType"] = _0x11499e),
        chrome["runtime"]["sendMessage"]({
          type: "list_to_poshmark",
          product_data: product_data,
        }));
    else alert("Please\x20purchase\x20credits\x20to\x20list\x20to\x20Poshmark");
  } else
    alert(
      "Please\x20upgrade\x20to\x20Ultimate\x20membership\x20to\x20list\x20to\x20Poshmark",
    );
}
console["log"]("amazon_search_page_functions.js\x20loaded");
function _0x280490(_0xc4d1aa, _0x112034 = 0x12c) {
  let _0xec703a;
  return (..._0x1705f7) => {
    (clearTimeout(_0xec703a),
      (_0xec703a = setTimeout(
        () => _0xc4d1aa["apply"](null, _0x1705f7),
        _0x112034,
      )));
  };
}
function _0x5bc107(_0x41d2b7, _0x3d0feb) {
  var _0x12d599 = _0x41d2b7["toLowerCase"]()["split"]("\x20"),
    _0x243c16 = [];
  for (var _0x5a50cb = 0x0; _0x5a50cb < _0x3d0feb["length"]; _0x5a50cb++) {
    var _0x5cfb6d = _0x3d0feb[_0x5a50cb];
    if (_0x5cfb6d["includes"]("\x20"))
      _0x41d2b7["toLowerCase"]()["includes"](_0x5cfb6d["toLowerCase"]()) &&
        (_0x243c16["push"](_0x5cfb6d),
        console["log"](
          "Removed\x20phrase:\x20" +
            _0x5cfb6d +
            "\x20-\x20Found\x20in\x20title:\x20" +
            _0x41d2b7,
        ));
    else
      for (var _0x291eb2 = 0x0; _0x291eb2 < _0x12d599["length"]; _0x291eb2++) {
        var _0x19954a = _0x12d599[_0x291eb2];
        if (_0x19954a === _0x5cfb6d["toLowerCase"]()) {
          (_0x243c16["push"](_0x5cfb6d),
            console["log"](
              "Removed\x20word:\x20" +
                _0x5cfb6d +
                "\x20-\x20Found\x20in\x20title\x20word:\x20" +
                _0x19954a,
            ));
          break;
        }
      }
  }
  return _0x243c16["length"] > 0x0;
}
function _0x43f02e(_0x3b3e8d, _0x1095cf, _0x14d98a = "any") {
  var _0x9fab07 = _0x3b3e8d["toLowerCase"]()["split"]("\x20"),
    _0x14e8b5 = [];
  for (var _0x508a79 = 0x0; _0x508a79 < _0x1095cf["length"]; _0x508a79++) {
    var _0x3a31f4 = _0x1095cf[_0x508a79];
    if (_0x3a31f4["includes"]("\x20"))
      _0x3b3e8d["toLowerCase"]()["includes"](_0x3a31f4["toLowerCase"]()) &&
        (_0x14e8b5["push"](_0x3a31f4),
        console["log"](
          "Found\x20phrase:\x20" +
            _0x3a31f4 +
            "\x20-\x20Found\x20in\x20title:\x20" +
            _0x3b3e8d,
        ));
    else
      for (var _0x3a9eb3 = 0x0; _0x3a9eb3 < _0x9fab07["length"]; _0x3a9eb3++) {
        var _0x3cc9e5 = _0x9fab07[_0x3a9eb3];
        if (_0x3cc9e5 === _0x3a31f4["toLowerCase"]()) {
          (_0x14e8b5["push"](_0x3a31f4),
            console["log"](
              "Found\x20word:\x20" +
                _0x3a31f4 +
                "\x20-\x20Found\x20in\x20title\x20word:\x20" +
                _0x3cc9e5,
            ));
          break;
        }
      }
  }
  return (
    ("all" === _0x14d98a && _0x14e8b5["length"] === _0x1095cf["length"]) ||
    ("any" === _0x14d98a && _0x14e8b5["length"] > 0x0)
  );
}
async function _0x42a3fc() {
  let { maxPrice: _0x11ab87 } =
      await chrome["storage"]["local"]["get"]("maxPrice"),
    { minPrice: _0x4fb709 } =
      await chrome["storage"]["local"]["get"]("minPrice");
  return (
    (_0x11ab87 = parseFloat(_0x11ab87)),
    (_0x4fb709 = parseFloat(_0x4fb709)),
    { minPrice: _0x4fb709, maxPrice: _0x11ab87 }
  );
}
function _0x25f56c(_0x42ad99) {
  var _0x47946e = _0x42ad99["querySelector"](".a-price-whole");
  if (null == _0x47946e) return null;
  var _0x44efcb = _0x47946e["innerText"]["replace"](/,/g, "");
  _0x44efcb = (_0x44efcb = (_0x44efcb = _0x44efcb["replace"](/\./g, ""))[
    "replace"
  ](/\$/g, ""))["replace"](/\n/g, "");
  var _0x3408b4 = _0x42ad99["querySelector"](".a-price-fraction");
  return (
    null != _0x3408b4 && (_0x44efcb = _0x44efcb + "." + _0x3408b4["innerText"]),
    (_0x44efcb = _0x44efcb["replace"](/,/g, "")),
    parseFloat(_0x44efcb)
  );
}
function filterCardsBasedOnPrice(_0x120109, _0x5c0cf7, _0x1d2a73) {
  return _0x120109["filter"]((_0x2305b1) => {
    const _0x4c36a3 = _0x25f56c(_0x2305b1);
    return null != _0x4c36a3 && _0x4c36a3 > _0x5c0cf7 && _0x4c36a3 < _0x1d2a73;
  });
}
function _0x39be91(_0x43a9ae) {
  var _0x33e251 = "";
  try {
    var _0x478ec8 = _0x43a9ae["querySelector"]("img.s-image");
    null != _0x478ec8 && (_0x33e251 = _0x478ec8["src"]);
  } catch (_0x56b63f) {}
  return _0x33e251;
}
function _0x52123f(_0x12e4f4) {
  return _0x12e4f4["getAttribute"]("data-asin");
}
function filterCardsWithAsins(_0x49526c) {
  return _0x49526c["filter"]((_0x4a3bb1) => {
    const _0x36a719 = _0x52123f(_0x4a3bb1);
    return null != _0x36a719 && "" !== _0x36a719;
  });
}
function _0x126f5f(_0x2c0029) {
  return _0x2c0029["map"]((_0x10813b) => _0x52123f(_0x10813b));
}
function filterBestSellerCards(_0x2f6516) {
  return _0x2f6516["filter"]((_0x676a8e) =>
    _0x676a8e["querySelector"]("[id*=\x22-best-seller\x22]"),
  );
}
function filterAmazonChoiceCards(_0x57cdbd) {
  return _0x57cdbd["filter"]((_0x338522) =>
    _0x338522["querySelector"]("[id*=\x22-amazons-choice-label\x22]"),
  );
}
function filterBooksFromCards(_0x3defa9) {
  const _0x3b16db = [
    "Hardcover",
    "Paperback",
    "Audiobook",
    "Audible",
    "Kindle\x20Edition",
    "Audio\x20CD",
    "Blu-ray",
    "DVD",
    "Prime\x20Video",
  ];
  return _0x3defa9["filter"]((_0xd670e0) => {
    const _0x47d714 = _0x52123f(_0xd670e0);
    if (null == _0x47d714 || !_0x47d714["startsWith"]("B0")) return !0x1;
    const _0x4e2431 = _0xd670e0["innerText"] || _0xd670e0["innerHTML"];
    return !_0x3b16db["some"]((_0x343e74) => _0x4e2431["includes"](_0x343e74));
  });
}
function _0x4014cd(_0x2105ce) {
  let _0x474fea = 0x0;
  try {
    var _0x318a8a = _0x2105ce["querySelector"](
      "span.a-size-base.s-underline-text",
    );
    (_0x318a8a ||
      (_0x318a8a = _0x2105ce["querySelector"](
        "[data-cy=\x22reviews-block\x22]\x20a[aria-label$=\x22ratings\x22]",
      )),
      _0x318a8a ||
        (_0x318a8a = _0x2105ce["querySelector"](
          "[data-cy=\x22reviews-block\x22]\x20div[data-csa-c-content-id*=\x22ratings\x22]",
        )));
    if (_0x318a8a && "" !== _0x318a8a["textContent"]["trim"]()) {
      var _0xb95408 = _0x318a8a["textContent"]["trim"]();
      _0xb95408 = _0xb95408["replace"](/\s+|\(|\)/g, "");
      let _0x2dcb69 = 0x1;
      (/[Kk]$/["test"](_0xb95408) &&
        ((_0x2dcb69 = 0x3e8), (_0xb95408 = _0xb95408["slice"](0x0, -0x1))),
        (_0x474fea = _0x427360(_0xb95408) * _0x2dcb69),
        (_0x474fea = isNaN(_0x474fea) ? 0x0 : Math["round"](_0x474fea)));
    }
  } catch (_0x4c2a4f) {
    console["error"](
      "Error\x20extracting\x20reviews\x20from\x20card:",
      _0x4c2a4f,
    );
  }
  return _0x474fea;
}
function _0x427360(_0x286e2a) {
  let _0x513973 = !0x1;
  (_0x286e2a = _0x286e2a["replace"](/[^\d.,-]/g, ""))["startsWith"]("-") &&
    ((_0x513973 = !0x0), (_0x286e2a = _0x286e2a["substring"](0x1)));
  let _0x3204c3 = ".",
    _0x2c7f2b = ",";
  if (_0x286e2a["includes"](".") && _0x286e2a["includes"](","))
    _0x286e2a["indexOf"](",") < _0x286e2a["indexOf"](".")
      ? ((_0x3204c3 = "."), (_0x2c7f2b = ","))
      : ((_0x3204c3 = ","), (_0x2c7f2b = "."));
  else {
    if (_0x286e2a["includes"](".")) {
      const _0x447248 = _0x286e2a["split"](".");
      0x3 === _0x447248[_0x447248["length"] - 0x1]["length"]
        ? ((_0x3204c3 = ""), (_0x2c7f2b = "."))
        : ((_0x3204c3 = "."), (_0x2c7f2b = ""));
    } else {
      if (_0x286e2a["includes"](",")) {
        const _0x38d04e = _0x286e2a["split"](",");
        0x3 === _0x38d04e[_0x38d04e["length"] - 0x1]["length"]
          ? ((_0x3204c3 = ""), (_0x2c7f2b = ","))
          : ((_0x3204c3 = ","), (_0x2c7f2b = ""));
      } else ((_0x3204c3 = ""), (_0x2c7f2b = ""));
    }
  }
  if (_0x2c7f2b) {
    const _0x34241d = new RegExp("\x5c" + _0x2c7f2b, "g");
    _0x286e2a = _0x286e2a["replace"](_0x34241d, "");
  }
  if (_0x3204c3 && "." !== _0x3204c3) {
    const _0x473cf9 = new RegExp("\x5c" + _0x3204c3, "g");
    _0x286e2a = _0x286e2a["replace"](_0x473cf9, ".");
  }
  let _0x3e43bd = parseFloat(_0x286e2a);
  return (_0x513973 && (_0x3e43bd = -_0x3e43bd), _0x3e43bd);
}
function _0x4372ce(_0x2cd0bf) {
  var _0x400ee4 = "";
  try {
    var _0x5976de = _0x2cd0bf["querySelector"](".s-title-instructions-style");
    null != _0x5976de &&
      (_0x400ee4 = (_0x400ee4 = (_0x400ee4 = _0x5976de["innerText"])["replace"](
        /\n/g,
        "\x20",
      ))["trim"]());
  } catch (_0x32e23a) {}
  return _0x400ee4;
}
function _0x2398c6(_0x5d47bc) {
  var _0x34b496 = "";
  console["log"]("extractTitleFromCarouselCard", _0x5d47bc);
  try {
    var _0x4d8df3 = _0x5d47bc["querySelector"](
      ".p13n-sc-truncate-desktop-type2",
    );
    (console["log"]("titleElement", _0x4d8df3),
      null != _0x4d8df3 &&
        (_0x34b496 = (_0x34b496 = (_0x34b496 = _0x4d8df3["textContent"])[
          "replace"
        ](/\n/g, "\x20"))["trim"]()));
  } catch (_0x285707) {}
  return _0x34b496;
}
function _0x17aca3(_0x592ad8) {
  return _0x592ad8["sort"]((_0xf46dbe, _0x37031c) => {
    const _0x126840 = _0x4014cd(_0xf46dbe);
    return _0x4014cd(_0x37031c) - _0x126840;
  });
}
async function _0x2edfda() {
  var _0x4fc531;
  return (
    (_0x4fc531 = window["location"]["href"]["includes"]("marketplaceID")
      ? ".s-main-slot\x20.s-result-item"
      : ".s-result-item"),
    Array["from"](document["querySelectorAll"](_0x4fc531))
  );
}
async function _0x7672ce(_0x499b09 = {}, _0xb7b43e = null) {
  console["log"]("retrieveFilteredCards\x20params", _0x499b09);
  async function _0x354b21(_0x131d50) {
    return null != _0x499b09[_0x131d50]
      ? _0x499b09[_0x131d50]
      : (await chrome["storage"]["local"]["get"](_0x131d50))[_0x131d50];
  }
  var _0x23d270 = parseInt(await _0x354b21("totalAsinsToFetchFromSearch")),
    _0x1f72e1 = await _0x2edfda();
  ((_0x1f72e1 = filterSponsoredCards(_0x1f72e1)),
    console["log"]("cards\x20cards", _0x1f72e1));
  var _0x13deb7 = await _0x354b21("minPrice");
  (_0xb7b43e || (_0xb7b43e = await _0x354b21("maxPrice")),
    (_0x13deb7 = Number(_0x13deb7)["toFixed"](0x2)),
    (_0xb7b43e = Number(_0xb7b43e)["toFixed"](0x2)),
    console["log"]("minPrice", _0x13deb7),
    console["log"]("maxPrice", _0xb7b43e));
  var filteredCards = filterCardsBasedOnPrice(_0x1f72e1, _0x13deb7, _0xb7b43e);
  ((filteredCards = filterCardsWithAsins(filteredCards)),
    console["log"]("filteredCards", filteredCards));
  var _0x2b6622 = await _0x354b21("max_similiar_niche_items"),
    _0x140b3a = await _0x4844e4(),
    _0x2bf229 = _0x126f5f(filteredCards),
    _0x5401a4 = _0x140b3a["filter"]((_0x4f4229) =>
      _0x2bf229["includes"](_0x4f4229),
    );
  (console["log"]("alreadyListedAsinsInPage", _0x5401a4),
    console["log"]("alreadyListedAsinsInPage\x20length", _0x5401a4["length"]),
    console["log"]("max_similiar_niche_items", _0x2b6622));
  if (_0x5401a4["length"] >= _0x2b6622)
    return (console["log"]("Max\x20similar\x20niche\x20items\x20reached"), []);
  console["log"]("Max\x20similar\x20niche\x20items\x20not\x20reached");
  var _0xaeeec6 = await _0x354b21("productList");
  _0xaeeec6 || (_0xaeeec6 = []);
  var _0x471643 = _0xaeeec6["map"]((_0x41867d) => _0x41867d["asin"]);
  ((filteredCards = filteredCards["filter"](
    (_0x326e89) => !_0x471643["includes"](_0x52123f(_0x326e89)),
  )),
    console["log"](
      "filtered\x20cards\x20after\x20removing\x20already\x20scraped\x20asins",
      filteredCards,
    ));
  (await _0x354b21("remove_books")) &&
    ((filteredCards = filterBooksFromCards(filteredCards)),
    console["log"]("remove_books\x20filtered\x20cards", filteredCards));
  var _0x2808a9 = await _0x354b21("restricted_words");
  _0x2808a9 &&
    _0x2808a9["length"] > 0x0 &&
    ((filteredCards = filteredCards["filter"](
      (_0x69e92b) => !_0x5bc107(_0x4372ce(_0x69e92b), _0x2808a9),
    )),
    console["log"]("restricted\x20words\x20filtered\x20cards", filteredCards));
  if (await _0x354b21("useRequiredKeywords")) {
    var _0xdf54f3 = await _0x354b21("keywords"),
      _0x3f3220 = await _0x354b21("requirementType");
    _0xdf54f3 &&
      _0xdf54f3["length"] > 0x0 &&
      ((filteredCards = filteredCards["filter"]((_0x21a482) =>
        _0x43f02e(_0x4372ce(_0x21a482), _0xdf54f3, _0x3f3220),
      )),
      console["log"](
        "required\x20keywords\x20filtered\x20cards",
        filteredCards,
      ));
  }
  if (await _0x354b21("veroProtectionEnabled")) {
    var _0x521b8b = await _0x354b21("veroBrands");
    (!_0x521b8b &&
      ((_0x521b8b = await fetch(chrome["runtime"]["getURL"]("/VeroList.txt"))),
      (_0x521b8b = (_0x521b8b = await _0x521b8b["text"]())["split"]("\x0a"))),
      (_0x521b8b = _0x521b8b["filter"](
        (_0x24f184) => _0x24f184["length"] > 0x0,
      )["map"]((_0x5228db) => _0x5228db["toLowerCase"]()["trim"]()))["length"] >
        0x0 &&
        ((filteredCards = filteredCards["filter"](
          (_0x5e6d15) => !_0x5bc107(_0x4372ce(_0x5e6d15), _0x521b8b),
        )),
        console["log"]("vero\x20filtered\x20cards", filteredCards)));
  }
  var _0x47e330 = await _0x354b21("min_reviews");
  console["log"]("min_reviews", _0x47e330);
  _0x47e330 > 0x0 &&
    ((filteredCards = filteredCards["filter"]((_0x38d265) => {
      var _0x4749d1 = _0x4014cd(_0x38d265);
      return (
        console["log"]("card", _0x38d265),
        console["log"]("reviews\x20from\x20card", _0x4749d1),
        _0x4749d1 >= _0x47e330
      );
    })),
    console["log"]("min_reviews\x20filtered\x20cards", filteredCards));
  var _0x3315c3 = await _0x354b21("max_reviews");
  console["log"]("max_reviews", _0x3315c3);
  _0x3315c3 > 0x0 &&
    ((filteredCards = filteredCards["filter"](
      (_0x14e082) => _0x4014cd(_0x14e082) <= _0x3315c3,
    )),
    console["log"]("max_reviews\x20filtered\x20cards", filteredCards));
  var _0x12505d = await _0x354b21("sortByReviews");
  console["log"]("sortByReviews", _0x12505d);
  _0x12505d &&
    ((filteredCards = _0x17aca3(filteredCards)),
    console["log"]("sorted\x20cards", filteredCards),
    filteredCards["forEach"]((_0x179110) => {}));
  var _0x15d2d5 = filterBestSellerCards(filteredCards);
  ((_0x15d2d5 = _0x17aca3(_0x15d2d5)),
    console["log"]("best\x20seller\x20cards", _0x15d2d5));
  var _0x498ddb = filterAmazonChoiceCards(filteredCards);
  ((_0x498ddb = _0x17aca3(_0x498ddb)),
    console["log"]("amazon\x20choice\x20cards", _0x498ddb));
  var _0xfc7bd3 = await _0x354b21("prioritizeAmazonChoice"),
    _0x3c8c86 = await _0x354b21("prioritizeBestSellers"),
    _0x3e964b = [];
  ((_0x3e964b = (_0x3e964b =
    _0xfc7bd3 && _0x3c8c86
      ? [..._0x498ddb, ..._0x15d2d5, ...filteredCards]
      : _0xfc7bd3
        ? [..._0x498ddb, ...filteredCards]
        : _0x3c8c86
          ? [..._0x15d2d5, ...filteredCards]
          : [...filteredCards])["filter"](
    (_0x4ebc77, _0x6c5540, self) =>
      _0x6c5540 ===
      self["findIndex"](
        (_0x4a637) => _0x52123f(_0x4a637) === _0x52123f(_0x4ebc77),
      ),
  )),
    console["log"]("combined\x20cards", _0x3e964b));
  var _0x2c3164 = await _0x354b21("duplicate_protection");
  (console["log"]("duplicate_protection", _0x2c3164),
    _0x2c3164 &&
      (_0x3e964b = _0x3e964b["filter"]((_0x593c69) => {
        var _0x346b7f = _0x52123f(_0x593c69);
        return !_0x140b3a["includes"](_0x346b7f);
      })));
  if (await _0x354b21("chinese_only"))
    (console["log"]("chinese_only\x20enabled"),
      (_0x3e964b = await filterChineseItems(_0x3e964b, _0x23d270)));
  else _0x3e964b = _0x3e964b["slice"](0x0, _0x23d270);
  return _0x3e964b;
}
async function filterChineseItems(_0x1ec9c9, _0x13f6b4) {
  var _0x58f1cd = [];
  for (const _0x503d78 of _0x1ec9c9) {
    console["log"]("Checking\x20if\x20card\x20is\x20Chinese:", _0x503d78);
    var _0x2ede0f = await _0x27fef3(_0x503d78);
    (console["log"]("isChineseSeller", _0x2ede0f),
      _0x2ede0f && _0x58f1cd["push"](_0x503d78));
    if (_0x58f1cd["length"] >= _0x13f6b4) break;
  }
  return _0x58f1cd;
}
async function _0x27fef3(_0x1fcb84) {
  var _0x18cd8e = _0x52123f(_0x1fcb84),
    _0x16b4ae = await chrome["runtime"]["sendMessage"]({
      type: "isChineseProduct",
      asin: _0x18cd8e,
    }),
    _0x21382b = _0x16b4ae?.["isChineseSeller"];
  return _0x21382b;
}
async function _0x127293() {
  var _0xd1749b = document["querySelectorAll"](".s-result-item"),
    filteredCards = [],
    filteredAsins = [],
    { maxPrice: _0x1429c5 } =
      await chrome["storage"]["local"]["get"]("maxPrice");
  _0x1429c5 = parseFloat(_0x1429c5);
  var { minPrice: _0x49c19a } =
    await chrome["storage"]["local"]["get"]("minPrice");
  _0x49c19a = parseFloat(_0x49c19a);
  for (var _0x3fd393 = 0x0; _0x3fd393 < _0xd1749b["length"]; _0x3fd393++) {
    var _0x5b7fa2 = _0xd1749b[_0x3fd393]["querySelector"](".a-price-whole");
    console["log"]("getAsins\x20", _0x5b7fa2);
    var _0x32a4de = null;
    (null != _0x5b7fa2 &&
      (_0x32a4de = _0x5b7fa2["innerText"]["replace"](/,/g, "")),
      console["log"]("getAsins\x20price", _0x32a4de),
      null != (_0x32a4de = parseFloat(_0x32a4de)) &&
        _0x32a4de < _0x1429c5 &&
        _0x32a4de > _0x49c19a &&
        filteredCards["push"](_0xd1749b[_0x3fd393]));
  }
  for (_0x3fd393 = 0x0; _0x3fd393 < filteredCards["length"]; _0x3fd393++) {
    var _0x32130d = filteredCards[_0x3fd393]["getAttribute"]("data-asin");
    null == _0x32130d ||
      "" === _0x32130d ||
      filteredAsins["includes"](_0x32130d) ||
      filteredAsins["push"](_0x32130d);
  }
  return (console["log"](filteredAsins), filteredAsins);
}
function _0x235997(_0x30af30) {
  chrome["storage"]["local"]["get"]("snipeModeEnabled", function (_0x16085b) {
    var _0x6a4c12 = _0x16085b["snipeModeEnabled"];
    console["log"]("Adding\x20ASIN\x20button\x20to\x20card:", _0x30af30);
    var _0x33b5bf = _0x30af30["getAttribute"]("data-asin");
    if (!_0x33b5bf) {
      var _0x9d61b = _0x30af30["querySelectorAll"]("[data-asin]");
      _0x9d61b["length"] > 0x0 &&
        (_0x33b5bf = _0x9d61b[0x0]["getAttribute"]("data-asin"));
    }
    if (!_0x33b5bf) return;
    var _0x4fcb70 =
      _0x30af30["querySelector"](".s-image") ||
      _0x30af30["querySelector"](".s-include-content-margin") ||
      _0x30af30["querySelector"](".p13n-sc-dynamic-image");
    _0x4fcb70 || console["log"]("No\x20image\x20element\x20found", _0x30af30);
    if (_0x27b860["includes"](_0x33b5bf)) {
      (console["log"](
        "ASIN\x20" +
          _0x33b5bf +
          "\x20is\x20already\x20in\x20the\x20list\x20of\x20SKUs",
      ),
        _0x30af30["classList"]["add"]("list-asin-card--duplicate"));
      const _0x1ecfd3 = document["createElement"]("span");
      (_0x1ecfd3["classList"]["add"]("list-asin-card--duplicate-text"),
        (_0x1ecfd3["textContent"] = "Already\x20Listed"),
        _0x4fcb70
          ? _0x4fcb70["after"](_0x1ecfd3)
          : _0x30af30["appendChild"](_0x1ecfd3));
      return;
    }
    const _0x118122 = document["createElement"]("button");
    (_0x118122["classList"]["add"]("list-asin-button"),
      (_0x118122["textContent"] = _0x6a4c12
        ? "Snipe\x20ASIN:\x20" + _0x33b5bf
        : "List\x20ASIN:\x20" + _0x33b5bf),
      _0x118122["addEventListener"]("click", async (_0x3b9017) => {
        (_0x3b9017["preventDefault"](),
          console["log"](_0x33b5bf),
          _0x27b860["push"](_0x33b5bf),
          (_0x118122["disabled"] = !0x0),
          _0x30af30["classList"]["remove"]("list-asin-button"),
          _0x118122["classList"]["add"]("listing-now"),
          _0x6a4c12
            ? ((_0x118122["textContent"] = "Sniping..."),
              navigator["clipboard"]["readText"]()["then"]((_0x263b98) => {
                console["log"](_0x263b98);
                var _0xf68934 = null;
                try {
                  _0xf68934 = JSON["parse"](_0x263b98);
                } catch (_0x35415e) {
                  (console["log"]("error\x20parsing\x20json", _0x35415e),
                    alert(
                      "You\x20must\x20copy\x20the\x20item\x20details\x20from\x20the\x20ebay\x20page\x20and\x20have\x20it\x20in\x20the\x20clipboard\x20to\x20snipe.\x20Please\x20try\x20again.",
                    ));
                  return;
                }
                null != _0xf68934["title"] &&
                null != _0xf68934["price"] &&
                null != _0xf68934["itemNumber"]
                  ? _0x25f56c(_0x30af30) > _0xf68934["price"]
                    ? alert(
                        "The\x20price\x20from\x20Amazon\x20is\x20greater\x20than\x20the\x20price\x20from\x20Ebay.\x20You\x20will\x20not\x20make\x20any\x20profit.\x20Please\x20try\x20again.",
                      )
                    : chrome["runtime"]["sendMessage"](
                        {
                          type: "open_amazon_and_snipe_to_ebay",
                          asin: _0x33b5bf,
                          snipeData: _0xf68934,
                        },
                        function (_0x1a41f2) {
                          console["log"](_0x1a41f2["farewell"]);
                        },
                      )
                  : alert(
                      "The\x20title,\x20price,\x20or\x20item\x20number\x20is\x20missing\x20from\x20the\x20clipboard.\x20Please\x20try\x20again.",
                    );
              }))
            : ((_0x118122["textContent"] = "Listing..."),
              chrome["runtime"]["sendMessage"](
                { type: "open_amazon_and_list_to_ebay", asin: _0x33b5bf },
                function (_0x56c8c7) {
                  console["log"](_0x56c8c7["farewell"]);
                },
              )));
      }),
      _0x4fcb70
        ? _0x4fcb70["after"](_0x118122)
        : _0x30af30["appendChild"](_0x118122));
  });
}
function _0x3bb0cb() {
  var _0x298688 = document["querySelectorAll"](".s-result-item");
  (console["log"]("Found\x20" + _0x298688["length"] + "\x20cards"),
    _0x298688["forEach"]((_0xf31394) => {
      _0x235997(_0xf31394);
      var _0x1005a0 = _0x1bf04c(_0x4372ce(_0xf31394));
      try {
        _0xf31394["querySelector"](
          ".sg-col-inner\x20.s-widget-container\x20.a-section",
        )["appendChild"](_0x1005a0);
      } catch (_0x5e53bd) {}
    }));
}
function _0x1a934c() {
  var _0x1b9041 = document["querySelectorAll"](".a-carousel-card");
  (console["log"](
    "Found\x20" + _0x1b9041["length"] + "\x20carousel\x20cards\x20cards",
  ),
    _0x1b9041["forEach"]((_0x4a6e9a) => {
      _0x235997(_0x4a6e9a);
      var _0xc344ef = _0x2398c6(_0x4a6e9a);
      console["log"]("title:", _0xc344ef);
      var _0x4576c6 = _0x1bf04c(_0xc344ef);
      try {
        _0x4a6e9a["appendChild"](_0x4576c6);
      } catch (_0x4300da) {
        console["warn"](
          "error\x20adding\x20ebay\x20button\x20to\x20carousel\x20item",
          _0x4300da,
        );
      }
    }));
}
async function _0x3e0703() {
  (console["log"](
    "Retrieved\x20" +
      _0x27b860["length"] +
      "\x20SKUs\x20from\x20local\x20storage",
  ),
    _0x3bb0cb(),
    _0x1a934c(),
    new MutationObserver((_0x134775) => {
      _0x134775["forEach"]((_0x557bea) => {
        _0x557bea["addedNodes"]["forEach"]((_0xe9e2e3) => {
          _0xe9e2e3["classList"] &&
            _0xe9e2e3["classList"]["contains"]("s-result-item") &&
            _0x235997(_0xe9e2e3);
        });
      });
    })["observe"](document["body"], { childList: !0x0, subtree: !0x0 }));
}
function _0x95b062() {
  const _0x573a9f = [];
  return (
    document["querySelectorAll"](".s-result-item")["forEach"]((_0x23e4b3) => {
      const _0x566dfe = _0x23e4b3["getAttribute"]("data-asin");
      _0x566dfe && _0x573a9f["push"](_0x566dfe);
    }),
    console["log"](_0x573a9f),
    _0x573a9f
  );
}
const _0x2b6051 = {
  totalAsinsToFetchFromSearch: 0x64,
  appendToAmazonLinks: !0x1,
  minPrice: 0x0,
  maxPrice: 0x3e8,
  min_reviews: 0x1,
  max_reviews: 0xf423f,
  sortByReviews: !0x0,
  remove_books: !0x0,
  useRequiredKeywords: !0x1,
  veroProtectionEnabled: !0x1,
  prioritizeAmazonChoice: !0x0,
  prioritizeBestSellers: !0x0,
  duplicate_protection: !0x0,
  max_similiar_niche_items: 0x1869f,
  collect_from_all_pages: !0x1,
};
var _0x202997 = "collectAsinsParams";
async function _0x39b5db() {
  var _0x11015e = document["querySelector"](
    "span[data-component-type=\x22s-result-info-bar\x22]",
  );
  if (!_0x11015e) return;
  var { amazonLinks: _0x5494ef } =
    await chrome["storage"]["local"]["get"]("amazonLinks");
  const _0x169681 = document["createElement"]("button");
  (_0x169681["classList"]["add"]("collect-asins-button"),
    (_0x169681["textContent"] =
      "Collect\x20ASINs\x20(" +
      ((_0x5494ef && _0x5494ef["length"]) || 0x0) +
      ")"));
  const _0x53b446 = document["createElement"]("button");
  (_0x53b446["classList"]["add"]("settings-button"),
    (_0x53b446["innerHTML"] = "⚙️"),
    (_0x53b446["title"] = "Adjust\x20Settings"),
    _0x53b446["addEventListener"]("click", (_0x3c1fb7) => {
      (_0x3c1fb7["preventDefault"](), openSettingsModal());
    }),
    _0x169681["addEventListener"]("click", async (_0x1de95d) => {
      _0x1de95d["preventDefault"]();
      function _0x262c70(_0x55ffd9) {
        return new Promise((_0x1a0c3a) => setTimeout(_0x1a0c3a, _0x55ffd9));
      }
      const _0x4e7c7e = await _0x349c6e();
      let _0x1739e2 = await _0x26f537(),
        _0x278ef0 = _0x1739e2["collect_from_all_pages"],
        { amazonLinks: _0x823089 } =
          await chrome["storage"]["local"]["get"]("amazonLinks");
      ((_0x823089 = _0x823089 || []),
        _0x1739e2["appendToAmazonLinks"] || (_0x823089 = []));
      let _0x530cce = 0x0,
        _0x4440ed = 0x1;
      for (;;) {
        let _0x4b92a0 = await _0x7672ce(_0x1739e2),
          _0x192160 = [];
        for (
          let _0x234fab = 0x0;
          _0x234fab < _0x4b92a0["length"];
          _0x234fab++
        ) {
          let _0x34de86 = _0x52123f(_0x4b92a0[_0x234fab]);
          _0x34de86 &&
            _0x192160["push"](
              "https://www.amazon." +
                _0x4e7c7e +
                "/dp/" +
                _0x34de86 +
                "?th=1&psc=1",
            );
        }
        let _0x50d795 = [...new Set([..._0x823089, ..._0x192160])],
          _0x472e7d = _0x50d795["length"] - _0x823089["length"];
        ((_0x823089 = _0x50d795),
          (_0x530cce += _0x472e7d),
          await chrome["storage"]["local"]["set"]({ amazonLinks: _0x823089 }),
          await navigator["clipboard"]["writeText"](_0x823089["join"]("\x0a")),
          (_0x169681["textContent"] =
            "Page\x20" +
            _0x4440ed +
            ":\x20+" +
            _0x472e7d +
            "\x20(Total:\x20" +
            _0x823089["length"] +
            ")"));
        if (!_0x278ef0) break;
        let _0x37b285 = document["querySelector"](".s-pagination-next");
        if (!_0x37b285 || _0x37b285["getAttribute"]("aria-disabled")) break;
        (_0x37b285["click"](), await _0x262c70(0xbb8), _0x4440ed++);
      }
      ((_0x169681["textContent"] =
        "Done!\x20Added\x20" + _0x530cce + "\x20link(s)."),
        setTimeout(() => {
          _0x169681["textContent"] =
            "Collect\x20ASINs\x20(Current:\x20" + _0x823089["length"] + ")";
        }, 0xfa0));
    }),
    _0x11015e["parentNode"]["insertBefore"](
      _0x169681,
      _0x11015e["nextSibling"],
    ),
    _0x11015e["parentNode"]["insertBefore"](
      _0x53b446,
      _0x169681["nextSibling"],
    ));
}
async function _0x26f537() {
  return new Promise((_0x41f35d, _0x459b0d) => {
    chrome["storage"]["local"]["get"](_0x202997, (_0x2f9464) => {
      if (chrome["runtime"]["lastError"])
        (console["error"](
          "Error\x20retrieving\x20params:",
          chrome["runtime"]["lastError"],
        ),
          _0x41f35d({ ..._0x2b6051 }));
      else {
        const _0xd9e35f = _0x2f9464[_0x202997];
        if (_0xd9e35f) {
          const _0x235bdb = { ..._0x2b6051, ..._0xd9e35f };
          _0x41f35d(_0x235bdb);
        } else _0x41f35d({ ..._0x2b6051 });
      }
    });
  });
}
async function _0x22242d(_0x1799bd) {
  return new Promise((_0x45a89c, _0x14e764) => {
    const _0x54d36b = {};
    ((_0x54d36b[_0x202997] = { ..._0x2b6051, ..._0x1799bd }),
      chrome["storage"]["local"]["set"](_0x54d36b, () => {
        if (chrome["runtime"]["lastError"])
          (console["error"](
            "Error\x20saving\x20params:",
            chrome["runtime"]["lastError"],
          ),
            _0x14e764(chrome["runtime"]["lastError"]));
        else _0x45a89c();
      }));
  });
}
function openSettingsModal() {
  _0x62c7e2();
}
async function _0x62c7e2() {
  if (document["getElementById"]("settings-modal-overlay")) return;
  let _0x3ae1fb = await _0x26f537();
  !_0x3ae1fb && ((_0x3ae1fb = _0x2b6051), await _0x22242d(_0x2b6051));
  const _0x155803 = document["createElement"]("div");
  ((_0x155803["id"] = "settings-modal-overlay"),
    _0x155803["classList"]["add"]("settings-modal-overlay"),
    _0x155803["addEventListener"]("click", function (_0xdb6c94) {
      _0xdb6c94["target"] === _0x155803 && _0x11a2f8();
    }));
  const _0x395f6e = document["createElement"]("div");
  ((_0x395f6e["id"] = "settings-modal"),
    _0x395f6e["classList"]["add"]("settings-modal"));
  const _0x365a87 = document["createElement"]("div");
  _0x365a87["classList"]["add"]("settings-modal-content");
  const _0x3188de = document["createElement"]("div");
  _0x3188de["classList"]["add"]("settings-modal-header");
  const _0x31bf27 = document["createElement"]("h2");
  ((_0x31bf27["textContent"] = "Adjust\x20Settings"),
    _0x3188de["appendChild"](_0x31bf27));
  const _0x7c1ecd = document["createElement"]("span");
  ((_0x7c1ecd["textContent"] = "Saved"),
    (_0x7c1ecd["style"]["cssText"] =
      "\x0a\x20\x20\x20\x20margin-left:auto;\x20font:600\x2012px/1\x20system-ui,Segoe\x20UI,Roboto,Arial,sans-serif;\x0a\x20\x20\x20\x20background:#e8f7ee;\x20color:#1e7d43;\x20border:1px\x20solid\x20#b7e3c9;\x0a\x20\x20\x20\x20padding:4px\x208px;\x20border-radius:999px;\x20opacity:0;\x20transition:opacity\x20.25s\x20ease;\x0a\x20\x20"),
    _0x3188de["appendChild"](_0x7c1ecd));
  const _0x35ccb6 = document["createElement"]("span");
  (_0x35ccb6["classList"]["add"]("settings-modal-close"),
    (_0x35ccb6["innerHTML"] = "&times;"),
    _0x35ccb6["addEventListener"]("click", _0x11a2f8),
    _0x3188de["appendChild"](_0x35ccb6),
    _0x365a87["appendChild"](_0x3188de));
  const _0xf85a9b = document["createElement"]("form");
  _0xf85a9b["id"] = "settings-modal-form";
  const _0x1d04bb = _0x280490(async (_0x2aa699) => {
    (await _0x22242d(_0x2aa699),
      (_0x7c1ecd["style"]["opacity"] = "1"),
      setTimeout(() => (_0x7c1ecd["style"]["opacity"] = "0"), 0x384));
  }, 0xfa);
  [
    {
      key: "totalAsinsToFetchFromSearch",
      label: "Total\x20ASINs\x20to\x20Fetch",
    },
    {
      key: "appendToAmazonLinks",
      label: "Keep\x20Current\x20Links\x20+\x20Add\x20More",
    },
    { key: "minPrice", label: "Minimum\x20Price" },
    { key: "maxPrice", label: "Maximum\x20Price" },
    { key: "min_reviews", label: "Minimum\x20Reviews" },
    { key: "max_reviews", label: "Maximum\x20Reviews" },
    { key: "sortByReviews", label: "Sort\x20By\x20Reviews" },
    { key: "remove_books", label: "Remove\x20Books" },
    { key: "useRequiredKeywords", label: "Use\x20Required\x20Keywords" },
    { key: "veroProtectionEnabled", label: "Vero\x20Protection\x20Enabled" },
    { key: "prioritizeAmazonChoice", label: "Prioritize\x20Amazon\x20Choice" },
    { key: "prioritizeBestSellers", label: "Prioritize\x20Best\x20Sellers" },
    { key: "duplicate_protection", label: "Duplicate\x20Protection" },
    {
      key: "max_similiar_niche_items",
      label: "Max\x20Similar\x20Niche\x20Items",
    },
    {
      key: "collect_from_all_pages",
      label:
        "Collect\x20From\x20All\x20Pages\x20(Toggle\x20this\x20to\x20collect\x20from\x20all\x20pages\x20of\x20search\x20results)",
    },
  ]["forEach"](({ key: _0x22737a, label: _0x4d80db }) => {
    const _0x57aa1b = _0x3ae1fb[_0x22737a],
      _0x210556 = document["createElement"]("div");
    _0x210556["classList"]["add"]("form-group");
    if ("boolean" == typeof _0x57aa1b) {
      const _0x4dbab8 = document["createElement"]("input");
      ((_0x4dbab8["type"] = "checkbox"),
        (_0x4dbab8["id"] = "param-" + _0x22737a),
        (_0x4dbab8["checked"] = !!_0x57aa1b));
      const _0x3d36b6 = document["createElement"]("label");
      ((_0x3d36b6["htmlFor"] = "param-" + _0x22737a),
        (_0x3d36b6["textContent"] = _0x4d80db),
        _0x4dbab8["addEventListener"]("change", async () => {
          ((_0x3ae1fb[_0x22737a] = _0x4dbab8["checked"]),
            _0x1d04bb({ ..._0x3ae1fb }));
        }),
        _0x210556["appendChild"](_0x4dbab8),
        _0x210556["appendChild"](_0x3d36b6));
    } else {
      const _0x481af3 = document["createElement"]("label");
      ((_0x481af3["htmlFor"] = "param-" + _0x22737a),
        (_0x481af3["textContent"] = _0x4d80db));
      const _0x497676 = document["createElement"]("input");
      ((_0x497676["type"] = "number"),
        (_0x497676["id"] = "param-" + _0x22737a),
        (_0x497676["value"] = _0x57aa1b),
        _0x497676["addEventListener"]("input", () => {
          const _0x4c4b5f = Number(_0x497676["value"]);
          ((_0x3ae1fb[_0x22737a] = Number["isFinite"](_0x4c4b5f)
            ? _0x4c4b5f
            : 0x0),
            _0x1d04bb({ ..._0x3ae1fb }));
        }),
        _0x497676["addEventListener"]("change", () => {
          const _0x2097e4 = Number(_0x497676["value"]);
          ((_0x3ae1fb[_0x22737a] = Number["isFinite"](_0x2097e4)
            ? _0x2097e4
            : 0x0),
            _0x1d04bb({ ..._0x3ae1fb }));
        }),
        _0x210556["appendChild"](_0x481af3),
        _0x210556["appendChild"](_0x497676));
    }
    _0xf85a9b["appendChild"](_0x210556);
  });
  const _0x1e1bdb = document["createElement"]("div");
  _0x1e1bdb["classList"]["add"]("results-button-group");
  const _0x83ab61 = document["createElement"]("button");
  ((_0x83ab61["type"] = "button"),
    (_0x83ab61["textContent"] = "Copy\x20Results\x20To\x20Clipboard"),
    _0x83ab61["addEventListener"]("click", _0x158d3f));
  const _0x98e560 = document["createElement"]("button");
  ((_0x98e560["type"] = "button"),
    (_0x98e560["textContent"] = "Clear\x20Results\x20from\x20Storage"),
    _0x98e560["addEventListener"]("click", _0x2c853d),
    _0x1e1bdb["appendChild"](_0x83ab61),
    _0x1e1bdb["appendChild"](_0x98e560),
    _0xf85a9b["appendChild"](_0x1e1bdb));
  const _0x6e7d53 = document["createElement"]("div");
  _0x6e7d53["classList"]["add"]("button-group");
  const _0x1fe9d9 = document["createElement"]("button");
  ((_0x1fe9d9["type"] = "button"),
    (_0x1fe9d9["textContent"] = "Save"),
    _0x1fe9d9["addEventListener"]("click", async () => {
      (await _0x22242d(_0x3ae1fb),
        (_0x7c1ecd["style"]["opacity"] = "1"),
        setTimeout(() => (_0x7c1ecd["style"]["opacity"] = "0"), 0x384));
    }));
  const _0x356c05 = document["createElement"]("button");
  ((_0x356c05["type"] = "button"),
    (_0x356c05["textContent"] = "Close"),
    _0x356c05["addEventListener"]("click", _0x11a2f8),
    _0xf85a9b["appendChild"](_0x6e7d53),
    _0xf85a9b["addEventListener"]("keydown", async (_0x264787) => {
      ("Escape" === _0x264787["key"] &&
        (_0x264787["preventDefault"](), _0x11a2f8()),
        (_0x264787["ctrlKey"] || _0x264787["metaKey"]) &&
          "s" === _0x264787["key"]["toLowerCase"]() &&
          (_0x264787["preventDefault"](),
          await _0x22242d(_0x3ae1fb),
          (_0x7c1ecd["style"]["opacity"] = "1"),
          setTimeout(() => (_0x7c1ecd["style"]["opacity"] = "0"), 0x384)));
    }),
    _0x365a87["appendChild"](_0xf85a9b),
    _0x395f6e["appendChild"](_0x365a87),
    _0x155803["appendChild"](_0x395f6e),
    document["body"]["appendChild"](_0x155803));
}
function _0x158d3f() {
  chrome["storage"]["local"]["get"]("amazonLinks", (_0xc51cee) => {
    const _0x2b8723 = _0xc51cee["amazonLinks"] || [];
    _0x2b8723["length"] > 0x0
      ? navigator["clipboard"]
          ["writeText"](_0x2b8723["join"]("\x0a"))
          ["then"](() => {
            alert("Results\x20copied\x20to\x20clipboard.");
          })
      : alert("No\x20results\x20to\x20copy.");
  });
}
function _0x2c853d() {
  chrome["storage"]["local"]["set"]({ amazonLinks: [] }, () => {
    alert("Results\x20cleared.");
    const _0x458b8b = document["querySelector"](".collect-asins-button");
    _0x458b8b && (_0x458b8b["textContent"] = "Collect\x20ASINs\x20(0)");
  });
}
function _0x11a2f8() {
  const _0x1fc74a = document["getElementById"]("settings-modal-overlay");
  _0x1fc74a && _0x1fc74a["parentNode"]["removeChild"](_0x1fc74a);
}
async function _0x1bc85d() {
  const _0x41a86e = {};
  for (const _0x53adc8 in _0x2b6051) {
    const _0xc3977b = document["getElementById"]("param-" + _0x53adc8);
    _0xc3977b &&
      ("checkbox" === _0xc3977b["type"]
        ? (_0x41a86e[_0x53adc8] = _0xc3977b["checked"])
        : "number" === _0xc3977b["type"]
          ? (_0x41a86e[_0x53adc8] = Number(_0xc3977b["value"]))
          : "text" === _0xc3977b["type"] &&
            (_0x41a86e[_0x53adc8] = _0xc3977b["value"]));
  }
  (await _0x22242d(_0x41a86e), _0x11a2f8());
}
async function _0x349c6e() {
  return new Promise((_0x459b43, _0x21c8b7) => {
    chrome["storage"]["local"]["get"]("domain", (_0x586438) => {
      chrome["runtime"]["lastError"]
        ? _0x21c8b7(chrome["runtime"]["lastError"])
        : _0x459b43(_0x586438["domain"] || "com");
    });
  });
}
function filterSponsoredCards(_0x39c03a) {
  return Array["from"](_0x39c03a)["filter"](
    (_0x1669f5) => !_0x1669f5["querySelector"](".puis-sponsored-label-text"),
  );
}
console["log"]("amazon_search_page_functions_snipe.js");
async function _0x3d426a(_0x234b6b) {
  (console["log"]("snipedItemData:\x20", _0x234b6b),
    _0x23f460(
      _0x234b6b["title"],
      _0x234b6b["price"],
      _0x234b6b["asin"],
      _0x234b6b["image"],
    ));
  var _0x3609da = document["querySelectorAll"](".s-result-item");
  for (let _0x41a6b6 = 0x0; _0x41a6b6 < _0x3609da["length"]; _0x41a6b6++) {
    let _0xab27dc = _0x3609da[_0x41a6b6];
    (_0x2f471d(_0xab27dc),
      _0x55b0e9(_0xab27dc),
      await _0x1b2565(_0xab27dc),
      _0x5c9ecb(_0xab27dc),
      _0x4416c9(_0xab27dc),
      _0x4e7959(_0xab27dc));
  }
}
function _0x4fc6fd(_0x454acf) {
  const _0xb419c8 = _0x454acf["textContent"]
    ["split"]("")
    ["map"]((_0x307173, _0x1095a0) =>
      "\x20" === _0x307173
        ? "<span\x20class=\x22letter\x22\x20style=\x22--animation-order:" +
          _0x1095a0 +
          "\x22>&nbsp;</span>"
        : "<span\x20class=\x22letter\x22\x20style=\x22--animation-order:" +
          _0x1095a0 +
          "\x22>" +
          _0x307173 +
          "</span>",
    )
    ["join"]("");
  _0x454acf["innerHTML"] = _0xb419c8;
}
async function _0x3ff55b() {
  const _0x2f525e = Math["floor"](0xbb8 * Math["random"]()) + 0x7d0;
  return new Promise((_0x429c45) => {
    setTimeout(() => {
      _0x429c45("High\x20Quality\x20Cat6\x20Cable");
    }, _0x2f525e);
  });
}
async function _0x5c9ecb(_0x5204b6) {
  const _0x4f662f = _0x5204b6["querySelector"](".custom-title-container");
  if (!_0x4f662f) {
    console["warn"](
      "Custom\x20title\x20container\x20not\x20found\x20in\x20the\x20card:",
      _0x5204b6,
    );
    return;
  }
  if (_0x4f662f["querySelector"](".cleaning-icon")) {
    console["warn"](
      "Cleaning\x20icon\x20already\x20exists\x20in\x20this\x20card:",
      _0x5204b6,
    );
    return;
  }
  const _0x204c3d = document["createElement"]("div");
  ((_0x204c3d["className"] = "cleaning-icon"),
    _0x204c3d["setAttribute"]("title", "Clean\x20Custom\x20Title"),
    _0x204c3d["setAttribute"]("role", "button"),
    _0x204c3d["setAttribute"]("aria-label", "Clean\x20Custom\x20Title"));
  var _0xd56bc3 = await _0x5a64f6("sniper-mark-single");
  (console["log"]("spinner:\x20", _0xd56bc3),
    _0x204c3d["appendChild"](_0xd56bc3));
  const _0x5e81a3 = _0x4f662f["querySelector"](".char-counter");
  if (_0x5e81a3) {
    const _0x19ebfa = _0x4f662f["querySelector"](
      ".custom-features-right-container",
    );
    _0x19ebfa
      ? _0x19ebfa["insertBefore"](_0x204c3d, _0x5e81a3)
      : _0x4f662f["insertBefore"](_0x204c3d, _0x5e81a3);
  } else _0x4f662f["appendChild"](_0x204c3d);
  _0x204c3d["addEventListener"]("click", async function (_0x511c36) {
    var _0x18f783 =
      _0x511c36["target"]["parentElement"]["querySelector"](".sniper-mark");
    (_0x2001ca(_0x18f783),
      _0x204c3d["classList"]["add"]("disabled"),
      (_0x204c3d["style"]["cursor"] = "not-allowed"));
    const _0x1daa57 = _0x4f662f["querySelector"](".custom-title-element");
    if (_0x1daa57)
      (!_0x1daa57["classList"]["contains"]("letters-wrapped") &&
        (_0x4fc6fd(_0x1daa57),
        _0x1daa57["classList"]["add"]("letters-wrapped")),
        _0x1daa57["classList"]["add"]("floating-loop"),
        _0x4372ce(_0x5204b6),
        _0x1daa57["textContent"],
        _0x1b25dd(_0x1daa57, await _0x3ff55b(), _0x4f662f, _0x204c3d),
        _0x4cb1eb(_0x18f783),
        _0x3f0777(_0x18f783),
        await new Promise((_0x26db3c) => setTimeout(_0x26db3c, 0x7d0)),
        _0xe9453f(_0x18f783));
    else
      console["warn"]("Custom\x20title\x20element\x20not\x20found:", _0x5204b6);
  });
}
function _0x1b25dd(_0x55fff4, _0x32fce6, _0x5145f3, _0x18e7d2) {
  _0x55fff4["classList"]["remove"]("floating-loop");
  const _0x724270 = Array["from"](_0x55fff4["querySelectorAll"](".letter"));
  ((_0x55fff4["style"]["position"] = "relative"),
    _0x724270["forEach"]((_0x4fe6db) => {
      const _0xae8057 = _0x4fe6db["getBoundingClientRect"](),
        _0xcb641a = _0x55fff4["getBoundingClientRect"](),
        _0x5620b6 = _0xae8057["left"] - _0xcb641a["left"],
        _0x38f085 = _0xae8057["top"] - _0xcb641a["top"];
      ((_0x4fe6db["style"]["position"] = "absolute"),
        (_0x4fe6db["style"]["left"] = _0x5620b6 + "px"),
        (_0x4fe6db["style"]["top"] = _0x38f085 + "px"),
        (_0x4fe6db["style"]["margin"] = "0"),
        (_0x4fe6db["currentLeft"] = _0x5620b6),
        (_0x4fe6db["currentTop"] = _0x38f085),
        (_0x4fe6db["assigned"] = !0x1));
    }),
    _0x724270["forEach"]((_0xd5562a) => {
      const _0x11c0dd = 0xc8 * (Math["random"]() - 0.5),
        _0x3d9db3 = 0xc8 * (Math["random"]() - 0.5),
        _0xb216b4 = _0xd5562a["currentLeft"] + _0x11c0dd,
        _0xda4b6 = _0xd5562a["currentTop"] + _0x3d9db3;
      ((_0xd5562a["style"]["transition"] =
        "left\x201s\x20ease-in-out,\x20top\x201s\x20ease-in-out"),
        (_0xd5562a["style"]["left"] = _0xb216b4 + "px"),
        (_0xd5562a["style"]["top"] = _0xda4b6 + "px"),
        (_0xd5562a["currentLeft"] = _0xb216b4),
        (_0xd5562a["currentTop"] = _0xda4b6));
    }),
    setTimeout(() => {
      _0x1c4fb3(_0x55fff4, _0x32fce6, _0x5145f3, _0x18e7d2);
    }, 0x3e8));
}
function _0x1c4fb3(_0x5b94e4, _0x16191c, _0x1eebe1, _0x1a229c) {
  const _0x20e547 = Array["from"](_0x5b94e4["querySelectorAll"](".letter")),
    _0x1c0dca = _0x16191c["split"](""),
    mapping = [];
  _0x1c0dca["forEach"]((_0x326856) => {
    let _0x5cb60c = null;
    for (const _0x6d84ee of _0x20e547)
      if (
        !_0x6d84ee["assigned"] &&
        _0x6d84ee["textContent"]["trim"]() === _0x326856
      ) {
        ((_0x5cb60c = _0x6d84ee), (_0x6d84ee["assigned"] = !0x0));
        break;
      }
    mapping["push"]({
      char: _0x326856,
      assignedOldLetter: _0x5cb60c,
      position: null,
    });
  });
  const _0x2091ba = document["createElement"]("div");
  ((_0x2091ba["style"]["visibility"] = "hidden"),
    (_0x2091ba["style"]["position"] = "absolute"),
    (_0x2091ba["style"]["top"] = "0px"),
    (_0x2091ba["style"]["left"] = "0px"),
    (_0x2091ba["style"]["whiteSpace"] = "nowrap"),
    _0x5b94e4["appendChild"](_0x2091ba));
  const _0xf4b19f = _0x1c0dca["map"]((_0x46607d, _0x2d9e2a) =>
    "\x20" === _0x46607d
      ? "<span\x20class=\x22new-letter\x22\x20data-index=\x22" +
        _0x2d9e2a +
        "\x22>&nbsp;</span>"
      : "<span\x20class=\x22new-letter\x22\x20data-index=\x22" +
        _0x2d9e2a +
        "\x22>" +
        _0x46607d +
        "</span>",
  )["join"]("");
  ((_0x2091ba["innerHTML"] = _0xf4b19f),
    Array["from"](_0x2091ba["querySelectorAll"](".new-letter"))["forEach"](
      (_0x3df503, _0x11642c) => {
        const _0x3fad4d = _0x3df503["getBoundingClientRect"](),
          _0x349073 = _0x5b94e4["getBoundingClientRect"](),
          _0x52a537 = _0x3fad4d["left"] - _0x349073["left"],
          _0x2fe9ee = _0x3fad4d["top"] - _0x349073["top"];
        mapping[_0x11642c]["position"] = { left: _0x52a537, top: _0x2fe9ee };
      },
    ),
    _0x5b94e4["removeChild"](_0x2091ba),
    mapping["forEach"]((_0x2f75bb, _0x9fe660) => {
      if (_0x2f75bb["assignedOldLetter"]) {
        const _0x213f39 = _0x2f75bb["assignedOldLetter"];
        ((_0x213f39["style"]["transition"] =
          "left\x201.5s\x20ease-in-out\x20" +
          0.05 * _0x9fe660 +
          "s,\x20top\x201.5s\x20ease-in-out\x20" +
          0.05 * _0x9fe660 +
          "s"),
          (_0x213f39["style"]["left"] = _0x2f75bb["position"]["left"] + "px"),
          (_0x213f39["style"]["top"] = _0x2f75bb["position"]["top"] + "px"));
      }
    }),
    _0x20e547["forEach"]((_0x27b03c) => {
      !_0x27b03c["assigned"] &&
        (setTimeout(() => {
          ((_0x27b03c["style"]["transition"] =
            "top\x201s\x20ease,\x20opacity\x201s\x20ease"),
            (_0x27b03c["style"]["top"] =
              parseFloat(_0x27b03c["style"]["top"]) + 0x64 + "px"),
            (_0x27b03c["style"]["opacity"] = "0"));
        }, 0x1f4),
        setTimeout(() => {
          _0x27b03c["remove"]();
        }, 0x5dc));
    }),
    mapping["forEach"]((_0x3a5bd3, _0x27b2f1) => {
      if (!_0x3a5bd3["assignedOldLetter"]) {
        const _0x31c672 = document["createElement"]("span");
        ((_0x31c672["className"] = "letter"),
          (_0x31c672["style"]["position"] = "absolute"),
          (_0x31c672["style"]["left"] = _0x3a5bd3["position"]["left"] + "px"),
          (_0x31c672["style"]["top"] =
            "-" + (0x32 * Math["random"]() + 0x32) + "px"),
          (_0x31c672["style"]["opacity"] = "0"),
          "\x20" === _0x3a5bd3["char"]
            ? (_0x31c672["innerHTML"] = "&nbsp;")
            : (_0x31c672["textContent"] = _0x3a5bd3["char"]),
          _0x5b94e4["appendChild"](_0x31c672),
          setTimeout(() => {
            ((_0x31c672["style"]["transition"] =
              "top\x201s\x20ease-out\x20" +
              0.05 * _0x27b2f1 +
              "s,\x20opacity\x201s\x20ease\x20" +
              0.05 * _0x27b2f1 +
              "s"),
              (_0x31c672["style"]["top"] = _0x3a5bd3["position"]["top"] + "px"),
              (_0x31c672["style"]["opacity"] = "1"));
          }, 0x64));
      }
    }),
    setTimeout(() => {
      const _0x44c7c3 = _0x1eebe1["querySelector"](".char-counter");
      (_0x44c7c3 && (_0x44c7c3["textContent"] = _0x16191c["length"] + "/80"),
        _0x5b94e4["classList"]["add"]("wow-animation"),
        setTimeout(() => {
          (_0x5b94e4["classList"]["remove"]("wow-animation"),
            _0x5b94e4["querySelectorAll"](".letter")["forEach"]((_0x25763f) => {
              ((_0x25763f["style"]["position"] = ""),
                (_0x25763f["style"]["left"] = ""),
                (_0x25763f["style"]["top"] = ""),
                (_0x25763f["style"]["transition"] = ""),
                (_0x25763f["style"]["transform"] = ""),
                (_0x25763f["style"]["opacity"] = ""));
            }),
            (_0x5b94e4["textContent"] = _0x16191c),
            _0x4fc6fd(_0x5b94e4));
        }, 0x7d0),
        _0x1a229c["classList"]["remove"]("disabled"),
        (_0x1a229c["style"]["cursor"] = "pointer"));
    }, 0x9c4));
}
async function _0x1b2565(_0x4c912d) {
  var _0x4032a8 = document["getElementById"]("snipeMode-banner-container"),
    _0x3d3f52 = 0x0;
  _0x4032a8 && (_0x3d3f52 = _0x4032a8["getAttribute"]("data-snipe-price"));
  if (!_0x4c912d) {
    console["warn"]("Invalid\x20card\x20element\x20provided.");
    return;
  }
  if (_0x4c912d["querySelector"](".custom-price-element")) {
    console["warn"](
      "Custom\x20price\x20element\x20already\x20exists\x20in\x20this\x20card:",
      _0x4c912d,
    );
    return;
  }
  var _0x358a49 = _0x25f56c(_0x4c912d);
  console["log"]("cardPrice:\x20", _0x358a49);
  var _0x41f598 = _0x358a49;
  _0x358a49 <= _0x3d3f52 && (_0x41f598 = _0x3d3f52);
  if (_0x358a49 > _0x3d3f52) {
    var { markupPrice: _0x161ce3 } =
      await chrome["storage"]["local"]["get"]("markupPrice");
    _0x41f598 = _0x358a49 + _0x161ce3;
  }
  const _0x104ec7 = document["createElement"]("div");
  ((_0x104ec7["className"] = "custom-price-element"),
    _0x104ec7["setAttribute"]("contenteditable", "true"),
    _0x104ec7["setAttribute"]("data-placeholder", "Your\x20Price"),
    _0x104ec7["setAttribute"]("spellcheck", "false"),
    _0x104ec7["setAttribute"]("role", "textbox"),
    _0x104ec7["setAttribute"]("aria-label", "Custom\x20Listing\x20Price"),
    _0x104ec7["setAttribute"]("tabindex", "0"),
    (_0x104ec7["textContent"] = _0x405f19(_0x41f598)),
    _0x104ec7["setAttribute"](
      "data-last-valid-price",
      _0x104ec7["textContent"],
    ),
    _0x104ec7["addEventListener"]("focus", function () {
      let _0x240d8a = _0x405f19(_0x41f598);
      this["textContent"]["trim"]() === _0x240d8a && (this["textContent"] = "");
    }),
    _0x104ec7["addEventListener"]("blur", function () {
      "" === this["textContent"]["trim"]()
        ? (this["textContent"] = _0x405f19(_0x41f598))
        : (function (_0x53b19b) {
            let _0xeeed7c = _0x53b19b["textContent"]
                ["trim"]()
                ["replace"](/[\$€£\ ]/g, "")
                ["trim"](),
              _0xe313d3 = _0xeeed7c["indexOf"](",") > -0x1 ? "," : ".",
              _0x494ed8 = _0xeeed7c["replace"](/,/g, "."),
              _0x14ee1f = parseFloat(_0x494ed8);
            if (isNaN(_0x14ee1f))
              (_0x53b19b["classList"]["add"]("invalid"),
                setTimeout(() => {
                  ((_0x53b19b["textContent"] =
                    _0x53b19b["getAttribute"]("data-last-valid-price") ||
                    _0x405f19(_0x41f598)),
                    _0x53b19b["classList"]["remove"]("invalid"));
                }, 0x1f4));
            else {
              let _0x2f88c0 = _0x405f19(_0x14ee1f, _0xe313d3);
              ((_0x53b19b["textContent"] = _0x2f88c0),
                _0x53b19b["setAttribute"]("data-last-valid-price", _0x2f88c0),
                _0x53b19b["classList"]["remove"]("invalid"),
                !(function (_0x17ea7e) {
                  const _0x4170bf = document["createElement"]("div");
                  ((_0x4170bf["className"] = "price-update-confirmation"),
                    (_0x4170bf["textContent"] = "Price\x20Updated!"),
                    _0x17ea7e["appendChild"](_0x4170bf),
                    setTimeout(() => {
                      (_0x4170bf["classList"]["add"]("fade-out"),
                        _0x4170bf["addEventListener"]("transitionend", () => {
                          _0x4170bf["parentNode"] &&
                            _0x4170bf["parentNode"]["removeChild"](_0x4170bf);
                        }));
                    }, 0x3e8));
                })(_0x53b19b));
            }
          })(this);
    }));
  function _0x405f19(_0xcb6e62, _0x4e11c2 = ".") {
    let _0x48ff3b = parseFloat(_0xcb6e62);
    isNaN(_0x48ff3b) && (_0x48ff3b = 0x0);
    let _0x2f5ac2 = _0x48ff3b["toFixed"](0x2);
    return (
      "," === _0x4e11c2 && (_0x2f5ac2 = _0x2f5ac2["replace"](".", ",")),
      "$" + _0x2f5ac2
    );
  }
  var _0x144b4c = _0x4c912d["querySelector"](".custom-features-left-container");
  _0x144b4c
    ? _0x144b4c["appendChild"](_0x104ec7)
    : console["warn"](
        "Custom\x20features\x20left\x20container\x20not\x20found\x20in\x20the\x20card:",
        _0x4c912d,
      );
}
function _0x55b0e9(_0x5ccde9) {
  const _0x327de8 = _0x5ccde9["querySelector"](".s-price-instructions-style");
  if (!_0x327de8) {
    console["warn"](
      "Price\x20element\x20not\x20found\x20in\x20the\x20card:",
      _0x5ccde9,
    );
    return;
  }
  const _0x31fe2d = _0x5ccde9["querySelector"](".s-product-image-container");
  if (_0x31fe2d)
    (_0x31fe2d["parentNode"]["insertBefore"](_0x327de8, _0x31fe2d),
      _0x327de8["classList"]["add"]("price-at-top"));
  else
    console["warn"](
      "Product\x20image\x20container\x20not\x20found\x20in\x20the\x20card:",
      _0x5ccde9,
    );
}
function _0x248db7(_0x1fc985) {
  let _0xfed85f = _0x1fc985["querySelector"](
    ".puis-atcb-add-container\x20.a-button-primary",
  );
  if (_0xfed85f) {
    let _0xbf6063 = _0xfed85f["querySelector"](".a-button-text");
    (_0xbf6063 && (_0xbf6063["textContent"] = "Snipe"),
      _0xfed85f["classList"]["remove"]("a-button-primary"),
      _0xfed85f["classList"]["add"]("snipe-button"),
      _0xfed85f["addEventListener"]("click", function (_0x127589) {
        (_0x127589["preventDefault"](),
          _0x127589["stopPropagation"](),
          !(function () {
            if (document["querySelector"](".sniper-animation-container"))
              return;
            let _0x29e0ed = document["createElement"]("div");
            ((_0x29e0ed["className"] = "sniper-overlay"),
              _0x29e0ed["setAttribute"]("role", "dialog"),
              _0x29e0ed["setAttribute"]("aria-modal", "true"));
            let _0x1abb88 = document["createElement"]("div");
            _0x1abb88["className"] = "sniper-animation-container";
            let _0x571a15 = document["createElement"]("img");
            ((_0x571a15["className"] = "sniper-animation-image"),
              (_0x571a15["src"] = chrome["runtime"]["getURL"](
                "libraries/target-spin/target.png",
              )),
              (_0x571a15["alt"] = "Sniper\x20Mark"),
              _0x1abb88["appendChild"](_0x571a15),
              document["body"]["appendChild"](_0x29e0ed),
              document["body"]["appendChild"](_0x1abb88));
            let _0x5b0d77 = document["createElement"]("div");
            ((_0x5b0d77["className"] = "sniper-message"),
              (_0x5b0d77["textContent"] = "Sniped!"),
              document["body"]["appendChild"](_0x5b0d77));
            function _0x22c310() {
              (_0x1abb88["classList"]["add"]("sniper-animation-fade-out"),
                _0x29e0ed["classList"]["add"]("sniper-overlay-fade-out"),
                _0x5b0d77["classList"]["add"]("sniper-message-fade-out"),
                setTimeout(function () {
                  (_0x1abb88["parentNode"] &&
                    _0x1abb88["parentNode"]["removeChild"](_0x1abb88),
                    _0x29e0ed["parentNode"] &&
                      _0x29e0ed["parentNode"]["removeChild"](_0x29e0ed),
                    _0x5b0d77["parentNode"] &&
                      _0x5b0d77["parentNode"]["removeChild"](_0x5b0d77));
                }, 0x1f4));
            }
            (_0x29e0ed["addEventListener"]("click", function (_0x3b6383) {
              _0x22c310();
            }),
              _0x1abb88["addEventListener"]("click", function (_0x47c35d) {
                _0x47c35d["stopPropagation"]();
              }),
              setTimeout(function () {
                _0x22c310();
              }, 0x7d0));
          })(),
          (_0xbf6063["disabled"] = !0x0),
          (_0xbf6063["textContent"] = "Sniped"));
      }));
  }
}
function _0x4416c9(_0x41f032) {
  var _0x30aa0d = document["createElement"]("div");
  ((_0x30aa0d["textContent"] = "Snipe\x20List"),
    _0x30aa0d["classList"]["remove"]("a-button-primary"),
    _0x30aa0d["classList"]["add"]("snipe-button"),
    _0x30aa0d["addEventListener"]("click", function (_0x222bc8) {
      (_0x222bc8["preventDefault"](),
        _0x222bc8["stopPropagation"](),
        !(function () {
          if (document["querySelector"](".sniper-animation-container")) return;
          let _0x3fc243 = document["createElement"]("div");
          ((_0x3fc243["className"] = "sniper-overlay"),
            _0x3fc243["setAttribute"]("role", "dialog"),
            _0x3fc243["setAttribute"]("aria-modal", "true"));
          let _0x39ea83 = document["createElement"]("div");
          _0x39ea83["className"] = "sniper-animation-container";
          let _0x3fd3f4 = document["createElement"]("img");
          ((_0x3fd3f4["className"] = "sniper-animation-image"),
            (_0x3fd3f4["src"] = chrome["runtime"]["getURL"](
              "libraries/target-spin/target.png",
            )),
            (_0x3fd3f4["alt"] = "Sniper\x20Mark"),
            _0x39ea83["appendChild"](_0x3fd3f4),
            document["body"]["appendChild"](_0x3fc243),
            document["body"]["appendChild"](_0x39ea83));
          let _0x5c8e91 = document["createElement"]("div");
          ((_0x5c8e91["className"] = "sniper-message"),
            (_0x5c8e91["textContent"] = "Sniped!"),
            document["body"]["appendChild"](_0x5c8e91));
          function _0x333fb0() {
            (_0x39ea83["classList"]["add"]("sniper-animation-fade-out"),
              _0x3fc243["classList"]["add"]("sniper-overlay-fade-out"),
              _0x5c8e91["classList"]["add"]("sniper-message-fade-out"),
              setTimeout(function () {
                (_0x39ea83["parentNode"] &&
                  _0x39ea83["parentNode"]["removeChild"](_0x39ea83),
                  _0x3fc243["parentNode"] &&
                    _0x3fc243["parentNode"]["removeChild"](_0x3fc243),
                  _0x5c8e91["parentNode"] &&
                    _0x5c8e91["parentNode"]["removeChild"](_0x5c8e91));
              }, 0x1f4));
          }
          (_0x3fc243["addEventListener"]("click", function (_0x2cbc28) {
            _0x333fb0();
          }),
            _0x39ea83["addEventListener"]("click", function (_0x578367) {
              _0x578367["stopPropagation"]();
            }),
            setTimeout(function () {
              _0x333fb0();
            }, 0x7d0));
        })(),
        (buttonTextElement["disabled"] = !0x0),
        (buttonTextElement["textContent"] = "Sniped"));
    }));
  var _0x5b871e = _0x41f032["querySelector"](
    ".custom-features-middle-container",
  );
  (console["log"]("middleContainer:\x20", _0x5b871e),
    console["log"]("card:\x20", _0x41f032),
    _0x5b871e
      ? _0x5b871e["appendChild"](_0x30aa0d)
      : console["log"]("middleContainer\x20not\x20found"));
}
async function _0x2f471d(_0x13d6d5) {
  var _0x3c1db9 = document["getElementById"]("snipeMode-banner-container"),
    _0x1ee052 = "";
  _0x3c1db9 &&
    (_0x1ee052 = _0x3c1db9["getAttribute"]("data-snipe-title") || "");
  let _0x12144d = _0x13d6d5["querySelector"](".s-title-instructions-style");
  if (!_0x12144d) return;
  let _0x320734 = _0x12144d["querySelectorAll"]("h2");
  _0x320734["forEach"](function (_0xaf0449) {
    (_0xaf0449["classList"]["remove"]("s-line-clamp-4", "s-line-clamp-1"),
      (_0xaf0449["style"]["whiteSpace"] = "normal"),
      (_0xaf0449["style"]["overflow"] = "visible"),
      (_0xaf0449["style"]["textOverflow"] = "clip"),
      (_0xaf0449["style"]["webkitLineClamp"] = "unset"),
      (_0xaf0449["style"]["maxHeight"] = "none"),
      (_0xaf0449["style"]["height"] = "auto"),
      (_0xaf0449["style"]["color"] = "#007600"),
      _0xaf0449["querySelectorAll"]("a")["forEach"](function (_0x1dcc47) {
        let _0x40c672 = _0x1dcc47["innerHTML"],
          _0x21bf19 = document["createElement"]("span");
        ((_0x21bf19["innerHTML"] = _0x40c672),
          (_0x21bf19["style"]["cursor"] = "text"),
          _0x1dcc47["parentNode"]["replaceChild"](_0x21bf19, _0x1dcc47));
      }));
  });
  let _0x378396 = _0x320734[_0x320734["length"] - 0x1]["textContent"]["trim"](),
    _0x33b31a = Array["from"](new Set(_0x378396["split"](/\s+/))),
    _0x297b1a = document["createElement"]("div");
  _0x297b1a["className"] = "word-bank-container";
  let _0x134422 = document["createElement"]("div");
  ((_0x134422["className"] = "word-bank-label"),
    (_0x134422["textContent"] =
      "Click\x20words\x20to\x20add\x20to\x20your\x20custom\x20title:"),
    _0x297b1a["appendChild"](_0x134422),
    _0x33b31a["forEach"](function (_0x400f6f) {
      let _0x22221f = document["createElement"]("button");
      ((_0x22221f["className"] = "word-button"),
        (_0x22221f["textContent"] = _0x400f6f),
        _0x22221f["addEventListener"]("click", function () {
          let _0x2d2135 = _0x5c19a9["textContent"]["trim"](),
            _0x55d475 = _0x2d2135 ? _0x2d2135 + "\x20" + _0x400f6f : _0x400f6f;
          ((_0x5c19a9["textContent"] = _0x55d475),
            !(function (_0x2201c7) {
              _0x2201c7["focus"]();
              if (
                void 0x0 !== window["getSelection"] &&
                void 0x0 !== document["createRange"]
              ) {
                let _0x4a2b63 = document["createRange"]();
                (_0x4a2b63["selectNodeContents"](_0x2201c7),
                  _0x4a2b63["collapse"](!0x1));
                let _0x131d22 = window["getSelection"]();
                (_0x131d22["removeAllRanges"](),
                  _0x131d22["addRange"](_0x4a2b63));
              }
            })(_0x5c19a9),
            _0xd15b70());
        }),
        _0x297b1a["appendChild"](_0x22221f));
    }));
  let _0x435616 = document["createElement"]("div");
  _0x435616["className"] = "custom-title-container";
  var _0x2e948e = document["createElement"]("div");
  ((_0x2e948e["className"] = "char-counter"),
    (_0x2e948e["textContent"] = _0x1ee052["length"] + "/80"));
  let _0x5c19a9 = document["createElement"]("div");
  ((_0x5c19a9["className"] = "custom-title-element"),
    (_0x5c19a9["contentEditable"] = "true"),
    (_0x5c19a9["textContent"] = _0x1ee052),
    _0x5c19a9["setAttribute"](
      "data-placeholder",
      "Click\x20here\x20to\x20edit\x20custom\x20title\x20(max\x2080\x20characters)",
    ),
    _0x5c19a9["setAttribute"]("spellcheck", "false"));
  function _0xd15b70() {
    let _0x5070e1 = _0x5c19a9["textContent"] || "",
      length = _0x5070e1["trim"]()["length"];
    ((_0x2e948e["textContent"] = length + "/80"),
      length > 0x50
        ? (_0x5c19a9["classList"]["add"]("exceeds-limit"),
          _0x2e948e["classList"]["add"]("exceeds-limit"))
        : (_0x5c19a9["classList"]["remove"]("exceeds-limit"),
          _0x2e948e["classList"]["remove"]("exceeds-limit")),
      _0x13d6d5["setAttribute"]("data-custom-title", _0x5070e1["trim"]()));
  }
  (_0x5c19a9["addEventListener"]("input", _0xd15b70),
    _0x5c19a9["addEventListener"]("keyup", _0xd15b70),
    _0x5c19a9["addEventListener"]("paste", function (_0x543251) {
      _0x543251["preventDefault"]();
      let _0x24a376 = (_0x543251["clipboardData"] || window["clipboardData"])[
        "getData"
      ]("text/plain");
      (document["execCommand"]("insertText", !0x1, _0x24a376), _0xd15b70());
    }));
  var _0x2d3ded = document["createElement"]("div");
  _0x2d3ded["className"] = "custom-title-features-container";
  var _0x51ce77 = document["createElement"]("div");
  _0x51ce77["className"] = "custom-features-left-container";
  var _0x3abbe1 = document["createElement"]("div");
  _0x3abbe1["className"] = "custom-features-middle-container";
  var _0x3756c8 = document["createElement"]("div");
  ((_0x3756c8["className"] = "custom-features-right-container"),
    _0x2d3ded["appendChild"](_0x51ce77),
    _0x2d3ded["appendChild"](_0x3abbe1),
    _0x2d3ded["appendChild"](_0x3756c8),
    _0x3756c8["appendChild"](_0x2e948e),
    _0x435616["appendChild"](_0x5c19a9),
    _0x435616["appendChild"](_0x2d3ded),
    _0x12144d["appendChild"](_0x435616),
    _0x12144d["appendChild"](_0x297b1a));
}
function _0x23f460(_0x238848, _0x6dee2a, _0x13d331, _0x1f1652) {
  var _0x23eaee = document["getElementById"]("snipeMode-banner-container");
  _0x23eaee && _0x23eaee["remove"]();
  var _0x7291be = document["createElement"]("div");
  ((_0x7291be["id"] = "snipeMode-banner-container"),
    (_0x7291be["className"] = "snipeMode-banner-container"),
    document["body"]["appendChild"](_0x7291be));
  var _0x590211 = document["createElement"]("img");
  ((_0x590211["className"] = "snipeMode-competitor-image"),
    (_0x590211["src"] = _0x1f1652),
    _0x7291be["appendChild"](_0x590211));
  var _0x248a44 = document["createElement"]("div");
  ((_0x248a44["className"] = "snipeMode-content"),
    _0x7291be["appendChild"](_0x248a44));
  var _0x34c866 = document["createElement"]("div");
  ((_0x34c866["className"] = "snipeMode-title-container"),
    _0x248a44["appendChild"](_0x34c866));
  var _0x557bfa = document["createElement"]("div");
  ((_0x557bfa["className"] = "snipeMode-competitor-title"),
    (_0x557bfa["contentEditable"] = "true"),
    (_0x557bfa["innerHTML"] = _0x238848),
    _0x34c866["appendChild"](_0x557bfa));
  var _0x25f50c = document["createElement"]("button");
  ((_0x25f50c["className"] = "snipeMode-refresh-button"),
    _0x25f50c["setAttribute"]("title", "Refresh\x20Custom\x20Titles"),
    (_0x25f50c["innerHTML"] = "&#x21bb;"),
    _0x34c866["appendChild"](_0x25f50c),
    _0x25f50c["addEventListener"]("click", function () {
      var _0x181bb3 = _0x557bfa["textContent"]["trim"]();
      (_0x7291be["setAttribute"]("data-snipe-title", _0x181bb3),
        _0x43f2b8(_0x181bb3));
    }));
  var _0x18a5e9 = document["createElement"]("div");
  ((_0x18a5e9["className"] = "snipeMode-competitor-price"),
    (_0x18a5e9["innerHTML"] = "Price:\x20$" + _0x6dee2a),
    _0x248a44["appendChild"](_0x18a5e9));
  var _0x501438 = document["createElement"]("button");
  ((_0x501438["id"] = "snipeMode-close-button"),
    (_0x501438["className"] = "snipeMode-close-button"),
    (_0x501438["innerHTML"] = "&times;"),
    _0x7291be["appendChild"](_0x501438),
    _0x501438["addEventListener"]("click", function () {
      _0x7291be["remove"]();
    }),
    _0x7291be["setAttribute"]("data-snipe-title", _0x238848),
    _0x7291be["setAttribute"]("data-snipe-price", _0x6dee2a),
    _0x7291be["setAttribute"]("data-snipe-item-number", _0x13d331));
}
function _0x43f2b8(_0x1c7cfe) {
  document["querySelectorAll"](".custom-title-element")["forEach"](
    function (_0x7cc19f) {
      _0x7cc19f["textContent"] = _0x1c7cfe;
      var _0x1ab2db = _0x7cc19f["closest"](".s-result-item");
      _0x1ab2db && _0x1ab2db["setAttribute"]("data-custom-title", _0x1c7cfe);
      var _0x5ce234 =
        _0x7cc19f["parentElement"]["querySelector"](".char-counter");
      (_0x5ce234 && (_0x5ce234["textContent"] = _0x1c7cfe["length"] + "/80"),
        _0x1c7cfe["length"] > 0x50
          ? (_0x7cc19f["classList"]["add"]("exceeds-limit"),
            _0x5ce234 && _0x5ce234["classList"]["add"]("exceeds-limit"))
          : (_0x7cc19f["classList"]["remove"]("exceeds-limit"),
            _0x5ce234 && _0x5ce234["classList"]["remove"]("exceeds-limit")));
    },
  );
}
function _0x4e7959(_0x4cfe8f, _0x1cb941 = "2%") {
  if (!_0x4cfe8f) {
    console["warn"]("Invalid\x20card\x20element\x20provided.");
    return;
  }
  if (_0x4cfe8f["querySelector"](".custom-adRate-element")) {
    console["warn"](
      "Custom\x20ad\x20rate\x20element\x20already\x20exists\x20in\x20this\x20card:",
      _0x4cfe8f,
    );
    return;
  }
  const _0x4161d8 = document["createElement"]("div");
  ((_0x4161d8["className"] = "custom-adRate-element"),
    _0x4161d8["setAttribute"]("contenteditable", "true"),
    _0x4161d8["setAttribute"]("data-placeholder", "Ad\x20Rate\x20(%)"),
    _0x4161d8["setAttribute"]("spellcheck", "false"),
    _0x4161d8["setAttribute"]("role", "textbox"),
    _0x4161d8["setAttribute"]("aria-label", "Custom\x20Ad\x20Rate"),
    _0x4161d8["setAttribute"]("tabindex", "0"),
    (_0x4161d8["textContent"] = _0x1cb941),
    _0x4161d8["setAttribute"]("data-last-valid-adRate", _0x1cb941),
    _0x4161d8["addEventListener"]("focus", function () {
      this["textContent"]["trim"]() === _0x1cb941 && (this["textContent"] = "");
    }),
    _0x4161d8["addEventListener"]("blur", function () {
      "" === this["textContent"]["trim"]()
        ? (this["textContent"] = _0x1cb941)
        : (function (_0x2b0a05) {
            let _0x560844 = _0x2b0a05["textContent"]
                ["trim"]()
                ["replace"]("%", "")
                ["trim"](),
              _0x212bc6 = parseFloat(_0x560844);
            if (isNaN(_0x212bc6))
              (_0x2b0a05["classList"]["add"]("invalid"),
                setTimeout(() => {
                  ((_0x2b0a05["textContent"] =
                    _0x2b0a05["getAttribute"]("data-last-valid-adRate") ||
                    _0x1cb941),
                    _0x2b0a05["classList"]["remove"]("invalid"));
                }, 0x1f4));
            else {
              let _0x40a28c = _0x212bc6 + "%";
              ((_0x2b0a05["textContent"] = _0x40a28c),
                _0x2b0a05["setAttribute"]("data-last-valid-adRate", _0x40a28c),
                _0x2b0a05["classList"]["remove"]("invalid"),
                !(function (_0x24502e) {
                  const _0x22d612 = document["createElement"]("div");
                  ((_0x22d612["className"] = "adRate-update-confirmation"),
                    (_0x22d612["textContent"] = "Ad\x20Rate\x20Updated!"),
                    _0x24502e["appendChild"](_0x22d612),
                    setTimeout(() => {
                      (_0x22d612["classList"]["add"]("fade-out"),
                        _0x22d612["addEventListener"]("transitionend", () => {
                          _0x22d612["parentNode"] &&
                            _0x22d612["parentNode"]["removeChild"](_0x22d612);
                        }));
                    }, 0x3e8));
                })(_0x2b0a05));
            }
          })(this);
    }));
  var _0x7a945 = _0x4cfe8f["querySelector"](".custom-features-left-container");
  _0x7a945
    ? _0x7a945["appendChild"](_0x4161d8)
    : console["warn"](
        "Custom\x20features\x20left\x20container\x20not\x20found\x20in\x20the\x20card:",
        _0x4cfe8f,
      );
}
console["log"]("amazon_search_page.js\x20loaded");
var _0x27b860 = [];
(chrome["runtime"]["onMessage"]["addListener"](
  function (_0x2b5dd7, _0x58ef28, _0x49b930) {
    (console["log"](
      _0x58ef28["tab"]
        ? "from\x20a\x20content\x20script:" + _0x58ef28["tab"]["url"]
        : "from\x20the\x20extension",
    ),
      console["log"](_0x2b5dd7));
    if ("get-top-items" == _0x2b5dd7["type"]) {
      console["log"]("get-top-items");
      var _0x30b33a = {};
      return (
        null != _0x2b5dd7["params"] && (_0x30b33a = _0x2b5dd7["params"]),
        _0x7672ce(_0x30b33a, _0x2b5dd7["maxPrice"])["then"](
          function (_0x16daf4) {
            var _0x29f386 = [];
            for (
              var _0x1abadd = 0x0;
              _0x1abadd < _0x16daf4["length"];
              _0x1abadd++
            ) {
              var _0x1f545a = _0x16daf4[_0x1abadd],
                _0x4f8f70 = {
                  asin: _0x52123f(_0x1f545a),
                  title: _0x4372ce(_0x1f545a),
                  price: _0x25f56c(_0x1f545a),
                  image: _0x39be91(_0x1f545a),
                  reviewCount: _0x4014cd(_0x1f545a),
                };
              _0x29f386["push"](_0x4f8f70);
            }
            _0x49b930({ products: _0x29f386 });
          },
        ),
        !0x0
      );
    }
  },
),
  document["addEventListener"]("DOMContentLoaded", async () => {
    ((_0x27b860 = await _0x4844e4()), console["log"]("DOM\x20loaded"));
    var { snipeModeEnabled: _0x489bcb } =
      await chrome["storage"]["local"]["get"]("snipeModeEnabled");
    if (_0x489bcb) {
      var { snipedItemData: _0x40c69b } =
        await chrome["storage"]["local"]["get"]("snipedItemData");
      _0x3d426a(_0x40c69b);
    } else (_0x3e0703(), _0x39b5db());
  }));
