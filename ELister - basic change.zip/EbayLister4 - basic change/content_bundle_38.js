function _0x57ccbb() {
  return new Promise((_0x1f165c) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x1f165c();
      });
    });
  });
}
function _0x360e77() {
  return new Promise((_0x29ac45) => {
    requestIdleCallback(() => {
      _0x29ac45();
    });
  });
}
function _0x249ef7(_0x24f17c = 0x3e8) {
  return new Promise((_0x16b237, _0x4df71e) => {
    let _0x5c3680,
      _0x476730 = Date["now"](),
      _0x3b0056 = !0x1;
    function _0xeeb111() {
      if (Date["now"]() - _0x476730 > _0x24f17c)
        (_0x3b0056 && _0x5c3680["disconnect"](), _0x16b237());
      else setTimeout(_0xeeb111, _0x24f17c);
    }
    const _0x281e81 = () => {
        _0x476730 = Date["now"]();
      },
      _0x5158a3 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x5c3680 = new MutationObserver(_0x281e81)),
        _0x5c3680["observe"](document["body"], _0x5158a3),
        (_0x3b0056 = !0x0),
        setTimeout(_0xeeb111, _0x24f17c));
    else
      window["onload"] = () => {
        ((_0x5c3680 = new MutationObserver(_0x281e81)),
          _0x5c3680["observe"](document["body"], _0x5158a3),
          (_0x3b0056 = !0x0),
          setTimeout(_0xeeb111, _0x24f17c));
      };
  });
}
async function _0x5a17c5() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x249ef7(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x54d746() {
  return await new Promise(function (_0x358bd7, _0x8784bf) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x33478c) {
        (console["log"]("result:\x20", _0x33478c["membership"]),
          _0x358bd7(_0x33478c["membership"]));
      },
    );
  });
}
async function _0x33684f() {
  return await new Promise(function (_0x5db068, _0x321c26) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x5ba099) {
        (console["log"]("result:\x20", _0x5ba099["creditsAvailable"]),
          _0x5db068(_0x5ba099["creditsAvailable"]));
      },
    );
  });
}
async function _0x518954(_0x162512) {
  if ("ultimate" != (await _0x54d746()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x33684f()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
console["log"]("content/captcha/hcaptcha/functions.js");
async function _0x37df73(_0x281159 = !0x1) {
  _0x281159 && chrome["storage"]["local"]["remove"]("nocaptcha");
  var { nocaptcha: _0x291b0b } =
    await chrome["storage"]["local"]["get"]("nocaptcha");
  if (_0x291b0b && _0x291b0b["apiKey"]) return _0x291b0b["apiKey"];
  var { user: _0x3af1ee } = await chrome["storage"]["local"]["get"]("user"),
    _0x158a20 =
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/getApiKey/1737002384160?email=" +
      _0x3af1ee["email"],
    _0x3f4787 = await _0x54d746();
  console["log"]("membership", _0x3f4787);
  if ("ultimate" == _0x3f4787) {
    var _0x239aca = await fetch(_0x158a20),
      _0x4a8b31 = await _0x239aca["json"]();
    console["log"]("data", _0x4a8b31);
    var _0x58a0df = _0x4a8b31["apiKey"];
    return (
      chrome["storage"]["local"]["set"]({ nocaptcha: { apiKey: _0x58a0df } }),
      _0x58a0df
    );
  }
  alert(
    "You\x20are\x20not\x20a\x20member\x20of\x20the\x20sniper\x20list.\x20Please\x20contact\x20support.",
  );
}
(async () => {
  console["log"]("content/hcaptcha/content.js");
  let _0x14497e = {
      logsEnabled: "true",
      APIKEY: await _0x37df73(),
      extensionEnabled: "true",
      hCaptchaEnabled: "true",
      PLANTYPE: "pro",
      hCaptchaAutoOpen: "true",
      hCaptchaAutoSolve: "true",
      hCaptchaAlwaysSolve: "false",
      debugMode: "false",
      debugModeGridOnly: "false",
      englishLanguage: "true",
      hCaptchaMultiSolveTime: 0xa,
      hCaptchaBoundingBoxSolveTime: 0xa,
      hCaptchaGridSolveTime: 0xa,
      customEndpoint: "api.example.com",
    },
    _0x174191 = "true" === _0x14497e["logsEnabled"];
  function _0x5987e6(..._0x508b94) {
    _0x174191 && console["log"](..._0x508b94);
  }
  _0x14497e["APIKEY"] &&
    (chrome["runtime"]["onMessage"]["addListener"](
      function (_0x52e326, _0x5babc9, _0x5018ff) {
        if ("refresh_iframes" === _0x52e326["action"]) {
          const _0x407fa2 = [
            ...document["querySelectorAll"]("[src*=newassets]"),
          ];
          if (_0x407fa2)
            for (const _0x41c8d0 of _0x407fa2) {
              const _0x5acf16 = _0x41c8d0["src"];
              ((_0x41c8d0["src"] = "about:blank"),
                setTimeout(function () {
                  _0x41c8d0["src"] = _0x5acf16;
                }, 0x64));
            }
          Array["from"](document["getElementsByTagName"]("iframe"))["forEach"](
            (_0x201a62) => {
              _0x201a62["src"] = _0x201a62["src"];
            },
          );
        }
      },
    ),
    (async () => {
      if ("false" === _0x14497e["extensionEnabled"]) return;
      if ("false" === _0x14497e["hCaptchaEnabled"]) return;
      const _0x331713 = (_0x4e9b9e) => document["querySelector"](_0x4e9b9e);
      function _0x5178c0() {
        const _0x4ebf0f = document["body"]["getBoundingClientRect"]();
        return (
          0x0 !== _0x4ebf0f?.["width"] &&
          0x0 !== _0x4ebf0f?.["height"] &&
          null !== document["querySelector"]("div.check")
        );
      }
      function _0x54499d(_0x2a4cb2) {
        return new Promise((_0x4396f4) => setTimeout(_0x4396f4, _0x2a4cb2));
      }
      function _0x3d9f23() {
        try {
          const _0x3aeb79 = document["querySelector"]("div.check");
          return _0x3aeb79 && "block" === _0x3aeb79["style"]["display"];
        } catch (_0xc23b42) {
          return (console["log"](_0xc23b42), !0x1);
        }
      }
      const _0x42c8d7 = () =>
        !navigator["onLine"] ||
        null == _0x14497e["PLANTYPE"] ||
        void 0x0 === _0x14497e["APIKEY"] ||
        "" === _0x14497e["APIKEY"];
      async function _0x490f38(_0x437fce) {
        const _0x4fdd0f = await fetchFromBackground(_0x437fce, {
            method: "GET",
          }),
          { data: _0x23334f, contentType: _0x31afc4 } = _0x4fdd0f;
        if (_0x31afc4 && _0x31afc4["includes"]("image"))
          return _0x23334f["replace"](/^data:image\/(png|jpeg);base64,/, "");
        return (_0x5987e6("❌\x20Failed\x20to\x20get\x20image\x20data"), null);
      }
      for (; !_0x42c8d7(); ) {
        await _0x54499d(0x3e8);
        if ("true" === _0x14497e["hCaptchaAutoOpen"] && _0x5178c0()) {
          if (_0x3d9f23()) {
            _0x5987e6("found\x20solved");
            if ("false" === _0x14497e["hCaptchaAlwaysSolve"]) break;
          }
          (await _0x54499d(0x3e8), _0x331713("#checkbox")?.["click"]());
        } else
          "true" === _0x14497e["hCaptchaAutoSolve"] &&
            null !== _0x331713("h2.prompt-text") &&
            (_0x5987e6("opening\x20box"),
            await _0x54499d(0x3e8),
            await _0x4453a4());
      }
      async function _0x4453a4() {
        let _0x3f5b35 = new Date();
        if ("true" == _0x14497e["debugMode"] && !_0x163f29()) {
          document["querySelector"](".button-submit")["click"]();
          return;
        }
        if ("true" == _0x14497e["debugModeGridOnly"] && !_0x482884()) {
          document["querySelector"](".button-submit")["click"]();
          return;
        }
        "true" === _0x14497e["englishLanguage"] &&
          "en" !==
            (document["documentElement"]["lang"] || navigator["language"]) &&
          (await (async function () {
            if (_0x163f29())
              (await _0x54499d(0xc8),
                document["querySelector"](".display-language.button")[
                  "click"
                ](),
                await _0x54499d(0x64),
                document["querySelector"](
                  ".language-selector\x20.option:nth-child(23)",
                )["click"]());
            else {
              if (_0x482884())
                (await _0x54499d(0x64),
                  document["querySelector"](
                    ".language-selector\x20.option:nth-child(23)",
                  )["click"]());
              else
                _0x41a8e1() &&
                  (document["querySelector"](".display-language.button")[
                    "click"
                  ](),
                  await _0x54499d(0xc8),
                  document["querySelector"](
                    ".language-selector\x20.option:nth-child(23)",
                  )["click"](),
                  await _0x54499d(0xc8));
            }
          })());
        const {
          target: _0x40401f,
          cells: _0x3092a9,
          images: _0x1402da,
          examples: _0x32c07c,
          example: _0x1b859b,
          choices: _0x511330,
        } = await (async function (_0xca4e2e = 0x1f4) {
          return new Promise(async (_0x3e3a4c) => {
            const _0x5e5441 = setInterval(async function () {
              let _0x516bec =
                document["querySelector"](".prompt-text")?.["textContent"];
              if (!_0x516bec) return;
              let _0x5ab9b7 = 0x0,
                _0x10f904 = {},
                _0x24a2a8 = [],
                _0x2b7ecf = [];
              if (_0x482884()) {
                _0x5ab9b7 = document["querySelectorAll"](
                  ".task-image\x20.image",
                );
                if (0x9 !== _0x5ab9b7["length"]) return;
                for (
                  let _0x2af51c = 0x0;
                  _0x2af51c < _0x5ab9b7["length"];
                  _0x2af51c++
                ) {
                  const _0x3b2a3f = _0x5ab9b7[_0x2af51c];
                  if (!_0x3b2a3f) return;
                  const _0xa43ba =
                    _0x3b2a3f["style"]["background"]["match"](
                      /url\("(.*)"/,
                    )?.[0x1] || null;
                  if (!_0xa43ba) return;
                  _0x10f904[_0x2af51c] = await _0x490f38(_0xa43ba);
                }
              } else {
                if (_0x41a8e1()) {
                  const _0x359400 = document["querySelector"](
                    ".task-image\x20.image",
                  )?.["style"]?.["background"];
                  if (_0x359400) {
                    const _0x2e6231 = _0x359400["match"](/url\("(.*)"/)?.[0x1];
                    _0x2e6231 && (_0x10f904[0x0] = await _0x490f38(_0x2e6231));
                  }
                  const _0x2a95a4 =
                    document["querySelectorAll"](".answer-text");
                  _0x2b7ecf = Array["from"](_0x2a95a4)["map"](
                    (_0x49503c) => _0x49503c["outerText"],
                  );
                } else {
                  if (_0x163f29()) {
                    const _0x3aba10 = await (async function () {
                      const _0x19d80f = document["querySelector"]("canvas");
                      if (!_0x19d80f) return null;
                      const [_0x394cc9, _0x5b89cf] = [
                          _0x19d80f["width"],
                          _0x19d80f["height"],
                        ],
                        _0x55701b = document["createElement"]("canvas");
                      ((_0x55701b["width"] = _0x394cc9),
                        (_0x55701b["height"] = _0x5b89cf));
                      const _0x18ea69 = _0x55701b["getContext"]("2d", {
                        willReadFrequently: !0x0,
                      });
                      _0x18ea69["drawImage"](_0x19d80f, 0x0, 0x0);
                      const _0x496e95 = _0x18ea69["getImageData"](
                        0x0,
                        0x0,
                        _0x394cc9,
                        _0x5b89cf,
                      );
                      if (
                        Array["from"](_0x496e95["data"])["every"](
                          (_0x61a66f, _0x587c9f) =>
                            _0x587c9f % 0x4 == 0x3 || 0x0 === _0x61a66f,
                        )
                      )
                        return (
                          console["error"](
                            "The\x20original\x20canvas\x20has\x20no\x20valid\x20content",
                          ),
                          null
                        );
                      const _0x43b295 = parseInt(
                          _0x19d80f["style"]["width"],
                          0xa,
                        ),
                        _0xb67cd = parseInt(_0x19d80f["style"]["height"], 0xa);
                      if (_0x43b295 <= 0x0 || _0xb67cd <= 0x0)
                        return (
                          console["error"](
                            "Desired\x20width/height\x20invalid",
                          ),
                          null
                        );
                      const _0x1109a3 = Math["min"](
                          _0x43b295 / _0x394cc9,
                          _0xb67cd / _0x5b89cf,
                        ),
                        [_0x4c61bf, _0x5993fb] = [
                          _0x394cc9 * _0x1109a3,
                          _0x5b89cf * _0x1109a3,
                        ],
                        _0x24f55f = document["createElement"]("canvas");
                      return (
                        Object["assign"](_0x24f55f, {
                          width: _0x4c61bf,
                          height: _0x5993fb,
                        }),
                        _0x24f55f["getContext"]("2d")["drawImage"](
                          _0x19d80f,
                          0x0,
                          0x0,
                          _0x394cc9,
                          _0x5b89cf,
                          0x0,
                          0x0,
                          _0x4c61bf,
                          _0x5993fb,
                        ),
                        _0x24f55f["toDataURL"]("image/jpeg")["replace"](
                          /^data:image\/(png|jpeg);base64,/,
                          "",
                        )
                      );
                    })();
                    _0x3aba10 && (_0x10f904[0x0] = _0x3aba10);
                    let _0x4bfa87 = document["querySelectorAll"](
                      ".example-image\x20.image",
                    );
                    for (const _0x6eb9e3 of _0x4bfa87) {
                      let _0x470f6c =
                        _0x6eb9e3["style"]["background"]["match"](
                          /url\("([^"]+)"\)/,
                        );
                      if (_0x470f6c)
                        try {
                          const _0x1b8812 = await _0x490f38(_0x470f6c[0x1]);
                          _0x24a2a8["push"](_0x1b8812);
                        } catch (_0x5e08b6) {
                          console["error"](
                            "Error\x20converting\x20image\x20to\x20Base64:",
                            _0x5e08b6,
                          );
                        }
                    }
                  }
                }
              }
              (clearInterval(_0x5e5441),
                _0x3e3a4c({
                  target: _0x516bec,
                  cells: _0x5ab9b7,
                  images: _0x10f904,
                  examples: _0x24a2a8,
                  example: {},
                  choices: _0x2b7ecf,
                }));
            }, _0xca4e2e);
          });
        })();
        if ("true" === !_0x14497e["hCaptchaAutoSolve"]) return;
        let _0x4cfc62 = _0x41a8e1()
          ? "objectTag"
          : _0x163f29()
            ? "objectClick"
            : "objectClassify";
        const _0x2d2827 = {
          apiKey: _0x14497e["APIKEY"],
          source: "chrome",
          version: "0.1.3",
          appID: 0x0,
          task: {
            type: "PopularCaptchaImage",
            queries: Object["values"](_0x1402da),
            question: _0x40401f,
            questionType: _0x4cfc62,
          },
        };
        var _0x5747a9;
        try {
          _0x5747a9 = await fetchFromBackground(
            "https://api.captchasonic.com/createTask",
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                apikey: _0x14497e["APIKEY"],
              },
              body: JSON["stringify"](_0x2d2827),
            },
          );
        } catch (_0x1bcb01) {
          (console["error"](
            "✘\x20CaptchaSonic\x20request\x20failed:",
            _0x1bcb01,
          ),
            _0x2a6266(
              "✘\x20Failed\x20to\x20connect\x20to\x20CaptchaSonic",
              0x1388,
              !0x1,
            ));
          throw new Error("✘\x20CaptchaSonic\x20request\x20failed");
        }
        console["log"]("✓\x20CaptchaSonic\x20response:", _0x5747a9);
        if (0x1 === (_0x5747a9 = _0x5747a9["data"])["code"]) {
          _0x14497e["APIKEY"] = await _0x37df73(!0x0);
          return;
        }
        if (!_0x5747a9 || 0xc8 !== _0x5747a9["code"]) {
          _0x2a6266(
            "Captchasonic\x20error:\x20" +
              (_0x5747a9?.["msg"] ||
                "Unknown\x20error\x20from\x20CaptchaSonic"),
          );
          return;
        }
        const { answers: _0x240ad2 } = _0x5747a9;
        if (!_0x240ad2) {
          _0x2a6266("No\x20answers\x20returned");
          return;
        }
        if (_0x41a8e1()) {
          const _0xa99e6f = _0x240ad2[0x0];
          Array["isArray"](_0xa99e6f) &&
            (await (async function (_0x2bedeb) {
              for (const _0xb62e49 of _0x2bedeb) {
                const _0x52f970 = [
                  ...document["querySelectorAll"](".answer-text"),
                ]["find"](
                  (_0x248250) =>
                    _0x248250["outerText"]["trim"]() === _0xb62e49["trim"](),
                );
                _0x52f970 &&
                  (_0x2a38d0(_0x52f970),
                  [...document["querySelectorAll"](".answer-example")]["some"](
                    (_0x196c6c) =>
                      "rgb(116,\x20116,\x20116)" ===
                      _0x196c6c["style"]["backgroundColor"],
                  ) || _0x2a38d0(_0x52f970));
              }
            })(_0xa99e6f));
        } else {
          if (_0x482884()) {
            if (Array["isArray"](_0x240ad2) && _0x240ad2["length"] >= 0x9) {
              let _0x576dad = Math["floor"](0x64 * Math["random"]() + 0xc8);
              for (
                let _0x2e6cf4 = 0x0;
                _0x2e6cf4 < _0x240ad2["length"];
                _0x2e6cf4++
              )
                !0x0 === _0x240ad2[_0x2e6cf4] &&
                  (_0x3092a9[_0x2e6cf4]["click"](), await _0x54499d(_0x576dad));
            }
          } else
            _0x163f29() &&
              Array["isArray"](_0x240ad2[0x0]) &&
              _0x240ad2[0x0]["length"] > 0x0 &&
              (await (async function (_0x1a0c08) {
                function _0x9ef18a(_0x1eac08, _0x1f187b, _0x3b6469) {
                  const _0x34396a = _0x1eac08["getBoundingClientRect"](),
                    _0xa4f121 = ["mouseover", "mousedown", "mouseup", "click"],
                    _0x224c54 = {
                      clientX: _0x1f187b + _0x34396a["left"],
                      clientY: _0x3b6469 + _0x34396a["top"],
                      bubbles: !0x0,
                    };
                  for (const _0x5d559e of _0xa4f121) {
                    const _0x2b8c6d = new MouseEvent(_0x5d559e, _0x224c54);
                    _0x1eac08["dispatchEvent"](_0x2b8c6d);
                  }
                }
                const _0x910443 = document["querySelector"]("canvas");
                if (_0x910443)
                  for (
                    let _0x63660e = 0x0;
                    _0x63660e < _0x1a0c08["length"];
                    _0x63660e++
                  ) {
                    const { x: _0xeb1ff0, y: _0x4b94e5 } = _0x1a0c08[_0x63660e];
                    (_0x9ef18a(_0x910443, _0xeb1ff0, _0x4b94e5),
                      await _0x54499d(0x12c));
                  }
              })(_0x240ad2[0x0]));
        }
        const _0x4e43e0 = new Date() - _0x3f5b35,
          _0x4a603f = _0x41a8e1()
            ? 0x3e8 * _0x14497e["hCaptchaMultiSolveTime"] - _0x4e43e0
            : _0x163f29()
              ? 0x3e8 * _0x14497e["hCaptchaBoundingBoxSolveTime"] - _0x4e43e0
              : 0x3e8 * _0x14497e["hCaptchaGridSolveTime"] - _0x4e43e0;
        (_0x4a603f > 0x0 && (await _0x54499d(_0x4a603f)),
          document["querySelector"](".button-submit")["click"](),
          (_0x3f5b35 = 0x0));
      }
      function _0x2a38d0(_0x160694) {
        ["mouseover", "mousedown", "mouseup", "click"]["forEach"](
          (_0x1e4011) => {
            if (_0x160694["fireEvent"])
              _0x160694["fireEvent"]("on" + _0x1e4011);
            else {
              const _0xb02396 = document["createEvent"]("MouseEvents");
              (_0xb02396["initEvent"](_0x1e4011, !0x0, !0x1),
                _0x160694["dispatchEvent"](_0xb02396));
            }
          },
        );
      }
      const _0x2a6266 = (_0x155056, _0x13bf39) => {
        const _0x3c5672 = document["createElement"]("div");
        ((_0x3c5672["style"]["cssText"] =
          "position:fixed;top:10%;left:0;background-color:rgba(0,0,0,.8);border-radius:4px;padding:16px;color:#fff;font:calc(14px\x20+\x20.5vw)\x20\x27Arial\x27,sans-serif;font-weight:bold;text-transform:uppercase;letter-spacing:1px;z-index:9999;transition:all\x201s;animation:slideIn\x201s\x20forwards"),
          (_0x3c5672["innerHTML"] = _0x155056),
          document["body"]["appendChild"](_0x3c5672));
        const _0x59a3e0 = document["createElement"]("style");
        ((_0x59a3e0["innerHTML"] =
          "@keyframes\x20slideIn{0%{transform:translateX(-100%)}100%{transform:translateX(0)}}@keyframes\x20slideOut{0%{transform:translateX(0)}100%{transform:translateX(100%)}}"),
          document["head"]["appendChild"](_0x59a3e0),
          setTimeout(() => {
            ((_0x3c5672["style"]["animation"] = "slideOut\x201s\x20forwards"),
              setTimeout(() => {
                document["body"]["removeChild"](_0x3c5672);
              }, 0x3e8));
          }, _0x13bf39 || 0xbb8));
      };
      function fetchFromBackground(_0x5002ee, _0x2d14a1 = {}) {
        return new Promise((_0x5cb758, _0x480a84) => {
          chrome["runtime"]["sendMessage"](
            { action: "fetch", url: _0x5002ee, options: _0x2d14a1 },
            (_0x5b0aea) => {
              chrome["runtime"]["lastError"]
                ? _0x480a84(chrome["runtime"]["lastError"])
                : _0x5b0aea && _0x5b0aea["error"]
                  ? _0x480a84(_0x5b0aea["error"])
                  : _0x5cb758(_0x5b0aea);
            },
          );
        });
      }
    })());
  function _0x41a8e1() {
    return null !== document["querySelector"](".task-answers");
  }
  function _0x482884() {
    return (
      0x9 === document["querySelectorAll"](".task-image\x20.image")?.["length"]
    );
  }
  function _0x163f29() {
    return null !== document["querySelector"](".bounding-box-example");
  }
})();
