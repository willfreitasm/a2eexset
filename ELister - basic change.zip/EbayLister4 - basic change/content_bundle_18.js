function _0x519172() {
  return new Promise((_0x1b9ad0) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x1b9ad0();
      });
    });
  });
}
function _0x539d8a() {
  return new Promise((_0x33ab15) => {
    requestIdleCallback(() => {
      _0x33ab15();
    });
  });
}
function _0xc21d84(_0x304b0c = 0x3e8) {
  return new Promise((_0x1d7a62, _0x4f37f1) => {
    let _0x5011df,
      _0x2122d5 = Date["now"](),
      _0x41e350 = !0x1;
    function _0x2d81cb() {
      if (Date["now"]() - _0x2122d5 > _0x304b0c)
        (_0x41e350 && _0x5011df["disconnect"](), _0x1d7a62());
      else setTimeout(_0x2d81cb, _0x304b0c);
    }
    const _0x40f48f = () => {
        _0x2122d5 = Date["now"]();
      },
      _0x4c3e1b = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x5011df = new MutationObserver(_0x40f48f)),
        _0x5011df["observe"](document["body"], _0x4c3e1b),
        (_0x41e350 = !0x0),
        setTimeout(_0x2d81cb, _0x304b0c));
    else
      window["onload"] = () => {
        ((_0x5011df = new MutationObserver(_0x40f48f)),
          _0x5011df["observe"](document["body"], _0x4c3e1b),
          (_0x41e350 = !0x0),
          setTimeout(_0x2d81cb, _0x304b0c));
      };
  });
}
async function _0x54fec1() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0xc21d84(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
var _0x10482e = !0x1;
function _0x6d2f13(_0x27a483, _0x57cd49 = "image/x-icon") {
  var _0x3a53d2 = "shortcut\x20icon";
  "image/gif" == _0x57cd49 || "image/png" == _0x57cd49
    ? (_0x3a53d2 = "icon")
    : (_0x10482e = !0x1);
  var _0x4ebe44 =
    document["querySelector"]("link[rel*=\x27icon\x27]") ||
    document["createElement"]("link");
  ((_0x4ebe44["type"] = _0x57cd49),
    (_0x4ebe44["rel"] = _0x3a53d2),
    (_0x4ebe44["href"] = _0x27a483),
    document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x4ebe44));
}
function _0x130b5b(_0x4b987e, _0x3ed04e = "image/x-icon") {
  let _0x57f0a6 =
      "image/gif" == _0x3ed04e || "image/png" == _0x3ed04e
        ? "icon"
        : "shortcut\x20icon",
    _0x907742 = document["querySelectorAll"]("link[rel*=\x27icon\x27]");
  if (0x0 === _0x907742["length"]) {
    let _0x266bab = document["createElement"]("link");
    ((_0x266bab["type"] = _0x3ed04e),
      (_0x266bab["rel"] = _0x57f0a6),
      (_0x266bab["href"] = _0x4b987e),
      document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x266bab));
    return;
  }
  for (let _0x1b91e9 of _0x907742) {
    ((_0x1b91e9["type"] = _0x3ed04e),
      (_0x1b91e9["rel"] = _0x57f0a6),
      (_0x1b91e9["href"] = _0x4b987e));
  }
}
function _0xbd1539() {
  _0x10482e = !0x0;
  var _0x227072 = 0x0,
    _0x418f7d = chrome["runtime"]["getURL"](
      "Favicons/Gifs/Gear/frame_" + _0x227072 + "_delay-0.04s.gif",
    ),
    _0x5f2268 = setInterval(function () {
      if (_0x10482e && _0x227072 < 0x1c)
        (_0x6d2f13(_0x418f7d, "image/gif"),
          _0x227072++,
          (_0x418f7d = chrome["runtime"]["getURL"](
            "Favicons/Gifs/Gear/frame_" + _0x227072 + "_delay-0.04s.gif",
          )));
      else {
        if (_0x10482e && _0x227072 >= 0x1c)
          ((_0x227072 = 0x0),
            (_0x418f7d = chrome["runtime"]["getURL"](
              "Favicons/Gifs/Gear/frame_" + _0x227072 + "_delay-0.04s.gif",
            )));
        else clearInterval(_0x5f2268);
      }
    }, 0x28);
}
function _0x3aa694() {
  _0x10482e = !0x0;
  var _0x5d99b1 = 0x0,
    _0x1314c9 = chrome["runtime"]["getURL"](
      "Favicons/Task_Bar/" + _0x5d99b1 + ".png",
    ),
    _0x505476 = setInterval(function () {
      if (_0x10482e && _0x5d99b1 < 0x1b)
        (_0x6d2f13(_0x1314c9, "image/gif"),
          _0x5d99b1++,
          (_0x1314c9 = chrome["runtime"]["getURL"](
            "Favicons/Task_Bar/" + _0x5d99b1 + ".png",
          )));
      else {
        if (_0x10482e && _0x5d99b1 >= 0x1b)
          ((_0x5d99b1 = 0x0),
            (_0x1314c9 = chrome["runtime"]["getURL"](
              "Favicons/Task_Bar/" + _0x5d99b1 + ".png",
            )));
        else clearInterval(_0x505476);
      }
    }, 0x28);
}
function _0x18be20() {
  _0x10482e = !0x0;
  var _0x4ee0d1 = 0x0,
    _0x393c74 = [0x2, 0x8, 0xe, 0x14, 0x1a, 0x1b],
    _0x51d666 = 0x28,
    _0x2fb122 = "0.04s",
    _0x57ea98 = setInterval(function () {
      if (_0x10482e) {
        _0x2fb122 = _0x393c74["includes"](_0x4ee0d1) ? "0.05s" : "0.04s";
        var _0x3a86ab =
          "frame_" +
          _0x4ee0d1["toString"]()["padStart"](0x2, "0") +
          "_delay-" +
          _0x2fb122 +
          ".gif";
        (_0x6d2f13(
          chrome["runtime"]["getURL"]("Favicons/Sniper/" + _0x3a86ab),
          "image/gif",
        ),
          ++_0x4ee0d1 >= 0x1b && (_0x4ee0d1 = 0x0),
          (_0x51d666 = "0.05s" === _0x2fb122 ? 0x32 : 0x28));
      } else clearInterval(_0x57ea98);
    }, _0x51d666);
}
async function _0x38d498() {
  ((_0x10482e = !0x1),
    await new Promise((_0x2ae780) => setTimeout(_0x2ae780, 0x7d0)));
}
async function _0x8c4ef4() {
  return await new Promise(function (_0x2196c5, _0x269933) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x343dae) {
        (console["log"]("result:\x20", _0x343dae["membership"]),
          _0x2196c5(_0x343dae["membership"]));
      },
    );
  });
}
async function _0x2e1f0c() {
  return await new Promise(function (_0x16a603, _0x13cfa0) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x305533) {
        (console["log"]("result:\x20", _0x305533["creditsAvailable"]),
          _0x16a603(_0x305533["creditsAvailable"]));
      },
    );
  });
}
async function _0x457252(_0x12b2f8) {
  if ("ultimate" != (await _0x8c4ef4()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x2e1f0c()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
function _0x100af3(
  _0x2fb96b = null,
  _0x33bd6e = null,
  _0x561156 = null,
  _0x45fb05 = null,
) {
  var _0x3e9a80 = document["createElement"]("a");
  (_0x3e9a80["setAttribute"]("class", "a-link-text"),
    _0x3e9a80["classList"]["add"]("icon"),
    _0x3e9a80["classList"]["add"]("amazonSearchLink"),
    _0x3e9a80["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x2445bb = document["createElement"]("img");
  return (
    _0x2445bb["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x2445bb["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3e9a80["appendChild"](_0x2445bb),
    _0x3e9a80["addEventListener"]("click", async function (_0x431a00) {
      (_0x431a00["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x2fb96b) {
        var _0x51e765 = _0x4a0993(_0x431a00);
        if (!_0x51e765) return;
        var _0x2a0da0 = extractItemData(_0x51e765);
        ((_0x2fb96b = _0x2a0da0["title"])["endsWith"]("...") &&
          (_0x2fb96b = _0x2fb96b["substring"](
            0x0,
            _0x2fb96b["lastIndexOf"]("\x20"),
          )),
          _0x2fb96b["length"] > 0x4b &&
            (_0x2fb96b = _0x2fb96b["substring"](
              0x0,
              _0x2fb96b["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x1fcbb5 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x1fcbb5),
        _0x1fcbb5 || (_0x1fcbb5 = "reviews"),
        console["log"]("amazonSortType", _0x1fcbb5),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x4c5a97 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x2fb96b["length"] > 0x50; )
        _0x2fb96b = _0x2fb96b["substring"](
          0x0,
          _0x2fb96b["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x203b9f } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x45f1f6 = _0x2fb96b;
      "keywords" == _0x203b9f && (_0x45f1f6 = await _0x549494(_0x2fb96b));
      try {
        _0x2a0da0 = extractItemData(_0x51e765);
      } catch (_0x4ce6b6) {
        console["log"]("error", _0x4ce6b6);
      }
      (_0x2a0da0 ||
        (_0x2a0da0 = {
          title: _0x2fb96b,
          price: _0x33bd6e,
          itemNumber: _0x561156,
          image: _0x45fb05,
        }),
        console["log"]("itemData", _0x2a0da0),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x45f1f6,
          options: { isTabActive: !0x0, sort: _0x1fcbb5 },
          itemData: _0x2a0da0,
        }));
    }),
    _0x3e9a80
  );
}
function _0x1a6642(_0x15b658) {
  var _0x132b04 = document["createElement"]("a");
  (_0x132b04["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x132b04["setAttribute"]("class", "a-link-text"),
    _0x132b04["classList"]["add"]("icon"),
    _0x132b04["classList"]["add"]("amazonSearchLink"),
    _0x132b04["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x204b94 = document["createElement"]("img");
  return (
    _0x204b94["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x204b94["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x132b04["appendChild"](_0x204b94),
    _0x132b04["addEventListener"]("click", async function (_0x577894) {
      (_0x577894["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x15b658),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x15b658,
        }));
    }),
    _0x132b04
  );
}
function _0x518d49(_0x1d1964) {
  var _0x3592ab = document["createElement"]("a");
  (_0x3592ab["setAttribute"]("id", "amazonLink"),
    _0x3592ab["setAttribute"]("class", "a-link-text"),
    _0x3592ab["classList"]["add"]("icon"),
    _0x3592ab["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x2147d0 = document["createElement"]("img");
  return (
    _0x2147d0["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x2147d0["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3592ab["appendChild"](_0x2147d0),
    _0x3592ab["addEventListener"]("click", async function (_0x5838fc) {
      (_0x5838fc["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0xf8448a } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x3a5246 =
          "https://www.amazon." +
          _0xf8448a +
          "/dp/" +
          _0x1d1964 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x3a5246 });
    }),
    _0x3592ab
  );
}
function _0x2b4405(_0x3a234d) {
  var _0x7fa2b2 = document["createElement"]("a");
  (_0x7fa2b2["setAttribute"]("id", "amazonLink"),
    _0x7fa2b2["setAttribute"]("class", "a-link-text"),
    _0x7fa2b2["classList"]["add"]("icon"),
    _0x7fa2b2["classList"]["add"]("amazonLink"),
    _0x7fa2b2["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x1315c2 = document["createElement"]("img");
  return (
    _0x1315c2["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x1315c2["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x7fa2b2["appendChild"](_0x1315c2),
    _0x7fa2b2["addEventListener"]("click", async function (_0x24311f) {
      (_0x24311f["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x3a234d(_0x24311f);
      } catch (_0xc36884) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0xc36884);
      }
    }),
    _0x7fa2b2
  );
}
function _0x167796(
  _0x52277e = null,
  _0x1dfb00,
  _0x5da8a4 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x52277e, _0x1dfb00);
  var _0x36d137 = document["createElement"]("a");
  (_0x36d137["setAttribute"]("id", "ebayLink"),
    _0x36d137["setAttribute"]("class", "a-link-text"),
    _0x36d137["classList"]["add"]("icon"),
    _0x1dfb00 && _0x1dfb00["soldItems"]
      ? _0x36d137["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x36d137["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x22df22 = document["createElement"]("img");
  return (
    _0x22df22["setAttribute"]("src", chrome["runtime"]["getURL"](_0x5da8a4)),
    _0x22df22["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x36d137["appendChild"](_0x22df22),
    _0x36d137["addEventListener"]("click", async function (_0x500524) {
      (_0x500524["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x52277e) console["log"]("title\x20found", _0x52277e);
      else {
        console["log"]("title\x20not\x20found");
        var _0x1a1e85 = _0x4a0993(_0x500524);
        if (!_0x1a1e85) return;
        var _0x4f819e = extractItemData(_0x1a1e85);
        _0x52277e = _0x4f819e["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x559ad4 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x52277e["length"] > 0x50; )
        _0x52277e = _0x52277e["substring"](
          0x0,
          _0x52277e["lastIndexOf"]("\x20"),
        );
      var _0xe2175a =
        "https://www.ebay." +
        _0x559ad4 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x52277e) +
        "&_odkw=" +
        encodeURIComponent(_0x52277e);
      (_0x1dfb00 && _0x1dfb00["soldItems"] && (_0xe2175a += "&LH_Sold=1"),
        _0x1dfb00 && _0x1dfb00["sortLowToHigh"] && (_0xe2175a += "&_sop=15"),
        _0x1dfb00 && _0x1dfb00["endedRecently"] && (_0xe2175a += "&_sop=13"),
        (_0xe2175a += "&LH_ItemCondition=1000"),
        (_0xe2175a += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0xe2175a,
        }));
    }),
    _0x36d137
  );
}
function _0x54f2b1(_0x168d20 = null) {
  var _0xfa433c = document["createElement"]("a");
  (_0xfa433c["setAttribute"]("id", "googleLink"),
    _0xfa433c["setAttribute"]("class", "a-link-text"),
    _0xfa433c["classList"]["add"]("icon"),
    _0xfa433c["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x4b41d9 = document["createElement"]("img");
  return (
    _0x4b41d9["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x4b41d9["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xfa433c["appendChild"](_0x4b41d9),
    _0xfa433c["addEventListener"]("click", async function (_0x11c939) {
      (_0x11c939["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x168d20) {
        var _0x1a3b03 = _0x4a0993(_0x11c939);
        if (!_0x1a3b03) return;
        var _0x46ecff = extractItemData(_0x1a3b03);
        _0x168d20 = _0x46ecff["image"];
      }
      var { domain: _0x3ffc88 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x21fe22(_0x3ffc88),
        encodeURIComponent(_0x168d20),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x168d20,
        }));
    }),
    _0xfa433c
  );
}
function _0x1ffd95(_0x16216b = null) {
  var _0x4938da = document["createElement"]("a");
  (_0x4938da["setAttribute"]("id", "googleLink"),
    _0x4938da["setAttribute"]("class", "a-link-text"),
    _0x4938da["classList"]["add"]("icon"),
    _0x4938da["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x378d70 = document["createElement"]("img");
  return (
    _0x378d70["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x378d70["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4938da["appendChild"](_0x378d70),
    _0x4938da["addEventListener"]("click", async function (_0xda9def) {
      (_0xda9def["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x16216b) {
        var _0x115a0a = _0x4a0993(_0xda9def);
        if (!_0x115a0a) return;
        var _0x212663 = extractItemData(_0x115a0a);
        _0x16216b = _0x212663["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x16216b,
      });
    }),
    _0x4938da
  );
}
function _0x249b04(_0x4faba5) {
  var _0x249c99 = document["createElement"]("a");
  (_0x249c99["setAttribute"]("id", "lookUpSkuLink"),
    _0x249c99["setAttribute"]("class", "a-link-text"),
    _0x249c99["classList"]["add"]("icon"),
    _0x249c99["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x57c3e6 = document["createElement"]("img");
  return (
    _0x57c3e6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x57c3e6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x249c99["appendChild"](_0x57c3e6),
    _0x249c99["addEventListener"]("click", async function (_0x1ce3ba) {
      (_0x1ce3ba["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x2d1f23 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x23ba8a =
          "https://www.amazon." +
          _0x2d1f23 +
          "/dp/" +
          _0x4faba5 +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x23ba8a,
        options: { active: !0x0 },
      });
    }),
    _0x249c99
  );
}
function _0x1f732e(_0x4e271f, _0x24bc82, _0x26c907) {
  var _0x30c5e1 = document["createElement"]("a");
  (_0x30c5e1["setAttribute"]("id", "copyDataLink"),
    _0x30c5e1["setAttribute"]("class", "a-link-text"),
    _0x30c5e1["classList"]["add"]("icon"),
    _0x30c5e1["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x2a48ac = document["createElement"]("img");
  return (
    _0x2a48ac["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x2a48ac["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x30c5e1["appendChild"](_0x2a48ac),
    _0x30c5e1["addEventListener"]("click", async function (_0x3b5dc7) {
      (_0x3b5dc7["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var _0x4f2d1a = _0x24bc82;
      try {
        var _0x2e9f3c = document["querySelector"]("#mainContent");
        if (_0x2e9f3c) {
          var _0x1a8d5b = _0x2e9f3c["innerText"] || _0x2e9f3c["textContent"];
          var _0x5e2a1c = _0x1a8d5b["match"](
            /(?:Was|Era|Était|War)\s+(?:US\s*)?\$?\s*([\d,]+\.?\d*)/i,
          );
          if (_0x5e2a1c && _0x5e2a1c[0x1]) {
            ((_0x4f2d1a = _0x5e2a1c[0x1]),
              console["log"](
                "Found\x20original\x20price\x20(text\x20match):",
                _0x4f2d1a,
              ));
          } else {
            var _0x3d8f2a = _0x2e9f3c["querySelectorAll"](
              'span[class*="STRIKETHROUGH"],span[class*="strikethrough"],span[class*="SECONDARY"],del,s',
            );
            for (var _0x1c9e4f of _0x3d8f2a) {
              var _0x4a2e1b = (_0x1c9e4f["innerText"] ||
                  _0x1c9e4f["textContent"])["trim"](),
                _0x2f8c3e = _0x4a2e1b["match"](/\$?\s*([\d,]+\.?\d*)/);
              if (
                _0x2f8c3e &&
                _0x2f8c3e[0x1] &&
                parseFloat(_0x2f8c3e[0x1]["replace"](/,/g, "")) >
                  parseFloat((_0x24bc82 + "")["replace"](/[^0-9.]/g, ""))
              ) {
                ((_0x4f2d1a = _0x2f8c3e[0x1]),
                  console["log"](
                    "Found\x20original\x20price\x20(strikethrough):",
                    _0x4f2d1a,
                  ));
                break;
              }
            }
            if (_0x4f2d1a === _0x24bc82) {
              var _0x5a3d2b = _0x1a8d5b["match"](
                /\((\d+)%\s*(?:off|de\s+desconto|remise|Rabatt)\)/i,
              );
              if (_0x5a3d2b) {
                var _0x3e8f1c = parseInt(_0x5a3d2b[0x1]),
                  _0x4d2e3a = parseFloat(
                    (_0x24bc82 + "")["replace"](/[^0-9.]/g, ""),
                  );
                if (!isNaN(_0x4d2e3a) && _0x3e8f1c > 0x0 && _0x3e8f1c < 0x64) {
                  var _0x2c9f1e = _0x4d2e3a / (0x1 - _0x3e8f1c / 0x64);
                  ((_0x4f2d1a = _0x2c9f1e["toFixed"](0x2)),
                    console["log"](
                      "Calculated\x20original\x20price\x20from\x20percentage:",
                      _0x4f2d1a,
                    ));
                }
              }
            }
          }
        }
      } catch (_0x3c8f2e) {
        console["log"]("Error\x20finding\x20original\x20price:", _0x3c8f2e);
      }
      var _0x24bc82_cleaned = _0x4f2d1a;
      isNaN(_0x4f2d1a) &&
        (_0x24bc82_cleaned = _0x4f2d1a["replace"](/[^0-9.]/g, ""));
      var _0x5ac301 = JSON["stringify"]({
          title: _0x4e271f,
          price: _0x24bc82_cleaned,
          itemNumber: _0x26c907,
        }),
        _0x2e8a4f = document["createElement"]("textarea");
      (document["body"]["appendChild"](_0x2e8a4f),
        (_0x2e8a4f["value"] = _0x5ac301),
        _0x2e8a4f["select"](),
        document["execCommand"]("copy"),
        document["body"]["removeChild"](_0x2e8a4f),
        console["log"]("Copied\x20to\x20clipboard:", _0x5ac301));
    }),
    _0x30c5e1
  );
}

function _0x1b676d(_0x466ae5 = null) {
  var _0x30c5e1 = document["createElement"]("a");
  (_0x30c5e1["setAttribute"]("id", "productHunterLink"),
    _0x30c5e1["setAttribute"]("class", "a-link-text"),
    _0x30c5e1["classList"]["add"]("icon"),
    _0x30c5e1["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x2a48ac = document["createElement"]("img");
  return (
    _0x2a48ac["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x2a48ac["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x30c5e1["appendChild"](_0x2a48ac),
    _0x30c5e1["addEventListener"]("click", async function (_0x3b5dc7) {
      (_0x3b5dc7["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x466ae5) {
        var _0x5e816d = _0x4a0993(_0x3b5dc7);
        if (!_0x5e816d) return;
        var _0x461556 = extractItemData(_0x5e816d);
        _0x466ae5 = _0x461556["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x466ae5),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x466ae5,
        }));
    }),
    _0x30c5e1
  );
}
function _0x21fe22(_0x572a65) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x572a65] || "en-US";
}
function _0x3a2d3a(_0x595029 = null) {
  console["log"]("createSearchTerapeakButton", _0x595029);
  var _0x51d2d2 = document["createElement"]("a");
  (_0x51d2d2["setAttribute"]("class", "a-link-text"),
    _0x51d2d2["classList"]["add"]("terapeakLink"),
    _0x51d2d2["classList"]["add"]("icon"),
    _0x51d2d2["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x595029 && _0x51d2d2["setAttribute"]("item_title", _0x595029));
  var _0x2068a3 = document["createElement"]("img");
  return (
    _0x2068a3["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x2068a3["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x51d2d2["appendChild"](_0x2068a3),
    _0x51d2d2["addEventListener"]("click", async function (_0x22f721) {
      (_0x22f721["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x1eed24 = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x1eed24),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x1eed24) {
        var _0x37a36e = _0x4a0993(_0x22f721);
        if (!_0x37a36e) return;
        _0x1eed24 = extractItemData(_0x37a36e)["title"];
      }
      console["log"]("title", _0x1eed24);
      var { convertToKeywords: _0x1134ef } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x1134ef) var _0x1eed24 = await _0x549494(_0x1eed24);
      var { domain: _0xdd3ef1 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x834076 = _0x71e154(_0x1eed24, _0xdd3ef1);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x834076 });
    }),
    _0x51d2d2
  );
}
async function _0x549494(_0x515d31) {
  var _0x4f0902 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x2961f9) => _0x2961f9["json"]());
  ((_0x4f0902["user_input"] = _0x515d31),
    console["log"]("jsonPrompt", _0x4f0902));
  var _0x3310d4 = await new Promise((_0x418ec5, _0xcc6690) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x4f0902,
      },
      function (_0x3b2812) {
        _0x418ec5(_0x3b2812["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x3310d4),
    (_0x3310d4 = JSON["parse"](_0x3310d4))["output"]
  );
}
function _0x71e154(
  _0x1461ec,
  _0x3d8a2f = "ca",
  _0x32ef63 = 0x1e,
  _0x4cd67f = 0x0,
  _0xddc2fe = 0x0,
  _0x436339 = 0x32,
  _0x250232 = "-itemssold",
  _0x5777c5 = "SOLD",
  _0x232d11 = "EBAY-CA",
  _0x51c6ef = "America/Toronto",
  _0xf8b7f7 = "BuyerLocation:::CA",
  _0x4fffb5 = 0x0,
) {
  _0x232d11 = "";
  switch (_0x3d8a2f) {
    case "ca":
    default:
      _0x232d11 = "EBAY-CA";
      break;
    case "com":
      _0x232d11 = "EBAY-US";
      break;
    case "co.uk":
      _0x232d11 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x3d8a2f +
    "/sh/research?" +
    [
      "keywords=" + _0x1461ec,
      "dayRange=" + _0x32ef63,
      "categoryId=" + _0x4cd67f,
      "offset=" + _0xddc2fe,
      "limit=" + _0x436339,
      "sorting=" + _0x250232,
      "tabName=" + _0x5777c5,
      "marketplace=" + _0x232d11,
      "tz=" + encodeURIComponent(_0x51c6ef),
      "minPrice=" + _0x4fffb5,
    ]["join"]("&")
  );
}
async function _0x1dd389(_0x351262) {
  var { domain: _0x2bec4c } = await chrome["storage"]["local"]["get"]("domain"),
    _0x59de76 =
      "https://www.ebay." +
      _0x2bec4c +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x351262 +
      "&store_name=" +
      _0x351262 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x59de76 });
}
async function _0x5c06fb(_0x699f70) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x699f70,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x699f70));
}
async function _0x54aeb3(_0x3420e7) {
  var { response: _0x3de151 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x3420e7,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x3de151), _0x3de151);
}
function _0x315efe(_0x57af59 = null) {
  console["log"]("createOpenSellerItemsButton", _0x57af59);
  var _0x1cf9a1 = document["createElement"]("a");
  (_0x1cf9a1["setAttribute"]("id", "sellerItemsLink"),
    _0x1cf9a1["setAttribute"]("class", "a-link-text"),
    _0x1cf9a1["classList"]["add"]("icon"),
    _0x1cf9a1["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x25a7af = document["createElement"]("img");
  return (
    _0x25a7af["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x25a7af["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1cf9a1["appendChild"](_0x25a7af),
    _0x1cf9a1["addEventListener"]("click", async function (_0x57005f) {
      (_0x57005f["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x57af59),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x57af59));
      var _0x1ffcff;
      if (!_0x57af59) {
        console["log"]("username\x20not\x20found");
        var _0x1d77cc = _0x4a0993(_0x57005f);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x1d77cc,
        );
        if (!_0x1d77cc) return;
        var _0x35c948 = extractItemData(_0x1d77cc);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x35c948,
        ),
          (_0x57af59 = _0x35c948["username"]),
          (_0x1ffcff = _0x35c948["itemNumber"]));
      }
      if (
        _0x57af59["includes"]("\x20") ||
        _0x57af59 !== _0x57af59["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x57af59,
        );
        if (!_0x1ffcff) {
          if (!(_0x1d77cc = _0x4a0993(_0x57005f))) return;
          _0x1ffcff = (_0x35c948 = extractItemData(_0x1d77cc))["itemNumber"];
        }
        _0x5c06fb(_0x1ffcff);
      } else
        ((_0x57af59 = _0x57af59["toLowerCase"]()),
          console["log"]("username", _0x57af59),
          _0x1dd389(_0x57af59));
    }),
    _0x1cf9a1
  );
}
function _0x3ed70f(_0x1c2363) {
  for (
    ;
    _0x1c2363 &&
    !_0x1c2363["classList"]["contains"]("s-item") &&
    !_0x1c2363["classList"]["contains"]("su-card-container");

  )
    _0x1c2363 = _0x1c2363["parentElement"];
  return _0x1c2363;
}
function _0x296e35(_0xd36f8a = null) {
  var _0x5eb127 = document["createElement"]("a");
  (_0x5eb127["setAttribute"]("id", "purchaseHistoryLink"),
    _0x5eb127["setAttribute"]("class", "a-link-text"),
    _0x5eb127["classList"]["add"]("icon"),
    _0x5eb127["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x2b1759 = document["createElement"]("img");
  return (
    _0x2b1759["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x2b1759["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5eb127["appendChild"](_0x2b1759),
    _0x5eb127["addEventListener"]("click", async function (_0x2e61a6) {
      (console["log"]("createCheckPurchaseHistoryButton", _0xd36f8a),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x2e61a6["preventDefault"]());
      var _0x457065 = _0x4a0993(_0x2e61a6);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x457065,
      );
      if (_0x457065) {
        var { selectedFilter: _0x2a1a7d } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x2a1a7d &&
          ((_0x2a1a7d = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x2a1a7d,
          }));
        var _0xa3875 = _0x2a1a7d,
          _0x1cf52a = await _0x5c2d10(_0x457065, _0xa3875, !0x1, !0x0);
        console["log"]("totalSold", _0x1cf52a);
      } else
        try {
          var _0x439001 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0xd36f8a,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x439001),
            (_0x1cf52a = _0x439001["totalSold"]));
        } catch (_0x39c4ec) {
          (console["log"]("error", _0x39c4ec), (_0x1cf52a = -0x3e7));
        }
    }),
    _0x5eb127
  );
}
function _0x4a0993(_0x3f82e9) {
  var _0x4e0f0d = _0x3f82e9["target"];
  return (
    (_0x4e0f0d = _0x3ed70f(_0x4e0f0d)),
    console["log"]("found\x20s-item", _0x4e0f0d),
    _0x4e0f0d
  );
}
function _0x5d4c2e(_0x21f838 = null, _0x603896 = null, _0x261b6e = null) {
  var _0x102e51 = document["createElement"]("a");
  (_0x102e51["setAttribute"]("id", "copyDataLink"),
    _0x102e51["setAttribute"]("class", "a-link-text"),
    _0x102e51["classList"]["add"]("icon"),
    _0x102e51["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x3a6099 = document["createElement"]("img");
  return (
    _0x3a6099["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x3a6099["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x102e51["appendChild"](_0x3a6099),
    _0x102e51["addEventListener"]("click", async function (_0x4d5dff) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x21f838,
        _0x603896,
        _0x261b6e,
      ),
        _0x4d5dff["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x21f838 && _0x603896 && _0x261b6e)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x21f838,
          _0x603896,
          _0x261b6e,
        ),
          isNaN(_0x603896) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x603896),
            (_0x603896 = _0x603896["replace"](/[^0-9.]/g, ""))),
          _0x56f5f9(
            JSON["stringify"]({
              title: _0x21f838,
              price: _0x603896,
              itemNumber: _0x261b6e,
            }),
          ));
      else {
        if (!_0x21f838 || !_0x603896 || !_0x261b6e) {
          var _0x364fed = _0x4a0993(_0x4d5dff);
          if (!_0x364fed) return;
        }
        var _0xc3bc62 = extractItemData(_0x364fed);
        (console["log"]("itemData", _0xc3bc62),
          _0x56f5f9(JSON["stringify"](_0xc3bc62)));
      }
    }),
    _0x102e51
  );
}
function _0x56f5f9(_0x4d58ec) {
  var _0x4be89e = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x4be89e),
    (_0x4be89e["value"] = _0x4d58ec),
    _0x4be89e["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x4be89e));
}
async function _0x3ef964(_0x14060e = null) {
  console["log"]("price", _0x14060e);
  if (_0x14060e) {
    try {
      _0x14060e = _0x14060e["replace"](/[^0-9.]/g, "");
    } catch (_0x432c99) {}
    _0x14060e = parseFloat(_0x14060e);
  }
  var _0x3ca33f = await _0x2db181(_0x14060e),
    _0x38ad7f = document["createElement"]("div");
  return (
    _0x38ad7f["setAttribute"]("id", "breakEvenPrice"),
    _0x38ad7f["setAttribute"]("class", "break-even-price"),
    (_0x38ad7f["textContent"] =
      "Break-even\x20price:\x20$" + _0x3ca33f["toFixed"](0x2)),
    _0x38ad7f
  );
}
async function _0x218bea(_0xd6e57a) {
  var _0x25f849 = !0x1,
    _0x379565 = !0x1,
    { includeCurrencyConversion: _0x379565 } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x25f849 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x587d33 =
    0.1325 * _0xd6e57a +
    0.021 * _0xd6e57a +
    _0xd6e57a * (_0x25f849 ? 0.004 : 0x0) +
    0.4;
  return (_0x379565 && (_0x587d33 += 0.035 * _0xd6e57a), _0xd6e57a - _0x587d33);
}
async function _0x2db181(_0x4d742a) {
  var { isInternational: _0x5355fc } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x3c1492 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x5355fc || (_0x5355fc = !0x1), _0x3c1492 || (_0x3c1492 = !0x0));
  var _0x5bb483 = 13.25;
  _0x3c1492 && (_0x5bb483 = 12.35);
  var _0x2037e2 = _0x4d742a + 0.0725 * _0x4d742a,
    _0xc84c82 =
      _0x2037e2 * (_0x5bb483 / 0x64) +
      0.4 +
      (_0x5355fc ? 0.004 * _0x2037e2 : 0x0),
    _0x13582c =
      _0x4d742a -
      (_0xc84c82 + (_0x5355fc ? 0.05 * _0xc84c82 : 0x0)) -
      (_0x5355fc ? 0.035 * _0x2037e2 : 0x0),
    { isUserTaxExempt: _0x52319d } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x52319d || (_0x52319d = !0x1),
    _0x52319d || (_0x13582c /= 1.0725),
    _0x5355fc && (_0x13582c -= (3.5 * _0x13582c) / 0x64),
    _0x13582c
  );
}
function _0xfd6d35(_0x21df41 = null) {
  console["log"]("createButtonToSaveSeller", _0x21df41);
  var _0x865b31 = document["createElement"]("a");
  (_0x865b31["setAttribute"]("id", "saveSellerLink"),
    _0x865b31["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x865b31["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x12c518 = document["createElement"]("img");
  return (
    _0x12c518["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x12c518["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x865b31["appendChild"](_0x12c518),
    _0x865b31["addEventListener"]("click", async function (_0x479c6b) {
      (_0x479c6b["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x21df41));
      var _0x28be0c;
      if (!_0x21df41) {
        var _0xc5f0e4 = _0x4a0993(_0x479c6b);
        if (!_0xc5f0e4) return;
        var _0x38aa72 = extractItemData(_0xc5f0e4);
        ((_0x21df41 = _0x38aa72["username"]),
          (_0x28be0c = _0x38aa72["itemNumber"]));
      }
      if (
        _0x21df41["includes"]("\x20") ||
        _0x21df41 !== _0x21df41["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x21df41,
        ),
          (_0x21df41 = await _0x54aeb3(_0x28be0c)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x21df41,
          ));
      else _0x21df41 = _0x21df41["toLowerCase"]();
      _0x865b31["setAttribute"]("data-seller-name", _0x21df41);
      var { ebayCompetitors: _0x44de6e } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x285bbd = (_0x44de6e = _0x44de6e || [])["indexOf"](_0x21df41);
      console["log"]("ebayCompetitors", _0x44de6e);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x285bbd
            ? (console["log"]("save-seller\x20clicked\x20username", _0x21df41),
              _0x44de6e["push"](_0x21df41),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x12c518["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x21df41,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x12c518["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x285bbd)
            (console["log"]("remove-seller\x20clicked\x20username", _0x21df41),
              _0x44de6e["splice"](_0x285bbd, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x12c518["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x21df41,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x44de6e });
    }),
    _0x865b31
  );
}
async function _0x491035(_0x1e3eab, _0x33ba1e) {
  var { ebayCompetitors: _0x3b4cfb } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x1ae0f5 = (_0x3b4cfb = _0x3b4cfb || [])["indexOf"](_0x33ba1e),
    _0x109380 = _0x1e3eab["querySelector"]("img");
  -0x1 !== _0x1ae0f5
    ? (_0x1e3eab["classList"]["replace"]("save-seller", "remove-seller"),
      _0x109380["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x1e3eab["classList"]["replace"]("remove-seller", "save-seller"),
      _0x109380["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x3e6eb1(
  _0x501483 = null,
  _0x2c1d9c = null,
  _0x110053 = null,
  _0x2ef846 = !0x0,
  _0x2c5306 = null,
  _0x2ffbdc = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x501483));
  var _0x415eda = _0xfd6d35(_0x2c1d9c),
    _0x28ce87 = _0x3a2d3a(_0x501483),
    _0x265693 = _0x296e35(_0x2c5306),
    _0x116a50 = _0x167796(_0x501483),
    _0x369260 = _0x100af3(_0x501483, _0x2ffbdc, _0x2c5306, _0x110053),
    _0x581646 = _0x167796(
      _0x501483,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x3d88b7 = _0x54f2b1(_0x110053),
    _0x4f30be = _0x1ffd95(_0x2c5306),
    _0x49e0a1 = _0x315efe(_0x2c1d9c),
    _0xeb2bae = document["createElement"]("div");
  _0xeb2bae["setAttribute"]("id", "search-div");
  var _0x54c8e7 = document["createElement"]("label");
  ((_0x54c8e7["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0xeb2bae["appendChild"](_0x54c8e7),
    _0xeb2bae["appendChild"](_0x369260),
    _0xeb2bae["appendChild"](_0x116a50),
    _0xeb2bae["appendChild"](_0x28ce87),
    _0xeb2bae["appendChild"](_0x3d88b7),
    _0xeb2bae["appendChild"](_0x4f30be),
    _0xeb2bae["appendChild"](_0x581646),
    console["log"]("CopyDataButton", _0x501483, _0x2ffbdc, _0x2c5306));
  var _0x7dd4e7 = _0x5d4c2e(_0x501483, _0x2ffbdc, _0x2c5306),
    _0x320d79 = document["createElement"]("div");
  _0x320d79["setAttribute"]("id", "item-buttons-div");
  var _0x2fb34a = document["createElement"]("div");
  (_0x2fb34a["setAttribute"]("id", "main-buttons-div"),
    _0x2fb34a["appendChild"](_0x49e0a1),
    _0x2fb34a["appendChild"](_0x265693),
    _0x2fb34a["appendChild"](_0x7dd4e7),
    _0x2fb34a["appendChild"](_0x415eda),
    _0x320d79["appendChild"](_0x2fb34a));
  if (_0x2ef846) {
    var _0x388cb8 = _0x21a738();
    _0x320d79["appendChild"](_0x388cb8);
  }
  return (_0x320d79["appendChild"](_0xeb2bae), _0x320d79);
}
var _0x262fdb = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x221dff) => {
        (console["log"](
          _0x221dff,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x262fdb, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x421d69) => {
        (console["log"](
          _0x421d69,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x262fdb, "search-type", "keywords"));
      },
    },
  },
];
async function _0x47b41c() {
  var { convertToKeywords: _0x3d9888 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x3d9888 &&
    ((_0x3d9888 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x262fdb,
      "search-type",
      _0x3d9888 ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x262fdb })[
      "init"
    ]());
}
var _0x3f9990 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x116b55) => {
        (console["log"](_0x116b55, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x3f9990, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x41cb21) => {
        (console["log"](_0x41cb21, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x3f9990, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x5cbdfc) => {
        (console["log"](
          _0x5cbdfc,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x3f9990, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x2d95d6) => {
        (console["log"](
          _0x2d95d6,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x3f9990, "search-type", "keywords"));
      },
    },
  },
];
async function _0xb61580() {
  var { amazonSortType: _0x56ccb0 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x5c2d72 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x5c2d72 &&
    ((_0x5c2d72 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x56ccb0 &&
      ((_0x56ccb0 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x3f9990, "sort-type", _0x56ccb0),
    updateContextMenu(_0x3f9990, "search-type", _0x5c2d72),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x3f9990 })[
      "init"
    ]());
}
_0x3f9990 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x263e82) => {
        (console["log"](_0x263e82, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x3f9990, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x567fe6) => {
        (console["log"](_0x567fe6, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x3f9990, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x12bae6 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x361eec) => {
        (console["log"](_0x361eec, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0x12bae6, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x314be8) => {
        (console["log"](_0x314be8, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0x12bae6, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5cf83e) => {
        (console["log"](_0x5cf83e, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0x12bae6, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x27f3bc) => {
        (console["log"](_0x27f3bc, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0x12bae6, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0xf87c86) => {
        (console["log"](_0xf87c86, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0x12bae6, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x508750) => {
        (console["log"](_0x508750, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0x12bae6, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3682cf) => {
        (console["log"](_0x3682cf, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0x12bae6, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x1776b9) => {
        (console["log"](_0x1776b9, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0x12bae6, "filter-type", "90"));
      },
    },
  },
];
async function _0x43fd57() {
  var { selectedFilter: _0x4c4e4e } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x4c4e4e &&
    ((_0x4c4e4e = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0x12bae6, "filter-type", _0x4c4e4e),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0x12bae6 })[
      "init"
    ]());
}
function _0x1f7e66() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x261cff() {
  const _0x2148a7 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x1f3ad2 = 0x0;
  const _0x8f5a54 = () =>
    new Promise((_0x27ad2e, _0x27574b) => {
      const _0x1b0325 = new MutationObserver((_0x231965, _0x4fdc9f) => {
        const _0x11ea1e = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x11ea1e &&
          (console["log"]("Details\x20form\x20found!"),
          _0x4fdc9f["disconnect"](),
          _0x27ad2e(_0x11ea1e));
      });
      (_0x1b0325["observe"](_0x2148a7, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x1b0325["disconnect"]();
          if (_0x1f3ad2 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x1f3ad2 + 0x1) +
                "/3)",
            ),
              _0x1f3ad2++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x27ad2e(_0x8f5a54()), 0x1388));
          else
            _0x27574b(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x19789a = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x19789a) {
    (_0x19789a["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x8f5a54(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x4ee835) {
      console["error"](_0x4ee835["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x4d9bb8(_0xaf89a8 = null, _0x5156a0 = null, _0x3b3bd2 = null) {
  var _0x51f0d6 = document["createElement"]("a");
  (_0x51f0d6["setAttribute"]("id", "copyDataLink"),
    _0x51f0d6["setAttribute"]("class", "a-link-text"),
    _0x51f0d6["classList"]["add"]("icon"),
    _0x51f0d6["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x180cb1 = document["createElement"]("img");
  return (
    _0x180cb1["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x180cb1["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x51f0d6["appendChild"](_0x180cb1),
    _0x51f0d6["addEventListener"]("click", async function (_0x4cf1f2) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0xaf89a8,
        _0x5156a0,
        _0x3b3bd2,
      ),
        _0x4cf1f2["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0xaf89a8 && _0x5156a0 && _0x3b3bd2) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0xaf89a8,
          _0x5156a0,
          _0x3b3bd2,
        );
        isNaN(_0x5156a0) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x5156a0),
          (_0x5156a0 = _0x5156a0["replace"](/[^0-9.]/g, "")));
        var _0x377958 = JSON["stringify"]({
          title: _0xaf89a8,
          price: _0x5156a0,
          itemNumber: _0x3b3bd2,
        });
        (_0x30a6a5(
          (_0x5b586a = await findSimiliarProducts(_0x377958))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x5b586a),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0xaf89a8 || !_0x5156a0 || !_0x3b3bd2) {
          var _0x4c5dca = _0x4a0993(_0x4cf1f2);
          if (!_0x4c5dca) return;
        }
        var _0x3f6309 = extractItemData(_0x4c5dca);
        (console["log"]("itemData", _0x3f6309),
          (_0x377958 = JSON["stringify"](_0x3f6309)));
        var _0x5b586a;
        (_0x30a6a5(
          (_0x5b586a = await findSimiliarProducts(_0x377958))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x5b586a),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x51f0d6
  );
}
async function findSimiliarProducts(_0x2680bc) {
  console["log"]("findSimiliarProducts", _0x2680bc);
  var _0x3d780e = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x2680bc,
  });
  return (console["log"]("response", _0x3d780e), _0x3d780e["productLinks"]);
}
function _0x30a6a5(_0x28b43a) {
  const _0x2a8219 = document["getElementById"]("productLinksModalOverlay");
  _0x2a8219 && _0x2a8219["remove"]();
  const _0x2b3feb = document["createElement"]("div");
  ((_0x2b3feb["id"] = "productLinksModalOverlay"),
    _0x2b3feb["classList"]["add"]("product-links-modal-overlay"));
  const _0x522f18 = document["createElement"]("div");
  _0x522f18["classList"]["add"]("product-links-modal");
  const _0x1c20f6 = document["createElement"]("div");
  _0x1c20f6["classList"]["add"]("modal-button-container");
  const _0x2efccc = document["createElement"]("button");
  (_0x2efccc["classList"]["add"]("close-button"),
    (_0x2efccc["innerText"] = "Close"),
    _0x2efccc["addEventListener"]("click", () => {
      _0x2b3feb["remove"]();
    }));
  const _0x5bb8e5 = document["createElement"]("button");
  (_0x5bb8e5["classList"]["add"]("copy-button"),
    (_0x5bb8e5["innerText"] = "Copy"),
    _0x5bb8e5["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x28b43a),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x4b3ef9) {
        console["error"]("Failed\x20to\x20copy:", _0x4b3ef9);
      }
    }));
  const _0x3fc947 = document["createElement"]("h2");
  _0x3fc947["innerText"] = "Similar\x20Product\x20Links";
  const _0x3ea0d2 = document["createElement"]("textarea");
  ((_0x3ea0d2["value"] = _0x28b43a),
    _0x3ea0d2["setAttribute"]("readonly", !0x0),
    (_0x3ea0d2["style"]["width"] = "100%"),
    (_0x3ea0d2["style"]["height"] = "300px"),
    _0x1c20f6["appendChild"](_0x5bb8e5),
    _0x1c20f6["appendChild"](_0x2efccc),
    _0x522f18["appendChild"](_0x1c20f6),
    _0x522f18["appendChild"](_0x3fc947),
    _0x522f18["appendChild"](_0x3ea0d2),
    _0x2b3feb["appendChild"](_0x522f18),
    document["body"]["appendChild"](_0x2b3feb));
}
function _0x290de0(_0x16ed0a) {
  const _0x28c27c = (_0x16ed0a = _0x16ed0a["replace"](/[^0-9.,]/g, ""))[
      "lastIndexOf"
    ](","),
    _0xf66b9f = _0x16ed0a["lastIndexOf"](".");
  return (
    (_0x16ed0a =
      _0x28c27c > _0xf66b9f
        ? (_0x16ed0a = _0x16ed0a["replace"](/\./g, ""))["replace"](",", ".")
        : _0x16ed0a["replace"](/,/g, "")),
    parseFloat(_0x16ed0a)
  );
}
async function _0x5e20ba() {
  const _0x3c93be = await fetch(
    chrome["runtime"]["getURL"](
      "libraries/safety-lib/safety_restricted_words.txt",
    ),
  );
  return (await _0x3c93be["text"]())
    ["split"]("\x0a")
    ["map"]((_0x316bf6) => _0x316bf6["trim"]())
    ["filter"]((_0x4072c4) => "" !== _0x4072c4);
}
function _0x4c6a9a(_0x352202, _0x37656f) {
  const _0x34dec3 = _0x37656f["filter"](
      (_0x23b52e) => _0x23b52e && _0x23b52e["trim"](),
    )["map"]((_0x11f8f6) => {
      const _0x40f740 = _0x11f8f6["replace"](/[.*+?^${}()|[\]\\]/g, "\x5c$&");
      return new RegExp("\x5cb" + _0x40f740 + "\x5cb", "gi");
    }),
    _0x4f08d0 = _0x352202["split"](/(<[^>]+>)/g);
  let _0x1dc704 = !0x1;
  return _0x4f08d0["map"]((_0x283487) => {
    if (/^<\s*(style|script)\b/i["test"](_0x283487))
      return ((_0x1dc704 = !0x0), _0x283487);
    if (/^<\s*\/\s*(style|script)\s*>/i["test"](_0x283487))
      return ((_0x1dc704 = !0x1), _0x283487);
    if (_0x1dc704 || _0x283487["startsWith"]("<")) return _0x283487;
    let _0x564586 = _0x283487;
    for (const _0x42ed7d of _0x34dec3)
      _0x564586 = _0x564586["replace"](_0x42ed7d, "");
    return _0x564586;
  })["join"]("");
}
function _0x8726a5(_0x55dca9, _0x6c00b5) {
  if (!_0x6c00b5) return _0x55dca9;
  return (
    Array["isArray"](_0x6c00b5) || (_0x6c00b5 = [_0x6c00b5]),
    _0x6c00b5["forEach"]((_0x442ea6) => {
      if (_0x442ea6) {
        const _0x858dd4 = _0x442ea6["replace"](/[.*+?^${}()|[\]\\]/g, "\x5c$&"),
          _0x54f0c8 = new RegExp(
            "\x5cb" + _0x858dd4 + "(?=[^A-Za-z])\x5cS*\x5cb",
            "gi",
          );
        _0x55dca9 = _0x55dca9["replace"](_0x54f0c8, "");
      }
    }),
    _0x55dca9
  );
}
async function _0x2ef2c5() {
  var _0x5b1f6b = await fetch(
    chrome["runtime"]["getURL"](
      "libraries/safety-lib/safety_restricted_prefixes.txt",
    ),
  );
  return (await _0x5b1f6b["text"]())
    ["split"]("\x0a")
    ["map"]((_0x4da38d) => _0x4da38d["trim"]())
    ["filter"]((_0x1cb2fb) => "" !== _0x1cb2fb);
}
async function _0x393317(_0x2bd9e2) {
  var filteredText = _0x2bd9e2;
  filteredText = _0x8726a5(filteredText, await _0x2ef2c5());
  var _0x592028 = await _0x5e20ba();
  return await _0x4c6a9a(filteredText, _0x592028);
}
function _0x2d92cf(_0x1fd784, _0x11f6d2) {
  if (!_0x11f6d2) return !0x1;
  return (
    Array["isArray"](_0x11f6d2) || (_0x11f6d2 = [_0x11f6d2]),
    _0x11f6d2["some"]((_0x372213) => {
      if (_0x372213) {
        const _0x49e401 = _0x372213["replace"](/[.*+?^${}()|[\]\\]/g, "\x5c$&"),
          _0x87ea01 = new RegExp("\x5cb" + _0x49e401 + "\x5cb", "i"),
          _0x48d88d = _0x1fd784["match"](_0x87ea01);
        if (_0x48d88d)
          return (
            console["log"](
              "Restricted\x20word\x20detected:\x20\x22" +
                _0x48d88d[0x0] +
                "\x22\x20for\x20word\x20\x22" +
                _0x372213 +
                "\x22\x20and\x20escapedWord\x20\x22" +
                _0x49e401 +
                "\x22",
            ),
            !0x0
          );
      }
      return !0x1;
    })
  );
}
function _0x329086(_0x491706, _0x49dd3b) {
  if (!_0x49dd3b) return !0x1;
  return (
    Array["isArray"](_0x49dd3b) || (_0x49dd3b = [_0x49dd3b]),
    _0x49dd3b["some"]((_0x3e89d8) => {
      if (_0x3e89d8) {
        const _0x5a011f = _0x3e89d8["replace"](/[.*+?^${}()|[\]\\]/g, "\x5c$&"),
          _0x127c8c = new RegExp(
            "\x5cb" + _0x5a011f + "(?=[^A-Za-z])\x5cS*\x5cb",
            "i",
          ),
          _0x201a0a = _0x491706["match"](_0x127c8c);
        if (_0x201a0a)
          return (
            console["log"](
              "Restricted\x20prefix\x20detected:\x20\x22" +
                _0x201a0a[0x0] +
                "\x22",
            ),
            !0x0
          );
      }
      return !0x1;
    })
  );
}
async function _0x52b24f(_0x24493e) {
  const _0xdb8899 = await _0x2ef2c5(),
    _0x4069ec = await _0x5e20ba(),
    _0x2c11cd = _0x329086(_0x24493e, _0xdb8899),
    _0x1eaf11 = _0x2d92cf(_0x24493e, _0x4069ec);
  return _0x2c11cd || _0x1eaf11;
}
console["log"]("ebay/store_search/functions.js\x20loaded");
var _0x787fea = !0x1,
  _0xd71d79 = 0x1f4;
function _0x1daa38() {
  var _0x369680 = document["createElement"]("button");
  return (
    _0x369680["setAttribute"]("class", "btn-extract-all"),
    (_0x369680["id"] = "btn-extract-all"),
    (_0x369680["innerHTML"] = "Extract\x20All\x20Titles"),
    _0x369680["addEventListener"]("click", async function (_0x24b59d) {
      _0x24b59d["preventDefault"]();
      var { run_status_extract_titles: _0x2dce00 } = await chrome["storage"][
        "local"
      ]["get"]("run_status_extract_titles");
      if (null == _0x2dce00 || 0x0 == _0x2dce00)
        ((_0x2dce00 = !0x0),
          _0x369680["classList"]["remove"]("btn-extract-all"),
          _0x369680["classList"]["add"]("btn-stop-extract-all"),
          (_0x369680["innerHTML"] = "Stop\x20Extracting\x20Titles"));
      else
        0x1 == _0x2dce00 &&
          (_0x369680["classList"]["remove"]("btn-stop-extract-all"),
          _0x369680["classList"]["add"]("btn-extract-all"),
          (_0x369680["innerHTML"] = "Extract\x20All\x20Titles"),
          (_0x2dce00 = !0x1));
      (chrome["storage"]["local"]["set"]({
        run_status_extract_titles: _0x2dce00,
      }),
        console["log"]("run_status_extract_titles", _0x2dce00),
        _0x84de87());
    }),
    _0x369680
  );
}
async function fetchSoldDataBasedOnSelection() {
  try {
    var { selectedFetchMethod: _0xa722e9 } = await chrome["storage"]["local"][
      "get"
    ]("selectedFetchMethod");
    ("none" == _0xa722e9 &&
      console["log"]("No\x20fetch\x20method\x20selected."),
      "sequential" == _0xa722e9 &&
        (console["log"]("Fetching\x20data\x20sequentially."),
        await fetchSoldDataSequentially()),
      "concurrent" == _0xa722e9 &&
        (console["log"]("Fetching\x20data\x20concurrently."),
        await fetchSoldDataConcurrently()),
      "sequential-purchase-history" == _0xa722e9 &&
        (console["log"](
          "Fetching\x20data\x20sequentially\x20via\x20purchase\x20history.",
        ),
        await fetchSoldDataSequentiallyViaPurchaseHistory()),
      "concurrent-purchase-history" == _0xa722e9 &&
        (console["log"](
          "Fetching\x20data\x20concurrently\x20via\x20purchase\x20history.",
        ),
        await fetchSoldDataConcurrentlyViaPurchaseHistory()));
  } catch (_0x53f82f) {
    console["error"](
      "An\x20error\x20occurred\x20while\x20fetching\x20sold\x20data:\x20",
      _0x53f82f,
    );
  }
}
function _0x562eff() {
  var _0x51bacc = document["createElement"]("button");
  return (
    _0x51bacc["setAttribute"]("class", "btn-clear-all-titles"),
    (_0x51bacc["innerHTML"] = "Clear\x20Titles"),
    chrome["storage"]["local"]["get"](
      "savedEbaySearchItems",
      function (_0x102f40) {
        _0x51bacc["innerHTML"] =
          "Clear\x20Titles\x20(" +
          _0x102f40["savedEbaySearchItems"]["length"] +
          ")";
      },
    ),
    _0x51bacc["addEventListener"]("click", function (_0x20c6f7) {
      (chrome["storage"]["local"]["set"]({ savedEbaySearchItems: [] }),
        (_0x51bacc["innerHTML"] = "Titles\x20Cleared\x20✔️"),
        setTimeout(function () {
          _0x51bacc["innerHTML"] = "Clear\x20Titles";
        }, 0xbb8));
    }),
    _0x51bacc
  );
}
async function _0x84de87() {
  console["log"]("extractAllTitles()");
  var _0x42f71d = !0x0;
  (console["log"]("run_status_extract_titles", _0x42f71d),
    (document["title"] = "🔥\x20Extracting\x20Titles\x20🔥"));
  try {
    await fetchSoldDataBasedOnSelection();
  } catch (_0x295426) {
    console["log"]("error", _0x295426);
  }
  try {
    _0x1ad230();
  } catch (_0x4c3fc4) {
    console["log"]("error", _0x4c3fc4);
  }
  var _0x2bd17e = getItemsData();
  console["log"]("ebaySearchItems", _0x2bd17e);
  var { savedEbaySearchItems: _0x313a84 } = await chrome["storage"]["local"][
    "get"
  ]("savedEbaySearchItems");
  (null == _0x313a84 && (_0x313a84 = []),
    (_0x313a84 = (_0x313a84 = _0x313a84["concat"](_0x2bd17e))["filter"](
      (_0x33ff55, _0x379fa5, _0x1a8fde) =>
        _0x1a8fde["findIndex"](
          (_0x347397) => _0x347397["title"] === _0x33ff55["title"],
        ) === _0x379fa5,
    )),
    chrome["storage"]["local"]["set"]({ savedEbaySearchItems: _0x313a84 }));
  var _0x4c38ec = await _0x3ba2e8();
  await new Promise((_0x1afd6d) => setTimeout(_0x1afd6d, 0xbb8));
  var { run_status_extract_titles: _0x42f71d } = await chrome["storage"][
    "local"
  ]["get"]("run_status_extract_titles");
  console["log"]("doesNextPageExist", _0x4c38ec);
  var { scrapeAllPages: _0x460b60 } =
    await chrome["storage"]["local"]["get"]("scrapeAllPages");
  if (0x1 == _0x4c38ec && 0x1 == _0x42f71d && 0x1 == _0x460b60)
    (console["log"]("doesNextPageExist\x20==\x20true"),
      document["getElementsByClassName"]("pagination__next")[0x0]["click"]());
  else {
    if (0x0 == _0x4c38ec || 0x0 == _0x460b60) {
      console["log"]("doesNextPageExist\x20==\x20false");
      var _0x297222 = document["getElementById"]("btn-extract-all");
      (_0x297222["classList"]["remove"]("btn-stop-extract-all"),
        _0x297222["classList"]["add"]("btn-extract-all"),
        (_0x297222["innerHTML"] = "Complete!"),
        (document["getElementsByClassName"]("btn-clear-all-titles")[0x0][
          "innerHTML"
        ] = "Clear\x20Titles\x20(" + _0x313a84["length"] + ")"),
        (document["title"] = "Completed\x20Extraction!\x20✔️"),
        (_0x42f71d = !0x1),
        chrome["storage"]["local"]["set"]({
          run_status_extract_titles: _0x42f71d,
        }),
        await new Promise((_0x933396) => setTimeout(_0x933396, 0xbb8)),
        (_0x297222["innerHTML"] = "Extract\x20All\x20Titles"));
    }
  }
}
function filterEbaySearchItemsByDate(_0x44cf2e, _0x234dd5) {
  if ("default" == _0x234dd5) return _0x44cf2e;
  var _0x5784cc = new Date(),
    _0x12f1ef = new Date();
  return (
    _0x12f1ef["setDate"](_0x12f1ef["getDate"]() - _0x234dd5),
    _0x44cf2e["filter"](function (_0x3a0422) {
      var _0x5ab6a2 = new Date(_0x3a0422["dateSold"]);
      return _0x5ab6a2 >= _0x12f1ef && _0x5ab6a2 <= _0x5784cc;
    })
  );
}
function _0x3ba2e8() {
  return new Promise((_0x16139c, _0x1323b4) => {
    var _0x1ce30f = document["getElementsByClassName"]("pagination__next")[0x0];
    (null == _0x1ce30f && _0x16139c(!0x1),
      _0x16139c("true" != _0x1ce30f["getAttribute"]("aria-disabled")));
  });
}
function _0x3f2681() {
  var _0x92c035 = document["createElement"]("button");
  return (
    _0x92c035["setAttribute"]("class", "btn-show-all-titles"),
    (_0x92c035["innerHTML"] = "Filter\x20Titles"),
    _0x92c035["addEventListener"]("click", function (_0x2f05fd) {
      chrome["runtime"]["sendMessage"]({ type: "openSortEbayItems" });
    }),
    _0x92c035
  );
}
async function _0x51e566() {
  var { savedEbaySearchItems: _0x31f348 } = await chrome["storage"]["local"][
      "get"
    ]("savedEbaySearchItems"),
    _0x39a9e5 = [];
  for (var _0x521058 = 0x0; _0x521058 < _0x31f348["length"]; _0x521058++)
    _0x39a9e5["push"](_0x31f348[_0x521058]["title"]);
  (console["log"](_0x39a9e5),
    _0x239dc4((_0x39a9e5 = _0x39a9e5["join"]("\x0a"))),
    _0x52a29(),
    _0x46f51c(_0x39a9e5));
}
function _0x21d862(_0x5d1c70, _0x5d190e, _0x47475c = "") {
  const _0x5a826d = document["createElement"](_0x5d1c70);
  return (
    (_0x5a826d["id"] = _0x5d190e),
    (_0x5a826d["innerHTML"] = _0x47475c),
    _0x5a826d
  );
}
function _0x1fb9a6(_0x55c46f, _0x24e1ca) {
  _0x24e1ca["forEach"]((_0x689d46) => _0x55c46f["appendChild"](_0x689d46));
}
function _0x239dc4(_0x19dbc0) {
  const _0x27ff57 = _0x21d862("div", "keyword_modal"),
    _0xb10b0 = _0x21d862("div", "keyword_modal_content"),
    _0x25ea78 = _0x21d862("div", "keyword_modal_header"),
    _0x1ce521 = _0x21d862("div", "keyword_modal_body"),
    _0x3a13c5 = _0x21d862("div", "keyword_modal_footer"),
    _0x561c2d = _0x21d862("span", "keyword_modal_close", "&times;");
  _0x25ea78["appendChild"](_0x561c2d);
  const _0x10bb44 = _0x21d862(
    "p",
    "keyword_info",
    "Loaded\x20" + _0x19dbc0["split"]("\x0a")["length"] + "\x20keywords",
  );
  _0x1ce521["appendChild"](_0x10bb44);
  const _0x449202 = _0x21d862("textarea", "keyword_textarea");
  ((_0x449202["value"] = _0x19dbc0),
    (_0x449202["style"]["width"] = "100%"),
    _0x1ce521["appendChild"](_0x449202));
  const _0x578210 = _0x21d862(
    "button",
    "copy_keywords_button",
    "Copy\x20All\x20Keywords",
  );
  ((_0x578210["style"]["display"] = "block"),
    (_0x578210["style"]["margin"] = "auto"),
    _0x3a13c5["appendChild"](_0x578210),
    _0x1fb9a6(_0xb10b0, [_0x25ea78, _0x1ce521, _0x3a13c5]),
    _0x27ff57["appendChild"](_0xb10b0),
    document["body"]["appendChild"](_0x27ff57),
    (_0x27ff57["style"]["display"] = "block"));
}
function _0x52a29() {
  document["getElementById"]("keyword_modal_close")["addEventListener"](
    "click",
    function () {
      document["getElementById"]("keyword_modal")["remove"]();
    },
  );
}
function _0x46f51c(_0x2a49e8) {
  const _0x1bcd11 = document["getElementById"]("copy_keywords_button");
  _0x1bcd11["addEventListener"]("click", function () {
    (navigator["clipboard"]["writeText"](_0x2a49e8),
      (_0x1bcd11["innerHTML"] = "Copied!"));
  });
}
async function _0x14dbb8() {
  var _0x252694 = document["createElement"]("select");
  ((_0x252694["id"] = "filter-dropdown"),
    _0x252694["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "Select\x20Filter", value: "default" },
      { text: "Last\x201\x20Day", value: "1" },
      { text: "Last\x203\x20Days", value: "3" },
      { text: "Last\x207\x20Days", value: "7" },
      { text: "Last\x2014\x20Days", value: "14" },
      { text: "Last\x2021\x20Days", value: "21" },
      { text: "Last\x2030\x20Days", value: "30" },
      { text: "Last\x2060\x20Days", value: "60" },
      { text: "Last\x2090\x20Days", value: "90" },
    ]["forEach"]((_0x317c57) => {
      var _0x4675c5 = document["createElement"]("option");
      ((_0x4675c5["value"] = _0x317c57["value"]),
        (_0x4675c5["innerText"] = _0x317c57["text"]),
        _0x252694["appendChild"](_0x4675c5));
    }));
  let { selectedFilter: _0x3fc950 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  !_0x3fc950 &&
    ((_0x3fc950 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: _0x3fc950 }));
  ((_0x252694["value"] = _0x3fc950),
    _0x252694["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        selectedFilter: this["value"],
      }),
        console["log"]("Filter\x20saved:\x20" + this["value"]));
    }));
  var _0x46dff7 = document["createElement"]("label");
  _0x46dff7["innerText"] =
    "Only\x20Scan\x20Items\x20That\x20Sold\x20within:\x20";
  var _0x771658 = document["createElement"]("div");
  return (
    _0x771658["setAttribute"]("class", "filter-dropdown-div"),
    (_0x771658["id"] = "filter-dropdown-container"),
    _0x771658["appendChild"](_0x46dff7),
    _0x771658["appendChild"](_0x252694),
    _0x771658
  );
}
function _0x3226e1() {
  var _0x319f15 = document["createElement"]("button");
  return (
    _0x319f15["setAttribute"]("class", "btn-terapeak-search"),
    (_0x319f15["innerHTML"] = "Find\x20Total\x20Sold\x20&\x20Competitors"),
    (_0x319f15["style"]["display"] = "none"),
    _0x319f15["addEventListener"]("click", async function (_0x562f39) {
      _0x562f39["preventDefault"]();
      let _0x240cf8 = _0x562f39["target"];
      for (; _0x240cf8 && !_0x240cf8["classList"]["contains"]("s-item"); )
        _0x240cf8 = _0x240cf8["parentElement"];
      _0x240cf8 &&
        (console["log"]("item", _0x240cf8),
        await _0x22324e(_0x240cf8),
        _0x8a04de());
    }),
    _0x319f15
  );
}
async function _0x32b8f3() {
  document["querySelector"](".s-item__wrapper");
}
async function _0x3fcc24(_0x24910a, _0x48b5f8) {
  var _0xe88b6b = _0x24910a["querySelector"](".s-item__itemID")["textContent"];
  ((_0xe88b6b = (_0xe88b6b = _0xe88b6b["split"]("Item:\x20")[0x1])["replace"](
    /\s/g,
    "",
  )),
    console["log"]("itemNumber", _0xe88b6b));
  var _0x4b83d3 = await chrome["runtime"]["sendMessage"]({
    type: "checkPurchaseHistory",
    itemNumber: _0xe88b6b,
    lastXDays: _0x48b5f8,
  });
  return (console["log"]("response", _0x4b83d3), _0x4b83d3["totalSold"]);
}
async function _0x5c2d10(
  _0x71872,
  _0x223c79,
  _0x2e96e5 = !0x0,
  _0x376d76 = !0x1,
) {
  console["log"]("item", _0x71872);
  var _0x5214ef;
  try {
    var _0x5c95e8 = _0x71872["querySelector"](".s-item__itemID");
    (_0x5c95e8 ||
      (_0x5c95e8 = (_0x5c95e8 = (_0x5c95e8 = _0x71872["querySelector"](
        ".su-card-container__attributes__secondary",
      ))["querySelectorAll"](".s-card__attribute-row"))[
        _0x5c95e8["length"] - 0x1
      ]),
      (_0x5214ef = _0x5c95e8["textContent"]));
  } catch (_0x264db6) {
    console["log"]("error", _0x264db6);
    return;
  }
  (console["log"]("itemNumber", _0x5214ef),
    (_0x5214ef = _0x5214ef["split"](":")[0x1]),
    console["log"]("itemNumber", _0x5214ef),
    (_0x5214ef = _0x5214ef["replace"](/\s/g, "")));
  var _0x22be3e = getTitleTag(_0x71872);
  console["log"]("soldDateElement", _0x22be3e);
  var _0x4d56dd;
  if (null !== _0x22be3e)
    ((_0x4d56dd = _0x22be3e["textContent"]),
      console["log"]("soldDate", _0x4d56dd),
      (_0x4d56dd = (_0x4d56dd = _0x4d56dd["split"]("\x20")
        ["slice"](0x1)
        ["join"]("\x20"))["trim"]()));
  else _0x4d56dd = null;
  (console["log"]("soldDate\x20before\x20parse", _0x4d56dd),
    (_0x4d56dd = parseDateSimple(_0x4d56dd)),
    console["log"]("soldDate\x20after\x20parse", _0x4d56dd));
  var _0x522c24 = new Date(_0x4d56dd);
  console["log"]("dateSold", _0x522c24);
  var _0x1a6401 = (new Date() - _0x522c24) / 0x5265c00;
  console["log"]("daysDifference", _0x1a6401);
  var _0x4f946b = 0x0;
  if (_0x1a6401 > _0x223c79 && !_0x376d76)
    console["log"]("daysDifference\x20>\x20lastXDays");
  else
    try {
      var _0x4f228b = await chrome["runtime"]["sendMessage"]({
        type: "checkPurchaseHistory",
        itemNumber: _0x5214ef,
        lastXDays: _0x223c79,
        closeTabAfterSearch: _0x2e96e5,
      });
      (console["log"]("response", _0x4f228b),
        (_0x4f946b = _0x4f228b["totalSold"]));
    } catch (_0x1a5929) {
      (console["log"]("error", _0x1a5929), (_0x4f946b = -0x3e7));
    }
  var _0x390418 = {
    0x1: _0x4f946b["totalSoldIn1"],
    0x3: _0x4f946b["totalSoldIn3"],
    0x7: _0x4f946b["totalSoldIn7"],
    0xe: _0x4f946b["totalSoldIn14"],
    0x1e: _0x4f946b["totalSoldIn30"],
    0x3c: _0x4f946b["totalSoldIn60"],
    0x5a: _0x4f946b["totalSoldIn90"],
  };
  const _0x348cd6 = [0x1, 0x3, 0x7, 0xe, 0x1e, 0x3c, 0x5a];
  let _0x202c19 = !0x0;
  for (let _0x71df0b of _0x348cd6)
    if (
      void 0x0 !== _0x390418[_0x71df0b] &&
      "undefined" !== _0x390418[_0x71df0b]
    ) {
      _0x202c19 = !0x1;
      break;
    }
  _0x4f946b = document["createElement"]("p");
  if (_0x202c19)
    ((_0x4f946b["innerHTML"] =
      "<strong>Total\x20Sold:</strong>\x20Not\x20Available"),
      _0x71872["appendChild"](_0x4f946b));
  else {
    var _0x28b907 = document["createElement"]("table");
    _0x28b907["className"] = "total-sold-table";
    var _0x4d8ca6 = document["createElement"]("tr");
    ((_0x4d8ca6["innerHTML"] =
      "<th>Last\x20X\x20Days</th><th>Total\x20Sold</th>"),
      _0x28b907["appendChild"](_0x4d8ca6),
      _0x348cd6["forEach"]((_0x442bc7) => {
        var _0x502b48 = document["createElement"]("tr");
        (_0x502b48["setAttribute"]("class", "total-sold-element"),
          _0x502b48["setAttribute"]("data-last-x-days", _0x442bc7),
          _0x502b48["setAttribute"](
            "data-total-sold",
            "undefined" !== _0x390418[_0x442bc7]
              ? _0x390418[_0x442bc7]
              : "Not\x20Available",
          ),
          (_0x502b48["innerHTML"] =
            "<td\x20>" +
            _0x442bc7 +
            "</td><td><b\x20style=\x22color:red;\x22>" +
            ("undefined" !== _0x390418[_0x442bc7]
              ? _0x390418[_0x442bc7]
              : "Not\x20Available") +
            "</b></td>"),
          _0x28b907["appendChild"](_0x502b48));
      }),
      _0x71872["appendChild"](_0x28b907));
  }
  setTimeout(() => {
    try {
      _0x28b907["classList"]["add"]("show-element");
    } catch (_0x38581c) {
      console["log"]("error", _0x38581c);
    }
    try {
      _0x28b907["querySelectorAll"]("tr")["forEach"](function (_0x321969) {
        _0x321969["classList"]["add"]("show-element");
      });
    } catch (_0x5f3aba) {
      console["log"]("error", _0x5f3aba);
    }
    try {
      _0x4f946b["classList"]["add"]("show-element");
    } catch (_0x281469) {
      console["log"]("error", _0x281469);
    }
  }, 0x0);
}
function _0xb2ebd2(_0xbe5fac, _0x476de8) {
  var _0x114d06 = document["createElement"]("div");
  return (
    _0x114d06["setAttribute"]("class", "total-sold-element"),
    _0x114d06["setAttribute"]("data-total-sold", _0xbe5fac),
    _0x114d06["setAttribute"]("data-last-x-days", _0x476de8),
    (_0x114d06["innerHTML"] =
      -0x3e7 == _0xbe5fac
        ? "Total\x20Sold:\x20<b\x20style=\x22color:red;\x22>\x20Error\x20Occurred\x20</b>"
        : "Total\x20Sold:\x20<b\x20style=\x22color:red;\x22>\x20" +
          _0xbe5fac +
          "\x20</b>\x20(Last\x20<b>\x20" +
          _0x476de8 +
          "\x20</b>\x20Days)"),
    _0x114d06
  );
}
async function _0x22324e(_0x3d9c90) {
  var _0x570555 = _0x3d9c90["querySelector"](".s-item__title")["textContent"];
  if (
    "" != _0x570555 &&
    null != _0x570555 &&
    null != _0x570555 &&
    "Shop\x20on\x20eBay" != _0x570555
  ) {
    console["log"]("title:", _0x570555);
    var _0x1ab989 = await _0x5dd535(_0x570555),
      _0x67a8ff = _0x1ab989["totalSold"],
      _0x15fc70 = _0x1ab989["totalCompetitors"],
      _0x28099d = document["createElement"]("div");
    (_0x28099d["setAttribute"]("class", "total-sold-element"),
      _0x28099d["setAttribute"]("data-total-sold", _0x67a8ff),
      (_0x28099d["innerHTML"] = "Total\x20Sold:\x20" + _0x67a8ff),
      _0x3d9c90["appendChild"](_0x28099d));
    var _0x475098 = document["createElement"]("div");
    (_0x475098["setAttribute"]("class", "total-competitors-element"),
      _0x475098["setAttribute"]("data-total-competitors", _0x15fc70),
      (_0x475098["innerHTML"] = "Total\x20Competitors:\x20" + _0x15fc70),
      _0x3d9c90["appendChild"](_0x475098),
      setTimeout(() => {
        (_0x28099d["classList"]["add"]("show-element"),
          _0x475098["classList"]["add"]("show-element"));
      }, 0x0));
  }
}
async function _0x5dd535(_0x49dc2a) {
  if (!0x0 === _0x787fea)
    return (
      _0x12ad9a(),
      (_0xd71d79 = 0x32),
      { totalSold: "Rate\x20Limited", totalCompetitors: "Rate\x20Limited" }
    );
  var _0x4dc1e6 = await chrome["runtime"]["sendMessage"]({
    type: "searchTitleOnTeraPeak",
    title: _0x49dc2a,
  });
  console["log"]("response", _0x4dc1e6);
  try {
    var _0x37b008 = _0x4dc1e6["response"]["soldData"];
    (console["log"]("soldData", _0x37b008), _0x8a04de());
  } catch (_0x30301c) {
    return (
      console["log"]("error", _0x30301c),
      (_0x787fea = !0x0),
      _0x12ad9a(),
      (_0xd71d79 = 0x32),
      { totalSold: "Rate\x20Limited", totalCompetitors: "Rate\x20Limited" }
    );
  }
  return _0x37b008;
}
function _0x12ad9a() {
  if (document["querySelector"](".overlay")) return;
  const _0x4495c2 = document["createElement"]("div");
  _0x4495c2["classList"]["add"]("overlay");
  const _0x5effdb = document["createElement"]("div");
  (_0x5effdb["classList"]["add"]("text"),
    (_0x5effdb["textContent"] =
      "Rate\x20Limit\x20Reached,\x20I\x20know\x20it\x20sucks\x20😭,\x20Try\x20again\x20in\x20a\x20bit!"),
    _0x4495c2["appendChild"](_0x5effdb));
  var _0x3a3267 = document["createElement"]("button");
  (_0x3a3267["setAttribute"]("class", "btn-stop-extract-all"),
    (_0x3a3267["innerHTML"] = "Stop\x20Extracting\x20Titles"),
    _0x3a3267["addEventListener"]("click", function (_0xf4ee24) {
      _0xf4ee24["preventDefault"]();
      var _0x1e193d = document["getElementById"]("btn-extract-all");
      (_0x1e193d["classList"]["remove"]("btn-stop-extract-all"),
        _0x1e193d["classList"]["add"]("btn-extract-all"),
        (_0x1e193d["innerHTML"] = "Extract\x20All\x20Titles"),
        (run_status_extract_titles = !0x1),
        chrome["storage"]["local"]["set"]({
          run_status_extract_titles: run_status_extract_titles,
        }),
        (_0x3a3267["innerHTML"] = "Please\x20Wait..."));
    }),
    _0x4495c2["appendChild"](_0x3a3267),
    document["body"]["appendChild"](_0x4495c2),
    setTimeout(() => {
      _0x4495c2["style"]["display"] = "flex";
    }, 0x0));
}
function _0x8a04de() {
  const _0x10d08e = document["querySelector"](".overlay");
  _0x10d08e &&
    ((_0x10d08e["style"]["animation"] = "fadeOut\x200.5s\x20ease\x20forwards"),
    setTimeout(() => {
      _0x10d08e["remove"]();
    }, 0x1f4));
}
async function _0x734791() {
  var _0x547c69 = document["createElement"]("label");
  _0x547c69["setAttribute"]("class", "filter-label");
  var _0x3cc2b9 = document["createElement"]("span");
  ((_0x3cc2b9["innerHTML"] = "Total\x20Sold\x20Filter:\x20"),
    _0x547c69["appendChild"](_0x3cc2b9));
  var _0x47ee11 = document["createElement"]("input");
  ((_0x47ee11["type"] = "number"),
    (_0x47ee11["id"] = "total-sold-input"),
    (_0x47ee11["min"] = "0"),
    _0x47ee11["setAttribute"]("class", "filter-input"));
  let { totalSoldFilter: _0xf7ba72 } =
    await chrome["storage"]["local"]["get"]("totalSoldFilter");
  return (
    !_0xf7ba72 &&
      ((_0xf7ba72 = 0x0),
      await chrome["storage"]["local"]["set"]({ totalSoldFilter: _0xf7ba72 })),
    (_0x47ee11["value"] = _0xf7ba72),
    _0x47ee11["addEventListener"]("input", async function () {
      this["value"] >= 0x0 &&
        (await chrome["storage"]["local"]["set"]({
          totalSoldFilter: this["value"],
        }),
        console["log"](
          "Total\x20Sold\x20Filter\x20saved:\x20" + this["value"],
        ));
    }),
    _0x547c69["appendChild"](_0x47ee11),
    _0x547c69
  );
}
async function _0x3ad681() {
  var _0x3d95b8 = document["createElement"]("label");
  _0x3d95b8["setAttribute"]("class", "filter-label");
  var _0x4e0d16 = document["createElement"]("span");
  ((_0x4e0d16["innerHTML"] = "Total\x20Competitors\x20Filter:\x20"),
    _0x3d95b8["appendChild"](_0x4e0d16));
  var _0x7f7dd7 = document["createElement"]("input");
  ((_0x7f7dd7["type"] = "number"),
    (_0x7f7dd7["id"] = "total-competitors-input"),
    (_0x7f7dd7["min"] = "0"),
    _0x7f7dd7["setAttribute"]("class", "filter-input"));
  let { totalCompetitorsFilter: _0x2fcac9 } = await chrome["storage"]["local"][
    "get"
  ]("totalCompetitorsFilter");
  return (
    !_0x2fcac9 &&
      ((_0x2fcac9 = 0x0),
      await chrome["storage"]["local"]["set"]({
        totalCompetitorsFilter: _0x2fcac9,
      })),
    (_0x7f7dd7["value"] = _0x2fcac9),
    _0x7f7dd7["addEventListener"]("input", async function () {
      this["value"] >= 0x0 &&
        (await chrome["storage"]["local"]["set"]({
          totalCompetitorsFilter: this["value"],
        }),
        console["log"](
          "Total\x20Competitors\x20Filter\x20saved:\x20" + this["value"],
        ));
    }),
    _0x3d95b8["appendChild"](_0x7f7dd7),
    _0x3d95b8
  );
}
async function fetchSoldDataConcurrently() {
  var { concurrencyLimit: _0x5d9088 } =
      await chrome["storage"]["local"]["get"]("concurrencyLimit"),
    _0xc9245c = _0x5d9088;
  console["log"]("fetchSoldDataConcurrently");
  var _0x297e5b = document["querySelectorAll"](".s-item__wrapper"),
    _0x9ad4f7 = Array["from"](_0x297e5b);
  const _0x9c1bb0 = [];
  for (
    let _0x1aee12 = 0x0;
    _0x1aee12 < Math["min"](_0xc9245c, _0x9ad4f7["length"]);
    _0x1aee12++
  )
    _0x9c1bb0["push"](_0x34427f(_0x9ad4f7));
  await Promise["all"](_0x9c1bb0);
}
async function _0x34427f(_0x25bb77) {
  for (; _0x25bb77["length"] > 0x0; ) {
    const _0x35b2bd = _0x25bb77["pop"]();
    (_0x35b2bd["classList"]["add"]("highlight"),
      await _0x22324e(_0x35b2bd),
      _0x35b2bd["classList"]["remove"]("highlight"));
  }
}
async function fetchSoldDataConcurrentlyViaPurchaseHistory() {
  var { concurrencyLimit: _0x17cb32 } =
      await chrome["storage"]["local"]["get"]("concurrencyLimit"),
    _0x3bca14 = _0x17cb32,
    _0x554108 = selectAllItems(),
    _0x23efb1 = Array["from"](_0x554108),
    { selectedFilter: _0x127ff4 } =
      await chrome["storage"]["local"]["get"]("selectedFilter");
  !_0x127ff4 &&
    ((_0x127ff4 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: _0x127ff4 }));
  var _0x5c5ce0 = _0x127ff4;
  const _0x2a1917 = [];
  console["log"]("CONCURRENCY_LIMIT", _0x3bca14);
  for (
    let _0x534272 = 0x0;
    _0x534272 < Math["min"](_0x3bca14, _0x23efb1["length"]);
    _0x534272++
  )
    _0x2a1917["push"](_0x1e90e2(_0x23efb1, _0x5c5ce0));
  await Promise["all"](_0x2a1917);
}
async function _0x1e90e2(_0x1e1633, _0xd5bf09) {
  for (; _0x1e1633["length"] > 0x0; ) {
    var _0x1c9b62 = _0x1e1633["pop"]();
    _0x1c9b62["classList"]["add"]("highlight");
    try {
      await _0x5c2d10(_0x1c9b62, _0xd5bf09);
    } catch (_0x4aca3d) {
      console["log"]("error", _0x4aca3d);
    }
    _0x1c9b62["classList"]["remove"]("highlight");
  }
}
async function fetchSoldDataSequentially() {
  const _0x12ee06 = document["querySelectorAll"](".s-item__wrapper");
  for (const _0x3be036 of _0x12ee06) {
    (_0x3be036["scrollIntoView"]({ block: "center", inline: "nearest" }),
      _0x3be036["classList"]["add"]("highlight"),
      await _0x22324e(_0x3be036),
      await new Promise((_0x1dae3d) => setTimeout(_0x1dae3d, _0xd71d79)),
      _0x3be036["classList"]["remove"]("highlight"));
  }
  (await new Promise((_0x415eb3) => setTimeout(_0x415eb3, 0x7d0)), _0x8a04de());
}
async function fetchSoldDataSequentiallyViaPurchaseHistory() {
  var _0x7b2921 = document["querySelectorAll"](
    ".s-item__wrapper:not(.highlight)",
  );
  console["log"](
    "fetchSoldDataSequentiallyViaPurchaseHistory\x20items",
    _0x7b2921,
  );
  for (var _0x3f2d6d of _0x7b2921) {
    try {
      _0x3f2d6d["querySelector"](".s-item__itemID")["textContent"];
    } catch (_0x149dc5) {
      console["log"]("itemNumber\x20not\x20found");
      continue;
    }
    (console["log"](
      "fetchSoldDataSequentiallyViaPurchaseHistory\x20item",
      _0x3f2d6d,
    ),
      _0x3f2d6d["scrollIntoView"]({ block: "center", inline: "nearest" }),
      _0x3f2d6d["classList"]["add"]("highlight"));
    var { selectedFilter: _0x52eb1f } =
      await chrome["storage"]["local"]["get"]("selectedFilter");
    !_0x52eb1f &&
      ((_0x52eb1f = "90"),
      await chrome["storage"]["local"]["set"]({ selectedFilter: _0x52eb1f }));
    var _0x1bea3d = _0x52eb1f;
    (await _0x5c2d10(_0x3f2d6d, _0x1bea3d),
      (_0xd71d79 = 0x96),
      await new Promise((_0xe92f1c) => setTimeout(_0xe92f1c, _0xd71d79)),
      _0x3f2d6d["classList"]["remove"]("highlight"));
  }
  (await new Promise((_0x599e90) => setTimeout(_0x599e90, 0x7d0)), _0x8a04de());
}
function _0x78f0df() {
  var fetchSoldDataButton = document["createElement"]("button");
  return (
    fetchSoldDataButton["setAttribute"]("class", "btn-fetch-sold-data"),
    (fetchSoldDataButton["innerHTML"] = "Fetch\x20Sold\x20Data"),
    fetchSoldDataButton["addEventListener"](
      "click",
      async function (_0x156dd9) {
        (_0x156dd9["preventDefault"](), await fetchSoldDataSequentially());
      },
    ),
    fetchSoldDataButton
  );
}
async function _0xffccfc() {
  var _0x8908f5 = document["createElement"]("select");
  (_0x8908f5["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "Off", value: "none" },
      { text: "On", value: "concurrent-purchase-history" },
    ]["forEach"]((_0x3c58b7) => {
      var _0x24f746 = document["createElement"]("option");
      ((_0x24f746["value"] = _0x3c58b7["value"]),
        (_0x24f746["innerText"] = _0x3c58b7["text"]),
        _0x8908f5["appendChild"](_0x24f746));
    }));
  let { selectedFetchMethod: _0x1321df } = await chrome["storage"]["local"][
    "get"
  ]("selectedFetchMethod");
  !_0x1321df &&
    ((_0x1321df = "none"),
    await chrome["storage"]["local"]["set"]({
      selectedFetchMethod: _0x1321df,
    }));
  ((_0x8908f5["value"] = _0x1321df),
    _0x8908f5["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        selectedFetchMethod: this["value"],
      }),
        console["log"]("Fetch\x20Method\x20saved:\x20" + this["value"]),
        "concurrent-purchase-history" == this["value"]
          ? ((document["getElementById"](
              "concurrency-limit-dropdown-container",
            )["style"]["display"] = "block"),
            (document["getElementById"]("filter-dropdown-container")["style"][
              "display"
            ] = "block"))
          : ((document["getElementById"](
              "concurrency-limit-dropdown-container",
            )["style"]["display"] = "none"),
            (document["getElementById"]("filter-dropdown-container")["style"][
              "display"
            ] = "none")));
    }));
  var _0xaf0cc0 = document["createElement"]("label");
  ((_0xaf0cc0["innerText"] = "Get\x20Total\x20Sold\x20History:"),
    _0xaf0cc0["setAttribute"]("for", "terapeak-fetch-mode"));
  var _0x225edd = document["createElement"]("div");
  return (
    _0x225edd["appendChild"](_0xaf0cc0),
    _0x225edd["appendChild"](_0x8908f5),
    _0x225edd
  );
}
async function _0x53d67b() {
  var _0x239bc6 = document["createElement"]("input");
  ((_0x239bc6["type"] = "checkbox"),
    (_0x239bc6["id"] = "scrape-all-pages-checkbox"));
  var { scrapeAllPages: _0x5ff5c } =
    await chrome["storage"]["local"]["get"]("scrapeAllPages");
  !_0x5ff5c &&
    ((_0x5ff5c = !0x1),
    await chrome["storage"]["local"]["set"]({ scrapeAllPages: _0x5ff5c }));
  ((_0x239bc6["checked"] = _0x5ff5c),
    _0x239bc6["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        scrapeAllPages: this["checked"],
      }),
        console["log"](
          "Scrape\x20All\x20Pages\x20saved:\x20" + this["checked"],
        ));
    }));
  var _0x253fb3 = document["createElement"]("label");
  ((_0x253fb3["innerText"] = "Scrape\x20All\x20Pages"),
    _0x253fb3["setAttribute"]("for", "scrape-all-pages-checkbox"));
  var _0x12883a = document["createElement"]("div");
  return (
    _0x12883a["appendChild"](_0x239bc6),
    _0x12883a["appendChild"](_0x253fb3),
    _0x12883a
  );
}
async function _0x5cfa4a() {
  var _0x4966a1 = document["createElement"]("select");
  ((_0x4966a1["id"] = "concurrency-limit-dropdown"),
    _0x4966a1["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "1", value: 0x1 },
      { text: "3", value: 0x3 },
      { text: "5", value: 0x5 },
      { text: "10", value: 0xa },
      { text: "15", value: 0xf },
      { text: "20", value: 0x14 },
      { text: "25", value: 0x19 },
      { text: "30", value: 0x1e },
      { text: "40", value: 0x28 },
      { text: "50", value: 0x32 },
    ]["forEach"]((_0x390755) => {
      var _0x1d90cc = document["createElement"]("option");
      ((_0x1d90cc["value"] = _0x390755["value"]),
        (_0x1d90cc["innerText"] = _0x390755["text"]),
        _0x4966a1["appendChild"](_0x1d90cc));
    }));
  var { concurrencyLimit: _0x3efb24 } =
    await chrome["storage"]["local"]["get"]("concurrencyLimit");
  console["log"]("concurrencyLimit", _0x3efb24);
  !_0x3efb24 &&
    ((_0x3efb24 = 0x5),
    chrome["storage"]["local"]["set"]({ concurrencyLimit: _0x3efb24 }));
  ((_0x4966a1["value"] = _0x3efb24),
    _0x4966a1["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        concurrencyLimit: this["value"],
      }),
        console["log"]("Concurrency\x20Limit\x20saved:\x20" + this["value"]));
    }));
  var _0x1b6db6 = document["createElement"]("label");
  ((_0x1b6db6["innerText"] = "Scanning\x20Speed:\x20"),
    _0x1b6db6["setAttribute"]("for", "concurrency-limit-dropdown"));
  var _0xba4acc = document["createElement"]("div");
  return (
    (_0xba4acc["id"] = "concurrency-limit-dropdown-container"),
    _0xba4acc["appendChild"](_0x1b6db6),
    _0xba4acc["appendChild"](_0x4966a1),
    _0xba4acc
  );
}
function _0x1ad230() {
  var _0x2ce9d1 = document["querySelectorAll"]("li"),
    _0x42a285 = Array["from"](_0x2ce9d1);
  ((_0x42a285 = (_0x42a285 = _0x42a285["filter"]((_0x203b4e) =>
    _0x203b4e["querySelector"](_0x1f7e66()),
  ))["filter"]((_0x12bc13) =>
    _0x12bc13["querySelector"](".total-sold-element"),
  ))["sort"]((_0x198373, _0x16b387) => {
    (console["log"]("a", _0x198373), console["log"]("b", _0x16b387));
    var _0x3df595 = _0x198373["querySelector"](".total-sold-element")[
        "getAttribute"
      ]("data-total-sold"),
      _0x545464 = _0x16b387["querySelector"](".total-sold-element")[
        "getAttribute"
      ]("data-total-sold");
    return "Rate\x20Limited" == _0x3df595 || "Rate\x20Limited" == _0x545464
      ? 0x0
      : _0x545464 - _0x3df595;
  }),
    _0x42a285["reverse"]());
  var _0x2c370b = _0x42a285[0x0]["parentNode"];
  _0x42a285["forEach"]((_0x5da6ed) =>
    _0x2c370b["insertBefore"](
      _0x5da6ed,
      _0x2c370b["firstChild"]["nextSibling"],
    ),
  );
}
function _0x5bbd2c() {
  var _0x679867 = document["createElement"]("button");
  return (
    _0x679867["setAttribute"]("class", "btn-check-all-purchase-history"),
    _0x679867["classList"]["add"]("filter-date-context"),
    (_0x679867["id"] = "btn-check-all-purchase-history"),
    (_0x679867["innerHTML"] = "Check\x20All\x20Purchase\x20History"),
    _0x679867["addEventListener"]("click", async function (_0x51d584) {
      try {
        await fetchSoldDataBasedOnSelection();
      } catch (_0x266d41) {
        console["log"]("error", _0x266d41);
      }
    }),
    _0x679867
  );
}
function _0x3cfc30(
  _0x3835ce = null,
  _0x54a949 = null,
  _0x46b07a = null,
  _0xaf299c = !0x0,
) {
  console["log"]("createEcommerceSearchButtonsPanel", _0x3835ce);
  var _0x55c990 = _0xfd6d35(_0x54a949),
    _0x346f70 = _0x3a2d3a(_0x3835ce),
    _0xc4c5f = _0x296e35(),
    _0x50b301 = _0x167796(_0x3835ce),
    _0x5e3b5d = _0x100af3(_0x3835ce),
    _0x11eb2a = _0x167796(
      _0x3835ce,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x17f0ec = _0x54f2b1(_0x46b07a),
    _0x3dc8b8 = _0x315efe(_0x54a949),
    _0x1d913b = document["createElement"]("div");
  _0x1d913b["setAttribute"]("id", "search-div");
  var _0x1609db = document["createElement"]("label");
  ((_0x1609db["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x1d913b["appendChild"](_0x1609db),
    _0x1d913b["appendChild"](_0x5e3b5d),
    _0x1d913b["appendChild"](_0x50b301),
    _0x1d913b["appendChild"](_0x346f70),
    _0x1d913b["appendChild"](_0x17f0ec),
    _0x1d913b["appendChild"](_0x11eb2a));
  var _0x3dcddb = _0x5d4c2e(),
    _0x1c3b10 = _0x21a738(),
    _0xc9ca0a = document["createElement"]("div");
  _0xc9ca0a["setAttribute"]("id", "item-buttons-div");
  var _0x39b264 = document["createElement"]("div");
  return (
    _0x39b264["setAttribute"]("id", "main-buttons-div"),
    _0x39b264["appendChild"](_0x3dc8b8),
    _0x39b264["appendChild"](_0xc4c5f),
    _0x39b264["appendChild"](_0x3dcddb),
    _0x39b264["appendChild"](_0x55c990),
    _0xc9ca0a["appendChild"](_0x39b264),
    _0xaf299c && _0xc9ca0a["appendChild"](_0x1c3b10),
    _0xc9ca0a["appendChild"](_0x1d913b),
    _0xc9ca0a
  );
}
console["log"]("functions.js\x20loaded");
var _0xdca837 = ["Condition"],
  _0x4be448;
function _0x144b5e() {
  if ((_0x11a6ef = _0x23226b())) return _0x11a6ef;
  if (
    (_0x20db69 = document["querySelector"](
      ".ux-seller-section__item--seller\x20span",
    ))
  )
    return _0x20db69["innerText"]["trim"]();
  if ((_0x20db69 = document["querySelector"](".vim.x-sellercard-atf\x20a"))) {
    if (
      (_0x344a2c = _0x20db69["href"]["match"](/ssn=([^&]+)/)) &&
      _0x344a2c[0x1]
    )
      return (
        console["log"]("Seller\x20Name:", _0x344a2c[0x1]),
        _0x344a2c[0x1]
      );
    if (
      (_0x20db69 = document["querySelector"](
        ".x-sellercard-atf__info__about-seller",
      ))
    ) {
      var _0x39800c = _0x20db69["getAttribute"]("title");
      if (_0x39800c)
        return (console["log"]("Seller\x20Name:", _0x39800c), _0x39800c);
    }
  }
  try {
    if (
      (_0x344a2c = (_0x20db69 = document["querySelectorAll"](
        "[data-testid=\x27x-sellercard-atf__data-item\x27]",
      )[0x2]["querySelector"]("a"))["href"]["match"](/requested=([^&]+)/)) &&
      _0x344a2c[0x1]
    )
      return (
        console["log"]("Seller\x20Name:", _0x344a2c[0x1]),
        _0x344a2c[0x1]
      );
  } catch (_0x3b9707) {
    console["error"]("Seller\x20Name\x20not\x20found");
  }
  var _0x20db69 = document["querySelector"](
    ".x-sellercard-atf__data-item-wrapper",
  )
    ["querySelectorAll"]("li")[0x1]
    ?.["querySelector"]("a");
  if (_0x20db69) {
    var _0x344a2c;
    if (
      (_0x344a2c = _0x20db69["href"]["match"](/ssn=([^&]+)/)) &&
      _0x344a2c[0x1]
    )
      return (
        console["log"]("Seller\x20Name:", _0x344a2c[0x1]),
        _0x344a2c[0x1]
      );
  }
  if (
    (_0x20db69 = document["querySelector"](
      ".x-sellercard-atf__info__about-seller\x20.ux-textspans",
    ))
  ) {
    var _0x11a6ef;
    return _0x20db69["innerText"]["trim"]();
  }
  return _0x11a6ef;
}
function _0x23226b() {
  var _0x5b9604 = document["querySelectorAll"]("span"),
    _0x2f7a5d = Array["from"](_0x5b9604)["find"]((_0x351779) =>
      _0x351779["innerText"]["includes"]("Seller\x27s\x20other\x20items"),
    );
  if (_0x2f7a5d) {
    var _0x4b4325 = _0x2f7a5d["parentElement"];
    if (_0x4b4325) {
      var _0x2b65db = _0x4b4325["href"];
      return new URL(_0x2b65db)["searchParams"]["get"]("_ssn") || null;
    }
    return null;
  }
  return null;
}
function _0x14a55b() {
  let _0x36cf54 = document["createElement"]("button");
  return (
    (_0x36cf54["className"] = "generate-search-button"),
    (_0x36cf54["textContent"] = "Search\x20Zikanalytics"),
    _0x36cf54["addEventListener"]("click", _0x3c4d5b),
    _0x36cf54
  );
}
async function _0x3c4d5b() {
  var _0x22cb24 = _0x144b5e();
  (await navigator["clipboard"]["writeText"](_0x22cb24),
    (window["location"]["href"] =
      "https://www.zikanalytics.com/SearchCompetitor/Index"));
}
function _0x5b7e91() {
  return document["querySelector"](
    "#mainContent\x20[class*=\x27item-title\x27]\x20span",
  )["innerText"]["trim"]();
}
function _0xb34c4a() {
  var _0x521740 = document["querySelector"](
    "#mainContent\x20[class*=\x27price-primary\x27]\x20span",
  )["innerText"]["trim"]();
  return _0x290de0(_0x521740);
}
function _0x16f0d8() {
  var _0x294ac3 = document["querySelector"](
      ".ux-image-carousel-container\x20.ux-image-carousel",
    )["querySelectorAll"]("img"),
    _0x5bcea0 = [];
  return (
    _0x294ac3["forEach"]((_0x51a137) => {
      var _0x23ee13 = _0x51a137["src"];
      ("" == _0x23ee13 && (_0x23ee13 = _0x51a137["dataset"]["src"]),
        _0x5bcea0["push"](_0x23ee13));
    }),
    _0x5bcea0
  );
}
function _0x119547() {
  const _0xa96192 = [];
  try {
    const _0xdbff2f = document["querySelectorAll"](
      ".ux-layout-section-evo__col",
    );
    if (!_0xdbff2f || 0x0 === _0xdbff2f["length"]) {
      console["error"]("Item\x20specifics\x20containers\x20not\x20found");
      return;
    }
    _0xdbff2f["forEach"]((_0x1a3b41, _0x318090) => {
      const _0x2975f8 = _0x1a3b41["querySelector"](
          ".ux-labels-values__labels-content",
        ),
        _0x1b5ca8 = _0x1a3b41["querySelector"](
          ".ux-labels-values__values-content",
        );
      if (_0x2975f8 && _0x1b5ca8) {
        var _0x433217 = _0x2975f8["innerText"]["trim"](),
          _0x56abd2 = _0x1b5ca8["innerText"]["trim"]();
        (_0x56abd2["includes"](",") &&
          (_0x56abd2 = _0x56abd2["split"](",")["map"]((_0x2fa13a) =>
            _0x2fa13a["trim"](),
          )),
          _0xa96192["push"]({ label: _0x433217, value: _0x56abd2 }));
      } else
        console["warn"](
          "Label\x20or\x20value\x20element\x20missing\x20in\x20container\x20" +
            (_0x318090 + 0x1) +
            ".\x20Skipping.",
        );
    });
  } catch (_0x1897d1) {
    console["error"](
      "An\x20error\x20occurred\x20while\x20retrieving\x20item\x20specifics:",
      _0x1897d1,
    );
  }
  return _0xa96192;
}
function filterItemSpecifics(_0x34cbab, _0x221611) {
  var filteredItemSpecifics = [];
  return (
    _0x34cbab["forEach"]((_0x329afe) => {
      _0x221611["includes"](_0x329afe["label"]) ||
        filteredItemSpecifics["push"](_0x329afe);
    }),
    filteredItemSpecifics
  );
}
console["log"]("Main\x20content\x20script\x20is\x20running");
function _0x564f8c() {
  return new Promise((_0x5566f7) => {
    window["addEventListener"]("message", (_0x1cea20) => {
      _0x1cea20["data"] &&
        "sendDescription" === _0x1cea20["data"]["action"] &&
        _0x5566f7(_0x1cea20["data"]["descriptionHTML"]);
    });
  });
}
async function _0x5d5d9c() {
  const _0x16e3e3 = document["querySelector"]("#desc_ifr");
  if (_0x16e3e3)
    return (
      _0x16e3e3["contentWindow"]["postMessage"](
        { action: "getDescription" },
        "*",
      ),
      await _0x564f8c()
    );
  return (console["error"]("Iframe\x20not\x20found"), null);
}
function _0x32daf6() {
  var _0x444b16 = document["querySelector"](".x-breadcrumb__wrapper")[
    "querySelectorAll"
  ]("a");
  return _0x444b16[_0x444b16["length"] - 0x1]["innerText"]["trim"]();
}
function _0x9f8c0() {
  var _0x2369be = document["querySelector"](".x-breadcrumb__wrapper");
  if (_0x2369be) {
    var _0x339eb9 = _0x2369be["querySelectorAll"]("a");
    if (0x0 !== _0x339eb9["length"]) {
      for (
        var _0x3ec4b2 = _0x339eb9["length"] - 0x1;
        _0x3ec4b2 >= 0x0;
        _0x3ec4b2--
      ) {
        var _0x24ec84 = _0x339eb9[_0x3ec4b2]["href"]
          ["trim"]()
          ["match"](/\/b\/[^/]+\/(\d+)/);
        if (_0x24ec84 && _0x24ec84[0x1])
          return (
            console["log"]("Category\x20ID:", _0x24ec84[0x1]),
            _0x24ec84[0x1]
          );
      }
      console["error"]("Category\x20ID\x20not\x20found");
    } else console["error"]("Breadcrumb\x20elements\x20not\x20found");
  } else console["error"]("Breadcrumb\x20wrapper\x20not\x20found");
}
function _0x21a738() {
  var _0x12be28 = document["createElement"]("div"),
    _0x3f1679 = document["createElement"]("a");
  ((_0x3f1679["className"] =
    "vim\x20fake-btn\x20fake-btn--primary\x20ux-call-to-action"),
    (_0x3f1679["href"] = "#"),
    _0x3f1679["classList"]["add"]("custom-button"));
  var _0x50c0f3 = document["createElement"]("span");
  return (
    (_0x50c0f3["className"] = "ux-call-to-action__cell"),
    (_0x50c0f3["innerHTML"] =
      "<span\x20class=\x22ux-call-to-action__text\x22>List\x20To\x20Ebay</span>"),
    _0x3f1679["appendChild"](_0x50c0f3),
    _0x12be28["appendChild"](_0x3f1679),
    (_0x12be28["className"] = "button-list\x20vim"),
    _0x3f1679["addEventListener"]("click", async function (_0x15809d) {
      _0x15809d["preventDefault"]();
      if (!_0x3f1679["classList"]["contains"]("disabled")) {
        (console["log"]("buttonList\x20clicked"),
          _0x3f1679["classList"]["add"]("disabled"),
          (_0x50c0f3["querySelector"](".ux-call-to-action__text")["innerText"] =
            "Listing..."));
        var _0x543a90 = await _0x34a848();
        console["log"]("itemData", _0x543a90);
        var _0x4f3e56 = await _0x8c4ef4();
        console["log"]("membership", _0x4f3e56);
        if ("ultimate" == _0x4f3e56) {
          if (0x0 != (await _0x2e1f0c())) {
            chrome["runtime"]["sendMessage"]({
              type: "deductCredits",
              amount: 0,
            });
            var _0x40bea9 = await new Promise((_0x32cc39) => {
              chrome["runtime"]["sendMessage"](
                { type: "listEbayItem", ebayData: _0x543a90 },
                function (_0x3124d6) {
                  _0x32cc39(_0x3124d6["response"]);
                },
              );
            });
            ((_0x4be448 = _0x40bea9),
              (_0x5619cc = _0x2a74fe(_0x40bea9["message"])),
              _0x12be28["appendChild"](_0x5619cc),
              (_0x50c0f3["querySelector"](".ux-call-to-action__text")[
                "innerText"
              ] =
                "itemListed" == _0x40bea9["message"]["type"]
                  ? "Listed!"
                  : "Failed!"));
          } else
            alert(
              "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits.",
            );
        } else {
          var _0x5619cc = _0x2a74fe({
            type: "error",
            message:
              "You\x20are\x20not\x20a\x20member\x20of\x20the\x20sniper\x20list.\x20Please\x20contact\x20support.",
          });
          (_0x12be28["appendChild"](_0x5619cc),
            (_0x50c0f3["querySelector"](".ux-call-to-action__text")[
              "innerText"
            ] = "Failed!"));
        }
      }
    }),
    _0x12be28
  );
}
function _0x2a74fe(_0x70fd57) {
  var _0x10c1c3 = document["createElement"]("div");
  _0x10c1c3["className"] = "info-box";
  var _0x422568 = "itemListed" == _0x70fd57["type"] ? "success" : "error",
    _0x553cc3 = _0x70fd57["ebayItemLink"]
      ? "<a\x20href=\x22" +
        _0x70fd57["ebayItemLink"] +
        "\x22\x20target=\x22_blank\x22>View\x20Item</a>"
      : "Not\x20Available";
  return (
    (_0x10c1c3["innerHTML"] =
      "\x0a\x20\x20\x20\x20<p>Status:\x20" +
      _0x422568 +
      "</p>\x0a\x20\x20\x20\x20<p>Message:\x20" +
      _0x70fd57["message"] +
      "</p>\x0a\x20\x20\x20\x20<p>" +
      _0x553cc3 +
      "</p>"),
    _0x10c1c3
  );
}
async function _0x28f55c(_0x4673d9, _0x1cf7c9, _0x106ade, _0x307aa4) {
  console["log"]("response", _0x4673d9);
  var _0x1c3f11 = _0x4673d9["message"]["message"],
    _0x977f2d = _0x4673d9["message"]["type"];
  _0x106ade["querySelector"](".ux-call-to-action__text")["innerText"] =
    "itemListed" == _0x977f2d ? "Listed!" : "Failed!";
  var _0x1aa0d5 = document["createElement"]("div");
  _0x1aa0d5["className"] = "info-box";
  var _0x13507c = "itemListed" == _0x977f2d ? "success" : "error",
    _0x5f3491 = _0x4673d9["message"]["ebayItemLink"]
      ? "<a\x20href=\x22" +
        _0x4673d9["message"]["ebayItemLink"] +
        "\x22\x20target=\x22_blank\x22>View\x20Item</a>"
      : "Not\x20Available";
  return (
    (_0x1aa0d5["innerHTML"] =
      "<p>Status:\x20" +
      _0x13507c +
      "</p><p>Message:\x20" +
      _0x1c3f11 +
      "</p><p>" +
      _0x5f3491 +
      "</p>"),
    _0x307aa4["appendChild"](_0x1aa0d5),
    _0x4673d9
  );
}
async function _0x34a848() {
  var _0x1ebdb5 = await _0x5d5d9c(),
    filteredItemSpecifics = filterItemSpecifics(_0x119547(), _0xdca837),
    _0x5c3afd = _0x5b7e91(),
    _0x21075c = _0xb34c4a(),
    _0x1cedc1 = _0x32daf6(),
    _0x213c29 = _0x9f8c0(),
    _0x5b76f6 = _0x16f0d8(),
    _0x31cf9 = _0x1e3a1e(),
    { sniper_price_markdown: _0x35aa61 } = await chrome["storage"]["local"][
      "get"
    ](["sniper_price_markdown"]);
  return {
    title: _0x5c3afd,
    price: (_0x21075c -= _0x35aa61),
    description: _0x1ebdb5,
    itemSpecifics: filteredItemSpecifics,
    category: _0x1cedc1,
    categoryId: _0x213c29,
    images: _0x5b76f6,
    listingType: "EbayRelist",
    sku: _0x31cf9,
  };
}
function _0x454396() {
  return window["location"]["href"]["match"](/itm\/([^?]+)/)[0x1];
}
async function _0x43704d() {
  console["log"]("getEcomSniperItemSku");
  var _0x53eb1c = null,
    _0x46cea7 = await _0x5d5d9c();
  console["log"]("description", _0x46cea7);
  if (!_0x46cea7) return null;
  var _0x4aaccb = new DOMParser()["parseFromString"](_0x46cea7, "text/html");
  console["log"]("descriptionElement", _0x4aaccb);
  var _0x5b5a92 = _0x4aaccb["querySelector"](".footerss");
  return (
    _0x5b5a92 && (_0x53eb1c = _0x5b5a92["getAttribute"]("data-label")),
    _0x53eb1c
  );
}
function _0x223cca() {
  var _0x28a162 = null,
    _0x16188f = document["querySelectorAll"](
      ".ux-labels-values__values-content",
    );
  for (var _0x1a62a9 of _0x16188f) {
    var _0x810bb5 = _0x1a62a9["innerText"]["trim"]();
    if (_0x810bb5["endsWith"]("==")) return _0x810bb5;
  }
  var _0x343f34 = document["querySelectorAll"](".ux-layout-section__row"),
    _0x229dea = null;
  return (
    _0x343f34["forEach"]((_0x59dcf3) => {
      (console["log"](_0x59dcf3["innerText"]),
        _0x59dcf3["innerText"]
          ["toLowerCase"]()
          ["includes"]("custom\x20label") && (_0x229dea = _0x59dcf3));
    }),
    _0x229dea &&
      (_0x28a162 = _0x229dea["querySelector"](
        ".ux-labels-values__values-content",
      )["innerText"]["trim"]()),
    _0x28a162
  );
}
async function _0x1e3a1e() {
  var _0x3f032d = null;
  return (_0x3f032d = _0x223cca())
    ? _0x3f032d
    : (_0x3f032d = await _0x43704d()) || null;
}
async function _0x41089b() {
  var _0x412c80 = _0x5b7e91(),
    _0x543509 = await _0x5d5d9c();
  try {
    const _0x435ab3 = new DOMParser()["parseFromString"](
      _0x543509,
      "text/html",
    );
    (_0x435ab3["querySelectorAll"]("style,\x20script")["forEach"]((_0x23cf1d) =>
      _0x23cf1d["remove"](),
    ),
      _0x435ab3["querySelectorAll"]("table")["forEach"]((_0x320a01) => {
        const _0xe3f91e = Array["from"](_0x320a01["querySelectorAll"]("tr"))
            ["map"]((_0x152f22) =>
              Array["from"](_0x152f22["querySelectorAll"]("td,\x20th"))
                ["map"]((_0x129f7e) => _0x129f7e["innerText"]["trim"]())
                ["join"]("\x20"),
            )
            ["join"]("\x0a"),
          _0x271adc = _0x435ab3["createElement"]("div");
        ((_0x271adc["textContent"] = _0xe3f91e),
          _0x320a01["parentNode"]["replaceChild"](_0x271adc, _0x320a01));
      }),
      (_0x543509 = _0x435ab3["body"]["innerText"]));
  } catch (_0x3721cd) {
    console["error"]("Error\x20parsing\x20description", _0x3721cd);
  }
  _0x543509 = (_0x543509 = (_0x543509 = (_0x543509 = (_0x543509 = (_0x543509 =
    _0x543509["replace"](/its original condition/g, ""))["replace"](
    /feel free to reach out/g,
    "",
  ))["replace"](/Herstellergarantie: Not Set/g, ""))["replace"](
    /Garantierte Software-Updates bis: unbekannt/g,
    "",
  ))["replace"](/Zertifizierung: Not Set/g, ""))["replace"](
    /Garantierte Software-Updates bis: Not Set/g,
    "",
  );
  var _0x430b01 = _0x119547();
  ((_0x430b01 = _0x430b01["filter"](
    (_0x18cdb5) => "Condition" != _0x18cdb5["label"],
  )),
    console["log"]("title", _0x412c80),
    console["log"]("description", _0x543509),
    console["log"]("itemSpecifics", _0x430b01));
  var _0x10ce56 = await _0x52b24f(_0x412c80);
  console["log"]("doesTitleContainRestrictedWords", _0x10ce56);
  var _0x5c8c09 = await _0x52b24f(_0x543509);
  console["log"]("doesDescriptionContainRestrictedWords", _0x5c8c09);
  var _0x5868a1 = !0x1;
  for (var _0x58dc99 = 0x0; _0x58dc99 < _0x430b01["length"]; _0x58dc99++) {
    var _0x1f696f = _0x430b01[_0x58dc99];
    if (Array["isArray"](_0x1f696f["value"]))
      for (
        var _0x22775e = 0x0;
        _0x22775e < _0x1f696f["value"]["length"];
        _0x22775e++
      ) {
        var _0x2f3f12 = _0x1f696f["value"][_0x22775e];
        if (await _0x52b24f(_0x2f3f12)) {
          _0x5868a1 = !0x0;
          break;
        }
      }
  }
  return (
    console["log"]("doesItemSpecificsContainRestrictedWords", _0x5868a1),
    _0x10ce56 || _0x5c8c09 || _0x5868a1
  );
}
function _0x163daf(_0x462c5f) {
  var _0x236570 = document["createElement"]("button");
  return (
    (_0x236570["className"] = "generate-search-button"),
    (_0x236570["textContent"] = "Search\x20SKU\x20on\x20Ecom\x20Sniper"),
    _0x236570["addEventListener"]("click", function () {
      console["log"]("Search\x20SKU\x20on\x20Ecom\x20Sniper\x20clicked");
    }),
    _0x236570
  );
}
(console["log"]("content.js\x20loaded"),
  _0x54fec1(),
  chrome["runtime"]["onMessage"]["addListener"](
    (_0xfdaa3, _0x560fd9, _0x64150f) => {
      console["log"](
        _0x560fd9["tab"]
          ? "From\x20a\x20content\x20script:" + _0x560fd9["tab"]["url"]
          : "From\x20the\x20extension\x20request.type\x20ebay.js" +
              _0xfdaa3["type"],
      );
      if ("list-item" === _0xfdaa3["type"])
        return (
          _0x528b13()["then"](function (_0x28f12a) {
            _0x64150f(_0x28f12a);
          }),
          !0x0
        );
      if ("clone-item" === _0xfdaa3["type"])
        return (
          _0x528b13(_0xfdaa3["ebayData"]["customLabel"])["then"](
            function (_0x52d9b8) {
              _0x64150f(_0x52d9b8);
            },
          ),
          !0x0
        );
      if ("open_seller_page_from_item_number" === _0xfdaa3["type"])
        return (
          console["log"]("open_seller_page_from_item_number", _0xfdaa3),
          _0x1dd389((_0x1b684e = _0x144b5e()))["then"](function (_0x579582) {
            _0x64150f(_0x579582);
          }),
          !0x0
        );
      if ("get_seller_name_from_item_page" === _0xfdaa3["type"]) {
        console["log"]("get_seller_name_from_item_page");
        var _0x1b684e = _0x144b5e();
        return (
          console["log"]("sellerName", _0x1b684e),
          _0x64150f(_0x1b684e),
          !0x0
        );
      }
      if ("get_sku_from_ebay_item" === _0xfdaa3["type"])
        return (
          _0x1e3a1e()["then"](function (_0x1d137e) {
            _0x64150f(_0x1d137e);
          }),
          !0x0
        );
      if ("check_if_item_is_restricted" === _0xfdaa3["type"])
        return (
          console["log"]("check_if_item_is_restricted"),
          _0x41089b()["then"](function (_0x506011) {
            _0x64150f(_0x506011);
          }),
          !0x0
        );
      if ("get_description_from_ebay_item" === _0xfdaa3["type"])
        return (
          _0x5d5d9c()["then"](function (_0x4bf1bd) {
            var _0x50abb9 = new DOMParser()["parseFromString"](
              _0x4bf1bd,
              "text/html",
            )["body"]["textContent"];
            _0x50abb9 = (_0x50abb9 = (_0x50abb9 = _0x50abb9["trim"]())[
              "replace"
            ](/\s\s+/g, "\x20"))
              ["trim"]()
              ["replace"](/&amp;/g, "&")
              ["replace"](/&lt;/g, "<")
              ["replace"](/&gt;/g, ">")
              ["replace"](/&quot;/g, "\x22")
              ["replace"](/&#39;/g, "\x27")
              ["replace"](/\t+/g, "\x20")
              ["replace"](/[\r\n]+/g, "\x20")
              ["replace"](/\s\s+/g, "\x20")
              ["replace"](/[.?!]{2,}/g, (_0x3c2170) => _0x3c2170[0x0])
              ["replace"](/<\/?[a-z][^>]*>/gi, "");
            var _0x2e54ba = _0x5b7e91();
            _0x64150f((_0x50abb9 = _0x2e54ba + "\x20" + _0x50abb9));
          }),
          !0x0
        );
      return !0x1;
    },
  ));
async function _0x528b13(_0x210e12) {
  var _0x3f0b96 = await _0x506feb("a.custom-button");
  if (_0x210e12) {
    var _0x138524 = document["createElement"]("div");
    ((_0x138524["id"] = "skuToSave"),
      (_0x138524["style"]["display"] = "none"),
      (_0x138524["innerText"] = _0x210e12),
      _0x3f0b96["appendChild"](_0x138524));
  }
  return (
    _0x6d2f13(
      chrome["runtime"]["getURL"]("Favicons/Completed/right_arrow.png"),
    ),
    _0x3f0b96["click"](),
    await _0x506feb("div.info-box"),
    _0x4be448
  );
}
function _0x506feb(_0x89f28d) {
  return new Promise((_0x34d1df, _0x33b8c2) => {
    const _0x150655 = setInterval(() => {
        const _0x33dd2b = document["querySelector"](_0x89f28d);
        _0x33dd2b && (clearInterval(_0x150655), _0x34d1df(_0x33dd2b));
      }, 0x64),
      _0x561b01 = setTimeout(() => {
        (clearInterval(_0x150655),
          _0x33b8c2(
            new Error(
              "Button\x20not\x20found\x20within\x20the\x20specified\x20time.",
            ),
          ));
      }, 0x1388);
    _0x150655 && clearTimeout(_0x561b01);
  });
}
function _0x4528a5(_0x129ad8) {
  return new Promise((_0x524396) => setTimeout(_0x524396, _0x129ad8));
}
async function _0x3ee9fc() {
  await _0x519172();
  var _0x269e08 = document["querySelector"](".x-buybox-cta");
  (console["log"]("buyboxCta", _0x269e08),
    _0x269e08 ||
      (_0x269e08 = document["querySelector"](
        ".ux-seller-section__item--seller",
      )));
  var _0x30ccf3 = _0x21a738();
  _0x269e08["appendChild"](_0x30ccf3);
  var _0x4e271f = _0x5b7e91(),
    _0x566828 = _0x144b5e(),
    _0x181ab0 = _0x16f0d8(),
    _0x26c907 = _0x454396(),
    _0x24bc82 = _0xb34c4a();
  (console["log"]("title", _0x4e271f),
    console["log"]("sellerName", _0x566828),
    console["log"]("images", _0x181ab0),
    console["log"]("itemNumber", _0x26c907),
    console["log"]("price", _0x24bc82));
  var _0x38eaca = _0x3e6eb1(
    _0x4e271f,
    _0x566828,
    _0x181ab0[0x0],
    !0x1,
    _0x26c907,
    _0x24bc82,
  );
  (_0x269e08["appendChild"](_0x38eaca),
    console["log"]("Getting\x20custom\x20label"));
  var _0x891da0 = await _0x1e3a1e();
  console["log"]("customLabel", _0x891da0);
  var _0x3e7885 = _0x1b676d(_0x4e271f);
  document["querySelector"](
    "#mainContent\x20[class*=\x27item-title\x27]\x20span",
  )["prepend"](_0x3e7885);
  var _0x2c8f4a = _0x1f732e(_0x4e271f, _0x24bc82, _0x26c907);
  document["querySelector"](
    "#mainContent\x20[class*=\x27item-title\x27]\x20span",
  )["prepend"](_0x2c8f4a);
  if (_0x891da0) {
    var _0x4679cc = _0x249b04(atob(_0x891da0));
    document["querySelector"](
      "#mainContent\x20[class*=\x27item-title\x27]\x20span",
    )["prepend"](_0x4679cc);
  }
  try {
    var _0x3dba95 = await _0x41089b();
    console["log"]("isItemRestricted", _0x3dba95);
  } catch (_0x527df9) {
    console["log"]("error", _0x527df9);
  }
}
_0x3ee9fc();

// Bulk Snipe Message Handlers
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.type === "bulk_snipe_check_sku") {
    const skuButton = document.querySelector("#lookUpSkuLink");
    sendResponse({ exists: !!skuButton });
    return true;
  }

  if (request.type === "bulk_snipe_click_copy") {
    const copyButton = document.querySelector("#copyDataLink");
    if (copyButton) {
      copyButton.click();
      console.log("Bulk Snipe: Clicked Copy Data button");
    }
    sendResponse({ success: !!copyButton });
    return true;
  }

  if (request.type === "bulk_snipe_click_lookup") {
    const lookupButton = document.querySelector("#lookUpSkuLink");
    if (lookupButton) {
      // Listen for new tab creation
      chrome.runtime.sendMessage(
        { type: "bulk_snipe_listen_for_amazon_tab" },
        function (response) {
          lookupButton.click();
          console.log("Bulk Snipe: Clicked Look up SKU button");

          // Wait for Amazon tab to be created (increased timeout)
          setTimeout(function () {
            chrome.runtime.sendMessage(
              { type: "bulk_snipe_get_amazon_tab" },
              function (tabResponse) {
                sendResponse({ amazonTabId: tabResponse.tabId });
              },
            );
          }, 3000);
        },
      );
      return true; // Keep channel open for async response
    } else {
      sendResponse({ amazonTabId: null });
    }
  }
});
