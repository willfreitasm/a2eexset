# Upgrade Installation Guide for Obfuscated eBay Lister Extension

**Target Audience**: Claude Code or AI assistants performing upgrades
**Purpose**: Apply all improvements from this version to another obfuscated version with different variable names
**Version**: Based on improvements completed 2025-10-15

---

## ⚠️ Important Prerequisites

Before starting this upgrade process:

1. **Create Complete Backup**: Copy entire extension directory to safe location
2. **Test Environment**: Set up Chrome in developer mode with test eBay/Amazon accounts
3. **Version Control**: Consider using git to track changes (optional but recommended)
4. **Read IMPROVEMENTS.md**: Understand what each improvement does
5. **Obfuscation Notice**: Target codebase will have different variable names - rely on patterns, not names

**Expected Time**: 4-6 hours for full upgrade (depending on code differences)

---

## 📋 Upgrade Overview

**Total Improvements**: 10 (3 major features + 7 improvements/fixes)

**Upgrade Order** (optimized for dependencies):
1. Code Beautification (makes everything easier)
2. Gemini API Title Generator (easy, standalone)
3. eBay Price Extraction Fix (critical, new file)
4. Delivery Time Error Fix (critical bug)
5. Free Shipping Validation Fix (bug fix)
6. Restricted Words List Update (data file)
7. Popup Bulk Snipe Button (UI enhancement)
8. Low Stock Filtering (feature)
9. Stealth Listing Feature (feature)
10. Bulk Snipe Tool (major feature - copy if missing)

---

## Step 0: Preparation & Code Beautification

### 0.1: Beautify Obfuscated Code

**Why First**: Makes all subsequent steps 10x easier

**Files to Beautify**: All `content_bundle_*.js` files

**Method 1: Using Prettier (Recommended)**
```bash
cd /path/to/extension
npx prettier --write "content_bundle_*.js"
npx prettier --write "background.bundle.js"
```

**Method 2: Using js-beautify**
```bash
npm install -g js-beautify
for file in content_bundle_*.js; do
  js-beautify -r "$file" --indent-size 2
done
```

**Validation**:
- Open any `content_bundle_*.js` file
- Verify proper indentation (2 spaces)
- Verify functions are on separate lines
- Test extension loads without errors

**Troubleshooting**:
- If extension breaks: Restore from backup and try with fewer files
- If syntax errors: Check that beautifier didn't corrupt string literals
- Performance OK: Beautification doesn't affect runtime performance

---

## Step 1: Gemini API Title Generator Integration

**Difficulty**: ⭐ Easy
**Impact**: High
**Risk**: Low
**Files**: `content_bundle_3.js` (or wherever title generation occurs)

### 1.1: Find Old API Endpoint

**Search Pattern**:
```javascript
// Look for OLD endpoint URL in any content_bundle file
grep -r "ebaysnipertitlebuilder" content_bundle_*.js
// OR search for pattern:
grep -r "BuildTitle" content_bundle_*.js
```

**Expected Pattern** (variable names will differ):
```javascript
await someFunction(
  "https://ebaysnipertitlebuilder.ngrok.io/api/TitleBuilder/BuildTitle",
  {
    // ... request data
  }
);
```

### 1.2: Replace with New Endpoint

**Find the line** containing the old URL and replace with:
```javascript
await someFunction(
  "https://suggest-optimized-titles-2-djybcnnsgq-uc.a.run.app",
  {
    request_type: "generate_10_titles",
    product_description: variableContainingDescription,
    product_title: variableContainingTitle,
  }
);
```

**Key Points**:
- Keep the same function call structure
- Ensure request format includes: `request_type`, `product_description`, `product_title`
- Response should be array of title strings

### 1.3: Test Title Generation

1. Open extension on Amazon product page
2. Click "Snipe-List" or title generation button
3. Check browser console for API call
4. Verify 10 titles are generated
5. Ensure no errors in console

**Success Criteria**: ✅ Titles generate without errors, quality improved

---

## Step 2: eBay Price Extraction Fix

**Difficulty**: ⭐⭐ Medium
**Impact**: Critical
**Risk**: Low (new file, doesn't modify existing code)
**Files**: Create `fix_ebay_item_price.js`, modify `manifest.json`

### 2.1: Create fix_ebay_item_price.js

**Create new file** in extension root directory with this exact content:

```javascript
// Fix price extraction on eBay item pages
// This script corrects the price value to avoid grabbing the seller feedback score

(function () {
  "use strict";

  console.log("[Price Fix] Script loaded on eBay item page");

  // Function to extract the correct price from eBay item page
  function extractCorrectPrice() {
    // Try multiple selectors to find the actual price
    const priceSelectors = [
      ".x-price-primary span.ux-textspans", // New eBay layout
      ".x-price-primary .ux-textspans--BOLD",
      '[itemprop="price"]',
      ".x-price-approx__price",
      ".vi-VR-cvipPrice",
      "#prcIsum",
      "#mm-saleDscPrc",
      ".notranslate.vi-VR-cvipPrice",
    ];

    for (const selector of priceSelectors) {
      const priceElement = document.querySelector(selector);
      if (priceElement) {
        let priceText = priceElement.textContent || priceElement.innerText;
        console.log(
          "[Price Fix] Found price with selector:",
          selector,
          "Text:",
          priceText,
        );

        // Extract numeric value
        priceText = priceText.replace(/[^0-9.,]/g, "");

        // Handle different decimal/thousand separators
        const lastComma = priceText.lastIndexOf(",");
        const lastDot = priceText.lastIndexOf(".");

        if (lastComma > lastDot) {
          // European format: 1.234,56
          priceText = priceText.replace(/\./g, "").replace(",", ".");
        } else {
          // US format: 1,234.56
          priceText = priceText.replace(/,/g, "");
        }

        const price = parseFloat(priceText);
        if (!isNaN(price) && price > 0) {
          console.log("[Price Fix] Extracted price:", price);
          return price.toFixed(2);
        }
      }
    }

    console.log("[Price Fix] Could not find price, returning null");
    return null;
  }

  // Override the Copy Data button creation to use correct price
  function patchCopyDataButton() {
    // Wait for the button to be created
    const observer = new MutationObserver((mutations) => {
      const copyButton = document.querySelector("#copyDataLink");
      if (copyButton && !copyButton.dataset.pricePatched) {
        console.log("[Price Fix] Found Copy Data button, patching...");
        copyButton.dataset.pricePatched = "true";

        // Get the correct price
        const correctPrice = extractCorrectPrice();
        if (correctPrice) {
          console.log(
            "[Price Fix] Patching button with correct price:",
            correctPrice,
          );

          // Re-attach click handler with correct price
          const oldHandler = copyButton.onclick;
          copyButton.onclick = null;

          copyButton.addEventListener("click", async function (e) {
            e.preventDefault();
            this.classList.add("clicked");
            setTimeout(() => {
              this.classList.remove("clicked");
            }, 800);

            // Get title and item number from the page
            const title =
              document.querySelector("h1.x-item-title__mainTitle span")
                ?.textContent ||
              document.querySelector(".it-ttl")?.textContent ||
              document.title.split("|")[0].trim();

            const itemNumber =
              window.location.pathname.match(/\/itm\/(\d+)/)?.[1] ||
              document.querySelector("[data-itemid]")?.dataset.itemid;

            const data = {
              title: title,
              price: correctPrice,
              itemNumber: itemNumber,
            };

            // Copy to clipboard
            const jsonString = JSON.stringify(data);
            const textarea = document.createElement("textarea");
            document.body.appendChild(textarea);
            textarea.value = jsonString;
            textarea.select();
            document.execCommand("copy");
            document.body.removeChild(textarea);

            console.log("[Price Fix] Copied to clipboard:", jsonString);
          });
        }
      }
    });

    // Observe for button creation
    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    // Stop observing after 10 seconds
    setTimeout(() => observer.disconnect(), 10000);
  }

  // Run when page loads
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", patchCopyDataButton);
  } else {
    patchCopyDataButton();
  }
})();
```

### 2.2: Register in manifest.json

**Find** the `content_scripts` section in `manifest.json`

**Add** new content script entry:
```json
{
  "matches": ["*://*.ebay.com/itm/*", "*://*.ebay.co.uk/itm/*"],
  "js": ["fix_ebay_item_price.js"],
  "run_at": "document_end"
}
```

### 2.3: Test Price Extraction

1. Reload extension
2. Navigate to any eBay item page
3. Open browser console
4. Look for `[Price Fix] Script loaded` message
5. Click "Copy Data" button
6. Check console for `[Price Fix] Copied to clipboard: {...}`
7. Paste clipboard - verify price is correct (not "99.8" or similar)

**Success Criteria**: ✅ Correct price extracted, not seller feedback

---

## Step 3: Delivery Time Error Fix

**Difficulty**: ⭐⭐⭐ Hard
**Impact**: Critical (prevents crashes)
**Risk**: Medium (modifying obfuscated code)
**Files**: `content_bundle_0.js` (or equivalent Amazon validation file)

### 3.1: Find Duplicate Function Names

**Search Method**:
```bash
# Search for function definitions
grep -n "function.*{" content_bundle_0.js | head -100

# Look for delivery-related DOM queries
grep -n "#delivery-message" content_bundle_0.js
grep -n "data-csa-c-delivery-time" content_bundle_0.js
```

**Pattern to Find** - Two functions with SAME NAME doing different things:

**Function 1** (Returns delivery DATE):
```javascript
function _0xSOMEHEX() {
  // Returns date from attribute
  return document["querySelector"](...).getAttribute("data-csa-c-delivery-time");
}
```

**Function 2** (Returns delivery MESSAGE):
```javascript
function _0xSOMEHEX() {  // SAME NAME - this is the problem!
  // Returns message text
  return document["getElementById"]("delivery-message")["innerText"];
}
```

### 3.2: Identify Which Function Does What

**Technique**: Search for where each function is called

1. **Find calls** to the function name
2. **Look at context** - is it expecting date or text?
3. **Look for** `new Date(...)` calls - these expect the date-returning function
4. **Look for** message display - these expect the text-returning function

### 3.3: Rename Second Function

**Change Function 2 name** (the one returning message text):
```javascript
// BEFORE
function _0xSOMEHEX() {
  var _0x140006 = "No\x20Delivery\x20Message";
  return (
    document["querySelectorAll"]("#delivery-message")["length"] &&
      (_0x140006 = document["getElementById"]("delivery-message")["innerText"]...),
    _0x140006
  );
}

// AFTER - Add _text suffix
function _0xSOMEHEX_text() {  // <-- Added _text
  var _0x140006 = "No\x20Delivery\x20Message";
  return (
    document["querySelectorAll"]("#delivery-message")["length"] &&
      (_0x140006 = document["getElementById"]("delivery-message")["innerText"]...),
    _0x140006
  );
}
```

### 3.4: Update All References

**Find** where the message function is called:
```bash
# Search for deliveryTimeMessage or similar
grep -n "deliveryTimeMessage" content_bundle_0.js
```

**Update call** to use new name:
```javascript
// BEFORE
deliveryTimeMessage: _0xSOMEHEX(_0xWHATEVER)

// AFTER
deliveryTimeMessage: _0xSOMEHEX_text()
```

### 3.5: Test Delivery Time Fix

1. Reload extension
2. Open Amazon product page with delivery information
3. Open browser console
4. Look for delivery time logs
5. **Should NOT see**: "Invalid delivery time date" errors
6. **Should see**: Proper date parsing

**Success Criteria**: ✅ No more delivery time errors in console

---

## Step 4: Free Shipping Validation Fix

**Difficulty**: ⭐⭐ Medium
**Impact**: Medium (validation accuracy)
**Risk**: Low
**Files**: `content_bundle_0.js` (bulk snipe validation area)

### 4.1: Find Free Shipping Validation

**Search Pattern**:
```bash
# Look for "hasFreeShipping" or similar
grep -n "hasFreeShipping\|freeShipping\|free.*shipping" content_bundle_0.js -i

# Look for bulk snipe validation
grep -n "Bulk Snipe\|bulk.*snipe" content_bundle_0.js -i
```

**Expected Pattern** - Variable assigned wrong function:
```javascript
// WRONG - using delivery date function instead of free shipping function
const hasFreeShipping = _0xDELIVERYFUNC(document);
```

### 4.2: Find Correct Free Shipping Function

**Technique**: Look for other places free shipping is checked

**Search for**:
- Functions that check `#delivery-message` text for "FREE"
- Functions checking for free shipping badge elements
- String matching "free", "shipping", "Prime"

**Common Pattern**:
```javascript
function _0xCORRECTFUNC(_0xdocument) {
  // Checks various elements for free shipping indicators
  return (
    document.querySelector(".free-shipping-badge") ||
    /free.*shipping/i.test(document.getElementById("delivery-message").innerText)
  );
}
```

### 4.3: Replace Function Call

**Find the WRONG call** in bulk snipe validation:
```javascript
// BEFORE (using wrong function)
const hasFreeShipping = _0xWRONGFUNC(document);

// AFTER (using correct free shipping function)
const hasFreeShipping = _0xCORRECTFUNC(document);
```

**Validation Method**: Cross-reference with other uses of free shipping check

### 4.4: Test Free Shipping Validation

1. Open bulk snipe settings
2. Add Amazon items with and without free shipping
3. Start validation
4. Check console logs for "[Bulk Snipe] Free shipping check: true/false"
5. Verify items without free shipping are skipped

**Success Criteria**: ✅ Free shipping correctly detected

---

## Step 5: Restricted Words List Update

**Difficulty**: ⭐ Very Easy
**Impact**: High (VERO protection)
**Risk**: None
**Files**: `restricted_words.txt`

### 5.1: Update restricted_words.txt

**Method 1**: Copy entire file from upgraded version

**Method 2**: Verify line count
```bash
# Should have 354 lines
wc -l restricted_words.txt
```

**Method 3**: Ensure new brands are included

Check file contains these additions (sample):
- nike
- adidas
- apple
- disney
- louis vuitton
- rolex
- gucci
- prada
... (354 total)

### 5.2: Verify Format

Each line should:
- Be lowercase
- Have no extra spaces
- Be one brand/term per line
- No special characters (unless part of brand name)

### 5.3: Test VERO Filtering

1. Open bulk snipe settings
2. Enable "Skip VERO protected items"
3. Add eBay items with brand names (Nike, Apple, Disney)
4. Start bulk snipe
5. Verify items are skipped with reason: "VERO/Restricted brand: [brand]"

**Success Criteria**: ✅ 354 entries, VERO filtering works

---

## Step 6: Popup Bulk Snipe Button

**Difficulty**: ⭐ Easy
**Impact**: Low (convenience)
**Risk**: None
**Files**: `popup/popup.html`, `popup/popup.bundle.js`

### 6.1: Add Button to popup.html

**Find** the "Open Bulk Lister" button (or similar):
```html
<button id="open_bulk_lister">Open Bulk Lister</button>
```

**Add** new button right after:
```html
<button id="open_bulk_snipe">Open Bulk Snipe</button>
```

### 6.2: Add Event Listener

**Option A**: If popup.bundle.js is NOT minified:
Open `popup/popup.bundle.js` and add:
```javascript
document.getElementById('open_bulk_snipe').addEventListener('click', function() {
  chrome.tabs.create({ url: chrome.runtime.getURL('bulk_snipe/bulk_snipe_settings.html') });
});
```

**Option B**: If popup.bundle.js IS minified:
Add inline script in `popup.html` before `</body>`:
```html
<script>
document.getElementById('open_bulk_snipe').addEventListener('click', function() {
  chrome.tabs.create({ url: chrome.runtime.getURL('bulk_snipe/bulk_snipe_settings.html') });
});
</script>
```

### 6.3: Test Button

1. Reload extension
2. Click extension icon to open popup
3. Click "Open Bulk Snipe" button
4. Verify bulk_snipe/bulk_snipe_settings.html opens in new tab

**Success Criteria**: ✅ Button opens bulk snipe settings

---

## Step 7: Low Stock Filtering Feature

**Difficulty**: ⭐⭐⭐ Hard
**Impact**: Medium (quality control)
**Risk**: Medium (multiple files)
**Files**: `bulk_snipe/bulk_snipe_settings.html`, `bulk_snipe/bulk_snipe_settings.js`, `content_bundle_0.js`

### 7.1: Add Checkbox to Settings UI

**Edit**: `bulk_snipe/bulk_snipe_settings.html`

**Find** other checkboxes like "Skip VERO" and add:
```html
<div class="form-group">
  <label for="skip-low-stock">Skip low stock items (1-3 in stock):</label>
  <input type="checkbox" id="skip-low-stock" name="skip-low-stock" />
</div>
```

### 7.2: Add Setting Persistence

**Edit**: `bulk_snipe/bulk_snipe_settings.js`

**In constructor** (find where other settings are initialized):
```javascript
this.skipLowStock = false;
```

**In initialization** (find where DOM elements are assigned):
```javascript
this.skipLowStockCheckbox = document.getElementById("skip-low-stock");
```

**Add event listener** (near other checkbox listeners):
```javascript
this.skipLowStockCheckbox.addEventListener("change", (e) => {
  this.skipLowStock = e.target.checked;
  this.saveSettings();
});
```

**In saveSettings** function:
```javascript
skipLowStock: this.skipLowStock,
```

**In loadSettings** function:
```javascript
this.skipLowStock = settings.skipLowStock || false;
```

**In updateUI** function:
```javascript
this.skipLowStockCheckbox.checked = this.skipLowStock;
```

**When passing to validation** (find where validation is called):
```javascript
skipLowStock: this.skipLowStock,
```

### 7.3: Add Validation Logic

**Edit**: `content_bundle_0.js`

**Find** the validation function (look for availability checks, "Bulk Snipe" logs)

**Pattern Recognition**:
- Look for function checking `availabilityMsg` or similar
- Look for checks like "in stock", "available", etc.
- Usually returns `{ valid: boolean, reason: string }`

**Add check** AFTER availability check but BEFORE extended delivery:
```javascript
// Check 2: Low stock check (conditional - skip items with 1, 2, or 3 in stock)
if (skipLowStock) {
  if (
    availabilityMsg.includes("only 1 left") ||
    availabilityMsg.includes("only 2 left") ||
    availabilityMsg.includes("only 3 left")
  ) {
    console.log("[Bulk Snipe] SKIP: Low stock detected (1-3 items)");
    return {
      valid: false,
      reason: "Low stock: " + availabilityMsg,
    };
  }
}
```

### 7.4: Test Low Stock Filter

1. Open bulk snipe settings
2. Check "Skip low stock items (1-3 in stock)"
3. Add Amazon items with "only 1 left in stock" message
4. Start validation
5. Verify items are skipped with reason: "Low stock: only X left in stock"

**Success Criteria**: ✅ Low stock items skipped when enabled

---

## Step 8: Stealth Listing Feature

**Difficulty**: ⭐⭐⭐ Hard
**Impact**: Medium (privacy)
**Risk**: Medium
**Files**: `popup/popup.html`, `content_bundle_9.js` (or wherever SKU embedding occurs)

### 8.1: Add Stealth Checkbox to Popup

**Edit**: `popup/popup.html`

**Find** other switches/checkboxes and add:
```html
<div>
  <span>Stealth Listing (Hide SKU)</span>
  <label class="switch">
    <input type="checkbox" id="stealth_listing_switch" />
    <span class="slider round"></span>
  </label>
</div>
```

### 8.2: Add Setting Persistence Script

**Add** inline script in `popup.html` before `</body>`:
```html
<script>
document.addEventListener('DOMContentLoaded', function() {
  const stealthSwitch = document.getElementById('stealth_listing_switch');

  // Load saved setting
  chrome.storage.local.get(['stealthListing'], function(result) {
    if (result.stealthListing !== undefined) {
      stealthSwitch.checked = result.stealthListing;
    }
  });

  // Save setting when changed
  stealthSwitch.addEventListener('change', function() {
    chrome.storage.local.set({
      stealthListing: this.checked
    }, function() {
      console.log('Stealth listing setting saved:', stealthSwitch.checked);
    });
  });
});
</script>
```

### 8.3: Find SKU Embedding Code

**Search Pattern**:
```bash
# Look for "footerss" class (hidden div with SKU)
grep -n "footerss" content_bundle_*.js

# Look for SKU placeholder
grep -n "{{SKU}}" content_bundle_*.js

# Look for base64 encoding of SKU
grep -n "btoa" content_bundle_*.js
```

**Expected Pattern** - Description building with SKU:
```javascript
// Creates hidden div with SKU
var someDiv = document["createElement"]("div");
someDiv["className"] = "footerss";
someDiv["setAttribute"]("data-label", "{{SKU}}");
someDiv["style"]["display"] = "none";
description += someDiv["outerHTML"];

// Later, replaces placeholder with actual SKU
var encodedSKU = btoa(productSKU);
return description["replace"]("{{SKU}}", encodedSKU);
```

### 8.4: Add Conditional SKU Embedding

**Find** the function that builds description HTML

**At the START of the function**, add:
```javascript
// Load stealth setting
var { stealthListing: stealthEnabled } = await chrome["storage"]["local"]["get"]("stealthListing");
```

**Wrap SKU footer creation** in condition:
```javascript
// BEFORE
var someDiv = document["createElement"]("div");
someDiv["className"] = "footerss";
someDiv["setAttribute"]("data-label", "{{SKU}}");
someDiv["style"]["display"] = "none";
description += someDiv["outerHTML"];

// AFTER - Only if NOT stealth mode
if (!stealthEnabled) {
  var someDiv = document["createElement"]("div");
  someDiv["className"] = "footerss";
  someDiv["setAttribute"]("data-label", "{{SKU}}");
  someDiv["style"]["display"] = "none";
  description += someDiv["outerHTML"];
}
```

**Wrap SKU replacement** in condition:
```javascript
// BEFORE
var encodedSKU = btoa(productSKU);
return description["replace"]("{{SKU}}", encodedSKU);

// AFTER - Only if NOT stealth mode
if (!stealthEnabled) {
  var encodedSKU = btoa(productSKU);
  return description["replace"]("{{SKU}}", encodedSKU);
}
return description;
```

### 8.5: Test Stealth Mode

**Test with Stealth OFF**:
1. Open popup, ensure "Stealth Listing" is unchecked
2. Create eBay listing
3. View listing description source HTML
4. Search for `class="footerss"` - should be FOUND
5. Verify `data-label` contains base64 SKU

**Test with Stealth ON**:
1. Open popup, check "Stealth Listing"
2. Create eBay listing
3. View listing description source HTML
4. Search for `class="footerss"` - should NOT be found

**Success Criteria**: ✅ SKU hidden when stealth enabled, visible when disabled

---

## Step 9: Copy Bulk Snipe Tool

**Difficulty**: ⭐ Easy (if already exists), ⭐⭐⭐⭐ Hard (if missing)
**Impact**: High (major feature)
**Risk**: Low (separate directory)
**Files**: `bulk_snipe/` directory

### 9.1: Check if Bulk Snipe Exists

```bash
ls bulk_snipe/
```

**If exists**: Skip this step
**If missing**: Copy entire directory from upgraded version

### 9.2: Copy Files

Copy these files from upgraded version:
- `bulk_snipe/bulk_snipe_settings.html`
- `bulk_snipe/bulk_snipe_settings.js`
- `bulk_snipe/styles.css`

### 9.3: Register in Manifest (if needed)

Check `manifest.json` has entry for bulk_snipe page:
```json
{
  "web_accessible_resources": [
    "bulk_snipe/bulk_snipe_settings.html",
    "bulk_snipe/styles.css"
  ]
}
```

### 9.4: Test Bulk Snipe

1. Open bulk_snipe/bulk_snipe_settings.html
2. Paste eBay item URLs
3. Configure settings (delay, max items, skip options)
4. Click "Start Bulk Snipe"
5. Verify sequential processing works
6. Check console for progress logs

**Success Criteria**: ✅ Bulk snipe processes items sequentially

---

## Pattern Recognition Guide

This section helps you find code when variable names are different.

### Finding Functions by Behavior

**Technique 1: Search for DOM Elements**
```bash
# Find delivery date function
grep -n "data-csa-c-delivery-time" content_bundle_*.js

# Find delivery message function
grep -n "#delivery-message" content_bundle_*.js

# Find price elements
grep -n "x-price-primary\|vi-VR-cvipPrice" content_bundle_*.js

# Find SKU footer
grep -n "footerss" content_bundle_*.js
```

**Technique 2: Search for String Literals**
```bash
# Find validation logs
grep -n "Bulk Snipe\|SKIP\|valid.*false" content_bundle_*.js

# Find API endpoints
grep -n "https://\|http://" content_bundle_*.js

# Find storage keys
grep -n "chrome.storage\|localStorage" content_bundle_*.js
```

**Technique 3: Search for Return Patterns**
```javascript
// Validation functions return this shape:
return {
  valid: false,
  reason: "Some reason"
};

// Search for this pattern:
grep -n "valid.*false\|valid.*true" content_bundle_0.js
```

**Technique 4: Follow the Data Flow**
```javascript
// Example: Find free shipping function
// 1. Search for "hasFreeShipping" variable
// 2. See what function assigns to it
// 3. Find that function definition
// 4. Verify it checks for free shipping elements
```

### Finding Code by Console Logs

Many functions have `console.log()` calls:
```bash
# Find bulk snipe logs
grep -n "console.log.*Bulk Snipe" content_bundle_*.js

# Find validation logs
grep -n "console.log.*SKIP\|console.log.*valid" content_bundle_*.js

# Find price fix logs
grep -n "console.log.*Price Fix" fix_ebay_item_price.js
```

### Finding Code by HTML Interaction

Look for specific IDs/classes:
```bash
# Copy Data button
grep -n "#copyDataLink\|copyDataLink" content_bundle_*.js

# Bulk snipe checkbox
grep -n "skip-low-stock" bulk_snipe/*.js

# Stealth listing switch
grep -n "stealth_listing_switch" popup/*.html
```

---

## Testing & Validation Checklist

After completing all upgrades, test each feature:

### Critical Features (Must Work)
- [ ] Extension loads without errors
- [ ] eBay price extraction returns correct price (not feedback)
- [ ] No "Invalid delivery time date" errors
- [ ] Free shipping validation accurate
- [ ] Bulk snipe processes items sequentially
- [ ] Challenge screen handling works

### Optional Features (Should Work)
- [ ] Gemini API title generation works
- [ ] Low stock filter skips 1-3 in stock items
- [ ] Stealth mode hides SKU in listings
- [ ] VERO filtering blocks restricted brands
- [ ] Popup bulk snipe button opens settings

### Integration Testing
- [ ] Process 5 items through bulk snipe end-to-end
- [ ] Verify all validation checks work together
- [ ] Check chrome.storage persists settings
- [ ] Confirm no JavaScript errors in console

### Regression Testing
- [ ] Old features still work (regular listing, import, etc.)
- [ ] Amazon page scraping still functions
- [ ] eBay listing creation still works
- [ ] Settings save/load correctly

---

## Troubleshooting

### Issue: Extension Won't Load After Changes

**Symptoms**: Extension fails to load, shows error on chrome://extensions

**Solutions**:
1. Check manifest.json syntax (use JSON validator)
2. Verify all referenced files exist
3. Check console for JavaScript syntax errors
4. Restore from backup and try one change at a time

### Issue: Can't Find Function with Specific Behavior

**Symptoms**: Pattern search returns too many or no results

**Solutions**:
1. Use multiple search patterns together
2. Look for unique string literals in the function
3. Search for console.log messages
4. Use browser DevTools to set breakpoints on DOM elements
5. Compare side-by-side with working version

### Issue: Function Names Are Completely Different

**Symptoms**: No variable names match between versions

**Solutions**:
1. Focus on return values, not variable names
2. Search for DOM queries (these are usually same)
3. Look for string literals (often preserved)
4. Use behavior-based identification
5. Compare function length/complexity

### Issue: Changes Break Existing Functionality

**Symptoms**: Old features stop working after modifications

**Solutions**:
1. Revert last change from backup
2. Add more defensive checks (if statements)
3. Preserve original function signatures
4. Add extensive console logging
5. Test in isolation before integrating

### Issue: Beautification Corrupted Code

**Symptoms**: Extension broken after running Prettier/js-beautify

**Solutions**:
1. Restore from backup
2. Try beautifying one file at a time
3. Check for corrupted regex patterns
4. Verify string literals weren't broken
5. Use `--no-semi` flag with Prettier if needed

---

## Rollback Procedure

If upgrade fails and you need to revert:

1. **Stop Chrome Extension**
   - Go to chrome://extensions
   - Toggle extension OFF

2. **Restore from Backup**
   ```bash
   rm -rf /path/to/extension/*
   cp -r /path/to/backup/* /path/to/extension/
   ```

3. **Verify Files**
   ```bash
   ls -la /path/to/extension/
   # Check all files restored
   ```

4. **Reload Extension**
   - Go to chrome://extensions
   - Click "Reload" on extension
   - Toggle extension ON

5. **Test Basic Functionality**
   - Open Amazon page
   - Try creating listing
   - Verify no console errors

---

## Completion Checklist

Mark each item when completed:

### Preparation
- [ ] Created complete backup
- [ ] Set up test environment
- [ ] Read IMPROVEMENTS.md
- [ ] Beautified code files

### Core Upgrades
- [ ] ✅ Step 1: Gemini API integration
- [ ] ✅ Step 2: eBay price extraction fix
- [ ] ✅ Step 3: Delivery time error fix
- [ ] ✅ Step 4: Free shipping validation fix
- [ ] ✅ Step 5: Restricted words update
- [ ] ✅ Step 6: Popup bulk snipe button
- [ ] ✅ Step 7: Low stock filtering
- [ ] ✅ Step 8: Stealth listing feature
- [ ] ✅ Step 9: Bulk snipe tool (if needed)

### Testing
- [ ] All critical features tested
- [ ] Optional features tested
- [ ] Integration testing completed
- [ ] Regression testing completed
- [ ] No console errors
- [ ] Extension loads successfully

### Documentation
- [ ] Document any deviations from guide
- [ ] Note new variable names found
- [ ] Record any issues encountered
- [ ] Create new IMPROVEMENTS.md for this version

---

## Success Criteria

Your upgrade is complete when:

1. ✅ All 10 improvements implemented
2. ✅ Extension loads without errors
3. ✅ Critical features work (price extraction, delivery validation, bulk snipe)
4. ✅ Optional features work (low stock, stealth, VERO)
5. ✅ No regression in existing features
6. ✅ All tests pass
7. ✅ Backup created and verified

**Estimated Completion Time**: 4-6 hours (depending on code complexity)

---

## Additional Resources

- **IMPROVEMENTS.md**: Detailed description of each improvement
- **Source Version**: Reference the working obfuscated version for comparison
- **Chrome DevTools**: Use to debug and test changes
- **Backup Directory**: Always available for rollback

---

**Document Version**: 1.0
**Last Updated**: 2025-10-15
**Compatible With**: eBay Lister Chrome Extension (obfuscated versions)

---

## Notes for AI Assistants

**When following this guide**:

1. **Read Entire Guide First**: Understand all steps before starting
2. **Work Methodically**: Complete one step fully before moving to next
3. **Test After Each Step**: Don't batch multiple changes without testing
4. **Use Pattern Recognition**: Don't rely on exact variable names
5. **Document Changes**: Note line numbers and variable names you find
6. **Ask for Clarification**: If user feedback needed, ask specific questions
7. **Backup Frequently**: Create checkpoint backups after major steps
8. **Be Patient**: Obfuscated code takes time to understand
9. **Use Console Logs**: Add logging to verify your changes work
10. **Think Behavior First**: What does the code DO, not what it's NAMED

**Red Flags** (stop and ask user):
- ⚠️ Cannot find pattern after extensive search
- ⚠️ Changes break extension completely
- ⚠️ Multiple attempts at fix all fail
- ⚠️ Code structure completely different
- ⚠️ Required files missing from codebase

**Good Signs** (continue confidently):
- ✅ Console logs show expected behavior
- ✅ Tests passing after changes
- ✅ Patterns match guide descriptions
- ✅ Extension loads without errors
- ✅ User confirms functionality works

---

*End of Upgrade Installation Guide*
