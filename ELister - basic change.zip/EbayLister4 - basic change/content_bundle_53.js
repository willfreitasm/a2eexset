function _0x16db98() {
  return new Promise((_0x126358) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x126358();
      });
    });
  });
}
function _0x39cb4f() {
  return new Promise((_0x2b666b) => {
    requestIdleCallback(() => {
      _0x2b666b();
    });
  });
}
function _0x3c8c1f(_0x15edc3 = 0x3e8) {
  return new Promise((_0x569706, _0x1cfbf5) => {
    let _0x56d1fe,
      _0x1cf158 = Date["now"](),
      _0x49170f = !0x1;
    function _0x339ae2() {
      if (Date["now"]() - _0x1cf158 > _0x15edc3)
        (_0x49170f && _0x56d1fe["disconnect"](), _0x569706());
      else setTimeout(_0x339ae2, _0x15edc3);
    }
    const _0x41b20d = () => {
        _0x1cf158 = Date["now"]();
      },
      _0x288112 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x56d1fe = new MutationObserver(_0x41b20d)),
        _0x56d1fe["observe"](document["body"], _0x288112),
        (_0x49170f = !0x0),
        setTimeout(_0x339ae2, _0x15edc3));
    else
      window["onload"] = () => {
        ((_0x56d1fe = new MutationObserver(_0x41b20d)),
          _0x56d1fe["observe"](document["body"], _0x288112),
          (_0x49170f = !0x0),
          setTimeout(_0x339ae2, _0x15edc3));
      };
  });
}
async function _0x887f40() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x3c8c1f(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x43d776() {
  return await new Promise(function (_0x557171, _0xc46e4d) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x1a1892) {
        (console["log"]("result:\x20", _0x1a1892["membership"]),
          _0x557171(_0x1a1892["membership"]));
      },
    );
  });
}
async function _0x5ec156() {
  return await new Promise(function (_0x3d6ec0, _0x257c13) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x374211) {
        (console["log"]("result:\x20", _0x374211["creditsAvailable"]),
          _0x3d6ec0(_0x374211["creditsAvailable"]));
      },
    );
  });
}
async function _0x19be30(_0x5a0893) {
  if ("ultimate" != (await _0x43d776()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x5ec156()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
(console["log"]("content/ebay/downloads/functions.js\x20loaded"),
  console["log"]("content/ebay/downloads/content.js\x20loaded"));
const _0x247ec0 = {
    downloadBannerButton:
      "#listings-content-target\x20.app-mod-banner\x20button",
    reportsDialogFooter:
      "#reports-bam\x20.lightbox-dialog__footer\x20.btn.btn--primary",
    fieldCards: ".se-field-card__content-description",
    welcomeModalButton: ".welcome-dialog\x20.btn.btn--primary",
    gridTable: "table[id$=\x22grid-component-table\x22]",
  },
  _0x2088bd = { SOURCE: "LISTINGS" },
  _0x1648de = { SOURCE: "LISTINGS", TYPE: "ALL_LISTINGS" },
  _0xaba621 = (_0x5ba023) =>
    new Promise((_0x2a7ed7) => setTimeout(_0x2a7ed7, _0x5ba023));
async function _0x36cae7(
  _0x19b368,
  _0x487cd5,
  _0x482865 = 0x1f4,
  _0x546ccf = 0x3a98,
) {
  const _0x1443f7 = Date["now"]();
  let _0xf2ed6c;
  for (; !(_0xf2ed6c = _0x19b368()); ) {
    if (Date["now"]() - _0x1443f7 > _0x546ccf)
      throw new Error("Timed\x20out\x20waiting\x20for\x20" + _0x487cd5);
    await _0xaba621(_0x482865);
  }
  return (console["log"](_0x487cd5 + "\x20found"), _0xf2ed6c);
}
function findInputByValue(_0x42e17a) {
  const _0x10813b = JSON["stringify"](_0x42e17a);
  return Array["from"](document["querySelectorAll"]("input[type=radio]"))[
    "find"
  ]((_0x229f9f) => _0x229f9f["value"] === _0x10813b);
}
function _0x447586() {
  const _0x3f0530 = document["querySelector"](_0x247ec0["gridTable"]);
  return _0x3f0530 ? Array["from"](_0x3f0530["querySelectorAll"]("tbody")) : [];
}
function _0x1632ad(_0x5b98ec) {
  const _0x2a9eca = _0x5b98ec["querySelector"](
    ".shui-dt-column__requestId\x20.shui-dt--text-column\x20div",
  );
  return _0x2a9eca ? _0x2a9eca["textContent"]["trim"]() : null;
}
async function fetchCsv(_0xa38035) {
  const _0x4eac31 = new Date(),
    _0x164e6e =
      "eBay-all-active-listings-report-" +
      _0x4eac31["getFullYear"]() +
      "-" +
      String(_0x4eac31["getMonth"]() + 0x1)["padStart"](0x2, "0") +
      "-" +
      String(_0x4eac31["getDate"]())["padStart"](0x2, "0") +
      "-" +
      _0xa38035 +
      ".csv",
    _0x152d2d =
      window["location"]["origin"] +
      "/sh/fpp/getfiledetails?client=sh-listings&requestId=" +
      _0xa38035 +
      "&filetype=output&fileName=" +
      encodeURIComponent(_0x164e6e);
  console["log"]("Fetching\x20CSV\x20from\x20" + _0x152d2d);
  const _0x37b115 = await fetch(_0x152d2d, { credentials: "include" });
  if (!_0x37b115["ok"])
    throw new Error("Fetch\x20failed:\x20" + _0x37b115["status"]);
  return await _0x37b115["text"]();
}
chrome["runtime"]["onMessage"]["addListener"](
  (_0x1b0f74, _0x5d5810, _0x1c95e0) => {
    if ("download_active_listings_csv" === _0x1b0f74["type"])
      return (
        console["log"]("Request\x20received:\x20download_active_listings_csv"),
        _0x2a76f7()
          ["then"]((_0x5c87f8) => _0x1c95e0({ success: !0x0, csv: _0x5c87f8 }))
          ["catch"]((_0xe32cb6) => {
            (console["error"]("Download\x20flow\x20error:", _0xe32cb6),
              _0x1c95e0({ success: !0x1, error: _0xe32cb6["message"] }));
          }),
        !0x0
      );
  },
);
async function _0x2a76f7() {
  (await _0x2c63bc(),
    (
      await _0x36cae7(
        () => document["querySelector"](_0x247ec0["downloadBannerButton"]),
        "Download\x20banner\x20button",
      )
    )["click"](),
    console["log"]("Download\x20UI\x20opened"),
    (
      await _0x36cae7(
        () => document["querySelectorAll"](_0x247ec0["fieldCards"])[0x0],
        "Source\x20dropdown",
      )
    )["click"](),
    (
      await _0x36cae7(
        () => findInputByValue(_0x2088bd),
        "Report\x20source\x20radio",
      )
    )["click"](),
    (
      await _0x36cae7(
        () => document["querySelectorAll"](_0x247ec0["fieldCards"])[0x1],
        "Type\x20dropdown",
      )
    )["click"](),
    (
      await _0x36cae7(
        () => findInputByValue(_0x1648de),
        "All-listings\x20radio",
      )
    )["click"](),
    await _0x36cae7(
      () => document["querySelector"](_0x247ec0["gridTable"]),
      "Reports\x20table",
    ));
  const _0x4c3bd0 = _0x447586()["map"](_0x1632ad)["filter"](Boolean);
  (console["log"]("Existing\x20requestIds:", _0x4c3bd0),
    (document["title"] = "Report\x20in\x20progress…"));
  const _0x1dc990 = await _0x36cae7(
    () => document["querySelector"](_0x247ec0["reportsDialogFooter"]),
    "Generate\x20report\x20button",
  );
  (_0x1dc990["scrollIntoView"]({ behavior: "smooth", block: "center" }),
    await _0xaba621(0x7d0),
    _0x1dc990["click"](),
    console["log"]("Report\x20generation\x20triggered"),
    await _0x36cae7(
      () =>
        _0x447586()["some"]((_0x221113) => {
          const _0x2d2fdb = _0x1632ad(_0x221113);
          return _0x2d2fdb && !_0x4c3bd0["includes"](_0x2d2fdb);
        }),
      "New\x20report\x20row",
      0x3e8,
      0x927c0,
    ));
  const _0x5b6950 = _0x447586()["find"]((_0x466f6c) => {
      const _0x1cdad4 = _0x1632ad(_0x466f6c);
      return _0x1cdad4 && !_0x4c3bd0["includes"](_0x1cdad4);
    }),
    _0x453a08 = _0x1632ad(_0x5b6950);
  console["log"]("Extracted\x20new\x20requestId:\x20" + _0x453a08);
  const _0x2d695d = await fetchCsv(_0x453a08);
  return ((document["title"] = "Report\x20completed"), _0x2d695d);
}
async function _0x2c63bc() {
  const _0x4ddd5b = document["querySelector"](_0x247ec0["welcomeModalButton"]);
  _0x4ddd5b &&
    (_0x4ddd5b["click"](),
    console["log"]("Welcome\x20modal\x20closed"),
    await _0xaba621(0x3e8));
}
