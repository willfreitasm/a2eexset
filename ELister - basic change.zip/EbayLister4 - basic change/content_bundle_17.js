class _0x558dfa {
  constructor({
    target: target = null,
    menuItems: menuItems = [],
    mode: mode = "dark",
  }) {
    ((this["target"] = target),
      (this["menuItems"] = menuItems),
      (this["mode"] = mode),
      (this["targetNode"] = this["getTargetNode"]()),
      (this["menuItemsNode"] = this["getMenuItemsNode"]()),
      (this["isOpened"] = !0x1),
      (this["menuContainer"] = null));
  }
  ["getTargetNode"]() {
    const _0x5a40b0 = document["querySelectorAll"](this["target"]);
    if (_0x5a40b0 && 0x0 !== _0x5a40b0["length"]) return _0x5a40b0;
    return (
      console["error"](
        "getTargetNode\x20::\x20\x22" +
          this["target"] +
          "\x22\x20target\x20not\x20found",
      ),
      []
    );
  }
  ["getMenuItemsNode"]() {
    const _0x4840a5 = [];
    if (!this["menuItems"])
      return (
        console["error"](
          "getMenuItemsNode\x20::\x20Please\x20enter\x20menu\x20items",
        ),
        []
      );
    return (
      console["log"]("this.menuItems", this["menuItems"]),
      this["menuItems"]["forEach"]((_0x44a9df, _0x2a2e3d) => {
        const _0x28cc6e = this["createItemMarkup"](_0x44a9df);
        (_0x28cc6e["firstChild"]["setAttribute"](
          "style",
          "animation-delay:\x20" + 0.08 * _0x2a2e3d + "s",
        ),
          _0x4840a5["push"](_0x28cc6e));
      }),
      _0x4840a5
    );
  }
  ["createItemMarkup"](_0x5706eb) {
    const _0x33d8ff = document["createElement"]("BUTTON"),
      _0x10657d = document["createElement"]("LI");
    return (
      (_0x33d8ff["innerHTML"] = _0x5706eb["content"]),
      _0x33d8ff["classList"]["add"]("contextMenu-button"),
      _0x5706eb["selected"] && _0x33d8ff["classList"]["add"]("selected"),
      _0x10657d["classList"]["add"]("contextMenu-item"),
      _0x5706eb["divider"] &&
        _0x10657d["setAttribute"]("data-divider", _0x5706eb["divider"]),
      _0x10657d["appendChild"](_0x33d8ff),
      _0x5706eb["events"] &&
        0x0 !== _0x5706eb["events"]["length"] &&
        Object["entries"](_0x5706eb["events"])["forEach"]((_0x5365b4) => {
          const [_0x11bd16, _0x438e36] = _0x5365b4;
          _0x33d8ff["addEventListener"](_0x11bd16, _0x438e36);
        }),
      _0x10657d
    );
  }
  ["renderMenu"]() {
    (console["log"]("rendering\x20menu", this["menuItemsNode"]),
      (this["menuItemsNode"] = this["getMenuItemsNode"]()));
    const _0x7c4129 = document["createElement"]("UL");
    return (
      _0x7c4129["classList"]["add"]("contextMenu"),
      _0x7c4129["setAttribute"]("data-theme", this["mode"]),
      this["menuItemsNode"]["forEach"]((_0x50f03f) =>
        _0x7c4129["appendChild"](_0x50f03f),
      ),
      _0x7c4129
    );
  }
  ["closeMenu"](_0x14028d) {
    this["isOpened"] && ((this["isOpened"] = !0x1), _0x14028d["remove"]());
  }
  ["init"]() {
    (document["addEventListener"]("click", () =>
      this["closeMenu"](this["menuContainer"]),
    ),
      window["addEventListener"]("blur", () =>
        this["closeMenu"](this["menuContainer"]),
      ),
      this["targetNode"]["forEach"]((_0x5be232) => {
        _0x5be232["addEventListener"]("contextmenu", (_0x21d620) => {
          (console["log"]("this.menuContainer", this["menuContainer"]),
            (this["menuContainer"] = this["renderMenu"]()),
            _0x21d620["preventDefault"](),
            console["log"]("this.menuContainer", this["menuContainer"]),
            (this["isOpened"] = !0x0));
          const { clientX: _0x46cb0b, clientY: _0x4b3118 } = _0x21d620;
          document["body"]["appendChild"](this["menuContainer"]);
          const _0x3e4667 =
              _0x4b3118 + this["menuContainer"]["scrollHeight"] >=
              window["innerHeight"]
                ? window["innerHeight"] -
                  this["menuContainer"]["scrollHeight"] -
                  0x14
                : _0x4b3118,
            _0x391ab4 =
              _0x46cb0b + this["menuContainer"]["scrollWidth"] >=
              window["innerWidth"]
                ? window["innerWidth"] -
                  this["menuContainer"]["scrollWidth"] -
                  0x14
                : _0x46cb0b;
          this["menuContainer"]["setAttribute"](
            "style",
            "--width:\x20" +
              this["menuContainer"]["scrollWidth"] +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--height:\x20" +
              this["menuContainer"]["scrollHeight"] +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--top:\x20" +
              _0x3e4667 +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--left:\x20" +
              _0x391ab4 +
              "px;",
          );
        });
      }));
  }
}
function _0x4057ba(_0x4147cb, _0x1f83cd, _0x159e42) {
  (_0x4147cb["forEach"]((_0x17cbc) => {
    _0x17cbc["id"] === _0x1f83cd && (_0x17cbc["selected"] = !0x1);
  }),
    _0x4147cb["forEach"]((_0x5e59c1) => {
      _0x5e59c1["id"] === _0x1f83cd &&
        _0x5e59c1["value"] === _0x159e42 &&
        (_0x5e59c1["selected"] = !0x0);
    }),
    console["log"]("updateContextMenu", _0x4147cb));
}
function _0x49d05a(_0x30b484) {
  var _0x3e17b = document["createElement"]("div");
  ((_0x3e17b["id"] = _0x30b484),
    (_0x3e17b["className"] = "custom-context-menu"));
  var _0x4df7b6 = [];
  function _0x5c2708() {
    (_0x3e17b &&
      ((_0x3e17b["style"]["display"] = "none"), _0x3e17b["remove"]()),
      document["removeEventListener"]("click", _0x5c2708));
  }
  return {
    addMenuItem: function (_0x181a68, _0x1d0c8b) {
      var _0x58c271 = document["createElement"]("div");
      ((_0x58c271["className"] = "context-menu-item"),
        (_0x58c271["textContent"] = _0x181a68),
        _0x58c271["addEventListener"]("click", function (_0x2c81e8) {
          (_0x1d0c8b(_0x2c81e8), _0x5c2708());
        }),
        _0x3e17b["appendChild"](_0x58c271),
        _0x4df7b6["push"](_0x58c271));
    },
    showMenu: function (_0x2d8327) {
      _0x2d8327["preventDefault"]();
      var _0x48707c = document["getElementById"](_0x30b484);
      (_0x48707c && _0x48707c["remove"](),
        document["body"]["appendChild"](_0x3e17b),
        (_0x3e17b["style"]["left"] = _0x2d8327["pageX"] + "px"),
        (_0x3e17b["style"]["top"] = _0x2d8327["pageY"] + "px"),
        (_0x3e17b["style"]["display"] = "block"),
        _0x3e17b["addEventListener"]("click", function (_0x353ce4) {
          _0x353ce4["stopPropagation"]();
        }),
        document["addEventListener"]("click", _0x5c2708));
    },
    hideMenu: _0x5c2708,
    id: _0x30b484,
    element: _0x3e17b,
  };
}
async function _0x2f112a(_0x5556b1) {
  if (_0x4b636a(_0x5556b1))
    return (
      console["log"]("Custom\x20view\x20settings\x20are\x20not\x20applied"),
      !0x0
    );
  await _0x334519();
  for (const _0x473bce of _0x5556b1) {
    (await _0x348328(_0x473bce, !0x0),
      console["log"](
        "Toggled\x20" + _0x473bce + "\x20on,\x20waiting\x204\x20seconds",
      ),
      await new Promise((_0x5b2b8f) => setTimeout(_0x5b2b8f, 0xfa0)));
  }
  return (
    console["log"](
      "Waiting\x2010\x20seconds\x20for\x20the\x20page\x20to\x20update",
    ),
    await new Promise((_0x9ffaaa) => setTimeout(_0x9ffaaa, 0x1388)),
    _0x16751a(),
    console["log"]("Custom\x20view\x20settings\x20are\x20applied"),
    !0x0
  );
}
async function _0x334519() {
  const _0x4a9efa = document["querySelector"]("button.customize-link");
  if (!_0x4a9efa) {
    console["error"]("Customize\x20button\x20not\x20found");
    throw new Error("Customize\x20button\x20not\x20found");
  }
  _0x4a9efa["click"]();
  let _0x2c339e = null;
  for (; !_0x2c339e; ) {
    (await new Promise((_0x1ae71b) => setTimeout(_0x1ae71b, 0xbb8)),
      (_0x2c339e = document["querySelector"]("#listings-customization-dialog")),
      _0x2c339e ||
        console["log"](
          "Could\x20not\x20find\x20customizationDialog,\x20trying\x20again\x20in\x203\x20seconds",
        ));
  }
  return (console["log"]("customizationDialog", _0x2c339e), _0x2c339e);
}
async function _0x348328(_0x3b54af = "Item\x20number", _0x4430a0 = !0x0) {
  const _0x7b3d59 = document["querySelectorAll"](
    "input[name=\x22customize-check\x22]",
  );
  let _0x2c0bb7 = null;
  for (const _0x5caf54 of _0x7b3d59) {
    const _0x1c5baf = _0x5caf54["getAttribute"]("data-text");
    if (
      Array["isArray"](_0x3b54af)
        ? _0x3b54af["includes"](_0x1c5baf)
        : _0x1c5baf === _0x3b54af
    ) {
      _0x2c0bb7 = _0x5caf54;
      break;
    }
  }
  if (!_0x2c0bb7) return !0x1;
  if (_0x2c0bb7["checked"] === _0x4430a0) return !0x0;
  return (_0x2c0bb7["focus"](), _0x2c0bb7["click"](), !0x0);
}
function _0x16751a() {
  console["log"]("Saving\x20custom\x20view\x20settings");
  var _0x5575b1 = document["querySelector"]("#customize-save");
  if (!_0x5575b1)
    return (console["error"]("Save\x20button\x20not\x20found"), !0x1);
  return (_0x5575b1["click"](), !0x0);
}
function _0x4b636a(_0x2aa416) {
  var _0xdaae87 = document["querySelector"](".header-row");
  if (!_0xdaae87)
    return (console["error"]("Header\x20row\x20not\x20found"), !0x1);
  var _0x323716 = _0xdaae87["querySelectorAll"]("th"),
    _0x3e4ac6 = new Set();
  for (var _0x470e28 of _0x323716) {
    var _0x126d89 = _0x470e28["querySelectorAll"](".th-title-content");
    if (0x0 !== _0x126d89["length"]) {
      var _0x309c78 =
        _0x126d89[_0x126d89["length"] - 0x1]["textContent"]["trim"]();
      _0x3e4ac6["add"](_0x309c78);
    }
  }
  console["log"]("displayedHeaders:", Array["from"](_0x3e4ac6));
  const _0xb905f5 = [];
  for (const _0xfc49a8 of _0x2aa416)
    Array["isArray"](_0xfc49a8)
      ? _0xfc49a8["some"]((_0x3f401f) => _0x3e4ac6["has"](_0x3f401f)) ||
        _0xb905f5["push"](_0xfc49a8)
      : _0x3e4ac6["has"](_0xfc49a8) || _0xb905f5["push"](_0xfc49a8);
  if (_0xb905f5["length"] > 0x0)
    return (console["log"]("Missing\x20options:", _0xb905f5), !0x1);
  return !0x0;
}
async function _0x666dd(_0x251351) {
  if (_0x375dad(_0x251351))
    return (
      console["log"](
        "All\x20desired\x20fields\x20are\x20already\x20checked—no\x20action\x20needed.",
      ),
      !0x0
    );
  await _0x1ac76f();
  for (const _0x34b28e of _0x251351) {
    (await _0x566ca0(_0x34b28e["nameAttr"], _0x34b28e["valueAttr"], !0x0),
      await new Promise((_0x5ddbe1) => setTimeout(_0x5ddbe1, 0x1f4)));
  }
  return (
    console["log"](
      "Waiting\x202\x20seconds\x20before\x20applying\x20changes...",
    ),
    await new Promise((_0x1c5cfd) => setTimeout(_0x1c5cfd, 0x7d0)),
    _0x1ad4f3(),
    console["log"](
      "Search\x20page\x20custom\x20view\x20settings\x20applied\x20successfully.",
    ),
    !0x0
  );
}
function _0x375dad(_0x8e6ae3) {
  for (const { nameAttr: _0x2d80ee, valueAttr: _0x4cd29d } of _0x8e6ae3) {
    const _0x5d7bc8 = document["querySelector"](
      "input[type=\x22checkbox\x22][name=\x22" +
        _0x2d80ee +
        "\x22][value=\x22" +
        _0x4cd29d +
        "\x22]",
    );
    if (!_0x5d7bc8 || !_0x5d7bc8["checked"]) return !0x1;
  }
  return !0x0;
}
async function _0x1ac76f() {
  const _0x3461e4 = document["querySelector"](".srp-view-options__customize");
  if (!_0x3461e4)
    throw new Error(
      "Customize\x20button\x20not\x20found\x20on\x20the\x20search\x20page.",
    );
  (_0x3461e4["click"](),
    console["log"](
      "Clicked\x20Customize\x20button,\x20waiting\x20for\x20form\x20to\x20appear...",
    ));
  let _0x48b721 = null,
    _0xa1e4ec = 0x0;
  for (; !_0x48b721 && _0xa1e4ec < 0x5; ) {
    (await new Promise((_0xb4be7b) => setTimeout(_0xb4be7b, 0x7d0)),
      (_0x48b721 = document["querySelector"](".s-customize-form__details")),
      !_0x48b721 &&
        (_0xa1e4ec++,
        console["log"](
          "Could\x20not\x20find\x20details\x20form\x20yet.\x20Attempt\x20" +
            _0xa1e4ec +
            "/5...",
        )));
  }
  if (!_0x48b721)
    throw new Error(
      "Customize\x20form\x20did\x20not\x20appear\x20after\x20several\x20attempts.",
    );
  return (
    console["log"]("Found\x20the\x20customize\x20form:", _0x48b721),
    _0x48b721
  );
}
async function _0x566ca0(_0x2cf91f, _0x5d9820, _0x224c26 = !0x0) {
  const _0x4ebaf3 =
      "input[type=\x22checkbox\x22][name=\x22" +
      _0x2cf91f +
      "\x22][value=\x22" +
      _0x5d9820 +
      "\x22]",
    _0xae6b34 = document["querySelector"](_0x4ebaf3);
  if (!_0xae6b34)
    return (
      console["error"](
        "Checkbox\x20with\x20name=\x22" +
          _0x2cf91f +
          "\x22\x20value=\x22" +
          _0x5d9820 +
          "\x22\x20not\x20found.",
      ),
      !0x1
    );
  if (_0xae6b34["checked"] === _0x224c26)
    return (
      console["log"](
        "Checkbox\x20(name=" +
          _0x2cf91f +
          ",\x20value=" +
          _0x5d9820 +
          ")\x20is\x20already\x20in\x20desired\x20state.",
      ),
      !0x0
    );
  return (
    _0xae6b34["focus"](),
    _0xae6b34["click"](),
    console["log"](
      "Toggled\x20checkbox\x20(name=" +
        _0x2cf91f +
        ",\x20value=" +
        _0x5d9820 +
        ")\x20to\x20" +
        _0x224c26 +
        ".",
    ),
    !0x0
  );
}
function _0x1ad4f3() {
  const _0x3d4df1 = document["querySelector"](
    ".s-customize-form__actions\x20.btn--primary",
  );
  if (!_0x3d4df1)
    return (
      console["error"](
        "Apply\x20changes\x20button\x20not\x20found\x20in\x20customize\x20form!",
      ),
      !0x1
    );
  return (
    _0x3d4df1["click"](),
    console["log"](
      "Clicked\x20\x27Apply\x20changes\x27\x20to\x20save\x20the\x20search\x20page\x20customizations.",
    ),
    !0x0
  );
}
async function _0x1b88b7() {
  await _0x666dd([
    { nameAttr: "_fcse", valueAttr: "1" },
    { nameAttr: "_fcie", valueAttr: "1" },
  ]);
}
function _0x14eb24(
  _0xb34d43 = null,
  _0x298bda = null,
  _0x5d0a8d = null,
  _0x41669b = null,
) {
  var _0x1fd52d = document["createElement"]("a");
  (_0x1fd52d["setAttribute"]("class", "a-link-text"),
    _0x1fd52d["classList"]["add"]("icon"),
    _0x1fd52d["classList"]["add"]("amazonSearchLink"),
    _0x1fd52d["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x1622a5 = document["createElement"]("img");
  return (
    _0x1622a5["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x1622a5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1fd52d["appendChild"](_0x1622a5),
    _0x1fd52d["addEventListener"]("click", async function (_0x4556b8) {
      (_0x4556b8["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0xb34d43) {
        var _0x513439 = _0x32e21d(_0x4556b8);
        if (!_0x513439) return;
        var _0x2e6d7b = _0x150388(_0x513439);
        ((_0xb34d43 = _0x2e6d7b["title"])["endsWith"]("...") &&
          (_0xb34d43 = _0xb34d43["substring"](
            0x0,
            _0xb34d43["lastIndexOf"]("\x20"),
          )),
          _0xb34d43["length"] > 0x4b &&
            (_0xb34d43 = _0xb34d43["substring"](
              0x0,
              _0xb34d43["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x130b09 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x130b09),
        _0x130b09 || (_0x130b09 = "reviews"),
        console["log"]("amazonSortType", _0x130b09),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x478116 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0xb34d43["length"] > 0x50; )
        _0xb34d43 = _0xb34d43["substring"](
          0x0,
          _0xb34d43["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x4a0255 } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x40cb33 = _0xb34d43;
      "keywords" == _0x4a0255 && (_0x40cb33 = await _0x27ea0f(_0xb34d43));
      try {
        _0x2e6d7b = _0x150388(_0x513439);
      } catch (_0x1f8328) {
        console["log"]("error", _0x1f8328);
      }
      (_0x2e6d7b ||
        (_0x2e6d7b = {
          title: _0xb34d43,
          price: _0x298bda,
          itemNumber: _0x5d0a8d,
          image: _0x41669b,
        }),
        console["log"]("itemData", _0x2e6d7b),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x40cb33,
          options: { isTabActive: !0x0, sort: _0x130b09 },
          itemData: _0x2e6d7b,
        }));
    }),
    _0x1fd52d
  );
}
function _0x3204f2(_0x23d02e) {
  var _0x393dc7 = document["createElement"]("a");
  (_0x393dc7["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x393dc7["setAttribute"]("class", "a-link-text"),
    _0x393dc7["classList"]["add"]("icon"),
    _0x393dc7["classList"]["add"]("amazonSearchLink"),
    _0x393dc7["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x284f55 = document["createElement"]("img");
  return (
    _0x284f55["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x284f55["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x393dc7["appendChild"](_0x284f55),
    _0x393dc7["addEventListener"]("click", async function (_0x6a3033) {
      (_0x6a3033["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x23d02e),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x23d02e,
        }));
    }),
    _0x393dc7
  );
}
function _0x28090a(_0x2550f4) {
  var _0x6f53d8 = document["createElement"]("a");
  (_0x6f53d8["setAttribute"]("id", "amazonLink"),
    _0x6f53d8["setAttribute"]("class", "a-link-text"),
    _0x6f53d8["classList"]["add"]("icon"),
    _0x6f53d8["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0xb2b43c = document["createElement"]("img");
  return (
    _0xb2b43c["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0xb2b43c["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x6f53d8["appendChild"](_0xb2b43c),
    _0x6f53d8["addEventListener"]("click", async function (_0x282954) {
      (_0x282954["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x2e5c5f } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x5ab2a7 =
          "https://www.amazon." +
          _0x2e5c5f +
          "/dp/" +
          _0x2550f4 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x5ab2a7 });
    }),
    _0x6f53d8
  );
}
function _0x4096fe(_0x10ea85) {
  var _0x32a1da = document["createElement"]("a");
  (_0x32a1da["setAttribute"]("id", "amazonLink"),
    _0x32a1da["setAttribute"]("class", "a-link-text"),
    _0x32a1da["classList"]["add"]("icon"),
    _0x32a1da["classList"]["add"]("amazonLink"),
    _0x32a1da["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x4ce9ad = document["createElement"]("img");
  return (
    _0x4ce9ad["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4ce9ad["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x32a1da["appendChild"](_0x4ce9ad),
    _0x32a1da["addEventListener"]("click", async function (_0x4e1d5a) {
      (_0x4e1d5a["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x10ea85(_0x4e1d5a);
      } catch (_0x4f1671) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x4f1671);
      }
    }),
    _0x32a1da
  );
}
function _0x83daf8(
  _0x315e74 = null,
  _0x433ec3,
  _0x579d22 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x315e74, _0x433ec3);
  var _0x2d6a40 = document["createElement"]("a");
  (_0x2d6a40["setAttribute"]("id", "ebayLink"),
    _0x2d6a40["setAttribute"]("class", "a-link-text"),
    _0x2d6a40["classList"]["add"]("icon"),
    _0x433ec3 && _0x433ec3["soldItems"]
      ? _0x2d6a40["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x2d6a40["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x15d039 = document["createElement"]("img");
  return (
    _0x15d039["setAttribute"]("src", chrome["runtime"]["getURL"](_0x579d22)),
    _0x15d039["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2d6a40["appendChild"](_0x15d039),
    _0x2d6a40["addEventListener"]("click", async function (_0x38a2eb) {
      (_0x38a2eb["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x315e74) console["log"]("title\x20found", _0x315e74);
      else {
        console["log"]("title\x20not\x20found");
        var _0x24d6a9 = _0x32e21d(_0x38a2eb);
        if (!_0x24d6a9) return;
        var _0x588385 = _0x150388(_0x24d6a9);
        _0x315e74 = _0x588385["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x7607a } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x315e74["length"] > 0x50; )
        _0x315e74 = _0x315e74["substring"](
          0x0,
          _0x315e74["lastIndexOf"]("\x20"),
        );
      var _0x2c26f3 =
        "https://www.ebay." +
        _0x7607a +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x315e74) +
        "&_odkw=" +
        encodeURIComponent(_0x315e74);
      (_0x433ec3 && _0x433ec3["soldItems"] && (_0x2c26f3 += "&LH_Sold=1"),
        _0x433ec3 && _0x433ec3["sortLowToHigh"] && (_0x2c26f3 += "&_sop=15"),
        _0x433ec3 && _0x433ec3["endedRecently"] && (_0x2c26f3 += "&_sop=13"),
        (_0x2c26f3 += "&LH_ItemCondition=1000"),
        (_0x2c26f3 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x2c26f3,
        }));
    }),
    _0x2d6a40
  );
}
function _0x417447(_0xa34bee = null) {
  var _0x60b33f = document["createElement"]("a");
  (_0x60b33f["setAttribute"]("id", "googleLink"),
    _0x60b33f["setAttribute"]("class", "a-link-text"),
    _0x60b33f["classList"]["add"]("icon"),
    _0x60b33f["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0xcead11 = document["createElement"]("img");
  return (
    _0xcead11["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0xcead11["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x60b33f["appendChild"](_0xcead11),
    _0x60b33f["addEventListener"]("click", async function (_0x66713c) {
      (_0x66713c["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0xa34bee) {
        var _0x15bba7 = _0x32e21d(_0x66713c);
        if (!_0x15bba7) return;
        var _0x33b3f7 = _0x150388(_0x15bba7);
        _0xa34bee = _0x33b3f7["image"];
      }
      var { domain: _0x38d588 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x56ca8b(_0x38d588),
        encodeURIComponent(_0xa34bee),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0xa34bee,
        }));
    }),
    _0x60b33f
  );
}
function _0x1c5fcf(_0xd1dc77 = null) {
  var _0x2370ce = document["createElement"]("a");
  (_0x2370ce["setAttribute"]("id", "googleLink"),
    _0x2370ce["setAttribute"]("class", "a-link-text"),
    _0x2370ce["classList"]["add"]("icon"),
    _0x2370ce["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x21c3df = document["createElement"]("img");
  return (
    _0x21c3df["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x21c3df["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2370ce["appendChild"](_0x21c3df),
    _0x2370ce["addEventListener"]("click", async function (_0x562fac) {
      (_0x562fac["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0xd1dc77) {
        var _0x2c32d7 = _0x32e21d(_0x562fac);
        if (!_0x2c32d7) return;
        var _0x1e2974 = _0x150388(_0x2c32d7);
        _0xd1dc77 = _0x1e2974["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0xd1dc77,
      });
    }),
    _0x2370ce
  );
}
function _0x31476d(_0x18605e) {
  var _0x414777 = document["createElement"]("a");
  (_0x414777["setAttribute"]("id", "lookUpSkuLink"),
    _0x414777["setAttribute"]("class", "a-link-text"),
    _0x414777["classList"]["add"]("icon"),
    _0x414777["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x31ff72 = document["createElement"]("img");
  return (
    _0x31ff72["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x31ff72["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x414777["appendChild"](_0x31ff72),
    _0x414777["addEventListener"]("click", async function (_0x3ef6e8) {
      (_0x3ef6e8["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x4693d8 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x1ccb82 =
          "https://www.amazon." +
          _0x4693d8 +
          "/dp/" +
          _0x18605e +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x1ccb82,
        options: { active: !0x0 },
      });
    }),
    _0x414777
  );
}
function _0x286abc(_0x512108 = null) {
  var _0x50a34a = document["createElement"]("a");
  (_0x50a34a["setAttribute"]("id", "productHunterLink"),
    _0x50a34a["setAttribute"]("class", "a-link-text"),
    _0x50a34a["classList"]["add"]("icon"),
    _0x50a34a["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x24eb38 = document["createElement"]("img");
  return (
    _0x24eb38["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x24eb38["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x50a34a["appendChild"](_0x24eb38),
    _0x50a34a["addEventListener"]("click", async function (_0x209bc8) {
      (_0x209bc8["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x512108) {
        var _0x36d8ea = _0x32e21d(_0x209bc8);
        if (!_0x36d8ea) return;
        var _0x3bc5a6 = _0x150388(_0x36d8ea);
        _0x512108 = _0x3bc5a6["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x512108),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x512108,
        }));
    }),
    _0x50a34a
  );
}
function _0x56ca8b(_0xcf7f54) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0xcf7f54] || "en-US";
}
function _0x183e50(_0x17f8d0 = null) {
  console["log"]("createSearchTerapeakButton", _0x17f8d0);
  var _0x26624f = document["createElement"]("a");
  (_0x26624f["setAttribute"]("class", "a-link-text"),
    _0x26624f["classList"]["add"]("terapeakLink"),
    _0x26624f["classList"]["add"]("icon"),
    _0x26624f["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x17f8d0 && _0x26624f["setAttribute"]("item_title", _0x17f8d0));
  var _0x48fa4e = document["createElement"]("img");
  return (
    _0x48fa4e["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x48fa4e["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x26624f["appendChild"](_0x48fa4e),
    _0x26624f["addEventListener"]("click", async function (_0x543cdc) {
      (_0x543cdc["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x455604 = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x455604),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x455604) {
        var _0xf95fa9 = _0x32e21d(_0x543cdc);
        if (!_0xf95fa9) return;
        _0x455604 = _0x150388(_0xf95fa9)["title"];
      }
      console["log"]("title", _0x455604);
      var { convertToKeywords: _0x2db9ab } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x2db9ab) var _0x455604 = await _0x27ea0f(_0x455604);
      var { domain: _0x298730 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x12b3ce = _0x945a19(_0x455604, _0x298730);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x12b3ce });
    }),
    _0x26624f
  );
}
async function _0x27ea0f(_0x2521ed) {
  var _0x16c579 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x429130) => _0x429130["json"]());
  ((_0x16c579["user_input"] = _0x2521ed),
    console["log"]("jsonPrompt", _0x16c579));
  var _0x38f485 = await new Promise((_0x407c49, _0x331060) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x16c579,
      },
      function (_0x4b5cc3) {
        _0x407c49(_0x4b5cc3["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x38f485),
    (_0x38f485 = JSON["parse"](_0x38f485))["output"]
  );
}
function _0x945a19(
  _0x504469,
  _0x4994f7 = "ca",
  _0x3a2727 = 0x1e,
  _0x3a4849 = 0x0,
  _0x41aaf4 = 0x0,
  _0x55dfac = 0x32,
  _0x14e234 = "-itemssold",
  _0x3256ea = "SOLD",
  _0x4ad0df = "EBAY-CA",
  _0xc2a684 = "America/Toronto",
  _0x4566a8 = "BuyerLocation:::CA",
  _0x53bb1e = 0x0,
) {
  _0x4ad0df = "";
  switch (_0x4994f7) {
    case "ca":
    default:
      _0x4ad0df = "EBAY-CA";
      break;
    case "com":
      _0x4ad0df = "EBAY-US";
      break;
    case "co.uk":
      _0x4ad0df = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x4994f7 +
    "/sh/research?" +
    [
      "keywords=" + _0x504469,
      "dayRange=" + _0x3a2727,
      "categoryId=" + _0x3a4849,
      "offset=" + _0x41aaf4,
      "limit=" + _0x55dfac,
      "sorting=" + _0x14e234,
      "tabName=" + _0x3256ea,
      "marketplace=" + _0x4ad0df,
      "tz=" + encodeURIComponent(_0xc2a684),
      "minPrice=" + _0x53bb1e,
    ]["join"]("&")
  );
}
async function _0x54b543(_0x561656) {
  var { domain: _0x471001 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x11ecb2 =
      "https://www.ebay." +
      _0x471001 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x561656 +
      "&store_name=" +
      _0x561656 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x11ecb2 });
}
async function _0x14eaa6(_0x1c1563) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x1c1563,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x1c1563));
}
async function _0x59315e(_0x433bb5) {
  var { response: _0x2c6964 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x433bb5,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x2c6964), _0x2c6964);
}
function _0x1ceb0d(_0x211c8b = null) {
  console["log"]("createOpenSellerItemsButton", _0x211c8b);
  var _0x1c5bb6 = document["createElement"]("a");
  (_0x1c5bb6["setAttribute"]("id", "sellerItemsLink"),
    _0x1c5bb6["setAttribute"]("class", "a-link-text"),
    _0x1c5bb6["classList"]["add"]("icon"),
    _0x1c5bb6["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x14c740 = document["createElement"]("img");
  return (
    _0x14c740["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x14c740["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1c5bb6["appendChild"](_0x14c740),
    _0x1c5bb6["addEventListener"]("click", async function (_0x4b966d) {
      (_0x4b966d["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x211c8b),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x211c8b));
      var _0x1a548e;
      if (!_0x211c8b) {
        console["log"]("username\x20not\x20found");
        var _0x2868ae = _0x32e21d(_0x4b966d);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x2868ae,
        );
        if (!_0x2868ae) return;
        var _0x4ed5a2 = _0x150388(_0x2868ae);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x4ed5a2,
        ),
          (_0x211c8b = _0x4ed5a2["username"]),
          (_0x1a548e = _0x4ed5a2["itemNumber"]));
      }
      if (
        _0x211c8b["includes"]("\x20") ||
        _0x211c8b !== _0x211c8b["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x211c8b,
        );
        if (!_0x1a548e) {
          if (!(_0x2868ae = _0x32e21d(_0x4b966d))) return;
          _0x1a548e = (_0x4ed5a2 = _0x150388(_0x2868ae))["itemNumber"];
        }
        _0x14eaa6(_0x1a548e);
      } else
        ((_0x211c8b = _0x211c8b["toLowerCase"]()),
          console["log"]("username", _0x211c8b),
          _0x54b543(_0x211c8b));
    }),
    _0x1c5bb6
  );
}
function _0x520688(_0x33eb19) {
  for (
    ;
    _0x33eb19 &&
    !_0x33eb19["classList"]["contains"]("s-item") &&
    !_0x33eb19["classList"]["contains"]("su-card-container");

  )
    _0x33eb19 = _0x33eb19["parentElement"];
  return _0x33eb19;
}
function _0xaf1f5e(_0x15672b = null) {
  var _0x2a1a8d = document["createElement"]("a");
  (_0x2a1a8d["setAttribute"]("id", "purchaseHistoryLink"),
    _0x2a1a8d["setAttribute"]("class", "a-link-text"),
    _0x2a1a8d["classList"]["add"]("icon"),
    _0x2a1a8d["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x45c492 = document["createElement"]("img");
  return (
    _0x45c492["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x45c492["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2a1a8d["appendChild"](_0x45c492),
    _0x2a1a8d["addEventListener"]("click", async function (_0x2d5da6) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x15672b),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x2d5da6["preventDefault"]());
      var _0x5dec0c = _0x32e21d(_0x2d5da6);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x5dec0c,
      );
      if (_0x5dec0c) {
        var { selectedFilter: _0x499782 } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x499782 &&
          ((_0x499782 = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x499782,
          }));
        var _0x2008a3 = _0x499782,
          _0x4af7e7 = await _0x4ad6f8(_0x5dec0c, _0x2008a3, !0x1, !0x0);
        console["log"]("totalSold", _0x4af7e7);
      } else
        try {
          var _0x2c40e3 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x15672b,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x2c40e3),
            (_0x4af7e7 = _0x2c40e3["totalSold"]));
        } catch (_0x149649) {
          (console["log"]("error", _0x149649), (_0x4af7e7 = -0x3e7));
        }
    }),
    _0x2a1a8d
  );
}
function _0x32e21d(_0x5c7856) {
  var _0x393cd0 = _0x5c7856["target"];
  return (
    (_0x393cd0 = _0x520688(_0x393cd0)),
    console["log"]("found\x20s-item", _0x393cd0),
    _0x393cd0
  );
}
function _0x5c1511(_0x57d186 = null, _0x57e4cd = null, _0x1fb871 = null) {
  var _0x6ce269 = document["createElement"]("a");
  (_0x6ce269["setAttribute"]("id", "copyDataLink"),
    _0x6ce269["setAttribute"]("class", "a-link-text"),
    _0x6ce269["classList"]["add"]("icon"),
    _0x6ce269["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x180a9b = document["createElement"]("img");
  return (
    _0x180a9b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x180a9b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x6ce269["appendChild"](_0x180a9b),
    _0x6ce269["addEventListener"]("click", async function (_0x3b4499) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x57d186,
        _0x57e4cd,
        _0x1fb871,
      ),
        _0x3b4499["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x57d186 && _0x57e4cd && _0x1fb871)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x57d186,
          _0x57e4cd,
          _0x1fb871,
        ),
          isNaN(_0x57e4cd) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x57e4cd),
            (_0x57e4cd = _0x57e4cd["replace"](/[^0-9.]/g, ""))),
          _0x2aa7bb(
            JSON["stringify"]({
              title: _0x57d186,
              price: _0x57e4cd,
              itemNumber: _0x1fb871,
            }),
          ));
      else {
        if (!_0x57d186 || !_0x57e4cd || !_0x1fb871) {
          var _0x4b7a7f = _0x32e21d(_0x3b4499);
          if (!_0x4b7a7f) return;
        }
        var _0xdbd308 = _0x150388(_0x4b7a7f);
        (console["log"]("itemData", _0xdbd308),
          _0x2aa7bb(JSON["stringify"](_0xdbd308)));
      }
    }),
    _0x6ce269
  );
}
function _0x2aa7bb(_0x35f1cf) {
  var _0x56194b = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x56194b),
    (_0x56194b["value"] = _0x35f1cf),
    _0x56194b["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x56194b));
}
async function _0x2d7ce5(_0x7be162 = null) {
  console["log"]("price", _0x7be162);
  if (_0x7be162) {
    try {
      _0x7be162 = _0x7be162["replace"](/[^0-9.]/g, "");
    } catch (_0xb658fc) {}
    _0x7be162 = parseFloat(_0x7be162);
  }
  var _0x1dc8d0 = await _0x5bb25f(_0x7be162),
    _0x3461d1 = document["createElement"]("div");
  return (
    _0x3461d1["setAttribute"]("id", "breakEvenPrice"),
    _0x3461d1["setAttribute"]("class", "break-even-price"),
    (_0x3461d1["textContent"] =
      "Break-even\x20price:\x20$" + _0x1dc8d0["toFixed"](0x2)),
    _0x3461d1
  );
}
async function _0x52711a(_0x4a935f) {
  var _0xc00328 = !0x1,
    _0x20b8f = !0x1,
    { includeCurrencyConversion: _0x20b8f } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0xc00328 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x6eb9e8 =
    0.1325 * _0x4a935f +
    0.021 * _0x4a935f +
    _0x4a935f * (_0xc00328 ? 0.004 : 0x0) +
    0.4;
  return (_0x20b8f && (_0x6eb9e8 += 0.035 * _0x4a935f), _0x4a935f - _0x6eb9e8);
}
async function _0x5bb25f(_0x16bbfd) {
  var { isInternational: _0x4b5165 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x48add7 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x4b5165 || (_0x4b5165 = !0x1), _0x48add7 || (_0x48add7 = !0x0));
  var _0x1b8f35 = 13.25;
  _0x48add7 && (_0x1b8f35 = 12.35);
  var _0xcc5744 = _0x16bbfd + 0.0725 * _0x16bbfd,
    _0x24b649 =
      _0xcc5744 * (_0x1b8f35 / 0x64) +
      0.4 +
      (_0x4b5165 ? 0.004 * _0xcc5744 : 0x0),
    _0xb5fe7a =
      _0x16bbfd -
      (_0x24b649 + (_0x4b5165 ? 0.05 * _0x24b649 : 0x0)) -
      (_0x4b5165 ? 0.035 * _0xcc5744 : 0x0),
    { isUserTaxExempt: _0x24a93a } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x24a93a || (_0x24a93a = !0x1),
    _0x24a93a || (_0xb5fe7a /= 1.0725),
    _0x4b5165 && (_0xb5fe7a -= (3.5 * _0xb5fe7a) / 0x64),
    _0xb5fe7a
  );
}
function _0x5422db(_0x3f7642 = null) {
  console["log"]("createButtonToSaveSeller", _0x3f7642);
  var _0x2e036c = document["createElement"]("a");
  (_0x2e036c["setAttribute"]("id", "saveSellerLink"),
    _0x2e036c["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x2e036c["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x1fad01 = document["createElement"]("img");
  return (
    _0x1fad01["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x1fad01["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2e036c["appendChild"](_0x1fad01),
    _0x2e036c["addEventListener"]("click", async function (_0x19771e) {
      (_0x19771e["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x3f7642));
      var _0x436bb4;
      if (!_0x3f7642) {
        var _0x5a512c = _0x32e21d(_0x19771e);
        if (!_0x5a512c) return;
        var _0x1fc4f5 = _0x150388(_0x5a512c);
        ((_0x3f7642 = _0x1fc4f5["username"]),
          (_0x436bb4 = _0x1fc4f5["itemNumber"]));
      }
      if (
        _0x3f7642["includes"]("\x20") ||
        _0x3f7642 !== _0x3f7642["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x3f7642,
        ),
          (_0x3f7642 = await _0x59315e(_0x436bb4)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x3f7642,
          ));
      else _0x3f7642 = _0x3f7642["toLowerCase"]();
      _0x2e036c["setAttribute"]("data-seller-name", _0x3f7642);
      var { ebayCompetitors: _0x327d9a } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0xfec3e3 = (_0x327d9a = _0x327d9a || [])["indexOf"](_0x3f7642);
      console["log"]("ebayCompetitors", _0x327d9a);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0xfec3e3
            ? (console["log"]("save-seller\x20clicked\x20username", _0x3f7642),
              _0x327d9a["push"](_0x3f7642),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x1fad01["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x3f7642,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x1fad01["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0xfec3e3)
            (console["log"]("remove-seller\x20clicked\x20username", _0x3f7642),
              _0x327d9a["splice"](_0xfec3e3, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x1fad01["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x3f7642,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x327d9a });
    }),
    _0x2e036c
  );
}
async function _0x15c211(_0x5082ce, _0x9df468) {
  var { ebayCompetitors: _0x1ba4aa } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x2ee17a = (_0x1ba4aa = _0x1ba4aa || [])["indexOf"](_0x9df468),
    _0x170f6e = _0x5082ce["querySelector"]("img");
  -0x1 !== _0x2ee17a
    ? (_0x5082ce["classList"]["replace"]("save-seller", "remove-seller"),
      _0x170f6e["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x5082ce["classList"]["replace"]("remove-seller", "save-seller"),
      _0x170f6e["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x5976bb(
  _0x3023df = null,
  _0x862160 = null,
  _0x933c87 = null,
  _0x3f849a = !0x0,
  _0x4fdec3 = null,
  _0x1d3bd5 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x3023df));
  var _0x2594e0 = _0x5422db(_0x862160),
    _0x3f261c = _0x183e50(_0x3023df),
    _0x455f9d = _0xaf1f5e(_0x4fdec3),
    _0x3c42de = _0x83daf8(_0x3023df),
    _0x4a7a77 = _0x14eb24(_0x3023df, _0x1d3bd5, _0x4fdec3, _0x933c87),
    _0x333a0c = _0x83daf8(
      _0x3023df,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x457544 = _0x417447(_0x933c87),
    _0x101eda = _0x1c5fcf(_0x4fdec3),
    _0x2c1094 = _0x1ceb0d(_0x862160),
    _0x1b2cd4 = document["createElement"]("div");
  _0x1b2cd4["setAttribute"]("id", "search-div");
  var _0x122ca9 = document["createElement"]("label");
  ((_0x122ca9["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x1b2cd4["appendChild"](_0x122ca9),
    _0x1b2cd4["appendChild"](_0x4a7a77),
    _0x1b2cd4["appendChild"](_0x3c42de),
    _0x1b2cd4["appendChild"](_0x3f261c),
    _0x1b2cd4["appendChild"](_0x457544),
    _0x1b2cd4["appendChild"](_0x101eda),
    _0x1b2cd4["appendChild"](_0x333a0c),
    console["log"]("CopyDataButton", _0x3023df, _0x1d3bd5, _0x4fdec3));
  var _0x1e0894 = _0x5c1511(_0x3023df, _0x1d3bd5, _0x4fdec3),
    _0x2c56f5 = document["createElement"]("div");
  _0x2c56f5["setAttribute"]("id", "item-buttons-div");
  var _0x11292b = document["createElement"]("div");
  (_0x11292b["setAttribute"]("id", "main-buttons-div"),
    _0x11292b["appendChild"](_0x2c1094),
    _0x11292b["appendChild"](_0x455f9d),
    _0x11292b["appendChild"](_0x1e0894),
    _0x11292b["appendChild"](_0x2594e0),
    _0x2c56f5["appendChild"](_0x11292b));
  if (_0x3f849a) {
    var _0x241d01 = _0x1a3f13();
    _0x2c56f5["appendChild"](_0x241d01);
  }
  return (_0x2c56f5["appendChild"](_0x1b2cd4), _0x2c56f5);
}
var _0x16e9be = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0xbc9a30) => {
        (console["log"](
          _0xbc9a30,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          _0x4057ba(_0x16e9be, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x480637) => {
        (console["log"](
          _0x480637,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          _0x4057ba(_0x16e9be, "search-type", "keywords"));
      },
    },
  },
];
async function _0x1a0d04() {
  var { convertToKeywords: _0x5bf0f2 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x5bf0f2 &&
    ((_0x5bf0f2 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    _0x4057ba(_0x16e9be, "search-type", _0x5bf0f2 ? "keywords" : "title"),
    new _0x558dfa({ target: ".terapeakLink", menuItems: _0x16e9be })["init"]());
}
var _0x961b12 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x1d5874) => {
        (console["log"](_0x1d5874, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          _0x4057ba(_0x961b12, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x57e10c) => {
        (console["log"](_0x57e10c, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          _0x4057ba(_0x961b12, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x361a9e) => {
        (console["log"](
          _0x361a9e,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          _0x4057ba(_0x961b12, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x44b66b) => {
        (console["log"](
          _0x44b66b,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          _0x4057ba(_0x961b12, "search-type", "keywords"));
      },
    },
  },
];
async function _0x17d8f1() {
  var { amazonSortType: _0x13f2a5 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x4cdc8c } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x4cdc8c &&
    ((_0x4cdc8c = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x13f2a5 &&
      ((_0x13f2a5 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    _0x4057ba(_0x961b12, "sort-type", _0x13f2a5),
    _0x4057ba(_0x961b12, "search-type", _0x4cdc8c),
    new _0x558dfa({ target: ".amazonSearchLink", menuItems: _0x961b12 })[
      "init"
    ]());
}
_0x961b12 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x49ade0) => {
        (console["log"](_0x49ade0, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          _0x4057ba(_0x961b12, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0xd26674) => {
        (console["log"](_0xd26674, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          _0x4057ba(_0x961b12, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x181751 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x21d6f2) => {
        (console["log"](_0x21d6f2, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          _0x4057ba(_0x181751, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3c1151) => {
        (console["log"](_0x3c1151, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          _0x4057ba(_0x181751, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x69e2e) => {
        (console["log"](_0x69e2e, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          _0x4057ba(_0x181751, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x894aae) => {
        (console["log"](_0x894aae, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          _0x4057ba(_0x181751, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2483ac) => {
        (console["log"](_0x2483ac, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          _0x4057ba(_0x181751, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x1a63c7) => {
        (console["log"](_0x1a63c7, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          _0x4057ba(_0x181751, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x262773) => {
        (console["log"](_0x262773, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          _0x4057ba(_0x181751, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x374d8b) => {
        (console["log"](_0x374d8b, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          _0x4057ba(_0x181751, "filter-type", "90"));
      },
    },
  },
];
async function _0x47d146() {
  var { selectedFilter: _0x545296 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x545296 &&
    ((_0x545296 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    _0x4057ba(_0x181751, "filter-type", _0x545296),
    new _0x558dfa({ target: ".filter-date-context", menuItems: _0x181751 })[
      "init"
    ]());
}
function _0x396b13() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x5aac06() {
  const _0x1c9deb = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x2e0986 = 0x0;
  const _0x3b8e27 = () =>
    new Promise((_0x28042a, _0x89dbbc) => {
      const _0x258705 = new MutationObserver((_0x46137d, _0x26f4e5) => {
        const _0x5990af = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x5990af &&
          (console["log"]("Details\x20form\x20found!"),
          _0x26f4e5["disconnect"](),
          _0x28042a(_0x5990af));
      });
      (_0x258705["observe"](_0x1c9deb, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x258705["disconnect"]();
          if (_0x2e0986 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x2e0986 + 0x1) +
                "/3)",
            ),
              _0x2e0986++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x28042a(_0x3b8e27()), 0x1388));
          else
            _0x89dbbc(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x41c89d = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x41c89d) {
    (_0x41c89d["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x3b8e27(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x1cec25) {
      console["error"](_0x1cec25["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x470219(_0x1a80d4 = null, _0xa8492b = null, _0xbf4651 = null) {
  var _0x48efaa = document["createElement"]("a");
  (_0x48efaa["setAttribute"]("id", "copyDataLink"),
    _0x48efaa["setAttribute"]("class", "a-link-text"),
    _0x48efaa["classList"]["add"]("icon"),
    _0x48efaa["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x1c37dc = document["createElement"]("img");
  return (
    _0x1c37dc["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x1c37dc["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x48efaa["appendChild"](_0x1c37dc),
    _0x48efaa["addEventListener"]("click", async function (_0x8da750) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x1a80d4,
        _0xa8492b,
        _0xbf4651,
      ),
        _0x8da750["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x1a80d4 && _0xa8492b && _0xbf4651) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x1a80d4,
          _0xa8492b,
          _0xbf4651,
        );
        isNaN(_0xa8492b) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0xa8492b),
          (_0xa8492b = _0xa8492b["replace"](/[^0-9.]/g, "")));
        var _0x231f93 = JSON["stringify"]({
          title: _0x1a80d4,
          price: _0xa8492b,
          itemNumber: _0xbf4651,
        });
        (_0x4e4dc6(
          (_0x1fcbd7 = await findSimiliarProducts(_0x231f93))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x1fcbd7),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x1a80d4 || !_0xa8492b || !_0xbf4651) {
          var _0x2482e4 = _0x32e21d(_0x8da750);
          if (!_0x2482e4) return;
        }
        var _0x3bd3c0 = _0x150388(_0x2482e4);
        (console["log"]("itemData", _0x3bd3c0),
          (_0x231f93 = JSON["stringify"](_0x3bd3c0)));
        var _0x1fcbd7;
        (_0x4e4dc6(
          (_0x1fcbd7 = await findSimiliarProducts(_0x231f93))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x1fcbd7),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x48efaa
  );
}
async function findSimiliarProducts(_0x5f420b) {
  console["log"]("findSimiliarProducts", _0x5f420b);
  var _0x1e89b2 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x5f420b,
  });
  return (console["log"]("response", _0x1e89b2), _0x1e89b2["productLinks"]);
}
function _0x4e4dc6(_0x3682a7) {
  const _0xf64002 = document["getElementById"]("productLinksModalOverlay");
  _0xf64002 && _0xf64002["remove"]();
  const _0x975e0d = document["createElement"]("div");
  ((_0x975e0d["id"] = "productLinksModalOverlay"),
    _0x975e0d["classList"]["add"]("product-links-modal-overlay"));
  const _0x11c36a = document["createElement"]("div");
  _0x11c36a["classList"]["add"]("product-links-modal");
  const _0xd44a96 = document["createElement"]("div");
  _0xd44a96["classList"]["add"]("modal-button-container");
  const _0x5e21c3 = document["createElement"]("button");
  (_0x5e21c3["classList"]["add"]("close-button"),
    (_0x5e21c3["innerText"] = "Close"),
    _0x5e21c3["addEventListener"]("click", () => {
      _0x975e0d["remove"]();
    }));
  const _0x1546f2 = document["createElement"]("button");
  (_0x1546f2["classList"]["add"]("copy-button"),
    (_0x1546f2["innerText"] = "Copy"),
    _0x1546f2["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x3682a7),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x5cae88) {
        console["error"]("Failed\x20to\x20copy:", _0x5cae88);
      }
    }));
  const _0x18aa71 = document["createElement"]("h2");
  _0x18aa71["innerText"] = "Similar\x20Product\x20Links";
  const _0x3d1a15 = document["createElement"]("textarea");
  ((_0x3d1a15["value"] = _0x3682a7),
    _0x3d1a15["setAttribute"]("readonly", !0x0),
    (_0x3d1a15["style"]["width"] = "100%"),
    (_0x3d1a15["style"]["height"] = "300px"),
    _0xd44a96["appendChild"](_0x1546f2),
    _0xd44a96["appendChild"](_0x5e21c3),
    _0x11c36a["appendChild"](_0xd44a96),
    _0x11c36a["appendChild"](_0x18aa71),
    _0x11c36a["appendChild"](_0x3d1a15),
    _0x975e0d["appendChild"](_0x11c36a),
    document["body"]["appendChild"](_0x975e0d));
}
function _0x3ee773(_0x1ea7c4) {
  try {
    try {
      var _0xe36887 = new Date(_0x1ea7c4);
      if (!isNaN(_0xe36887)) return _0xe36887;
    } catch (_0x152cbd) {}
    var _0x21b0c7 = _0x1ea7c4["split"](",")[0x0]
      ["trim"]()
      ["match"](/(\d+)\.? ?(\w+)[.]? ?(\d+)/);
    if (!_0x21b0c7)
      return (
        console["error"]("Date\x20string\x20not\x20recognized:", _0x1ea7c4),
        null
      );
    console["log"]("match:\x20", _0x21b0c7);
    const _0x36153c = _0x21b0c7[0x1],
      _0x58f20e = _0x21b0c7[0x2]["toLowerCase"](),
      _0x100df3 = _0x21b0c7[0x3],
      _0x2116f2 = _0x1983c8[_0x58f20e];
    if (!_0x2116f2)
      return (console["error"]("Month\x20not\x20recognized:", _0x58f20e), null);
    const _0x4d90ec = _0x100df3 + "-" + _0x2116f2 + "-" + _0x36153c,
      _0x39a2e6 = new Date(_0x4d90ec);
    if (isNaN(_0x39a2e6))
      return (console["error"]("Invalid\x20date\x20parsed:", _0x4d90ec), null);
    return _0x39a2e6;
  } catch (_0x2f3dbe) {
    return (
      console["error"]("Error\x20parsing\x20date:", _0x1ea7c4, _0x2f3dbe),
      null
    );
  }
}
const _0x1983c8 = {
  gen: "01",
  genn: "01",
  feb: "02",
  febb: "02",
  mar: "03",
  apr: "04",
  mag: "05",
  magg: "05",
  giu: "06",
  lug: "07",
  ago: "08",
  set: "09",
  sett: "09",
  ott: "10",
  nov: "11",
  dic: "12",
  ene: "01",
  feb: "02",
  mar: "03",
  abr: "04",
  may: "05",
  jun: "06",
  jul: "07",
  ago: "08",
  sep: "09",
  oct: "10",
  nov: "11",
  dic: "12",
  janv: "01",
  févr: "02",
  mars: "03",
  avr: "04",
  mai: "05",
  juin: "06",
  juil: "07",
  août: "08",
  sept: "09",
  oct: "10",
  nov: "11",
  déc: "12",
  jan: "01",
  feb: "02",
  märz: "03",
  mrz: "03",
  apr: "04",
  mai: "05",
  juni: "06",
  juli: "07",
  aug: "08",
  sept: "09",
  okt: "10",
  nov: "11",
  dez: "12",
  jan: "01",
  feb: "02",
  mar: "03",
  apr: "04",
  may: "05",
  jun: "06",
  jul: "07",
  aug: "08",
  sep: "09",
  oct: "10",
  nov: "11",
  dec: "12",
};
var _0x37046d = _0x3ee773("Aug\x2030\x202024");
console["log"](_0x37046d);
function _0x305c93(_0x493a66) {
  const _0x8880f = (_0x493a66 = _0x493a66["replace"](/[^0-9.,]/g, ""))[
      "lastIndexOf"
    ](","),
    _0x5aaddf = _0x493a66["lastIndexOf"](".");
  return (
    (_0x493a66 =
      _0x8880f > _0x5aaddf
        ? (_0x493a66 = _0x493a66["replace"](/\./g, ""))["replace"](",", ".")
        : _0x493a66["replace"](/,/g, "")),
    parseFloat(_0x493a66)
  );
}
console["log"]("public_search\x20functions.js\x20loaded");
function _0x1a3f13() {
  var _0x495101 = document["createElement"]("div"),
    _0x34b92f = document["createElement"]("a");
  ((_0x34b92f["className"] =
    "vim\x20fake-btn\x20fake-btn--primary\x20ux-call-to-action"),
    (_0x34b92f["href"] = "#"),
    _0x34b92f["classList"]["add"]("custom-button"));
  var _0x2a9d59 = document["createElement"]("span");
  return (
    (_0x2a9d59["className"] = "ux-call-to-action__cell"),
    (_0x2a9d59["innerHTML"] =
      "<span\x20class=\x22ux-call-to-action__text\x22>List\x20To\x20Ebay</span>"),
    _0x34b92f["appendChild"](_0x2a9d59),
    _0x495101["appendChild"](_0x34b92f),
    (_0x495101["className"] = "button-list\x20vim"),
    _0x34b92f["addEventListener"]("click", async function (_0x331dd2) {
      _0x331dd2["preventDefault"]();
      if (!_0x34b92f["classList"]["contains"]("disabled")) {
        (console["log"]("buttonList\x20clicked"),
          _0x34b92f["classList"]["add"]("disabled"),
          (_0x2a9d59["querySelector"](".ux-call-to-action__text")["innerText"] =
            "Listing..."));
        var _0x1085e0 = _0x331dd2["target"];
        console["log"]("item", _0x1085e0);
        for (; _0x1085e0 && !_0x1085e0["classList"]["contains"]("s-item"); )
          _0x1085e0 = _0x1085e0["parentElement"];
        console["log"]("item", _0x1085e0);
        if (_0x1085e0) {
          console["log"]("item", _0x1085e0);
          var _0x4ffc98 = _0x150388(_0x1085e0, 0x0);
          console["log"]("itemData", _0x4ffc98);
          var _0xa5c30b = await new Promise((_0x599af5) => {
            chrome["runtime"]["sendMessage"](
              { type: "OpenEbayItemAndlistEbayItem", itemData: _0x4ffc98 },
              function (_0x4e3d9e) {
                _0x599af5(_0x4e3d9e["response"]);
              },
            );
          });
          console["log"]("response", _0xa5c30b);
          var _0x1de33c = _0x2a6e95(_0xa5c30b["response"]["message"]);
          (_0x495101["appendChild"](_0x1de33c),
            (_0x2a9d59["querySelector"](".ux-call-to-action__text")[
              "innerText"
            ] =
              "itemListed" == _0xa5c30b["response"]["message"]["type"]
                ? "Listed!"
                : "Failed!"));
        }
      }
    }),
    _0x495101
  );
}
function _0x2a6e95(_0x3b8207) {
  console["log"]("createDisplayElement\x20message", _0x3b8207);
  var _0x4fc6ae = document["createElement"]("div");
  _0x4fc6ae["className"] = "info-box";
  var _0xd0a827 = "itemListed" == _0x3b8207["type"] ? "success" : "error",
    _0xcd8f4b = _0x3b8207["ebayItemLink"]
      ? "<a\x20href=\x22" +
        _0x3b8207["ebayItemLink"] +
        "\x22\x20target=\x22_blank\x22>View\x20Item</a>"
      : "Not\x20Available";
  return (
    (_0x4fc6ae["innerHTML"] =
      "\x0a\x20\x20\x20\x20\x20\x20<p>Status:\x20" +
      _0xd0a827 +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>Message:\x20" +
      _0x3b8207["message"] +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>" +
      _0xcd8f4b +
      "</p>"),
    _0x4fc6ae
  );
}
function _0x3dff33() {
  document["querySelectorAll"](".s-item")["forEach"]((_0x3868be, _0x2650a5) => {
    const _0x142114 = document["createElement"]("div");
    ((_0x142114["style"]["position"] = "absolute"),
      (_0x142114["style"]["top"] = "5px"),
      (_0x142114["style"]["left"] = "5px"),
      (_0x142114["style"]["backgroundColor"] = "white"),
      (_0x142114["style"]["padding"] = "5px"),
      (_0x142114["style"]["border"] = "1px\x20solid\x20black"),
      (_0x142114["style"]["borderRadius"] = "5px"),
      (_0x142114["style"]["zIndex"] = "1000"),
      (_0x142114["innerText"] = "Rank:\x20" + (_0x2650a5 + 0x1)),
      (_0x3868be["style"]["position"] = "relative"),
      _0x3868be["appendChild"](_0x142114));
  });
}
function _0x44d2fb() {
  console["log"]("Selecting\x20all\x20items...");
  var _0x2668df = document["querySelectorAll"]("#srp-river-results\x20.s-item");
  return (
    console["log"](_0x2668df),
    [
      ..._0x2668df,
      ...document["querySelectorAll"](".srp-results\x20.su-card-container"),
    ]
  );
}
function _0x3777ec(_0x79af57) {
  var _0x566504 = _0x79af57["querySelector"](
    ".s-item__title--tag\x20.POSITIVE",
  );
  return (
    _0x566504 ||
      (_0x566504 = _0x79af57["querySelector"](
        ".s-item__caption--signal.POSITIVE",
      )),
    _0x566504 ||
      (_0x566504 = _0x79af57["querySelector"](".s-card__caption\x20.positive")),
    _0x566504
  );
}
function _0x150388(_0x1c02c9, _0x3d3512 = 0x0) {
  console["log"]("Extracting\x20item\x20data...", _0x1c02c9);
  var _0x29e358 =
      _0x1c02c9["querySelector"](".s-item__title") ||
      _0x1c02c9["querySelector"](".s-card__title"),
    _0x593a27 = _0x29e358 ? _0x29e358["querySelector"](".clipped") : null;
  _0x593a27 && (_0x593a27["textContent"] = "");
  var _0x21aed1 = _0x29e358 ? _0x29e358["textContent"] : null;
  const _0x3a3da3 = _0x3d3512 + 0x1,
    _0x6b38c7 = null !== _0x1c02c9["querySelector"](".s-item__etrs-text");
  var _0x479c8d = _0x3777ec(_0x1c02c9),
    _0x23edc3;
  _0x23edc3 =
    null !== _0x479c8d
      ? (_0x23edc3 = (_0x23edc3 = _0x479c8d["textContent"])["replace"](
          "Sold",
          "",
        ))["trim"]()
      : null;
  var _0x8c208f = {},
    _0x5e1320 = "N/A";
  try {
    var _0x11ad68 = _0x1c02c9["querySelectorAll"](".total-sold-element");
    for (_0x3d3512 = 0x0; _0x3d3512 < _0x11ad68["length"]; _0x3d3512++) {
      var _0x4e05ae = _0x11ad68[_0x3d3512],
        _0x861e36 = _0x4e05ae["getAttribute"]("data-total-sold");
      _0x8c208f[_0x4e05ae["getAttribute"]("data-last-x-days")] = _0x861e36;
    }
    isNaN(_0x5e1320) && (_0x5e1320 = "N/A");
  } catch (_0x3b01b7) {
    console["log"](
      "Error\x20getting\x20total\x20sold\x20or\x20total\x20competitors",
      _0x3b01b7,
    );
  }
  var _0x5edc36 =
    _0x1c02c9["querySelector"](".s-item__image-wrapper\x20img") ||
    _0x1c02c9["querySelector"](".image-treatment\x20img");
  _0x5edc36 = _0x5edc36["getAttribute"]("src");
  var _0x4a98a0 = _0x1c02c9["querySelector"]("a")
    ["getAttribute"]("href")
    ["split"]("?")[0x0]
    ["split"]("/")
    ["pop"]();
  console["log"]("itemNumber", _0x4a98a0);
  var _0x16fe1c = _0x2d977a(_0x1c02c9);
  return {
    title: _0x21aed1,
    price: _0x265f3d(_0x1c02c9),
    listRanking: _0x3a3da3,
    sponsored: _0x6b38c7,
    itemNumber: _0x4a98a0,
    dateSold: _0x23edc3,
    totalSold: _0x8c208f,
    totalCompetitors: _0x5e1320,
    image: _0x5edc36,
    username: _0x16fe1c,
    sellerFeedback: _0x7d53d4(_0x1c02c9),
    sellerFeedbackPercent: _0x3b1017(_0x1c02c9),
  };
}
function _0x265f3d(_0x5b0232) {
  var _0x40e5cc = _0x5b0232["querySelector"](".s-item__price");
  _0x40e5cc || (_0x40e5cc = _0x5b0232["querySelector"](".s-card__price"));
  var _0x151eaa = _0x40e5cc["textContent"];
  return _0x305c93(_0x151eaa);
}
function _0x3e932b() {
  var _0x143b76 = document["querySelectorAll"](
    ".su-card-container__attributes__secondary",
  );
  return (
    (_0x143b76 && 0x0 != _0x143b76["length"]) ||
      (_0x143b76 = document["querySelectorAll"](
        ".srp-results\x20.s-item__details-section--secondary",
      )),
    _0x143b76
  );
}
function _0x102614(_0x59af90) {
  var _0x3ec6e0 = _0x59af90["querySelectorAll"](
    ".su-card-container__attributes__secondary\x20.s-card__attribute-row",
  );
  return 0x3 == _0x3ec6e0["length"]
    ? _0x3ec6e0[0x1]
    : 0x2 == _0x3ec6e0["length"] || 0x1 == _0x3ec6e0["length"]
      ? _0x3ec6e0[0x0]
      : _0x59af90["querySelector"](".s-item__seller-info-text") ||
        _0x59af90["querySelector"](".s-item__etrs-text") ||
        document["querySelector"](".s-item__etrs-text") ||
        _0x59af90["querySelector"](
          ".su-card-container__attributes__secondary\x20.secondary",
        );
}
function _0x2d977a(_0x4e2d22) {
  var _0x34bfc7 = _0x102614(_0x4e2d22),
    _0x3b3cce = _0x34bfc7 ? _0x34bfc7["innerText"] : null;
  return (
    (_0x3b3cce = (_0x3b3cce = _0x3b3cce["split"]("(")[0x0])["trim"]())[
      "includes"
    ]("%") && (_0x3b3cce = _0x3b3cce["replace"](/[\d.,]+%.*$/, "")["trim"]()),
    _0x3b3cce
  );
}
function _0x31c56a() {
  const _0x2b0111 = _0x44d2fb(),
    _0x3ff1f8 = [];
  for (let _0x4865c1 = 0x0; _0x4865c1 < _0x2b0111["length"]; _0x4865c1++) {
    const _0x106609 = _0x2b0111[_0x4865c1];
    var _0x47540b;
    try {
      _0x47540b = _0x150388(_0x106609, _0x4865c1);
    } catch (_0x11f2c7) {
      console["error"]("Error\x20extracting\x20item\x20data:", _0x11f2c7);
      continue;
    }
    _0x3ff1f8["push"](_0x47540b);
  }
  return _0x3ff1f8;
}
function _0x40ce79(_0x6cd923, _0x4545d1) {
  console["log"]("Received\x20itemNumber:", _0x6cd923);
  let _0x1f672a = parseInt(_0x6cd923);
  console["log"](
    "Item\x20number\x20after\x20conversion\x20to\x20integer:",
    _0x1f672a,
  );
  for (let _0x4b5863 = 0x0; _0x4b5863 < _0x4545d1["length"]; _0x4b5863++) {
    const _0x495042 = _0x4545d1[_0x4b5863];
    (console["log"]("Item\x20" + (_0x4b5863 + 0x1) + ":", _0x495042),
      console["log"](
        "Item\x27s\x20number\x20in\x20data\x20before\x20conversion\x20to\x20integer:",
        _0x495042["itemNumber"],
      ));
    let _0x2b29b9 = parseInt(_0x495042["itemNumber"]);
    console["log"](
      "Item\x27s\x20number\x20in\x20data\x20after\x20conversion\x20to\x20integer:",
      _0x2b29b9,
    );
    if (Number["isNaN"](_0x1f672a) || Number["isNaN"](_0x2b29b9)) {
      console["log"](
        "Integer\x20conversion\x20failed.\x20Falling\x20back\x20to\x20string\x20comparison.",
      );
      let _0x450322 = String(_0x6cd923)["trim"]();
      console["log"]("Trimmed\x20input\x20item\x20number:", _0x450322);
      let _0x40df1e = String(_0x495042["itemNumber"])["trim"]();
      console["log"]("Trimmed\x20item\x20number\x20from\x20data:", _0x40df1e);
      if (_0x40df1e === _0x450322)
        return (
          console["log"]("Item\x20found\x20using\x20string\x20comparison."),
          _0x495042
        );
    } else {
      console["log"]("Comparing\x20integers:", _0x2b29b9, _0x1f672a);
      if (_0x2b29b9 === _0x1f672a)
        return (
          console["log"]("Item\x20found\x20using\x20integer\x20comparison."),
          _0x495042
        );
    }
  }
  return (console["log"]("No\x20matching\x20item\x20found."), null);
}
function _0x1c3c23() {
  var _0x515629 = document["createElement"]("button");
  return (
    _0x515629["setAttribute"]("class", "btn-sort-by-total-sold"),
    _0x515629["classList"]["add"]("filter-date-context"),
    (_0x515629["id"] = "btn-sort-by-total-sold"),
    (_0x515629["innerHTML"] = "Total\x20Sold"),
    _0x515629["addEventListener"]("click", function (_0x473829) {
      _0x55f2e7();
    }),
    _0x515629
  );
}
async function _0x55f2e7() {
  var _0x36072e = document["querySelectorAll"]("li");
  console["log"]("items", _0x36072e);
  var _0x575e24 = Array["from"](_0x36072e);
  (console["log"]("itemsArray", _0x575e24),
    (_0x575e24 = _0x575e24["filter"]((_0x451e35) =>
      _0x451e35["querySelector"](_0x396b13()),
    )),
    console["log"](
      "removed\x20any\x20element\x20that\x20doesnt\x20have\x20s-item__caption-section",
      _0x575e24,
    ),
    (_0x575e24 = _0x575e24["filter"]((_0x4cc748) =>
      _0x4cc748["querySelector"](".total-sold-element"),
    )),
    console["log"](
      "removed\x20any\x20item\x20that\x20doesnt\x20have\x20data-total-sold\x20attribute",
      _0x575e24,
    ));
  var { selectedFilter: _0x4f4e04 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (_0x575e24["sort"]((_0x370eec, _0x1cc289) => {
    (console["log"]("a", _0x370eec), console["log"]("b", _0x1cc289));
    var _0x5a4fdf = _0x370eec["querySelector"](
        ".total-sold-element[data-last-x-days=\x22" + _0x4f4e04 + "\x22]",
      )["getAttribute"]("data-total-sold"),
      _0x4aa189 = _0x1cc289["querySelector"](
        ".total-sold-element[data-last-x-days=\x22" + _0x4f4e04 + "\x22]",
      )["getAttribute"]("data-total-sold");
    return "Rate\x20Limited" == _0x5a4fdf || "Rate\x20Limited" == _0x4aa189
      ? 0x0
      : _0x4aa189 - _0x5a4fdf;
  }),
    console["log"]("itemsArray", _0x575e24),
    _0x575e24["reverse"]());
  var _0x3dd135 = _0x575e24[0x0]["parentNode"];
  _0x575e24["forEach"]((_0x170945) =>
    _0x3dd135["insertBefore"](
      _0x170945,
      _0x3dd135["firstChild"]["nextSibling"],
    ),
  );
}
function _0x1fc8a5() {
  var _0x3df31c = document["createElement"]("button");
  return (
    _0x3df31c["setAttribute"]("class", "btn-sort-by-sold-date"),
    (_0x3df31c["id"] = "btn-sort-by-sold-date"),
    (_0x3df31c["innerHTML"] = "Sold\x20Date"),
    _0x3df31c["addEventListener"]("click", function (_0x12dd7b) {
      _0x34b665();
    }),
    _0x3df31c
  );
}
function _0x34b665() {
  var _0x545bd7 = document["querySelectorAll"]("li"),
    _0x338ff7 = Array["from"](_0x545bd7);
  ((_0x338ff7 = _0x338ff7["filter"]((_0x4961aa) =>
    _0x4961aa["querySelector"](_0x396b13()),
  )),
    console["log"]("itemsArray", _0x338ff7),
    _0x338ff7["sort"]((_0x4a0e15, _0x22c8d9) => {
      (console["log"]("a", _0x4a0e15), console["log"]("b", _0x22c8d9));
      var _0x4bbb82 = _0x2cec01(_0x4a0e15),
        _0x6d16f8 = _0x2cec01(_0x22c8d9);
      (console["log"]("aDateSold", _0x4bbb82),
        console["log"]("bDateSold", _0x6d16f8));
      if (null == _0x4bbb82 || null == _0x6d16f8) return 0x0;
      var _0x2ecb62 = new Date(_0x4bbb82);
      return new Date(_0x6d16f8) - _0x2ecb62;
    }),
    _0x338ff7["reverse"]());
  var _0x3db83b = _0x338ff7[0x0]["parentNode"];
  (_0x338ff7["forEach"]((_0x27a306) =>
    _0x3db83b["insertBefore"](
      _0x27a306,
      _0x3db83b["firstChild"]["nextSibling"],
    ),
  ),
    console["log"]("itemsArray", _0x338ff7));
}
function _0x2cec01(_0x2e97d7) {
  var _0x11b058 = _0x2e97d7["querySelector"](
    ".s-item__title--tag\x20.POSITIVE",
  );
  null === _0x11b058 &&
    (_0x11b058 = _0x2e97d7["querySelector"](
      ".s-item__caption--signal.POSITIVE",
    ));
  var _0xe5c0f;
  _0xe5c0f =
    null !== _0x11b058
      ? (_0xe5c0f = (_0xe5c0f = _0x11b058["textContent"])["replace"](
          "Sold",
          "",
        ))["trim"]()
      : null;
  var _0x1ca721 = new Date(_0xe5c0f),
    _0x5ceb31 = (new Date() - _0x1ca721) / 0x5265c00;
  return (console["log"]("daysDifference", _0x5ceb31), _0xe5c0f);
}
function _0x3a7b2e() {
  var _0x5b02af = document["querySelectorAll"]("li"),
    _0x4f82f0 = Array["from"](_0x5b02af);
  ((_0x4f82f0 = (_0x4f82f0 = _0x4f82f0["filter"]((_0x51dce2) =>
    _0x51dce2["querySelector"](".s-item__price"),
  ))["filter"]((_0x236e0d) => _0x236e0d["id"]["startsWith"]("item")))["sort"](
    (_0x1029e3, _0x2ac05) => {
      (console["log"]("a", _0x1029e3), console["log"]("b", _0x2ac05));
      var _0x37054b =
          _0x1029e3["querySelector"](".s-item__price")["textContent"],
        _0x5b9955 = _0x2ac05["querySelector"](".s-item__price")["textContent"];
      return (
        (_0x37054b = _0x37054b["replace"]("$", "")),
        (_0x5b9955 = _0x5b9955["replace"]("$", "")),
        (_0x37054b = _0x37054b["replace"](/[^0-9.]/g, "")),
        (_0x5b9955 = _0x5b9955["replace"](/[^0-9.]/g, "")),
        (_0x37054b = parseFloat(_0x37054b)) - parseFloat(_0x5b9955)
      );
    },
  ),
    _0x4f82f0["reverse"]());
  var _0x1b320b = _0x4f82f0[0x0]["parentNode"];
  _0x4f82f0["forEach"]((_0x44a238) =>
    _0x1b320b["insertBefore"](
      _0x44a238,
      _0x1b320b["firstChild"]["nextSibling"],
    ),
  );
}
function _0x4a711c() {
  var _0x5378fa = document["querySelectorAll"]("li"),
    _0x27c1b8 = Array["from"](_0x5378fa);
  ((_0x27c1b8 = (_0x27c1b8 = _0x27c1b8["filter"]((_0x1888d7) =>
    _0x1888d7["querySelector"](".s-item__price"),
  ))["filter"]((_0x21a7e2) => _0x21a7e2["id"]["startsWith"]("item")))["sort"](
    (_0x475669, _0x26d9c7) => {
      (console["log"]("a", _0x475669), console["log"]("b", _0x26d9c7));
      var _0x40cd66 =
          _0x475669["querySelector"](".s-item__price")["textContent"],
        _0x14b3da = _0x26d9c7["querySelector"](".s-item__price")["textContent"];
      return (
        (_0x40cd66 = _0x40cd66["replace"]("$", "")),
        (_0x14b3da = _0x14b3da["replace"]("$", "")),
        (_0x40cd66 = _0x40cd66["replace"](/[^0-9.]/g, "")),
        (_0x14b3da = _0x14b3da["replace"](/[^0-9.]/g, "")),
        (_0x40cd66 = parseFloat(_0x40cd66)),
        (_0x14b3da = parseFloat(_0x14b3da)) - _0x40cd66
      );
    },
  ),
    _0x27c1b8["reverse"]());
  var _0x5637f0 = _0x27c1b8[0x0]["parentNode"];
  _0x27c1b8["forEach"]((_0x115dbb) =>
    _0x5637f0["insertBefore"](
      _0x115dbb,
      _0x5637f0["firstChild"]["nextSibling"],
    ),
  );
}
function _0xfc1ea() {
  var _0x55c793 = document["createElement"]("button");
  return (
    _0x55c793["setAttribute"]("class", "btn-sort-by-lowest-price"),
    (_0x55c793["id"] = "btn-sort-by-lowest-price"),
    (_0x55c793["innerHTML"] = "Lowest\x20Price"),
    _0x55c793["setAttribute"]("data-sort", "lowest-price"),
    _0x55c793["addEventListener"]("click", function (_0x3974ea) {
      "lowest-price" == _0x55c793["getAttribute"]("data-sort")
        ? (_0x3a7b2e(),
          _0x55c793["setAttribute"]("data-sort", "highest-price"),
          (_0x55c793["innerHTML"] = "Highest\x20Price"))
        : (_0x4a711c(),
          _0x55c793["setAttribute"]("data-sort", "lowest-price"),
          (_0x55c793["innerHTML"] = "Lowest\x20Price"));
    }),
    _0x55c793
  );
}
function _0x7d53d4(_0x41f902) {
  var _0xc943c8 = _0x102614(_0x41f902);
  const _0x48c737 = _0xc943c8?.["textContent"]["match"](/\(([^)]+)\)/),
    _0x5eb3e4 = _0x48c737?.[0x1]?.["trim"]() || null;
  if (_0x5eb3e4 && _0x5eb3e4["toLowerCase"]()["includes"]("k")) {
    const _0x38bd4f = _0x5eb3e4["match"](/[\d,]+/);
    if (_0x38bd4f)
      return 0x3e8 * parseInt(_0x38bd4f[0x0]["replace"](/,/g, ""), 0xa);
  }
  if (!_0x5eb3e4) return null;
  const _0x215320 = _0x5eb3e4["replace"](/[.,](?=\d{3}\b)/g, "")["replace"](
      /[,\.]\d+$/,
      "",
    ),
    _0x27a2e3 = parseInt(_0x215320, 0xa);
  return isNaN(_0x27a2e3) ? null : _0x27a2e3;
}
function _0x3b1017(_0xde8ddb) {
  var _0x427164 = _0x102614(_0xde8ddb),
    _0x5579b6 = _0x427164?.["textContent"]["match"](
      /(\d{1,3}(?:[.,]\d{1,3})?)\s*%/,
    ),
    _0x786181 = null;
  return (
    _0x5579b6
      ? (_0x786181 = _0x5579b6[0x1]["replace"](",", "."))
      : console["warn"](
          "No\x20feedback\x20percent\x20found\x20in\x20username\x20element:",
          _0x427164,
        ),
    _0x786181
  );
}
console["log"]("ebay/store_search/functions.js\x20loaded");
var _0x35aca1 = !0x1,
  _0x581054 = 0x1f4;
function _0x4da526() {
  var _0x44379d = document["createElement"]("button");
  return (
    _0x44379d["setAttribute"]("class", "btn-extract-all"),
    (_0x44379d["id"] = "btn-extract-all"),
    (_0x44379d["innerHTML"] = "Extract\x20All\x20Titles"),
    _0x44379d["addEventListener"]("click", async function (_0x33b411) {
      _0x33b411["preventDefault"]();
      var { run_status_extract_titles: _0x39d69b } = await chrome["storage"][
        "local"
      ]["get"]("run_status_extract_titles");
      if (null == _0x39d69b || 0x0 == _0x39d69b)
        ((_0x39d69b = !0x0),
          _0x44379d["classList"]["remove"]("btn-extract-all"),
          _0x44379d["classList"]["add"]("btn-stop-extract-all"),
          (_0x44379d["innerHTML"] = "Stop\x20Extracting\x20Titles"));
      else
        0x1 == _0x39d69b &&
          (_0x44379d["classList"]["remove"]("btn-stop-extract-all"),
          _0x44379d["classList"]["add"]("btn-extract-all"),
          (_0x44379d["innerHTML"] = "Extract\x20All\x20Titles"),
          (_0x39d69b = !0x1));
      (chrome["storage"]["local"]["set"]({
        run_status_extract_titles: _0x39d69b,
      }),
        console["log"]("run_status_extract_titles", _0x39d69b),
        _0x1dc30a());
    }),
    _0x44379d
  );
}
async function fetchSoldDataBasedOnSelection() {
  try {
    var { selectedFetchMethod: _0x42b9e1 } = await chrome["storage"]["local"][
      "get"
    ]("selectedFetchMethod");
    ("none" == _0x42b9e1 &&
      console["log"]("No\x20fetch\x20method\x20selected."),
      "sequential" == _0x42b9e1 &&
        (console["log"]("Fetching\x20data\x20sequentially."),
        await fetchSoldDataSequentially()),
      "concurrent" == _0x42b9e1 &&
        (console["log"]("Fetching\x20data\x20concurrently."),
        await fetchSoldDataConcurrently()),
      "sequential-purchase-history" == _0x42b9e1 &&
        (console["log"](
          "Fetching\x20data\x20sequentially\x20via\x20purchase\x20history.",
        ),
        await fetchSoldDataSequentiallyViaPurchaseHistory()),
      "concurrent-purchase-history" == _0x42b9e1 &&
        (console["log"](
          "Fetching\x20data\x20concurrently\x20via\x20purchase\x20history.",
        ),
        await fetchSoldDataConcurrentlyViaPurchaseHistory()));
  } catch (_0x1731e4) {
    console["error"](
      "An\x20error\x20occurred\x20while\x20fetching\x20sold\x20data:\x20",
      _0x1731e4,
    );
  }
}
function _0x28f974() {
  var _0x52b137 = document["createElement"]("button");
  return (
    _0x52b137["setAttribute"]("class", "btn-clear-all-titles"),
    (_0x52b137["innerHTML"] = "Clear\x20Titles"),
    chrome["storage"]["local"]["get"](
      "savedEbaySearchItems",
      function (_0x3b4279) {
        _0x52b137["innerHTML"] =
          "Clear\x20Titles\x20(" +
          _0x3b4279["savedEbaySearchItems"]["length"] +
          ")";
      },
    ),
    _0x52b137["addEventListener"]("click", function (_0x5bc1ca) {
      (chrome["storage"]["local"]["set"]({ savedEbaySearchItems: [] }),
        (_0x52b137["innerHTML"] = "Titles\x20Cleared\x20✔️"),
        setTimeout(function () {
          _0x52b137["innerHTML"] = "Clear\x20Titles";
        }, 0xbb8));
    }),
    _0x52b137
  );
}
async function _0x1dc30a() {
  console["log"]("extractAllTitles()");
  var _0x218838 = !0x0;
  (console["log"]("run_status_extract_titles", _0x218838),
    (document["title"] = "🔥\x20Extracting\x20Titles\x20🔥"));
  try {
    await fetchSoldDataBasedOnSelection();
  } catch (_0x18af57) {
    console["log"]("error", _0x18af57);
  }
  try {
    _0x55f2e7();
  } catch (_0x1a22ff) {
    console["log"]("error", _0x1a22ff);
  }
  var _0x2e9ed8 = _0x31c56a();
  console["log"]("ebaySearchItems", _0x2e9ed8);
  var { savedEbaySearchItems: _0x2baccc } = await chrome["storage"]["local"][
    "get"
  ]("savedEbaySearchItems");
  (null == _0x2baccc && (_0x2baccc = []),
    (_0x2baccc = (_0x2baccc = _0x2baccc["concat"](_0x2e9ed8))["filter"](
      (_0x107f4a, _0x2552fc, _0x569adf) =>
        _0x569adf["findIndex"](
          (_0x4d787b) => _0x4d787b["title"] === _0x107f4a["title"],
        ) === _0x2552fc,
    )),
    chrome["storage"]["local"]["set"]({ savedEbaySearchItems: _0x2baccc }));
  var _0x462451 = await _0x4a7b0b();
  await new Promise((_0x3b367a) => setTimeout(_0x3b367a, 0xbb8));
  var { run_status_extract_titles: _0x218838 } = await chrome["storage"][
    "local"
  ]["get"]("run_status_extract_titles");
  console["log"]("doesNextPageExist", _0x462451);
  var { scrapeAllPages: _0x3bc2c0 } =
    await chrome["storage"]["local"]["get"]("scrapeAllPages");
  if (0x1 == _0x462451 && 0x1 == _0x218838 && 0x1 == _0x3bc2c0)
    (console["log"]("doesNextPageExist\x20==\x20true"),
      document["getElementsByClassName"]("pagination__next")[0x0]["click"]());
  else {
    if (0x0 == _0x462451 || 0x0 == _0x3bc2c0) {
      console["log"]("doesNextPageExist\x20==\x20false");
      var _0x5a27db = document["getElementById"]("btn-extract-all");
      (_0x5a27db["classList"]["remove"]("btn-stop-extract-all"),
        _0x5a27db["classList"]["add"]("btn-extract-all"),
        (_0x5a27db["innerHTML"] = "Complete!"),
        (document["getElementsByClassName"]("btn-clear-all-titles")[0x0][
          "innerHTML"
        ] = "Clear\x20Titles\x20(" + _0x2baccc["length"] + ")"),
        (document["title"] = "Completed\x20Extraction!\x20✔️"),
        (_0x218838 = !0x1),
        chrome["storage"]["local"]["set"]({
          run_status_extract_titles: _0x218838,
        }),
        await new Promise((_0xfe038) => setTimeout(_0xfe038, 0xbb8)),
        (_0x5a27db["innerHTML"] = "Extract\x20All\x20Titles"));
    }
  }
}
function filterEbaySearchItemsByDate(_0x19daf0, _0x3d344f) {
  if ("default" == _0x3d344f) return _0x19daf0;
  var _0x8dac7e = new Date(),
    _0x58e277 = new Date();
  return (
    _0x58e277["setDate"](_0x58e277["getDate"]() - _0x3d344f),
    _0x19daf0["filter"](function (_0x1826bb) {
      var _0x3e4f3c = new Date(_0x1826bb["dateSold"]);
      return _0x3e4f3c >= _0x58e277 && _0x3e4f3c <= _0x8dac7e;
    })
  );
}
function _0x4a7b0b() {
  return new Promise((_0x984834, _0x4a9b76) => {
    var _0x34c57f = document["getElementsByClassName"]("pagination__next")[0x0];
    (null == _0x34c57f && _0x984834(!0x1),
      _0x984834("true" != _0x34c57f["getAttribute"]("aria-disabled")));
  });
}
function _0x87eee4() {
  var _0x34a5d8 = document["createElement"]("button");
  return (
    _0x34a5d8["setAttribute"]("class", "btn-show-all-titles"),
    (_0x34a5d8["innerHTML"] = "Filter\x20Titles"),
    _0x34a5d8["addEventListener"]("click", function (_0x1372d5) {
      chrome["runtime"]["sendMessage"]({ type: "openSortEbayItems" });
    }),
    _0x34a5d8
  );
}
async function _0x41385b() {
  var { savedEbaySearchItems: _0x482817 } = await chrome["storage"]["local"][
      "get"
    ]("savedEbaySearchItems"),
    _0x555030 = [];
  for (var _0x30e6f = 0x0; _0x30e6f < _0x482817["length"]; _0x30e6f++)
    _0x555030["push"](_0x482817[_0x30e6f]["title"]);
  (console["log"](_0x555030),
    _0x3c252f((_0x555030 = _0x555030["join"]("\x0a"))),
    _0x3cc1e7(),
    _0x4570a5(_0x555030));
}
function _0x5b3c06(_0x53bb67, _0x1d5808, _0x8b0d60 = "") {
  const _0x188499 = document["createElement"](_0x53bb67);
  return (
    (_0x188499["id"] = _0x1d5808),
    (_0x188499["innerHTML"] = _0x8b0d60),
    _0x188499
  );
}
function _0xac3970(_0x85f04, _0xc7899d) {
  _0xc7899d["forEach"]((_0x2a0871) => _0x85f04["appendChild"](_0x2a0871));
}
function _0x3c252f(_0x39b0f3) {
  const _0x22fce0 = _0x5b3c06("div", "keyword_modal"),
    _0x5b8d54 = _0x5b3c06("div", "keyword_modal_content"),
    _0x10270b = _0x5b3c06("div", "keyword_modal_header"),
    _0x4b83cc = _0x5b3c06("div", "keyword_modal_body"),
    _0x583ea4 = _0x5b3c06("div", "keyword_modal_footer"),
    _0x2e2cc6 = _0x5b3c06("span", "keyword_modal_close", "&times;");
  _0x10270b["appendChild"](_0x2e2cc6);
  const _0x58112e = _0x5b3c06(
    "p",
    "keyword_info",
    "Loaded\x20" + _0x39b0f3["split"]("\x0a")["length"] + "\x20keywords",
  );
  _0x4b83cc["appendChild"](_0x58112e);
  const _0x527e3c = _0x5b3c06("textarea", "keyword_textarea");
  ((_0x527e3c["value"] = _0x39b0f3),
    (_0x527e3c["style"]["width"] = "100%"),
    _0x4b83cc["appendChild"](_0x527e3c));
  const _0x1470e5 = _0x5b3c06(
    "button",
    "copy_keywords_button",
    "Copy\x20All\x20Keywords",
  );
  ((_0x1470e5["style"]["display"] = "block"),
    (_0x1470e5["style"]["margin"] = "auto"),
    _0x583ea4["appendChild"](_0x1470e5),
    _0xac3970(_0x5b8d54, [_0x10270b, _0x4b83cc, _0x583ea4]),
    _0x22fce0["appendChild"](_0x5b8d54),
    document["body"]["appendChild"](_0x22fce0),
    (_0x22fce0["style"]["display"] = "block"));
}
function _0x3cc1e7() {
  document["getElementById"]("keyword_modal_close")["addEventListener"](
    "click",
    function () {
      document["getElementById"]("keyword_modal")["remove"]();
    },
  );
}
function _0x4570a5(_0x4c7946) {
  const _0x1f94ba = document["getElementById"]("copy_keywords_button");
  _0x1f94ba["addEventListener"]("click", function () {
    (navigator["clipboard"]["writeText"](_0x4c7946),
      (_0x1f94ba["innerHTML"] = "Copied!"));
  });
}
async function _0x2a3b25() {
  var _0x4279cc = document["createElement"]("select");
  ((_0x4279cc["id"] = "filter-dropdown"),
    _0x4279cc["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "Select\x20Filter", value: "default" },
      { text: "Last\x201\x20Day", value: "1" },
      { text: "Last\x203\x20Days", value: "3" },
      { text: "Last\x207\x20Days", value: "7" },
      { text: "Last\x2014\x20Days", value: "14" },
      { text: "Last\x2021\x20Days", value: "21" },
      { text: "Last\x2030\x20Days", value: "30" },
      { text: "Last\x2060\x20Days", value: "60" },
      { text: "Last\x2090\x20Days", value: "90" },
    ]["forEach"]((_0x2c4d15) => {
      var _0x55a555 = document["createElement"]("option");
      ((_0x55a555["value"] = _0x2c4d15["value"]),
        (_0x55a555["innerText"] = _0x2c4d15["text"]),
        _0x4279cc["appendChild"](_0x55a555));
    }));
  let { selectedFilter: _0x3bf7ea } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  !_0x3bf7ea &&
    ((_0x3bf7ea = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: _0x3bf7ea }));
  ((_0x4279cc["value"] = _0x3bf7ea),
    _0x4279cc["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        selectedFilter: this["value"],
      }),
        console["log"]("Filter\x20saved:\x20" + this["value"]));
    }));
  var _0x5f4633 = document["createElement"]("label");
  _0x5f4633["innerText"] =
    "Only\x20Scan\x20Items\x20That\x20Sold\x20within:\x20";
  var _0x2e0e22 = document["createElement"]("div");
  return (
    _0x2e0e22["setAttribute"]("class", "filter-dropdown-div"),
    (_0x2e0e22["id"] = "filter-dropdown-container"),
    _0x2e0e22["appendChild"](_0x5f4633),
    _0x2e0e22["appendChild"](_0x4279cc),
    _0x2e0e22
  );
}
function _0xb84d90() {
  var _0x85502a = document["createElement"]("button");
  return (
    _0x85502a["setAttribute"]("class", "btn-terapeak-search"),
    (_0x85502a["innerHTML"] = "Find\x20Total\x20Sold\x20&\x20Competitors"),
    (_0x85502a["style"]["display"] = "none"),
    _0x85502a["addEventListener"]("click", async function (_0x1b652f) {
      _0x1b652f["preventDefault"]();
      let _0x122611 = _0x1b652f["target"];
      for (; _0x122611 && !_0x122611["classList"]["contains"]("s-item"); )
        _0x122611 = _0x122611["parentElement"];
      _0x122611 &&
        (console["log"]("item", _0x122611),
        await _0x1f78d1(_0x122611),
        _0x3c94aa());
    }),
    _0x85502a
  );
}
async function _0x42f28f() {
  document["querySelector"](".s-item__wrapper");
}
async function _0x4ba8be(_0xd87064, _0x3d76f9) {
  var _0x5dfe20 = _0xd87064["querySelector"](".s-item__itemID")["textContent"];
  ((_0x5dfe20 = (_0x5dfe20 = _0x5dfe20["split"]("Item:\x20")[0x1])["replace"](
    /\s/g,
    "",
  )),
    console["log"]("itemNumber", _0x5dfe20));
  var _0x546de1 = await chrome["runtime"]["sendMessage"]({
    type: "checkPurchaseHistory",
    itemNumber: _0x5dfe20,
    lastXDays: _0x3d76f9,
  });
  return (console["log"]("response", _0x546de1), _0x546de1["totalSold"]);
}
async function _0x4ad6f8(
  _0x5850b5,
  _0x5202e0,
  _0x3675a1 = !0x0,
  _0x194d69 = !0x1,
) {
  console["log"]("item", _0x5850b5);
  var _0x3ef2ce;
  try {
    var _0x444733 = _0x5850b5["querySelector"](".s-item__itemID");
    (_0x444733 ||
      (_0x444733 = (_0x444733 = (_0x444733 = _0x5850b5["querySelector"](
        ".su-card-container__attributes__secondary",
      ))["querySelectorAll"](".s-card__attribute-row"))[
        _0x444733["length"] - 0x1
      ]),
      (_0x3ef2ce = _0x444733["textContent"]));
  } catch (_0x284c8f) {
    console["log"]("error", _0x284c8f);
    return;
  }
  (console["log"]("itemNumber", _0x3ef2ce),
    (_0x3ef2ce = _0x3ef2ce["split"](":")[0x1]),
    console["log"]("itemNumber", _0x3ef2ce),
    (_0x3ef2ce = _0x3ef2ce["replace"](/\s/g, "")));
  var _0x3f77b0 = _0x3777ec(_0x5850b5);
  console["log"]("soldDateElement", _0x3f77b0);
  var _0x490f34;
  if (null !== _0x3f77b0)
    ((_0x490f34 = _0x3f77b0["textContent"]),
      console["log"]("soldDate", _0x490f34),
      (_0x490f34 = (_0x490f34 = _0x490f34["split"]("\x20")
        ["slice"](0x1)
        ["join"]("\x20"))["trim"]()));
  else _0x490f34 = null;
  (console["log"]("soldDate\x20before\x20parse", _0x490f34),
    (_0x490f34 = _0x3ee773(_0x490f34)),
    console["log"]("soldDate\x20after\x20parse", _0x490f34));
  var _0x43b24f = new Date(_0x490f34);
  console["log"]("dateSold", _0x43b24f);
  var _0x49a6bf = (new Date() - _0x43b24f) / 0x5265c00;
  console["log"]("daysDifference", _0x49a6bf);
  var _0x4dde43 = 0x0;
  if (_0x49a6bf > _0x5202e0 && !_0x194d69)
    console["log"]("daysDifference\x20>\x20lastXDays");
  else
    try {
      var _0x23fcbb = await chrome["runtime"]["sendMessage"]({
        type: "checkPurchaseHistory",
        itemNumber: _0x3ef2ce,
        lastXDays: _0x5202e0,
        closeTabAfterSearch: _0x3675a1,
      });
      (console["log"]("response", _0x23fcbb),
        (_0x4dde43 = _0x23fcbb["totalSold"]));
    } catch (_0x305e07) {
      (console["log"]("error", _0x305e07), (_0x4dde43 = -0x3e7));
    }
  var _0xe636c5 = {
    0x1: _0x4dde43["totalSoldIn1"],
    0x3: _0x4dde43["totalSoldIn3"],
    0x7: _0x4dde43["totalSoldIn7"],
    0xe: _0x4dde43["totalSoldIn14"],
    0x1e: _0x4dde43["totalSoldIn30"],
    0x3c: _0x4dde43["totalSoldIn60"],
    0x5a: _0x4dde43["totalSoldIn90"],
  };
  const _0x12d943 = [0x1, 0x3, 0x7, 0xe, 0x1e, 0x3c, 0x5a];
  let _0x4ea84b = !0x0;
  for (let _0x640a69 of _0x12d943)
    if (
      void 0x0 !== _0xe636c5[_0x640a69] &&
      "undefined" !== _0xe636c5[_0x640a69]
    ) {
      _0x4ea84b = !0x1;
      break;
    }
  _0x4dde43 = document["createElement"]("p");
  if (_0x4ea84b)
    ((_0x4dde43["innerHTML"] =
      "<strong>Total\x20Sold:</strong>\x20Not\x20Available"),
      _0x5850b5["appendChild"](_0x4dde43));
  else {
    var _0x56785b = document["createElement"]("table");
    _0x56785b["className"] = "total-sold-table";
    var _0x1961c4 = document["createElement"]("tr");
    ((_0x1961c4["innerHTML"] =
      "<th>Last\x20X\x20Days</th><th>Total\x20Sold</th>"),
      _0x56785b["appendChild"](_0x1961c4),
      _0x12d943["forEach"]((_0xff9874) => {
        var _0xd96cdd = document["createElement"]("tr");
        (_0xd96cdd["setAttribute"]("class", "total-sold-element"),
          _0xd96cdd["setAttribute"]("data-last-x-days", _0xff9874),
          _0xd96cdd["setAttribute"](
            "data-total-sold",
            "undefined" !== _0xe636c5[_0xff9874]
              ? _0xe636c5[_0xff9874]
              : "Not\x20Available",
          ),
          (_0xd96cdd["innerHTML"] =
            "<td\x20>" +
            _0xff9874 +
            "</td><td><b\x20style=\x22color:red;\x22>" +
            ("undefined" !== _0xe636c5[_0xff9874]
              ? _0xe636c5[_0xff9874]
              : "Not\x20Available") +
            "</b></td>"),
          _0x56785b["appendChild"](_0xd96cdd));
      }),
      _0x5850b5["appendChild"](_0x56785b));
  }
  setTimeout(() => {
    try {
      _0x56785b["classList"]["add"]("show-element");
    } catch (_0x2039dc) {
      console["log"]("error", _0x2039dc);
    }
    try {
      _0x56785b["querySelectorAll"]("tr")["forEach"](function (_0x4afabb) {
        _0x4afabb["classList"]["add"]("show-element");
      });
    } catch (_0x39d604) {
      console["log"]("error", _0x39d604);
    }
    try {
      _0x4dde43["classList"]["add"]("show-element");
    } catch (_0x45fa4b) {
      console["log"]("error", _0x45fa4b);
    }
  }, 0x0);
}
function _0x35d1f3(_0xb40b9b, _0x11a68e) {
  var _0x20014b = document["createElement"]("div");
  return (
    _0x20014b["setAttribute"]("class", "total-sold-element"),
    _0x20014b["setAttribute"]("data-total-sold", _0xb40b9b),
    _0x20014b["setAttribute"]("data-last-x-days", _0x11a68e),
    (_0x20014b["innerHTML"] =
      -0x3e7 == _0xb40b9b
        ? "Total\x20Sold:\x20<b\x20style=\x22color:red;\x22>\x20Error\x20Occurred\x20</b>"
        : "Total\x20Sold:\x20<b\x20style=\x22color:red;\x22>\x20" +
          _0xb40b9b +
          "\x20</b>\x20(Last\x20<b>\x20" +
          _0x11a68e +
          "\x20</b>\x20Days)"),
    _0x20014b
  );
}
async function _0x1f78d1(_0x5dad3a) {
  var _0x5a467b = _0x5dad3a["querySelector"](".s-item__title")["textContent"];
  if (
    "" != _0x5a467b &&
    null != _0x5a467b &&
    null != _0x5a467b &&
    "Shop\x20on\x20eBay" != _0x5a467b
  ) {
    console["log"]("title:", _0x5a467b);
    var _0x355f17 = await _0x21e54d(_0x5a467b),
      _0x2b980e = _0x355f17["totalSold"],
      _0x1a8a1b = _0x355f17["totalCompetitors"],
      _0x63e3e4 = document["createElement"]("div");
    (_0x63e3e4["setAttribute"]("class", "total-sold-element"),
      _0x63e3e4["setAttribute"]("data-total-sold", _0x2b980e),
      (_0x63e3e4["innerHTML"] = "Total\x20Sold:\x20" + _0x2b980e),
      _0x5dad3a["appendChild"](_0x63e3e4));
    var _0xef9999 = document["createElement"]("div");
    (_0xef9999["setAttribute"]("class", "total-competitors-element"),
      _0xef9999["setAttribute"]("data-total-competitors", _0x1a8a1b),
      (_0xef9999["innerHTML"] = "Total\x20Competitors:\x20" + _0x1a8a1b),
      _0x5dad3a["appendChild"](_0xef9999),
      setTimeout(() => {
        (_0x63e3e4["classList"]["add"]("show-element"),
          _0xef9999["classList"]["add"]("show-element"));
      }, 0x0));
  }
}
async function _0x21e54d(_0x5e0ec1) {
  if (!0x0 === _0x35aca1)
    return (
      _0x360b65(),
      (_0x581054 = 0x32),
      { totalSold: "Rate\x20Limited", totalCompetitors: "Rate\x20Limited" }
    );
  var _0x3b979c = await chrome["runtime"]["sendMessage"]({
    type: "searchTitleOnTeraPeak",
    title: _0x5e0ec1,
  });
  console["log"]("response", _0x3b979c);
  try {
    var _0x2b0da3 = _0x3b979c["response"]["soldData"];
    (console["log"]("soldData", _0x2b0da3), _0x3c94aa());
  } catch (_0x215d74) {
    return (
      console["log"]("error", _0x215d74),
      (_0x35aca1 = !0x0),
      _0x360b65(),
      (_0x581054 = 0x32),
      { totalSold: "Rate\x20Limited", totalCompetitors: "Rate\x20Limited" }
    );
  }
  return _0x2b0da3;
}
function _0x360b65() {
  if (document["querySelector"](".overlay")) return;
  const _0x3935d0 = document["createElement"]("div");
  _0x3935d0["classList"]["add"]("overlay");
  const _0x2a31e9 = document["createElement"]("div");
  (_0x2a31e9["classList"]["add"]("text"),
    (_0x2a31e9["textContent"] =
      "Rate\x20Limit\x20Reached,\x20I\x20know\x20it\x20sucks\x20😭,\x20Try\x20again\x20in\x20a\x20bit!"),
    _0x3935d0["appendChild"](_0x2a31e9));
  var _0xbbfca0 = document["createElement"]("button");
  (_0xbbfca0["setAttribute"]("class", "btn-stop-extract-all"),
    (_0xbbfca0["innerHTML"] = "Stop\x20Extracting\x20Titles"),
    _0xbbfca0["addEventListener"]("click", function (_0x49482e) {
      _0x49482e["preventDefault"]();
      var _0x23c3a6 = document["getElementById"]("btn-extract-all");
      (_0x23c3a6["classList"]["remove"]("btn-stop-extract-all"),
        _0x23c3a6["classList"]["add"]("btn-extract-all"),
        (_0x23c3a6["innerHTML"] = "Extract\x20All\x20Titles"),
        (run_status_extract_titles = !0x1),
        chrome["storage"]["local"]["set"]({
          run_status_extract_titles: run_status_extract_titles,
        }),
        (_0xbbfca0["innerHTML"] = "Please\x20Wait..."));
    }),
    _0x3935d0["appendChild"](_0xbbfca0),
    document["body"]["appendChild"](_0x3935d0),
    setTimeout(() => {
      _0x3935d0["style"]["display"] = "flex";
    }, 0x0));
}
function _0x3c94aa() {
  const _0x473f11 = document["querySelector"](".overlay");
  _0x473f11 &&
    ((_0x473f11["style"]["animation"] = "fadeOut\x200.5s\x20ease\x20forwards"),
    setTimeout(() => {
      _0x473f11["remove"]();
    }, 0x1f4));
}
async function _0x3d0521() {
  var _0x5846ac = document["createElement"]("label");
  _0x5846ac["setAttribute"]("class", "filter-label");
  var _0x5e853a = document["createElement"]("span");
  ((_0x5e853a["innerHTML"] = "Total\x20Sold\x20Filter:\x20"),
    _0x5846ac["appendChild"](_0x5e853a));
  var _0x106511 = document["createElement"]("input");
  ((_0x106511["type"] = "number"),
    (_0x106511["id"] = "total-sold-input"),
    (_0x106511["min"] = "0"),
    _0x106511["setAttribute"]("class", "filter-input"));
  let { totalSoldFilter: _0x1efe08 } =
    await chrome["storage"]["local"]["get"]("totalSoldFilter");
  return (
    !_0x1efe08 &&
      ((_0x1efe08 = 0x0),
      await chrome["storage"]["local"]["set"]({ totalSoldFilter: _0x1efe08 })),
    (_0x106511["value"] = _0x1efe08),
    _0x106511["addEventListener"]("input", async function () {
      this["value"] >= 0x0 &&
        (await chrome["storage"]["local"]["set"]({
          totalSoldFilter: this["value"],
        }),
        console["log"](
          "Total\x20Sold\x20Filter\x20saved:\x20" + this["value"],
        ));
    }),
    _0x5846ac["appendChild"](_0x106511),
    _0x5846ac
  );
}
async function _0x1ff915() {
  var _0x58b20a = document["createElement"]("label");
  _0x58b20a["setAttribute"]("class", "filter-label");
  var _0x2d7a2d = document["createElement"]("span");
  ((_0x2d7a2d["innerHTML"] = "Total\x20Competitors\x20Filter:\x20"),
    _0x58b20a["appendChild"](_0x2d7a2d));
  var _0x13dca1 = document["createElement"]("input");
  ((_0x13dca1["type"] = "number"),
    (_0x13dca1["id"] = "total-competitors-input"),
    (_0x13dca1["min"] = "0"),
    _0x13dca1["setAttribute"]("class", "filter-input"));
  let { totalCompetitorsFilter: _0x7180fc } = await chrome["storage"]["local"][
    "get"
  ]("totalCompetitorsFilter");
  return (
    !_0x7180fc &&
      ((_0x7180fc = 0x0),
      await chrome["storage"]["local"]["set"]({
        totalCompetitorsFilter: _0x7180fc,
      })),
    (_0x13dca1["value"] = _0x7180fc),
    _0x13dca1["addEventListener"]("input", async function () {
      this["value"] >= 0x0 &&
        (await chrome["storage"]["local"]["set"]({
          totalCompetitorsFilter: this["value"],
        }),
        console["log"](
          "Total\x20Competitors\x20Filter\x20saved:\x20" + this["value"],
        ));
    }),
    _0x58b20a["appendChild"](_0x13dca1),
    _0x58b20a
  );
}
async function fetchSoldDataConcurrently() {
  var { concurrencyLimit: _0x46a9a8 } =
      await chrome["storage"]["local"]["get"]("concurrencyLimit"),
    _0x25fee3 = _0x46a9a8;
  console["log"]("fetchSoldDataConcurrently");
  var _0x5f9495 = document["querySelectorAll"](".s-item__wrapper"),
    _0x55fc96 = Array["from"](_0x5f9495);
  const _0x35c455 = [];
  for (
    let _0x4b510f = 0x0;
    _0x4b510f < Math["min"](_0x25fee3, _0x55fc96["length"]);
    _0x4b510f++
  )
    _0x35c455["push"](_0x1ebf67(_0x55fc96));
  await Promise["all"](_0x35c455);
}
async function _0x1ebf67(_0xa73a4) {
  for (; _0xa73a4["length"] > 0x0; ) {
    const _0x1375c8 = _0xa73a4["pop"]();
    (_0x1375c8["classList"]["add"]("highlight"),
      await _0x1f78d1(_0x1375c8),
      _0x1375c8["classList"]["remove"]("highlight"));
  }
}
async function fetchSoldDataConcurrentlyViaPurchaseHistory() {
  var { concurrencyLimit: _0x47f7f3 } =
      await chrome["storage"]["local"]["get"]("concurrencyLimit"),
    _0x5ce6e3 = _0x47f7f3,
    _0x2d1f28 = _0x44d2fb(),
    _0x3a7241 = Array["from"](_0x2d1f28),
    { selectedFilter: _0x1b2d52 } =
      await chrome["storage"]["local"]["get"]("selectedFilter");
  !_0x1b2d52 &&
    ((_0x1b2d52 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: _0x1b2d52 }));
  var _0x5d9da0 = _0x1b2d52;
  const _0x53635b = [];
  console["log"]("CONCURRENCY_LIMIT", _0x5ce6e3);
  for (
    let _0x429f5f = 0x0;
    _0x429f5f < Math["min"](_0x5ce6e3, _0x3a7241["length"]);
    _0x429f5f++
  )
    _0x53635b["push"](_0x4d7f49(_0x3a7241, _0x5d9da0));
  await Promise["all"](_0x53635b);
}
async function _0x4d7f49(_0x2e2fd3, _0x3dc7a6) {
  for (; _0x2e2fd3["length"] > 0x0; ) {
    var _0xcaac18 = _0x2e2fd3["pop"]();
    _0xcaac18["classList"]["add"]("highlight");
    try {
      await _0x4ad6f8(_0xcaac18, _0x3dc7a6);
    } catch (_0x30c263) {
      console["log"]("error", _0x30c263);
    }
    _0xcaac18["classList"]["remove"]("highlight");
  }
}
async function fetchSoldDataSequentially() {
  const _0x18b7d8 = document["querySelectorAll"](".s-item__wrapper");
  for (const _0x4d91cc of _0x18b7d8) {
    (_0x4d91cc["scrollIntoView"]({ block: "center", inline: "nearest" }),
      _0x4d91cc["classList"]["add"]("highlight"),
      await _0x1f78d1(_0x4d91cc),
      await new Promise((_0x11bfe6) => setTimeout(_0x11bfe6, _0x581054)),
      _0x4d91cc["classList"]["remove"]("highlight"));
  }
  (await new Promise((_0x23d44d) => setTimeout(_0x23d44d, 0x7d0)), _0x3c94aa());
}
async function fetchSoldDataSequentiallyViaPurchaseHistory() {
  var _0x14e7cb = document["querySelectorAll"](
    ".s-item__wrapper:not(.highlight)",
  );
  console["log"](
    "fetchSoldDataSequentiallyViaPurchaseHistory\x20items",
    _0x14e7cb,
  );
  for (var _0x5b5d55 of _0x14e7cb) {
    try {
      _0x5b5d55["querySelector"](".s-item__itemID")["textContent"];
    } catch (_0x5f1286) {
      console["log"]("itemNumber\x20not\x20found");
      continue;
    }
    (console["log"](
      "fetchSoldDataSequentiallyViaPurchaseHistory\x20item",
      _0x5b5d55,
    ),
      _0x5b5d55["scrollIntoView"]({ block: "center", inline: "nearest" }),
      _0x5b5d55["classList"]["add"]("highlight"));
    var { selectedFilter: _0x1bec5b } =
      await chrome["storage"]["local"]["get"]("selectedFilter");
    !_0x1bec5b &&
      ((_0x1bec5b = "90"),
      await chrome["storage"]["local"]["set"]({ selectedFilter: _0x1bec5b }));
    var _0x2309ea = _0x1bec5b;
    (await _0x4ad6f8(_0x5b5d55, _0x2309ea),
      (_0x581054 = 0x96),
      await new Promise((_0x5a7e42) => setTimeout(_0x5a7e42, _0x581054)),
      _0x5b5d55["classList"]["remove"]("highlight"));
  }
  (await new Promise((_0x5c498b) => setTimeout(_0x5c498b, 0x7d0)), _0x3c94aa());
}
function _0x4639fd() {
  var fetchSoldDataButton = document["createElement"]("button");
  return (
    fetchSoldDataButton["setAttribute"]("class", "btn-fetch-sold-data"),
    (fetchSoldDataButton["innerHTML"] = "Fetch\x20Sold\x20Data"),
    fetchSoldDataButton["addEventListener"](
      "click",
      async function (_0x398aec) {
        (_0x398aec["preventDefault"](), await fetchSoldDataSequentially());
      },
    ),
    fetchSoldDataButton
  );
}
async function _0x4ee8b0() {
  var _0x11c2bf = document["createElement"]("select");
  (_0x11c2bf["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "Off", value: "none" },
      { text: "On", value: "concurrent-purchase-history" },
    ]["forEach"]((_0x15aab8) => {
      var _0x161acf = document["createElement"]("option");
      ((_0x161acf["value"] = _0x15aab8["value"]),
        (_0x161acf["innerText"] = _0x15aab8["text"]),
        _0x11c2bf["appendChild"](_0x161acf));
    }));
  let { selectedFetchMethod: _0x5af7cc } = await chrome["storage"]["local"][
    "get"
  ]("selectedFetchMethod");
  !_0x5af7cc &&
    ((_0x5af7cc = "none"),
    await chrome["storage"]["local"]["set"]({
      selectedFetchMethod: _0x5af7cc,
    }));
  ((_0x11c2bf["value"] = _0x5af7cc),
    _0x11c2bf["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        selectedFetchMethod: this["value"],
      }),
        console["log"]("Fetch\x20Method\x20saved:\x20" + this["value"]),
        "concurrent-purchase-history" == this["value"]
          ? ((document["getElementById"](
              "concurrency-limit-dropdown-container",
            )["style"]["display"] = "block"),
            (document["getElementById"]("filter-dropdown-container")["style"][
              "display"
            ] = "block"))
          : ((document["getElementById"](
              "concurrency-limit-dropdown-container",
            )["style"]["display"] = "none"),
            (document["getElementById"]("filter-dropdown-container")["style"][
              "display"
            ] = "none")));
    }));
  var _0x1125a5 = document["createElement"]("label");
  ((_0x1125a5["innerText"] = "Get\x20Total\x20Sold\x20History:"),
    _0x1125a5["setAttribute"]("for", "terapeak-fetch-mode"));
  var _0x5ab658 = document["createElement"]("div");
  return (
    _0x5ab658["appendChild"](_0x1125a5),
    _0x5ab658["appendChild"](_0x11c2bf),
    _0x5ab658
  );
}
async function _0xe4f804() {
  var _0x29d93f = document["createElement"]("input");
  ((_0x29d93f["type"] = "checkbox"),
    (_0x29d93f["id"] = "scrape-all-pages-checkbox"));
  var { scrapeAllPages: _0x179d1a } =
    await chrome["storage"]["local"]["get"]("scrapeAllPages");
  !_0x179d1a &&
    ((_0x179d1a = !0x1),
    await chrome["storage"]["local"]["set"]({ scrapeAllPages: _0x179d1a }));
  ((_0x29d93f["checked"] = _0x179d1a),
    _0x29d93f["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        scrapeAllPages: this["checked"],
      }),
        console["log"](
          "Scrape\x20All\x20Pages\x20saved:\x20" + this["checked"],
        ));
    }));
  var _0x1bf988 = document["createElement"]("label");
  ((_0x1bf988["innerText"] = "Scrape\x20All\x20Pages"),
    _0x1bf988["setAttribute"]("for", "scrape-all-pages-checkbox"));
  var _0x5da221 = document["createElement"]("div");
  return (
    _0x5da221["appendChild"](_0x29d93f),
    _0x5da221["appendChild"](_0x1bf988),
    _0x5da221
  );
}
async function _0x2627e8() {
  var _0x286c48 = document["createElement"]("select");
  ((_0x286c48["id"] = "concurrency-limit-dropdown"),
    _0x286c48["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "1", value: 0x1 },
      { text: "3", value: 0x3 },
      { text: "5", value: 0x5 },
      { text: "10", value: 0xa },
      { text: "15", value: 0xf },
      { text: "20", value: 0x14 },
      { text: "25", value: 0x19 },
      { text: "30", value: 0x1e },
      { text: "40", value: 0x28 },
      { text: "50", value: 0x32 },
    ]["forEach"]((_0x31490c) => {
      var _0x59fcfd = document["createElement"]("option");
      ((_0x59fcfd["value"] = _0x31490c["value"]),
        (_0x59fcfd["innerText"] = _0x31490c["text"]),
        _0x286c48["appendChild"](_0x59fcfd));
    }));
  var { concurrencyLimit: _0x38b405 } =
    await chrome["storage"]["local"]["get"]("concurrencyLimit");
  console["log"]("concurrencyLimit", _0x38b405);
  !_0x38b405 &&
    ((_0x38b405 = 0x5),
    chrome["storage"]["local"]["set"]({ concurrencyLimit: _0x38b405 }));
  ((_0x286c48["value"] = _0x38b405),
    _0x286c48["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        concurrencyLimit: this["value"],
      }),
        console["log"]("Concurrency\x20Limit\x20saved:\x20" + this["value"]));
    }));
  var _0x27f4fc = document["createElement"]("label");
  ((_0x27f4fc["innerText"] = "Scanning\x20Speed:\x20"),
    _0x27f4fc["setAttribute"]("for", "concurrency-limit-dropdown"));
  var _0x25c869 = document["createElement"]("div");
  return (
    (_0x25c869["id"] = "concurrency-limit-dropdown-container"),
    _0x25c869["appendChild"](_0x27f4fc),
    _0x25c869["appendChild"](_0x286c48),
    _0x25c869
  );
}
function _0x55f2e7() {
  var _0x1f4373 = document["querySelectorAll"]("li"),
    _0x5916bf = Array["from"](_0x1f4373);
  ((_0x5916bf = (_0x5916bf = _0x5916bf["filter"]((_0x2f9f73) =>
    _0x2f9f73["querySelector"](_0x396b13()),
  ))["filter"]((_0x3c120f) =>
    _0x3c120f["querySelector"](".total-sold-element"),
  ))["sort"]((_0x18bcc6, _0xeb8a8e) => {
    (console["log"]("a", _0x18bcc6), console["log"]("b", _0xeb8a8e));
    var _0xba5c3f = _0x18bcc6["querySelector"](".total-sold-element")[
        "getAttribute"
      ]("data-total-sold"),
      _0x38662f = _0xeb8a8e["querySelector"](".total-sold-element")[
        "getAttribute"
      ]("data-total-sold");
    return "Rate\x20Limited" == _0xba5c3f || "Rate\x20Limited" == _0x38662f
      ? 0x0
      : _0x38662f - _0xba5c3f;
  }),
    _0x5916bf["reverse"]());
  var _0x32393b = _0x5916bf[0x0]["parentNode"];
  _0x5916bf["forEach"]((_0x2b4ede) =>
    _0x32393b["insertBefore"](
      _0x2b4ede,
      _0x32393b["firstChild"]["nextSibling"],
    ),
  );
}
function _0x543d96() {
  var _0x27f7e6 = document["createElement"]("button");
  return (
    _0x27f7e6["setAttribute"]("class", "btn-check-all-purchase-history"),
    _0x27f7e6["classList"]["add"]("filter-date-context"),
    (_0x27f7e6["id"] = "btn-check-all-purchase-history"),
    (_0x27f7e6["innerHTML"] = "Check\x20All\x20Purchase\x20History"),
    _0x27f7e6["addEventListener"]("click", async function (_0x24744a) {
      try {
        await fetchSoldDataBasedOnSelection();
      } catch (_0x36e9bf) {
        console["log"]("error", _0x36e9bf);
      }
    }),
    _0x27f7e6
  );
}
function _0x4d2091(
  _0x5bd807 = null,
  _0x57b466 = null,
  _0x220be3 = null,
  _0x38f554 = !0x0,
) {
  console["log"]("createEcommerceSearchButtonsPanel", _0x5bd807);
  var _0x2ef9e4 = _0x5422db(_0x57b466),
    _0x1cc385 = _0x183e50(_0x5bd807),
    _0x3eb4c8 = _0xaf1f5e(),
    _0x397878 = _0x83daf8(_0x5bd807),
    _0xfdf977 = _0x14eb24(_0x5bd807),
    _0x525a83 = _0x83daf8(
      _0x5bd807,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x217208 = _0x417447(_0x220be3),
    _0x4c4b40 = _0x1ceb0d(_0x57b466),
    _0x1b83b6 = document["createElement"]("div");
  _0x1b83b6["setAttribute"]("id", "search-div");
  var _0x3522dd = document["createElement"]("label");
  ((_0x3522dd["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x1b83b6["appendChild"](_0x3522dd),
    _0x1b83b6["appendChild"](_0xfdf977),
    _0x1b83b6["appendChild"](_0x397878),
    _0x1b83b6["appendChild"](_0x1cc385),
    _0x1b83b6["appendChild"](_0x217208),
    _0x1b83b6["appendChild"](_0x525a83));
  var _0x41a3de = _0x5c1511(),
    _0x47436f = _0x1a3f13(),
    _0x3b3431 = document["createElement"]("div");
  _0x3b3431["setAttribute"]("id", "item-buttons-div");
  var _0x34b1a3 = document["createElement"]("div");
  return (
    _0x34b1a3["setAttribute"]("id", "main-buttons-div"),
    _0x34b1a3["appendChild"](_0x4c4b40),
    _0x34b1a3["appendChild"](_0x3eb4c8),
    _0x34b1a3["appendChild"](_0x41a3de),
    _0x34b1a3["appendChild"](_0x2ef9e4),
    _0x3b3431["appendChild"](_0x34b1a3),
    _0x38f554 && _0x3b3431["appendChild"](_0x47436f),
    _0x3b3431["appendChild"](_0x1b83b6),
    _0x3b3431
  );
}
(console["log"]("ebay/store_search/content.js\x20loaded"),
  chrome["runtime"]["onMessage"]["addListener"](
    function (_0x5ec5b4, _0x5f4d18, _0x3aeee8) {
      "research_competitor" == _0x5ec5b4["type"] &&
        (console["log"]("Researching\x20competitor"),
        _0x11db4c()["then"]((_0x90fe01) => {
          chrome["runtime"]["sendMessage"]({
            type: "research_competitor_done",
            didResearch: _0x90fe01,
          });
        }));
    },
  ));
async function _0x11db4c() {
  return (await _0x1dc30a(), !0x0);
}
async function _0x3859ba() {
  var { run_status_extract_titles: _0x5a32f2 } = await chrome["storage"][
      "local"
    ]["get"]("run_status_extract_titles"),
    _0x3f19dc = document["querySelector"]("#mainContent"),
    _0x43280e = _0x4da526(),
    _0x593157 = _0x28f974(),
    _0x5c8c13 = _0x87eee4(),
    filterDropDown = await _0x2a3b25();
  (await _0x3d0521(), await _0x1ff915());
  var fetchSoldDataDropDown = await _0x4ee8b0(),
    _0x1e20bf = await _0xe4f804(),
    _0x3c0e8f = await _0x2627e8();
  ((_0xc45510 = document["createElement"]("div"))["setAttribute"](
    "id",
    "ebay-buttons-div",
  ),
    _0xc45510["appendChild"](_0x43280e),
    _0xc45510["appendChild"](_0x593157),
    _0xc45510["appendChild"](_0x5c8c13),
    _0xc45510["appendChild"](_0x1e20bf));
  var _0x1e3057 = document["createElement"]("div");
  _0x1e3057["setAttribute"]("id", "scan-settings-container");
  var _0x3b3bc7 = document["createElement"]("label");
  ((_0x3b3bc7["innerHTML"] =
    "<b>Enable\x20\x27Total\x20Sold\x27\x20to\x20access\x20complete\x20sales\x20history.\x20Note:\x20This\x20setting\x20will\x20slow\x20down\x20the\x20scanning\x20process.</b>"),
    _0x1e3057["appendChild"](_0x3b3bc7),
    _0x1e3057["appendChild"](fetchSoldDataDropDown),
    _0x1e3057["appendChild"](filterDropDown),
    _0x1e3057["appendChild"](_0x3c0e8f),
    _0xc45510["appendChild"](_0x1e3057));
  var _0x4480f6 = document["createElement"]("a");
  ((_0x4480f6["href"] =
    "https://chromewebstore.google.com/detail/captcha-solver-auto-hcapt/hlifkpholllijblknnmbfagnkjneagid?hl=en-US"),
    (_0x4480f6["innerHTML"] = "Install\x20Captcha\x20Solver"),
    (_0x4480f6["target"] = "_blank"),
    (_0x4480f6["style"]["marginLeft"] = "10px"),
    (_0x4480f6["id"] = "captcha-solver-link"),
    _0x3f19dc["insertBefore"](_0xc45510, _0x3f19dc["firstChild"]));
  "none" == document["querySelector"](".filter-dropdown-class")["value"]
    ? ((document["getElementById"]("concurrency-limit-dropdown-container")[
        "style"
      ]["display"] = "none"),
      (document["getElementById"]("filter-dropdown-container")["style"][
        "display"
      ] = "none"))
    : ((document["getElementById"]("concurrency-limit-dropdown-container")[
        "style"
      ]["display"] = "block"),
      (document["getElementById"]("filter-dropdown-container")["style"][
        "display"
      ] = "block"));
  var _0x587056 = _0x3e932b();
  for (var _0x3be946 = 0x0; _0x3be946 < _0x587056["length"]; _0x3be946++) {
    var _0x5916f2 = _0x587056[_0x3be946],
      _0xc45510 = _0x5976bb(),
      _0x411d76 = _0x265f3d(_0x520688(_0x5916f2)),
      _0xa8f68f = await _0x2d7ce5(_0x411d76);
    (_0xc45510["appendChild"](_0xa8f68f), _0x5916f2["appendChild"](_0xc45510));
  }
  (_0x1a0d04(), _0x17d8f1());
}
_0x3859ba();
