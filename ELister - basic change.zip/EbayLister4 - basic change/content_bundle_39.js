function _0x3b1ec9() {
  return new Promise((_0x150989) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x150989();
      });
    });
  });
}
function _0x11ef69() {
  return new Promise((_0x17b463) => {
    requestIdleCallback(() => {
      _0x17b463();
    });
  });
}
function _0x2aa57d(_0x32208c = 0x3e8) {
  return new Promise((_0x55119a, _0x398661) => {
    let _0x315bca,
      _0x3ba16f = Date["now"](),
      _0x4b9d26 = !0x1;
    function _0x36a867() {
      if (Date["now"]() - _0x3ba16f > _0x32208c)
        (_0x4b9d26 && _0x315bca["disconnect"](), _0x55119a());
      else setTimeout(_0x36a867, _0x32208c);
    }
    const _0x59cd39 = () => {
        _0x3ba16f = Date["now"]();
      },
      _0x5a434f = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x315bca = new MutationObserver(_0x59cd39)),
        _0x315bca["observe"](document["body"], _0x5a434f),
        (_0x4b9d26 = !0x0),
        setTimeout(_0x36a867, _0x32208c));
    else
      window["onload"] = () => {
        ((_0x315bca = new MutationObserver(_0x59cd39)),
          _0x315bca["observe"](document["body"], _0x5a434f),
          (_0x4b9d26 = !0x0),
          setTimeout(_0x36a867, _0x32208c));
      };
  });
}
async function _0xdd2536() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x2aa57d(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x5e6058() {
  return await new Promise(function (_0x5e1687, _0x29ee22) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x5ef024) {
        (console["log"]("result:\x20", _0x5ef024["membership"]),
          _0x5e1687(_0x5ef024["membership"]));
      },
    );
  });
}
async function _0x5503db() {
  return await new Promise(function (_0x375d41, _0x2fb213) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x596f11) {
        (console["log"]("result:\x20", _0x596f11["creditsAvailable"]),
          _0x375d41(_0x596f11["creditsAvailable"]));
      },
    );
  });
}
async function _0x17824e(_0x4a9d1e) {
  if ("ultimate" != (await _0x5e6058()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x5503db()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
function _0x1f4c20(
  _0xe20b6 = null,
  _0x277b42 = null,
  _0x4180f4 = null,
  _0x31a144 = null,
) {
  var _0x146e31 = document["createElement"]("a");
  (_0x146e31["setAttribute"]("class", "a-link-text"),
    _0x146e31["classList"]["add"]("icon"),
    _0x146e31["classList"]["add"]("amazonSearchLink"),
    _0x146e31["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x53338a = document["createElement"]("img");
  return (
    _0x53338a["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x53338a["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x146e31["appendChild"](_0x53338a),
    _0x146e31["addEventListener"]("click", async function (_0x44e220) {
      (_0x44e220["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0xe20b6) {
        var _0x183e8a = _0x71ce41(_0x44e220);
        if (!_0x183e8a) return;
        var _0x1c4462 = extractItemData(_0x183e8a);
        ((_0xe20b6 = _0x1c4462["title"])["endsWith"]("...") &&
          (_0xe20b6 = _0xe20b6["substring"](
            0x0,
            _0xe20b6["lastIndexOf"]("\x20"),
          )),
          _0xe20b6["length"] > 0x4b &&
            (_0xe20b6 = _0xe20b6["substring"](
              0x0,
              _0xe20b6["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x2fc193 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x2fc193),
        _0x2fc193 || (_0x2fc193 = "reviews"),
        console["log"]("amazonSortType", _0x2fc193),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x3deb94 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0xe20b6["length"] > 0x50; )
        _0xe20b6 = _0xe20b6["substring"](0x0, _0xe20b6["lastIndexOf"]("\x20"));
      var { amazonSearchType: _0xfbdd } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x525786 = _0xe20b6;
      "keywords" == _0xfbdd && (_0x525786 = await _0x48858f(_0xe20b6));
      try {
        _0x1c4462 = extractItemData(_0x183e8a);
      } catch (_0x385f63) {
        console["log"]("error", _0x385f63);
      }
      (_0x1c4462 ||
        (_0x1c4462 = {
          title: _0xe20b6,
          price: _0x277b42,
          itemNumber: _0x4180f4,
          image: _0x31a144,
        }),
        console["log"]("itemData", _0x1c4462),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x525786,
          options: { isTabActive: !0x0, sort: _0x2fc193 },
          itemData: _0x1c4462,
        }));
    }),
    _0x146e31
  );
}
function _0x2491bb(_0x497581) {
  var _0x25278e = document["createElement"]("a");
  (_0x25278e["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x25278e["setAttribute"]("class", "a-link-text"),
    _0x25278e["classList"]["add"]("icon"),
    _0x25278e["classList"]["add"]("amazonSearchLink"),
    _0x25278e["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x2ec1bd = document["createElement"]("img");
  return (
    _0x2ec1bd["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x2ec1bd["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x25278e["appendChild"](_0x2ec1bd),
    _0x25278e["addEventListener"]("click", async function (_0x334c60) {
      (_0x334c60["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x497581),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x497581,
        }));
    }),
    _0x25278e
  );
}
function _0x27779c(_0x2cffec) {
  var _0x2f635e = document["createElement"]("a");
  (_0x2f635e["setAttribute"]("id", "amazonLink"),
    _0x2f635e["setAttribute"]("class", "a-link-text"),
    _0x2f635e["classList"]["add"]("icon"),
    _0x2f635e["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x3447c6 = document["createElement"]("img");
  return (
    _0x3447c6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x3447c6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2f635e["appendChild"](_0x3447c6),
    _0x2f635e["addEventListener"]("click", async function (_0x90b1b1) {
      (_0x90b1b1["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x5a7610 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x2ca9e3 =
          "https://www.amazon." +
          _0x5a7610 +
          "/dp/" +
          _0x2cffec +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x2ca9e3 });
    }),
    _0x2f635e
  );
}
function _0x51fa32(_0x1c5358) {
  var _0x4ba05e = document["createElement"]("a");
  (_0x4ba05e["setAttribute"]("id", "amazonLink"),
    _0x4ba05e["setAttribute"]("class", "a-link-text"),
    _0x4ba05e["classList"]["add"]("icon"),
    _0x4ba05e["classList"]["add"]("amazonLink"),
    _0x4ba05e["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x14d50a = document["createElement"]("img");
  return (
    _0x14d50a["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x14d50a["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4ba05e["appendChild"](_0x14d50a),
    _0x4ba05e["addEventListener"]("click", async function (_0x173b39) {
      (_0x173b39["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x1c5358(_0x173b39);
      } catch (_0x48f418) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x48f418);
      }
    }),
    _0x4ba05e
  );
}
function _0x569881(
  _0x4322b8 = null,
  _0x408a8f,
  _0x57ae29 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x4322b8, _0x408a8f);
  var _0x447445 = document["createElement"]("a");
  (_0x447445["setAttribute"]("id", "ebayLink"),
    _0x447445["setAttribute"]("class", "a-link-text"),
    _0x447445["classList"]["add"]("icon"),
    _0x408a8f && _0x408a8f["soldItems"]
      ? _0x447445["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x447445["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x519af5 = document["createElement"]("img");
  return (
    _0x519af5["setAttribute"]("src", chrome["runtime"]["getURL"](_0x57ae29)),
    _0x519af5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x447445["appendChild"](_0x519af5),
    _0x447445["addEventListener"]("click", async function (_0x9048d8) {
      (_0x9048d8["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x4322b8) console["log"]("title\x20found", _0x4322b8);
      else {
        console["log"]("title\x20not\x20found");
        var _0x41a4c6 = _0x71ce41(_0x9048d8);
        if (!_0x41a4c6) return;
        var _0x46d8c6 = extractItemData(_0x41a4c6);
        _0x4322b8 = _0x46d8c6["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x20a157 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x4322b8["length"] > 0x50; )
        _0x4322b8 = _0x4322b8["substring"](
          0x0,
          _0x4322b8["lastIndexOf"]("\x20"),
        );
      var _0x524126 =
        "https://www.ebay." +
        _0x20a157 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x4322b8) +
        "&_odkw=" +
        encodeURIComponent(_0x4322b8);
      (_0x408a8f && _0x408a8f["soldItems"] && (_0x524126 += "&LH_Sold=1"),
        _0x408a8f && _0x408a8f["sortLowToHigh"] && (_0x524126 += "&_sop=15"),
        _0x408a8f && _0x408a8f["endedRecently"] && (_0x524126 += "&_sop=13"),
        (_0x524126 += "&LH_ItemCondition=1000"),
        (_0x524126 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x524126,
        }));
    }),
    _0x447445
  );
}
function _0x878e31(_0x587a0f = null) {
  var _0x345088 = document["createElement"]("a");
  (_0x345088["setAttribute"]("id", "googleLink"),
    _0x345088["setAttribute"]("class", "a-link-text"),
    _0x345088["classList"]["add"]("icon"),
    _0x345088["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x2d641b = document["createElement"]("img");
  return (
    _0x2d641b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x2d641b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x345088["appendChild"](_0x2d641b),
    _0x345088["addEventListener"]("click", async function (_0x208dec) {
      (_0x208dec["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x587a0f) {
        var _0x200de4 = _0x71ce41(_0x208dec);
        if (!_0x200de4) return;
        var _0x40a16d = extractItemData(_0x200de4);
        _0x587a0f = _0x40a16d["image"];
      }
      var { domain: _0x30dd1c } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x96473e(_0x30dd1c),
        encodeURIComponent(_0x587a0f),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x587a0f,
        }));
    }),
    _0x345088
  );
}
function _0xd5b075(_0x3c5fdb = null) {
  var _0xb4ef33 = document["createElement"]("a");
  (_0xb4ef33["setAttribute"]("id", "googleLink"),
    _0xb4ef33["setAttribute"]("class", "a-link-text"),
    _0xb4ef33["classList"]["add"]("icon"),
    _0xb4ef33["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x475d31 = document["createElement"]("img");
  return (
    _0x475d31["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x475d31["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xb4ef33["appendChild"](_0x475d31),
    _0xb4ef33["addEventListener"]("click", async function (_0x27aca7) {
      (_0x27aca7["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x3c5fdb) {
        var _0x4d32f7 = _0x71ce41(_0x27aca7);
        if (!_0x4d32f7) return;
        var _0x44a019 = extractItemData(_0x4d32f7);
        _0x3c5fdb = _0x44a019["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x3c5fdb,
      });
    }),
    _0xb4ef33
  );
}
function _0x511c99(_0x53458b) {
  var _0x223b58 = document["createElement"]("a");
  (_0x223b58["setAttribute"]("id", "lookUpSkuLink"),
    _0x223b58["setAttribute"]("class", "a-link-text"),
    _0x223b58["classList"]["add"]("icon"),
    _0x223b58["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x9b6e5c = document["createElement"]("img");
  return (
    _0x9b6e5c["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x9b6e5c["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x223b58["appendChild"](_0x9b6e5c),
    _0x223b58["addEventListener"]("click", async function (_0x5e453b) {
      (_0x5e453b["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x1b50e8 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x929699 =
          "https://www.amazon." +
          _0x1b50e8 +
          "/dp/" +
          _0x53458b +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x929699,
        options: { active: !0x0 },
      });
    }),
    _0x223b58
  );
}
function _0x26bdf9(_0x2a6bd6 = null) {
  var _0x445563 = document["createElement"]("a");
  (_0x445563["setAttribute"]("id", "productHunterLink"),
    _0x445563["setAttribute"]("class", "a-link-text"),
    _0x445563["classList"]["add"]("icon"),
    _0x445563["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x3b3148 = document["createElement"]("img");
  return (
    _0x3b3148["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x3b3148["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x445563["appendChild"](_0x3b3148),
    _0x445563["addEventListener"]("click", async function (_0x4717cc) {
      (_0x4717cc["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x2a6bd6) {
        var _0x480aa5 = _0x71ce41(_0x4717cc);
        if (!_0x480aa5) return;
        var _0x25fe3b = extractItemData(_0x480aa5);
        _0x2a6bd6 = _0x25fe3b["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x2a6bd6),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x2a6bd6,
        }));
    }),
    _0x445563
  );
}
function _0x96473e(_0x2214ae) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x2214ae] || "en-US";
}
function _0x1ce03f(_0x322986 = null) {
  console["log"]("createSearchTerapeakButton", _0x322986);
  var _0x5ae341 = document["createElement"]("a");
  (_0x5ae341["setAttribute"]("class", "a-link-text"),
    _0x5ae341["classList"]["add"]("terapeakLink"),
    _0x5ae341["classList"]["add"]("icon"),
    _0x5ae341["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x322986 && _0x5ae341["setAttribute"]("item_title", _0x322986));
  var _0x2c6bb6 = document["createElement"]("img");
  return (
    _0x2c6bb6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x2c6bb6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5ae341["appendChild"](_0x2c6bb6),
    _0x5ae341["addEventListener"]("click", async function (_0x159c89) {
      (_0x159c89["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x7adb0f = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x7adb0f),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x7adb0f) {
        var _0x115e21 = _0x71ce41(_0x159c89);
        if (!_0x115e21) return;
        _0x7adb0f = extractItemData(_0x115e21)["title"];
      }
      console["log"]("title", _0x7adb0f);
      var { convertToKeywords: _0x3ccf59 } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x3ccf59) var _0x7adb0f = await _0x48858f(_0x7adb0f);
      var { domain: _0x4b3bd6 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x26dd92 = _0x415a8f(_0x7adb0f, _0x4b3bd6);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x26dd92 });
    }),
    _0x5ae341
  );
}
async function _0x48858f(_0x8d40b4) {
  var _0x16c551 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0xdc1fba) => _0xdc1fba["json"]());
  ((_0x16c551["user_input"] = _0x8d40b4),
    console["log"]("jsonPrompt", _0x16c551));
  var _0x12aa4f = await new Promise((_0x243cb1, _0x41a990) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x16c551,
      },
      function (_0x408a54) {
        _0x243cb1(_0x408a54["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x12aa4f),
    (_0x12aa4f = JSON["parse"](_0x12aa4f))["output"]
  );
}
function _0x415a8f(
  _0x442117,
  _0x36805f = "ca",
  _0x4f97c7 = 0x1e,
  _0x55ed4d = 0x0,
  _0x5bc384 = 0x0,
  _0x20a54d = 0x32,
  _0x4616be = "-itemssold",
  _0x1313fb = "SOLD",
  _0x1e1ae2 = "EBAY-CA",
  _0x2305cc = "America/Toronto",
  _0xf04c5e = "BuyerLocation:::CA",
  _0xfa1c48 = 0x0,
) {
  _0x1e1ae2 = "";
  switch (_0x36805f) {
    case "ca":
    default:
      _0x1e1ae2 = "EBAY-CA";
      break;
    case "com":
      _0x1e1ae2 = "EBAY-US";
      break;
    case "co.uk":
      _0x1e1ae2 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x36805f +
    "/sh/research?" +
    [
      "keywords=" + _0x442117,
      "dayRange=" + _0x4f97c7,
      "categoryId=" + _0x55ed4d,
      "offset=" + _0x5bc384,
      "limit=" + _0x20a54d,
      "sorting=" + _0x4616be,
      "tabName=" + _0x1313fb,
      "marketplace=" + _0x1e1ae2,
      "tz=" + encodeURIComponent(_0x2305cc),
      "minPrice=" + _0xfa1c48,
    ]["join"]("&")
  );
}
async function _0x37db1a(_0x19da8e) {
  var { domain: _0x44d94b } = await chrome["storage"]["local"]["get"]("domain"),
    _0x44f5b9 =
      "https://www.ebay." +
      _0x44d94b +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x19da8e +
      "&store_name=" +
      _0x19da8e +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x44f5b9 });
}
async function _0x497586(_0x31eded) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x31eded,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x31eded));
}
async function _0x25a4c(_0x54de78) {
  var { response: _0x23234b } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x54de78,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x23234b), _0x23234b);
}
function _0x6ec32e(_0x2f5bad = null) {
  console["log"]("createOpenSellerItemsButton", _0x2f5bad);
  var _0x56e543 = document["createElement"]("a");
  (_0x56e543["setAttribute"]("id", "sellerItemsLink"),
    _0x56e543["setAttribute"]("class", "a-link-text"),
    _0x56e543["classList"]["add"]("icon"),
    _0x56e543["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x79e149 = document["createElement"]("img");
  return (
    _0x79e149["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x79e149["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x56e543["appendChild"](_0x79e149),
    _0x56e543["addEventListener"]("click", async function (_0x49a415) {
      (_0x49a415["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x2f5bad),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x2f5bad));
      var _0x5395ce;
      if (!_0x2f5bad) {
        console["log"]("username\x20not\x20found");
        var _0x256b36 = _0x71ce41(_0x49a415);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x256b36,
        );
        if (!_0x256b36) return;
        var _0x3ef7f8 = extractItemData(_0x256b36);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x3ef7f8,
        ),
          (_0x2f5bad = _0x3ef7f8["username"]),
          (_0x5395ce = _0x3ef7f8["itemNumber"]));
      }
      if (
        _0x2f5bad["includes"]("\x20") ||
        _0x2f5bad !== _0x2f5bad["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x2f5bad,
        );
        if (!_0x5395ce) {
          if (!(_0x256b36 = _0x71ce41(_0x49a415))) return;
          _0x5395ce = (_0x3ef7f8 = extractItemData(_0x256b36))["itemNumber"];
        }
        _0x497586(_0x5395ce);
      } else
        ((_0x2f5bad = _0x2f5bad["toLowerCase"]()),
          console["log"]("username", _0x2f5bad),
          _0x37db1a(_0x2f5bad));
    }),
    _0x56e543
  );
}
function _0x45524f(_0x3b2ce4) {
  for (
    ;
    _0x3b2ce4 &&
    !_0x3b2ce4["classList"]["contains"]("s-item") &&
    !_0x3b2ce4["classList"]["contains"]("su-card-container");

  )
    _0x3b2ce4 = _0x3b2ce4["parentElement"];
  return _0x3b2ce4;
}
function _0x15f734(_0x3902 = null) {
  var _0x3e2102 = document["createElement"]("a");
  (_0x3e2102["setAttribute"]("id", "purchaseHistoryLink"),
    _0x3e2102["setAttribute"]("class", "a-link-text"),
    _0x3e2102["classList"]["add"]("icon"),
    _0x3e2102["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x2dde7b = document["createElement"]("img");
  return (
    _0x2dde7b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x2dde7b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3e2102["appendChild"](_0x2dde7b),
    _0x3e2102["addEventListener"]("click", async function (_0x2797cf) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x3902),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x2797cf["preventDefault"]());
      var _0x3a445c = _0x71ce41(_0x2797cf);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x3a445c,
      );
      if (_0x3a445c) {
        var { selectedFilter: _0x10a993 } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x10a993 &&
          ((_0x10a993 = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x10a993,
          }));
        var _0x4f9e78 = _0x10a993,
          _0x46671b = await checkPurchaseHistoryAndAddToItem(
            _0x3a445c,
            _0x4f9e78,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x46671b);
      } else
        try {
          var _0x2db7c1 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x3902,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x2db7c1),
            (_0x46671b = _0x2db7c1["totalSold"]));
        } catch (_0x50958a) {
          (console["log"]("error", _0x50958a), (_0x46671b = -0x3e7));
        }
    }),
    _0x3e2102
  );
}
function _0x71ce41(_0x53ca78) {
  var _0x1d7145 = _0x53ca78["target"];
  return (
    (_0x1d7145 = _0x45524f(_0x1d7145)),
    console["log"]("found\x20s-item", _0x1d7145),
    _0x1d7145
  );
}
function _0x1fdb3e(_0x401cba = null, _0x44e777 = null, _0x18f9e7 = null) {
  var _0x48cfe4 = document["createElement"]("a");
  (_0x48cfe4["setAttribute"]("id", "copyDataLink"),
    _0x48cfe4["setAttribute"]("class", "a-link-text"),
    _0x48cfe4["classList"]["add"]("icon"),
    _0x48cfe4["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x3a1fd5 = document["createElement"]("img");
  return (
    _0x3a1fd5["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x3a1fd5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x48cfe4["appendChild"](_0x3a1fd5),
    _0x48cfe4["addEventListener"]("click", async function (_0x1f2bfd) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x401cba,
        _0x44e777,
        _0x18f9e7,
      ),
        _0x1f2bfd["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x401cba && _0x44e777 && _0x18f9e7)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x401cba,
          _0x44e777,
          _0x18f9e7,
        ),
          isNaN(_0x44e777) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x44e777),
            (_0x44e777 = _0x44e777["replace"](/[^0-9.]/g, ""))),
          _0x1907b5(
            JSON["stringify"]({
              title: _0x401cba,
              price: _0x44e777,
              itemNumber: _0x18f9e7,
            }),
          ));
      else {
        if (!_0x401cba || !_0x44e777 || !_0x18f9e7) {
          var _0xbbe457 = _0x71ce41(_0x1f2bfd);
          if (!_0xbbe457) return;
        }
        var _0x5e5841 = extractItemData(_0xbbe457);
        (console["log"]("itemData", _0x5e5841),
          _0x1907b5(JSON["stringify"](_0x5e5841)));
      }
    }),
    _0x48cfe4
  );
}
function _0x1907b5(_0x31becf) {
  var _0x285e46 = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x285e46),
    (_0x285e46["value"] = _0x31becf),
    _0x285e46["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x285e46));
}
async function _0x4451c0(_0x29531b = null) {
  console["log"]("price", _0x29531b);
  if (_0x29531b) {
    try {
      _0x29531b = _0x29531b["replace"](/[^0-9.]/g, "");
    } catch (_0x484afa) {}
    _0x29531b = parseFloat(_0x29531b);
  }
  var _0x3956af = await _0x2091f5(_0x29531b),
    _0x5eee72 = document["createElement"]("div");
  return (
    _0x5eee72["setAttribute"]("id", "breakEvenPrice"),
    _0x5eee72["setAttribute"]("class", "break-even-price"),
    (_0x5eee72["textContent"] =
      "Break-even\x20price:\x20$" + _0x3956af["toFixed"](0x2)),
    _0x5eee72
  );
}
async function _0x1f3b3f(_0x52c974) {
  var _0x209ef2 = !0x1,
    _0x4e91fb = !0x1,
    { includeCurrencyConversion: _0x4e91fb } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x209ef2 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x24e08c =
    0.1325 * _0x52c974 +
    0.021 * _0x52c974 +
    _0x52c974 * (_0x209ef2 ? 0.004 : 0x0) +
    0.4;
  return (_0x4e91fb && (_0x24e08c += 0.035 * _0x52c974), _0x52c974 - _0x24e08c);
}
async function _0x2091f5(_0xd09c8c) {
  var { isInternational: _0x1a232c } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x4b2c70 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x1a232c || (_0x1a232c = !0x1), _0x4b2c70 || (_0x4b2c70 = !0x0));
  var _0x5752c5 = 13.25;
  _0x4b2c70 && (_0x5752c5 = 12.35);
  var _0x1c4b12 = _0xd09c8c + 0.0725 * _0xd09c8c,
    _0x59b7f6 =
      _0x1c4b12 * (_0x5752c5 / 0x64) +
      0.4 +
      (_0x1a232c ? 0.004 * _0x1c4b12 : 0x0),
    _0x1685b4 =
      _0xd09c8c -
      (_0x59b7f6 + (_0x1a232c ? 0.05 * _0x59b7f6 : 0x0)) -
      (_0x1a232c ? 0.035 * _0x1c4b12 : 0x0),
    { isUserTaxExempt: _0x12e9f3 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x12e9f3 || (_0x12e9f3 = !0x1),
    _0x12e9f3 || (_0x1685b4 /= 1.0725),
    _0x1a232c && (_0x1685b4 -= (3.5 * _0x1685b4) / 0x64),
    _0x1685b4
  );
}
function _0x2b6a2a(_0x56ce4f = null) {
  console["log"]("createButtonToSaveSeller", _0x56ce4f);
  var _0x5ece79 = document["createElement"]("a");
  (_0x5ece79["setAttribute"]("id", "saveSellerLink"),
    _0x5ece79["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x5ece79["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x2ed0f7 = document["createElement"]("img");
  return (
    _0x2ed0f7["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x2ed0f7["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5ece79["appendChild"](_0x2ed0f7),
    _0x5ece79["addEventListener"]("click", async function (_0x5a6b02) {
      (_0x5a6b02["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x56ce4f));
      var _0x845c85;
      if (!_0x56ce4f) {
        var _0xb66502 = _0x71ce41(_0x5a6b02);
        if (!_0xb66502) return;
        var _0x4282ce = extractItemData(_0xb66502);
        ((_0x56ce4f = _0x4282ce["username"]),
          (_0x845c85 = _0x4282ce["itemNumber"]));
      }
      if (
        _0x56ce4f["includes"]("\x20") ||
        _0x56ce4f !== _0x56ce4f["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x56ce4f,
        ),
          (_0x56ce4f = await _0x25a4c(_0x845c85)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x56ce4f,
          ));
      else _0x56ce4f = _0x56ce4f["toLowerCase"]();
      _0x5ece79["setAttribute"]("data-seller-name", _0x56ce4f);
      var { ebayCompetitors: _0x3c216b } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x4c33b3 = (_0x3c216b = _0x3c216b || [])["indexOf"](_0x56ce4f);
      console["log"]("ebayCompetitors", _0x3c216b);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x4c33b3
            ? (console["log"]("save-seller\x20clicked\x20username", _0x56ce4f),
              _0x3c216b["push"](_0x56ce4f),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x2ed0f7["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x56ce4f,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x2ed0f7["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x4c33b3)
            (console["log"]("remove-seller\x20clicked\x20username", _0x56ce4f),
              _0x3c216b["splice"](_0x4c33b3, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x2ed0f7["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x56ce4f,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x3c216b });
    }),
    _0x5ece79
  );
}
async function _0x25062d(_0x1f688e, _0x449622) {
  var { ebayCompetitors: _0xad3234 } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x2712a5 = (_0xad3234 = _0xad3234 || [])["indexOf"](_0x449622),
    _0x1965b8 = _0x1f688e["querySelector"]("img");
  -0x1 !== _0x2712a5
    ? (_0x1f688e["classList"]["replace"]("save-seller", "remove-seller"),
      _0x1965b8["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x1f688e["classList"]["replace"]("remove-seller", "save-seller"),
      _0x1965b8["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x1f584e(
  _0x2e06ac = null,
  _0x1f1ef2 = null,
  _0x37441b = null,
  _0x2f784c = !0x0,
  _0x16b7f3 = null,
  _0x2cdd99 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x2e06ac));
  var _0x3f0d9a = _0x2b6a2a(_0x1f1ef2),
    _0xafb306 = _0x1ce03f(_0x2e06ac),
    _0x18ac06 = _0x15f734(_0x16b7f3),
    _0x1ecc1e = _0x569881(_0x2e06ac),
    _0x9e608 = _0x1f4c20(_0x2e06ac, _0x2cdd99, _0x16b7f3, _0x37441b),
    _0x193c45 = _0x569881(
      _0x2e06ac,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x413ede = _0x878e31(_0x37441b),
    _0x31f0d7 = _0xd5b075(_0x16b7f3),
    _0x2bcd07 = _0x6ec32e(_0x1f1ef2),
    _0x4d0582 = document["createElement"]("div");
  _0x4d0582["setAttribute"]("id", "search-div");
  var _0x4cb368 = document["createElement"]("label");
  ((_0x4cb368["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x4d0582["appendChild"](_0x4cb368),
    _0x4d0582["appendChild"](_0x9e608),
    _0x4d0582["appendChild"](_0x1ecc1e),
    _0x4d0582["appendChild"](_0xafb306),
    _0x4d0582["appendChild"](_0x413ede),
    _0x4d0582["appendChild"](_0x31f0d7),
    _0x4d0582["appendChild"](_0x193c45),
    console["log"]("CopyDataButton", _0x2e06ac, _0x2cdd99, _0x16b7f3));
  var _0x4dc415 = _0x1fdb3e(_0x2e06ac, _0x2cdd99, _0x16b7f3),
    _0x465861 = document["createElement"]("div");
  _0x465861["setAttribute"]("id", "item-buttons-div");
  var _0x2b7ee3 = document["createElement"]("div");
  (_0x2b7ee3["setAttribute"]("id", "main-buttons-div"),
    _0x2b7ee3["appendChild"](_0x2bcd07),
    _0x2b7ee3["appendChild"](_0x18ac06),
    _0x2b7ee3["appendChild"](_0x4dc415),
    _0x2b7ee3["appendChild"](_0x3f0d9a),
    _0x465861["appendChild"](_0x2b7ee3));
  if (_0x2f784c) {
    var _0x3b9aa5 = createButtonListToEbay();
    _0x465861["appendChild"](_0x3b9aa5);
  }
  return (_0x465861["appendChild"](_0x4d0582), _0x465861);
}
var _0x4ab599 = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0xd52fc9) => {
        (console["log"](
          _0xd52fc9,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x4ab599, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x3cc819) => {
        (console["log"](
          _0x3cc819,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x4ab599, "search-type", "keywords"));
      },
    },
  },
];
async function _0x4067a9() {
  var { convertToKeywords: _0x2a6a47 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x2a6a47 &&
    ((_0x2a6a47 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x4ab599,
      "search-type",
      _0x2a6a47 ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x4ab599 })[
      "init"
    ]());
}
var _0x118c0d = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0xfe68de) => {
        (console["log"](_0xfe68de, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x118c0d, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x5b9873) => {
        (console["log"](_0x5b9873, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x118c0d, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0xf98505) => {
        (console["log"](
          _0xf98505,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x118c0d, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0xc3238d) => {
        (console["log"](
          _0xc3238d,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x118c0d, "search-type", "keywords"));
      },
    },
  },
];
async function _0x4f3f33() {
  var { amazonSortType: _0x39bd99 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x36f4e3 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x36f4e3 &&
    ((_0x36f4e3 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x39bd99 &&
      ((_0x39bd99 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x118c0d, "sort-type", _0x39bd99),
    updateContextMenu(_0x118c0d, "search-type", _0x36f4e3),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x118c0d })[
      "init"
    ]());
}
_0x118c0d = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x495ca8) => {
        (console["log"](_0x495ca8, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x118c0d, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x2cf0f3) => {
        (console["log"](_0x2cf0f3, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x118c0d, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x1953d1 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x435dbf) => {
        (console["log"](_0x435dbf, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0x1953d1, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3526ed) => {
        (console["log"](_0x3526ed, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0x1953d1, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x1d1537) => {
        (console["log"](_0x1d1537, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0x1953d1, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x41cdc0) => {
        (console["log"](_0x41cdc0, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0x1953d1, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x4f551b) => {
        (console["log"](_0x4f551b, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0x1953d1, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x970a8c) => {
        (console["log"](_0x970a8c, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0x1953d1, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x97808b) => {
        (console["log"](_0x97808b, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0x1953d1, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x71a28f) => {
        (console["log"](_0x71a28f, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0x1953d1, "filter-type", "90"));
      },
    },
  },
];
async function _0x17487a() {
  var { selectedFilter: _0x5b34d9 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x5b34d9 &&
    ((_0x5b34d9 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0x1953d1, "filter-type", _0x5b34d9),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0x1953d1 })[
      "init"
    ]());
}
function _0x1a7887() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x15774e() {
  const _0x35910e = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x339172 = 0x0;
  const _0x185ea3 = () =>
    new Promise((_0x5b7f89, _0x100493) => {
      const _0x427a73 = new MutationObserver((_0x1e640e, _0x5f5a99) => {
        const _0x11defc = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x11defc &&
          (console["log"]("Details\x20form\x20found!"),
          _0x5f5a99["disconnect"](),
          _0x5b7f89(_0x11defc));
      });
      (_0x427a73["observe"](_0x35910e, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x427a73["disconnect"]();
          if (_0x339172 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x339172 + 0x1) +
                "/3)",
            ),
              _0x339172++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x5b7f89(_0x185ea3()), 0x1388));
          else
            _0x100493(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x51144c = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x51144c) {
    (_0x51144c["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x185ea3(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x2eefa6) {
      console["error"](_0x2eefa6["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x3ac3a4(_0x19fa6d = null, _0x197001 = null, _0xa9a95a = null) {
  var _0x5611d1 = document["createElement"]("a");
  (_0x5611d1["setAttribute"]("id", "copyDataLink"),
    _0x5611d1["setAttribute"]("class", "a-link-text"),
    _0x5611d1["classList"]["add"]("icon"),
    _0x5611d1["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x2692ec = document["createElement"]("img");
  return (
    _0x2692ec["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x2692ec["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5611d1["appendChild"](_0x2692ec),
    _0x5611d1["addEventListener"]("click", async function (_0x503908) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x19fa6d,
        _0x197001,
        _0xa9a95a,
      ),
        _0x503908["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x19fa6d && _0x197001 && _0xa9a95a) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x19fa6d,
          _0x197001,
          _0xa9a95a,
        );
        isNaN(_0x197001) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x197001),
          (_0x197001 = _0x197001["replace"](/[^0-9.]/g, "")));
        var _0x4f1dad = JSON["stringify"]({
          title: _0x19fa6d,
          price: _0x197001,
          itemNumber: _0xa9a95a,
        });
        (_0x575794(
          (_0x17b752 = await findSimiliarProducts(_0x4f1dad))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x17b752),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x19fa6d || !_0x197001 || !_0xa9a95a) {
          var _0x4dbae2 = _0x71ce41(_0x503908);
          if (!_0x4dbae2) return;
        }
        var _0x1284a6 = extractItemData(_0x4dbae2);
        (console["log"]("itemData", _0x1284a6),
          (_0x4f1dad = JSON["stringify"](_0x1284a6)));
        var _0x17b752;
        (_0x575794(
          (_0x17b752 = await findSimiliarProducts(_0x4f1dad))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x17b752),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x5611d1
  );
}
async function findSimiliarProducts(_0x39b4c5) {
  console["log"]("findSimiliarProducts", _0x39b4c5);
  var _0x1165a0 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x39b4c5,
  });
  return (console["log"]("response", _0x1165a0), _0x1165a0["productLinks"]);
}
function _0x575794(_0x256b94) {
  const _0x83bc94 = document["getElementById"]("productLinksModalOverlay");
  _0x83bc94 && _0x83bc94["remove"]();
  const _0x3faea4 = document["createElement"]("div");
  ((_0x3faea4["id"] = "productLinksModalOverlay"),
    _0x3faea4["classList"]["add"]("product-links-modal-overlay"));
  const _0x3b2a64 = document["createElement"]("div");
  _0x3b2a64["classList"]["add"]("product-links-modal");
  const _0x377ca7 = document["createElement"]("div");
  _0x377ca7["classList"]["add"]("modal-button-container");
  const _0x37452f = document["createElement"]("button");
  (_0x37452f["classList"]["add"]("close-button"),
    (_0x37452f["innerText"] = "Close"),
    _0x37452f["addEventListener"]("click", () => {
      _0x3faea4["remove"]();
    }));
  const _0x37691b = document["createElement"]("button");
  (_0x37691b["classList"]["add"]("copy-button"),
    (_0x37691b["innerText"] = "Copy"),
    _0x37691b["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x256b94),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0xe45428) {
        console["error"]("Failed\x20to\x20copy:", _0xe45428);
      }
    }));
  const _0x7f3baa = document["createElement"]("h2");
  _0x7f3baa["innerText"] = "Similar\x20Product\x20Links";
  const _0x90a158 = document["createElement"]("textarea");
  ((_0x90a158["value"] = _0x256b94),
    _0x90a158["setAttribute"]("readonly", !0x0),
    (_0x90a158["style"]["width"] = "100%"),
    (_0x90a158["style"]["height"] = "300px"),
    _0x377ca7["appendChild"](_0x37691b),
    _0x377ca7["appendChild"](_0x37452f),
    _0x3b2a64["appendChild"](_0x377ca7),
    _0x3b2a64["appendChild"](_0x7f3baa),
    _0x3b2a64["appendChild"](_0x90a158),
    _0x3faea4["appendChild"](_0x3b2a64),
    document["body"]["appendChild"](_0x3faea4));
}
(console["log"]("content/ebay/best_offer/functions.js"),
  console["log"]("content/ebay/best_offer/content.js"),
  (async () => {
    var _0x56c93d = await _0x5e6058();
    console["log"]("membership:", _0x56c93d);
    if ("ultimate" == _0x56c93d) {
      console["log"](
        "You\x20are\x20a\x20member\x20of\x20the\x20sniper\x20list.",
      );
      var _0x55133b = document["querySelector"](
          ".app-manageoffer-item-card__title\x20a",
        )["href"]["split"]("/"),
        _0x4733af = _0x2491bb(
          (_0x55133b = _0x55133b[_0x55133b["length"] - 0x1]),
        ),
        _0x5a3346 = document["querySelector"](
          ".app-manageoffer-item-card__title",
        );
      _0x5a3346["insertBefore"](_0x4733af, _0x5a3346["firstChild"]);
    } else
      alert(
        "You\x20are\x20not\x20a\x20member\x20of\x20the\x20sniper\x20list.\x20Please\x20contact\x20support.",
      );
  })());
