function _0x297165(_0xca0995, _0x124714) {
  return (
    console["log"]("test\x20save\x20to\x20local\x20storage"),
    console["log"]("key\x20" + _0xca0995 + ",\x20value\x20" + _0x124714),
    new Promise((_0x17689f, _0x3f8339) => {
      chrome["storage"]["local"]["set"](
        { [_0xca0995]: _0x124714 },
        function () {
          (console["log"]("my\x20key", _0xca0995),
            chrome["storage"]["local"]["get"](_0xca0995, function (_0x259ab3) {
              (console["log"](
                "the\x20Value\x20currently\x20is\x20",
                _0x259ab3[_0xca0995],
              ),
                _0x17689f());
            }));
        },
      );
    })
  );
}
function _0x46b3e3(_0x237eb0) {
  return new Promise((_0x316a6a, _0x910c6b) => {
    chrome["storage"]["local"]["get"](_0x237eb0, function (_0x50b24f) {
      (console["log"]("Value\x20currently\x20is\x20", _0x50b24f[_0x237eb0]),
        _0x316a6a(_0x50b24f[_0x237eb0]));
    });
  });
}
var _0x505daf = (_0x3fe447, _0x56ef32) => {
  var _0x15a1f1 = document["querySelector"](_0x3fe447);
  console["log"]("Checking");
  if (_0x15a1f1) return (console["log"]("Found"), _0x56ef32(_0x15a1f1));
  setTimeout(() => _0x505daf(_0x3fe447, _0x56ef32), 0x1f4);
};
function _0x36029f(_0x240a50, _0x45375c = 0x32, _0x105372 = 0x64) {
  const _0x29af9a = document["querySelector"](_0x240a50);
  !window["__" + _0x240a50] &&
    ((window["__" + _0x240a50] = 0x0),
    (window["__" + _0x240a50 + "__delay"] = _0x45375c),
    (window["__" + _0x240a50 + "__tries"] = _0x105372));
  if (null === _0x29af9a) {
    if (window["__" + _0x240a50] >= window["__" + _0x240a50 + "__tries"])
      return ((window["__" + _0x240a50] = 0x0), Promise["resolve"](null));
    return new Promise((_0x1b7419) => {
      (window["__" + _0x240a50]++,
        setTimeout(_0x1b7419, window["__" + _0x240a50 + "__delay"]));
    })["then"](() => _0x36029f(_0x240a50));
  }
  return Promise["resolve"](_0x29af9a);
}
function _0x186af9(
  _0x3e2344 = document,
  _0x3f6687,
  _0x51a096 = 0x32,
  _0xef3524 = 0x64,
) {
  const _0x128574 = _0x3e2344["querySelector"](_0x3f6687);
  !window["__" + _0x3f6687] &&
    ((window["__" + _0x3f6687] = 0x0),
    (window["__" + _0x3f6687 + "__delay"] = _0x51a096),
    (window["__" + _0x3f6687 + "__tries"] = _0xef3524));
  if (null === _0x128574) {
    if (window["__" + _0x3f6687] >= window["__" + _0x3f6687 + "__tries"])
      return ((window["__" + _0x3f6687] = 0x0), Promise["resolve"](null));
    return new Promise((_0x4f2cf5) => {
      (window["__" + _0x3f6687]++,
        setTimeout(_0x4f2cf5, window["__" + _0x3f6687 + "__delay"]));
    })["then"](() => _0x36029f(_0x3f6687));
  }
  return Promise["resolve"](_0x128574);
}
(console["log"]("promoted_listing.js:\x20"),
  window["parent"]["postMessage"](
    { pageLoaded_for_promoted_listing: !0x0 },
    "*",
  ),
  window["addEventListener"]("message", (_0x49b9a1) => {
    var _0x200092 = JSON["stringify"](_0x49b9a1["data"]);
    (console["log"](
      "Received\x20message\x20on\x20promoted\x20listing:\x20" + _0x200092,
    ),
      "send_message_to_promoted_listing_to_click_promoted_listing_button" ===
        _0x49b9a1["data"]["type"] && _0x19fe43(_0x49b9a1["data"]["adRate"]));
  }));
async function _0x19fe43(_0x5ac52d) {
  (await _0x2e0c27(), await _0x538bc3(_0x5ac52d));
}
function _0x2e0c27() {
  return new Promise((_0x2ef7af, _0x425a18) => {
    (document["getElementById"]("optinCheckbox")["click"](), _0x2ef7af());
  });
}
async function _0x538bc3(_0x1da1aa) {
  await _0x36029f("#adRate");
  var _0x1b0bbd = document["getElementById"]("adRate");
  ((_0x1b0bbd["value"] = _0x1da1aa),
    _0x1b0bbd["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    _0x1b0bbd["parentElement"]["nextSibling"]["nextSibling"]["click"]());
}
function _0x541fc9(_0x1989d7) {
  return new Promise((_0x1bfa9e, _0x14c283) => {
    setTimeout(() => {
      _0x1bfa9e();
    }, _0x1989d7);
  });
}
