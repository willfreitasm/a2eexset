# Gemini Title Generator API

A cost-efficient eBay title generation API using Google Gemini AI.

## Cost Comparison
- **Google Gemini Flash 2.0**: ~$0.13 per 1,000 requests (~$4/month for 1,000/day)
- **OpenAI GPT-4o-mini**: ~$0.26 per 1,000 requests (~$8/month for 1,000/day)

## Setup

### 1. Get Your Gemini API Key
1. Go to https://aistudio.google.com/app/apikey
2. Click "Create API Key"
3. Copy your API key

### 2. Install Dependencies
```bash
cd gemini-title-api
npm install
```

### 3. Configure API Key
```bash
# Copy the example env file
cp .env.example .env

# Edit .env and add your API key
# GEMINI_API_KEY=your_actual_api_key_here
```

### 4. Start the Server
```bash
npm start
```

Server will run on http://localhost:3000

## Test the API

### Using curl:
```bash
curl -X POST http://localhost:3000 \
  -H "Content-Type: application/json" \
  -d '{
    "request_type": "generate_10_titles",
    "product_title": "Bedroom Table Lamps",
    "product_description": "Beige silver touch bedside lamps with USB ports",
    "language": "english"
  }'
```

### Using the Extension:
The API uses the exact same interface as your current API, so you just need to change the URL in your extension from:
```
https://suggestoptimizedtitles-djybcnnsgq-uc.a.run.app
```
to:
```
http://localhost:3000
```

## Supported Languages
- english
- spanish
- french
- german
- italian

## Response Format
Returns an array of 5 title strings:
```json
[
  "Touch Control Table Lamps Set of 2 - Beige Silver Bedside Lamps with USB Ports",
  "Modern Bedroom Lamps Pair - Touch Dimmable Nightstand Lamps with USB Charging",
  "Elegant Beige Table Lamps - Set of 2 Touch Control Lamps with USB C+A Ports",
  "Stylish Bedside Lamps Set - Silver Beige Touch Lamps with 3-Way Dimming USB",
  "Premium Nightstand Lamps Pair - Touch Control Beige Lamps with USB Charging Ports"
]
```

## Monitoring Costs

To track your usage:
1. Go to https://aistudio.google.com/app/apikey
2. Click on your API key
3. View usage statistics

Free tier: 15 requests/minute (21,600/day)
Paid tier: $0.075 per 1M input chars, $0.30 per 1M output chars
