# Deploy to Google Cloud Run - Step by Step

## Prerequisites
- Your Gemini API key (you already have this!)
- A Google Cloud account (same account you used for Gemini)

---

## 🚀 Deployment Steps (5 minutes)

### Step 1: Install Google Cloud CLI

**Windows:**
1. Download: https://dl.google.com/dl/cloudsdk/channels/rapid/GoogleCloudSDKInstaller.exe
2. Run the installer
3. Follow the prompts (keep default settings)
4. **Restart your terminal/command prompt**

**OR use WSL/Linux:**
```bash
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
```

### Step 2: Login to Google Cloud
```bash
gcloud auth login
```
This will open your browser - login with the same Google account you used for Gemini API.

### Step 3: Create a Google Cloud Project
```bash
gcloud projects create ebay-title-gen-001 --name="eBay Title Generator"
gcloud config set project ebay-title-gen-001
```

**Note:** If `ebay-title-gen-001` is taken, try `ebay-title-gen-002`, `ebay-title-gen-003`, etc.

### Step 4: Enable Required APIs
```bash
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
```

### Step 5: Navigate to Your Project Folder
```bash
cd "C:\Users\wifmm\Downloads\extensions\eBayLister\EbayLister4 - basic change\gemini-title-api"
```

**OR in WSL:**
```bash
cd "/mnt/c/Users/wifmm/Downloads/extensions/eBayLister/EbayLister4 - basic change/gemini-title-api"
```

### Step 6: Deploy to Cloud Run
```bash
gcloud run deploy gemini-title-api \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE
```

**IMPORTANT:** Replace `YOUR_GEMINI_API_KEY_HERE` with your actual Gemini API key!

**What this does:**
- Builds your app in the cloud
- Creates a container
- Deploys it to Cloud Run
- Makes it publicly accessible
- Takes ~2-3 minutes

### Step 7: Get Your URL

After deployment completes, you'll see output like:
```
Service URL: https://gemini-title-api-xxxxx-uc.a.run.app
```

**Copy this URL!** This is your new API endpoint.

---

## 🧪 Test Your Deployed API

### Test with curl:
```bash
curl -X POST https://YOUR-CLOUD-RUN-URL-HERE \
  -H "Content-Type: application/json" \
  -d "{\"request_type\":\"generate_10_titles\",\"product_title\":\"Bedroom Table Lamps\",\"product_description\":\"Beige silver touch bedside lamps\",\"language\":\"english\"}"
```

### Test in browser:
Visit: `https://YOUR-CLOUD-RUN-URL-HERE/health`

You should see: `{"status":"ok","service":"Gemini Title Generator"}`

---

## 💰 Pricing (You'll Stay in Free Tier)

**Cloud Run Free Tier (per month):**
- ✅ 2 million requests
- ✅ 360,000 GB-seconds of memory
- ✅ 180,000 vCPU-seconds

**Your usage (1,000 requests/day):**
- 30,000 requests/month
- Well within free tier! ✅

**Gemini API:**
- Free: 15 requests/minute
- Paid: ~$0.13 per 1,000 requests

**Total cost:** $0 - $4/month (depending on volume)

---

## 🔧 Update Your Extension

Once deployed, update your extension to use the new URL.

Find this line in your code:
```javascript
'https://suggestoptimizedtitles-djybcnnsgq-uc.a.run.app'
```

Replace with:
```javascript
'https://YOUR-CLOUD-RUN-URL.run.app'
```

---

## 📊 Monitor Usage

**View logs:**
```bash
gcloud run services logs read gemini-title-api --region us-central1
```

**View metrics:**
```bash
gcloud run services describe gemini-title-api --region us-central1
```

**Or use web console:**
https://console.cloud.google.com/run

---

## 🔄 Update Your API (After Code Changes)

Just run the deploy command again:
```bash
gcloud run deploy gemini-title-api \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE
```

---

## ❓ Troubleshooting

**"Project already exists":**
Use a different project name: `ebay-title-gen-002`

**"Permission denied":**
Make sure you're logged in: `gcloud auth login`

**"Billing not enabled":**
Go to https://console.cloud.google.com/billing and add a payment method (you won't be charged if you stay in free tier)

**Need help?**
Check logs: `gcloud run services logs read gemini-title-api --region us-central1 --limit 50`
