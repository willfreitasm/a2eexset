function _0x215df5() {
  return new Promise((_0x593c3f) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x593c3f();
      });
    });
  });
}
function _0x4af93f() {
  return new Promise((_0x548896) => {
    requestIdleCallback(() => {
      _0x548896();
    });
  });
}
function _0x596076(_0x4033d1 = 0x3e8) {
  return new Promise((_0x24648d, _0x5f44f8) => {
    let _0x371a2b,
      _0x154d43 = Date["now"](),
      _0x5d04c2 = !0x1;
    function _0x3af38d() {
      if (Date["now"]() - _0x154d43 > _0x4033d1)
        (_0x5d04c2 && _0x371a2b["disconnect"](), _0x24648d());
      else setTimeout(_0x3af38d, _0x4033d1);
    }
    const _0x1b9127 = () => {
        _0x154d43 = Date["now"]();
      },
      _0x5786d5 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x371a2b = new MutationObserver(_0x1b9127)),
        _0x371a2b["observe"](document["body"], _0x5786d5),
        (_0x5d04c2 = !0x0),
        setTimeout(_0x3af38d, _0x4033d1));
    else
      window["onload"] = () => {
        ((_0x371a2b = new MutationObserver(_0x1b9127)),
          _0x371a2b["observe"](document["body"], _0x5786d5),
          (_0x5d04c2 = !0x0),
          setTimeout(_0x3af38d, _0x4033d1));
      };
  });
}
async function _0x9fd4ad() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x596076(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x3bd18e(_0x42bc38, _0x3ed0b3) {
  const _0x37e111 = new Promise((_0x116689, _0x3403ab) => {
    const _0x4aafd2 = setTimeout(() => {
      (clearTimeout(_0x4aafd2),
        _0x3403ab(new Error("Operation\x20timed\x20out")));
    }, _0x42bc38);
  });
  return Promise["race"]([_0x3ed0b3, _0x37e111]);
}
function _0x2aa5d7(_0x1a2f3a) {
  const _0x4b4361 = (_0x1a2f3a = _0x1a2f3a["replace"](/[^0-9.,]/g, ""))[
      "lastIndexOf"
    ](","),
    _0x123e61 = _0x1a2f3a["lastIndexOf"](".");
  return (
    (_0x1a2f3a =
      _0x4b4361 > _0x123e61
        ? (_0x1a2f3a = _0x1a2f3a["replace"](/\./g, ""))["replace"](",", ".")
        : _0x1a2f3a["replace"](/,/g, "")),
    parseFloat(_0x1a2f3a)
  );
}
var _0x118839 = !0x1;
console["log"]("ebay.active_listings_functions.js\x20loaded");
async function _0x552585(_0x3f2b42) {
  var _0x4a9f0a = !0x0,
    _0x573edd = _0x543048(),
    _0x95ebd9,
    _0x4aaac5;
  for (; _0x4a9f0a; ) {
    ((_0x95ebd9 = _0x3a8a6d()),
      (_0x4aaac5 = await _0x1b4dd9()),
      (skuList = skuList["concat"](_0x4aaac5)),
      await _0x3e70f2(_0x4aaac5),
      (document["title"] =
        "Page\x20" +
        _0x95ebd9 +
        "/" +
        _0x573edd +
        "\x20SKUS:\x20" +
        skuList["length"]),
      (_0x4a9f0a = await _0x36aeb2()) &&
        (await _0x4adb74(),
        await _0x2c5c00(0x3e8),
        await _0x46e804(_0x95ebd9 + 0x1),
        chrome["runtime"]["sendMessage"]({ type: "updateData" }),
        chrome["storage"]["local"]["set"]({ page_number: _0x95ebd9 + 0x1 })));
  }
  ((document["title"] = "Saving\x20Skus\x20-\x20" + document["title"]),
    await _0x3e70f2(_0x4aaac5),
    (document["title"] = "Saved\x20SKUS:\x20" + skuList["length"]));
}
function _0x3e70f2(_0x4316b8) {
  return new Promise((_0x108558) => {
    chrome["storage"]["local"]["get"]("skuList", (_0x6cffc0) => {
      var _0x4740cd = _0x6cffc0["skuList"]
        ? _0x6cffc0["skuList"]["concat"](_0x4316b8)
        : _0x4316b8;
      chrome["storage"]["local"]["set"]({ skuList: _0x4740cd }, _0x108558);
    });
  });
}
async function _0x136ce4() {
  return new Promise((_0x3c43f2) => {
    chrome["storage"]["local"]["get"]("skuList", async (_0x15361e) => {
      var _0x3181c9 = await _0x1b4dd9(),
        _0x23ea0a = _0x15361e["skuList"]["concat"](_0x3181c9);
      chrome["storage"]["local"]["set"]({ skuList: _0x23ea0a }, _0x3c43f2);
    });
  });
}
function _0x2c5c00(_0x493438) {
  return new Promise((_0x5a2d96) => setTimeout(_0x5a2d96, _0x493438));
}
async function _0x46e804(_0x5557c2) {
  for (; _0x3a8a6d() !== _0x5557c2; ) await _0x2c5c00(0x3e8);
}
function _0x4adb74() {
  document["getElementsByClassName"]("pagination__next")[0x0]["click"]();
}
function _0x36aeb2() {
  var _0x44fcd1 = document["querySelector"](".pagination__next");
  return !!_0x44fcd1 && "true" !== _0x44fcd1["getAttribute"]("aria-disabled");
}
function _0x543048() {
  var _0x2fdf50 = document["querySelector"](".go-to-page\x20.label");
  if (_0x2fdf50) return parseInt(_0x2fdf50["innerText"]["replace"](/\D/g, ""));
  var _0x1975a3 = document["querySelectorAll"](".pagination__items\x20li");
  if (_0x1975a3["length"] > 0x0) {
    var _0xe02c77 = _0x1975a3[_0x1975a3["length"] - 0x1];
    return parseInt(_0xe02c77["innerText"]);
  }
  return 0x1;
}
function _0x3a8a6d() {
  return (_0x4f18ea = document["querySelector"](
    ".go-to-page\x20.textbox__control",
  ))
    ? parseInt(_0x4f18ea["value"])
    : (_0x4f18ea = document["querySelector"](
          ".pagination__items\x20[aria-current=\x22page\x22]",
        ))
      ? parseInt(_0x4f18ea["innerText"])
      : 0x1;
  var _0x4f18ea;
}
function _0x1b4dd9() {
  return new Promise((_0x4f373c) => {
    const _0x3467c8 = [];
    (_0x5e65db()["forEach"]((_0xe8d04f) => {
      _0xe8d04f["querySelectorAll"]("tr")["forEach"]((_0x3094fd) => {
        const _0x2862df = _0x3094fd["querySelector"](
          "td[class*=\x22listingSKU\x22]\x20.cell-wrapper",
        );
        if (_0x2862df) {
          const _0x5250a6 = _0x2862df["textContent"]["trim"]();
          _0x5250a6 && _0x3467c8["push"](_0x5250a6);
        }
      });
    }),
      _0x4f373c(_0x3467c8));
  });
}
function _0x5e65db() {
  return document["querySelectorAll"]("table[id*=gridData]\x20tbody");
}
function _0x315468(_0x1422f3) {
  const _0x291c9e = _0x5e65db();
  for (const _0x4fcfb5 of _0x291c9e)
    if (
      _0x4fcfb5["querySelector"](".grid-row")["getAttribute"]("data-id") ===
      _0x1422f3
    )
      return _0x4fcfb5;
  return null;
}
function _0x286c18() {
  return document["querySelectorAll"]("table[id*=gridData]")["length"] > 0x0;
}
function fetchEbayData(_0x53a59c) {
  let _0x1000cd = {};
  var _0x47029b = _0x53a59c["querySelector"]("div[class*=\x22title__text\x22]");
  _0x47029b && (_0x1000cd["title"] = _0x47029b["textContent"]["trim"]());
  var _0x267f66 = _0x53a59c["querySelector"]("td[class*=\x22image\x22]\x20img");
  _0x267f66 && (_0x1000cd["photos"] = _0x267f66["getAttribute"]("src"));
  var _0x1cf5a6 = _0x53a59c["querySelector"]("td[class*=\x22listingSKU");
  _0x1cf5a6 && (_0x1000cd["customLabel"] = _0x1cf5a6["textContent"]["trim"]());
  if (
    (_0x5c7c42 = _0x53a59c["querySelector"](
      "td[class*=\x22price\x22]\x20[class*=\x22sh-strikethrough\x22]",
    ))
  ) {
    var _0x5b6543 = _0x5c7c42["textContent"]["trim"]();
    _0x1000cd["price"] = _0x2aa5d7(_0x5b6543);
  } else {
    var _0x5c7c42;
    if (
      (_0x5c7c42 = _0x53a59c["querySelector"](
        "td[class*=\x22price\x22]\x20[class*=\x22price__current\x22]",
      ))
    ) {
      const _0x3dc5aa = _0x5c7c42["textContent"]["trim"]();
      _0x1000cd["price"] = _0x2aa5d7(_0x3dc5aa);
    }
  }
  var _0x847236 = _0x53a59c["querySelector"](
    "td[class*=\x22availableQuantity\x22]\x20[class*=\x22cell-wrapper\x22]",
  );
  _0x847236 &&
    (_0x1000cd["availableQty"] = parseInt(
      _0x847236["textContent"]["trim"]()["replace"](/[^0-9\.]+/g, ""),
    ));
  var _0x3d950b = _0x53a59c["querySelector"]("td[class*=\x22listingId\x22]");
  (_0x3d950b && (_0x1000cd["itemNumber"] = _0x3d950b["textContent"]["trim"]()),
    _0x3d950b ||
      (_0x1000cd["itemNumber"] =
        _0x53a59c["querySelector"](".grid-row")["getAttribute"]("data-id")));
  var _0x308fb5 = _0x53a59c["querySelector"]("td[class*=\x22soldQuantity\x22]");
  _0x308fb5 &&
    (_0x1000cd["soldQuantity"] = parseInt(
      _0x308fb5["textContent"]["trim"]()["replace"](/[^0-9\.]+/g, ""),
    ));
  var _0x1d4a11 = _0x53a59c["querySelector"](
    "td[class*=\x22scheduledStartDate\x22]\x20[class*=\x22text-column\x22]\x20div",
  );
  _0x1d4a11 &&
    (_0x1000cd["scheduledStartDate"] = _0x1d4a11["textContent"]["trim"]());
  var _0x56d938 = _0x53a59c["querySelector"](
    "td[class*=\x22timeRemaining\x22]\x20[class*=\x22text-column\x22]\x20div",
  );
  _0x56d938 && (_0x1000cd["timeLeft"] = _0x56d938["textContent"]["trim"]());
  var _0x14cf6f = _0x53a59c["querySelector"](
    "td[class*=\x22visitCount\x22]\x20.cell-wrapper\x20.fake-link",
  );
  return (
    _0x14cf6f &&
      (_0x1000cd["viewCount"] = parseInt(
        _0x14cf6f["textContent"]["trim"]()["replace"](/[^0-9\.]+/g, ""),
      )),
    _0x1000cd
  );
}
function _0x51a515(_0x257eff) {
  var _0x31dcf7 = document["createElement"]("button"),
    _0x14dcab =
      _0x257eff["charAt"](0x0)["toUpperCase"]() + _0x257eff["slice"](0x1);
  return (
    (_0x31dcf7["innerHTML"] = _0x14dcab + "\x20Relist"),
    _0x31dcf7["classList"]["add"]("relist-button"),
    _0x31dcf7["classList"]["add"](_0x257eff + "-relist-button"),
    (_0x31dcf7["onclick"] = async function (_0x540bd7) {
      (_0x540bd7["preventDefault"](),
        console["log"]("Relist\x20button\x20clicked"),
        (this["disabled"] = !0x0),
        (this["innerHTML"] =
          "Relisting\x20" +
          _0x14dcab +
          "...\x20<span\x20class=\x27loader\x27></span>"),
        chrome["storage"]["local"]["set"]({ bulkListType: _0x257eff }));
      var _0x4337e9 = this;
      for (; "TR" !== _0x4337e9["tagName"]; )
        _0x4337e9 = _0x4337e9["parentElement"];
      console["log"](_0x4337e9);
      var _0x15eb3f = fetchEbayData(_0x4337e9);
      console["log"](_0x15eb3f);
      var _0x4bd69c = await new Promise((_0x49a2c9) => {
        chrome["runtime"]["sendMessage"](
          { type: "relistItem", ebayData: _0x15eb3f },
          function (_0x1fd8b9) {
            (console["log"](_0x1fd8b9), _0x49a2c9(_0x1fd8b9["response"]));
          },
        );
      });
      console["log"]("Response\x20received", _0x4bd69c);
      var _0x101258 = document["createElement"]("div");
      _0x101258["className"] = "info-box";
      if (_0x4bd69c) {
        var _0x204ede = _0x4bd69c["status"]
            ? _0x4bd69c["status"]
            : "Not\x20Available",
          _0xe9319c = _0x4bd69c["url"]
            ? "<a\x20href=\x22" +
              _0x4bd69c["url"] +
              "\x22\x20target=\x22_blank\x22>" +
              _0x4bd69c["url"] +
              "</a>"
            : "Not\x20Available",
          _0x170cd8 = _0x4bd69c["message"]
            ? _0x4bd69c["message"]
            : "Not\x20Available",
          _0x3b1ce6 = _0x4bd69c["ebayItemLink"]
            ? "<a\x20href=\x22" +
              _0x4bd69c["ebayItemLink"] +
              "\x22\x20target=\x22_blank\x22>View\x20Item</a>"
            : "Not\x20Available";
        _0x101258["innerHTML"] =
          "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p>Status:\x20" +
          _0x204ede +
          "</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p>URL:\x20" +
          _0xe9319c +
          "</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p>Message:\x20" +
          _0x170cd8 +
          "</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p>" +
          _0x3b1ce6 +
          "</p>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20";
      } else
        _0x101258["innerHTML"] = "<p>Error:\x20No\x20response\x20received</p>";
      (_0x4337e9["querySelector"]("td[class*=\x22title\x22]")["appendChild"](
        _0x101258,
      ),
        await new Promise((_0x5680bf) => setTimeout(_0x5680bf, 0x7d0)),
        (this["innerHTML"] = _0x14dcab + "\x20Relisted"));
    }),
    _0x31dcf7
  );
}
function _0x2f6e9a(_0x3ecc3d) {
  console["log"]("createDisplayElement\x20message", _0x3ecc3d);
  var _0x22168e = document["createElement"]("div");
  _0x22168e["className"] = "info-box";
  var _0x58e460 = "itemListed" == _0x3ecc3d["status"] ? "success" : "error",
    _0x181339 = _0x3ecc3d["ebayItemLink"]
      ? "<a\x20href=\x22" +
        _0x3ecc3d["ebayItemLink"] +
        "\x22\x20target=\x22_blank\x22>View\x20Item</a>"
      : "Not\x20Available",
    _0x4daf95 = _0x3ecc3d["url"]
      ? "<a\x20href=\x22" +
        _0x3ecc3d["url"] +
        "\x22\x20target=\x22_blank\x22>Amazon</a>"
      : "Not\x20Available",
    _0x219899 =
      "<span\x20class=\x22time-tracker\x22>[" +
      new Date()["toLocaleTimeString"]() +
      "]</span>";
  return (
    (_0x22168e["innerHTML"] =
      "\x0a\x20\x20\x20\x20\x20\x20<p>Status:\x20" +
      _0x58e460 +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>Message:\x20" +
      _0x3ecc3d["message"] +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>" +
      _0x4daf95 +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>" +
      _0x181339 +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>" +
      _0x219899 +
      "</p>\x0a\x20\x20\x20\x20\x20\x20"),
    _0x22168e
  );
}
function _0x38039a() {
  var _0x4ce030 = document["createElement"]("button");
  return (
    (_0x4ce030["innerHTML"] = "Update\x20List"),
    (_0x4ce030["className"] = "update-listing-button"),
    (_0x4ce030["onclick"] = async function (_0x423b69) {
      (_0x423b69["preventDefault"](),
        console["log"]("Update\x20Listing\x20button\x20clicked"),
        (this["disabled"] = !0x0),
        (this["innerHTML"] =
          "Updating\x20Listing...\x20<span\x20class=\x27loader\x27></span>"));
      var _0x40567d = this;
      for (; "TR" !== _0x40567d["tagName"]; )
        _0x40567d = _0x40567d["parentElement"];
      console["log"](_0x40567d);
      var _0x238086 = fetchEbayData(_0x40567d);
      console["log"](_0x238086);
      var _0x1e9e59 = await deductCredits(0);
      if (_0x1e9e59["success"]) {
        var _0x558c6f = await new Promise((_0x1117c7) => {
          chrome["runtime"]["sendMessage"](
            { type: "updateListing", ebayData: _0x238086 },
            function (_0x47b3f5) {
              (console["log"](_0x47b3f5), _0x1117c7(_0x47b3f5));
            },
          );
        });
        (console["log"]("Response\x20received", _0x558c6f),
          (this["innerHTML"] = "Listing\x20Updated"));
        var _0x24b66e = _0x2f6e9a(_0x558c6f["response"]);
        _0x40567d["querySelector"]("td[class*=\x22title\x22]")["appendChild"](
          _0x24b66e,
        );
      } else
        (console["log"]("deductCreditsResponse", _0x1e9e59),
          (this["innerHTML"] = "Error:\x20" + _0x1e9e59["message"]));
    }),
    _0x4ce030
  );
}
function _0x43c9ff() {
  var _0x489da2 = document["createElement"]("button");
  return (
    (_0x489da2["innerHTML"] = "Smart\x20Relist"),
    (_0x489da2["className"] = "smart-relist-button"),
    (_0x489da2["onclick"] = async function (_0x24ea2c) {
      (_0x24ea2c["preventDefault"](),
        console["log"]("Smart\x20Relist\x20button\x20clicked"));
      var _0x133104 = this;
      for (; "TR" !== _0x133104["tagName"]; )
        _0x133104 = _0x133104["parentElement"];
      console["log"](_0x133104);
      var _0x4f895a = await deductCredits(0);
      if (_0x4f895a["success"]) await _0x540c72(_0x133104);
      else
        (console["log"]("deductCreditsResponse", _0x4f895a),
          (this["innerHTML"] = "Error:\x20" + _0x4f895a["message"]));
    }),
    _0x489da2
  );
}
async function _0x540c72(_0x9927bb) {
  chrome["storage"]["local"]["set"]({ run_status_bulk_lister: !0x0 });
  var _0x679bf8 = _0x9927bb["querySelector"](".smart-relist-button");
  ((_0x679bf8["disabled"] = !0x0),
    (_0x679bf8["innerHTML"] =
      "Smart\x20Relisting...\x20<span\x20class=\x27loader\x27></span>"));
  var _0x56f401 = fetchEbayData(_0x9927bb);
  console["log"](_0x56f401);
  var _0x460b24 = await new Promise((_0x4095b6) => {
    chrome["runtime"]["sendMessage"](
      { type: "smartRelist", ebayData: _0x56f401 },
      function (_0xf63696) {
        (console["log"](_0xf63696), _0x4095b6(_0xf63696));
      },
    );
  });
  (console["log"]("Response\x20received", _0x460b24),
    (_0x679bf8["innerHTML"] = "Smart\x20Relisted"));
  var _0x269a87 = _0x2f6e9a(_0x460b24["response"]);
  return (
    _0x9927bb["querySelector"]("td[class*=\x22title\x22]")["appendChild"](
      _0x269a87,
    ),
    _0x460b24
  );
}
function _0x513b53() {
  var _0x570082 = document["createElement"]("button");
  return (
    (_0x570082["innerHTML"] = "Clone\x20List"),
    (_0x570082["className"] = "clone-list-button"),
    (_0x570082["onclick"] = async function (_0x17899a) {
      (_0x17899a["preventDefault"](),
        console["log"]("Clone\x20List\x20button\x20clicked"),
        (this["disabled"] = !0x0),
        (this["innerHTML"] =
          "Cloning\x20List...\x20<span\x20class=\x27loader\x27></span>"));
      var _0x5a496d = this;
      for (; "TR" !== _0x5a496d["tagName"]; )
        _0x5a496d = _0x5a496d["parentElement"];
      console["log"](_0x5a496d);
      var _0x21656c = fetchEbayData(_0x5a496d);
      console["log"](_0x21656c);
      var _0x5b8332 = await deductCredits(0);
      if (_0x5b8332["success"]) {
        var _0x37db55 = await new Promise((_0x4a616c) => {
          chrome["runtime"]["sendMessage"](
            { type: "cloneList", ebayData: _0x21656c },
            function (_0x36d8cf) {
              (console["log"](_0x36d8cf), _0x4a616c(_0x36d8cf));
            },
          );
        });
        (console["log"]("Response\x20received", _0x37db55),
          (this["innerHTML"] = "List\x20Cloned"));
        var _0x47fb91 = _0x2f6e9a(_0x37db55["response"]["response"]["message"]);
        _0x5a496d["querySelector"]("td[class*=\x22title\x22]")["appendChild"](
          _0x47fb91,
        );
      } else
        (console["log"]("deductCreditsResponse", _0x5b8332),
          (this["innerHTML"] = "Error:\x20" + _0x5b8332["message"]));
    }),
    _0x570082
  );
}
function findItemNode(_0x15926a) {
  var _0x1f9c48 = _0x5e65db();
  for (let _0x27ff4f = 0x0; _0x27ff4f < _0x1f9c48["length"]; _0x27ff4f++) {
    var _0xda683c = _0x1f9c48[_0x27ff4f];
    console["log"]("itemNode", _0xda683c);
    if (
      _0xda683c["querySelector"](".grid-row:not(.grid-row-notice)")[
        "getAttribute"
      ]("data-id") == _0x15926a
    )
      return _0xda683c;
  }
}
async function _0x3ef13a(_0x3fbb64, _0x13ef7c) {
  return new Promise((_0x420b94) => {
    new MutationObserver((_0x239747, _0xc80587) => {
      for (let _0x5059fa of _0x239747)
        if ("childList" === _0x5059fa["type"]) {
          const _0x20646c = Array["from"](
            document["querySelectorAll"](_0x3fbb64),
          );
          for (let _0x2301ea of _0x20646c)
            if (_0x13ef7c(_0x2301ea)) {
              (console["log"]("Element\x20found", _0x2301ea),
                _0xc80587["disconnect"](),
                _0x420b94(_0x2301ea));
              break;
            }
        }
    })["observe"](document["body"], { childList: !0x0, subtree: !0x0 });
  });
}
async function _0x5d7fab(_0x268baf) {
  (setTimeout(() => {
    return (console["log"]("endItem\x20timeout"), "timeout");
  }, 0x1d4c0),
    console["log"]("endItem", _0x268baf),
    _0x268baf["querySelector"](".toggle-menu.btn")["click"]());
  var _0xb09b80 = await _0x3ef13a("[class*=menu__item]", (_0x320126) => {
    const _0x2f1a4a = _0x320126["textContent"]["trim"]();
    return (
      "End\x20listing" === _0x2f1a4a ||
      "Angebot\x20beenden" === _0x2f1a4a ||
      "Mettre\x20fin\x20à\x20l\x27annonce" === _0x2f1a4a ||
      "Chiudi\x20l\x27inserzione" === _0x2f1a4a ||
      "Finalizar\x20anuncio" === _0x2f1a4a ||
      "p2380676.m4639.l73072" === (_0x320126["getAttribute"]("_sp") || "")
    );
  });
  ((_0xb09b80 = _0xb09b80["firstElementChild"]),
    await new Promise((_0x20a740) => setTimeout(_0x20a740, 0x7d0)),
    _0xb09b80["click"]());
  var _0x319238 = await _0x3ef13a(
    "[class*=se-end-listing]",
    (_0x1958fa) => null != _0x1958fa,
  );
  console["log"](".se-end-listing\x20element\x20found", _0x319238);
  var _0x339daa = _0x319238["querySelectorAll"]("button"),
    _0x1f5957;
  for (let _0x5208d1 = 0x0; _0x5208d1 < _0x339daa["length"]; _0x5208d1++) {
    var _0x28a40e = _0x339daa[_0x5208d1];
    if (
      "End\x20listing" === _0x28a40e["innerText"]["trim"]() ||
      "Angebot\x20beenden" === _0x28a40e["innerText"]["trim"]() ||
      "Mettre\x20fin\x20à\x20l\x27annonce" ===
        _0x28a40e["innerText"]["trim"]() ||
      "Chiudi\x20l\x27inserzione" === _0x28a40e["innerText"]["trim"]() ||
      "Finalizar\x20anuncio" === _0x28a40e["innerText"]["trim"]()
    ) {
      _0x1f5957 = _0x28a40e;
      break;
    }
  }
  return (
    console["log"]("finalEndListingButton", _0x1f5957),
    await new Promise((_0x1b540d) => setTimeout(_0x1b540d, 0x7d0)),
    _0x1f5957["click"](),
    "itemEnded"
  );
}
function _0x5d14f8() {
  var _0x2a3bb6 = document["createElement"]("button");
  return (
    (_0x2a3bb6["innerHTML"] = "End\x20Item"),
    (_0x2a3bb6["className"] = "end-item-button"),
    (_0x2a3bb6["onclick"] = async function (_0x35f8b0) {
      (_0x35f8b0["preventDefault"](),
        console["log"]("End\x20Item\x20button\x20clicked"),
        (this["disabled"] = !0x0),
        (this["innerHTML"] =
          "Ending\x20Item...\x20<span\x20class=\x27loader\x27></span>"));
      var _0x6d1b72 = this;
      for (; "TR" !== _0x6d1b72["tagName"]; )
        _0x6d1b72 = _0x6d1b72["parentElement"];
      console["log"](_0x6d1b72);
      var _0x301631 = fetchEbayData(_0x6d1b72);
      console["log"](_0x301631);
      var _0x117018 = await new Promise((_0x4b637b) => {
        chrome["runtime"]["sendMessage"](
          { type: "endItem", ebayData: _0x301631 },
          function (_0xd6f38f) {
            (console["log"](_0xd6f38f), _0x4b637b(_0xd6f38f));
          },
        );
      });
      (console["log"]("Response\x20received", _0x117018),
        _0x117018["response"]
          ? (this["innerHTML"] = "Item\x20Ended")
          : (this["innerHTML"] = "Error\x20Ending\x20Item"));
    }),
    _0x2a3bb6
  );
}
function _0x1e551c(_0x56e1e6, _0x499794) {
  const _0x3953fc = document["querySelector"](_0x56e1e6);
  if (_0x3953fc)
    (_0x3953fc["addEventListener"]("click", function (_0x5920bb) {
      let _0xe8c890 = _0x5920bb["target"];
      for (; _0xe8c890 && _0xe8c890 !== _0x3953fc; ) {
        if (_0xe8c890["matches"](_0x499794)) {
          _0x5920bb["preventDefault"]();
          const _0x3835bb = _0xe8c890["href"];
          (window["open"](_0x3835bb, "_blank"),
            console["log"](
              "Opening\x20" + _0x3835bb + "\x20in\x20a\x20new\x20tab.",
            ));
          return;
        }
        _0xe8c890 = _0xe8c890["parentElement"];
      }
    }),
      console["log"](
        "Event\x20delegation\x20setup\x20complete\x20for\x20opening\x20title\x20links\x20in\x20new\x20tab.",
      ));
  else console["warn"]("Container\x20not\x20found.");
}
async function fetchAllEbayData(_0x4d38c3) {
  var _0x1547a8 = [];
  for (const _0xb53df1 of _0x4d38c3)
    _0x1547a8["push"](fetchEbayData(_0xb53df1));
  return _0x1547a8;
}
async function _0x391f15(_0x22e620) {
  var _0x2ca68 = _0x5e65db();
  console["log"]("itemNodes", _0x2ca68);
  var filteredItemNodes = [];
  for (const _0x4b1353 of _0x2ca68) {
    var _0x39e689 = fetchEbayData(_0x4b1353);
    _0x22e620["includes"](_0x39e689["itemNumber"]) &&
      (console["log"]("itemNode\x20found", _0x4b1353),
      filteredItemNodes["push"](_0x4b1353));
  }
  return filteredItemNodes;
}
async function _0x583605(_0x31791d) {
  for (var _0x1ea705 of _0x31791d) {
    var _0x5ba813 = _0x1ea705["querySelector"](
      "input[id^=\x22shui-dt-checkone\x22]",
    );
    if (_0x5ba813) {
      var _0x408b64 = new MouseEvent("click", {
        view: window,
        bubbles: !0x0,
        cancelable: !0x0,
      });
      _0x5ba813["dispatchEvent"](_0x408b64);
    }
  }
  return _0x31791d;
}
function _0x12a288(_0x424225, _0x17f4d9, _0x1b130f = 0x2d0) {
  const _0x346627 = [],
    _0xdbb64e = _0x5e65db();
  console["log"]("itemNodes", _0xdbb64e);
  for (const _0x3d006e of _0xdbb64e) {
    var _0x34189d = fetchEbayData(_0x3d006e),
      _0x5e87c5 = _0x34189d["soldQuantity"],
      _0x262f36 = _0x34189d["viewCount"];
    isNaN(_0x5e87c5) ||
      isNaN(_0x262f36) ||
      (_0x14e1b9(_0x34189d["timeLeft"], _0x1b130f) &&
        _0x5e87c5 <= _0x424225 &&
        _0x262f36 <= _0x17f4d9 &&
        _0x346627["push"](_0x3d006e));
  }
  return _0x346627;
}
function _0x101d51() {
  const _0x281916 = document["createElement"]("button");
  return (
    (_0x281916["textContent"] = "Stop"),
    (_0x281916["className"] = "stop-button"),
    _0x281916["addEventListener"]("click", async (_0x8c5311) => {
      (_0x8c5311["preventDefault"](),
        console["log"]("Stop\x20button\x20clicked"),
        (document["title"] = "Stop\x20-\x20" + document["title"]),
        (_0x281916["disabled"] = !0x0),
        (_0x281916["innerHTML"] =
          "Stopping...\x20<span\x20class=\x27custom-loader\x27></span>"),
        (_0x118839 = !0x0),
        (_0x281916["textContent"] = "Stopped"));
    }),
    _0x281916
  );
}
async function _0x46d85e() {
  const _0x8f5cd9 = document["createElement"]("button");
  ((_0x8f5cd9["textContent"] =
    "Bulk\x20Smart\x20Relist\x20Low\x20Performing\x20Items"),
    (_0x8f5cd9["className"] = "bulk-smart-relist-button"),
    _0x8f5cd9["addEventListener"]("click", async (_0x97c0af) => {
      (_0x97c0af["preventDefault"](),
        console["log"]("Bulk\x20Smart\x20Relist\x20button\x20clicked"),
        (document["title"] =
          "Bulk\x20Smart\x20Relist\x20-\x20" + document["title"]),
        (_0x8f5cd9["disabled"] = !0x0),
        (_0x8f5cd9["innerHTML"] =
          "Processing...\x20<span\x20class=\x27custom-loader\x27></span>"));
      var { minViewCount: _0x22f1d5 } =
          await chrome["storage"]["local"]["get"]("minViewCount"),
        { minSoldQuantity: _0xb64f7d } =
          await chrome["storage"]["local"]["get"]("minSoldQuantity"),
        { filterByHours: filterByHours } =
          await chrome["storage"]["local"]["get"]("filterByHours"),
        _0x417707 = await _0x12a288(_0xb64f7d, _0x22f1d5, filterByHours);
      console["log"]("Low\x20Performing\x20Nodes:", _0x417707);
      var { maxConcurrentTasks: _0x207a51 } =
        await chrome["storage"]["local"]["get"]("maxConcurrentTasks");
      ((_0x207a51 = parseInt(_0x207a51, 0xa)) > 0xa && (_0x207a51 = 0xa),
        console["log"]("lowPerformingNodes\x20to\x20process", _0x417707),
        _0x417707["length"] > 0x0 && (await _0xfe80e9(_0x417707, _0x207a51)),
        (_0x8f5cd9["textContent"] = "Items\x20Bulk\x20Smartly\x20Relisted"));
      var { autoRefresh: _0x4ac3eb } =
        await chrome["storage"]["local"]["get"]("autoRefresh");
      _0x4ac3eb
        ? (console["log"]("autoRefreshCheckbox\x20checked"),
          console["log"]("refreshing\x20page\x20in\x205\x20minutes"),
          (document["title"] =
            "Refreshing\x20Page\x20in\x205\x20minutes\x20-\x20" +
            document["title"]),
          await _0x2c5c00(0x493e0),
          chrome["runtime"]["sendMessage"]({ type: "refresh_page_and_relist" }))
        : (console["log"]("autoRefreshCheckbox\x20not\x20checked"),
          (document["title"] = "Done\x20-\x20" + document["title"]));
    }));
  var _0x5dd2c3 = await _0x44598b(),
    _0x5e8922 = await _0xab5022(),
    filterByHoursSelectDiv = await _0x593a03(),
    _0x240d73 = await _0x453b50(),
    _0x3e7b29 = await _0x4808e7(),
    _0x36f477 = await _0x46aae3(),
    _0x420f97 = await _0x33ea8f(),
    _0x56cc1f = await _0x17eaa2();
  _0x101d51();
  var _0x55a443 = document["createElement"]("div");
  ((_0x55a443["className"] = "bulk-smart-relist-button-container"),
    _0x55a443["appendChild"](_0x5e8922),
    _0x55a443["appendChild"](_0x5dd2c3),
    _0x55a443["appendChild"](filterByHoursSelectDiv),
    _0x55a443["appendChild"](_0x240d73),
    _0x55a443["appendChild"](_0x3e7b29));
  var _0x33fae4 = document["createElement"]("div");
  ((_0x33fae4["style"]["height"] = "10px"),
    _0x55a443["appendChild"](_0x33fae4),
    _0x55a443["appendChild"](_0x36f477),
    _0x55a443["appendChild"](_0x420f97));
  var _0x2e6ec6 = document["createElement"]("div");
  ((_0x2e6ec6["className"] = "action-button-container"),
    _0x2e6ec6["appendChild"](_0x8f5cd9),
    _0x55a443["appendChild"](_0x2e6ec6));
  var _0x2d6a34 = document["createElement"]("div");
  return (
    (_0x2d6a34["className"] = "smart-relist-ui"),
    _0x2d6a34["appendChild"](_0x55a443),
    _0x2d6a34["appendChild"](_0x56cc1f),
    _0x2d6a34
  );
}
async function _0x593a03() {
  var filterByHoursSelect = document["createElement"]("select");
  ((filterByHoursSelect["className"] = "filter-by-hours-select"),
    (filterByHoursSelect["name"] = "filter-by-hours-select"),
    (filterByHoursSelect["id"] = "filter-by-hours-select"));
  var _0x465ef0 = document["createElement"]("option");
  ((_0x465ef0["value"] = "12"),
    (_0x465ef0["text"] = "12h"),
    filterByHoursSelect["appendChild"](_0x465ef0));
  var _0xa095de = document["createElement"]("option");
  ((_0xa095de["value"] = "24"),
    (_0xa095de["text"] = "24h"),
    filterByHoursSelect["appendChild"](_0xa095de));
  var _0x10cff0 = document["createElement"]("option");
  ((_0x10cff0["value"] = "48"),
    (_0x10cff0["text"] = "48h"),
    filterByHoursSelect["appendChild"](_0x10cff0));
  var { filterByHours: filterByHours } =
    await chrome["storage"]["local"]["get"]("filterByHours");
  if (filterByHours) filterByHoursSelect["value"] = filterByHours;
  else
    ((filterByHoursSelect["value"] = "24"),
      await chrome["storage"]["local"]["set"]({ filterByHours: "24" }));
  filterByHoursSelect["addEventListener"]("change", function (_0x172c0e) {
    (_0x172c0e["preventDefault"](),
      console["log"]("filterByHoursSelect\x20changed"),
      console["log"]("filterByHoursSelect.value", filterByHoursSelect["value"]),
      chrome["storage"]["local"]["set"]({
        filterByHours: filterByHoursSelect["value"],
      }));
  });
  var filterByHoursSelectLabel = document["createElement"]("label");
  ((filterByHoursSelectLabel["htmlFor"] = "filter-by-hours-select"),
    filterByHoursSelectLabel["appendChild"](
      document["createTextNode"]("Filter\x20By\x20Hours"),
    ));
  var filterByHoursSelectDiv = document["createElement"]("div");
  return (
    (filterByHoursSelectDiv["className"] = "filter-by-hours-select-div"),
    filterByHoursSelectDiv["appendChild"](filterByHoursSelect),
    filterByHoursSelectDiv["appendChild"](filterByHoursSelectLabel),
    filterByHoursSelectDiv
  );
}
async function _0x453b50() {
  var _0x38e98b = document["createElement"]("input");
  ((_0x38e98b["type"] = "number"),
    (_0x38e98b["id"] = "min-sold-quantity-input"),
    (_0x38e98b["name"] = "min-sold-quantity-input"),
    (_0x38e98b["value"] = "0"),
    (_0x38e98b["min"] = "0"),
    (_0x38e98b["max"] = "1000"),
    (_0x38e98b["step"] = "1"));
  var _0x3dbd07 = document["createElement"]("label");
  ((_0x3dbd07["htmlFor"] = "min-sold-quantity-input"),
    _0x3dbd07["appendChild"](
      document["createTextNode"]("Min\x20Sold\x20Quantity"),
    ));
  var _0x2b015c = document["createElement"]("div");
  ((_0x2b015c["className"] = "min-sold-quantity-input-div"),
    _0x2b015c["appendChild"](_0x38e98b),
    _0x2b015c["appendChild"](_0x3dbd07));
  var { minSoldQuantity: _0x397145 } =
    await chrome["storage"]["local"]["get"]("minSoldQuantity");
  if (_0x397145) _0x38e98b["value"] = _0x397145;
  else
    ((_0x38e98b["value"] = "0"),
      await chrome["storage"]["local"]["set"]({ minSoldQuantity: "0" }));
  return (
    _0x38e98b["addEventListener"]("change", function () {
      (console["log"]("minSoldQuantityInput\x20changed"),
        console["log"]("minSoldQuantityInput.value", _0x38e98b["value"]),
        chrome["storage"]["local"]["set"]({
          minSoldQuantity: _0x38e98b["value"],
        }),
        highlightLowPerformingNodes(
          document["getElementById"]("min-sold-quantity-input")["value"],
          document["getElementById"]("min-view-count-input")["value"],
        ));
    }),
    _0x2b015c
  );
}
async function _0x4808e7() {
  var _0xef3489 = document["createElement"]("input");
  ((_0xef3489["type"] = "number"),
    (_0xef3489["id"] = "min-view-count-input"),
    (_0xef3489["name"] = "min-view-count-input"),
    (_0xef3489["value"] = "0"),
    (_0xef3489["min"] = "0"),
    (_0xef3489["max"] = "1000"),
    (_0xef3489["step"] = "1"));
  var _0x5e4c47 = document["createElement"]("label");
  ((_0x5e4c47["htmlFor"] = "min-view-count-input"),
    _0x5e4c47["appendChild"](
      document["createTextNode"]("Min\x20View\x20Count"),
    ));
  var _0x5e9b38 = document["createElement"]("div");
  ((_0x5e9b38["className"] = "min-view-count-input-div"),
    _0x5e9b38["appendChild"](_0xef3489),
    _0x5e9b38["appendChild"](_0x5e4c47));
  var { minViewCount: _0x1c661f } =
    await chrome["storage"]["local"]["get"]("minViewCount");
  if (_0x1c661f) _0xef3489["value"] = _0x1c661f;
  else
    ((_0xef3489["value"] = "0"),
      await chrome["storage"]["local"]["set"]({ minViewCount: "0" }));
  return (
    _0xef3489["addEventListener"]("change", function () {
      (console["log"]("minViewCountInput\x20changed"),
        console["log"]("minViewCountInput.value", _0xef3489["value"]),
        chrome["storage"]["local"]["set"]({ minViewCount: _0xef3489["value"] }),
        highlightLowPerformingNodes(
          document["getElementById"]("min-sold-quantity-input")["value"],
          document["getElementById"]("min-view-count-input")["value"],
        ));
    }),
    _0x5e9b38
  );
}
async function _0x46aae3() {
  var _0x48f065 = document["createElement"]("input");
  ((_0x48f065["type"] = "number"),
    (_0x48f065["id"] = "max-price-to-list-input"),
    (_0x48f065["name"] = "max-price-to-list-input"),
    (_0x48f065["value"] = "0"),
    (_0x48f065["min"] = "0"),
    (_0x48f065["max"] = "1000"),
    (_0x48f065["step"] = "1"));
  var _0x1d10b9 = document["createElement"]("label");
  ((_0x1d10b9["htmlFor"] = "max-price-to-list-input"),
    _0x1d10b9["appendChild"](
      document["createTextNode"]("Max\x20Price\x20To\x20List"),
    ));
  var _0xb7faf8 = document["createElement"]("div");
  ((_0xb7faf8["className"] = "max-price-to-list-input-div"),
    _0xb7faf8["appendChild"](_0x48f065),
    _0xb7faf8["appendChild"](_0x1d10b9));
  var { maxPrice: _0x320b5a } =
    await chrome["storage"]["local"]["get"]("maxPrice");
  return (
    _0x320b5a || (_0x320b5a = 0x64),
    (_0x48f065["value"] = _0x320b5a),
    _0x48f065["addEventListener"]("change", function () {
      (console["log"]("maxPriceToListInput\x20changed"),
        console["log"]("maxPriceToListInput.value", _0x48f065["value"]),
        chrome["storage"]["local"]["set"]({ maxPrice: _0x48f065["value"] }));
    }),
    _0xb7faf8
  );
}
async function _0x33ea8f() {
  var _0x4a7cac = document["createElement"]("input");
  ((_0x4a7cac["type"] = "number"),
    (_0x4a7cac["id"] = "min-price-to-list-input"),
    (_0x4a7cac["name"] = "min-price-to-list-input"),
    (_0x4a7cac["value"] = "0"),
    (_0x4a7cac["min"] = "0"),
    (_0x4a7cac["max"] = "1000"),
    (_0x4a7cac["step"] = "1"));
  var _0x27bbec = document["createElement"]("label");
  ((_0x27bbec["htmlFor"] = "min-price-to-list-input"),
    _0x27bbec["appendChild"](
      document["createTextNode"]("Min\x20Price\x20To\x20List"),
    ));
  var _0x502822 = document["createElement"]("div");
  ((_0x502822["className"] = "min-price-to-list-input-div"),
    _0x502822["appendChild"](_0x4a7cac),
    _0x502822["appendChild"](_0x27bbec));
  var { minPrice: _0x3e1c30 } =
    await chrome["storage"]["local"]["get"]("minPrice");
  return (
    _0x3e1c30 || (_0x3e1c30 = 0x0),
    (_0x4a7cac["value"] = _0x3e1c30),
    _0x4a7cac["addEventListener"]("change", function () {
      (console["log"]("minPriceToListInput\x20changed"),
        console["log"]("minPriceToListInput.value", _0x4a7cac["value"]),
        chrome["storage"]["local"]["set"]({ minPrice: _0x4a7cac["value"] }));
    }),
    _0x502822
  );
}
async function _0x44598b() {
  var _0x1727ba = document["createElement"]("select");
  ((_0x1727ba["className"] = "concurrent-tasks-select"),
    (_0x1727ba["name"] = "concurrent-tasks-select"),
    (_0x1727ba["id"] = "concurrent-tasks-select"));
  for (var _0x5c520c = 0x1; _0x5c520c <= 0xa; _0x5c520c++) {
    var _0x54c19a = document["createElement"]("option");
    ((_0x54c19a["value"] = _0x5c520c),
      (_0x54c19a["text"] = _0x5c520c),
      _0x1727ba["appendChild"](_0x54c19a));
  }
  _0x1727ba["value"] = 0x4;
  var _0x2dda19 = document["createElement"]("label");
  ((_0x2dda19["htmlFor"] = "concurrent-tasks-select"),
    _0x2dda19["appendChild"](
      document["createTextNode"]("Concurrent\x20Tasks"),
    ));
  var _0x4fae3f = document["createElement"]("div");
  ((_0x4fae3f["className"] = "concurrent-tasks-select-div"),
    _0x4fae3f["appendChild"](_0x1727ba),
    _0x4fae3f["appendChild"](_0x2dda19));
  var { maxConcurrentTasks: _0x43cf0d } =
    await chrome["storage"]["local"]["get"]("maxConcurrentTasks");
  if (_0x43cf0d) _0x1727ba["value"] = _0x43cf0d;
  else
    ((_0x1727ba["value"] = 0x4),
      await chrome["storage"]["local"]["set"]({ maxConcurrentTasks: "4" }));
  return (
    _0x1727ba["addEventListener"]("change", function () {
      (console["log"]("select\x20changed"),
        console["log"]("select.value", _0x1727ba["value"]),
        chrome["storage"]["local"]["set"]({
          maxConcurrentTasks: _0x1727ba["value"],
        }));
    }),
    _0x4fae3f
  );
}
async function _0xab5022() {
  var _0x472228 = document["createElement"]("input");
  ((_0x472228["type"] = "checkbox"),
    (_0x472228["id"] = "auto-refresh-checkbox"),
    (_0x472228["name"] = "auto-refresh-checkbox"),
    (_0x472228["value"] = "auto-refresh-checkbox"),
    (_0x472228["checked"] = !0x1));
  var _0x128631 = document["createElement"]("label");
  ((_0x128631["htmlFor"] = "auto-refresh-checkbox"),
    _0x128631["appendChild"](
      document["createTextNode"]("Auto\x20Refresh\x20Page"),
    ));
  var _0x545ecb = document["createElement"]("div");
  ((_0x545ecb["className"] = "auto-refresh-checkbox-div"),
    _0x545ecb["appendChild"](_0x472228),
    _0x545ecb["appendChild"](_0x128631));
  var { autoRefresh: _0x44d3ee } =
    await chrome["storage"]["local"]["get"]("autoRefresh");
  if (_0x44d3ee) _0x472228["checked"] = !0x0;
  else
    ((_0x472228["checked"] = !0x1),
      await chrome["storage"]["local"]["set"]({ autoRefresh: !0x1 }));
  return (
    _0x472228["addEventListener"]("change", function () {
      this["checked"]
        ? (console["log"]("checked"),
          chrome["storage"]["local"]["set"]({ autoRefresh: !0x0 }))
        : (console["log"]("unchecked"),
          chrome["storage"]["local"]["set"]({ autoRefresh: !0x1 }));
    }),
    _0x545ecb
  );
}
async function _0x17eaa2() {
  var _0x5b56d4 = document["createElement"]("div");
  _0x5b56d4["className"] = "smart-relist-intro";
  var _0x27924a = document["createElement"]("p");
  ((_0x27924a["className"] = "smart-relist-explanation"),
    (_0x27924a["textContent"] =
      "Welcome\x20to\x20the\x20Smart\x20Relist\x20feature!\x20Set\x20your\x20preferences\x20below\x20to\x20relist\x20items\x20on\x20your\x20eBay\x20account\x20based\x20on\x20ending\x20time,\x20minimum\x20sold\x20quantity,\x20and\x20view\x20count.\x20Choose\x20the\x20number\x20of\x20concurrent\x20listings\x20our\x20AI-enhanced\x20tool\x20will\x20process,\x20optimizing\x20item\x20titles\x20for\x20better\x20visibility.\x20Note:\x20Enabling\x20\x27Auto\x20Refresh\x20Page\x27\x20will\x20refresh\x20the\x20page\x20automatically\x20after\x20relisting.\x20Disable\x20this\x20feature\x20and\x20refresh\x20the\x20page\x20manually\x20to\x20turn\x20it\x20off."));
  var _0x4c8a69 = document["createElement"]("p");
  return (
    (_0x4c8a69["style"]["fontWeight"] = "bold"),
    (_0x4c8a69["textContent"] =
      "Customizable\x20Table\x20on\x20eBay\x20must\x20include:\x20\x27Custom\x20Label\x27,\x20\x27Item\x20Number\x27,\x20\x27Available\x20Quantity\x27,\x20\x27Sold\x20Quantity\x27,\x20\x27Views\x27,\x20\x27Current\x20Price\x27,\x20\x27Start\x20Date\x27"),
    _0x5b56d4["appendChild"](_0x27924a),
    _0x5b56d4["appendChild"](_0x4c8a69),
    _0x5b56d4
  );
}
function _0x14e1b9(_0x44d83a, _0x246599) {
  const {
    days: _0x27a7e5,
    hours: _0x4adcb7,
    minutes: _0x4cbda5,
    seconds: _0x217bcc,
  } = (function (_0x2daa7c) {
    let _0x1e0374 = 0x0,
      _0x5e0dca = 0x0,
      _0x3652b8 = 0x0,
      _0x562a4b = 0x0;
    const _0x21a44e = /(\d+)\s*(d|T|h|Std|m|Min|s|Sek)/g;
    let _0x3e631f;
    for (; null !== (_0x3e631f = _0x21a44e["exec"](_0x2daa7c)); ) {
      const _0x2d3975 = parseInt(_0x3e631f[0x1], 0xa),
        _0x593977 = _0x3e631f[0x2];
      "d" === _0x593977 || "T" === _0x593977
        ? (_0x1e0374 += _0x2d3975)
        : "h" === _0x593977 || "Std" === _0x593977
          ? (_0x5e0dca += _0x2d3975)
          : "m" === _0x593977 || "Min" === _0x593977
            ? (_0x3652b8 += _0x2d3975)
            : ("s" !== _0x593977 && "Sek" !== _0x593977) ||
              (_0x562a4b += _0x2d3975);
    }
    return {
      days: _0x1e0374,
      hours: _0x5e0dca,
      minutes: _0x3652b8,
      seconds: _0x562a4b,
    };
  })(_0x44d83a);
  return (
    0x18 * _0x27a7e5 + _0x4adcb7 + _0x4cbda5 / 0x3c + _0x217bcc / 0xe10 <
    _0x246599
  );
}
function _0x32452d() {
  alert("Processing\x20stopped");
}
async function _0xfe80e9(_0x1f882f, _0x52ddae = 0x4) {
  let _0x1504e8 = [],
    _0x11e70e = 0x0,
    _0x596f2e = 0x0,
    _0x10197c = !0x1;
  const _0x44a90d = () => {
    if (_0x596f2e < _0x1f882f["length"]) {
      console["log"](
        "Preparing\x20to\x20process\x20node\x20at\x20index\x20" + _0x596f2e,
      );
      const _0x4ac357 = _0x19212d(_0x1f882f[_0x596f2e++])
        ["then"](() => {
          (_0x11e70e++,
            console["log"](
              "Node\x20at\x20index\x20" +
                (_0x596f2e - 0x1) +
                "\x20processed.\x20Total\x20processed:\x20" +
                _0x11e70e,
            ));
        })
        ["finally"](() => {
          ((_0x1504e8 = _0x1504e8["filter"](
            (_0x1f809f) => _0x1f809f !== _0x4ac357,
          )),
            _0x44a90d());
        });
      (_0x1504e8["push"](_0x4ac357),
        console["log"](
          "Started\x20processing\x20node\x20at\x20index\x20" +
            (_0x596f2e - 0x1) +
            ".\x20Ongoing\x20tasks:\x20" +
            _0x1504e8["length"],
        ));
    } else _0x10197c = !0x0;
  };
  for (
    let _0x4cbae7 = 0x0;
    _0x4cbae7 < _0x52ddae && _0x4cbae7 < _0x1f882f["length"];
    _0x4cbae7++
  )
    _0x44a90d();
  (await (async () => {
    for (; _0x1504e8["length"] > 0x0 || !_0x10197c; )
      await Promise["all"](_0x1504e8);
  })(),
    console["log"]("All\x20nodes\x20processed"));
}
async function _0x19212d(_0x156634) {
  console["log"]("Processing\x20node:\x20" + _0x156634);
  try {
    (console["log"]("Processing\x20node", _0x156634),
      await _0x540c72(_0x156634));
  } catch (_0x533db5) {
    console["error"]("Error\x20processing\x20node:\x20" + _0x156634, _0x533db5);
  }
  return (_0x156634["classList"]["add"]("processed-node"), _0x156634);
}
Promise["prototype"]["isFulfilled"] = function () {
  return (
    Promise["race"]([
      this,
      new Promise((_0x59d3f2) => setTimeout(_0x59d3f2, 0x0)),
    ]) === this
  );
};
async function _0x1c8689(_0x1dd2dc, _0x2b28c4, _0x50add) {
  var _0x47fb7a = _0x1dd2dc["querySelector"](
    "td[class*=\x22" + _0x2b28c4 + "\x22]\x20button[data]",
  );
  console["log"]("editButton", _0x47fb7a);
  !_0x47fb7a &&
    ((_0x47fb7a = _0x1dd2dc["querySelector"](
      "td[class*=\x22" +
        _0x2b28c4 +
        "\x22]\x20button[column=\x22" +
        _0x2b28c4 +
        "\x22]",
    )),
    console["log"]("editButton", _0x47fb7a));
  if (!_0x47fb7a)
    return (console["log"]("editButton\x20button\x20not\x20found"), !0x1);
  (console["log"]("#1"),
    _0x47fb7a["click"](),
    await new Promise((_0x5731dd) => setTimeout(_0x5731dd, 0xbb8)));
  var _0x288231 = await _0x105f02(_0x2b28c4, _0x47fb7a);
  (console["log"]("inputBox", _0x288231),
    console["log"]("#2"),
    (_0x288231["value"] = _0x50add),
    _0x288231["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    _0x512272(_0x288231),
    await new Promise((_0x2c45dd) => setTimeout(_0x2c45dd, 0xbb8)),
    console["log"]("#3"));
  var _0x4d8ba0 = document["querySelector"](
    "form[class*=\x22inline-edit-\x22]\x20button[type=\x22submit\x22]",
  );
  !_0x4d8ba0 &&
    ((_0x4d8ba0 = document["querySelector"](
      "form[class*=\x22quick-edit-field\x22]\x20[type=\x22submit\x22]",
    )),
    console["log"]("formButton", _0x4d8ba0));
  (_0x4d8ba0["click"](),
    console["log"]("formButton", _0x4d8ba0),
    console["log"]("#4"));
  var _0x24260a = await _0x4aba90();
  if (_0x24260a) console["log"]("succssfullyUpdated");
  else
    ((_0x1dd2dc["style"]["backgroundColor"] = "#fc95ab"),
      console["log"]("failed\x20to\x20update"));
  return (
    console["log"]("#5"),
    await new Promise((_0x2b550d) => setTimeout(_0x2b550d, 0xbb8)),
    _0x24260a
  );
}
function _0x512272(_0x344359) {
  var _0x34e947 = _0x344359["value"]["length"];
  if (_0x344359["setSelectionRange"])
    (_0x344359["focus"](),
      _0x344359["setSelectionRange"](_0x34e947, _0x34e947));
  else {
    if (_0x344359["createTextRange"]) {
      var _0x3e6701 = _0x344359["createTextRange"]();
      (_0x3e6701["collapse"](!0x0),
        _0x3e6701["moveEnd"]("character", _0x34e947),
        _0x3e6701["moveStart"]("character", _0x34e947),
        _0x3e6701["select"]());
    }
  }
}
async function _0x105f02(_0x20129d, _0x3a34a9) {
  return new Promise((_0x519dbf, _0x198080) => {
    let _0x40aced = document["querySelector"](
      "input[name=\x22members[0][" + _0x20129d + "]\x22]",
    );
    if (_0x40aced) {
      _0x519dbf(_0x40aced);
      return;
    }
    const _0x5bb0d4 = setInterval(() => {
        _0x40aced = document["querySelector"](
          "input[name=\x22members[0][" + _0x20129d + "]\x22]",
        );
        if (_0x40aced)
          (clearInterval(_0x5bb0d4),
            _0x1ff0b5["disconnect"](),
            _0x519dbf(_0x40aced));
        else _0x3a34a9["click"]();
      }, 0x3e8),
      _0x1ff0b5 = new MutationObserver((_0x14d7c0) => {
        for (const _0x5903c4 of _0x14d7c0)
          if (_0x5903c4["addedNodes"]["length"] > 0x0) {
            _0x40aced = document["querySelector"](
              "input[name=\x22members[0][" + _0x20129d + "]\x22]",
            );
            if (_0x40aced) {
              (clearInterval(_0x5bb0d4),
                _0x1ff0b5["disconnect"](),
                _0x519dbf(_0x40aced));
              break;
            }
          }
      });
    _0x1ff0b5["observe"](document["body"], { childList: !0x0, subtree: !0x0 });
  });
}
async function _0x4aba90() {
  return new Promise(function (_0x5de39f, _0x21ab17) {
    var _0x413fdc = ".popover-content-wrap",
      popoverElement = document["querySelector"](_0x413fdc);
    !popoverElement &&
      ((_0x413fdc = ".quick-edit-modal__input"),
      (popoverElement = document["querySelector"](_0x413fdc)));
    var _0x431f88 = popoverElement["querySelector"](
        "button[type=\x22reset\x22]",
      ),
      _0x41b843 = !0x0,
      _0xa7f435,
      _0x4fc972;
    if (popoverElement) {
      var _0xa2d4ad = new MutationObserver(function (_0x4f38e6) {
        _0x4f38e6["forEach"](function (_0x248be9) {
          _0x248be9["removedNodes"]["length"] > 0x0 &&
            !(popoverElement = document["querySelector"](_0x413fdc)) &&
            (_0xa2d4ad["disconnect"](),
            clearTimeout(_0xa7f435),
            clearTimeout(_0x4fc972),
            _0x5de39f(_0x41b843));
        });
      });
      (_0xa2d4ad["observe"](document["body"], {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
        characterData: !0x1,
      }),
        (_0xa7f435 = setTimeout(function () {
          ((popoverElement = document["querySelector"](_0x413fdc)),
            console["log"]("popoverElement", popoverElement),
            console["log"]("cancelButton", _0x431f88),
            popoverElement && (_0x431f88["click"](), (_0x41b843 = !0x1)));
        }, 0x3a98)),
        (_0x4fc972 = setTimeout(function () {
          ((popoverElement = document["querySelector"](_0x413fdc)),
            console["log"]("popoverElement", popoverElement),
            console["log"](
              "sending\x20message\x20to\x20continue\x20tracking\x20page",
            ),
            popoverElement &&
              chrome["runtime"]["sendMessage"]({ type: "continue_tracking" }));
        }, 0x7530)));
    } else _0x5de39f();
  });
}
async function _0x8d43f6() {
  var _0x522b55 = await _0x12a288(0x0, 0x0, 0xf423f);
  for (var _0x14f1ed = 0x0; _0x14f1ed < _0x522b55["length"]; _0x14f1ed++) {
    console["log"]("selecting\x20node", _0x522b55[_0x14f1ed]);
    var _0x11d8c7 = _0x522b55[_0x14f1ed]["querySelector"](
      "input[type=\x22checkbox\x22]",
    );
    (_0x11d8c7 && !_0x11d8c7["checked"] && _0x11d8c7["click"](),
      _0x522b55[_0x14f1ed]["classList"]["add"]("low-performing"));
  }
}
function _0xb10453() {
  var _0x36a87d = document["createElement"]("div");
  _0x36a87d["className"] = "active-listings-options-container";
  var _0x30d3e = createEndLowPerformingItemsButton();
  ((_0x30d3e["className"] = "btn\x20btn--secondary"),
    (_0x30d3e["style"]["borderColor"] = "#ff4d4d"),
    (_0x30d3e["style"]["color"] = "#ff4d4d"),
    _0x36a87d["appendChild"](_0x30d3e));
  var _0x4767f3 = document["createElement"]("button");
  ((_0x4767f3["textContent"] = "⚙️"),
    (_0x4767f3["className"] = "btn\x20btn--icon"),
    (_0x4767f3["style"]["marginLeft"] = "8px"),
    _0x36a87d["appendChild"](_0x4767f3));
  var _0x2cfe5d = document["createElement"]("div");
  return (
    (_0x2cfe5d["className"] = "end-items-modal"),
    (_0x2cfe5d["innerHTML"] =
      "\x0a\x20\x20\x20\x20<div\x20class=\x22end-items-modal-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<h2>End\x20Items\x20Settings</h2>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Sold\x20Limit\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22number\x22\x20id=\x22minSold\x22\x20/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p\x20class=\x22desc\x22>End\x20items\x20that\x20have\x20this\x20many\x20sales\x20or\x20fewer.<br>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Example:\x200\x20=\x20only\x20items\x20with\x20no\x20sales.</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Views\x20Limit\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22number\x22\x20id=\x22minViews\x22\x20/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p\x20class=\x22desc\x22>End\x20items\x20that\x20have\x20this\x20many\x20views\x20or\x20fewer.<br>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Example:\x200\x20=\x20only\x20items\x20with\x20no\x20views.</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Total\x20Items\x20to\x20End\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22number\x22\x20id=\x22maxItems\x22\x20/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p\x20class=\x22desc\x22>0\x20=\x20End\x20items\x20on\x20this\x20page\x20only.<br>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Any\x20other\x20number\x20=\x20Keep\x20going\x20through\x20pages\x20until\x20that\x20many\x20are\x20ended,\x20or\x20no\x20more\x20items\x20remain.</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<p\x20class=\x22note\x22>⚠️\x20This\x20is\x20a\x20simple\x20bulk\x20end\x20tool\x20—\x20nothing\x20complicated.</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22modal-actions\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22saveSettings\x22\x20class=\x22btn\x20btn--primary\x22>Save</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22closeModal\x22\x20class=\x22btn\x20btn--secondary\x22>Cancel</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20</div>\x0a"),
    document["body"]["appendChild"](_0x2cfe5d),
    _0x4767f3["addEventListener"]("click", async () => {
      (await (async function () {
        const _0xe6b16 = await chrome["storage"]["local"]["get"]([
          "minSoldQuantity",
          "minViewCount",
          "totalItemsToEnd",
        ]);
        ((document["getElementById"]("minSold")["value"] =
          _0xe6b16["minSoldQuantity"] ?? 0x0),
          (document["getElementById"]("minViews")["value"] =
            _0xe6b16["minViewCount"] ?? 0x0),
          (document["getElementById"]("maxItems")["value"] =
            _0xe6b16["totalItemsToEnd"] ?? 0x0));
      })(),
        (_0x2cfe5d["style"]["display"] = "block"));
    }),
    _0x2cfe5d["querySelector"]("#closeModal")["addEventListener"](
      "click",
      () => {
        _0x2cfe5d["style"]["display"] = "none";
      },
    ),
    _0x2cfe5d["querySelector"]("#saveSettings")["addEventListener"](
      "click",
      async () => {
        const _0x1012f1 = document["getElementById"]("minSold")["value"],
          _0x598ed8 = document["getElementById"]("minViews")["value"],
          _0x29bfb7 = document["getElementById"]("maxItems")["value"];
        (await chrome["storage"]["local"]["set"]({
          minSoldQuantity: _0x1012f1,
          minViewCount: _0x598ed8,
          totalItemsToEnd: _0x29bfb7,
        }),
          console["log"]("Saved\x20settings:", {
            minSold: _0x1012f1,
            minViews: _0x598ed8,
            maxItems: _0x29bfb7,
          }),
          (_0x2cfe5d["style"]["display"] = "none"));
      },
    ),
    _0x36a87d
  );
}
async function _0x37026c(_0x46dc31) {
  if (_0x5f54e7(_0x46dc31))
    return (
      console["log"]("Custom\x20view\x20settings\x20are\x20not\x20applied"),
      !0x0
    );
  await openCustomizeActiveViewSettings();
  for (const _0x566ecc of _0x46dc31) {
    (await _0x41dcc1(_0x566ecc, !0x0),
      console["log"](
        "Toggled\x20" + _0x566ecc + "\x20on,\x20waiting\x204\x20seconds",
      ),
      await new Promise((_0x307307) => setTimeout(_0x307307, 0xfa0)));
  }
  return (
    console["log"](
      "Waiting\x2010\x20seconds\x20for\x20the\x20page\x20to\x20update",
    ),
    await new Promise((_0x32949d) => setTimeout(_0x32949d, 0x1388)),
    _0x371a46(),
    console["log"]("Custom\x20view\x20settings\x20are\x20applied"),
    !0x0
  );
}
async function openCustomizeActiveViewSettings() {
  const _0x27d9ce = document["querySelector"]("button.customize-link");
  if (!_0x27d9ce) {
    console["error"]("Customize\x20button\x20not\x20found");
    throw new Error("Customize\x20button\x20not\x20found");
  }
  _0x27d9ce["click"]();
  let _0x464d93 = null;
  for (; !_0x464d93; ) {
    (await new Promise((_0x592e10) => setTimeout(_0x592e10, 0xbb8)),
      (_0x464d93 = document["querySelector"]("#listings-customization-dialog")),
      _0x464d93 ||
        console["log"](
          "Could\x20not\x20find\x20customizationDialog,\x20trying\x20again\x20in\x203\x20seconds",
        ));
  }
  return (console["log"]("customizationDialog", _0x464d93), _0x464d93);
}
async function _0x41dcc1(_0x14b0a6 = "Item\x20number", _0x4886c6 = !0x0) {
  const _0x4eaf7c = document["querySelectorAll"](
    "input[name=\x22customize-check\x22]",
  );
  let _0x1b17a1 = null;
  for (const _0x247a54 of _0x4eaf7c) {
    const _0x14b1b8 = _0x247a54["getAttribute"]("data-text");
    if (
      Array["isArray"](_0x14b0a6)
        ? _0x14b0a6["includes"](_0x14b1b8)
        : _0x14b1b8 === _0x14b0a6
    ) {
      _0x1b17a1 = _0x247a54;
      break;
    }
  }
  if (!_0x1b17a1) return !0x1;
  if (_0x1b17a1["checked"] === _0x4886c6) return !0x0;
  return (_0x1b17a1["focus"](), _0x1b17a1["click"](), !0x0);
}
function _0x371a46() {
  console["log"]("Saving\x20custom\x20view\x20settings");
  var _0x19aa03 = document["querySelector"]("#customize-save");
  if (!_0x19aa03)
    return (console["error"]("Save\x20button\x20not\x20found"), !0x1);
  return (_0x19aa03["click"](), !0x0);
}
function _0x5f54e7(_0x1ed5f1) {
  var _0x335c94 = document["querySelector"](".header-row");
  if (!_0x335c94)
    return (console["error"]("Header\x20row\x20not\x20found"), !0x1);
  var _0x176370 = _0x335c94["querySelectorAll"]("th"),
    _0x1e60a5 = new Set();
  for (var _0x8114aa of _0x176370) {
    var _0x2480a3 = _0x8114aa["querySelectorAll"](".th-title-content");
    if (0x0 !== _0x2480a3["length"]) {
      var _0x365008 =
        _0x2480a3[_0x2480a3["length"] - 0x1]["textContent"]["trim"]();
      _0x1e60a5["add"](_0x365008);
    }
  }
  console["log"]("displayedHeaders:", Array["from"](_0x1e60a5));
  const _0x5a0cfc = [];
  for (const _0x3d1735 of _0x1ed5f1)
    Array["isArray"](_0x3d1735)
      ? _0x3d1735["some"]((_0x46133a) => _0x1e60a5["has"](_0x46133a)) ||
        _0x5a0cfc["push"](_0x3d1735)
      : _0x1e60a5["has"](_0x3d1735) || _0x5a0cfc["push"](_0x3d1735);
  if (_0x5a0cfc["length"] > 0x0)
    return (console["log"]("Missing\x20options:", _0x5a0cfc), !0x1);
  return !0x0;
}
async function _0x10f5e1(_0xda7054) {
  if (_0xedc1dc(_0xda7054))
    return (
      console["log"](
        "All\x20desired\x20fields\x20are\x20already\x20checked—no\x20action\x20needed.",
      ),
      !0x0
    );
  await openSearchPageCustomizeDialogNoLang();
  for (const _0x2692bb of _0xda7054) {
    (await _0x50f2ef(_0x2692bb["nameAttr"], _0x2692bb["valueAttr"], !0x0),
      await new Promise((_0x1067e2) => setTimeout(_0x1067e2, 0x1f4)));
  }
  return (
    console["log"](
      "Waiting\x202\x20seconds\x20before\x20applying\x20changes...",
    ),
    await new Promise((_0x20887d) => setTimeout(_0x20887d, 0x7d0)),
    _0x11ebfa(),
    console["log"](
      "Search\x20page\x20custom\x20view\x20settings\x20applied\x20successfully.",
    ),
    !0x0
  );
}
function _0xedc1dc(_0x48349d) {
  for (const { nameAttr: _0x2023fd, valueAttr: _0x3fce28 } of _0x48349d) {
    const _0x180416 = document["querySelector"](
      "input[type=\x22checkbox\x22][name=\x22" +
        _0x2023fd +
        "\x22][value=\x22" +
        _0x3fce28 +
        "\x22]",
    );
    if (!_0x180416 || !_0x180416["checked"]) return !0x1;
  }
  return !0x0;
}
async function openSearchPageCustomizeDialogNoLang() {
  const _0x41c035 = document["querySelector"](".srp-view-options__customize");
  if (!_0x41c035)
    throw new Error(
      "Customize\x20button\x20not\x20found\x20on\x20the\x20search\x20page.",
    );
  (_0x41c035["click"](),
    console["log"](
      "Clicked\x20Customize\x20button,\x20waiting\x20for\x20form\x20to\x20appear...",
    ));
  let _0x11e33a = null,
    _0x35b8c6 = 0x0;
  for (; !_0x11e33a && _0x35b8c6 < 0x5; ) {
    (await new Promise((_0x51555f) => setTimeout(_0x51555f, 0x7d0)),
      (_0x11e33a = document["querySelector"](".s-customize-form__details")),
      !_0x11e33a &&
        (_0x35b8c6++,
        console["log"](
          "Could\x20not\x20find\x20details\x20form\x20yet.\x20Attempt\x20" +
            _0x35b8c6 +
            "/5...",
        )));
  }
  if (!_0x11e33a)
    throw new Error(
      "Customize\x20form\x20did\x20not\x20appear\x20after\x20several\x20attempts.",
    );
  return (
    console["log"]("Found\x20the\x20customize\x20form:", _0x11e33a),
    _0x11e33a
  );
}
async function _0x50f2ef(_0x9f5f10, _0x515b48, _0x4b1bef = !0x0) {
  const _0x427f9b =
      "input[type=\x22checkbox\x22][name=\x22" +
      _0x9f5f10 +
      "\x22][value=\x22" +
      _0x515b48 +
      "\x22]",
    _0x2a9793 = document["querySelector"](_0x427f9b);
  if (!_0x2a9793)
    return (
      console["error"](
        "Checkbox\x20with\x20name=\x22" +
          _0x9f5f10 +
          "\x22\x20value=\x22" +
          _0x515b48 +
          "\x22\x20not\x20found.",
      ),
      !0x1
    );
  if (_0x2a9793["checked"] === _0x4b1bef)
    return (
      console["log"](
        "Checkbox\x20(name=" +
          _0x9f5f10 +
          ",\x20value=" +
          _0x515b48 +
          ")\x20is\x20already\x20in\x20desired\x20state.",
      ),
      !0x0
    );
  return (
    _0x2a9793["focus"](),
    _0x2a9793["click"](),
    console["log"](
      "Toggled\x20checkbox\x20(name=" +
        _0x9f5f10 +
        ",\x20value=" +
        _0x515b48 +
        ")\x20to\x20" +
        _0x4b1bef +
        ".",
    ),
    !0x0
  );
}
function _0x11ebfa() {
  const _0x177d17 = document["querySelector"](
    ".s-customize-form__actions\x20.btn--primary",
  );
  if (!_0x177d17)
    return (
      console["error"](
        "Apply\x20changes\x20button\x20not\x20found\x20in\x20customize\x20form!",
      ),
      !0x1
    );
  return (
    _0x177d17["click"](),
    console["log"](
      "Clicked\x20\x27Apply\x20changes\x27\x20to\x20save\x20the\x20search\x20page\x20customizations.",
    ),
    !0x0
  );
}
async function _0x40cc05() {
  await _0x10f5e1([
    { nameAttr: "_fcse", valueAttr: "1" },
    { nameAttr: "_fcie", valueAttr: "1" },
  ]);
}
console["log"]("ebay\x20ended\x20listings\x20functions.js\x20loaded");
async function _0x140acf() {
  (console["log"]("sellSimilarEndedItems"), await _0x596076());
  var { lowPerformingItemData: _0x1a0550 } = await chrome["storage"]["local"][
    "get"
  ]("lowPerformingItemData");
  console["log"]("lowPerformingItemData", _0x1a0550);
  var _0x2e01c7 = _0x1a0550["map"]((_0x876db3) => _0x876db3["itemNumber"]);
  (console["log"]("itemNumbers", _0x2e01c7),
    console["log"]("itemNumbers.length", _0x2e01c7["length"]));
  var _0x8aee9d = await _0x391f15(_0x2e01c7);
  (console["log"]("lowPerformingItemNodes", _0x8aee9d),
    0x0 != _0x8aee9d["length"] &&
      (await _0x583605(_0x8aee9d),
      await new Promise((_0x50bb8c) => setTimeout(_0x50bb8c, 0x7d0)),
      _0x3c7222(),
      await _0x5a7425()));
}
async function _0x5a7425() {
  var _0x561196 = null;
  for (; !_0x561196; ) {
    var _0x2e7430 = document["querySelectorAll"]("button");
    !(_0x561196 = Array["from"](_0x2e7430)["find"](
      (_0x33f828) =>
        "continue" === _0x33f828["textContent"]["trim"]()["toLowerCase"]() ||
        "weiter" === _0x33f828["textContent"]["trim"]()["toLowerCase"](),
    )) &&
      (console["log"]("waiting\x20for\x20submit\x20button\x20to\x20appear"),
      await new Promise((_0x4abfa4) => setTimeout(_0x4abfa4, 0x3e8)));
  }
  (console["log"]("submit\x20button\x20found"), _0x561196["click"]());
}
async function _0x3c7222() {
  console["log"]("clickSellSimilarButton");
  var _0xa3b65f = document["querySelectorAll"]("button");
  Array["from"](_0xa3b65f)
    ["find"](
      (_0x14425d) =>
        "sell\x20similar" ===
          _0x14425d["textContent"]["trim"]()["toLowerCase"]() ||
        "ähnlichen\x20artikel\x20verkaufen" ===
          _0x14425d["textContent"]["trim"]()["toLowerCase"](),
    )
    ["click"]();
}
async function _0x340301() {
  await chrome["storage"]["local"]["remove"]("lowPerformingItemData");
}
async function _0x1f7b95() {
  console["log"]("sortByEndDate");
  var _0x1a9ad8 = document["querySelector"](
    "th.shui-dt-column__actualEndDate\x20button",
  );
  (_0x1a9ad8["click"](),
    await _0x596076(),
    _0x1a9ad8["click"](),
    await _0x596076());
}
(console["log"]("ebay\x20ended\x20listings\x20content.js\x20loaded"),
  _0x9fd4ad(),
  chrome["runtime"]["onMessage"]["addListener"](
    function (_0x140d85, _0x2919f8, _0xae822) {
      console["log"](
        "message\x20received\x20in\x20ebay\x20ended\x20listings\x20content.js",
        _0x140d85,
      );
      if ("sell_similar_ended_low_performing_items" == _0x140d85["type"])
        return (
          console["log"](
            "get_ended_listings\x20message\x20received\x20in\x20ebay\x20ended\x20listings\x20content.js",
          ),
          0x0 == _0x140d85["automatic"]
            ? chrome["runtime"]["sendMessage"]({
                type: "sell-similar-button-clicked",
              })
            : _0xae822({ response: "waiting_for_sell_similar_to_be_clicked" }),
          _0x140acf(),
          !0x0
        );
      if ("prepare_sell_similar_workspace" == _0x140d85["type"]) {
        var _0xe0cce6 = [
          ["Item\x20number", "Artikelnummer"],
          ["Custom\x20label\x20(SKU)", "Bestandseinheit\x20(SKU)"],
          ["Views\x20(30\x20days)", "Aufrufe\x20(30\x20Tage)"],
          ["Available\x20quantity", "Verfügbare\x20Anzahl"],
          ["End\x20date", "Enddatum"],
        ];
        _0x5f54e7(_0xe0cce6)
          ? (chrome["runtime"]["sendMessage"]({
              type: "preparing_sell_similar_workspace",
            }),
            _0x140acf())
          : (chrome["runtime"]["sendMessage"]({
              type: "resend_message_to_tab_on_update_and_notified",
              message: _0x140d85,
            }),
            _0x3bd18e(0x1d4c0, _0x37026c(_0xe0cce6))
              ["then"](() => {})
              ["catch"]((_0x1447df) => {
                (console["log"]("applyCustomViewSettings\x20error", _0x1447df),
                  location["reload"]());
              }));
      }
      return !0x0;
    },
  ));
async function _0x2968f1() {
  (await _0x9fd4ad(), await _0x140acf());
}
