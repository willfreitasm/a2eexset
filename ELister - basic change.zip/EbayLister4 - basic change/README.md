# EcomSniper Chrome Extension

This Chrome extension is part of the EcomSniper software suite, which enables users
to automate Amazon to eBay dropshipping at scale.

## Legal

© 2025 EcomSniper. All rights reserved.

The contents of this repository and extension are proprietary. Unauthorized
use, distribution, or reverse engineering is strictly prohibited.

See the [LICENSE](./LICENSE) file for more details.
