(console["log"]("ebay\x20listing\x20success\x20js\x20loaded"),
  chrome["runtime"]["sendMessage"]({
    type: "itemListed",
    message: "Item\x20Listed\x20Successfully!",
  }));
