var _0x514ae8 = !0x1;
function _0xe40540(_0x364aa6, _0x1bf9be = "image/x-icon") {
  var _0x4c74dd = "shortcut\x20icon";
  "image/gif" == _0x1bf9be || "image/png" == _0x1bf9be
    ? (_0x4c74dd = "icon")
    : (_0x514ae8 = !0x1);
  var _0x1cb3af =
    document["querySelector"]("link[rel*=\x27icon\x27]") ||
    document["createElement"]("link");
  ((_0x1cb3af["type"] = _0x1bf9be),
    (_0x1cb3af["rel"] = _0x4c74dd),
    (_0x1cb3af["href"] = _0x364aa6),
    document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x1cb3af));
}
function _0x4f4925(_0x4fd6f9, _0x2e5bd9 = "image/x-icon") {
  let _0x537760 =
      "image/gif" == _0x2e5bd9 || "image/png" == _0x2e5bd9
        ? "icon"
        : "shortcut\x20icon",
    _0x1af309 = document["querySelectorAll"]("link[rel*=\x27icon\x27]");
  if (0x0 === _0x1af309["length"]) {
    let _0x3fa439 = document["createElement"]("link");
    ((_0x3fa439["type"] = _0x2e5bd9),
      (_0x3fa439["rel"] = _0x537760),
      (_0x3fa439["href"] = _0x4fd6f9),
      document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x3fa439));
    return;
  }
  for (let _0x3afb5e of _0x1af309) {
    ((_0x3afb5e["type"] = _0x2e5bd9),
      (_0x3afb5e["rel"] = _0x537760),
      (_0x3afb5e["href"] = _0x4fd6f9));
  }
}
function _0x1b07bf() {
  _0x514ae8 = !0x0;
  var _0xac2487 = 0x0,
    _0xf2c489 = chrome["runtime"]["getURL"](
      "Favicons/Gifs/Gear/frame_" + _0xac2487 + "_delay-0.04s.gif",
    ),
    _0x1db249 = setInterval(function () {
      if (_0x514ae8 && _0xac2487 < 0x1c)
        (_0xe40540(_0xf2c489, "image/gif"),
          _0xac2487++,
          (_0xf2c489 = chrome["runtime"]["getURL"](
            "Favicons/Gifs/Gear/frame_" + _0xac2487 + "_delay-0.04s.gif",
          )));
      else {
        if (_0x514ae8 && _0xac2487 >= 0x1c)
          ((_0xac2487 = 0x0),
            (_0xf2c489 = chrome["runtime"]["getURL"](
              "Favicons/Gifs/Gear/frame_" + _0xac2487 + "_delay-0.04s.gif",
            )));
        else clearInterval(_0x1db249);
      }
    }, 0x28);
}
function _0xd04cf2() {
  _0x514ae8 = !0x0;
  var _0x51deb1 = 0x0,
    _0x34885a = chrome["runtime"]["getURL"](
      "Favicons/Task_Bar/" + _0x51deb1 + ".png",
    ),
    _0x1ad706 = setInterval(function () {
      if (_0x514ae8 && _0x51deb1 < 0x1b)
        (_0xe40540(_0x34885a, "image/gif"),
          _0x51deb1++,
          (_0x34885a = chrome["runtime"]["getURL"](
            "Favicons/Task_Bar/" + _0x51deb1 + ".png",
          )));
      else {
        if (_0x514ae8 && _0x51deb1 >= 0x1b)
          ((_0x51deb1 = 0x0),
            (_0x34885a = chrome["runtime"]["getURL"](
              "Favicons/Task_Bar/" + _0x51deb1 + ".png",
            )));
        else clearInterval(_0x1ad706);
      }
    }, 0x28);
}
function _0x118cc6() {
  _0x514ae8 = !0x0;
  var _0xb9d998 = 0x0,
    _0x24550a = [0x2, 0x8, 0xe, 0x14, 0x1a, 0x1b],
    _0x27ef19 = 0x28,
    _0x3e6acd = "0.04s",
    _0x1e1e4f = setInterval(function () {
      if (_0x514ae8) {
        _0x3e6acd = _0x24550a["includes"](_0xb9d998) ? "0.05s" : "0.04s";
        var _0x1ef10f =
          "frame_" +
          _0xb9d998["toString"]()["padStart"](0x2, "0") +
          "_delay-" +
          _0x3e6acd +
          ".gif";
        (_0xe40540(
          chrome["runtime"]["getURL"]("Favicons/Sniper/" + _0x1ef10f),
          "image/gif",
        ),
          ++_0xb9d998 >= 0x1b && (_0xb9d998 = 0x0),
          (_0x27ef19 = "0.05s" === _0x3e6acd ? 0x32 : 0x28));
      } else clearInterval(_0x1e1e4f);
    }, _0x27ef19);
}
async function _0x55b694() {
  ((_0x514ae8 = !0x1),
    await new Promise((_0x2d6ab7) => setTimeout(_0x2d6ab7, 0x7d0)));
}
function _0x9897a7() {
  return new Promise((_0x40f450) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x40f450();
      });
    });
  });
}
function _0x4c973b() {
  return new Promise((_0x19298e) => {
    requestIdleCallback(() => {
      _0x19298e();
    });
  });
}
function _0xb4cf73(_0x18e486 = 0x3e8) {
  return new Promise((_0x4896d2, _0x556e93) => {
    let _0x48e950,
      _0x112862 = Date["now"](),
      _0x493e99 = !0x1;
    function _0x24d5cd() {
      if (Date["now"]() - _0x112862 > _0x18e486)
        (_0x493e99 && _0x48e950["disconnect"](), _0x4896d2());
      else setTimeout(_0x24d5cd, _0x18e486);
    }
    const _0x5ae626 = () => {
        _0x112862 = Date["now"]();
      },
      _0x3b3774 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x48e950 = new MutationObserver(_0x5ae626)),
        _0x48e950["observe"](document["body"], _0x3b3774),
        (_0x493e99 = !0x0),
        setTimeout(_0x24d5cd, _0x18e486));
    else
      window["onload"] = () => {
        ((_0x48e950 = new MutationObserver(_0x5ae626)),
          _0x48e950["observe"](document["body"], _0x3b3774),
          (_0x493e99 = !0x0),
          setTimeout(_0x24d5cd, _0x18e486));
      };
  });
}
async function _0x50ea7f() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0xb4cf73(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
console["log"]("chat.js\x20loaded");
let _0x501724 = [],
  _0x5f3ee6 = !0x1;
var _0x1a8567 = 0x0,
  _0x4a0eb5 = 0x1,
  documentTitle = "Chat\x20GPT\x20Web",
  _0x2482d7;
setInterval(function () {
  document["title"] = documentTitle;
}, 0x12c);
var _0x262e37 = "Favicons/Completed/chatGptReceived.png",
  _0x271c13 = "Favicons/OpenAi/chat_gpt_connected.png";
async function _0x59eed5() {
  var _0x1eb6ad = document["querySelectorAll"]("span");
  for (var _0x821de1 = 0x0; _0x821de1 < _0x1eb6ad["length"]; _0x821de1++)
    if ("New\x20Chat" === _0x1eb6ad[_0x821de1]["innerText"])
      return (_0x2d4d6b("Version\x201\x20detected"), 0x1);
  return (_0x2d4d6b("Version\x202\x20detected"), 0x2);
}
function _0x2970d3() {
  (console["log"]("Activating\x20alwaysActive\x20function"),
    Object["defineProperty"](document, "visibilityState", {
      value: "visible",
      writable: !0x0,
    }),
    console["log"](
      "visibilityState\x20set\x20to:",
      document["visibilityState"],
    ),
    Object["defineProperty"](document, "hidden", {
      value: !0x1,
      writable: !0x0,
    }),
    console["log"]("hidden\x20set\x20to:", document["hidden"]),
    window["dispatchEvent"](new Event("focus")),
    console["log"]("Focus\x20event\x20dispatched"));
}
async function _0x51d90a() {
  (await _0xb4cf73(),
    (await _0x4641b4("#prompt-textarea", 0x186a0))["parentElement"]);
  var _0x1d99ee = _0x5a6187();
  ((_0x4a0eb5 = await _0x59eed5()),
    console["log"]("chat.js:\x20webVersion:\x20", _0x4a0eb5));
  var _0x20b5a2 = null;
  (0x1 === _0x4a0eb5 &&
    (_0x20b5a2 = await _0xa8d1bc("span", "New\x20Chat", 0x186a0)),
    0x2 === _0x4a0eb5 &&
      (_0x20b5a2 = await _0xa8d1bc("div", "ChatGPT", 0x186a0)),
    _0x20b5a2["parentElement"]["appendChild"](_0x1d99ee),
    (_0x1d99ee = await _0xa8d1bc("Button", "Connect", 0x186a0))["click"]());
}
_0x51d90a();
function _0x3b545d() {
  var _0x4e4253 = document["createElement"]("button");
  return (
    (_0x4e4253["id"] = "send_prompt"),
    (_0x4e4253["innerHTML"] = "Send\x20Prompt"),
    (_0x4e4253["onclick"] = async function (_0x320971) {
      (_0x320971["preventDefault"](), _0x320971["stopPropagation"]());
      var _0xd71dc8 = document["getElementById"]("prompt-textarea")["value"],
        _0x17a589 = await _0x3f0578(_0xd71dc8);
      console["log"]("response:\x20", _0x17a589);
    }),
    _0x4e4253
  );
}
function _0x5a6187() {
  var _0x31f89a = document["createElement"]("button");
  return (
    (_0x31f89a["id"] = "initialize_chat_gpt_web"),
    (_0x31f89a["innerHTML"] = "Connect"),
    _0x31f89a["classList"]["add"]("initialize-btn"),
    (_0x31f89a["onclick"] = async function (_0x19a559) {
      (_0x19a559["preventDefault"](),
        _0x19a559["stopPropagation"](),
        (_0x31f89a["innerHTML"] = "Connecting.."));
      var _0x12c743 = await new Promise(function (_0x364567, _0x104abd) {
        chrome["runtime"]["sendMessage"](
          { type: "add_chat_gpt_web_connection" },
          function (_0x5617dd) {
            (console["log"]("result:\x20", _0x5617dd),
              _0x364567(_0x5617dd["response"]));
          },
        );
      });
      (console["log"]("response:\x20", _0x12c743),
        (_0x31f89a["innerHTML"] = "Connected"),
        _0x31f89a["classList"]["add"]("connected"),
        console["log"]("chat.js:\x20button.onclick"));
    }),
    _0x31f89a
  );
}
chrome["runtime"]["onMessage"]["addListener"](
  function (_0xb4eaba, _0x532923, _0x31ba80) {
    console["log"]("chat.js\x20onMessage\x20received:\x20", _0xb4eaba);
    if ("ask_chat_gpt_web" === _0xb4eaba["message"])
      return (
        console["log"]("ask_chat_gpt_web\x20received", _0xb4eaba),
        _0x501724["push"]({ request: _0xb4eaba, sendResponse: _0x31ba80 }),
        _0x5f3ee6 || _0x5a7c59(),
        !0x0
      );
    if ("check_alive" === _0xb4eaba["message"])
      return (
        console["log"]("check_alive\x20received"),
        _0x31ba80({ alive: !0x0 }),
        !0x0
      );
    if ("get_last_message" === _0xb4eaba["message"]) {
      console["log"]("get_last_message\x20received");
      var _0x536823 = _0x49d564();
      return (
        console["log"]("chat.js:\x20last_message:\x20", _0x536823),
        _0x31ba80({ message: _0x536823 }),
        !0x0
      );
    }
    return !0x0;
  },
);
async function _0x5a7c59() {
  if (0x0 === _0x501724["length"]) {
    _0x5f3ee6 = !0x1;
    return;
  }
  _0x5f3ee6 = !0x0;
  let _0x5310da = _0x501724["shift"]();
  _0x5310da["request"]["options"]["startNewChat"] &&
    (await _0x3d967e(),
    _0x27357b("New\x20Chat\x20Started\x20from\x20processQueue"));
  try {
    _0x27357b("Processing\x20Message");
    let _0x472c79 = await _0x3f0578(_0x5310da["request"]["prompt"]);
    (_0x27357b(
      "Message\x20Processed:\x20" +
        _0x5310da["request"]["prompt"] +
        ",\x20" +
        _0x472c79["length"],
    ),
      _0x5310da["sendResponse"](_0x472c79),
      ++_0x1a8567 % 0x32 == 0x0 && (await _0x3d967e()));
  } catch (_0x5c67ab) {
    console["error"]("Error\x20processing\x20message:", _0x5c67ab);
  }
  _0x5a7c59();
}
async function _0x3d967e() {
  var _0x1768a9 = null;
  (0x1 === _0x4a0eb5 &&
    (_0x1768a9 = await _0xa8d1bc("span", "New\x20Chat", 0x186a0)),
    0x2 === _0x4a0eb5 &&
      (_0x1768a9 = await _0x4641b4("button.text-token-text-primary")),
    _0x1768a9["click"]());
  var _0x112939 = await _0x4641b4("#prompt-textarea", 0x186a0);
  return (
    console["log"]("chat.js:\x20startNewChat:\x20textArea:\x20", _0x112939),
    await new Promise((_0x205b86) => setTimeout(_0x205b86, 0x3e8)),
    _0x2970d3(),
    !0x0
  );
}
async function _0x3f0578(_0x185276) {
  try {
    clearInterval(_0x2482d7);
  } catch (_0xcfcb23) {}
  var _0x3d65ff = document["title"];
  ((document["title"] = "Asking\x20Chat\x20GPT\x20Web"),
    _0x27357b("Asking\x20Chat\x20GPT\x20Web"),
    _0x2d4d6b(
      "Asking\x20Chat\x20GPT\x20Web\x20with\x20prompt:\x20" + _0x185276,
    ));
  if (_0xa08042())
    return (
      _0x2d4d6b("Error\x20Detected"),
      console["log"]("chat.js:\x20Error\x20Detected"),
      _0x2d4d6b("Waiting\x2010\x20seconds"),
      await new Promise((_0x333dd0) => setTimeout(_0x333dd0, 0x2710)),
      await _0x3d967e(),
      await _0x3f0578(_0x185276)
    );
  _0x2482d7 = setInterval(() => {
    if (_0x3a645d())
      return (
        console["log"](
          "Exiting\x20startProcess\x20due\x20to\x20limit\x20reached.",
        ),
        clearInterval(_0x2482d7),
        null
      );
  }, 0x3e8);
  var _0x348002 = document["getElementById"]("prompt-textarea");
  _0x4f4925(chrome["runtime"]["getURL"](_0x271c13));
  var _0x58a0c2 = null;
  try {
    (await _0x358706(_0x348002, _0x185276),
      (_0x58a0c2 = _0xb28ed1()),
      _0x27357b("Entered\x20Prompt"),
      console["log"]("chat.js:\x20Entered\x20Prompt"));
  } catch {
    return (
      clearInterval(_0x2482d7),
      await _0x3d967e(),
      await _0x3f0578(_0x185276)
    );
  }
  var _0x383fd0 = _0x291d2d(),
    _0x8ab2d0 = _0x348002["parentElement"]["querySelector"](
      "button[data-testid=\x27send-button\x27]",
    );
  (await _0x151630(_0x8ab2d0),
    _0x8ab2d0["click"](),
    console["log"]("chat.js:\x20ask_button.click()\x20done"),
    _0x2d4d6b("ask_button.click()\x20done"),
    (document["title"] = "Prompt\x20Sent"),
    _0x27357b("Prompt\x20Sent"));
  var _0x530093 = _0x587b89("button", "Response\x201"),
    _0x1103bc = _0x587b89("button.m-auto", "Regenerate"),
    _0x5b255f = _0x587b89("button", "Use\x20default\x20model");
  (_0x2d4d6b("Waiting\x20for\x20Regenerate\x20Button"),
    await _0x383fd0,
    _0x27357b("Stop\x20Generating\x20Button\x20Found"),
    _0x2d4d6b("Stop\x20Generating\x20Button\x20Found"));
  0x1 === _0x4a0eb5 &&
    ((_0x574f43 = await _0xbbfd())["focus"](),
    _0x27357b("Regenerate\x20Button\x20Found"),
    _0x2d4d6b("Web\x20Version\x201:\x20Regenerate\x20Button\x20Found"));
  if (0x2 === _0x4a0eb5) {
    var _0x1c410e = await _0x49e628();
    (_0x27357b("Disabled\x20Send\x20Button\x20Found"),
      _0x2d4d6b("Web\x20Version\x202:\x20Disabled\x20Send\x20Button\x20Found"));
    var _0x574f43 = await _0x47ff85();
    (_0x27357b("Regenerate\x20Button\x20Found"),
      _0x2d4d6b("Web\x20Version\x202:\x20Regenerate\x20Button\x20Found"),
      _0x1c410e["focus"](),
      _0x574f43["focus"]());
  }
  (await _0x58a0c2,
    _0x2d4d6b("Post\x20Status\x20Done"),
    console["log"]("chat.js:\x20postStatus\x20done"),
    console["log"]("chat.js:\x20waitForRegenarteButton\x20done"),
    _0x27357b("Regenerate\x20Button\x20Found"),
    clearInterval(_0x530093),
    clearInterval(_0x1103bc),
    clearInterval(_0x5b255f),
    clearInterval(_0x2482d7),
    _0x2d4d6b("Cleared\x20all\x20intervals"));
  var _0xe12ef1 = document["querySelector"](
    "div[role=\x27presentation\x27]\x20.text-red-500",
  );
  if (_0xe12ef1)
    return (
      _0x2d4d6b("Too\x20Many\x20Requests"),
      console["log"]("chat.js:\x20Too\x20Many\x20Requests:\x20", _0xe12ef1),
      _0x2d4d6b("Waiting\x2010\x20seconds"),
      await _0x3f0578(_0x185276)
    );
  (_0x27357b("Getting\x20Last\x20Message"),
    _0x2d4d6b("Getting\x20Last\x20Message"));
  var _0x189bb5 = await _0x207500();
  (console["log"]("secondLastMessage:\x20", _0x189bb5),
    console["log"]("prompt:\x20", _0x185276),
    _0x2d4d6b("Second\x20Last\x20Message:\x20" + _0x189bb5),
    _0x27357b("Last\x20Message\x20Received"));
  if (!_0x4b0182(_0x185276, _0x189bb5))
    return (
      _0x2d4d6b(
        "Prompt\x20and\x20Second\x20Last\x20Message\x20are\x20not\x20same\x20even\x20after\x20trimming",
      ),
      console["log"](
        "chat.js:\x20prompt\x20and\x20secondLastMessage\x20are\x20not\x20same\x20even\x20after\x20trimming",
      ),
      _0x27357b(
        "Prompt\x20and\x20Second\x20Last\x20Message\x20are\x20not\x20same",
      ),
      await _0x3f0578(_0x185276)
    );
  (_0x2d4d6b(
    "Prompt\x20and\x20Second\x20Last\x20Message\x20are\x20same\x20after\x20trimming",
  ),
    console["log"](
      "chat.js:\x20prompt\x20and\x20secondLastMessage\x20are\x20same\x20after\x20trimming",
    ),
    _0x27357b(
      "Prompt\x20and\x20Second\x20Last\x20Message\x20are\x20same\x20after\x20trimming",
    ),
    _0x27357b("Second\x20Last\x20Message\x20Length:\x20" + _0x189bb5["length"]),
    _0x2d4d6b("Waiting\x20for\x20Chat\x20Box\x20to\x20be\x20Idle"),
    await _0x59a81a(),
    _0x2d4d6b("Chat\x20Box\x20is\x20Idle"),
    _0x2d4d6b("Waiting\x20for\x20Last\x20Message"));
  var _0x5d99bc = null;
  try {
    (_0x2d4d6b("Last\x20Message:\x20" + (_0x5d99bc = _0x49d564())),
      _0x27357b("Last\x20Message\x20Length:\x20" + _0x5d99bc["length"]));
  } catch (_0x16c763) {
    (_0x2d4d6b("Error\x20getting\x20last\x20message:\x20" + _0x16c763),
      console["log"](
        "chat.js\x20getLastMessage:\x20ask_chat_gpt_web:\x20error:\x20",
        _0x16c763,
      ),
      _0x2d4d6b("Waiting\x2010\x20seconds\x20for\x20last\x20message"),
      await new Promise((_0x5582a2) => setTimeout(_0x5582a2, 0x2710)),
      (_0x5d99bc = _0x49d564()));
  }
  return (
    console["log"]("chat.js:\x20last_message:\x20", _0x5d99bc),
    (document["title"] = "Response\x20Received"),
    setTimeout(function () {
      document["title"] = _0x3d65ff;
    }, 0xbb8),
    _0x4f4925(chrome["runtime"]["getURL"](_0x262e37)),
    _0x5d99bc
  );
}
function _0x3f78f1(_0x12a1a7, _0x5554ee) {
  let _0x59b7ed = [];
  for (
    let _0x14827e = 0x0;
    _0x14827e < Math["max"](_0x12a1a7["length"], _0x5554ee["length"]);
    _0x14827e++
  )
    _0x12a1a7[_0x14827e] !== _0x5554ee[_0x14827e] &&
      (_0x59b7ed["push"](_0x14827e),
      console["log"](
        "Difference\x20at\x20position\x20" +
          _0x14827e +
          ":\x20\x27" +
          _0x12a1a7[_0x14827e] +
          "\x27\x20vs\x20\x27" +
          _0x5554ee[_0x14827e] +
          "\x27",
      ));
  0x0 === _0x59b7ed["length"]
    ? console["log"]("No\x20differences\x20found.")
    : console["log"]("Total\x20differences:\x20" + _0x59b7ed["length"]);
}
async function _0x27357b(_0x3220c1) {
  documentTitle = _0x3220c1;
}
function _0xc5961a(_0x5b50af) {
  return _0x5b50af["replace"](/\s+/g, "");
}
function _0x4b0182(_0x3dc941, _0xf06c62) {
  return _0xc5961a(_0x3dc941) === _0xc5961a(_0xf06c62);
}
function _0x4533fe(_0x437f43, _0xc0d873) {
  _0x437f43["focus"]();
  const _0x148e1a = new InputEvent("input", {
    bubbles: !0x0,
    inputType: "insertText",
    data: _0xc0d873,
  });
  _0x437f43["dispatchEvent"](_0x148e1a);
  const _0x929d23 = new Event("change", { bubbles: !0x0 });
  _0x437f43["dispatchEvent"](_0x929d23);
}
async function _0x151630(_0x3b7138) {
  return new Promise((_0x820411) => {
    if (!_0x3b7138["disabled"]) {
      _0x820411();
      return;
    }
    const _0x2fdc62 = new MutationObserver((_0xcd6119) => {
      _0xcd6119["forEach"]((_0x367c59) => {
        "attributes" === _0x367c59["type"] &&
          !_0x3b7138["disabled"] &&
          (_0x2fdc62["disconnect"](), _0x820411());
      });
    });
    _0x2fdc62["observe"](_0x3b7138, { attributes: !0x0 });
  });
}
async function _0x358706(_0x14bef5, _0x40c1f0) {
  ((_0x14bef5["value"] = _0x40c1f0), _0x4533fe(_0x14bef5, _0x40c1f0));
}
function _0x49d564() {
  var _0x5c1d25 = _0x120b24(),
    _0x3c9c37 = "";
  return (
    _0x5c1d25["childNodes"]["forEach"]((_0x4ee3aa) => {
      _0x4ee3aa["nodeType"] === Node["TEXT_NODE"]
        ? (_0x3c9c37 += _0x4ee3aa["nodeValue"])
        : _0x4ee3aa["nodeType"] === Node["ELEMENT_NODE"] &&
          (_0x3c9c37 += _0x4ee3aa["innerText"] + "\x0a");
    }),
    _0x3c9c37["trim"]()
  );
}
function _0x120b24() {
  var _0x3bcc96 = document["querySelector"](
    "div[role=\x27presentation\x27]\x20.flex.flex-col.text-sm",
  )["querySelectorAll"](".group");
  return _0x3bcc96[_0x3bcc96["length"] - 0x1]["querySelector"](".markdown");
}
async function _0x207500() {
  var _0x25e552 = document["querySelector"](
    "div[role=\x27presentation\x27]\x20.flex.flex-col.text-sm",
  );
  await _0x4641b4(".group\x20.markdown", 0x186a0);
  var _0x4698d6 = _0x25e552["querySelectorAll"](".group"),
    _0x24beea = _0x4698d6[_0x4698d6["length"] - 0x2]
      ["querySelector"]("div[data-message-author-role=\x27user\x27]")
      ["querySelector"]("div"),
    _0x1e7ebe = "";
  return (
    _0x24beea["childNodes"]["forEach"]((_0x101af7) => {
      _0x101af7["nodeType"] === Node["TEXT_NODE"]
        ? (_0x1e7ebe += _0x101af7["nodeValue"])
        : _0x101af7["nodeType"] === Node["ELEMENT_NODE"] &&
          (_0x1e7ebe += _0x101af7["innerText"] + "\x0a");
    }),
    _0x1e7ebe["trim"]()
  );
}
async function _0xbbfd() {
  var _0x207e65 = await _0xa8d1bc("button", "Regenerate");
  return (
    console["log"]("chat.js:\x20waitForRegenarteButton:\x20", _0x207e65),
    await new Promise((_0x4b8354) => setTimeout(_0x4b8354, 0x3e8)),
    _0x207e65
  );
}
async function _0x49e628() {
  var _0x1bfc9c = await _0x4641b4(
    "button[data-testid=\x22send-button\x22]",
    0xea60,
  );
  return (
    console["log"]("chat.js:\x20waitForDisabledSendButton:\x20", _0x1bfc9c),
    _0x1bfc9c
  );
}
function _0x47ff85() {
  return new Promise((_0x39423a, _0x59adcc) => {
    const _0x61b653 = setTimeout(() => {
        (clearInterval(_0x1692c2),
          _0x59adcc(
            "Timed\x20out\x20waiting\x20for\x20the\x20regenerate\x20button",
          ));
      }, 0x7530),
      _0x1692c2 = setInterval(() => {
        var _0x286ac0 = document["querySelectorAll"](
            "div[data-testid*=\x27conversation-turn-\x27]",
          ),
          _0x276798 = _0x286ac0[_0x286ac0["length"] - 0x1],
          _0x182a74 = _0x276798
            ? _0x276798["querySelector"](
                "button.md\x5c:group-hover\x5c:visible",
              )
            : null;
        if (_0x182a74)
          (console["log"]("Found\x20regenerateButton", _0x182a74),
            clearInterval(_0x1692c2),
            clearTimeout(_0x61b653),
            _0x39423a(_0x182a74));
        else
          console["log"](
            "Regenerate\x20button\x20not\x20found,\x20checking\x20again...",
          );
      }, 0x3e8);
  });
}
async function _0x291d2d() {
  var _0x3412e0;
  try {
    (0x1 === _0x4a0eb5 &&
      (_0x3412e0 = await _0xa8d1bc("button", "Stop\x20generating", 0x2710)),
      0x2 === _0x4a0eb5 &&
        (_0x3412e0 = await _0x4641b4(
          "button[aria-label=\x22Stop\x20generating\x22]",
          0xea60,
        )));
  } catch (_0x3252c) {
    console["log"](
      "chat.js:\x20waitForStopGeneratingButton:\x20error:\x20",
      _0x3252c,
    );
  }
  return (
    console["log"]("chat.js:\x20waitForStopGeneratingButton:\x20", _0x3412e0),
    _0x3412e0
  );
}
function _0x5bb4f2(_0x40d49f, _0x1ce225 = 0x1388) {
  return new Promise((_0x1f5b7a) => {
    let _0x50b1e7, _0x1c7279;
    const _0x3b6b0e = new MutationObserver(() => {
      ((_0x1c7279 = _0x40d49f["textContent"]),
        _0x1c7279 === _0x50b1e7 && (_0x1f5b7a(), _0x3b6b0e["disconnect"]()),
        (_0x50b1e7 = _0x1c7279));
    });
    (_0x3b6b0e["observe"](_0x40d49f, { childList: !0x0, subtree: !0x0 }),
      setTimeout(() => {
        (_0x1f5b7a(), _0x3b6b0e["disconnect"]());
      }, _0x1ce225));
  });
}
async function _0xa8d1bc(_0x22a639, _0x43c37b, _0x47178b = 0xea60) {
  return new Promise((_0x32f1c7, _0x1fd83e) => {
    const _0x4025bf = setInterval(() => {
      document["querySelectorAll"](_0x22a639)["forEach"]((_0x38b3d9) => {
        _0x38b3d9["innerText"] === _0x43c37b &&
          (clearInterval(_0x4025bf), _0x32f1c7(_0x38b3d9));
      });
    }, 0x64);
    setTimeout(() => {
      (clearInterval(_0x4025bf),
        _0x1fd83e(
          new Error(
            "Timed\x20out\x20after\x20" +
              _0x47178b +
              "\x20ms\x20for\x20selector\x20" +
              _0x22a639 +
              "\x20with\x20innerText\x20" +
              _0x43c37b,
          ),
        ));
    }, _0x47178b);
  });
}
async function _0x4641b4(_0x342f90, _0x3afc79 = 0xea60) {
  return new Promise((_0x4f1457, _0x7d01d5) => {
    const _0x13df23 = setInterval(() => {
      const _0x3175e3 = document["querySelector"](_0x342f90);
      _0x3175e3 && (clearInterval(_0x13df23), _0x4f1457(_0x3175e3));
    }, 0x64);
    setTimeout(() => {
      (clearInterval(_0x13df23),
        _0x7d01d5(
          new Error(
            "Timed\x20out\x20after\x20" +
              _0x3afc79 +
              "\x20ms\x20for\x20selector\x20" +
              _0x342f90,
          ),
        ));
    }, _0x3afc79);
  });
}
function _0x587b89(_0x1b54db, _0x24ab10) {
  const _0x15fe39 = setInterval(() => {
    document["querySelectorAll"](_0x1b54db)["forEach"]((_0x4509db) => {
      _0x4509db["innerText"]["includes"](_0x24ab10) &&
        (clearInterval(_0x15fe39), _0x4509db["click"]());
    });
  }, 0x64);
  return _0x15fe39;
}
async function _0xb28ed1() {
  return await new Promise((_0x4083fc, _0x4ac968) => {
    const _0x229d09 = function (_0x4feeb0, _0x48588f, _0x5effdd) {
      "post-request-detected" === _0x4feeb0["type"] &&
        (console["log"]("POST\x20request\x20to\x20lat/r\x20detected!"),
        console["log"]("request:\x20", _0x4feeb0),
        chrome["runtime"]["onMessage"]["removeListener"](_0x229d09),
        _0x4083fc(_0x4feeb0));
    };
    chrome["runtime"]["onMessage"]["addListener"](_0x229d09);
  });
}
function _0x2d4d6b(_0xa0231a) {
  chrome["runtime"]["sendMessage"]({ type: "log", log: _0xa0231a });
}
async function _0x872d3a(_0x572a58, _0x35c2d8 = 0x3e8) {
  return new Promise((_0xb9a2b4, _0x50f39d) => {
    let _0x3b5a67 = null;
    const _0x1c8f15 = () => {
        (_0x6c940b["disconnect"](), _0xb9a2b4());
      },
      _0x6c940b = new MutationObserver(() => {
        (clearTimeout(_0x3b5a67),
          (_0x3b5a67 = setTimeout(_0x1c8f15, _0x35c2d8)));
      });
    (_0x6c940b["observe"](_0x572a58, {
      childList: !0x0,
      subtree: !0x0,
      attributes: !0x0,
    }),
      (_0x3b5a67 = setTimeout(_0x1c8f15, _0x35c2d8)));
  });
}
async function _0x59a81a() {
  (_0x777853(), _0x2d4d6b("Tab\x20Activated:\x20" + (await _0x2598b5())));
  var _0x24f917 = _0x120b24();
  return (await _0x872d3a(_0x24f917, 0x3e8), _0x24f917);
}
async function _0x2598b5() {
  return await new Promise(function (_0x4a0fb2, _0x57ffca) {
    chrome["runtime"]["sendMessage"](
      { type: "make_tab_active" },
      function (_0x56ad9b) {
        console["log"]("result:\x20", _0x56ad9b);
        var _0x3b65e8 = !0x1;
        try {
          _0x3b65e8 = _0x56ad9b["response"];
        } catch (_0x4645a5) {
          console["log"]("chat.js:\x20makeTabActive:\x20error:\x20", _0x4645a5);
        }
        _0x4a0fb2(_0x3b65e8);
      },
    );
  });
}
async function _0x777853() {
  (_0x2d4d6b("Visibility\x20State:\x20" + document["visibilityState"]),
    _0x2d4d6b("Window\x20Blur\x20State:\x20" + document["hidden"]),
    _0x2d4d6b(
      "Active\x20Element:\x20" +
        (document["activeElement"]
          ? document["activeElement"]["tagName"]
          : "None"),
    ),
    _0x2d4d6b("Document\x20Has\x20Focus:\x20" + document["hasFocus"]()),
    _0x2d4d6b("Performance\x20Timing:\x20" + window["performance"]["now"]()),
    _0x2d4d6b("Current\x20Time:\x20" + Date["now"]()),
    navigator["onLine"]
      ? _0x2d4d6b("Network\x20State:\x20Online")
      : _0x2d4d6b("Network\x20State:\x20Offline"));
}
async function _0x22251f() {
  const _0x41ffaf = new Event("visibilitychange");
  document["dispatchEvent"](_0x41ffaf);
}
async function _0x2409b8() {
  (Object["defineProperty"](document, "visibilityState", {
    value: "visible",
    writable: !0x0,
  }),
    console["log"](
      "visibilityState\x20set\x20to:",
      document["visibilityState"],
    ),
    Object["defineProperty"](document, "hidden", {
      value: !0x1,
      writable: !0x0,
    }),
    console["log"]("hidden\x20set\x20to:", document["hidden"]));
}
async function _0x1ddba7() {
  window["dispatchEvent"](new Event("focus"));
}
async function _0x22a7ef() {
  window["dispatchEvent"](new Event("blur"));
}
async function _0x1debea(_0x2dab1f, _0x2469f1) {
  const _0x425005 = new MouseEvent("click", {
    view: window,
    bubbles: !0x0,
    cancelable: !0x0,
    clientX: _0x2dab1f,
    clientY: _0x2469f1,
  });
  document["dispatchEvent"](_0x425005);
}
async function _0x18a216(_0x50683d, _0x2da97c) {
  const _0x196e25 = new MouseEvent("mousemove", {
    view: window,
    bubbles: !0x0,
    cancelable: !0x0,
    clientX: _0x50683d,
    clientY: _0x2da97c,
  });
  document["dispatchEvent"](_0x196e25);
}
function _0x5495a9() {
  let _0x358760 = new Event("focus");
  document["dispatchEvent"](_0x358760);
}
function _0x28253a() {
  let _0x131a9a = new Event("blur");
  document["dispatchEvent"](_0x131a9a);
}
function _0x43c3a6() {
  let _0x12c76b = document["createElement"]("input");
  ((_0x12c76b["style"]["position"] = "absolute"),
    (_0x12c76b["style"]["opacity"] = "0"),
    (_0x12c76b["style"]["height"] = "0"),
    (_0x12c76b["style"]["width"] = "0"),
    document["body"]["appendChild"](_0x12c76b),
    _0x12c76b["focus"](),
    setTimeout(() => {
      document["body"]["removeChild"](_0x12c76b);
    }, 0x64));
}
function _0x43f6e7() {
  (_0x2d4d6b("Activating\x20alwaysActive\x20function"),
    _0x2409b8(),
    _0x5495a9(),
    _0x43c3a6(),
    _0x22251f(),
    _0x1ddba7(),
    _0x1debea(0x64, 0x64),
    _0x18a216(0xc8, 0xc8),
    _0x777853());
}
function _0xa08042() {
  return !!document["querySelector"](
    "div[role=\x27presentation\x27]\x20.text-red-500",
  );
}
function _0x3a645d() {
  var _0x3e0286 = document["querySelector"](
    "div[role=\x27presentation\x27]\x20.text-red-500",
  );
  if (
    _0x3e0286 &&
    _0x3e0286["innerText"]["includes"]("limit") &&
    _0x3e0286["innerText"]["includes"]("reached")
  )
    return (console["log"]("chat.js:\x20Limit\x20Reached"), !0x0);
  return (console["log"]("chat.js:\x20Limit\x20Not\x20Reached"), !0x1);
}
