async function _0x2d9a6a(_0x45cef8, _0x484766) {
  return new Promise((_0x51d189, _0x2fe716) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x45cef8, data: _0x484766 },
      function (_0x9b65e8) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x484766),
          console["log"]("fetchData\x20response", _0x9b65e8),
          _0x51d189(_0x9b65e8["data"]));
      },
    );
  });
}
async function _0x2ba8fa(_0x2aea05, _0x14e896) {
  return new Promise((_0x186b3b, _0x556fc7) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x2aea05, data: _0x14e896 },
      function (_0x2c7218) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x14e896),
          console["log"]("fetchData\x20response", _0x2c7218),
          _0x2c7218["error"] && _0x556fc7(_0x2c7218["error"]),
          _0x186b3b(_0x2c7218["data"]));
      },
    );
  });
}
function _0x2dc0d0(
  _0x1a628e,
  {
    primeEligible: primeEligible = !0x0,
    maxPrice: maxPrice = null,
    minPrice: minPrice = null,
    pageNumber: pageNumber = 0x1,
    sort: sort = "reviews",
    freeShipping: freeShipping = !0x0,
    domain: domain = "com",
    isSellerAmazon: isSellerAmazon = !0x1,
  } = {},
) {
  (console["log"]("buildAmazonSearchUrl"),
    console["log"](_0x1a628e),
    console["log"]("maxPrice:\x20" + maxPrice),
    console["log"]("minPrice:\x20" + minPrice));
  let _0x1e48ee =
    "https://www.amazon." + domain + "/s?k=" + encodeURIComponent(_0x1a628e);
  return (
    null != minPrice &&
      null == maxPrice &&
      (_0x1e48ee += "&rh=p_36%3A" + 0x64 * minPrice + "-"),
    null == minPrice &&
      null != maxPrice &&
      (_0x1e48ee += "&rh=p_36%3A-" + 0x64 * maxPrice),
    null != minPrice &&
      null != maxPrice &&
      (_0x1e48ee += "&rh=p_36%3A" + 0x64 * minPrice + "-" + 0x64 * maxPrice),
    null == minPrice && null == maxPrice && (_0x1e48ee += "&rh=p_36%3A-"),
    "com" == domain
      ? (_0x1e48ee += "%2Cp_85%3A2470955011")
      : "ca" == domain && (_0x1e48ee += "%2Cp_85%3A5690392011"),
    freeShipping &&
      ("com" == domain &&
        ((_0x1e48ee += "%2C"), (_0x1e48ee += "p_76%3A1249155011")),
      "ca" == domain &&
        ((_0x1e48ee += "%2C"), (_0x1e48ee += "p_76%3A3276484011"))),
    isSellerAmazon &&
      ("com" == domain &&
        ((_0x1e48ee += "%2C"),
        (_0x1e48ee += "p_n_feature_forty-seven_browse-bin%3A24677333011")),
      "ca" == domain &&
        ((_0x1e48ee += "%2C"), (_0x1e48ee += "p_6%3AA3DWYIK6Y9EEQB"))),
    primeEligible && (_0x1e48ee += "&rhf=gp%3Aa"),
    "lowest-price" == sort && (_0x1e48ee += "&s=price-asc-rank"),
    "reviews" == sort && (_0x1e48ee += "&s=review-count-rank"),
    _0x1e48ee
  );
}
function _0x20c1cd(
  _0x5402f6,
  _0x156b04 = "ca",
  _0x3f7510 = 0x1e,
  _0x16287b = 0x0,
  _0x5cfc87 = 0x0,
  _0x99c186 = 0x32,
  _0x2b90ec = "-itemssold",
  _0x4080f5 = "SOLD",
  _0x46aa4f = "EBAY-CA",
  _0x255ecb = "America/Toronto",
  _0x1cf3b4 = "BuyerLocation:::CA",
  _0x5cb18e = 0x1e,
) {
  _0x46aa4f = "";
  switch (_0x156b04) {
    case "ca":
    default:
      _0x46aa4f = "EBAY-CA";
      break;
    case "com":
      _0x46aa4f = "EBAY-US";
      break;
    case "co.uk":
      _0x46aa4f = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x156b04 +
    "/sh/research?" +
    [
      "keywords=" + _0x5402f6,
      "dayRange=" + _0x3f7510,
      "categoryId=" + _0x16287b,
      "offset=" + _0x5cfc87,
      "limit=" + _0x99c186,
      "sorting=" + _0x2b90ec,
      "tabName=" + _0x4080f5,
      "marketplace=" + _0x46aa4f,
      "tz=" + encodeURIComponent(_0x255ecb),
      "minPrice=" + _0x5cb18e,
    ]["join"]("&")
  );
}
function _0x3554c2(_0xbc3b29) {
  return (
    "https://www.ebay.ca/sh/research?marketplace=EBAY-CA&keywords=" +
    encodeURIComponent(_0xbc3b29) +
    "&dayRange=30&endDate=1679082379576&startDate=1676493979576&categoryId=0&offset=0&limit=50&tabName=ACTIVE&tz=America%2FToronto"
  );
}
console["log"]("functions.js\x20loaded");
function _0x203454() {
  var _0x4bf1f6 = document["createElement"]("button");
  return (
    _0x4bf1f6["setAttribute"](
      "class",
      "btn\x20btn-primary\x20search-terapeak-button\x20pushable\x20front",
    ),
    _0x4bf1f6["setAttribute"]("style", "margin-left:\x2010px;"),
    (_0x4bf1f6["innerHTML"] = "Search\x20Terapeak"),
    _0x4bf1f6["addEventListener"]("click", function (_0x4a7084) {
      (_0x4a7084["preventDefault"](), _0x9d6eac(_0x4a7084));
    }),
    _0x4bf1f6
  );
}
function _0x9d6eac(_0x49c17c) {
  var _0x31399f = _0x49c17c["target"]["parentNode"];
  console["log"](_0x31399f);
  var _0x3d2da6 = _0x31399f["querySelector"](
      ".str-card-title\x20.str-text-span",
    )["innerText"],
    _0x1b1894 = _0x31399f["querySelector"](
      ".str-item-card__property-displayPrice",
    )["innerText"];
  ((_0x1b1894 = _0x1b1894["replace"](/[^0-9.]/g, "")),
    (_0x1b1894 *= 0.7),
    (_0x1b1894 = Math["round"](_0x1b1894)),
    console["log"](_0x3d2da6));
  var _0x15f995 = _0x3d2da6["split"]("\x20"),
    _0x2389c2 = _0x20c1cd(
      (_0x3d2da6 = (_0x3d2da6 = (_0x3d2da6 = _0x15f995["slice"](0x0, 0x5)[
        "join"
      ]("\x20"))["replace"](/[^a-zA-Z0-9]+$/, ""))["trim"]()),
      void 0x0,
      0x2da,
      void 0x0,
      void 0x0,
      void 0x0,
      void 0x0,
      void 0x0,
      void 0x0,
      void 0x0,
      void 0x0,
      _0x1b1894,
    );
  (console["log"](_0x2389c2),
    chrome["runtime"]["sendMessage"]({
      type: "open-tab-by-url",
      url: _0x2389c2,
    }));
}
console["log"]("content.js\x20loaded");
var _0x1d8720 = document["getElementsByClassName"]("str-item-card\x20ITEM");
for (var _0x211d8f = 0x0; _0x211d8f < _0x1d8720["length"]; _0x211d8f++) {
  var _0x246740 = _0x1d8720[_0x211d8f],
    _0x1176dc = _0x203454();
  _0x246740["appendChild"](_0x1176dc);
}
