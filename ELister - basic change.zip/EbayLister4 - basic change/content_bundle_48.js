function _0x4aae16(
  _0x22df49,
  _0x197ac9 = 0x3e8,
  {
    titlePrefix: titlePrefix = "Auto\x20Order",
    position: position = "top-left",
    scale: scale = 1.25,
    autoShowHud: autoShowHud = !0x0,
    fadeOutMs: fadeOutMs = 0x5dc,
  } = {},
) {
  let _0x1c2ab8 = Promise["resolve"](),
    _0x58582d = null,
    _0x3f80b1 = 0x0,
    _0x5a8fb2 = null;
  function _0x13972e(_0x1ef08f, _0x5482f1 = "#fff") {
    (function () {
      return (
        !_0x5a8fb2 &&
          (document["querySelectorAll"]("link[rel*=\x27icon\x27]")["forEach"](
            (_0x3d70e8) => _0x3d70e8["remove"](),
          ),
          (_0x5a8fb2 = document["createElement"]("link")),
          (_0x5a8fb2["rel"] = "icon"),
          document["head"]["appendChild"](_0x5a8fb2)),
        _0x5a8fb2
      );
    })()["href"] = (function (_0x2c080c, _0x201812 = "#fff") {
      const _0x3c29c3 = document["createElement"]("canvas");
      ((_0x3c29c3["width"] = 0x40), (_0x3c29c3["height"] = 0x40));
      const _0x2a8016 = _0x3c29c3["getContext"]("2d");
      return (
        (_0x2a8016["fillStyle"] = _0x201812),
        _0x2a8016["fillRect"](0x0, 0x0, 0x40, 0x40),
        (_0x2a8016["font"] = "48px\x20serif"),
        (_0x2a8016["textAlign"] = "center"),
        (_0x2a8016["textBaseline"] = "middle"),
        _0x2a8016["fillText"](_0x2c080c, 0x20, 0x28),
        _0x3c29c3["toDataURL"]("image/png")
      );
    })(_0x1ef08f, _0x5482f1);
  }
  const _0x1667ca = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
  let _0x3143da = null,
    _0x1b1b55 = 0x0,
    _0x2b096f = "";
  function _0x10817f(_0x4ab027) {
    ((_0x2b096f = _0x4ab027), _0x5e9334());
    const _0x187a0c = titlePrefix + ":\x20" + _0x4ab027,
      _0x55b7c1 = () => {
        document["title"] =
          _0x1667ca[_0x1b1b55++ % _0x1667ca["length"]] + "\x20" + _0x187a0c;
      };
    _0x55b7c1();
    const _0x2aa6a8 = () => (document["hidden"] ? 0x190 : 0x78);
    ((_0x3143da = setInterval(_0x55b7c1, _0x2aa6a8())),
      document["addEventListener"](
        "visibilitychange",
        () => {
          _0x3143da &&
            (clearInterval(_0x3143da),
            (_0x3143da = setInterval(_0x55b7c1, _0x2aa6a8())));
        },
        { once: !0x0 },
      ));
  }
  function _0x5e9334(_0x409c2f = "") {
    (_0x3143da && (clearInterval(_0x3143da), (_0x3143da = null)),
      _0x409c2f
        ? (document["title"] = titlePrefix + ":\x20" + _0x409c2f)
        : _0x2b096f && (document["title"] = titlePrefix + ":\x20" + _0x2b096f));
  }
  let _0x2c1a92 = null,
    _0x2ea94d = !0x1;
  function _0x28b346() {
    if (_0x2c1a92) return _0x2c1a92;
    return (
      !(function () {
        if (_0x2ea94d) return;
        _0x2ea94d = !0x0;
        const _0x511033 = document["createElement"]("style");
        ((_0x511033["textContent"] =
          "\x0a\x20\x20\x20\x20\x20\x20.ao-hud{position:fixed;z-index:2147483647;display:inline-flex;align-items:flex-start;gap:12px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20background:rgba(18,20,23,.96);color:#e7f3ff;border:1px\x20solid\x20rgba(255,255,255,.1);\x0a\x20\x20\x20\x20\x20\x20\x20\x20padding:12px\x2014px;border-radius:14px;box-shadow:0\x2010px\x2030px\x20rgba(0,0,0,.35);\x0a\x20\x20\x20\x20\x20\x20\x20\x20font:600\x2014px/1.35\x20system-ui,-apple-system,Segoe\x20UI,Roboto,sans-serif;pointer-events:none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20opacity:0;transform:translateY(-6px);transition:opacity\x20.18s,transform\x20.18s}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.show{opacity:1;transform:translateY(0)}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.tl{top:16px;left:16px;transform-origin:\x20top\x20left}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.tr{top:16px;right:16px;transform-origin:\x20top\x20right}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.bl{bottom:16px;left:16px;transform-origin:\x20bottom\x20left}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.br{bottom:16px;right:16px;transform-origin:\x20bottom\x20right}\x0a\x0a\x20\x20\x20\x20\x20\x20.ao-spin{width:22px;height:22px;border-radius:50%;border:3px\x20solid\x20currentColor;border-right-color:transparent;animation:ao-rot\x20.7s\x20linear\x20infinite}\x0a\x20\x20\x20\x20\x20\x20@keyframes\x20ao-rot{to{transform:rotate(360deg)}}\x0a\x20\x20\x20\x20\x20\x20.ao-icon{font-size:20px;display:none}\x0a\x0a\x20\x20\x20\x20\x20\x20/*\x20Allow\x20wrapping\x20instead\x20of\x20single-line\x20ellipsis\x20*/\x0a\x20\x20\x20\x20\x20\x20.ao-text{\x0a\x20\x20\x20\x20\x20\x20\x20\x20white-space:\x20normal;\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20was:\x20nowrap\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20word-break:\x20break-word;\x0a\x20\x20\x20\x20\x20\x20\x20\x20overflow:\x20visible;\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20was:\x20hidden\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20text-overflow:\x20initial;\x20\x20\x20\x20\x20\x20/*\x20was:\x20ellipsis\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20max-width:\x20min(60vw,\x20720px);\x20/*\x20keep\x20it\x20readable\x20on\x20wide\x20screens\x20*/\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20.ao-hud.done{color:#19c37d}.ao-hud.error{color:#ff6b6b}\x0a\x20\x20\x20\x20"),
          document["head"]["appendChild"](_0x511033));
      })(),
      (_0x2c1a92 = document["createElement"]("div")),
      (_0x2c1a92["className"] =
        "ao-hud\x20" +
        ("top-right" === position
          ? "tr"
          : "bottom-left" === position
            ? "bl"
            : "bottom-right" === position
              ? "br"
              : "tl")),
      (_0x2c1a92["style"]["scale"] = String(scale)),
      (_0x2c1a92["innerHTML"] =
        "\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-spin\x22\x20aria-hidden=\x22true\x22></div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-icon\x22\x20aria-hidden=\x22true\x22>✅</div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-text\x22\x20aria-live=\x22polite\x22\x20aria-atomic=\x22true\x22></div>\x0a\x20\x20\x20\x20"),
      document["body"]["appendChild"](_0x2c1a92),
      _0x2c1a92
    );
  }
  function _0x27b04b() {
    return _0x1c2ab8;
  }
  return (
    _0x13972e("🟡", "#fff"),
    {
      update: function (
        _0xf1a864,
        {
          delayMs: delayMs = _0x197ac9,
          coalesce: coalesce = !0x0,
          showHud: showHud = autoShowHud,
        } = {},
      ) {
        if (coalesce && _0xf1a864 === _0x58582d) return _0x1c2ab8;
        _0x58582d = _0xf1a864;
        const _0x1460f4 = _0x3f80b1;
        return (
          _0x13972e("🟡", "#fff"),
          showHud
            ? (function (_0x4be71c) {
                if (!autoShowHud) {
                  _0x10817f(_0x4be71c);
                  return;
                }
                const _0x42184b = _0x28b346();
                (_0x42184b["classList"]["remove"]("done", "error"),
                  _0x42184b["classList"]["add"]("show"),
                  (_0x42184b["querySelector"](".ao-spin")["style"]["display"] =
                    ""),
                  (_0x42184b["querySelector"](".ao-icon")["style"]["display"] =
                    "none"),
                  (_0x42184b["querySelector"](".ao-text")["textContent"] =
                    _0x4be71c),
                  _0x10817f(_0x4be71c));
              })(_0xf1a864)
            : _0x10817f(_0xf1a864),
          (_0x1c2ab8 = _0x1c2ab8["then"](async () => {
            if (_0x1460f4 !== _0x3f80b1) return;
            const _0x522373 = document["getElementById"](_0x22df49);
            (_0x522373 && (_0x522373["innerText"] = _0xf1a864),
              await ((_0x588d81 = delayMs),
              new Promise((_0x26f2a5) => setTimeout(_0x26f2a5, _0x588d81))));
            var _0x588d81;
          })["catch"](() => {})),
          _0x1c2ab8
        );
      },
      cancel: function () {
        _0x3f80b1++;
      },
      whenIdle: _0x27b04b,
      finish: async function (_0x2d29f4 = "Complete") {
        (await _0x27b04b(),
          _0x13972e("✅", "#fff"),
          !(function (_0x5b0379) {
            (autoShowHud &&
              (_0x28b346(),
              _0x2c1a92["classList"]["remove"]("error"),
              _0x2c1a92["classList"]["add"]("done", "show"),
              (_0x2c1a92["querySelector"](".ao-spin")["style"]["display"] =
                "none"),
              (_0x2c1a92["querySelector"](".ao-icon")["style"]["display"] = ""),
              (_0x2c1a92["querySelector"](".ao-icon")["textContent"] = "✅"),
              (_0x2c1a92["querySelector"](".ao-text")["textContent"] =
                _0x5b0379),
              fadeOutMs > 0x0 &&
                setTimeout(
                  () => _0x2c1a92["classList"]["remove"]("show"),
                  fadeOutMs,
                )),
              _0x5e9334(_0x5b0379));
          })(_0x2d29f4));
      },
      error: function (_0x216120 = "Failed") {
        (_0x13972e("❌", "#fff"),
          !(function (_0x5ae546) {
            (autoShowHud &&
              (_0x28b346(),
              _0x2c1a92["classList"]["remove"]("done"),
              _0x2c1a92["classList"]["add"]("error", "show"),
              (_0x2c1a92["querySelector"](".ao-spin")["style"]["display"] =
                "none"),
              (_0x2c1a92["querySelector"](".ao-icon")["style"]["display"] = ""),
              (_0x2c1a92["querySelector"](".ao-icon")["textContent"] = "❌"),
              (_0x2c1a92["querySelector"](".ao-text")["textContent"] =
                _0x5ae546)),
              _0x5e9334(_0x5ae546));
          })(_0x216120));
      },
    }
  );
}
console["log"](
  "content/amazon/auto_order/order_details/functions.js\x20loaded",
);
function _0x303932() {
  var _0x4257ad = document["querySelector"](
    ".order-date-invoice-item\x20[dir=\x22ltr\x22]",
  );
  _0x4257ad ||
    (_0x4257ad = document["querySelector"]("[data-component=\x22orderId\x22]"));
  var _0x4a3242 = _0x4257ad["textContent"];
  return _0x4a3242["trim"]();
}
function _0x3f7565() {
  var _0x47031a = _0x2c7ebd();
  if (
    "de" === _0x47031a ||
    "fr" === _0x47031a ||
    "es" === _0x47031a ||
    "it" === _0x47031a ||
    "nl" === _0x47031a ||
    "co.uk" === _0x47031a
  )
    return _0x20026();
  var _0x72fe97 = _0x1d8ead("Total\x20before\x20tax:");
  (console["log"]("element", _0x72fe97),
    _0x72fe97 || (_0x72fe97 = _0x1d8ead("Total\x20Before\x20GST:")));
  var _0x59b7e7 = _0x72fe97["closest"]("[class*=\x22row-label\x22]")[
    "nextElementSibling"
  ]["textContent"];
  return (
    (_0x59b7e7 = (_0x59b7e7 = _0x59b7e7["trim"]())["replace"](/[^0-9.]/g, "")),
    parseFloat(_0x59b7e7)["toFixed"](0x2)
  );
}
function _0x2c7ebd() {
  const _0x293b90 = window["location"]["hostname"]["toLowerCase"]();
  return _0x293b90["endsWith"]("amazon.co.uk")
    ? "co.uk"
    : _0x293b90["endsWith"]("amazon.de")
      ? "de"
      : _0x293b90["endsWith"]("amazon.fr")
        ? "fr"
        : _0x293b90["endsWith"]("amazon.es")
          ? "es"
          : _0x293b90["endsWith"]("amazon.it")
            ? "it"
            : _0x293b90["endsWith"]("amazon.nl")
              ? "nl"
              : _0x293b90["endsWith"]("amazon.com")
                ? "com"
                : _0x293b90["endsWith"]("amazon.com.au")
                  ? "au"
                  : _0x293b90["endsWith"]("amazon.ca")
                    ? "ca"
                    : null;
}
function _0x20026() {
  const _0x40d506 = {
      de: 0.19,
      fr: 0.2,
      es: 0.21,
      it: 0.22,
      nl: 0.21,
      "co.uk": 0.2,
    }[_0x2c7ebd()],
    _0x4b0d15 = _0x1a6d2c();
  if ("number" != typeof _0x4b0d15 || null == _0x40d506) return null;
  const _0x1bf39d = Math["round"](0x64 * _0x4b0d15);
  return (Math["round"](_0x1bf39d / (0x1 + _0x40d506)) / 0x64)["toFixed"](0x2);
}
function _0x13a940() {
  const _0xc00cdf = {
      de: 0.19,
      fr: 0.2,
      es: 0.21,
      it: 0.22,
      nl: 0.21,
      "co.uk": 0.2,
    }[_0x2c7ebd()],
    _0x1580e9 = _0x1a6d2c();
  if ("number" != typeof _0x1580e9 || null == _0xc00cdf) return null;
  const _0x590b9a = Math["round"](0x64 * _0x1580e9);
  return ((_0x590b9a - Math["round"](_0x590b9a / (0x1 + _0xc00cdf))) / 0x64)[
    "toFixed"
  ](0x2);
}
function _0x291270() {
  var _0x4c20ea = [
      "Estimated\x20tax\x20to\x20be\x20collected:",
      "Estimated\x20PST/RST/QST:",
      "Estimated\x20GST/HST:",
      "Estimated\x20GST:",
      "Estimated\x20GST\x20to\x20be\x20collected:",
      "GST:",
    ],
    _0x1a2724 = [];
  const _0x1cfdd8 = document["querySelectorAll"]("li");
  var _0x2a0e2b = [];
  for (let _0xa4f91c of _0x1cfdd8)
    for (let _0x2c423b of _0x4c20ea)
      _0xa4f91c?.["innerText"]["includes"](_0x2c423b) &&
        _0x2a0e2b["push"](_0xa4f91c);
  (console["log"]("matchingElements", _0x2a0e2b),
    (_0x2a0e2b = [...new Set(_0x2a0e2b)]),
    console["log"]("matchingElements\x20deduped", _0x2a0e2b));
  if (0x0 === _0x2a0e2b["length"]) return null;
  for (let _0x54514f of _0x2a0e2b) {
    var _0x516fde = _0x54514f?.["querySelector"](
      "[class*=\x22row-content\x22]",
    )?.["textContent"];
    _0x516fde && _0x1a2724["push"](_0x13a6c7(_0x516fde));
  }
  console["log"]("taxValues", _0x1a2724);
  var _0x2fff4b = _0x1a2724["reduce"](
    (_0x339417, _0xba8904) => _0x339417 + _0xba8904,
    0x0,
  );
  return (console["log"]("totalTax", _0x2fff4b), _0x2fff4b);
}
function _0x3f4e30(_0xcc9e4e) {
  const _0x2456b5 = document["querySelectorAll"]("*"),
    _0x5f26b3 = [];
  for (let _0xb46726 of _0x2456b5)
    for (let _0x3f3ca2 of _0xcc9e4e)
      if (_0xb46726["innerText"]["includes"](_0x3f3ca2)) {
        _0x5f26b3["push"](_0xb46726);
        break;
      }
  return _0x5f26b3;
}
function _0x5d970c() {
  var _0x40af34 = _0x2c7ebd();
  if (
    "de" === _0x40af34 ||
    "fr" === _0x40af34 ||
    "es" === _0x40af34 ||
    "it" === _0x40af34 ||
    "nl" === _0x40af34 ||
    "co.uk" === _0x40af34
  )
    return _0x13a940();
  var _0x3bf91f = _0x291270();
  if (null !== _0x3bf91f) return _0x3bf91f;
  var _0x383dda = _0x1a6d2c();
  console["log"]("grandTotal", _0x383dda);
  var _0x3d8ba9 = _0x3f7565();
  console["log"]("totalBeforeTax", _0x3d8ba9);
  var _0x14aa2c = _0x383dda - _0x3d8ba9;
  return _0x14aa2c["toFixed"](0x2);
}
function _0x1c7696() {
  var _0x9eb96e = _0x48f498([
      "Grand\x20Total:",
      "Gesamtsumme:",
      "Eindtotaal:",
      "Montant\x20total",
    ]),
    _0x497376 = _0x9eb96e?.["closest"]("[class*=\x22row-label\x22]")?.[
      "nextElementSibling"
    ];
  return _0x497376;
}
function _0x1a6d2c() {
  var _0x39082f = _0x1c7696(),
    _0x19bedc = _0x39082f?.["textContent"];
  return _0x13a6c7(_0x19bedc);
}
function _0x38bc2d() {
  const _0x1cb556 = _0x1c7696(),
    _0x16734f = (_0x1cb556?.["textContent"] || "")
      ["replace"](/[0-9\s.,\-€$£¥]/g, "")
      ["trim"]();
  if (_0x16734f["length"] > 0x0) return _0x16734f;
  const _0x266186 = (location["hostname"] || "")
      ["toLowerCase"]()
      ["replace"](/^www\./, ""),
    map = {
      "amazon.com": "USD",
      "amazon.ca": "CAD",
      "amazon.com.mx": "MXN",
      "amazon.com.br": "BRL",
      "amazon.com.au": "AUD",
      "amazon.co.uk": "GBP",
      "amazon.de": "EUR",
      "amazon.fr": "EUR",
      "amazon.it": "EUR",
      "amazon.es": "EUR",
      "amazon.nl": "EUR",
      "amazon.se": "SEK",
      "amazon.pl": "PLN",
      "amazon.com.tr": "TRY",
      "amazon.ae": "AED",
      "amazon.sa": "SAR",
      "amazon.co.jp": "JPY",
      "amazon.in": "INR",
      "amazon.sg": "SGD",
      "amazon.cn": "CNY",
      "amazon.eg": "EGP",
      "amazon.be": "EUR",
    };
  return map[_0x266186]
    ? map[_0x266186]
    : _0x266186["endsWith"](".co.uk")
      ? "GBP"
      : _0x266186["endsWith"](".de") ||
          _0x266186["endsWith"](".fr") ||
          _0x266186["endsWith"](".it") ||
          _0x266186["endsWith"](".es") ||
          _0x266186["endsWith"](".nl")
        ? "EUR"
        : _0x266186["endsWith"](".se")
          ? "SEK"
          : _0x266186["endsWith"](".pl")
            ? "PLN"
            : _0x266186["endsWith"](".tr")
              ? "TRY"
              : _0x266186["endsWith"](".ae")
                ? "AED"
                : _0x266186["endsWith"](".sa")
                  ? "SAR"
                  : _0x266186["endsWith"](".co.jp")
                    ? "JPY"
                    : _0x266186["endsWith"](".in")
                      ? "INR"
                      : _0x266186["endsWith"](".sg")
                        ? "SGD"
                        : _0x266186["endsWith"](".com.mx")
                          ? "MXN"
                          : _0x266186["endsWith"](".com.br")
                            ? "BRL"
                            : _0x266186["endsWith"](".com.au")
                              ? "AUD"
                              : _0x266186["endsWith"](".ca")
                                ? "CAD"
                                : _0x266186["endsWith"](".cn")
                                  ? "CNY"
                                  : _0x266186["endsWith"](".eg")
                                    ? "EGP"
                                    : _0x266186["endsWith"](".be")
                                      ? "EUR"
                                      : (_0x266186["endsWith"](".com"), "USD");
}
function _0x13a6c7(_0x186e90) {
  if (!_0x186e90) return null;
  let _0x4fb4a7 = _0x186e90["replace"](/[^\d.,-]/g, "")["trim"]();
  if (
    _0x4fb4a7["includes"](",") &&
    _0x4fb4a7["lastIndexOf"](",") > _0x4fb4a7["lastIndexOf"](".")
  )
    ((_0x4fb4a7 = _0x4fb4a7["replace"](/\./g, "")),
      (_0x4fb4a7 = _0x4fb4a7["replace"](",", ".")));
  else _0x4fb4a7 = _0x4fb4a7["replace"](/,/g, "");
  const _0x2ecd3f = parseFloat(_0x4fb4a7);
  return isNaN(_0x2ecd3f) ? null : _0x2ecd3f;
}
function _0x54caa8() {
  var _0x4d8ed9 = document["querySelector"](".shipment-top-row");
  _0x4d8ed9 || (_0x4d8ed9 = document["querySelector"]("#shipment-top-row"));
  var _0x25e9af = _0x4d8ed9["querySelector"]("div")["textContent"];
  return _0x25e9af["trim"]();
}
function _0x469ade() {
  var _0x3713dc = document["querySelector"](".order-date-invoice-item");
  _0x3713dc ||
    (_0x3713dc = document["querySelector"](
      "[data-component=\x22orderDate\x22]",
    ));
  var _0xf1568f = _0x3713dc["textContent"];
  return _0xf1568f["trim"]();
}
function _0x1cd09e() {
  var _0x2ff145 = document["querySelector"](".displayAddressDiv");
  _0x2ff145 ||
    (_0x2ff145 = document["querySelector"](
      "[data-component=\x22shippingAddress\x22]",
    ))
      ["querySelectorAll"]("h5")
      ["forEach"](function (_0x12ecfd) {
        _0x12ecfd["remove"]();
      });
  var _0x5c8c9f = _0x2ff145["textContent"];
  return (_0x5c8c9f = (_0x5c8c9f = _0x5c8c9f["trim"]())["replace"](
    /\n\s*\n/g,
    "\x0a",
  ))["trim"]();
}
function _0x2b5e9c() {
  var _0x5db2b8 = document["querySelector"](
      "[data-component=\x22shipments\x22]\x20.a-box-inner\x20.a-fixed-right-grid-col\x20a",
    )["getAttribute"]("href"),
    _0x1003a8 = _0x5db2b8["split"]("/")[0x3];
  return (
    _0x1003a8
      ? console["warn"]("SKU\x20not\x20found\x20in\x20href:", _0x5db2b8)
      : (_0x1003a8 = _0x5db2b8["split"]("/dp/")[0x1]["split"]("?")[0x0]),
    _0x1003a8
  );
}
function _0x1d8ead(_0x12d29f) {
  const _0x55568d = document["querySelectorAll"]("*");
  var _0x3fed47 = [];
  for (let _0x432237 of _0x55568d)
    _0x432237["innerText"]["includes"](_0x12d29f) &&
      _0x3fed47["push"](_0x432237);
  return _0x3fed47["length"] > 0x0
    ? _0x3fed47[_0x3fed47["length"] - 0x1]
    : null;
}
function _0x48f498(_0x496d22) {
  if (!Array["isArray"](_0x496d22)) return null;
  const _0x10c497 = document["querySelectorAll"]("*"),
    _0x55b36d = [];
  for (let _0x184346 of _0x10c497)
    for (let _0x3c11aa of _0x496d22)
      if (_0x184346["innerText"]["includes"](_0x3c11aa)) {
        _0x55b36d["push"](_0x184346);
        break;
      }
  return _0x55b36d["length"] > 0x0
    ? _0x55b36d[_0x55b36d["length"] - 0x1]
    : null;
}
async function _0x181010() {
  var _0x405ec6 = _0x303932(),
    _0x1f4d53 = _0x3f7565(),
    _0x4c489b = _0x1cd09e(),
    _0x29376d,
    _0x2da506 = _0x5dba82();
  _0x29376d = _0x5d970c();
  var { amazonEmail: _0x16d26f } = await chrome["storage"]["local"]["get"]([
      "amazonEmail",
    ]),
    _0x3cdbf7 = _0x54caa8(),
    _0x136e9d = _0x469ade(),
    _0x25b9ed = {
      amazonOrderNumber: _0x405ec6,
      totalBeforeTax: _0x1f4d53,
      totalTax: _0x29376d,
      estimatedDeliveryDate: _0x3cdbf7,
      amazonSku: _0x2b5e9c(),
      fulfillmentDate: _0x136e9d,
      customerAddress: _0x4c489b,
      amazonDomain: _0x2da506,
      amazonEmail: _0x16d26f,
      grandTotal: _0x1a6d2c(),
    },
    _0x262ec1 = _0x38bc2d();
  return (
    console["log"]("grandTotalCurrency", _0x262ec1),
    _0x262ec1 && (_0x25b9ed["grandTotalCurrency"] = _0x262ec1),
    _0x25b9ed
  );
}
function _0x3c57d5() {
  var _0x335b08 = document["createElement"]("button");
  return (
    (_0x335b08["innerHTML"] = "Export\x20To\x20ClipBoard"),
    (_0x335b08["className"] = "copyButton"),
    (_0x335b08["onclick"] = async function () {
      var _0x4d02ac = await _0x181010(),
        _0x2885db = _0x4d02ac["customerAddress"]["split"]("\x0a")[0x0];
      ((_0x335b08["innerHTML"] =
        "Exported:\x20" + _0x2885db + "\x20to\x20ClipBoard"),
        console["log"](_0x4d02ac),
        navigator["clipboard"]
          ["writeText"](JSON["stringify"](_0x4d02ac))
          ["then"](() => {
            (_0x335b08["classList"]["add"]("copied"),
              setTimeout(() => {
                _0x335b08["classList"]["remove"]("copied");
              }, 0x7d0));
          }));
    }),
    _0x335b08
  );
}
async function _0x3bf756(_0xb9bfa0 = !0x1, _0x4f8ec9) {
  console["log"]("copyOrderDetails");
  var _0x47dfe6 = await _0x181010();
  console["log"]("orderDetails", _0x47dfe6);
  var _0x42ba64 = JSON["stringify"](_0x47dfe6);
  console["log"]("stringified\x20orderDetails", _0x42ba64);
  if (_0xb9bfa0) {
    console["log"]("orderDetailsString", _0x42ba64);
    var _0x27d805 = {
      clipKey: _0x4f8ec9,
      content: JSON["stringify"](_0x47dfe6),
    };
    console["log"]("data", _0x27d805);
    try {
      console["log"]("making\x20request");
      var _0x4f96cd = await fetch(
        "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/virtualClipboard/",
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON["stringify"](_0x27d805),
        },
      );
      console["log"]("response", _0x4f96cd);
      if (!_0x4f96cd["ok"])
        throw new Error("Failed\x20to\x20save\x20order\x20details");
      var _0x70a85b = await _0x4f96cd["json"]();
      return (
        console["log"]("Order\x20details\x20saved\x20successfully:", _0x70a85b),
        _0x70a85b
      );
    } catch (_0x5a9f58) {
      console["error"]("Error\x20saving\x20order\x20details:", _0x5a9f58);
      throw _0x5a9f58;
    }
  } else navigator["clipboard"]["writeText"](_0x42ba64);
}
function _0x5dba82() {
  return window["location"]["href"]["split"]("/")[0x2];
}
function _0x24939() {
  var _0x5a48f1 = document["createElement"]("button");
  return (
    (_0x5a48f1["innerText"] = "Export\x20to\x20EcomSniper"),
    _0x5a48f1["classList"]["add"]("ebay-submit-order-details-button"),
    _0x5a48f1["addEventListener"]("click", async function () {
      var _0x451e04 = await _0x181010(),
        { orderDetails: _0x3efd06 } =
          await chrome["storage"]["local"]["get"]("orderDetails");
      console["log"]("orderDetails", _0x3efd06);
      var _0x196966 = { ..._0x451e04, ..._0x3efd06 };
      console["log"]("combinedData", _0x196966);
      var _0x3196db = await _0x58ffdb(
        _0x3efd06["orderEarnings"],
        _0x451e04["totalBeforeTax"],
        _0x451e04["totalTax"],
        _0x451e04["amazonDomain"],
      );
      _0x196966["profit"] = _0x3196db;
      var _0x455d39 = _0x451e04["customerAddress"]["split"]("\x0a")[0x0],
        _0x1529b9 = _0x3efd06["customer"]["name"];
      if (await _0x21f7ea(_0x455d39, _0x1529b9))
        try {
          var _0x8a04d = await _0x212457(_0x196966);
          (console["log"]("response", _0x8a04d),
            _0x5a48f1["classList"]["remove"](
              "ebay-submit-order-details-button-working",
            ),
            _0x5a48f1["classList"]["add"](
              "ebay-submit-order-details-button-success",
            ),
            (_0x5a48f1["innerText"] = "Exported!"));
        } catch (_0x21de05) {
          (_0x5a48f1["classList"]["remove"](
            "ebay-submit-order-details-button-working",
          ),
            _0x5a48f1["classList"]["add"](
              "ebay-submit-order-details-button-error",
            ),
            (_0x5a48f1["innerText"] = "Error\x20Exporting\x20Data"),
            console["log"]("error", _0x21de05));
        }
      else
        (_0x5a48f1["classList"]["remove"](
          "ebay-submit-order-details-button-working",
        ),
          _0x5a48f1["classList"]["add"](
            "ebay-submit-order-details-button-error",
          ),
          (_0x5a48f1["innerText"] = "Check\x20Details"));
    }),
    _0x5a48f1
  );
}
async function _0x1deaa4() {
  var { orderDetails: _0x2d6106 } =
      await chrome["storage"]["local"]["get"]("orderDetails"),
    _0x5db9b4 = document["createElement"]("div");
  _0x5db9b4["classList"]["add"]("order-details");
  var _0x246826 = document["createElement"]("p");
  return (
    (_0x246826["textContent"] =
      "Customer:\x20" + _0x2d6106["customer"]["name"]),
    _0x5db9b4["appendChild"](_0x246826),
    _0x5db9b4
  );
}
async function _0x561a24() {
  try {
    var _0x43cec0 = await _0x181010(),
      { amazonEmail: _0x156ff8 } = await chrome["storage"]["local"]["get"]([
        "amazonEmail",
      ]);
    _0x43cec0["amazonEmail"] = _0x156ff8;
    var { orderDetails: _0x4450f0 } =
      await chrome["storage"]["local"]["get"]("orderDetails");
    console["log"]("orderDetails", _0x4450f0);
    var _0x205e62 = { ..._0x43cec0, ..._0x4450f0 };
    console["log"]("combinedData", _0x205e62);
    var _0x44a2d2 = await _0x58ffdb(
      _0x4450f0["orderEarnings"],
      _0x43cec0["totalBeforeTax"],
      _0x43cec0["totalTax"],
      _0x43cec0["amazonDomain"],
    );
    _0x205e62["profit"] = _0x44a2d2;
    var _0x377f4c = _0x43cec0["customerAddress"]["split"]("\x0a")[0x0],
      _0x192906 = _0x4450f0["customer"]["name"];
    if (!(await _0x21f7ea(_0x377f4c, _0x192906)))
      throw new Error("Fulfillment\x20details\x20are\x20incorrect");
    var _0x430fb1 = await _0x212457(_0x205e62);
    console["log"]("response", _0x430fb1);
  } catch (_0x5f537b) {
    throw new Error("Error\x20exporting\x20data\x20to\x20EcomSniper");
  }
}
async function _0x21f7ea(_0x46a728, _0x229393) {
  return (
    _0x229393 === _0x46a728 ||
    confirm(
      "WARNING:\x20Customer\x20name\x20does\x20not\x20match!\x20Please\x20verify\x20the\x20fulfillment\x20details.",
    )
  );
}
async function _0x212457(_0x1e91cf) {
  try {
    var _0xd50bb4 = await fetch(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/ebayOrders",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON["stringify"](_0x1e91cf),
      },
    );
    if (!_0xd50bb4["ok"])
      throw new Error("Failed\x20to\x20submit\x20eBay\x20order");
    var _0x2a3bd8 = await _0xd50bb4["json"]();
    return (
      console["log"]("eBay\x20order\x20submitted\x20successfully:", _0x2a3bd8),
      _0x2a3bd8
    );
  } catch (_0x2b0f9c) {
    console["error"]("Error\x20submitting\x20eBay\x20order:", _0x2b0f9c);
    throw _0x2b0f9c;
  }
}
const _0x54a785 = {
  CAD_TO_USD: 0x1 / 1.3507,
  USD_TO_CAD: 1.3507,
  GBP_TO_USD: 0x1 / 0.789173,
  USD_TO_GBP: 0.789173,
  AUD_TO_USD: 0x1 / 1.64866,
  USD_TO_AUD: 1.64866,
  EUR_TO_USD: 0x1 / 1.0821,
  USD_TO_EUR: 1.0821,
};
function _0x5a5ef8(_0x3174d0) {
  let _0x1e6298 = _0x3174d0["match"](/(C \$|\$|£|A \$|€)/);
  return {
    currencySymbol: _0x1e6298 ? _0x1e6298[0x0] : null,
    amount: parseFloat(_0x3174d0["replace"](/[^\d.-]/g, "")),
  };
}
function _0x2aab74(_0xad4f2a) {
  switch (_0xad4f2a) {
    case "www.amazon.ca":
      return "CAD";
    case "www.amazon.com":
      return "USD";
    case "www.amazon.co.uk":
      return "GBP";
    case "www.amazon.com.au":
      return "AUD";
    case "www.amazon.de":
      return "EUR";
    default:
      return "UNKNOWN";
  }
}
function _0x30a1bd(_0x449dce) {
  return parseFloat(_0x449dce["replace"](/[^\d.-]/g, ""));
}
async function _0x58ffdb(_0xad6823, _0x11bb2f, _0x1e2e6c, _0x465760) {
  console["log"]("Raw\x20Order\x20Earnings:", _0xad6823);
  var { currencySymbol: _0x4f5e10, amount: _0x3eae92 } = _0x5a5ef8(_0xad6823);
  (console["log"]("Currency\x20Symbol:", _0x4f5e10),
    console["log"]("Order\x20Earnings:", _0x3eae92),
    console["log"]("Total\x20Before\x20Tax:", _0x11bb2f),
    console["log"]("Total\x20Tax:", _0x1e2e6c),
    console["log"]("Amazon\x20Domain:", _0x465760));
  var _0x2563ea = _0x2aab74(_0x465760);
  console["log"]("Domain\x20Currency:", _0x2563ea);
  if ("UNKNOWN" === _0x2563ea)
    return (
      console["error"]("Unsupported\x20Amazon\x20domain"),
      "Unsupported\x20domain"
    );
  var _0x254b86 =
    (_0x11bb2f = _0x30a1bd(_0x11bb2f)) + (_0x1e2e6c = _0x30a1bd(_0x1e2e6c));
  console["log"]("Total\x20Cost:", _0x254b86);
  var _0x2cfc3f = _0x254b86;
  let _0x1a9fdf =
    { "C\x20$": "CAD", $: "USD", "£": "GBP", "A\x20$": "AUD", "€": "EUR" }[
      _0x4f5e10
    ] || "USD";
  console["log"]("Earnings\x20Currency:", _0x1a9fdf);
  if (_0x1a9fdf !== _0x2563ea) {
    let _0x4bfd9e = _0x2563ea + "_TO_" + _0x1a9fdf,
      _0x5106ca = _0x54a785[_0x4bfd9e] || 0x1;
    ((_0x2cfc3f = _0x254b86 * _0x5106ca),
      console["log"]("Conversion\x20Key:", _0x4bfd9e),
      console["log"]("Conversion\x20Rate:", _0x5106ca),
      console["log"]("Converted\x20Cost:", _0x2cfc3f));
  }
  let _0x395a3c = _0x3eae92 - _0x2cfc3f;
  console["log"]("Profit:", _0x395a3c);
  let _0x36e236 = "" + _0x4f5e10 + _0x395a3c["toFixed"](0x2);
  return (console["log"]("Formatted\x20Profit:", _0x36e236), _0x36e236);
}
(console["log"]("content/amazon/auto_order/order_details/content.js\x20loaded"),
  chrome["runtime"]["onMessage"]["addListener"](
    function (_0x22ebde, _0x3f503d, _0x237953) {
      "autoOrder" === _0x22ebde["type"] &&
        "record_order_details" === _0x22ebde["action"] &&
        (console["log"](
          "Received\x20request\x20to\x20get\x20order\x20history:",
          _0x22ebde["orderDetails"],
        ),
        _0x50feb7(_0x22ebde["orderDetails"]));
    },
  ),
  document["addEventListener"]("DOMContentLoaded", async function () {
    var _0x1a846a = await _0x181010();
    console["log"]("fulfillmentData", _0x1a846a);
  }));
async function _0x50feb7(_0x1985af) {
  var _0x39f875 = new _0x4aae16();
  _0x39f875["update"]("Retrieving\x20customer\x20address");
  var _0x41efbb = _0x1cd09e();
  console["log"]("customerAddress", _0x41efbb);
  var _0x24f1f2 = _0x41efbb["split"]("\x0a")[0x0],
    _0x1a2a23 = _0x1985af["customer"]["name"];
  _0x39f875["update"](
    "Collecting\x20Your\x20Order\x20Details,\x20Please\x20wait...",
  );
  var _0x1e69c9 = await _0x181010();
  (console["log"]("fullfillmentData", _0x1e69c9),
    _0x39f875["update"](
      "Checking\x20if\x20fulfillment\x20details\x20are\x20correct",
    ));
  if (!(await _0x21f7ea(_0x24f1f2, _0x1a2a23))) {
    (_0x39f875["error"](
      "It\x20seems\x20the\x20fulfillment\x20details\x20are\x20incorrect",
    ),
      console["log"]("Fulfillment\x20details\x20are\x20incorrect"));
    throw new Error("Fulfillment\x20details\x20are\x20incorrect");
  }
  var _0x14f5e0 = { ..._0x1985af, ..._0x1e69c9 };
  try {
    var { amazonEmail: _0x4e3154 } = await chrome["storage"]["local"]["get"]([
      "amazonEmail",
    ]);
    _0x14f5e0["amazonEmail"] = _0x4e3154;
  } catch (_0x292af1) {
    console["error"](
      "Error\x20getting\x20amazonEmail\x20from\x20storage",
      _0x292af1,
    );
  }
  (console["log"]("orderToSubmit", _0x14f5e0),
    _0x39f875["update"](
      "Sending\x20order\x20details\x20to\x20eBay,\x20Please\x20wait...",
    ));
  var _0x441423 = 0x0,
    _0x4ef034 = !0x1;
  for (; !_0x4ef034 && _0x441423 < 0x3; ) {
    (++_0x441423 > 0x1 &&
      _0x39f875["update"](
        "Failed\x20to\x20submit\x20order\x20details,\x20retrying\x20(" +
          _0x441423 +
          "/3)...",
      ),
      await new Promise((_0x46b756) => setTimeout(_0x46b756, 0x1388)));
    if (_0x441423 > 0x1) {
      var _0x2da6f3 = _0x1306d8(_0x14f5e0["domain"]);
      _0x14f5e0["orderEarningsCurrency"] = _0x2da6f3;
    }
    try {
      var _0x8b2a34 = await _0x212457(_0x14f5e0);
      (console["log"]("response", _0x8b2a34), (_0x4ef034 = !0x0));
    } catch (_0x16c822) {
      console["error"]("Error\x20submitting\x20eBay\x20order:", _0x16c822);
    }
  }
  (_0x4ef034
    ? _0x39f875["finish"](
        "Order\x20details\x20sent!\x20You\x20can\x20return\x20to\x20your\x20eBay\x20order\x20page\x20now.",
      )
    : _0x39f875["error"](
        "Failed\x20to\x20submit\x20order\x20details\x20after\x203\x20attempts.",
      ),
    _0x1985af["autoCloseAmazonTabAfterOrder"] &&
      chrome["runtime"]["sendMessage"]({ type: "close_tab" }));
}
function _0x1306d8(_0x538e6c) {
  switch (_0x538e6c) {
    case "com":
    default:
      return "USD";
    case "co.uk":
      return "GBP";
    case "ca":
      return "CAD";
    case "de":
    case "fr":
    case "it":
    case "es":
    case "nl":
      return "EUR";
    case "com.mx":
      return "MXN";
    case "com.au":
      return "AUD";
    case "se":
      return "SEK";
    case "pl":
      return "PLN";
    case "in":
      return "INR";
  }
}
