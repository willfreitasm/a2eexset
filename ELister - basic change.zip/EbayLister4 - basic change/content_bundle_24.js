var _0xa98fbf = !0x1;
function _0x48a61d(_0xbc263e, _0x369697 = "image/x-icon") {
  var _0xf7d33 = "shortcut\x20icon";
  "image/gif" == _0x369697 || "image/png" == _0x369697
    ? (_0xf7d33 = "icon")
    : (_0xa98fbf = !0x1);
  var _0x4113a6 =
    document["querySelector"]("link[rel*=\x27icon\x27]") ||
    document["createElement"]("link");
  ((_0x4113a6["type"] = _0x369697),
    (_0x4113a6["rel"] = _0xf7d33),
    (_0x4113a6["href"] = _0xbc263e),
    document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x4113a6));
}
function _0x5af816(_0x283a62, _0x3548e5 = "image/x-icon") {
  let _0x35d4d4 =
      "image/gif" == _0x3548e5 || "image/png" == _0x3548e5
        ? "icon"
        : "shortcut\x20icon",
    _0x46bcea = document["querySelectorAll"]("link[rel*=\x27icon\x27]");
  if (0x0 === _0x46bcea["length"]) {
    let _0x14c97c = document["createElement"]("link");
    ((_0x14c97c["type"] = _0x3548e5),
      (_0x14c97c["rel"] = _0x35d4d4),
      (_0x14c97c["href"] = _0x283a62),
      document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x14c97c));
    return;
  }
  for (let _0x6505fa of _0x46bcea) {
    ((_0x6505fa["type"] = _0x3548e5),
      (_0x6505fa["rel"] = _0x35d4d4),
      (_0x6505fa["href"] = _0x283a62));
  }
}
function _0x314a5a() {
  _0xa98fbf = !0x0;
  var _0x256a73 = 0x0,
    _0x20532b = chrome["runtime"]["getURL"](
      "Favicons/Gifs/Gear/frame_" + _0x256a73 + "_delay-0.04s.gif",
    ),
    _0x34c19a = setInterval(function () {
      if (_0xa98fbf && _0x256a73 < 0x1c)
        (_0x48a61d(_0x20532b, "image/gif"),
          _0x256a73++,
          (_0x20532b = chrome["runtime"]["getURL"](
            "Favicons/Gifs/Gear/frame_" + _0x256a73 + "_delay-0.04s.gif",
          )));
      else {
        if (_0xa98fbf && _0x256a73 >= 0x1c)
          ((_0x256a73 = 0x0),
            (_0x20532b = chrome["runtime"]["getURL"](
              "Favicons/Gifs/Gear/frame_" + _0x256a73 + "_delay-0.04s.gif",
            )));
        else clearInterval(_0x34c19a);
      }
    }, 0x28);
}
function _0x34e526() {
  _0xa98fbf = !0x0;
  var _0x8c898b = 0x0,
    _0x3fa86e = chrome["runtime"]["getURL"](
      "Favicons/Task_Bar/" + _0x8c898b + ".png",
    ),
    _0x448edf = setInterval(function () {
      if (_0xa98fbf && _0x8c898b < 0x1b)
        (_0x48a61d(_0x3fa86e, "image/gif"),
          _0x8c898b++,
          (_0x3fa86e = chrome["runtime"]["getURL"](
            "Favicons/Task_Bar/" + _0x8c898b + ".png",
          )));
      else {
        if (_0xa98fbf && _0x8c898b >= 0x1b)
          ((_0x8c898b = 0x0),
            (_0x3fa86e = chrome["runtime"]["getURL"](
              "Favicons/Task_Bar/" + _0x8c898b + ".png",
            )));
        else clearInterval(_0x448edf);
      }
    }, 0x28);
}
function _0x19294e() {
  _0xa98fbf = !0x0;
  var _0x30e61a = 0x0,
    _0x2057a3 = [0x2, 0x8, 0xe, 0x14, 0x1a, 0x1b],
    _0x5bb951 = 0x28,
    _0x14e9c5 = "0.04s",
    _0x4e28fb = setInterval(function () {
      if (_0xa98fbf) {
        _0x14e9c5 = _0x2057a3["includes"](_0x30e61a) ? "0.05s" : "0.04s";
        var _0xb855cb =
          "frame_" +
          _0x30e61a["toString"]()["padStart"](0x2, "0") +
          "_delay-" +
          _0x14e9c5 +
          ".gif";
        (_0x48a61d(
          chrome["runtime"]["getURL"]("Favicons/Sniper/" + _0xb855cb),
          "image/gif",
        ),
          ++_0x30e61a >= 0x1b && (_0x30e61a = 0x0),
          (_0x5bb951 = "0.05s" === _0x14e9c5 ? 0x32 : 0x28));
      } else clearInterval(_0x4e28fb);
    }, _0x5bb951);
}
async function _0x2dfb81() {
  ((_0xa98fbf = !0x1),
    await new Promise((_0x30f1be) => setTimeout(_0x30f1be, 0x7d0)));
}
function _0x24d064() {
  return new Promise((_0x4b0f28) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x4b0f28();
      });
    });
  });
}
function _0x11ceaf() {
  return new Promise((_0x31fc2a) => {
    requestIdleCallback(() => {
      _0x31fc2a();
    });
  });
}
function _0x4a7ce7(_0x3692cb = 0x3e8) {
  return new Promise((_0x443d05, _0x406d22) => {
    let _0x3df748,
      _0x25b73a = Date["now"](),
      _0x7e8ce3 = !0x1;
    function _0x22de9a() {
      if (Date["now"]() - _0x25b73a > _0x3692cb)
        (_0x7e8ce3 && _0x3df748["disconnect"](), _0x443d05());
      else setTimeout(_0x22de9a, _0x3692cb);
    }
    const _0xcbaf13 = () => {
        _0x25b73a = Date["now"]();
      },
      _0x5355f8 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x3df748 = new MutationObserver(_0xcbaf13)),
        _0x3df748["observe"](document["body"], _0x5355f8),
        (_0x7e8ce3 = !0x0),
        setTimeout(_0x22de9a, _0x3692cb));
    else
      window["onload"] = () => {
        ((_0x3df748 = new MutationObserver(_0xcbaf13)),
          _0x3df748["observe"](document["body"], _0x5355f8),
          (_0x7e8ce3 = !0x0),
          setTimeout(_0x22de9a, _0x3692cb));
      };
  });
}
async function _0x3b90d9() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x4a7ce7(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
console["log"]("ebay_error_page.js");
async function _0x5246d0() {
  (await _0x24d064(),
    chrome["runtime"]["sendMessage"]({
      type: "itemFailed",
      sku: "error",
      message: "Ebay\x20Error\x20Page",
    }),
    _0x48a61d("https://www.freeiconspng.com/uploads/error-icon-4.png"),
    (document["title"] = "Failed\x20to\x20Submit\x20the\x20Listing!"));
}
_0x5246d0();
