var _0x46e1b0 = async function (_0x373a51 = "sniper-mark") {
  var _0x5d6cf5 = document["createElement"]("img");
  return (
    (_0x5d6cf5["id"] = _0x373a51),
    _0x5d6cf5["classList"]["add"]("sniper-mark"),
    (_0x5d6cf5["src"] = await chrome["runtime"]["getURL"](
      "libraries/target-spin/target.png",
    )),
    _0x5d6cf5
  );
};
function _0x3dfbec() {
  var _0x472878 = document["querySelectorAll"](".sniper-mark");
  for (var _0x54a8ce = 0x0; _0x54a8ce < _0x472878["length"]; _0x54a8ce++)
    _0x472878[_0x54a8ce]["classList"]["add"]("spin");
}
function _0x515973() {
  var _0x4622ce = document["querySelectorAll"](".sniper-mark");
  for (var _0x206fb0 = 0x0; _0x206fb0 < _0x4622ce["length"]; _0x206fb0++)
    _0x4622ce[_0x206fb0]["classList"]["remove"]("spin");
}
function _0x53f2da() {
  var _0xf8827 = document["querySelectorAll"](".sniper-mark");
  for (var _0x24a8bf = 0x0; _0x24a8bf < _0xf8827["length"]; _0x24a8bf++)
    _0xf8827[_0x24a8bf]["classList"]["add"]("flash");
}
function _0x54c694() {
  var _0x53d542 = document["querySelectorAll"](".sniper-mark");
  for (var _0x5ae2ad = 0x0; _0x5ae2ad < _0x53d542["length"]; _0x5ae2ad++)
    _0x53d542[_0x5ae2ad]["classList"]["remove"]("flash");
}
function _0x4173d3(_0x1b4b31) {
  _0x1b4b31["classList"]["add"]("spin");
}
function _0x4bf737(_0x296092) {
  _0x296092["classList"]["remove"]("spin");
}
function _0x4bf4ac(_0x1f7ee7) {
  _0x1f7ee7["classList"]["add"]("flash");
}
function _0x1636d1(_0x247f12) {
  _0x247f12["classList"]["remove"]("flash");
}
function _0x3d0db2(_0x4945da, _0x221371) {
  console["log"]("flyInText:\x20started");
  const _0x5c625d = _0x4945da["split"]("");
  ((_0x221371["innerHTML"] = ""),
    console["log"]("flyInText:\x20finished\x20clearing\x20element"));
  const _0x599330 = document["createElement"]("style");
  ((_0x599330["innerHTML"] =
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20@keyframes\x20flyIn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20from\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateY(-100%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x200;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20to\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateY(0%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x201;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"),
    console["log"]("flyInText:\x20finished\x20creating\x20style"),
    document["head"]["appendChild"](_0x599330),
    console["log"](
      "flyInText:\x20finished\x20appending\x20style\x20to\x20head",
    ),
    _0x5c625d["forEach"]((_0x555f4e, _0x3ff471) => {
      const _0x44cc82 = document["createElement"]("span");
      ((_0x44cc82["innerHTML"] = _0x555f4e),
        (_0x44cc82["style"]["opacity"] = "0"),
        (_0x44cc82["style"]["animation"] =
          "flyIn\x200.1s\x20ease\x20forwards\x20" + _0x3ff471 / 0x23 + "s"),
        _0x221371["appendChild"](_0x44cc82));
    }),
    console["log"](
      "flyInText:\x20finished\x20appending\x20chars\x20to\x20element",
    ));
}
function _0x1a88dd(_0x1392e4, screenWidth, screenHeight, _0x17aecc) {
  const _0x2eead3 = document["createElement"]("div");
  return (
    (_0x2eead3["style"]["position"] = "absolute"),
    (_0x2eead3["style"]["fontSize"] = _0x1392e4 + "px"),
    (_0x2eead3["style"]["zIndex"] = "9999999"),
    (_0x2eead3["speed"] = Math["random"]() * _0x17aecc + 0x1),
    Math["random"]() > 0.5 &&
      (_0x2eead3["style"]["color"] =
        "#" + Math["floor"](0xffffff * Math["random"]())["toString"](0x10)),
    _0x1fb797(_0x2eead3, screenWidth, screenHeight),
    document["body"]["appendChild"](_0x2eead3),
    _0x2eead3
  );
}
function _0x1fb797(_0x276acc, screenWidth, screenHeight) {
  ((_0x276acc["style"]["top"] = Math["random"]() * -screenHeight + "px"),
    (_0x276acc["style"]["left"] =
      Math["floor"](Math["random"]() * screenWidth) + "px"),
    (_0x276acc["style"]["opacity"] = 0x1));
}
function _0x200b95(
  _0x3a1b3f,
  _0x86589d,
  _0x3232a2,
  _0x5c702f,
  screenWidth,
  screenHeight,
  _0x1285d7,
) {
  const _0x10a5a7 = performance["now"]() - _0x1285d7;
  (_0x3a1b3f["forEach"]((_0x57e36f) => {
    const _0x55c76a = parseFloat(_0x57e36f["style"]["top"]),
      _0x80560 = parseFloat(_0x57e36f["style"]["left"]),
      _0x260996 = _0x57e36f["speed"];
    if (_0x55c76a > screenHeight)
      _0x1fb797(_0x57e36f, screenWidth, screenHeight);
    else
      ((_0x57e36f["style"]["top"] =
        _0x55c76a + _0x260996 * (_0x10a5a7 / 0x3e8) + "px"),
        (_0x57e36f["style"]["left"] =
          _0x80560 + 0x2 * Math["random"]() - 0x1 + "px"),
        (_0x57e36f["style"]["opacity"] = Math["max"](
          0x0,
          (_0x86589d - _0x10a5a7) / _0x86589d,
        )));
  }),
    _0x10a5a7 < _0x86589d
      ? requestAnimationFrame(() =>
          _0x200b95(
            _0x3a1b3f,
            _0x86589d,
            _0x3232a2,
            _0x5c702f,
            screenWidth,
            screenHeight,
            _0x1285d7,
          ),
        )
      : _0x3a1b3f["forEach"]((_0x3d5442) => {
          document["body"]["removeChild"](_0x3d5442);
        }));
}
var _0x16b022 = !0x1;
function _0x41785d(_0x2ebc45, _0x533ca4 = "image/x-icon") {
  var _0xdbd3d1 = "shortcut\x20icon";
  "image/gif" == _0x533ca4 || "image/png" == _0x533ca4
    ? (_0xdbd3d1 = "icon")
    : (_0x16b022 = !0x1);
  var _0x56eabe =
    document["querySelector"]("link[rel*=\x27icon\x27]") ||
    document["createElement"]("link");
  ((_0x56eabe["type"] = _0x533ca4),
    (_0x56eabe["rel"] = _0xdbd3d1),
    (_0x56eabe["href"] = _0x2ebc45),
    document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x56eabe));
}
function _0x1f373c(_0x47db21, _0x340ce7 = "image/x-icon") {
  let _0x19b1b2 =
      "image/gif" == _0x340ce7 || "image/png" == _0x340ce7
        ? "icon"
        : "shortcut\x20icon",
    _0x3a044a = document["querySelectorAll"]("link[rel*=\x27icon\x27]");
  if (0x0 === _0x3a044a["length"]) {
    let _0x3d1c79 = document["createElement"]("link");
    ((_0x3d1c79["type"] = _0x340ce7),
      (_0x3d1c79["rel"] = _0x19b1b2),
      (_0x3d1c79["href"] = _0x47db21),
      document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x3d1c79));
    return;
  }
  for (let _0x31d6d2 of _0x3a044a) {
    ((_0x31d6d2["type"] = _0x340ce7),
      (_0x31d6d2["rel"] = _0x19b1b2),
      (_0x31d6d2["href"] = _0x47db21));
  }
}
function _0x5d0a63() {
  _0x16b022 = !0x0;
  var _0x324519 = 0x0,
    _0x4476d1 = chrome["runtime"]["getURL"](
      "Favicons/Gifs/Gear/frame_" + _0x324519 + "_delay-0.04s.gif",
    ),
    _0x78a9be = setInterval(function () {
      if (_0x16b022 && _0x324519 < 0x1c)
        (_0x41785d(_0x4476d1, "image/gif"),
          _0x324519++,
          (_0x4476d1 = chrome["runtime"]["getURL"](
            "Favicons/Gifs/Gear/frame_" + _0x324519 + "_delay-0.04s.gif",
          )));
      else {
        if (_0x16b022 && _0x324519 >= 0x1c)
          ((_0x324519 = 0x0),
            (_0x4476d1 = chrome["runtime"]["getURL"](
              "Favicons/Gifs/Gear/frame_" + _0x324519 + "_delay-0.04s.gif",
            )));
        else clearInterval(_0x78a9be);
      }
    }, 0x28);
}
function _0x5493fb() {
  _0x16b022 = !0x0;
  var _0x5f0e43 = 0x0,
    _0x2d084c = chrome["runtime"]["getURL"](
      "Favicons/Task_Bar/" + _0x5f0e43 + ".png",
    ),
    _0x9581ce = setInterval(function () {
      if (_0x16b022 && _0x5f0e43 < 0x1b)
        (_0x41785d(_0x2d084c, "image/gif"),
          _0x5f0e43++,
          (_0x2d084c = chrome["runtime"]["getURL"](
            "Favicons/Task_Bar/" + _0x5f0e43 + ".png",
          )));
      else {
        if (_0x16b022 && _0x5f0e43 >= 0x1b)
          ((_0x5f0e43 = 0x0),
            (_0x2d084c = chrome["runtime"]["getURL"](
              "Favicons/Task_Bar/" + _0x5f0e43 + ".png",
            )));
        else clearInterval(_0x9581ce);
      }
    }, 0x28);
}
function _0x2edd6a() {
  _0x16b022 = !0x0;
  var _0x15898c = 0x0,
    _0x5c0cc1 = [0x2, 0x8, 0xe, 0x14, 0x1a, 0x1b],
    _0x26a98a = 0x28,
    _0x1e67a5 = "0.04s",
    _0x483855 = setInterval(function () {
      if (_0x16b022) {
        _0x1e67a5 = _0x5c0cc1["includes"](_0x15898c) ? "0.05s" : "0.04s";
        var _0x4f31fc =
          "frame_" +
          _0x15898c["toString"]()["padStart"](0x2, "0") +
          "_delay-" +
          _0x1e67a5 +
          ".gif";
        (_0x41785d(
          chrome["runtime"]["getURL"]("Favicons/Sniper/" + _0x4f31fc),
          "image/gif",
        ),
          ++_0x15898c >= 0x1b && (_0x15898c = 0x0),
          (_0x26a98a = "0.05s" === _0x1e67a5 ? 0x32 : 0x28));
      } else clearInterval(_0x483855);
    }, _0x26a98a);
}
async function _0x420233() {
  ((_0x16b022 = !0x1),
    await new Promise((_0x30e2f5) => setTimeout(_0x30e2f5, 0x7d0)));
}
async function _0x1d68fc(_0x161dfe, _0x1796d3) {
  return new Promise((_0x238ec0, _0xfc2c66) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x161dfe, data: _0x1796d3 },
      function (_0x46fe2d) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x1796d3),
          console["log"]("fetchData\x20response", _0x46fe2d),
          _0x238ec0(_0x46fe2d["data"]));
      },
    );
  });
}
async function _0x37ebff(_0x4e9cb9, _0x2bedc9) {
  return new Promise((_0x282d08, _0x118f30) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x4e9cb9, data: _0x2bedc9 },
      function (_0x40fd5d) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x2bedc9),
          console["log"]("fetchData\x20response", _0x40fd5d),
          _0x40fd5d["error"] && _0x118f30(_0x40fd5d["error"]),
          _0x282d08(_0x40fd5d["data"]));
      },
    );
  });
}
async function fetchPrompt(_0x1f1d92) {
  var _0xc432ca = chrome["runtime"]["getURL"](_0x1f1d92),
    _0x28a76a = await fetch(_0xc432ca);
  return await _0x28a76a["text"]();
}
function _0x176ee3(_0x53a138, _0x5a481f = 0.7, _0x1dae90 = "text-davinci-003") {
  return new Promise((_0x26757b, _0x32cce5) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "request-openAi",
        prompt: _0x53a138,
        temperature: _0x5a481f,
        model: _0x1dae90,
      },
      function (_0x1e8b10) {
        _0x26757b(_0x1e8b10["response"]);
      },
    );
  });
}
function _0x2e06a7(_0x3c0d9a) {
  if (!_0x3c0d9a["error"]) return _0x3c0d9a;
  alert(
    "OpenAI:\x20" +
      _0x3c0d9a["error"]["message"] +
      "\x0aENTER\x20IN\x20NEW\x20API\x20KEY",
  );
}
function _0x5d29d6(_0xdac585, _0x1294d8) {
  return (
    console["log"]("test\x20save\x20to\x20local\x20storage"),
    console["log"]("key\x20" + _0xdac585 + ",\x20value\x20" + _0x1294d8),
    new Promise((_0x508472, _0x4fe4fa) => {
      chrome["storage"]["local"]["set"](
        { [_0xdac585]: _0x1294d8 },
        function () {
          (console["log"]("my\x20key", _0xdac585),
            chrome["storage"]["local"]["get"](_0xdac585, function (_0x4ae63f) {
              (console["log"](
                "the\x20Value\x20currently\x20is\x20",
                _0x4ae63f[_0xdac585],
              ),
                _0x508472());
            }));
        },
      );
    })
  );
}
function _0x2f9597(_0x3aec77) {
  return new Promise((_0x695db, _0x5764c0) => {
    chrome["storage"]["local"]["get"](_0x3aec77, function (_0x924be1) {
      (console["log"]("Value\x20currently\x20is\x20", _0x924be1[_0x3aec77]),
        _0x695db(_0x924be1[_0x3aec77]));
    });
  });
}
function _0xd72872() {
  var _0x2b1fb1 = document["createElement"]("table");
  return (
    _0x2b1fb1["setAttribute"]("id", "listing-data-table"),
    _0x2b1fb1["setAttribute"]("class", "styled-table"),
    _0x2b1fb1["createTHead"]()["insertRow"](0x0),
    _0x2b1fb1["createTBody"](),
    _0x2b1fb1
  );
}
function _0x2f5245(_0x5da1a6, _0xbb1eb8) {
  var _0x344609 = _0xbb1eb8["headerName"],
    _0x5a2d7c = _0x344609["toLowerCase"]()["replace"](/ /g, "-"),
    _0x4e3c79 =
      _0x5da1a6["querySelector"]("thead")["getElementsByTagName"]("tr")[0x0],
    _0x2577fe = document["createElement"]("th");
  ((_0x2577fe["innerHTML"] = _0x344609),
    _0x2577fe["setAttribute"]("class", _0x5a2d7c + "-header"),
    _0x4e3c79["appendChild"](_0x2577fe));
}
function _0x442148(_0x1b60cf) {
  var _0x5920fe = _0x1b60cf["toLowerCase"]()["replace"](/ /g, "-");
  return document["querySelector"]("." + _0x5920fe + "-header")["cellIndex"];
}
function _0xda3845(_0x9a1f7e) {
  var _0x374256 = _0x9a1f7e["querySelector"]("thead")
      ["getElementsByTagName"]("tr")[0x0]
      ["getElementsByTagName"]("th"),
    _0x3c2af9 =
      _0x9a1f7e["querySelector"]("tbody")["getElementsByTagName"]("tr"),
    _0x462c8b = _0x9a1f7e["querySelector"]("tbody")["insertRow"](
      _0x3c2af9["length"],
    );
  for (var _0x4fdb83 = 0x0; _0x4fdb83 < _0x374256["length"]; _0x4fdb83++)
    _0x462c8b["insertCell"](_0x4fdb83)["setAttribute"](
      "class",
      _0x374256[_0x4fdb83]["innerHTML"]["toLowerCase"]()["replace"](/ /g, "-") +
        "-cell",
    );
  return _0x3c2af9["length"];
}
function _0x44920a(_0x1de8fc, _0x19ac9c) {
  var _0x4e0e22 = _0x19ac9c["rowNumber"],
    _0x33f60d = _0x19ac9c["headerName"],
    _0x256b33 = _0x19ac9c["cellValue"],
    _0xc5de06 = _0x33f60d["toLowerCase"]()["replace"](/ /g, "-");
  _0x1de8fc["querySelector"](
    "tbody\x20tr:nth-child(" + _0x4e0e22 + ")\x20td." + _0xc5de06 + "-cell",
  )["innerHTML"] = _0x256b33;
}
function _0x507a4e(_0x1ee442, _0x11bcd2) {
  var _0xd1da03 = _0x11bcd2["button"],
    _0x5bfaae = _0x11bcd2["rowNumber"],
    _0x36d7db = _0x11bcd2["headerName"]["toLowerCase"]()["replace"](/ /g, "-");
  _0x1ee442["querySelector"](
    "tbody\x20tr:nth-child(" + _0x5bfaae + ")\x20td." + _0x36d7db + "-cell",
  )["appendChild"](_0xd1da03);
}
function _0x428b98(_0x51ff1c, _0x2ae46c) {
  var _0x1dd6bc, _0x5420d6, _0x5dba0e, _0x54d0f6, _0x35f7ba, _0x1b459e;
  ((_0x51ff1c = document["getElementById"](_0x51ff1c)), (_0x5420d6 = !0x0));
  for (; _0x5420d6; ) {
    ((_0x5420d6 = !0x1),
      (_0x1dd6bc = _0x51ff1c["getElementsByTagName"]("tr")),
      console["log"]("sortTable\x20rows", _0x1dd6bc));
    for (_0x5dba0e = 0x1; _0x5dba0e < _0x1dd6bc["length"] - 0x1; _0x5dba0e++) {
      _0x1b459e = !0x1;
      var _0x19b55c = _0x1dd6bc[_0x5dba0e];
      (console["log"]("xRow", _0x19b55c),
        (_0x54d0f6 =
          _0x1dd6bc[_0x5dba0e]["getElementsByTagName"]("td")[
            _0x442148(_0x2ae46c)
          ]),
        (_0x35f7ba =
          _0x1dd6bc[_0x5dba0e + 0x1]["getElementsByTagName"]("td")[
            _0x442148(_0x2ae46c)
          ]),
        console["log"]("sortTable\x20x", _0x54d0f6),
        console["log"]("sortTable\x20y", _0x35f7ba));
      if (
        _0x54d0f6["innerHTML"]["toLowerCase"]() >
        _0x35f7ba["innerHTML"]["toLowerCase"]()
      ) {
        _0x1b459e = !0x0;
        break;
      }
    }
    _0x1b459e &&
      (_0x1dd6bc[_0x5dba0e]["parentNode"]["insertBefore"](
        _0x1dd6bc[_0x5dba0e + 0x1],
        _0x1dd6bc[_0x5dba0e],
      ),
      (_0x5420d6 = !0x0));
  }
}
function _0x2b2e50(_0x1f3e05) {
  var _0x51f1d4 = _0x1f3e05["buttonInnerText"],
    _0x378c3d = _0x1f3e05["textAreaSelector"],
    _0x3d67a9 = _0x1f3e05["valueToSet"],
    _0x368d92 = _0x1f3e05["callback"],
    _0x5a6084 = document["createElement"]("button");
  return (
    (_0x5a6084["innerText"] = _0x51f1d4),
    (_0x5a6084["onclick"] = function () {
      ((document["querySelector"](_0x378c3d)["value"] = _0x3d67a9),
        _0x368d92 && _0x368d92());
    }),
    _0x5a6084
  );
}
console["log"]("Sanitizer\x20loading");
var _0x1d6003 = new (function () {
  var _0x215280 = {
      A: !0x0,
      ABBR: !0x0,
      B: !0x0,
      BLOCKQUOTE: !0x0,
      BODY: !0x0,
      BR: !0x0,
      CENTER: !0x0,
      CODE: !0x0,
      DIV: !0x0,
      EM: !0x0,
      FONT: !0x0,
      H1: !0x0,
      H2: !0x0,
      H3: !0x0,
      H4: !0x0,
      H5: !0x0,
      H6: !0x0,
      HR: !0x0,
      I: !0x0,
      LABEL: !0x0,
      LI: !0x0,
      OL: !0x0,
      P: !0x0,
      PRE: !0x0,
      SMALL: !0x0,
      SOURCE: !0x0,
      SPAN: !0x0,
      STRONG: !0x0,
      TABLE: !0x0,
      TBODY: !0x0,
      TR: !0x0,
      TD: !0x0,
      TH: !0x0,
      THEAD: !0x0,
      UL: !0x0,
      U: !0x0,
      VIDEO: !0x0,
    },
    _0x2417f8 = { FORM: !0x0 },
    _0x491e7c = {
      align: !0x0,
      color: !0x0,
      controls: !0x0,
      height: !0x0,
      src: !0x0,
      style: !0x0,
      target: !0x0,
      title: !0x0,
      type: !0x0,
      width: !0x0,
    },
    _0x2c331f = {
      color: !0x0,
      "background-color": !0x0,
      "font-size": !0x0,
      "text-align": !0x0,
      "text-decoration": !0x0,
      "font-weight": !0x0,
    },
    _0x23656f = [""],
    _0x23d3a5 = { href: !0x0, action: !0x0 };
  this["SanitizeHtml"] = function (_0x48db1d) {
    if ("" == (_0x48db1d = _0x48db1d["trim"]())) return "";
    if ("<br>" == _0x48db1d) return "";
    var _0x51e2b6 = document["createElement"]("iframe");
    if (void 0x0 === _0x51e2b6["sandbox"])
      return (
        alert(
          "Your\x20browser\x20does\x20not\x20support\x20sandboxed\x20iframes.\x20Please\x20upgrade\x20to\x20a\x20modern\x20browser.",
        ),
        ""
      );
    ((_0x51e2b6["sandbox"] = "allow-same-origin"),
      (_0x51e2b6["style"]["display"] = "none"),
      document["body"]["appendChild"](_0x51e2b6));
    var _0x24d478 =
      _0x51e2b6["contentDocument"] || _0x51e2b6["contentWindow"]["document"];
    (null == _0x24d478["body"] && _0x24d478["write"]("<body></body>"),
      (_0x24d478["body"]["innerHTML"] = _0x48db1d));
    var _0x1c06f8 = (function _0x552d8b(_0x222c17) {
      if (_0x222c17["nodeType"] == Node["TEXT_NODE"])
        var _0xf15f69 = _0x222c17["cloneNode"](!0x0);
      else {
        if (
          _0x222c17["nodeType"] == Node["ELEMENT_NODE"] &&
          (_0x215280[_0x222c17["tagName"]] || _0x2417f8[_0x222c17["tagName"]])
        ) {
          if (
            ("SPAN" == _0x222c17["tagName"] ||
              "B" == _0x222c17["tagName"] ||
              "I" == _0x222c17["tagName"] ||
              "U" == _0x222c17["tagName"]) &&
            "" == _0x222c17["innerHTML"]["trim"]()
          )
            return document["createDocumentFragment"]();
          _0xf15f69 = _0x2417f8[_0x222c17["tagName"]]
            ? _0x24d478["createElement"]("DIV")
            : _0x24d478["createElement"](_0x222c17["tagName"]);
          for (
            var _0x585fdf = 0x0;
            _0x585fdf < _0x222c17["attributes"]["length"];
            _0x585fdf++
          ) {
            var _0x2c7fa7 = _0x222c17["attributes"][_0x585fdf];
            if (_0x491e7c[_0x2c7fa7["name"]]) {
              if ("style" == _0x2c7fa7["name"])
                for (s = 0x0; s < _0x222c17["style"]["length"]; s++) {
                  var _0xa436c5 = _0x222c17["style"][s];
                  _0x2c331f[_0xa436c5] &&
                    _0xf15f69["style"]["setProperty"](
                      _0xa436c5,
                      _0x222c17["style"]["getPropertyValue"](_0xa436c5),
                    );
                }
              else {
                if (
                  _0x23d3a5[_0x2c7fa7["name"]] &&
                  _0x2c7fa7["value"]["indexOf"](":") > -0x1 &&
                  !_0x5e20f1(_0x2c7fa7["value"], _0x23656f)
                )
                  continue;
                _0xf15f69["setAttribute"](
                  _0x2c7fa7["name"],
                  _0x2c7fa7["value"],
                );
              }
            }
          }
          for (
            _0x585fdf = 0x0;
            _0x585fdf < _0x222c17["childNodes"]["length"];
            _0x585fdf++
          ) {
            var _0x1bb00a = _0x552d8b(_0x222c17["childNodes"][_0x585fdf]);
            _0xf15f69["appendChild"](_0x1bb00a, !0x1);
          }
        } else _0xf15f69 = document["createDocumentFragment"]();
      }
      return _0xf15f69;
    })(_0x24d478["body"]);
    return (
      document["body"]["removeChild"](_0x51e2b6),
      _0x1c06f8["innerHTML"]
        ["replace"](/<br[^>]*>(\S)/g, "<br>\x0a$1")
        ["replace"](/div><div/g, "div>\x0a<div")
    );
  };
  function _0x5e20f1(_0x1acb0c, _0xfa4b87) {
    for (var _0x5e5255 = 0x0; _0x5e5255 < _0xfa4b87["length"]; _0x5e5255++)
      if (0x0 == _0x1acb0c["indexOf"](_0xfa4b87[_0x5e5255])) return !0x0;
    return !0x1;
  }
  ((this["AllowedTags"] = _0x215280),
    (this["AllowedAttributes"] = _0x491e7c),
    (this["AllowedCssStyles"] = _0x2c331f),
    (this["AllowedSchemas"] = _0x23656f));
})();
function _0x2e4ce5(_0x4fbfdd, find, _0x14b03e) {
  try {
    var _0x5436c0,
      _0x446fd7 = "",
      _0x21bfb7 = _0x4fbfdd,
      _0x235ff6 = find["toLowerCase"]();
    for (
      ;
      -0x1 !== (_0x5436c0 = _0x21bfb7["toLowerCase"]()["indexOf"](_0x235ff6));

    ) {
      ((_0x446fd7 += _0x21bfb7["substr"](0x0, _0x5436c0) + _0x14b03e),
        (_0x21bfb7 = _0x21bfb7["substr"](_0x5436c0 + find["length"])));
    }
    return _0x446fd7 + _0x21bfb7;
  } catch (_0x46f727) {
    return _0x4fbfdd;
  }
}
function _0x3d3485(_0x5859d1) {
  return _0x5859d1["charAt"](0x0)["toUpperCase"]() + _0x5859d1["slice"](0x1);
}
var _0x58adf4 = (_0x5dc1fa, _0x3b2a6a) => {
    console["log"]("test\x20waitUntilElementExists");
    var _0x11974a = document["querySelector"](_0x5dc1fa);
    console["log"]("Checking");
    if (_0x11974a) return (console["log"]("Found"), _0x3b2a6a(_0x11974a));
    setTimeout(() => _0x58adf4(_0x5dc1fa, _0x3b2a6a), 0x1f4);
  },
  _0x4d4601 = (_0x487e0c, _0x12ae8) => {
    console["log"]("test");
    var _0x47f8af = document["querySelectorAll"](_0x487e0c)[0x0];
    console["log"]("Checking");
    if (_0x47f8af) return (console["log"]("Found"), _0x12ae8(_0x47f8af));
    setTimeout(() => _0x4d4601(_0x487e0c, _0x12ae8), 0x1f4);
  };
_0x58adf4 = (_0x22331b, _0xc4cbd6) => {
  var _0x31060b = document["querySelector"](_0x22331b);
  console["log"]("Checking");
  if (_0x31060b) return (console["log"]("Found"), _0xc4cbd6(_0x31060b));
  setTimeout(() => _0x58adf4(_0x22331b, _0xc4cbd6), 0x1f4);
};
function _0x6ec189(_0x11354a, _0x700db0 = 0x32, _0x51845d = 0x64) {
  const _0xcc9412 = document["querySelector"](_0x11354a);
  !window["__" + _0x11354a] &&
    ((window["__" + _0x11354a] = 0x0),
    (window["__" + _0x11354a + "__delay"] = _0x700db0),
    (window["__" + _0x11354a + "__tries"] = _0x51845d));
  if (null === _0xcc9412) {
    if (window["__" + _0x11354a] >= window["__" + _0x11354a + "__tries"])
      return ((window["__" + _0x11354a] = 0x0), Promise["resolve"](null));
    return new Promise((_0x33306f) => {
      (window["__" + _0x11354a]++,
        setTimeout(_0x33306f, window["__" + _0x11354a + "__delay"]));
    })["then"](() => _0x6ec189(_0x11354a));
  }
  return Promise["resolve"](_0xcc9412);
}
function _0xd3b690(
  _0x2c960d = document,
  _0x42f8c3,
  _0x1879ae = 0x32,
  _0x373eaa = 0x64,
) {
  const _0x367c9a = _0x2c960d["querySelector"](_0x42f8c3);
  !window["__" + _0x42f8c3] &&
    ((window["__" + _0x42f8c3] = 0x0),
    (window["__" + _0x42f8c3 + "__delay"] = _0x1879ae),
    (window["__" + _0x42f8c3 + "__tries"] = _0x373eaa));
  if (null === _0x367c9a) {
    if (window["__" + _0x42f8c3] >= window["__" + _0x42f8c3 + "__tries"])
      return ((window["__" + _0x42f8c3] = 0x0), Promise["resolve"](null));
    return new Promise((_0x54f6af) => {
      (window["__" + _0x42f8c3]++,
        setTimeout(_0x54f6af, window["__" + _0x42f8c3 + "__delay"]));
    })["then"](() => _0x6ec189(_0x42f8c3));
  }
  return Promise["resolve"](_0x367c9a);
}
const _0x5c1af6 = { URL: "URL", BASE_64: "BASE_64" };
console["log"]("image_utils.js");
async function _0x751656(_0x5bb445) {
  if (!_0x5bb445) throw new Error("Image\x20URL\x20is\x20required");
  var _0x2990b3 = (_0x2990b3 = await _0x42671a(_0x5bb445))["b64Image"];
  return await _0x4ae3bb(_0x2990b3);
}
function _0x42671a(_0x5e6160) {
  return new Promise((_0x119051, _0x5ad5c4) => {
    chrome["runtime"]["sendMessage"](
      { type: "url-to-b64", url: _0x5e6160 },
      (_0x1e0c9b) => {
        _0x1e0c9b && _0x1e0c9b["error"]
          ? _0x5ad5c4(new Error(_0x1e0c9b["error"]))
          : _0x119051(_0x1e0c9b);
      },
    );
  });
}
const _0xbc30c9 = (_0x4b5b15, _0x1c8c55) => {
    ((trimmedString = _0x4b5b15),
      _0x4b5b15["startsWith"]("data") &&
        (trimmedString = _0x4b5b15["split"](",")[0x1]));
    const _0x45462f = atob(trimmedString),
      _0x1a62b9 = new ArrayBuffer(_0x45462f["length"]),
      _0x8d3ad0 = new Uint8Array(_0x1a62b9);
    for (let _0x598048 = 0x0; _0x598048 < _0x45462f["length"]; _0x598048++)
      _0x8d3ad0[_0x598048] = _0x45462f["charCodeAt"](_0x598048);
    const _0x3bc79f = new Blob([_0x1a62b9], { type: "image/jpeg" });
    return new File([_0x3bc79f], _0x1c8c55, {
      lastModified: new Date()["getTime"](),
      type: "image/jpeg",
    });
  },
  _0x124b7b = (_0x2d1509, _0x2a41c6) => {
    const _0x20fc6a = new DataTransfer();
    (_0x20fc6a["items"]["add"](_0x2d1509),
      (_0x2a41c6["files"] = _0x20fc6a["files"]));
    const _0x1131ee = new Event("change", { bubbles: !0x0 });
    _0x2a41c6["dispatchEvent"](_0x1131ee);
  };
var _0x35a146 = async (_0x17cb1f, _0x2daeda, _0x169ba5, _0x59dedc) => {
  let _0x46e0b8;
  if (_0x59dedc == _0x5c1af6["URL"]) {
    const { b64Image: _0x211baf } = await _0x42671a(_0x17cb1f);
    _0x46e0b8 = _0xbc30c9(_0x211baf, _0x169ba5);
  }
  _0x59dedc == _0x5c1af6["BASE_64"] &&
    (_0x46e0b8 = _0xbc30c9(_0x17cb1f, _0x169ba5));
  var _0x227926 = document["querySelector"](_0x2daeda);
  _0x124b7b(_0x46e0b8, _0x227926);
};
async function _0x2af591(
  _0x5cd155,
  _0x3d286e,
  _0x38b09e,
  _0x22f6de,
  _0x5e1f0d,
  _0x13e025,
  _0x28631a,
  _0x3e1516,
) {
  var _0x10fb1a = await _0x751656(_0x5cd155);
  _0x10fb1a = await _0x960017(_0x10fb1a, _0x5e1f0d, _0x13e025);
  var _0x5c3e89 = await _0x751656(_0x38b09e);
  ((_0x5c3e89 = await _0x960017(_0x5c3e89, 0.45 * _0x13e025, 0.45 * _0x5e1f0d)),
    (_0x10fb1a = await _0x470a52(_0x10fb1a, _0x5c3e89, 0.75)));
  var _0x50e347 = await _0x751656(_0x3d286e);
  return (
    (_0x50e347 = await _0x960017(
      _0x50e347,
      0.45 * _0x13e025,
      0.45 * _0x5e1f0d,
    )),
    await _0x4cfd71(_0x10fb1a, _0x50e347, 0.95)
  );
}
async function _0x2164e8(
  _0x37c093,
  _0x4c76c9,
  _0x17b1be,
  _0x343005,
  _0x1c0c71,
  _0x1959e9,
  _0x49eb1c,
) {
  var _0x2f4076 = await _0x751656(_0x37c093);
  _0x2f4076 = await _0xf69a72(_0x2f4076, _0x343005, _0x1c0c71);
  var _0x2f294f = await _0x751656(_0x4c76c9);
  return (
    (_0x2f294f = await _0xf69a72(
      _0x2f294f,
      0.45 * _0x1c0c71,
      0.45 * _0x343005,
    )),
    (_0x2f4076 = await _0x1d9f9b(_0x2f4076, _0x2f294f, "right")),
    (_0x2f294f = await _0xf69a72(_0x2f294f, 0.4 * _0x1c0c71, 0.4 * _0x343005)),
    await _0x3b79fc(_0x2f4076, _0x2f294f, 0.7, _0x4c76c9)
  );
}
async function _0x569b3f(_0x2001ed) {
  var _0x111103 = _0x2001ed["imageSource"],
    _0x388820 = _0x2001ed["waterMarkUrl"],
    _0x35c6b5 = await _0x751656(_0x111103);
  ((_0x35c6b5 = await _0x40ffa2(_0x35c6b5)),
    (_0x35c6b5 = await _0x59fc80(_0x35c6b5)));
  var _0x983534 = await _0x751656(_0x388820);
  return (
    (_0x983534 = await _0xf69a72(
      _0x983534,
      0.2 * _0x35c6b5["height"],
      0.2 * _0x35c6b5["width"],
    )),
    (_0x983534 = await _0x40ffa2(_0x983534)),
    (_0x983534 = await _0x59fc80(_0x983534)),
    (_0x35c6b5 = await _0x1d9f9b(_0x35c6b5, _0x983534, "right")),
    (_0x35c6b5 = await _0x3b79fc(_0x35c6b5, _0x983534, 0.7))["width"] >
    _0x35c6b5["height"]
      ? (_0x35c6b5 = await _0x4d1ca7({
          imageObject: _0x35c6b5,
          padding: _0x35c6b5["width"] - _0x35c6b5["height"],
          paddingDirection: "height",
        }))
      : (_0x35c6b5["width"] < _0x35c6b5["height"] ||
          _0x35c6b5["width"] == _0x35c6b5["height"]) &&
        (_0x35c6b5 = await _0x4d1ca7({
          imageObject: _0x35c6b5,
          padding: _0x35c6b5["height"] - _0x35c6b5["width"],
          paddingDirection: "width",
        })),
    _0x35c6b5
  );
}
async function _0x461cf2(_0x182b6f, _0x2b22ed = "Look", _0xfa0fe3 = "Inside") {
  var _0x257241 = _0x182b6f["imageSource"],
    _0x5a3c0a = _0x182b6f["waterMarkUrl"],
    _0x2fb296 = await _0x751656(_0x257241);
  ((_0x2fb296 = await _0x40ffa2(_0x2fb296)),
    (_0x2fb296 = await _0x59fc80(_0x2fb296)));
  var _0x4e7df5 = await _0x751656(_0x5a3c0a);
  ((_0x4e7df5 = await _0xf69a72(
    _0x4e7df5,
    0.2 * _0x2fb296["height"],
    0.2 * _0x2fb296["width"],
  )),
    (_0x4e7df5 = await _0x40ffa2(_0x4e7df5)),
    (_0x4e7df5 = await _0x59fc80(_0x4e7df5)));
  var _0x2f0c62 = getProductDescriptionAndFeatures(),
    _0x19cd9b = getFilteredTitle() + "\x0a\x0a" + _0x2f0c62,
    _0x10c524 = await _0x1d68fc(
      "http://1.1.1.66:1102/api/ItemSpecifics/GetBuyerIntent",
      { request_type: "get_buyer_intent", productDescription: _0x19cd9b },
    );
  console["log"]("twoWordBuyerIntent", _0x10c524);
  var _0x430428 = _0x10c524["split"]("\x20");
  _0x2b22ed = _0x430428[0x0];
  for (var _0x8285a2 = 0x1; _0x8285a2 < _0x430428["length"]; _0x8285a2++)
    _0xfa0fe3 += "\x20" + _0x430428[_0x8285a2];
  return (
    (_0xfa0fe3 = _0xfa0fe3["trim"]()),
    (_0x2b22ed = _0x2b22ed["trim"]()),
    (_0x2fb296 = await _0x5bf060(_0x2fb296, _0x2b22ed, _0xfa0fe3)),
    (_0x2fb296 = await _0x1d9f9b(_0x2fb296, _0x4e7df5, "right")),
    (_0x2fb296 = await _0x242a71(_0x2fb296)),
    await _0x3b79fc(_0x2fb296, _0x4e7df5, 0.7)
  );
}
async function _0x11a0bc(_0x320789) {
  var _0x28c7cf = _0x320789["imageSource"],
    _0x1e0a71 = _0x320789["waterMarkUrl"],
    _0xfe5de1 = await _0x751656(_0x28c7cf);
  ((_0xfe5de1 = await _0x40ffa2(_0xfe5de1)),
    (_0xfe5de1 = await _0x59fc80(_0xfe5de1)));
  var _0x536d00 = await _0x751656(_0x1e0a71);
  return (
    (_0x536d00 = await _0xf69a72(
      _0x536d00,
      0.2 * _0xfe5de1["height"],
      0.2 * _0xfe5de1["width"],
    )),
    (_0x536d00 = await _0x40ffa2(_0x536d00)),
    (_0x536d00 = await _0x59fc80(_0x536d00)),
    (_0xfe5de1 = await _0x1d9f9b(_0xfe5de1, _0x536d00, "right")),
    (_0xfe5de1 = await _0x242a71(_0xfe5de1)),
    (_0xfe5de1 = await _0x3b79fc(_0xfe5de1, _0x536d00, 0.7)),
    await _0x561892(_0xfe5de1, 0x1f4, 0x1f4)
  );
}
function _0x45d53c(_0x44c044) {
  ((imgWidth = _0x44c044["width"]), (imgHeight = _0x44c044["height"]));
  var _0x4e2add = document["createElement"]("canvas");
  (_0x4e2add["setAttribute"]("width", imgWidth),
    _0x4e2add["setAttribute"]("height", imgHeight));
  var _0x3957c0 = _0x4e2add["getContext"]("2d");
  _0x3957c0["drawImage"](_0x44c044, 0x0, 0x0);
  var _0x51df9e = _0x3957c0["getImageData"](0x0, 0x0, imgWidth, imgHeight)[
      "data"
    ],
    _0x14abe9 = function (_0x216258, _0x3761bc) {
      var _0x4492ee = imgWidth * _0x3761bc + _0x216258;
      return {
        red: _0x51df9e[0x4 * _0x4492ee],
        green: _0x51df9e[0x4 * _0x4492ee + 0x1],
        blue: _0x51df9e[0x4 * _0x4492ee + 0x2],
        opacity: _0x51df9e[0x4 * _0x4492ee + 0x3],
      };
    },
    _0x2b777e = function (_0x140d90) {
      return (
        _0x140d90["red"] > 0xc8 &&
        _0x140d90["green"] > 0xc8 &&
        _0x140d90["blue"] > 0xc8
      );
    },
    _0x3b8a1d = function (_0x7278a) {
      var _0x5a840a = _0x7278a ? 0x1 : -0x1;
      for (
        var _0x50acab = _0x7278a ? 0x0 : imgHeight - 0x1;
        _0x7278a ? _0x50acab < imgHeight : _0x50acab > -0x1;
        _0x50acab += _0x5a840a
      )
        for (var _0x5ba07a = 0x0; _0x5ba07a < imgWidth; _0x5ba07a++) {
          var _0x381b53 = _0x14abe9(_0x5ba07a, _0x50acab);
          if (!_0x2b777e(_0x381b53))
            return _0x7278a
              ? _0x50acab
              : Math["min"](_0x50acab + 0x1, imgHeight);
        }
      return null;
    },
    _0x46850e = function (_0x951aee) {
      var _0x4dfe54 = _0x951aee ? 0x1 : -0x1;
      for (
        var _0x47719b = _0x951aee ? 0x0 : imgWidth - 0x1;
        _0x951aee ? _0x47719b < imgWidth : _0x47719b > -0x1;
        _0x47719b += _0x4dfe54
      )
        for (var _0x34d517 = 0x0; _0x34d517 < imgHeight; _0x34d517++) {
          var _0x3b8af0 = _0x14abe9(_0x47719b, _0x34d517);
          if (!_0x2b777e(_0x3b8af0))
            return _0x951aee
              ? _0x47719b
              : Math["min"](_0x47719b + 0x1, imgWidth);
        }
      return null;
    },
    _0x5d3cdf = _0x3b8a1d(!0x0),
    _0x18018f = _0x3b8a1d(!0x1),
    _0x319ca0 = _0x46850e(!0x0),
    _0x5661db = _0x46850e(!0x1) - _0x319ca0,
    _0x252f21 = _0x18018f - _0x5d3cdf;
  return (
    _0x4e2add["setAttribute"]("width", _0x5661db),
    _0x4e2add["setAttribute"]("height", _0x252f21),
    _0x4e2add["getContext"]("2d")["drawImage"](
      _0x44c044,
      _0x319ca0,
      _0x5d3cdf,
      _0x5661db,
      _0x252f21,
      0x0,
      0x0,
      _0x5661db,
      _0x252f21,
    ),
    _0x4e2add["toDataURL"]()
  );
}
async function _0x43545f(_0x4b060b) {
  var _0x547bc3 = _0x4b060b["imageSource"],
    _0x3ee8e7 = await _0x751656(_0x547bc3);
  ((_0x3ee8e7 = await _0x4d1ca7({
    imageObject: _0x3ee8e7,
    padding: _0x3ee8e7["width"] - _0x3ee8e7["height"],
    paddingDirection: "height",
  })),
    (_0x3ee8e7 = await _0x352871(_0x3ee8e7, "black", "30px")),
    document["body"]["prepend"](_0x3ee8e7));
}
function _0x4d1ca7(_0x24359d) {
  return new Promise((_0x22c74c, _0x55e42f) => {
    var _0x52fc28 = _0x24359d["imageObject"],
      _0x4ed59d = _0x24359d["padding"],
      _0x283066 = _0x24359d["paddingDirection"] || "all",
      _0x2cd8b8 = document["createElement"]("canvas");
    _0x2cd8b8["id"] = "myCanvas";
    var _0x225963 = _0x2cd8b8["getContext"]("2d");
    "all" == _0x283066 &&
      ((_0x2cd8b8["width"] = _0x52fc28["width"] + _0x4ed59d),
      (_0x2cd8b8["height"] = _0x52fc28["height"] + _0x4ed59d),
      (_0x225963["fillStyle"] = "white"),
      _0x225963["fillRect"](0x0, 0x0, _0x2cd8b8["width"], _0x2cd8b8["height"]),
      _0x225963["drawImage"](_0x52fc28, _0x4ed59d / 0x2, _0x4ed59d / 0x2));
    "height" == _0x283066 &&
      ((_0x2cd8b8["width"] = _0x52fc28["width"]),
      (_0x2cd8b8["height"] = _0x52fc28["height"] + _0x4ed59d),
      (_0x225963["fillStyle"] = "white"),
      _0x225963["fillRect"](0x0, 0x0, _0x2cd8b8["width"], _0x2cd8b8["height"]),
      _0x225963["drawImage"](_0x52fc28, 0x0, _0x4ed59d / 0x2));
    "width" == _0x283066 &&
      ((_0x2cd8b8["width"] = _0x52fc28["width"] + _0x4ed59d),
      (_0x2cd8b8["height"] = _0x52fc28["height"]),
      (_0x225963["fillStyle"] = "white"),
      _0x225963["fillRect"](0x0, 0x0, _0x2cd8b8["width"], _0x2cd8b8["height"]),
      _0x225963["drawImage"](_0x52fc28, _0x4ed59d / 0x2, 0x0));
    var _0x2d51fc = new Image();
    ((_0x2d51fc["onload"] = function () {
      _0x22c74c(_0x2d51fc);
    }),
      (_0x2d51fc["src"] = _0x2cd8b8["toDataURL"]()));
  });
}
async function _0x219206(
  _0x5a3806,
  _0x30fac4,
  _0x3b93ff,
  _0x20a706,
  _0x16b7da,
  _0x23a6b1,
  _0x5f0729,
  _0xc770c9,
) {
  var _0x10df57 = await _0x751656(_0x5a3806);
  ((_0x10df57 = await _0xf69a72(_0x10df57, _0x16b7da, _0x23a6b1)),
    (_0x10df57 = await _0x40ffa2(_0x10df57)));
  var _0x57ed20 = await _0x751656(_0x3b93ff);
  ((_0x57ed20 = await _0x40ffa2(_0x57ed20)),
    (_0x57ed20 = await _0xf69a72(
      _0x57ed20,
      0.45 * _0x23a6b1,
      0.45 * _0x16b7da,
    )));
  var _0x10b77f = await _0x751656(_0x30fac4);
  return (
    (_0x10b77f = await _0xf69a72(
      _0x10b77f,
      0.45 * _0x23a6b1,
      0.45 * _0x16b7da,
    )),
    (_0x10df57 = await _0x1d9f9b(_0x10df57, _0x10b77f, "right")),
    (_0x10b77f = await _0xf69a72(_0x10b77f, 0.4 * _0x16b7da, 0.4 * _0x23a6b1)),
    (_0x10df57 = await _0x267114(_0x10df57, _0x10b77f, 0x1, 0xc)),
    (_0x57ed20 = await _0x2cf69d(
      _0x57ed20,
      0.65 * _0x10b77f["width"],
      0.65 * _0x10b77f["height"],
    )),
    (_0x57ed20 = await _0x59fc80(_0x57ed20)),
    (_0x10df57 = await _0x3b79fc(_0x10df57, _0x57ed20, 0.7)),
    (_0x10df57 = await _0x242a71(_0x10df57)),
    await _0x561892(_0x10df57, 0x1f4, 0x1f4)
  );
}
async function _0x5ca1e7(
  _0x4cdb30,
  _0x37e885,
  _0x23d683,
  _0xa7791d,
  _0x40443c,
  _0x104256,
  _0x1f41d7,
  _0x3fa189,
) {
  var _0x16887e = await _0x751656(_0x4cdb30);
  ((_0x16887e = await _0xf69a72(_0x16887e, _0x40443c, _0x104256)),
    (_0x16887e = await _0x40ffa2(_0x16887e)));
  var _0xf39567 = await _0x751656(_0x23d683);
  ((_0xf39567 = await _0xf69a72(_0xf39567, 0.45 * _0x104256, 0.45 * _0x40443c)),
    (waterMarkImg = await _0x40ffa2(_0xf39567)),
    (waterMarkImg = await _0x59fc80(_0xf39567)));
  var _0x16f550 = await _0x751656(_0x37e885);
  return (
    (_0x16f550 = await _0xf69a72(
      _0x16f550,
      0.45 * _0x104256,
      0.45 * _0x40443c,
    )),
    (_0x16887e = await _0x1d9f9b(_0x16887e, _0x16f550, "right")),
    (_0xf39567 = await _0x2cf69d(
      _0xf39567,
      0.65 * _0x16f550["width"],
      0.65 * _0x16f550["height"],
    )),
    (_0xf39567 = await _0x59fc80(_0xf39567)),
    (_0x16887e = await _0x3b79fc(_0x16887e, _0xf39567, 0.7)),
    (_0x16887e = await _0x242a71(_0x16887e)),
    (_0x16f550 = await _0xf69a72(_0x16f550, 0.4 * _0x40443c, 0.4 * _0x104256)),
    (_0x16887e = await _0x267114(_0x16887e, _0x16f550, 0x1, 0xc)),
    await _0x561892(_0x16887e, 0x1f4, 0x1f4)
  );
}
async function _0x27a412(
  _0x1d2038,
  _0xcea2a6,
  _0xb59a8f,
  _0x4845eb,
  _0x123d4f,
  _0x5e845e,
  _0x4ee97b,
  _0x4e3a29,
) {
  var _0x2167b0 = await _0x751656(_0x1d2038);
  ((_0x2167b0 = await _0xf69a72(_0x2167b0, _0x123d4f, _0x5e845e)),
    (_0x2167b0 = await _0x40ffa2(_0x2167b0)));
  var _0x380589 = await _0x751656(_0xb59a8f);
  ((_0x380589 = await _0xf69a72(_0x380589, 0.45 * _0x5e845e, 0.45 * _0x123d4f)),
    (waterMarkImg = await _0x40ffa2(_0x380589)),
    (waterMarkImg = await _0x59fc80(_0x380589)));
  var _0x49d418 = await _0x751656(_0xcea2a6);
  return (
    (_0x49d418 = await _0xf69a72(
      _0x49d418,
      0.45 * _0x5e845e,
      0.45 * _0x123d4f,
    )),
    (_0x2167b0 = await _0x1d9f9b(_0x2167b0, _0x49d418, "right")),
    (_0x2167b0 = await _0x242a71(_0x2167b0)),
    (_0x380589 = await _0x2cf69d(
      _0x380589,
      0.65 * _0x49d418["width"],
      0.65 * _0x49d418["height"],
    )),
    (_0x380589 = await _0x59fc80(_0x380589)),
    (_0x2167b0 = await _0x3b79fc(_0x2167b0, _0x380589, 0.7)),
    (_0x49d418 = await _0xf69a72(_0x49d418, 0.4 * _0x123d4f, 0.4 * _0x5e845e)),
    (_0x2167b0 = await _0x267114(_0x2167b0, _0x49d418, 0x1, 0xc)),
    (_0x2167b0 = await _0x266c8f(_0x2167b0)),
    (_0x2167b0 = await _0x450fc3(_0x2167b0)),
    await _0x561892(_0x2167b0, 0x1f4, 0x1f4)
  );
}
function _0x2dc99d(_0x424a5e, _0x513ee9, _0x3c68d6) {
  return new Promise(async (_0x33f405, _0x4cc055) => {
    let _0x202bfd = document["createElement"]("canvas");
    ((_0x202bfd["width"] = _0x424a5e["width"]),
      (_0x202bfd["height"] = _0x424a5e["height"]));
    let _0x2ed2cd = _0x202bfd["getContext"]("2d");
    ((_0x2ed2cd["fillStyle"] = _0x3c68d6),
      _0x2ed2cd["fillRect"](0x0, 0x0, _0x202bfd["width"], _0x202bfd["height"]),
      _0x2ed2cd["drawImage"](
        _0x424a5e,
        0x0,
        0x0,
        _0x424a5e["width"],
        _0x424a5e["height"],
      ));
    var _0x27faa4 = new Image();
    ((_0x27faa4["onload"] = function () {
      _0x33f405(_0x27faa4);
    }),
      (_0x27faa4["src"] = _0x202bfd["toDataURL"]()));
  });
}
async function _0x54f109(
  _0x328d3f,
  _0x258788,
  _0x5437f2,
  _0x2e9f61,
  _0x5bb300,
  _0x4636bb,
  _0x3001ca,
  _0x256fb8,
) {
  var _0x20e59a = await _0x751656(_0x328d3f);
  ((_0x20e59a = await _0xf69a72(_0x20e59a, _0x5bb300, _0x4636bb)),
    (_0x20e59a = await _0x40ffa2(_0x20e59a)));
  var _0x1f5e29 = await _0x751656(_0x5437f2);
  _0x1f5e29 = await _0xf69a72(_0x1f5e29, 0.45 * _0x4636bb, 0.45 * _0x5bb300);
  var _0x35039b = await _0x751656(_0x258788);
  return (
    (_0x35039b = await _0xf69a72(
      _0x35039b,
      0.45 * _0x4636bb,
      0.45 * _0x5bb300,
    )),
    (_0x35039b = await _0x59fc80(_0x35039b)),
    (_0x35039b = await _0x2dc99d(_0x35039b, _0x258788, "beige")),
    (_0x20e59a = await _0x1d9f9b(_0x20e59a, _0x35039b, "right")),
    (_0x35039b = await _0xf69a72(_0x35039b, 0.4 * _0x5bb300, 0.4 * _0x4636bb)),
    (_0x20e59a = await _0x267114(_0x20e59a, _0x35039b, 0x1, 0xc)),
    (_0x1f5e29 = await _0x40ffa2(_0x1f5e29)),
    (_0x1f5e29 = await _0x2cf69d(
      _0x1f5e29,
      _0x35039b["width"],
      _0x35039b["height"],
    )),
    (_0x1f5e29 = await _0x59fc80(_0x1f5e29)),
    (_0x20e59a = await _0x3b79fc(_0x20e59a, _0x1f5e29, 0.7, _0x5437f2)),
    (_0x20e59a = await _0x242a71(_0x20e59a)),
    (_0x20e59a = await _0x266c8f(_0x20e59a)),
    (_0x20e59a = await _0x450fc3(_0x20e59a)),
    await _0x561892(_0x20e59a, 0x1f4, 0x1f4)
  );
}
async function _0x28be60(
  _0x20ee13,
  _0x182091,
  _0x41ef90,
  _0x28f721,
  _0x5587ee,
  _0x17fb20,
  _0x34feda,
  _0x33ea78,
  _0x1c49cb,
  _0x1a6f80,
) {
  var _0x4e861d = await _0x751656(_0x20ee13);
  _0x4e861d = await _0x960017(_0x4e861d, _0x34feda, _0x33ea78);
  var _0x46ce5b = await _0x751656(_0x41ef90);
  _0x46ce5b = await _0xf69a72(_0x46ce5b, 0.45 * _0x33ea78, 0.45 * _0x34feda);
  var _0x1ec0eb = await _0x751656(_0x182091);
  ((_0x1ec0eb = await _0xf69a72(_0x1ec0eb, 0.45 * _0x33ea78, 0.45 * _0x34feda)),
    (_0x4e861d = await _0x1d9f9b(_0x4e861d, _0x1ec0eb, "right")),
    (_0x1ec0eb = await _0xf69a72(_0x1ec0eb, 0.4 * _0x33ea78, 0.4 * _0x34feda)),
    (_0x46ce5b = await _0xf69a72(_0x46ce5b, 0.4 * _0x33ea78, 0.4 * _0x34feda)),
    (_0x4e861d = await _0x267114(_0x4e861d, _0x1ec0eb, 0x1, 0xc)),
    (_0x46ce5b = await _0x59fc80(_0x46ce5b)),
    (_0x4e861d = await _0x3b79fc(_0x4e861d, _0x46ce5b, 0.7)));
  var _0x460c9e = await _0x751656(_0x28f721);
  ((_0x460c9e = await _0x419c01(_0x460c9e)),
    (_0x460c9e = await _0xf69a72(
      _0x460c9e,
      0.45 * _0x33ea78,
      0.45 * _0x34feda,
    )));
  var _0x5b7ac4 = await _0x751656(_0x5587ee);
  _0x5b7ac4 = await _0x419c01(_0x5b7ac4);
  if (
    (_0x5b7ac4 = await _0xf69a72(
      _0x5b7ac4,
      0.45 * _0x33ea78,
      0.45 * _0x34feda,
    ))["width"] >= _0x460c9e["width"]
  )
    ((_0x4e861d = await _0x1d9f9b(_0x4e861d, _0x5b7ac4, "left")),
      (_0x5b7ac4 = await _0xf69a72(
        _0x5b7ac4,
        0.4 * _0x33ea78,
        0.4 * _0x34feda,
      )),
      (_0x460c9e = await _0xf69a72(
        _0x460c9e,
        0.4 * _0x33ea78,
        0.4 * _0x34feda,
      )),
      (_0x4e861d = await _0x1d6c45(_0x4e861d, _0x5b7ac4, 0x1, 0xc)),
      (_0x4e861d = await _0x599c15(_0x4e861d, _0x460c9e, 0x1)));
  else
    _0x460c9e["width"] > _0x5b7ac4["width"] &&
      ((_0x4e861d = await _0x1d9f9b(_0x4e861d, _0x460c9e, "left")),
      (_0x5b7ac4 = await _0xf69a72(
        _0x5b7ac4,
        0.4 * _0x33ea78,
        0.4 * _0x34feda,
      )),
      (_0x460c9e = await _0xf69a72(
        _0x460c9e,
        0.4 * _0x33ea78,
        0.4 * _0x34feda,
      )),
      (_0x4e861d = await _0x599c15(_0x4e861d, _0x460c9e, 0x1)),
      (_0x4e861d = await _0x1d6c45(_0x4e861d, _0x5b7ac4, 0x1, 0xc)));
  return await _0x561892(_0x4e861d, 0x1f4, 0x1f4);
}
function _0x352871(_0x202648, _0xf4b12b, _0x215690) {
  return new Promise((_0x44db68, _0x12eb34) => {
    var _0x2a7d7c = document["createElement"]("canvas");
    ((_0x2a7d7c["width"] = _0x202648["width"]),
      (_0x2a7d7c["height"] = _0x202648["height"]));
    var _0xbdfe36 = _0x2a7d7c["getContext"]("2d");
    (_0xbdfe36["drawImage"](_0x202648, 0x0, 0x0),
      (_0xbdfe36["strokeStyle"] = _0xf4b12b),
      (_0xbdfe36["lineWidth"] = _0x215690),
      _0xbdfe36["strokeRect"](
        0x0,
        0x0,
        _0x2a7d7c["width"],
        _0x2a7d7c["height"],
      ));
    var _0x446656 = new Image();
    ((_0x446656["onload"] = function () {
      _0x44db68(_0x446656);
    }),
      (_0x446656["src"] = _0x2a7d7c["toDataURL"]()));
  });
}
async function _0x583d68(
  _0x46fd48,
  _0x1681f0,
  _0x4a55ce,
  _0x203c1a,
  _0xd55322,
  _0x5f5aef,
  _0x22667b,
) {
  var _0x3e97c2 = await _0x751656(_0x46fd48);
  _0x3e97c2 = await _0x960017(_0x3e97c2, _0x203c1a, _0xd55322);
  var _0x418062 = await _0x751656(
    "https://centreforinquiry.ca/wp-content/uploads/2020/05/68353859-canadian-map-with-canada-flag.jpg",
  );
  ((_0x418062 = await _0x960017(_0x418062, 0.45 * _0xd55322, 0.45 * _0x203c1a)),
    (_0x3e97c2 = await _0x470a52(_0x3e97c2, _0x418062, 0.75)));
  var _0x44a3d0 = await _0x751656(_0x1681f0);
  return (
    (_0x44a3d0 = await _0x419c01(_0x44a3d0)),
    (_0x44a3d0 = await _0x1c3a5c(_0x44a3d0)),
    (_0x44a3d0 = await _0x5221f5(_0x44a3d0, 0xa)),
    (_0x44a3d0 = await _0x960017(
      _0x44a3d0,
      0.45 * _0xd55322,
      0.45 * _0x203c1a,
    )),
    (_0x3e97c2 = await _0x4cfd71(_0x3e97c2, _0x44a3d0, 0.95)),
    (_0x3e97c2 = await _0x478d74(_0x3e97c2, _0x4a55ce, _0x5f5aef, _0x22667b)),
    await _0x419c01(_0x3e97c2)
  );
}
function _0x419c01(_0x58ccd9) {
  return new Promise(function (_0x3a80e0, _0x55f4c3) {
    let _0x437117 = document["createElement"]("canvas");
    ((_0x437117["width"] = _0x58ccd9["width"]),
      (_0x437117["height"] = _0x58ccd9["height"]));
    let _0x2885ee = _0x437117["getContext"]("2d");
    ((_0x2885ee["fillStyle"] = "white"),
      _0x2885ee["fillRect"](0x0, 0x0, _0x437117["width"], _0x437117["height"]),
      _0x2885ee["drawImage"](
        _0x58ccd9,
        0x0,
        0x0,
        _0x437117["width"],
        _0x437117["height"],
      ),
      (_0x2885ee["strokeStyle"] = "black"),
      (_0x2885ee["lineWidth"] = 0x1e),
      _0x2885ee["strokeRect"](
        0x0,
        0x0,
        _0x437117["width"],
        _0x437117["height"],
      ));
    var _0x8048c9 = new Image();
    ((_0x8048c9["onload"] = function () {
      _0x3a80e0(_0x8048c9);
    }),
      (_0x8048c9["src"] = _0x437117["toDataURL"]()));
  });
}
function _0x4cfd71(_0x507ae4, _0x1a8fd4, _0x18b43d) {
  return new Promise(function (_0x1b24ba, _0x13e80d) {
    let _0x3fa2f7 = document["createElement"]("canvas");
    ((_0x3fa2f7["width"] = _0x507ae4["width"]),
      (_0x3fa2f7["height"] = _0x507ae4["height"]));
    let _0x242ac2 = _0x3fa2f7["getContext"]("2d");
    ((_0x242ac2["fillStyle"] = "white"),
      _0x242ac2["fillRect"](0x0, 0x0, _0x3fa2f7["width"], _0x3fa2f7["height"]),
      _0x242ac2["drawImage"](_0x507ae4, 0x0, 0x0),
      (_0x242ac2["globalAlpha"] = _0x18b43d));
    var _0x12b569 =
        _0x3fa2f7["width"] - _0x1a8fd4["width"] - _0x3fa2f7["width"] / 0x32,
      _0x556fb5 =
        _0x3fa2f7["height"] - _0x1a8fd4["height"] - _0x3fa2f7["height"] / 0xc;
    _0x242ac2["drawImage"](_0x1a8fd4, _0x12b569, _0x556fb5);
    var _0x4b95c5 = new Image();
    ((_0x4b95c5["onload"] = function () {
      _0x1b24ba(_0x4b95c5);
    }),
      (_0x4b95c5["src"] = _0x3fa2f7["toDataURL"]()));
  });
}
async function _0x3878bc(
  _0x5dc071,
  _0x2acf50,
  _0x452e4b,
  _0x1b21c3,
  _0xf60d72,
) {
  var _0x12b56a = localStorage["getItem"]("waterMarkUrl"),
    _0x22a946 = await _0x751656(_0x5dc071);
  _0x22a946 = await _0x960017(_0x22a946, _0x1b21c3, _0xf60d72);
  var _0x40f0dc = await _0x751656(_0x12b56a);
  ((_0x40f0dc = await _0x960017(_0x40f0dc, 0.4 * _0xf60d72, 0.4 * _0x1b21c3)),
    (_0x22a946 = await _0x470a52(_0x22a946, _0x40f0dc, 0.75)),
    (_0x22a946 = await _0x478d74(_0x22a946, _0x2acf50)),
    upload(_0x22a946["src"], _0x2acf50, _0x452e4b));
}
async function _0x5eeee3(
  _0x3557c5,
  _0x2f1705,
  _0x1e3f2c,
  _0x388a17,
  _0x4e205a,
) {
  localStorage["getItem"]("waterMarkUrl");
  var _0x259108 = await _0x751656(_0x3557c5);
  ((_0x259108 = await _0x5221f5(_0x259108, 0x0)),
    (_0x259108 = await _0x960017(_0x259108, _0x388a17, _0x4e205a)),
    upload(_0x259108["src"], _0x2f1705, _0x1e3f2c));
}
function _0x5719a7(_0x5a63b4) {
  var _0x5c1acc = document["createElement"]("img");
  ((_0x5c1acc["src"] = _0x5a63b4),
    document["getElementsByTagName"]("html")[0x0]["appendChild"](_0x5c1acc));
}
function _0x37f51d(_0x5ae656) {
  return new Promise(function (_0x3a60b2, _0x13e14d) {
    var _0x4396cd = new Image();
    ((_0x4396cd["src"] = _0x5ae656),
      (_0x4396cd["crossOrigin"] = "anonymous"),
      (_0x4396cd["onload"] = function () {
        _0x3a60b2(_0x4396cd);
      }));
  });
}
async function _0x478d74(_0x1dfdd3, _0x2373c7, _0x2f5347, _0x11e91e) {
  var _0x56ef43 = await _0x392393(_0x1dfdd3, _0x2373c7, _0x2f5347, _0x11e91e);
  return await _0x21bd2e(_0x1dfdd3, _0x2373c7, _0x56ef43, _0x2f5347, _0x11e91e);
}
function _0x21bd2e(_0x3ace32, _0xd3c9ed, _0x331f2c, _0xc9851e, _0x3ed6dd) {
  return new Promise(function (_0x2579b8, _0x292c11) {
    var _0x569da5 = document["createElement"]("canvas");
    _0x569da5["id"] = "myCanvas";
    var _0x385554 = (_0x3ace32["height"] / 0xa) * 0.45,
      _0x1d75ef = _0x385554 + _0x385554 / 0x2,
      _0x57a98a = _0x385554;
    ((_0x569da5["width"] = _0x3ace32["width"]),
      (_0x569da5["height"] = _0x3ace32["height"] + _0x1d75ef * _0x331f2c));
    var _0x2272cc = _0x569da5["getContext"]("2d");
    ((_0x2272cc["fillStyle"] = "white"),
      _0x2272cc["fillRect"](0x0, 0x0, _0x569da5["width"], _0x569da5["height"]));
    var _0x3bc02c = _0x569da5["width"],
      _0x465a66 = _0x569da5["height"] * (0x46 / 0x5dc);
    ((_0x2272cc["fillStyle"] = _0xc9851e),
      (_0x2272cc["font"] = _0x385554 + "px\x20" + _0x3ed6dd),
      _0x525e55(_0x2272cc, _0xd3c9ed, 0x0, _0x57a98a, _0x3bc02c, _0x465a66),
      _0x2272cc["drawImage"](_0x3ace32, 0x0, _0x1d75ef * _0x331f2c));
    let _0x5f06f2 = new Image();
    ((_0x5f06f2["crossOrigin"] = "anonymous"),
      (_0x5f06f2["src"] = _0x569da5["toDataURL"]()),
      (_0x5f06f2["onload"] = function () {
        _0x2579b8(_0x5f06f2);
      }));
  });
}
function _0x5ba1df(_0x13fa14) {
  var _0x5d6fd7 = (_0x13fa14["height"] / 0xa) * 1.5,
    _0x754520 = _0x5d6fd7 + _0x5d6fd7 / 0x2,
    _0x307693 = _0x5d6fd7;
  return new Promise(function (_0x44a18e, _0x2bd336) {
    var _0x2f0946 = document["createElement"]("canvas");
    ((_0x2f0946["id"] = "myCanvas"),
      (_0x2f0946["width"] = _0x13fa14["width"]),
      (_0x2f0946["height"] = _0x13fa14["height"] + 0x1 * _0x754520));
    var _0x37b884 = _0x2f0946["getContext"]("2d");
    ((_0x37b884["fillStyle"] = "white"),
      _0x37b884["fillRect"](0x0, 0x0, _0x2f0946["width"], _0x2f0946["height"]),
      _0x2f0946["width"],
      (_0x37b884["fillStyle"] = "#F79148"),
      (_0x37b884["font"] = "bold\x20" + _0x5d6fd7 + "px\x20Arial"),
      _0x37b884["fillText"]("Look\x20", 0x0, _0x307693));
    var _0x11b510 = _0x37b884["measureText"]("Look\x20")["width"];
    ((_0x37b884["fillStyle"] = "#34B8FF"),
      (_0x37b884["font"] = "bold\x20" + _0x5d6fd7 + "px\x20Arial"),
      _0x37b884["fillText"]("Inside\x20⤸", 0x0 + _0x11b510, _0x307693),
      _0x37b884["drawImage"](_0x13fa14, 0x0, 0x1 * _0x754520));
    var _0xf45a39 = new Image();
    ((_0xf45a39["crossOrigin"] = "anonymous"),
      (_0xf45a39["src"] = _0x2f0946["toDataURL"]()),
      (_0xf45a39["onload"] = function () {
        _0x44a18e(_0xf45a39);
      }));
  });
}
function _0x5bf060(_0xf3016d, _0x1135d7, _0x23f47d) {
  _0x23f47d += "\x20⤸";
  var _0x3bb105 = _0xf3016d["width"],
    _0x44f5b3 = _0xf3016d["width"] / 0xa,
    _0x56cb5c = _0x44f5b3 + _0x44f5b3 / 0x2,
    _0x18b6f2 = _0x44f5b3;
  return new Promise(function (_0x4c3927, _0x2a293a) {
    var _0x55afcc = document["createElement"]("canvas");
    ((_0x55afcc["id"] = "myCanvas"),
      (_0x55afcc["width"] = _0xf3016d["width"]),
      (_0x55afcc["height"] = _0xf3016d["height"] + 0x1 * _0x56cb5c));
    var _0xe825ad = _0x55afcc["getContext"]("2d");
    ((_0xe825ad["fillStyle"] = "white"),
      _0xe825ad["fillRect"](0x0, 0x0, _0x55afcc["width"], _0x55afcc["height"]),
      (_0xe825ad["fillStyle"] = "#34B8FF"),
      (_0xe825ad["font"] = "bold\x20" + _0x44f5b3 + "px\x20Arial"),
      _0xe825ad["fillText"](_0x1135d7, 0x0, _0x18b6f2));
    var _0x139816 = _0xe825ad["measureText"](_0x1135d7)["width"],
      _0x5a77d4 = ((_0x3bb105 - _0x139816) / _0x23f47d["length"]) * 0x2;
    ((_0xe825ad["fillStyle"] = "#F79148"),
      (_0xe825ad["font"] = "bold\x20" + _0x5a77d4 + "px\x20Arial"),
      _0xe825ad["fillText"](_0x23f47d, 0x0 + _0x139816, _0x18b6f2),
      _0xe825ad["drawImage"](_0xf3016d, 0x0, 0x1 * _0x56cb5c));
    var _0x494db7 = new Image();
    ((_0x494db7["crossOrigin"] = "anonymous"),
      (_0x494db7["src"] = _0x55afcc["toDataURL"]()),
      (_0x494db7["onload"] = function () {
        _0x4c3927(_0x494db7);
      }));
  });
}
function _0x392393(_0xbdb082, _0x3ff7ac, _0x473b16, _0x4101b8) {
  return new Promise((_0xd0472b) => {
    var _0x2cf0a9 = document["createElement"]("canvas");
    _0x2cf0a9["id"] = "myCanvas";
    var _0x1a696d = (_0xbdb082["height"] / 0xa) * 0.45,
      _0x42da1c = _0x1a696d;
    ((_0x2cf0a9["width"] = _0xbdb082["width"]),
      (_0x2cf0a9["height"] = _0xbdb082["height"]));
    var _0x3d9d7 = _0x2cf0a9["getContext"]("2d");
    ((_0x3d9d7["fillStyle"] = "white"),
      _0x3d9d7["fillRect"](0x0, 0x0, _0x2cf0a9["width"], _0x2cf0a9["height"]));
    var _0x4bd399 = _0x2cf0a9["width"],
      _0xb526bb = _0x2cf0a9["height"] * (0x46 / 0x5dc);
    ((_0x3d9d7["fillStyle"] = _0x473b16),
      (_0x3d9d7["font"] = _0x1a696d + "px\x20" + _0x4101b8));
    var _0x15962b = 0x1,
      _0x225d3d = _0x3ff7ac["split"]("\x20"),
      _0xf0d0f5 = "";
    for (var _0x1e2e36 = 0x0; _0x1e2e36 < _0x225d3d["length"]; _0x1e2e36++) {
      var _0xe35678 = _0xf0d0f5 + _0x225d3d[_0x1e2e36] + "\x20";
      if (
        _0x3d9d7["measureText"](_0xe35678)["width"] > _0x4bd399 &&
        _0x1e2e36 > 0x0
      )
        (_0x15962b++,
          _0x3d9d7["fillText"](_0xf0d0f5, 0x0, _0x42da1c),
          (_0xf0d0f5 = _0x225d3d[_0x1e2e36] + "\x20"),
          (_0x42da1c += _0xb526bb));
      else _0xf0d0f5 = _0xe35678;
    }
    _0xd0472b(_0x15962b);
  });
}
function _0x525e55(
  _0x17a5cf,
  _0x292e96,
  _0xc12711,
  _0x403e06,
  _0xa29e9c,
  _0x4b684f,
) {
  var _0x47575c = _0x292e96["split"]("\x20"),
    _0x1822d7 = "";
  for (var _0x257834 = 0x0; _0x257834 < _0x47575c["length"]; _0x257834++) {
    var _0x1d01a8 = _0x1822d7 + _0x47575c[_0x257834] + "\x20";
    if (
      _0x17a5cf["measureText"](_0x1d01a8)["width"] > _0xa29e9c &&
      _0x257834 > 0x0
    )
      (_0x17a5cf["fillText"](_0x1822d7, _0xc12711, _0x403e06),
        (_0x1822d7 = _0x47575c[_0x257834] + "\x20"),
        (_0x403e06 += _0x4b684f));
    else _0x1822d7 = _0x1d01a8;
  }
  _0x17a5cf["fillText"](_0x1822d7, _0xc12711, _0x403e06);
}
function _0x1c3a5c(_0x55d453) {
  return new Promise(function (_0x5b18ac, _0x49234a) {
    var _0x484458 = document["createElement"]("canvas");
    ((_0x484458["id"] = "myCanvas"),
      (_0x484458["width"] = _0x55d453["width"]),
      (_0x484458["height"] = _0x55d453["height"]));
    var _0x34182e = _0x484458["getContext"]("2d");
    ((_0x34182e["fillStyle"] = "white"),
      _0x34182e["fillRect"](0x0, 0x0, _0x484458["width"], _0x484458["height"]),
      _0x34182e["translate"](_0x484458["width"], 0x0),
      _0x34182e["scale"](-0x1, 0x1),
      _0x34182e["drawImage"](_0x55d453, 0x0, 0x0));
    let _0x1aff24 = new Image();
    ((_0x1aff24["crossOrigin"] = "anonymous"),
      (_0x1aff24["src"] = _0x484458["toDataURL"]()),
      (_0x1aff24["onload"] = function () {
        _0x5b18ac(_0x1aff24);
      }));
  });
}
function _0x960017(_0x1454b7, _0x47067c, _0x1268ca) {
  return new Promise(function (_0x3a7359, _0x3c2677) {
    var _0x3142a7 = document["createElement"]("canvas");
    ((_0x3142a7["id"] = "myCanvas"),
      (_0x3142a7["width"] = _0x47067c),
      (_0x3142a7["height"] = _0x1268ca));
    var _0x3fdedb = _0x3142a7["getContext"]("2d");
    ((_0x3fdedb["fillStyle"] = "white"),
      _0x3fdedb["fillRect"](0x0, 0x0, _0x3142a7["width"], _0x3142a7["height"]));
    var _0x173cf1 = _0x47067c / 0x2,
      _0x1006f3 = _0x1268ca / 0x2,
      _0x407665 = 0x1;
    (_0x1454b7["width"] > _0x1454b7["height"] &&
      (_0x407665 = _0x47067c / _0x1454b7["width"]),
      _0x1454b7["width"] < _0x1454b7["height"] &&
        (_0x407665 = _0x47067c / _0x1454b7["height"]),
      _0x1454b7["width"] === _0x1454b7["height"] &&
        (_0x407665 = _0x47067c / _0x1454b7["height"]));
    var _0x3b71f4 = _0x1454b7["width"] * _0x407665,
      _0x3a4c9b = _0x1454b7["height"] * _0x407665;
    ((_0x3fdedb["globalAlpha"] = 0x1),
      _0x3fdedb["drawImage"](
        _0x1454b7,
        _0x173cf1 - _0x3b71f4 / 0x2,
        _0x1006f3 - _0x3a4c9b / 0x2,
        _0x3b71f4,
        _0x3a4c9b,
      ));
    let _0x527641 = new Image();
    ((_0x527641["crossOrigin"] = "anonymous"),
      (_0x527641["src"] = _0x3142a7["toDataURL"]()),
      (_0x527641["onload"] = function () {
        _0x3a7359(_0x527641);
      }));
  });
}
function _0xf69a72(_0x1fef50, _0x5a00f2, _0x1a8e2c) {
  return new Promise(function (_0x5f176b, _0x4b92c0) {
    var _0x4efc53 = 0x1;
    (_0x1fef50["width"] > _0x1fef50["height"] &&
      (_0x4efc53 = _0x5a00f2 / _0x1fef50["width"]),
      _0x1fef50["width"] < _0x1fef50["height"] &&
        (_0x4efc53 = _0x5a00f2 / _0x1fef50["height"]),
      _0x1fef50["width"] === _0x1fef50["height"] &&
        (_0x4efc53 = _0x5a00f2 / _0x1fef50["height"]));
    var _0x212724 = _0x1fef50["width"] * _0x4efc53,
      _0x1a9a95 = _0x1fef50["height"] * _0x4efc53,
      _0x512eb5 = document["createElement"]("canvas");
    ((_0x512eb5["id"] = "myCanvas"),
      (_0x512eb5["width"] = _0x212724),
      (_0x512eb5["height"] = _0x1a9a95),
      (_0x512eb5["style"] = "border:2px\x20solid\x20black;"));
    var _0x947cfc = _0x512eb5["getContext"]("2d");
    ((_0x947cfc["fillStyle"] = "white"),
      _0x947cfc["fillRect"](0x0, 0x0, _0x512eb5["width"], _0x512eb5["height"]),
      (_0x947cfc["globalAlpha"] = 0x1),
      _0x947cfc["drawImage"](_0x1fef50, 0x0, 0x0, _0x212724, _0x1a9a95));
    let _0x2a34cd = new Image();
    ((_0x2a34cd["crossOrigin"] = "anonymous"),
      (_0x2a34cd["src"] = _0x512eb5["toDataURL"]()),
      (_0x2a34cd["onload"] = function () {
        _0x5f176b(_0x2a34cd);
      }));
  });
}
function _0x20a895(_0x4a7ae7) {
  return new Promise(function (_0x388dc7, _0x1cca77) {
    const _0x7bc556 = Math["max"](_0x4a7ae7["width"], _0x4a7ae7["height"]),
      _0x32f8a0 = document["createElement"]("canvas");
    ((_0x32f8a0["width"] = _0x7bc556), (_0x32f8a0["height"] = _0x7bc556));
    const _0x3b0e3c = _0x32f8a0["getContext"]("2d");
    ((_0x3b0e3c["fillStyle"] = "white"),
      _0x3b0e3c["fillRect"](0x0, 0x0, _0x32f8a0["width"], _0x32f8a0["height"]));
    const _0x90a3ca = (_0x7bc556 - _0x4a7ae7["width"]) / 0x2,
      _0xfc92f = (_0x7bc556 - _0x4a7ae7["height"]) / 0x2;
    _0x3b0e3c["drawImage"](
      _0x4a7ae7,
      _0x90a3ca,
      _0xfc92f,
      _0x4a7ae7["width"],
      _0x4a7ae7["height"],
    );
    const _0x1c4535 = new Image();
    ((_0x1c4535["onload"] = function () {
      _0x388dc7(_0x1c4535);
    }),
      (_0x1c4535["src"] = _0x32f8a0["toDataURL"]()));
  });
}
function _0x561892(_0x23e45b, _0x1bfc32, _0x4da3eb) {
  return new Promise(function (_0x381990, _0x2cbc2f) {
    var _0x19f644 = _0x23e45b["width"],
      _0x5229a1 = _0x23e45b["height"];
    if (_0x19f644 < _0x1bfc32 || _0x5229a1 < _0x4da3eb) {
      var _0x418668 = document["createElement"]("canvas"),
        _0x2aee47 = _0x418668["getContext"]("2d"),
        _0x2bcdc1 = Math["max"](_0x1bfc32 / _0x19f644, _0x4da3eb / _0x5229a1);
      ((_0x19f644 *= _0x2bcdc1),
        (_0x5229a1 *= _0x2bcdc1),
        (_0x418668["width"] = _0x19f644),
        (_0x418668["height"] = _0x5229a1),
        _0x2aee47["drawImage"](_0x23e45b, 0x0, 0x0, _0x19f644, _0x5229a1));
      var _0x4a27cd = new Image();
      ((_0x4a27cd["src"] = _0x418668["toDataURL"]()),
        (_0x4a27cd["onload"] = function () {
          _0x381990(_0x4a27cd);
        }));
    } else _0x381990(_0x23e45b);
  });
}
function _0x2cf69d(_0x26448f, _0x14bf9b, _0x2ed669) {
  return new Promise(function (_0xba582, _0x16eb9a) {
    var _0x111996 = 0x1;
    (_0x26448f["width"] > _0x26448f["height"] &&
      (_0x111996 = _0x14bf9b / _0x26448f["width"]),
      _0x26448f["width"] < _0x26448f["height"] &&
        (_0x111996 = _0x14bf9b / _0x26448f["height"]),
      _0x26448f["width"] === _0x26448f["height"] &&
        (_0x111996 = _0x14bf9b / _0x26448f["height"]));
    var _0x4d29a9 = _0x26448f["width"] * _0x111996,
      _0x46c3a8 = _0x26448f["height"] * _0x111996,
      _0xa82dda = 0x1;
    for (; _0x4d29a9 > _0x14bf9b; ) {
      ((_0x4d29a9 = _0x26448f["width"] * _0xa82dda),
        (_0x46c3a8 = _0x26448f["height"] * _0xa82dda),
        (_0xa82dda -= 0.01));
    }
    var _0x386300 = document["createElement"]("canvas");
    ((_0x386300["id"] = "myCanvas"),
      (_0x386300["width"] = _0x4d29a9),
      (_0x386300["height"] = _0x46c3a8),
      (_0x386300["style"] = "border:2px\x20solid\x20black;"));
    var _0xa07da1 = _0x386300["getContext"]("2d");
    ((_0xa07da1["fillStyle"] = "white"),
      _0xa07da1["fillRect"](0x0, 0x0, _0x386300["width"], _0x386300["height"]),
      (_0xa07da1["globalAlpha"] = 0x1),
      _0xa07da1["drawImage"](_0x26448f, 0x0, 0x0, _0x4d29a9, _0x46c3a8));
    let _0x2c5e91 = new Image();
    ((_0x2c5e91["crossOrigin"] = "anonymous"),
      (_0x2c5e91["src"] = _0x386300["toDataURL"]()),
      (_0x2c5e91["onload"] = function () {
        _0xba582(_0x2c5e91);
      }));
  });
}
function _0x4ae3bb(_0x46525f) {
  return new Promise((_0x5998c4, _0x116281) => {
    var _0x38ba79 = document["createElement"]("canvas")["getContext"]("2d"),
      _0xc928b0 = new Image();
    ((_0xc928b0["onload"] = function () {
      (_0x38ba79["drawImage"](_0xc928b0, 0x0, 0x0), _0x5998c4(_0xc928b0));
    }),
      (_0xc928b0["src"] = _0x46525f));
  });
}
function _0x470a52(_0x24284c, _0x3488eb, _0x3712a1) {
  return new Promise(function (_0x27bfc8, _0x47d476) {
    let _0x400220 = document["createElement"]("canvas");
    ((_0x400220["width"] = _0x24284c["width"] + _0x3488eb["width"]),
      (_0x400220["height"] = _0x24284c["height"]));
    let _0x1a7228 = _0x400220["getContext"]("2d");
    ((_0x1a7228["fillStyle"] = "white"),
      _0x1a7228["fillRect"](0x0, 0x0, _0x400220["width"], _0x400220["height"]),
      _0x1a7228["drawImage"](_0x24284c, 0x0, 0x0),
      (_0x1a7228["globalAlpha"] = _0x3712a1));
    var _0x12bc7e = 0.9 * _0x3488eb["width"],
      _0x4386b6 = 0.9 * _0x3488eb["height"];
    _0x1a7228["drawImage"](
      _0x3488eb,
      _0x400220["width"] - _0x12bc7e,
      0x0,
      _0x12bc7e,
      _0x4386b6,
    );
    var _0x47b6ac = new Image();
    ((_0x47b6ac["onload"] = function () {
      _0x27bfc8(_0x47b6ac);
    }),
      (_0x47b6ac["src"] = _0x400220["toDataURL"]()));
  });
}
function _0x5221f5(_0x26f624, _0x52ea17) {
  return new Promise(function (_0x11a4c2, _0x554ec8) {
    var _0x591e94 = document["createElement"]("canvas"),
      _0x3b1014 = _0x591e94["getContext"]("2d");
    ((_0x3b1014["fillStyle"] = "white"),
      _0x3b1014["fillRect"](0x0, 0x0, _0x591e94["width"], _0x591e94["height"]));
    var _0x46804b = (_0x52ea17 * Math["PI"]) / 0xb4,
      _0x278092 = Math["cos"](_0x46804b),
      _0x58b940 = Math["sin"](_0x46804b);
    (_0x58b940 < 0x0 && (_0x58b940 = -_0x58b940),
      _0x278092 < 0x0 && (_0x278092 = -_0x278092),
      (_0x591e94["width"] =
        _0x26f624["height"] * _0x58b940 + _0x26f624["width"] * _0x278092),
      (_0x591e94["height"] =
        _0x26f624["height"] * _0x278092 + _0x26f624["width"] * _0x58b940));
    var _0x13251b = _0x26f624["width"],
      _0x46c99b = _0x26f624["height"],
      _0x36f0b7 = _0x591e94["width"] / 0x2,
      _0x209b19 = _0x591e94["height"] / 0x2,
      _0x5dcb59 = Math["PI"] / 0xb4;
    (_0x3b1014["translate"](_0x36f0b7, _0x209b19),
      _0x3b1014["rotate"](_0x52ea17 * _0x5dcb59),
      _0x3b1014["drawImage"](
        _0x26f624,
        -_0x13251b / 0x2,
        -_0x46c99b / 0x2,
        _0x13251b,
        _0x46c99b,
      ));
    var _0x37def1 = new Image();
    ((_0x37def1["onload"] = function () {
      _0x11a4c2(_0x37def1);
    }),
      (_0x37def1["src"] = _0x591e94["toDataURL"]()));
  });
}
function _0x1d9f9b(_0x1cd8f8, _0x38338d, _0x59916d) {
  return new Promise(function (_0x3b9f56, _0x1fbf25) {
    let _0x1179c5 = document["createElement"]("canvas");
    ((_0x1179c5["width"] = _0x1cd8f8["width"] + _0x38338d["width"]),
      (_0x1179c5["height"] = _0x1cd8f8["height"]));
    let _0x3ff6ac = _0x1179c5["getContext"]("2d");
    ((_0x3ff6ac["fillStyle"] = "white"),
      _0x3ff6ac["fillRect"](0x0, 0x0, _0x1179c5["width"], _0x1179c5["height"]));
    var _0x9c4544 = _0x38338d["width"];
    (_0x38338d["height"],
      "left" === _0x59916d
        ? _0x3ff6ac["drawImage"](_0x1cd8f8, _0x9c4544, 0x0)
        : "right" === _0x59916d && _0x3ff6ac["drawImage"](_0x1cd8f8, 0x0, 0x0));
    var _0x228191 = new Image();
    ((_0x228191["onload"] = function () {
      _0x3b9f56(_0x228191);
    }),
      (_0x228191["src"] = _0x1179c5["toDataURL"]()));
  });
}
function _0x274046(_0x562e4b, _0x3104d5, _0x564b56) {
  return new Promise(function (_0x339fa2, _0x24cef6) {
    let _0x3a0367 = document["createElement"]("canvas");
    ((_0x3a0367["width"] = _0x562e4b["width"] + _0x3104d5),
      (_0x3a0367["height"] = _0x562e4b["height"]));
    let _0x21fb02 = _0x3a0367["getContext"]("2d");
    ((_0x21fb02["fillStyle"] = "white"),
      _0x21fb02["fillRect"](0x0, 0x0, _0x3a0367["width"], _0x3a0367["height"]));
    var _0x3a6367 = _0x3104d5;
    "top" === _0x564b56
      ? _0x21fb02["drawImage"](_0x562e4b, 0x0, _0x3a6367)
      : "botttom" === _0x564b56 && _0x21fb02["drawImage"](_0x562e4b, 0x0, 0x0);
    var _0x2ae2b4 = new Image();
    ((_0x2ae2b4["onload"] = function () {
      _0x339fa2(_0x2ae2b4);
    }),
      (_0x2ae2b4["src"] = _0x3a0367["toDataURL"]()));
  });
}
function _0x242a71(_0x73eae5) {
  return new Promise(function (_0x401f93, _0x7272b8) {
    let _0x5d4258 = document["createElement"]("canvas");
    console["log"]("Making\x20image\x20aspect\x20same");
    if (_0x73eae5["width"] > _0x73eae5["height"])
      ((_0x5d4258["width"] = _0x73eae5["width"]),
        (_0x5d4258["height"] =
          _0x73eae5["height"] + (_0x73eae5["width"] - _0x73eae5["height"])));
    else
      _0x73eae5["width"] < _0x73eae5["height"]
        ? ((_0x5d4258["height"] = _0x73eae5["height"]),
          (_0x5d4258["width"] =
            _0x73eae5["width"] + (_0x73eae5["height"] - _0x73eae5["width"])))
        : (console["log"]("Image\x20is\x20already\x20a\x20square"),
          _0x401f93(_0x73eae5));
    console["log"]("Done\x20making\x20image\x20aspect\x20same");
    let _0x508435 = _0x5d4258["getContext"]("2d");
    ((_0x508435["fillStyle"] = "white"),
      _0x508435["fillRect"](0x0, 0x0, _0x5d4258["width"], _0x5d4258["height"]),
      _0x508435["drawImage"](
        _0x73eae5,
        (_0x5d4258["width"] - _0x73eae5["width"]) / 0x2,
        (_0x5d4258["height"] - _0x73eae5["height"]) / 0x2,
      ));
    var _0x29c32f = new Image();
    ((_0x29c32f["onload"] = function () {
      _0x401f93(_0x29c32f);
    }),
      (_0x29c32f["src"] = _0x5d4258["toDataURL"]()));
  });
}
function _0x599c15(_0x56489e, _0xdccdc2, _0x355bdf) {
  return new Promise(function (_0x57473f, _0x4875ac) {
    let _0x380ad3 = document["createElement"]("canvas");
    ((_0x380ad3["width"] = _0x56489e["width"]),
      (_0x380ad3["height"] = _0x56489e["height"]));
    let _0x1a3b4c = _0x380ad3["getContext"]("2d");
    ((_0x1a3b4c["fillStyle"] = "white"),
      _0x1a3b4c["fillRect"](0x0, 0x0, _0x380ad3["width"], _0x380ad3["height"]));
    var _0x2d7f48 = _0xdccdc2["width"],
      _0x1c937a = _0xdccdc2["height"];
    (_0x1a3b4c["drawImage"](_0x56489e, 0x0, 0x0),
      (_0x1a3b4c["globalAlpha"] = _0x355bdf));
    var _0x2bff07 = 0x0 + _0x380ad3["width"] / 0x32;
    _0x1a3b4c["drawImage"](_0xdccdc2, _0x2bff07, 0x0, _0x2d7f48, _0x1c937a);
    var _0x35a116 = new Image();
    ((_0x35a116["onload"] = function () {
      _0x57473f(_0x35a116);
    }),
      (_0x35a116["src"] = _0x380ad3["toDataURL"]()));
  });
}
function _0x3b79fc(_0x2a1414, _0x3b3563, _0x8284a0) {
  return new Promise(async function (_0x4f65b3, _0x4775cc) {
    let _0x386bcd = document["createElement"]("canvas");
    ((_0x386bcd["width"] = _0x2a1414["width"]),
      (_0x386bcd["height"] = _0x2a1414["height"]));
    let _0x28507f = _0x386bcd["getContext"]("2d");
    ((_0x28507f["fillStyle"] = "white"),
      _0x28507f["fillRect"](0x0, 0x0, _0x386bcd["width"], _0x386bcd["height"]),
      _0x28507f["drawImage"](_0x2a1414, 0x0, 0x0),
      (_0x28507f["globalAlpha"] = _0x8284a0),
      _0x28507f["drawImage"](
        _0x3b3563,
        _0x386bcd["width"] - _0x3b3563["width"],
        0x0,
        _0x3b3563["width"],
        _0x3b3563["height"],
      ));
    var _0x54a82d = new Image();
    ((_0x54a82d["onload"] = function () {
      _0x4f65b3(_0x54a82d);
    }),
      (_0x54a82d["src"] = _0x386bcd["toDataURL"]()));
  });
}
function _0x3c41f6(_0x55d823, _0x3c429d, _0x319bd0) {
  return new Promise(function (_0x30f3c2, _0x5ae2d6) {
    let _0x137210 = document["createElement"]("canvas");
    ((_0x137210["width"] = _0x55d823["width"]),
      (_0x137210["height"] = _0x55d823["height"]));
    let _0x58779b = _0x137210["getContext"]("2d");
    ((_0x58779b["fillStyle"] = "white"),
      _0x58779b["fillRect"](0x0, 0x0, _0x137210["width"], _0x137210["height"]),
      _0x58779b["drawImage"](_0x55d823, 0x0, 0x0),
      (_0x58779b["globalAlpha"] = _0x319bd0));
    var _0x2d975d = _0x3c429d["width"],
      _0x25cb78 = _0x3c429d["height"];
    _0x58779b["drawImage"](
      _0x3c429d,
      _0x137210["width"] - _0x2d975d,
      0x0,
      _0x2d975d,
      _0x25cb78,
    );
    var _0x171df2 = new Image();
    ((_0x171df2["onload"] = function () {
      _0x30f3c2(_0x171df2);
    }),
      (_0x171df2["src"] = _0x137210["toDataURL"]()));
  });
}
function _0x790ef3(
  _0x4842ae,
  _0x340537,
  _0x398fb2,
  _0x4413b8,
  _0x588d79,
  _0x4fa4a3,
) {
  (_0x4842ae["beginPath"](),
    _0x4842ae["moveTo"](_0x340537 + _0x4fa4a3, _0x398fb2),
    _0x4842ae["lineTo"](_0x340537 + _0x4413b8 - _0x4fa4a3, _0x398fb2),
    _0x4842ae["quadraticCurveTo"](
      _0x340537 + _0x4413b8,
      _0x398fb2,
      _0x340537 + _0x4413b8,
      _0x398fb2 + _0x4fa4a3,
    ),
    _0x4842ae["lineTo"](
      _0x340537 + _0x4413b8,
      _0x398fb2 + _0x588d79 - _0x4fa4a3,
    ),
    _0x4842ae["quadraticCurveTo"](
      _0x340537 + _0x4413b8,
      _0x398fb2 + _0x588d79,
      _0x340537 + _0x4413b8 - _0x4fa4a3,
      _0x398fb2 + _0x588d79,
    ),
    _0x4842ae["lineTo"](_0x340537 + _0x4fa4a3, _0x398fb2 + _0x588d79),
    _0x4842ae["quadraticCurveTo"](
      _0x340537,
      _0x398fb2 + _0x588d79,
      _0x340537,
      _0x398fb2 + _0x588d79 - _0x4fa4a3,
    ),
    _0x4842ae["lineTo"](_0x340537, _0x398fb2 + _0x4fa4a3),
    _0x4842ae["quadraticCurveTo"](
      _0x340537,
      _0x398fb2,
      _0x340537 + _0x4fa4a3,
      _0x398fb2,
    ),
    _0x4842ae["closePath"]());
}
function _0x267114(_0x3a7587, _0x4c9a6a, _0x1f0e75, _0x5cab7f) {
  return new Promise(function (_0x5642ec, _0x50f716) {
    let _0x10868d = document["createElement"]("canvas");
    ((_0x10868d["width"] = _0x3a7587["width"]),
      (_0x10868d["height"] = _0x3a7587["height"]));
    let _0x136e4c = _0x10868d["getContext"]("2d");
    ((_0x136e4c["fillStyle"] = "white"),
      _0x136e4c["fillRect"](0x0, 0x0, _0x10868d["width"], _0x10868d["height"]),
      _0x136e4c["drawImage"](_0x3a7587, 0x0, 0x0),
      (_0x136e4c["globalAlpha"] = _0x1f0e75));
    var _0x435ed9 =
        _0x10868d["width"] - _0x4c9a6a["width"] - _0x10868d["width"] / 0x32,
      _0x18956f =
        _0x10868d["height"] -
        _0x4c9a6a["height"] -
        _0x10868d["height"] / _0x5cab7f;
    (_0x790ef3(
      _0x136e4c,
      _0x435ed9,
      _0x18956f,
      _0x4c9a6a["width"],
      _0x4c9a6a["height"],
      0xa,
    ),
      _0x136e4c["clip"](),
      _0x136e4c["drawImage"](_0x4c9a6a, _0x435ed9, _0x18956f));
    var _0x10e201 = new Image();
    ((_0x10e201["onload"] = function () {
      _0x5642ec(_0x10e201);
    }),
      (_0x10e201["src"] = _0x10868d["toDataURL"]()));
  });
}
function _0x1d6c45(_0x12a12b, _0x2927fc, _0x7e6c29, _0x513cc8) {
  return new Promise(function (_0x5d0e07, _0xa0e190) {
    let _0x2cba3d = document["createElement"]("canvas");
    ((_0x2cba3d["width"] = _0x12a12b["width"]),
      (_0x2cba3d["height"] = _0x12a12b["height"]));
    let _0x18a527 = _0x2cba3d["getContext"]("2d");
    ((_0x18a527["fillStyle"] = "white"),
      _0x18a527["fillRect"](0x0, 0x0, _0x2cba3d["width"], _0x2cba3d["height"]),
      _0x18a527["drawImage"](_0x12a12b, 0x0, 0x0),
      (_0x18a527["globalAlpha"] = _0x7e6c29));
    var _0x5a90f8 = 0x0 + _0x2cba3d["width"] / 0x32,
      _0x4a4db2 =
        _0x2cba3d["height"] -
        _0x2927fc["height"] -
        _0x2cba3d["height"] / _0x513cc8;
    _0x18a527["drawImage"](_0x2927fc, _0x5a90f8, _0x4a4db2);
    var _0x1d8e7a = new Image();
    ((_0x1d8e7a["onload"] = function () {
      _0x5d0e07(_0x1d8e7a);
    }),
      (_0x1d8e7a["src"] = _0x2cba3d["toDataURL"]()));
  });
}
function _0xd2b58(_0x5d6ad3, _0x38c45a, _0x1450bf) {
  return new Promise(function (_0x5192c6, _0xda66fc) {
    let _0x317232 = document["createElement"]("canvas");
    ((_0x317232["width"] = _0x5d6ad3["width"]),
      (_0x317232["height"] = _0x5d6ad3["height"]));
    let _0x31d932 = _0x317232["getContext"]("2d");
    ((_0x31d932["fillStyle"] = "white"),
      _0x31d932["fillRect"](0x0, 0x0, _0x317232["width"], _0x317232["height"]),
      _0x31d932["drawImage"](_0x5d6ad3, 0x0, 0x0),
      _0x31d932["drawImage"](
        _0x38c45a,
        _0x1450bf,
        _0x317232["height"] - _0x38c45a["height"],
      ));
    var _0x4080fc = new Image();
    ((_0x4080fc["onload"] = function () {
      _0x5192c6(_0x4080fc);
    }),
      (_0x4080fc["src"] = _0x317232["toDataURL"]()));
  });
}
function _0x37fc97(_0x715476, _0x3b7b05) {
  return new Promise(function (_0x540347, _0x32e95c) {
    let _0x1dfa4c = document["createElement"]("canvas");
    ((_0x1dfa4c["width"] = _0x715476["width"]),
      (_0x1dfa4c["height"] = _0x715476["height"]));
    let _0x1b4ecc = _0x1dfa4c["getContext"]("2d");
    ((_0x1b4ecc["fillStyle"] = "white"),
      _0x1b4ecc["fillRect"](0x0, 0x0, _0x1dfa4c["width"], _0x1dfa4c["height"]),
      (_0x1b4ecc["globalAlpha"] = _0x3b7b05),
      _0x1b4ecc["drawImage"](_0x715476, 0x0, 0x0));
    var _0x35851d = new Image();
    ((_0x35851d["onload"] = function () {
      _0x540347(_0x35851d);
    }),
      (_0x35851d["src"] = _0x1dfa4c["toDataURL"]()));
  });
}
function _0x3dcff9(_0x404b05, _0x43ffcd) {
  return new Promise(function (_0x22b2dd, _0x2acde1) {
    let _0x33ae13 = document["createElement"]("canvas");
    ((_0x33ae13["width"] = _0x404b05["width"] + imgWatermark["width"]),
      (_0x33ae13["height"] = _0x404b05["height"]));
    let _0xfb0ffe = _0x33ae13["getContext"]("2d");
    ((_0xfb0ffe["fillStyle"] = "white"),
      _0xfb0ffe["fillRect"](0x0, 0x0, _0x33ae13["width"], _0x33ae13["height"]),
      (_0xfb0ffe["globalAlpha"] = _0x43ffcd),
      _0xfb0ffe["drawImage"](_0x404b05, 0x0, 0x0));
    var _0x13391d = 0.9 * imgWatermark["width"],
      _0x8cb81a = 0.9 * imgWatermark["height"];
    _0xfb0ffe["drawImage"](
      imgWatermark,
      _0x33ae13["width"] - _0x13391d,
      0x0,
      _0x13391d,
      _0x8cb81a,
    );
    var _0x29f966 = new Image();
    ((_0x29f966["onload"] = function () {
      _0x22b2dd(_0x29f966);
    }),
      (_0x29f966["src"] = _0x33ae13["toDataURL"]()));
  });
}
function _0x2e1f19(_0x253bf0) {
  return new Promise((_0x5140f7, _0x3f7d33) => {
    var _0x36e359 = document["createElement"]("canvas"),
      _0x4b69d6 = _0x36e359["getContext"]("2d");
    ((_0x36e359["width"] = _0x253bf0["width"]),
      (_0x36e359["height"] = _0x253bf0["height"]));
    var _0x2188e1 = new Image();
    ((_0x2188e1["onload"] = function () {
      (_0x4b69d6["drawImage"](_0x253bf0, 0x0, 0x0), _0x5140f7(_0x36e359));
    }),
      (_0x2188e1["src"] = _0x253bf0["src"]));
  });
}
function _0x602f20(_0x1f693a) {
  return new Promise((_0x58c6ec, _0x586d09) => {
    var _0x5cff7d = new Image();
    ((_0x5cff7d["onload"] = function () {
      _0x58c6ec(_0x5cff7d);
    }),
      (_0x5cff7d["src"] = _0x1f693a["toDataURL"]()));
  });
}
function _0x40ffa2(_0xc611f2) {
  return new Promise((_0x298a11, _0x3ceae8) => {
    var _0xde7422 = new Image(),
      _0x4a4db4 = document["createElement"]("canvas"),
      _0x32f645 = _0x4a4db4["getContext"]("2d"),
      _0xd153c6 = {};
    ((_0xde7422["onload"] = function () {
      ((_0x4a4db4["width"] = _0xde7422["width"]),
        (_0x4a4db4["height"] = _0xde7422["height"]),
        _0x32f645["drawImage"](
          _0xde7422,
          0x0,
          0x0,
          _0xde7422["width"],
          _0xde7422["height"],
        ),
        (_0xd153c6 = _0x32f645["getImageData"](
          0x0,
          0x0,
          _0xde7422["width"],
          _0xde7422["height"],
        )["data"]));
      var _0x4e5e43 = _0x50111c(!0x0, _0xde7422, _0xd153c6),
        _0x1a01f9 = _0x50111c(!0x1, _0xde7422, _0xd153c6),
        _0x260456 = _0x397d6e(!0x0, _0xde7422, _0xd153c6),
        _0x1ed455 = _0x397d6e(!0x1, _0xde7422, _0xd153c6) - _0x260456,
        _0x1f7772 = _0x1a01f9 - _0x4e5e43;
      ((_0x4a4db4["width"] = _0x1ed455),
        (_0x4a4db4["height"] = _0x1f7772),
        _0x32f645["drawImage"](
          _0xde7422,
          _0x260456,
          _0x4e5e43,
          _0x1ed455,
          _0x1f7772,
          0x0,
          0x0,
          _0x1ed455,
          _0x1f7772,
        ));
      let _0x146958 = new Image();
      ((_0x146958["crossOrigin"] = "anonymous"),
        (_0x146958["onload"] = function () {
          _0x298a11(_0x146958);
        }),
        (_0x146958["src"] = _0x4a4db4["toDataURL"]()));
    }),
      (_0xde7422["src"] = _0xc611f2["src"]));
  });
}
function _0x397d6e(_0x1bef15, _0x29656c, _0x24c581) {
  var _0x81613a = _0x1bef15 ? 0x1 : -0x1;
  for (
    var _0x4ccfcf = _0x1bef15 ? 0x0 : _0x29656c["width"] - 0x1;
    _0x1bef15 ? _0x4ccfcf < _0x29656c["width"] : _0x4ccfcf > -0x1;
    _0x4ccfcf += _0x81613a
  )
    for (var _0x41ebb6 = 0x0; _0x41ebb6 < _0x29656c["height"]; _0x41ebb6++)
      if (!_0x1cac98(_0x3fba0c(_0x4ccfcf, _0x41ebb6, _0x24c581, _0x29656c)))
        return _0x4ccfcf;
  return null;
}
function _0x50111c(_0x212557, _0x34c176, _0x28377c) {
  var _0x5d27d3 = _0x212557 ? 0x1 : -0x1;
  for (
    var _0x262e5f = _0x212557 ? 0x0 : _0x34c176["height"] - 0x1;
    _0x212557 ? _0x262e5f < _0x34c176["height"] : _0x262e5f > -0x1;
    _0x262e5f += _0x5d27d3
  )
    for (var _0x2371e8 = 0x0; _0x2371e8 < _0x34c176["width"]; _0x2371e8++)
      if (!_0x1cac98(_0x3fba0c(_0x2371e8, _0x262e5f, _0x28377c, _0x34c176)))
        return _0x262e5f;
  return null;
}
function _0x1cac98(_0x5a22a6) {
  return (
    0xff == _0x5a22a6["red"] &&
    0xff == _0x5a22a6["green"] &&
    0xff == _0x5a22a6["blue"]
  );
}
function _0x3fba0c(_0x504210, _0x2cc566, _0x3a92a9, _0x467059) {
  return {
    red: _0x3a92a9[0x4 * (_0x467059["width"] * _0x2cc566 + _0x504210)],
    green: _0x3a92a9[0x4 * (_0x467059["width"] * _0x2cc566 + _0x504210) + 0x1],
    blue: _0x3a92a9[0x4 * (_0x467059["width"] * _0x2cc566 + _0x504210) + 0x2],
  };
}
function _0x59fc80(_0x26fd63) {
  return new Promise((_0xa4086e, _0x4b929e) => {
    var _0x184689 = document["createElement"]("canvas"),
      _0x43ce70 = _0x184689["getContext"]("2d");
    ((_0x184689["width"] = _0x26fd63["width"]),
      (_0x184689["height"] = _0x26fd63["height"]),
      _0x43ce70["drawImage"](
        _0x26fd63,
        0x0,
        0x0,
        _0x26fd63["width"],
        _0x26fd63["height"],
      ));
    let _0x2d3b07 = _0x43ce70["getImageData"](
      0x0,
      0x0,
      _0x26fd63["width"],
      _0x26fd63["height"],
    );
    var _0x19734d = _0x2d3b07["data"];
    for (let _0x77479b = 0x0; _0x77479b < _0x19734d["length"]; _0x77479b += 0x4)
      [
        _0x19734d[_0x77479b],
        _0x19734d[_0x77479b + 0x1],
        _0x19734d[_0x77479b + 0x2],
      ]["every"]((_0x46588b) => _0x46588b < 0x100 && _0x46588b > 0xf5) &&
        (_0x19734d[_0x77479b + 0x3] = 0x0);
    _0x43ce70["putImageData"](_0x2d3b07, 0x0, 0x0);
    var _0x4fef3f = new Image();
    ((_0x4fef3f["onload"] = function () {
      _0xa4086e(_0x4fef3f);
    }),
      (_0x4fef3f["src"] = _0x184689["toDataURL"]()));
  });
}
async function _0x266c8f(
  _0x3f57fe,
  _0x2e0f25 = "/Image_Badges/Best_Seller.png",
) {
  var _0x370e51 = chrome["runtime"]["getURL"](_0x2e0f25),
    _0xce34e4 = await _0x751656(_0x370e51),
    _0x53f3e7 = document["createElement"]("canvas"),
    _0x439453 = _0x53f3e7["getContext"]("2d");
  ((_0x53f3e7["width"] = _0x3f57fe["width"]),
    (_0x53f3e7["height"] = _0x3f57fe["height"] + _0xce34e4["height"]),
    (_0x439453["fillStyle"] = "white"),
    _0x439453["fillRect"](0x0, 0x0, _0x53f3e7["width"], _0x53f3e7["height"]),
    _0x439453["drawImage"](_0x3f57fe, 0x0, _0xce34e4["height"]),
    _0x439453["drawImage"](
      _0xce34e4,
      0x0,
      0x0,
      _0xce34e4["width"],
      _0xce34e4["height"],
    ));
  var _0x2046e1 = new Image();
  return ((_0x2046e1["src"] = _0x53f3e7["toDataURL"]()), _0x2046e1);
}
async function _0x450fc3(
  _0x45fbbd,
  _0x43b33b = "/Image_Badges/Limited-Time-Deal-Badge.jpg",
) {
  var _0x580e44 = chrome["runtime"]["getURL"](_0x43b33b),
    _0xb0f86c = await _0x751656(_0x580e44),
    _0x3bcd9e = document["createElement"]("canvas"),
    _0x696efb = _0x3bcd9e["getContext"]("2d");
  ((_0x3bcd9e["width"] = _0x45fbbd["width"]),
    (_0x3bcd9e["height"] = _0x45fbbd["height"]),
    (_0x696efb["fillStyle"] = "white"),
    _0x696efb["fillRect"](0x0, 0x0, _0x3bcd9e["width"], _0x3bcd9e["height"]),
    _0x696efb["drawImage"](_0x45fbbd, 0x0, 0x0));
  var _0x133f35 = _0x45fbbd["width"] / 2.5,
    _0x5d0d20 = _0xb0f86c["height"] * (_0x133f35 / _0xb0f86c["width"]);
  _0x696efb["drawImage"](
    _0xb0f86c,
    _0x45fbbd["width"] - _0x133f35,
    _0x45fbbd["height"] - _0x5d0d20,
    _0x133f35,
    _0x5d0d20,
  );
  var _0x190512 = new Image();
  return ((_0x190512["src"] = _0x3bcd9e["toDataURL"]()), _0x190512);
}
async function _0xd92106(
  _0xadd2d5,
  _0x563db9,
  _0x26e030,
  _0x5028f6,
  _0x12fd6d,
  _0x54a232,
  _0x5dab00,
  _0x2f3484,
  _0x574843,
  _0x1b1d69,
  _0x547020 = !0x1,
) {
  (console["log"]("Creating\x20multi\x20image\x20V2"),
    console["log"]("imageSource", _0xadd2d5));
  var _0x3f0009 = await _0x751656(_0xadd2d5);
  ((_0x3f0009 = await _0xf69a72(_0x3f0009, _0x5dab00, _0x2f3484)),
    (_0x3f0009 = await _0x40ffa2(_0x3f0009)));
  var _0x1c5278 = await _0x751656(_0x563db9),
    _0x349e49 = await _0x751656(_0x5028f6),
    _0x2afa71 = await _0x751656(_0x12fd6d);
  ((_0x1c5278 = await _0xf69a72(_0x1c5278, 0.45 * _0x5dab00, 0.45 * _0x2f3484)),
    (_0x349e49 = await _0xf69a72(
      _0x349e49,
      0.45 * _0x5dab00,
      0.45 * _0x2f3484,
    )),
    (_0x2afa71 = await _0xf69a72(
      _0x2afa71,
      0.45 * _0x5dab00,
      0.45 * _0x2f3484,
    )));
  var _0xcc79e5 = Math["max"](
    _0x1c5278["width"],
    _0x349e49["width"],
    _0x2afa71["width"],
  );
  ((_0x3f0009 = await _0x46e691(_0x3f0009, _0xcc79e5, "right")),
    (_0x3f0009 = await _0x242a71(_0x3f0009)),
    (_0x1c5278 = await _0xf69a72(_0x1c5278, 0.4 * _0x5dab00, 0.4 * _0x2f3484)),
    (_0x349e49 = await _0xf69a72(_0x349e49, 0.4 * _0x5dab00, 0.4 * _0x2f3484)),
    (_0x2afa71 = await _0xf69a72(_0x2afa71, 0.4 * _0x5dab00, 0.4 * _0x2f3484)));
  var _0x3797d5 = 0x0;
  ((_0x3f0009 = await _0x1358e8(_0x3f0009, _0x1c5278, _0x3797d5)),
    (_0x3797d5 += _0x1c5278["height"] + _0x3f0009["height"] / 0x19),
    (_0x3f0009 = await _0x1358e8(_0x3f0009, _0x349e49, _0x3797d5)),
    (_0x3797d5 += _0x349e49["height"] + _0x3f0009["height"] / 0x19),
    (_0x3f0009 = await _0x1358e8(_0x3f0009, _0x2afa71, _0x3797d5)));
  var _0x5706bd = await _0x751656(_0x26e030);
  _0x5706bd = await _0xf69a72(
    _0x5706bd,
    0.2 * _0x3f0009["height"],
    0.2 * _0x3f0009["width"],
  );
  var _0x28021c = _0x3f0009["height"],
    _0x548b51 = chrome["runtime"]["getURL"]("/Image_Badges/Best_Seller.png"),
    _0x2c4af6 = await _0x751656(_0x548b51),
    _0x3cd0c0 = _0x3f0009["height"] / 0x5,
    _0x4fdd74 = _0x2c4af6["width"] * (_0x3cd0c0 / _0x2c4af6["height"]);
  _0x2c4af6 = await _0xf69a72(_0x2c4af6, _0x4fdd74, _0x3cd0c0);
  if (_0x547020) {
    _0x3f0009 = await _0x266c8f(_0x3f0009);
    var _0x3930b1 =
      (_0x3f0009 = await _0x450fc3(_0x3f0009))["height"] - _0x28021c;
    ((_0x5706bd = await _0xf69a72(
      _0x5706bd,
      _0x3930b1,
      0.2 * _0x3f0009["width"],
    )),
      (_0x3f0009 = await _0x4efce6(_0x3f0009, _0x5706bd, 0.7)));
  }
  return await _0x561892(_0x3f0009, 0x1f4, 0x1f4);
}
function _0x5af5bc(_0x3203a0, _0x31f7a5, _0x55a1a3, _0x13aef6 = 0x1) {
  return new Promise(function (_0xfa6494, _0x1eb45e) {
    let _0x21fc9d = document["createElement"]("canvas");
    ((_0x21fc9d["width"] = _0x3203a0["width"]),
      (_0x21fc9d["height"] = _0x3203a0["height"]));
    let _0x346858 = _0x21fc9d["getContext"]("2d");
    ((_0x346858["fillStyle"] = "white"),
      _0x346858["fillRect"](0x0, 0x0, _0x21fc9d["width"], _0x21fc9d["height"]),
      _0x346858["drawImage"](_0x3203a0, 0x0, 0x0));
    var _0x16147c = _0x55a1a3;
    (_0x790ef3(
      _0x346858,
      0x0,
      _0x16147c,
      _0x31f7a5["width"],
      _0x31f7a5["height"],
      0xa,
    ),
      (_0x346858["globalAlpha"] = _0x13aef6),
      _0x346858["drawImage"](_0x31f7a5, 0x0, _0x16147c));
    let _0x188b75 = new Image();
    ((_0x188b75["src"] = _0x21fc9d["toDataURL"]()), _0xfa6494(_0x188b75));
  });
}
function _0x1358e8(_0x58591b, _0x5ef247, _0x45c76c) {
  return new Promise(function (_0x186245, _0x2b4d71) {
    let _0x1d3c1b = document["createElement"]("canvas");
    ((_0x1d3c1b["width"] = _0x58591b["width"]),
      (_0x1d3c1b["height"] = _0x58591b["height"]));
    let _0x1d8ac8 = _0x1d3c1b["getContext"]("2d");
    ((_0x1d8ac8["fillStyle"] = "white"),
      _0x1d8ac8["fillRect"](0x0, 0x0, _0x1d3c1b["width"], _0x1d3c1b["height"]),
      _0x1d8ac8["drawImage"](_0x58591b, 0x0, 0x0),
      (_0x1d8ac8["globalAlpha"] = 0.9));
    var _0x4206da =
        _0x1d3c1b["width"] - _0x5ef247["width"] - _0x1d3c1b["width"] / 0x32,
      _0x3e55d0 = _0x45c76c;
    (_0x790ef3(
      _0x1d8ac8,
      _0x4206da,
      _0x3e55d0,
      _0x5ef247["width"],
      _0x5ef247["height"],
      0xa,
    ),
      _0x1d8ac8["clip"](),
      _0x1d8ac8["drawImage"](_0x5ef247, _0x4206da, _0x3e55d0));
    var _0x390d0c = new Image();
    ((_0x390d0c["onload"] = function () {
      _0x186245(_0x390d0c);
    }),
      (_0x390d0c["src"] = _0x1d3c1b["toDataURL"]()));
  });
}
function _0x46e691(_0x8ff824, _0x34196f, _0x387dd2) {
  return new Promise(function (_0x184e23, _0x382669) {
    let _0x3cf72f = document["createElement"]("canvas");
    ((_0x3cf72f["width"] = _0x8ff824["width"] + _0x34196f),
      (_0x3cf72f["height"] = _0x8ff824["height"]));
    let _0x54dfea = _0x3cf72f["getContext"]("2d");
    ((_0x54dfea["fillStyle"] = "white"),
      _0x54dfea["fillRect"](0x0, 0x0, _0x3cf72f["width"], _0x3cf72f["height"]));
    var _0x16e073 = _0x34196f;
    "left" === _0x387dd2
      ? _0x54dfea["drawImage"](_0x8ff824, _0x16e073, 0x0)
      : "right" === _0x387dd2 && _0x54dfea["drawImage"](_0x8ff824, 0x0, 0x0);
    var _0x55cbdd = new Image();
    ((_0x55cbdd["onload"] = function () {
      _0x184e23(_0x55cbdd);
    }),
      (_0x55cbdd["src"] = _0x3cf72f["toDataURL"]()));
  });
}
function _0x4a5efa(_0x15e94d, _0x1685db, _0x1b57b8) {
  return new Promise(function (_0x1d1a78, _0x283054) {
    let _0x9d0ee = document["createElement"]("canvas");
    ((_0x9d0ee["width"] = _0x15e94d["width"]),
      (_0x9d0ee["height"] = _0x15e94d["height"] + _0x1685db));
    let _0x1e6f7f = _0x9d0ee["getContext"]("2d");
    ((_0x1e6f7f["fillStyle"] = "white"),
      _0x1e6f7f["fillRect"](0x0, 0x0, _0x9d0ee["width"], _0x9d0ee["height"]));
    var _0xca1ee0 = _0x1685db;
    "top" === _0x1b57b8
      ? _0x1e6f7f["drawImage"](_0x15e94d, 0x0, _0xca1ee0)
      : "bottom" === _0x1b57b8 && _0x1e6f7f["drawImage"](_0x15e94d, 0x0, 0x0);
    var _0xd63fee = new Image();
    ((_0xd63fee["onload"] = function () {
      _0x1d1a78(_0xd63fee);
    }),
      (_0xd63fee["src"] = _0x9d0ee["toDataURL"]()));
  });
}
function _0x4efce6(_0x4654c5, _0x2f4ca5, _0x594649) {
  return new Promise(async function (_0x31264e, _0x4d0100) {
    let _0x33b6ca = document["createElement"]("canvas");
    ((_0x33b6ca["width"] = _0x4654c5["width"]),
      (_0x33b6ca["height"] = _0x4654c5["height"]));
    let _0x4a5445 = _0x33b6ca["getContext"]("2d");
    ((_0x4a5445["fillStyle"] = "white"),
      _0x4a5445["fillRect"](0x0, 0x0, _0x33b6ca["width"], _0x33b6ca["height"]),
      _0x4a5445["drawImage"](_0x4654c5, 0x0, 0x0),
      (_0x4a5445["globalAlpha"] = _0x594649),
      _0x4a5445["drawImage"](
        _0x2f4ca5,
        _0x33b6ca["width"] - _0x2f4ca5["width"],
        0x0,
        _0x2f4ca5["width"],
        _0x2f4ca5["height"],
      ));
    var _0x916adc = new Image();
    ((_0x916adc["onload"] = function () {
      _0x31264e(_0x916adc);
    }),
      (_0x916adc["src"] = _0x33b6ca["toDataURL"]()));
  });
}
function _0x387739(_0x5b1cc1) {
  return new Promise(function (_0xb35bd0, _0x44db66) {
    let _0x4bd16c = document["createElement"]("canvas");
    (_0x5b1cc1["width"], _0x5b1cc1["height"]);
    if (_0x5b1cc1["width"] > _0x5b1cc1["height"])
      ((_0x4bd16c["width"] = _0x5b1cc1["width"]),
        (_0x4bd16c["height"] =
          _0x5b1cc1["height"] + (_0x5b1cc1["width"] - _0x5b1cc1["height"])));
    else {
      if (!(_0x5b1cc1["width"] < _0x5b1cc1["height"])) return _0x5b1cc1;
      ((_0x4bd16c["height"] = _0x5b1cc1["height"]),
        (_0x4bd16c["width"] =
          _0x5b1cc1["width"] + (_0x5b1cc1["height"] - _0x5b1cc1["width"])));
    }
    let _0x4073c2 = _0x4bd16c["getContext"]("2d");
    ((_0x4073c2["fillStyle"] = "white"),
      _0x4073c2["fillRect"](0x0, 0x0, _0x4bd16c["width"], _0x4bd16c["height"]),
      _0x4073c2["drawImage"](
        _0x5b1cc1,
        _0x4bd16c["width"] - _0x5b1cc1["width"],
        _0x4bd16c["height"] - _0x5b1cc1["height"],
      ));
    var _0x4ab316 = new Image();
    ((_0x4ab316["onload"] = function () {
      _0xb35bd0(_0x4ab316);
    }),
      (_0x4ab316["src"] = _0x4bd16c["toDataURL"]()));
  });
}
async function _0x1db0eb(_0x5709e3, _0x3f616d) {
  var _0x28131b = await _0x751656(_0x5709e3);
  _0x28131b = await _0xf69a72(_0x28131b, 0x5dc, 0x5dc);
  var _0x1ac441 = [];
  for (var _0x45b379 = 0x0; _0x45b379 < _0x3f616d["length"]; _0x45b379++) {
    var _0x3d7eb0 = await _0x751656(_0x3f616d[_0x45b379]);
    ((_0x3d7eb0 = await _0xf69a72(
      _0x3d7eb0,
      _0x28131b["width"] / _0x3f616d["length"],
      _0x28131b["height"] / _0x3f616d["length"],
    )),
      _0x1ac441["push"](_0x3d7eb0));
  }
  var _0x55fa20 = _0x1ac441[0x0];
  for (_0x45b379 = 0x0; _0x45b379 < _0x1ac441["length"]; _0x45b379++)
    _0x1ac441[_0x45b379]["width"] > _0x55fa20["width"] &&
      (_0x55fa20 = _0x1ac441[_0x45b379]);
  _0x28131b = await _0x4a5efa(_0x28131b, _0x55fa20["height"], "bottom");
  for (_0x45b379 = 0x0; _0x45b379 < _0x1ac441["length"]; _0x45b379++)
    _0x28131b = await _0xd2b58(
      _0x28131b,
      _0x1ac441[_0x45b379],
      _0x45b379 * (_0x28131b["width"] / _0x1ac441["length"]),
    );
  return _0x28131b;
}
async function _0x31b92f(_0x5ef044, _0x15cff9, _0x30e38a) {
  ((_0x5ef044 = await _0xf69a72(_0x5ef044, 0x5dc, 0x5dc)),
    (_0x5ef044 = await _0x40ffa2(_0x5ef044)));
  var _0x5f1313 = await _0x751656(_0x30e38a);
  ((_0x5f1313 = await _0x40ffa2(_0x5f1313)),
    (_0x5f1313 = await _0xf69a72(_0x5f1313, 0x2a3, 0x2a3)));
  var _0x2936f8 = await _0x751656(_0x15cff9);
  return (
    (_0x2936f8 = await _0xf69a72(_0x2936f8, 0x2a3, 0x2a3)),
    (_0x5ef044 = await _0x1d9f9b(_0x5ef044, _0x2936f8, "right")),
    (_0x2936f8 = await _0xf69a72(_0x2936f8, 0x258, 0x258)),
    (_0x5ef044 = await _0x267114(_0x5ef044, _0x2936f8, 0x1, 0xc)),
    (_0x5f1313 = await _0x2cf69d(
      _0x5f1313,
      0.65 * _0x2936f8["width"],
      0.65 * _0x2936f8["height"],
    )),
    (_0x5f1313 = await _0x59fc80(_0x5f1313)),
    (_0x5ef044 = await _0x3b79fc(_0x5ef044, _0x5f1313, 0.7)),
    (_0x5ef044 = await _0x242a71(_0x5ef044)),
    await _0x561892(_0x5ef044, 0x1f4, 0x1f4)
  );
}
function _0x3d9211(_0xaf5a8f, _0x376c7d) {
  return new Promise((_0x1185ff, _0x3a21c3) => {
    const _0x5affa1 = _0xaf5a8f,
      _0x2156cb = document["createElement"]("canvas");
    ((_0x2156cb["width"] = _0x5affa1["width"]),
      (_0x2156cb["height"] = _0x5affa1["height"]));
    const _0x2f3ec7 = _0x2156cb["getContext"]("2d");
    (_0x2f3ec7["clearRect"](0x0, 0x0, _0x2156cb["width"], _0x2156cb["height"]),
      _0x2f3ec7["save"](),
      _0x2f3ec7["beginPath"](),
      _0x2f3ec7["moveTo"](_0x376c7d, 0x0),
      _0x2f3ec7["lineTo"](_0x2156cb["width"] - _0x376c7d, 0x0),
      _0x2f3ec7["quadraticCurveTo"](
        _0x2156cb["width"],
        0x0,
        _0x2156cb["width"],
        _0x376c7d,
      ),
      _0x2f3ec7["lineTo"](_0x2156cb["width"], _0x2156cb["height"] - _0x376c7d),
      _0x2f3ec7["quadraticCurveTo"](
        _0x2156cb["width"],
        _0x2156cb["height"],
        _0x2156cb["width"] - _0x376c7d,
        _0x2156cb["height"],
      ),
      _0x2f3ec7["lineTo"](_0x376c7d, _0x2156cb["height"]),
      _0x2f3ec7["quadraticCurveTo"](
        0x0,
        _0x2156cb["height"],
        0x0,
        _0x2156cb["height"] - _0x376c7d,
      ),
      _0x2f3ec7["lineTo"](0x0, _0x376c7d),
      _0x2f3ec7["quadraticCurveTo"](0x0, 0x0, _0x376c7d, 0x0),
      _0x2f3ec7["clip"](),
      _0x2f3ec7["drawImage"](
        _0x5affa1,
        0x0,
        0x0,
        _0x2156cb["width"],
        _0x2156cb["height"],
      ),
      _0x2f3ec7["restore"]());
    const _0x227b8c = new Image();
    ((_0x227b8c["onload"] = () => {
      _0x1185ff(_0x227b8c);
    }),
      (_0x227b8c["src"] = _0x2156cb["toDataURL"]()));
  });
}
async function _0x5d43e6(_0x3c4b0d, _0x55c7ca) {
  var _0x4ff7a7 = document["createElement"]("canvas");
  ((_0x4ff7a7["width"] = 0x1f4), (_0x4ff7a7["height"] = 0x1f4));
  var _0xe07d1 = _0x4ff7a7["getContext"]("2d");
  ((_0xe07d1["fillStyle"] = "#E53238"),
    _0xe07d1["fillRect"](0x0, 0x0, _0x4ff7a7["width"], 0x14),
    (_0xe07d1["fillStyle"] = "#0074E8"),
    _0xe07d1["fillRect"](
      _0x4ff7a7["width"] - 0x14,
      0x0,
      0x14,
      _0x4ff7a7["height"],
    ),
    (_0xe07d1["fillStyle"] = "#F5AF02"),
    _0xe07d1["fillRect"](
      0x0,
      _0x4ff7a7["height"] - 0x14,
      _0x4ff7a7["width"],
      0x14,
    ),
    (_0xe07d1["fillStyle"] = "#86B817"),
    _0xe07d1["fillRect"](0x0, 0x0, 0x14, _0x4ff7a7["height"]));
  var _0x5cc1bf = _0x4ff7a7["width"] - 0x28,
    _0x344169 = _0x4ff7a7["height"] - 0x28;
  ((_0xe07d1["fillStyle"] = "#ffffff"),
    _0xe07d1["fillRect"](0x14, 0x14, _0x5cc1bf, _0x344169));
  var _0x2ae188 = "Informationen\x20zur\x20Produktsicherheit";
  ((_0xe07d1["font"] = "bold\x2024px\x20Arial"),
    (_0xe07d1["fillStyle"] = "#000"));
  var _0xda2951 =
    0x14 + (_0x5cc1bf - _0xe07d1["measureText"](_0x2ae188)["width"]) / 0x2;
  (_0xe07d1["fillText"](_0x2ae188, _0xda2951, 0x28),
    (_0xe07d1["strokeStyle"] = "#cccccc"),
    (_0xe07d1["lineWidth"] = 0x1),
    _0xe07d1["beginPath"](),
    _0xe07d1["moveTo"](0x1e, 0x4b),
    _0xe07d1["lineTo"](0x14 + _0x5cc1bf - 0xa, 0x4b),
    _0xe07d1["stroke"]());
  var _0x4bc647 = 0x14 + _0x344169 - 0xa;
  function _0x43014f(
    _0x3da346,
    _0x55c407,
    _0x120932,
    _0x273703,
    _0x307104,
    _0x36ed6d,
    _0x2793dd,
  ) {
    ((_0x3da346["fillStyle"] = "#000"),
      (_0x3da346["font"] = "bold\x2016px\x20Arial"),
      (_0x3da346["textBaseline"] = "top"),
      _0x3da346["fillText"](_0x307104, _0x55c407 + 0x8, _0x120932),
      (_0x120932 += 0x14),
      (_0x3da346["font"] = "14px\x20Arial"));
    var _0x458211 = (function (_0x18070f, _0x3bca09, _0x1070a3) {
      var _0x248035 = _0x3bca09["split"]("\x0a"),
        _0x50aa29 = [];
      for (var _0x54362d = 0x0; _0x54362d < _0x248035["length"]; _0x54362d++) {
        var _0xabe82a = _0x248035[_0x54362d]["split"]("\x20"),
          _0x5a44f7 = "";
        for (
          var _0xcf272e = 0x0;
          _0xcf272e < _0xabe82a["length"];
          _0xcf272e++
        ) {
          var _0x2f88ab = _0x5a44f7 + _0xabe82a[_0xcf272e] + "\x20";
          if (
            _0x18070f["measureText"](_0x2f88ab)["width"] > _0x1070a3 &&
            _0xcf272e > 0x0
          )
            (_0x50aa29["push"](_0x5a44f7["trim"]()),
              (_0x5a44f7 = _0xabe82a[_0xcf272e] + "\x20"));
          else _0x5a44f7 = _0x2f88ab;
        }
        _0x50aa29["push"](_0x5a44f7["trim"]());
      }
      return _0x50aa29;
    })(_0x3da346, _0x36ed6d, _0x273703 - 0x10);
    for (
      var _0x14fac4 = 0x0;
      _0x14fac4 < _0x458211["length"] && !(_0x120932 + 0x10 > _0x2793dd);
      _0x14fac4++
    ) {
      (_0x3da346["fillText"](_0x458211[_0x14fac4], _0x55c407 + 0x8, _0x120932),
        (_0x120932 += 0x10));
    }
    return _0x120932;
  }
  var _0x41f484 = _0x43014f(
    _0xe07d1,
    0x14,
    0x55,
    _0x5cc1bf,
    "Hersteller:",
    _0x3c4b0d,
    0x55 + (0x14 + _0x344169 - 0x55 - 0xa) / 0x2,
  );
  return (
    _0x43014f(
      _0xe07d1,
      0x14,
      (_0x41f484 += 0xa),
      _0x5cc1bf,
      "EU\x20Verantwortliche\u00a0Person:",
      _0x55c7ca,
      _0x4bc647,
    ),
    (_0xe07d1["strokeStyle"] = "#eeeeee"),
    (_0xe07d1["lineWidth"] = 0x2),
    _0xe07d1["strokeRect"](0x14, 0x14, _0x5cc1bf, _0x344169),
    new Promise(function (_0x424c4d) {
      var _0x2a1dc0 = new Image();
      ((_0x2a1dc0["src"] = _0x4ff7a7["toDataURL"]("image/png")),
        (_0x2a1dc0["onload"] = function () {
          _0x424c4d(_0x2a1dc0);
        }));
    })
  );
}
console["log"]("pre_list_display.js\x20loaded");
function _0x318fa6(_0x3a36be) {
  var _0x191505 = document["createElement"]("h2");
  return (
    (_0x191505["id"] = "title_ecom_sniper"),
    (_0x191505["textContent"] = _0x3a36be),
    _0x191505
  );
}
function _0x277e24(_0x64f989) {
  var _0x14d36a = document["createElement"]("div");
  _0x14d36a["id"] = "listTitleContainer";
  var _0x2ae2d8 = document["createElement"]("textarea");
  ((_0x2ae2d8["id"] = "listTitle"),
    (_0x2ae2d8["rows"] = "1"),
    (_0x2ae2d8["cols"] = "50"),
    (_0x2ae2d8["placeholder"] = "Input\x20new\x20title\x20here..."),
    (_0x2ae2d8["textContent"] = _0x64f989));
  var _0x28ae01 = document["createElement"]("div");
  return (
    (_0x28ae01["id"] = "charCount"),
    (_0x28ae01["textContent"] =
      "Characters:\x20" + _0x2ae2d8["value"]["length"] + "/80"),
    _0x2ae2d8["addEventListener"]("input", function () {
      _0x28ae01["textContent"] =
        "Characters:\x20" + _0x2ae2d8["value"]["length"] + "/80";
    }),
    _0x14d36a["appendChild"](_0x2ae2d8),
    _0x14d36a["appendChild"](_0x28ae01),
    _0x14d36a
  );
}
function _0x6f0d48(_0x472f2c) {
  var _0x3f3f8b = document["createElement"]("div");
  _0x3f3f8b["id"] = "listDescriptionContainer";
  var _0x47adb5 = document["createElement"]("h2");
  ((_0x47adb5["textContent"] = "Scraped\x20Description"),
    _0x3f3f8b["appendChild"](_0x47adb5));
  var _0x34d655 = document["createElement"]("p");
  return (
    (_0x34d655["id"] = "listDescription"),
    (_0x34d655["contentEditable"] = "true"),
    (_0x34d655["innerHTML"] = _0x472f2c),
    _0x3f3f8b["appendChild"](_0x34d655),
    _0x3f3f8b
  );
}
function _0x3bf45c(_0x5ee2be) {
  var _0x3db1a8 = document["createDocumentFragment"]();
  for (var _0x528d60 = 0x0; _0x528d60 < _0x5ee2be["length"]; _0x528d60++) {
    var _0x1e11e8 = document["createElement"]("div");
    _0x1e11e8["classList"]["add"]("imageContainer");
    var _0x10c5da = document["createElement"]("img");
    ((_0x10c5da["src"] = _0x5ee2be[_0x528d60]),
      (_0x10c5da["width"] = "100"),
      (_0x10c5da["height"] = "100"));
    var _0x3b8a45 = document["createElement"]("span");
    ((_0x3b8a45["textContent"] = "x"),
      _0x3b8a45["classList"]["add"]("deleteButton"),
      _0x3b8a45["addEventListener"]("click", function (_0x2ffa8d) {
        (_0x2ffa8d["stopPropagation"](), this["parentNode"]["remove"]());
      }),
      _0x10c5da["addEventListener"]("click", function () {
        var _0x4a7edd = document["querySelectorAll"](".highlight");
        for (var _0x2d8246 = 0x0; _0x2d8246 < _0x4a7edd["length"]; _0x2d8246++)
          _0x4a7edd[_0x2d8246]["classList"]["remove"]("highlight");
        this["classList"]["add"]("highlight");
      }),
      _0x10c5da["addEventListener"]("dblclick", _0x3b08af),
      _0x1e11e8["appendChild"](_0x10c5da),
      _0x1e11e8["appendChild"](_0x3b8a45),
      _0x3db1a8["appendChild"](_0x1e11e8));
  }
  return _0x3db1a8;
}
async function _0x5c7179(_0x467a38, _0x52eb9d) {
  console["log"]("mainImage:\x20" + _0x467a38);
  var _0x50583f = await _0x1db0eb(_0x467a38, _0x52eb9d),
    _0x2edf85 = document["createElement"]("div");
  _0x2edf85["classList"]["add"]("imageContainer");
  var _0x33d8b9 = document["createElement"]("img");
  ((_0x33d8b9["src"] = _0x50583f["src"]),
    (_0x33d8b9["width"] = "100"),
    (_0x33d8b9["height"] = "100"));
  var _0x4f2223 = document["createElement"]("span");
  return (
    (_0x4f2223["textContent"] = "x"),
    _0x4f2223["classList"]["add"]("deleteButton"),
    _0x4f2223["addEventListener"]("click", function (_0x38247b) {
      (_0x38247b["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x33d8b9["addEventListener"]("click", function () {
      var _0xeaf4d7 = document["querySelectorAll"](".highlight");
      for (var _0x3b4176 = 0x0; _0x3b4176 < _0xeaf4d7["length"]; _0x3b4176++)
        _0xeaf4d7[_0x3b4176]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x33d8b9["addEventListener"]("dblclick", _0x3b08af),
    _0x2edf85["appendChild"](_0x33d8b9),
    _0x2edf85["appendChild"](_0x4f2223),
    _0x2edf85
  );
}
async function _0x44fd48(_0x25813d, _0x27f3ac, _0x19c3ec) {
  console["log"]("mainImage:\x20" + _0x25813d);
  var _0x27a2bf = await _0x1db0eb(_0x25813d, _0x19c3ec),
    _0x27dfbc = await _0x31b92f(
      _0x27a2bf,
      _0x27f3ac,
      "https://i.imgur.com/DMwAoOA.png",
    ),
    _0x4bab3 = document["createElement"]("div");
  _0x4bab3["classList"]["add"]("imageContainer");
  var _0x3defc8 = document["createElement"]("img");
  ((_0x3defc8["src"] = _0x27dfbc["src"]),
    (_0x3defc8["width"] = "100"),
    (_0x3defc8["height"] = "100"));
  var _0x270de5 = document["createElement"]("span");
  return (
    (_0x270de5["textContent"] = "x"),
    _0x270de5["classList"]["add"]("deleteButton"),
    _0x270de5["addEventListener"]("click", function (_0x5274c0) {
      (_0x5274c0["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x3defc8["addEventListener"]("click", function () {
      var _0x5bc1f5 = document["querySelectorAll"](".highlight");
      for (var _0x373cc2 = 0x0; _0x373cc2 < _0x5bc1f5["length"]; _0x373cc2++)
        _0x5bc1f5[_0x373cc2]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x3defc8["addEventListener"]("dblclick", _0x3b08af),
    _0x3defc8["classList"]["add"]("highlight"),
    _0x4bab3["appendChild"](_0x3defc8),
    _0x4bab3["appendChild"](_0x270de5),
    _0x4bab3
  );
}
async function _0x328eae(_0x4b3e12, _0xc5e823, _0x47f193, _0x26e1c7) {
  var { watermark_url: _0x4d8a8e } =
      await chrome["storage"]["local"]["get"]("watermark_url"),
    _0x283c6b = await _0xd92106(
      _0x4b3e12,
      _0xc5e823,
      _0x4d8a8e,
      _0x47f193,
      _0x26e1c7,
      "imageTitle",
      0x5dc,
      0x5dc,
      "black",
      "arial",
      !0x0,
    ),
    _0x25b359 = document["createElement"]("div");
  _0x25b359["classList"]["add"]("imageContainer");
  var _0x2ec4cd = document["createElement"]("img");
  _0x2ec4cd["src"] = _0x283c6b["src"];
  var _0x12a84 = document["createElement"]("span");
  return (
    (_0x12a84["textContent"] = "x"),
    _0x12a84["classList"]["add"]("deleteButton"),
    _0x12a84["addEventListener"]("click", function (_0x5da188) {
      (_0x5da188["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x2ec4cd["addEventListener"]("click", function () {
      var _0x552e0f = document["querySelectorAll"](".highlight");
      for (var _0x4e7509 = 0x0; _0x4e7509 < _0x552e0f["length"]; _0x4e7509++)
        _0x552e0f[_0x4e7509]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x2ec4cd["addEventListener"]("dblclick", _0x3b08af),
    _0x2ec4cd["classList"]["add"]("highlight"),
    _0x25b359["appendChild"](_0x2ec4cd),
    _0x25b359["appendChild"](_0x12a84),
    _0x25b359
  );
}
function _0x3b08af(_0x8db9f7) {
  var _0x15087b = document["getElementById"]("myModal"),
    _0x2bd43f = document["getElementById"]("img01");
  ((_0x15087b["style"]["display"] = "block"), (_0x2bd43f["src"] = this["src"]));
}
function _0x206e90() {
  document["getElementById"]("myModal")["style"]["display"] = "none";
}
function _0x26aac7(_0x2f0dd4) {
  var _0x3844a2 = document["getElementById"]("myModal");
  _0x2f0dd4["target"] == _0x3844a2 && _0x206e90();
}
function _0x5a4daa(_0x5c9739) {
  var _0x34b749 = document["createElement"]("h3");
  return (
    (_0x34b749["textContent"] = "Scraped\x20Price:\x20$" + _0x5c9739),
    _0x34b749
  );
}
function _0x3b4b77(_0x505648) {
  var _0x7243d = document["createElement"]("h3");
  return (
    (_0x7243d["id"] = "listSku"),
    (_0x7243d["textContent"] = _0x505648),
    _0x7243d
  );
}
function _0x5d559f(_0x2c2b23) {
  var _0x240f67 = document["createElement"]("div");
  _0x240f67["id"] = "listPriceContainer";
  var _0x44b68b = document["createElement"]("label");
  ((_0x44b68b["htmlFor"] = "newPrice"),
    (_0x44b68b["textContent"] = "Price\x20to\x20be\x20listed\x20on\x20eBay:"));
  var _0x102d88 = document["createElement"]("input");
  return (
    (_0x102d88["id"] = "listPrice"),
    (_0x102d88["type"] = "number"),
    (_0x102d88["placeholder"] = "Input\x20new\x20price\x20here..."),
    (_0x102d88["value"] = _0x2c2b23),
    _0x240f67["appendChild"](_0x44b68b),
    _0x240f67["appendChild"](_0x102d88),
    _0x240f67
  );
}
function _0x3bb71b() {
  var _0x3d7c96 = document["createElement"]("button");
  return (
    (_0x3d7c96["id"] = "listOnEbayButton"),
    (_0x3d7c96["textContent"] = "List\x20on\x20eBay"),
    _0x3d7c96["addEventListener"]("click", function () {
      _0x2509cc();
    }),
    _0x3d7c96
  );
}
function _0x5b3a6e() {
  const _0x1e09cf = document["createElement"]("button");
  return (
    (_0x1e09cf["innerHTML"] = "<b>Snipe\x20Title</b>"),
    (_0x1e09cf["id"] = "create-title-v4"),
    _0x1e09cf["classList"]["add"]("create-title-v4"),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x3de4c1) {
        console["log"]("createSnipeTitleButton\x20response:\x20", _0x3de4c1);
        if (_0x3de4c1["creditsAvailable"])
          _0x1e09cf["onclick"] = function () {
            (console["log"]("clicked\x20button"),
              chrome["runtime"]["sendMessage"](
                { type: "checkCredits" },
                async function (_0x4374a8) {
                  console["log"]("response:\x20", _0x4374a8);
                  if (_0x4374a8["creditsAvailable"]) {
                    chrome["runtime"]["sendMessage"]({
                      type: "deductCredits",
                      amount: 0,
                    });
                    var _0x2147f0 =
                        document["querySelector"]("#listTitle")["textContent"],
                      _0x1183ed = document["querySelector"](
                        "#listDescriptionContainer\x20p",
                      )["innerText"];
                    await _0x2e8bac(_0x2147f0, _0x1183ed);
                  } else
                    alert(
                      "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits.",
                    );
                },
              ));
          };
        else
          ((_0x1e09cf["disabled"] = !0x0),
            (_0x1e09cf["innerHTML"] =
              "<b>Snipe\x20Title</b>\x20(No\x20Credits)"),
            (_0x1e09cf["style"]["backgroundColor"] = "grey"));
      },
    ),
    _0x1e09cf
  );
}
async function _0x1137bc() {
  var _0x325888 = document["querySelector"]("#create-title-v4");
  ((_0x325888["disabled"] = !0x0),
    (_0x325888["style"]["backgroundColor"] = "grey"),
    (_0x325888["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    _0x420233(),
    _0x3dfbec(),
    (document["title"] = "Creating\x20The\x20Perfect\x20Title\x20-\x20"),
    _0x2edd6a());
  var _0x33b64b =
      document["querySelector"]("#listTitle")["textContent"] +
      "\x0a" +
      document["querySelector"]("#listDescriptionContainer\x20p")["innerText"],
    _0x32f2d7 = await _0x1d68fc(
      "https://ebaysnipertitlebuilder.ngrok.io/api/TitleBuilder/BuildTitle",
      { request_type: "build_title", product_description: _0x33b64b },
    );
  console["log"]("getAiTitleFromApi\x20data:\x20", _0x32f2d7);
  var _0x4fac60 = _0x32f2d7["title"];
  (console["log"](
    "\x20createTitleV4AndAppendToTable\x20ai_title:\x20",
    _0x4fac60,
  ),
    _0x41785d(chrome["runtime"]["getURL"]("Favicons/Completed/received.png")),
    await new Promise((_0x1fea6c) => setTimeout(_0x1fea6c, 0x3e8)),
    console["log"]("finished\x20waiting\x201\x20second"),
    (document["title"] = "Received\x20Title:\x20\x22" + _0x4fac60 + "\x22"),
    _0x599458(_0x4fac60, "Perfect\x20Title"),
    console["log"]("finished\x20createCellWithTitle"));
  var _0x1ed572 = document["getElementById"]("listing-data-table"),
    _0x4b8f78 =
      _0x1ed572["rows"][_0x1ed572["rows"]["length"] - 0x1]["querySelector"](
        ".title-cell",
      );
  (console["log"]("finished\x20tableRow.querySelector(.title-cell);"),
    _0x4fac60 || (_0x4fac60 = "undefined"),
    _0x3d0db2(_0x4fac60, _0x4b8f78),
    console["log"]("finished\x20flyInText"));
  var _0x25a76e = document["querySelector"]("#listTitle");
  return (
    (_0x25a76e["value"] = _0x4fac60),
    _0x25a76e["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    console["log"]("finished\x20textArea.value\x20=\x20ai_title;"),
    _0x515973(),
    _0x53f2da(),
    await new Promise((_0x37b966) => setTimeout(_0x37b966, 0x7d0)),
    _0x54c694(),
    (_0x325888["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x325888["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x325888["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x325888["disabled"] = !0x1));
    }, 0x7d0),
    _0x4fac60
  );
}
async function _0x2e8bac(_0x772b53, _0x8c6dfa) {
  var _0x14314e = document["querySelector"]("#create-title-v4");
  ((_0x14314e["disabled"] = !0x0),
    (_0x14314e["style"]["backgroundColor"] = "grey"),
    (_0x14314e["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    _0x420233(),
    _0x3dfbec(),
    console["log"]("create10TitlesV3AndAppendToTable"),
    _0x772b53 || (_0x772b53 = getFilteredTitle()),
    _0x8c6dfa || (_0x8c6dfa = getProductDescriptionAndFeatures()));
  var _0x7063cd = await _0x1d68fc(
    "https://suggest-optimized-titles-2-djybcnnsgq-uc.a.run.app",
    {
      request_type: "generate_10_titles",
      product_description: _0x8c6dfa,
      product_title: _0x772b53,
    },
  );
  console["log"]("create10TitlesV3AndAppendToTable\x20data:\x20", _0x7063cd);
  var _0x2213e6 = _0x7063cd;
  if (!_0x2213e6)
    return (
      _0x599458("Error\x20-\x20Try\x20Again", "Perfect\x20Title"),
      _0x515973(),
      _0x53f2da(),
      await new Promise((_0x1a4910) => setTimeout(_0x1a4910, 0x7d0)),
      _0x54c694(),
      (_0x14314e["innerHTML"] = "<b>Sniped\x20Title!</b>"),
      (_0x14314e["style"]["backgroundColor"] = "#3a86ff"),
      setTimeout(function () {
        ((_0x14314e["innerHTML"] = "<b>Snipe\x20Title</b>"),
          (_0x14314e["disabled"] = !0x1));
      }, 0x7d0),
      null
    );
  (Array["isArray"](_0x2213e6) || (_0x2213e6 = [_0x2213e6]),
    (_0x2213e6 = _0x2213e6["filter"](function (_0x2ad2d7) {
      return _0x2ad2d7["trim"]()["length"] > 0x0;
    })["map"](function (_0x5dc911) {
      return _0x5dc911["trim"]();
    })));
  var _0x33822f = "";
  for (var _0x2273b5 = 0x0; _0x2273b5 < _0x2213e6["length"]; _0x2273b5++)
    (_0x772b53 = _0x2213e6[_0x2273b5])["length"] > _0x33822f["length"] &&
      _0x772b53["length"] <= 0x50 &&
      (_0x33822f = _0x772b53);
  0x0 == _0x33822f["length"] && (_0x33822f = _0x2213e6[0x0]);
  for (_0x2273b5 = 0x0; _0x2273b5 < _0x2213e6["length"]; _0x2273b5++) {
    ((_0x772b53 = _0x2213e6[_0x2273b5]),
      console["log"]("title:\x20", _0x772b53));
    if (!(_0x772b53["length"] > 0x5a)) {
      _0x599458(
        _0x772b53,
        _0x33822f == _0x772b53 ? "Perfect\x20Title" : "Great\x20Title",
      );
      var _0xa1a4e5 = document["getElementById"]("listing-data-table");
      (_0x3d0db2(
        _0x772b53,
        _0xa1a4e5["rows"][_0xa1a4e5["rows"]["length"] - 0x1]["querySelector"](
          ".title-cell",
        ),
      ),
        _0x53f2da(),
        await new Promise((_0x476e39) => setTimeout(_0x476e39, 0x12c)),
        _0x54c694());
    }
  }
  var _0xf76ca6 = document["querySelector"]("#the-textarea");
  (_0xf76ca6 || (_0xf76ca6 = document["querySelector"]("#listTitle")),
    (_0xf76ca6["value"] = _0x33822f));
  try {
    updateTheCharacterCountOnTextArea();
  } catch (_0xd8ea8e) {}
  return (
    _0x515973(),
    _0x53f2da(),
    await new Promise((_0x31f9f4) => setTimeout(_0x31f9f4, 0x7d0)),
    _0x54c694(),
    (_0x14314e["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x14314e["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x14314e["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x14314e["disabled"] = !0x1));
    }, 0x7d0),
    _0x33822f
  );
}
async function _0x599458(_0x336489, _0x452fdc) {
  var _0x4b76f4 = document["getElementById"]("listing-data-table"),
    _0x5d838b = _0xda3845(_0x4b76f4);
  (_0x44920a(_0x4b76f4, {
    rowNumber: _0x5d838b,
    cellValue: _0x5d838b,
    headerName: "Rank",
  }),
    _0x44920a(_0x4b76f4, {
      rowNumber: _0x5d838b,
      cellValue: _0x336489,
      headerName: "Title",
    }),
    _0x44920a(_0x4b76f4, {
      rowNumber: _0x5d838b,
      cellValue: _0x452fdc,
      headerName: "Type",
    }),
    _0x44920a(_0x4b76f4, {
      rowNumber: _0x5d838b,
      cellValue: _0x336489["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x5d846c = document["createElement"]("button");
  ((_0x5d846c["innerHTML"] = "Change"),
    (_0x5d846c["onclick"] = function () {
      var _0xda689 = document["querySelector"]("#listTitle");
      ((_0xda689["value"] = _0x336489),
        _0xda689["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
    }),
    _0x507a4e(_0x4b76f4, {
      button: _0x5d846c,
      rowNumber: _0x5d838b,
      headerName: "Action",
    }));
}
async function _0x358d05() {
  _0x3dfbec();
  var _0x1a25c2 = document["querySelectorAll"](".imageContainer\x20img"),
    _0x400f1d = [];
  for (var _0x464686 = 0x0; _0x464686 < _0x1a25c2["length"]; _0x464686++)
    _0x400f1d["push"](_0x1a25c2[_0x464686]["src"]);
  if (_0x400f1d["length"] < 0x4)
    (alert(
      "You\x20need\x204\x20images\x20to\x20generate\x20a\x20quad\x20image",
    ),
      _0x515973());
  else {
    var _0x1c1c17 = await _0x328eae(
      _0x400f1d[0x0],
      _0x400f1d[0x1],
      _0x400f1d[0x2],
      _0x400f1d[0x3],
    );
    (document["querySelector"]("#imagesContainer")["appendChild"](_0x1c1c17),
      _0x515973(),
      _0x53f2da(),
      await new Promise((_0x2531cf) => setTimeout(_0x2531cf, 0x7d0)),
      _0x54c694());
  }
}
async function _0x4042ed() {
  _0x3dfbec();
  var _0x365b6c = document["querySelectorAll"](".imageContainer\x20img"),
    _0x46add7 = [];
  for (var _0x104bc4 = 0x0; _0x104bc4 < _0x365b6c["length"]; _0x104bc4++)
    _0x46add7["push"](_0x365b6c[_0x104bc4]["src"]);
  var _0x42430d = await _0x5c7179(_0x46add7[0x0], _0x46add7);
  (document["querySelector"]("#imagesContainer")["appendChild"](_0x42430d),
    _0x515973(),
    _0x53f2da(),
    await new Promise((_0x2f487b) => setTimeout(_0x2f487b, 0x7d0)),
    _0x54c694());
}
async function _0x2cdeb3(_0x354a78) {
  var _0x30586c = _0x354a78["images"],
    _0x325362 = _0x354a78["title"],
    _0x3e35cb = _0x354a78["price"],
    _0x1158bf = _0x354a78["description"];
  _0x3e35cb = _0x354a78["price"];
  var _0x519efb = _0x354a78["sku"];
  _0x354a78["attributeImages"];
  var _0x6c6ffa = _0x5b3a6e(),
    _0x8547b2 = _0x46e1b0();
  _0x25dbd7();
  var _0x522fe8 = document["createElement"]("div");
  _0x522fe8["id"] = "data-box";
  var _0x277aa8 = document["createElement"]("div");
  _0x277aa8["id"] = "imagesContainer";
  var _0x234062 = _0x3bf45c(_0x30586c);
  (_0x277aa8["appendChild"](_0x234062), _0x522fe8["appendChild"](_0x277aa8));
  var _0x1d2d84 = document["createElement"]("div");
  _0x1d2d84["id"] = "buttonContainer";
  var _0x5557e3 = document["createElement"]("button");
  ((_0x5557e3["innerHTML"] = "Generate\x20Quad\x20Image"),
    (_0x5557e3["id"] = "generateQuadImageButton"),
    (_0x5557e3["onclick"] = async function (_0x44b11a) {
      (_0x44b11a["preventDefault"](),
        (_0x5557e3["disabled"] = !0x0),
        (_0x5557e3["style"]["backgroundColor"] = "grey"),
        await _0x358d05(),
        (_0x5557e3["disabled"] = !0x1),
        (_0x5557e3["style"]["backgroundColor"] = "#4CAF50"));
    }));
  var _0x45a02e = document["createElement"]("button");
  ((_0x45a02e["innerHTML"] = "Create\x20Multi\x20Image"),
    (_0x45a02e["id"] = "createMultiImageButton"),
    (_0x45a02e["onclick"] = async function (_0x2e9918) {
      (_0x2e9918["preventDefault"](),
        (_0x45a02e["disabled"] = !0x0),
        (_0x45a02e["style"]["backgroundColor"] = "grey"),
        await _0x4042ed(),
        (_0x45a02e["disabled"] = !0x1),
        (_0x45a02e["style"]["backgroundColor"] = "#4CAF50"));
    }));
  var _0xf326 = _0x8547b2["cloneNode"](!0x0);
  (_0x1d2d84["appendChild"](_0xf326),
    _0x1d2d84["appendChild"](_0x5557e3),
    _0x1d2d84["appendChild"](_0x45a02e),
    _0x522fe8["appendChild"](_0x1d2d84),
    _0x522fe8["appendChild"](_0x318fa6(_0x325362)),
    _0x522fe8["appendChild"](_0x277e24(_0x325362)),
    _0x522fe8["appendChild"](_0x5d559f(_0x3e35cb)),
    _0x522fe8["appendChild"](_0x8547b2),
    _0x522fe8["appendChild"](_0x6c6ffa),
    _0x522fe8["appendChild"](_0x3bb71b()));
  var _0x36cee7 = _0xd72872();
  (_0x522fe8["appendChild"](_0x36cee7),
    _0x2f5245(_0x36cee7, { headerName: "Rank" }),
    _0x2f5245(_0x36cee7, { headerName: "Type" }),
    _0x2f5245(_0x36cee7, { headerName: "Title" }),
    _0x2f5245(_0x36cee7, { headerName: "Total\x20Characters" }),
    _0x2f5245(_0x36cee7, { headerName: "Action" }));
  var _0x4a53c7 = _0xda3845(_0x36cee7);
  (_0x44920a(_0x36cee7, {
    rowNumber: _0x4a53c7,
    cellValue: _0x4a53c7,
    headerName: "Rank",
  }),
    _0x44920a(_0x36cee7, {
      rowNumber: _0x4a53c7,
      cellValue: _0x325362,
      headerName: "Title",
    }),
    _0x44920a(_0x36cee7, {
      rowNumber: _0x4a53c7,
      cellValue: "Filtered",
      headerName: "Type",
    }),
    _0x44920a(_0x36cee7, {
      rowNumber: _0x4a53c7,
      cellValue: _0x325362["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x597c53 = document["createElement"]("button");
  ((_0x597c53["innerHTML"] = "Change"),
    (_0x597c53["onclick"] = function () {
      var _0x77c908 = document["querySelector"]("#listTitle");
      ((_0x77c908["value"] = _0x325362),
        _0x77c908["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
    }),
    _0x507a4e(_0x36cee7, {
      button: _0x597c53,
      rowNumber: _0x4a53c7,
      headerName: "Action",
    }),
    _0x522fe8["appendChild"](_0x6f0d48(_0x1158bf)),
    _0x522fe8["appendChild"](_0x5a4daa(_0x3e35cb)),
    _0x522fe8["appendChild"](_0x3b4b77(_0x519efb)));
  var _0x2bc69d = document["createElement"]("span");
  ((_0x2bc69d["innerHTML"] = "&times;"),
    _0x2bc69d["classList"]["add"]("close-button"),
    (_0x2bc69d["onclick"] = function () {
      _0x522fe8["remove"]();
    }),
    _0x522fe8["appendChild"](_0x2bc69d),
    document["body"]["insertBefore"](_0x522fe8, document["body"]["firstChild"]),
    document["querySelector"](".imageContainer")
      ["querySelector"]("img")
      ["click"](),
    _0x5e5d4e());
}
function _0x5e5d4e() {
  var _0x54723b = document["getElementById"]("imagesContainer");
  new Sortable(_0x54723b, {
    animation: 0x96,
    chosenClass: "sortable-chosen",
    dragClass: "sortable-drag",
  });
}
function _0x2509cc() {
  (_0x41785d(chrome["runtime"]["getURL"]("Favicons/Completed/right_arrow.png")),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      async function (_0x5ee30b) {
        console["log"]("response:\x20", _0x5ee30b);
        if (_0x5ee30b["creditsAvailable"]) {
          chrome["runtime"]["sendMessage"]({
            type: "deductCredits",
            amount: 0,
          });
          var _0x22560a = document["querySelectorAll"](
              ".imageContainer\x20img",
            ),
            _0x11b559 = [];
          for (
            var _0x42ae21 = 0x0;
            _0x42ae21 < _0x22560a["length"];
            _0x42ae21++
          )
            _0x11b559["push"](_0x22560a[_0x42ae21]["src"]);
          var _0x1f1f7b = document["querySelector"](
              ".imageContainer\x20img.highlight",
            )["src"],
            _0x51c371 = await _0x751656(_0x1f1f7b),
            _0x413557 = {
              title:
                document["querySelector"]("#title_ecom_sniper")["innerText"],
              custom_title: document["querySelector"]("#listTitle")["value"],
              custom_price: document["querySelector"]("#listPrice")["value"],
              descriptionHTML:
                document["querySelector"]("#listDescription")["innerHTML"],
              descriptionText:
                document["querySelector"]("#listDescription")["innerText"],
              main_hd_images: _0x11b559,
              main_sd_images: [],
              selected_image: _0x51c371["src"],
              listingType: "paid2",
              sku: document["querySelector"]("#listSku")["innerText"],
            };
          chrome["runtime"]["sendMessage"](
            { type: "list_to_ebay", product_data: _0x413557 },
            function (_0x328cee) {
              console["log"](_0x328cee["farewell"]);
            },
          );
        } else
          alert(
            "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits\x20to\x20continue\x20listing.",
          );
      },
    ));
}
function _0x25dbd7() {
  const _0x5a6ad4 = document["createElement"]("div");
  ((_0x5a6ad4["id"] = "myModal"), _0x5a6ad4["classList"]["add"]("modal"));
  const _0x2b9811 = document["createElement"]("span");
  (_0x2b9811["classList"]["add"]("close"),
    (_0x2b9811["innerHTML"] = "&times;"),
    _0x5a6ad4["appendChild"](_0x2b9811));
  const _0x1fe51a = document["createElement"]("img");
  (_0x1fe51a["classList"]["add"]("modal-content"),
    (_0x1fe51a["id"] = "img01"),
    _0x5a6ad4["appendChild"](_0x1fe51a),
    document["body"]["appendChild"](_0x5a6ad4),
    document["getElementsByClassName"]("close")[0x0]["addEventListener"](
      "click",
      _0x206e90,
    ),
    window["addEventListener"]("click", _0x26aac7));
}
(console["log"]("lcgfoods.js\x20loaded"),
  document["addEventListener"]("DOMContentLoaded", function () {
    var _0x277e2a = fetchTitle(),
      _0x720580 = fetchDescription(),
      _0x4b69ee = fetchImages(),
      _0x25e925 = fetchIngredients();
    (null != _0x25e925 && (_0x720580 += "<h2>Ingredients</h2>" + _0x25e925),
      _0x2cdeb3({
        title: _0x277e2a,
        description: _0x720580,
        images: _0x4b69ee,
        price: fetchPrice(),
        attributeImages: fetchAttributeImages(),
      }));
  }));
function fetchDescription() {
  return document["querySelector"](".description")["innerHTML"];
}
function fetchTitle() {
  return document["querySelector"]("#body\x20h1")["innerHTML"];
}
function fetchImages() {
  var _0x120f5c = document["querySelectorAll"](".photos\x20img"),
    _0x5e0cad = [];
  for (var _0x4881e4 = 0x1; _0x4881e4 < _0x120f5c["length"]; _0x4881e4++)
    null == _0x120f5c[_0x4881e4]["getAttribute"]("xlarge") ||
      _0x5e0cad["push"](_0x120f5c[_0x4881e4]["getAttribute"]("xlarge"));
  return _0x5e0cad;
}
function fetchIngredients() {
  var _0x5c708e = document["querySelector"]("[id^=\x22ingredients-\x22]");
  return null == _0x5c708e
    ? null
    : _0x5c708e["querySelector"](".modal-body")["innerText"];
}
function fetchPrice() {
  var _0x6ae82c = document["querySelector"]("div.price");
  try {
    return _0x6ae82c["innerText"]["match"](/\d+\.\d+/)[0x0];
  } catch (_0x30d0c9) {
    return null;
  }
}
function fetchAttributeImages() {
  var _0x44d23c = document["querySelector"](".layout_component_246")[
      "querySelectorAll"
    ]("img"),
    _0x275432 = [];
  for (var _0x405bfa = 0x0; _0x405bfa < _0x44d23c["length"]; _0x405bfa++)
    _0x275432["push"](_0x44d23c[_0x405bfa]["getAttribute"]("src"));
  return _0x275432;
}
