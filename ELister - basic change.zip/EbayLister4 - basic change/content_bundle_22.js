console["log"]("content.js\x20loaded");
function _0xae4d78() {
  var _0x39191a = document["createElement"]("button");
  return (
    (_0x39191a["innerHTML"] = "Scrape\x20Keywords"),
    (_0x39191a["id"] = "scrape_keywords_button"),
    _0x39191a["addEventListener"]("click", async function (_0x1c12c7) {
      (_0x1c12c7["preventDefault"](),
        _0x196890("Scraping\x20keywords,\x20please\x20wait..."),
        await _0x49414c(),
        _0x454a00());
      const _0x2c6eb0 = document["querySelector"](".overlay");
      _0x2c6eb0 && _0x2c6eb0["remove"]();
    }),
    _0x39191a
  );
}
function _0xe9a653(_0x159c08, _0xced456, _0xb23f11, _0x375a72) {
  var _0x1b9a71 = document["createElement"]("button");
  return (
    (_0x1b9a71["innerHTML"] = _0xb23f11),
    (_0x1b9a71["id"] = _0x159c08),
    (_0x1b9a71["className"] = _0xced456),
    _0x1b9a71["addEventListener"]("click", async function (_0x67b82f) {
      (_0x67b82f["preventDefault"](),
        _0x196890("Generating\x20random\x20adjective,\x20please\x20wait..."),
        (document["getElementById"]("search-form-amazon-keyword-md")["value"] =
          _0x375a72),
        document["getElementById"]("search-form-amazon-md")
          ["querySelector"]("button")
          ["click"]());
    }),
    _0x1b9a71
  );
}
function _0x196890(_0x3eaa65) {
  const _0x4f96d6 = document["createElement"]("div");
  _0x4f96d6["classList"]["add"]("overlay");
  const _0x4224cf = document["createElement"]("div");
  (_0x4224cf["classList"]["add"]("spinner"),
    _0x4f96d6["appendChild"](_0x4224cf));
  const _0x44e0f2 = document["createElement"]("div");
  ((_0x44e0f2["id"] = "overlay_text"),
    (_0x44e0f2["textContent"] = _0x3eaa65),
    _0x4f96d6["appendChild"](_0x44e0f2),
    document["body"]["appendChild"](_0x4f96d6));
}
document["addEventListener"]("DOMContentLoaded", async function () {
  console["log"]("dom.js\x20loaded");
  var _0x5eecf2 = _0xae4d78(),
    _0x4d6c32 = _0xe9a653(
      "search_adjective",
      "search",
      "Generate\x20Random\x20Adjective",
      await _0x43d81b(),
    ),
    _0xdac0bc = _0xe9a653(
      "search_noun",
      "search",
      "Generate\x20Random\x20Noun",
      await _0x4d52e3(),
    ),
    _0x469933 = document["getElementById"]("search-form-amazon-md");
  (_0x469933["appendChild"](_0x5eecf2),
    _0x469933["appendChild"](_0x4d6c32),
    _0x469933["appendChild"](_0xdac0bc));
});
function _0x3aee10() {
  const _0x256a99 = [],
    _0x1c9a09 = document["getElementsByClassName"]("keyword-panel-keyword");
  for (let _0x184ff5 of _0x1c9a09) _0x256a99["push"](_0x184ff5["innerText"]);
  return _0x256a99["join"]("\x0a");
}
function _0x335ea9(_0x53645d, _0x5b285c, _0x211303 = "") {
  const _0x290f71 = document["createElement"](_0x53645d);
  return (
    (_0x290f71["id"] = _0x5b285c),
    (_0x290f71["innerHTML"] = _0x211303),
    _0x290f71
  );
}
function _0x41a770(_0x3ee0b3, _0x740d78) {
  _0x740d78["forEach"]((_0xe6d5e4) => _0x3ee0b3["appendChild"](_0xe6d5e4));
}
function _0x59423b(_0x4589db) {
  const _0x2a13e6 = _0x335ea9("div", "keyword_modal"),
    _0x5cb434 = _0x335ea9("div", "keyword_modal_content"),
    _0x322c04 = _0x335ea9("div", "keyword_modal_header"),
    _0x4fabd4 = _0x335ea9("div", "keyword_modal_body"),
    _0x48c495 = _0x335ea9("div", "keyword_modal_footer"),
    _0xd14f06 = _0x335ea9("span", "keyword_modal_close", "&times;");
  _0x322c04["appendChild"](_0xd14f06);
  const _0x1310e2 = _0x335ea9(
    "p",
    "keyword_info",
    "Loaded\x20" + _0x4589db["split"]("\x0a")["length"] + "\x20keywords",
  );
  _0x4fabd4["appendChild"](_0x1310e2);
  const _0x2d6248 = _0x335ea9("textarea", "keyword_textarea");
  ((_0x2d6248["value"] = _0x4589db),
    (_0x2d6248["style"]["width"] = "100%"),
    _0x4fabd4["appendChild"](_0x2d6248));
  const _0x57716f = _0x335ea9(
    "button",
    "copy_keywords_button",
    "Copy\x20All\x20Keywords",
  );
  ((_0x57716f["style"]["display"] = "block"),
    (_0x57716f["style"]["margin"] = "auto"),
    _0x48c495["appendChild"](_0x57716f),
    _0x41a770(_0x5cb434, [_0x322c04, _0x4fabd4, _0x48c495]),
    _0x2a13e6["appendChild"](_0x5cb434),
    document["body"]["appendChild"](_0x2a13e6),
    (_0x2a13e6["style"]["display"] = "block"));
}
function _0x36161b() {
  document["getElementById"]("keyword_modal_close")["addEventListener"](
    "click",
    function () {
      document["getElementById"]("keyword_modal")["remove"]();
    },
  );
}
function _0x37d015(_0x3760c7) {
  const _0xe5f867 = document["getElementById"]("copy_keywords_button");
  _0xe5f867["addEventListener"]("click", function () {
    (navigator["clipboard"]["writeText"](_0x3760c7),
      (_0xe5f867["innerHTML"] = "Copied!"));
  });
}
async function _0x454a00() {
  const _0x3cd3ee = _0x3aee10();
  (_0x59423b(_0x3cd3ee),
    _0x36161b(),
    _0x37d015(_0x3cd3ee),
    document["getElementById"]("copy_keywords_button")["click"]());
}
async function _0x49414c() {
  let _0x3551eb = document["querySelector"](".btn-search-results-load-more");
  if (_0x3551eb)
    (_0x3551eb["click"](),
      await new Promise((_0x3bacdb) => setTimeout(_0x3bacdb, 0x1388)),
      await _0x49414c());
  else console["log"]("No\x20more\x20items\x20to\x20load");
}
async function _0x4d52e3() {
  const _0x3f5b54 = await fetch("https://random-word-form.repl.co/random/noun"),
    _0x132369 = await _0x3f5b54["json"]();
  return (console["log"](_0x132369), _0x132369[0x0]);
}
async function _0x43d81b() {
  const _0x108aab = await fetch(
      "https://random-word-form.repl.co/random/adjective",
    ),
    _0x2483d6 = await _0x108aab["json"]();
  return (console["log"](_0x2483d6), _0x2483d6[0x0]);
}
