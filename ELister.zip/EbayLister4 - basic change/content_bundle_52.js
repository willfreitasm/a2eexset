function _0x149311() {
  return new Promise((_0x31f88c) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x31f88c();
      });
    });
  });
}
function _0x27abfb() {
  return new Promise((_0x415b80) => {
    requestIdleCallback(() => {
      _0x415b80();
    });
  });
}
function _0x4db4c4(_0x279663 = 0x3e8) {
  return new Promise((_0x1a36d3, _0x5ede84) => {
    let _0x58b673,
      _0x2eb74e = Date["now"](),
      _0x51e2a9 = !0x1;
    function _0x529e03() {
      if (Date["now"]() - _0x2eb74e > _0x279663)
        (_0x51e2a9 && _0x58b673["disconnect"](), _0x1a36d3());
      else setTimeout(_0x529e03, _0x279663);
    }
    const _0x1c1302 = () => {
        _0x2eb74e = Date["now"]();
      },
      _0x23ae15 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x58b673 = new MutationObserver(_0x1c1302)),
        _0x58b673["observe"](document["body"], _0x23ae15),
        (_0x51e2a9 = !0x0),
        setTimeout(_0x529e03, _0x279663));
    else
      window["onload"] = () => {
        ((_0x58b673 = new MutationObserver(_0x1c1302)),
          _0x58b673["observe"](document["body"], _0x23ae15),
          (_0x51e2a9 = !0x0),
          setTimeout(_0x529e03, _0x279663));
      };
  });
}
async function _0x3d4351() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x4db4c4(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x392aac(_0x36cb65) {
  var _0x286218 = document["querySelector"](".sh-core-header__username");
  _0x286218 && (_0x286218["innerText"] = _0x36cb65);
}
function _0xba8757(_0x3c8730) {
  var _0x5c94eb = document["querySelector"]("#user-name");
  _0x5c94eb && (_0x5c94eb["innerText"] = _0x3c8730);
}
function _0x52143d(_0xa22934) {
  var _0x1fb0ae = document["querySelector"](
    ".site-preferences-top-nav__feedback",
  );
  _0x1fb0ae && (_0x1fb0ae["innerText"] = _0xa22934);
}
function _0xb570b9(_0xf9c548, _0x3d03dd) {
  !(function _0x4f80e6(_0x5f13a0) {
    _0x5f13a0["nodeType"] === Node["TEXT_NODE"]
      ? (_0x5f13a0["nodeValue"] = _0x5f13a0["nodeValue"]["replace"](
          new RegExp(_0xf9c548, "gi"),
          _0x3d03dd,
        ))
      : _0x5f13a0["nodeType"] === Node["ELEMENT_NODE"] &&
        Array["from"](_0x5f13a0["childNodes"])["forEach"](_0x4f80e6);
  })(document["body"]);
}
function _0x36dcc2(_0x18f745, _0x4bce5d) {
  var _0x1cc003 = document["querySelector"]("#gh-uid");
  if (_0x1cc003) {
    var _0x4f9147 = _0x1cc003["innerText"]["replace"](
      new RegExp(_0x18f745, "i"),
      _0x4bce5d,
    );
    _0x1cc003["innerText"] = _0x4f9147;
  }
}
async function _0x558b5a() {
  var { fullName: _0x1704f4 } =
    await chrome["storage"]["local"]["get"]("fullName");
  console["log"](_0x1704f4);
  if (_0x1704f4 && "string" == typeof _0x1704f4) return _0x1704f4;
  var _0x1704f4 = await fetchFullName();
  return (
    console["log"]("Fullname\x20that\x20is\x20fetched:\x20" + _0x1704f4),
    chrome["storage"]["local"]["set"]({ fullName: _0x1704f4 }),
    _0x1704f4
  );
}
async function _0x5c064b() {
  var { storeName: _0x2bc5c3 } =
    await chrome["storage"]["local"]["get"]("storeName");
  if (_0x2bc5c3 && "string" == typeof _0x2bc5c3) return _0x2bc5c3;
  var _0x2bc5c3 = await fetchStoreName();
  return (
    console["log"]("Storename\x20that\x20is\x20fetched:\x20" + _0x2bc5c3),
    chrome["storage"]["local"]["set"]({ storeName: _0x2bc5c3 }),
    _0x2bc5c3
  );
}
async function fetchStoreName() {
  return document["querySelector"](".str-seller-card__user-name")["innerText"][
    "trim"
  ]();
}
async function fetchFullName() {
  return (
    await _0xfd57ad(),
    _0x316f07()["parentElement"]["firstChild"]["innerText"]["trim"]()
  );
}
async function _0xfd57ad() {
  if (!_0x316f07()) {
    var _0x3d069b = document["querySelector"](".gh-identity\x20button");
    _0x3d069b &&
      (_0x3d069b["click"](),
      !_0x316f07() &&
        (await new Promise((_0x55ae4f) => setTimeout(_0x55ae4f, 0x3e8)),
        _0x3d069b["click"]()));
  }
}
function _0x316f07() {
  return document["querySelector"](".gh-identity-signed-in__user-ratings");
}
async function _0x1cf2f2() {
  var { ebayUsername: _0x383be7 } =
    await chrome["storage"]["local"]["get"]("ebayUsername");
  if (_0x383be7 && "string" == typeof _0x383be7) return _0x383be7;
  var _0x383be7 = await fetchUserName();
  return (
    console["log"]("ebayUsername\x20that\x20is\x20fetched:\x20" + _0x383be7),
    chrome["storage"]["local"]["set"]({ ebayUsername: _0x383be7 }),
    _0x383be7
  );
}
async function fetchUserName() {
  return (
    await _0xfd57ad(),
    _0x316f07()["children"][0x0]["innerText"]["trim"]()
  );
}
function _0xa8e542(_0xc2bb28) {
  return _0xc2bb28["charAt"](0x1) + "*****";
}
function _0x48304c(_0xc20eb9, _0x12f676) {
  var _0x57b452 = document["getElementById"]("gh-ug");
  if (_0x57b452) {
    var _0x1981d6 = _0xc20eb9["split"]("\x20"),
      _0x58c730 = _0x57b452["innerText"];
    (_0x1981d6["forEach"]((_0x19ecae) => {
      _0x58c730 = _0x58c730["replace"](new RegExp(_0x19ecae, "i"), _0x12f676);
    }),
      (_0x57b452["innerText"] = _0x58c730));
    var _0x37907f = document["querySelector"]("#gh-un");
    _0x37907f &&
      (_0x37907f["textContent"] = _0x37907f["textContent"]["replace"](
        new RegExp(_0xc20eb9, "i"),
        _0x12f676,
      ));
  }
}
function _0x7b1b2f() {
  var _0x3c049d = document["querySelector"]("#me-badge"),
    _0x3591af =
      _0x3c049d["querySelector"]("a")["innerText"]["charAt"](0x1) + "*****";
  _0x3c049d["querySelector"]("a")["innerText"] = _0x3591af;
}
function _0x62f898() {
  var _0x164a1d = document["querySelector"](
      ".ux-seller-section__item--seller\x20.ux-textspans",
    ),
    _0xfd1717 = _0x164a1d["innerText"]["charAt"](0x1) + "*****";
  _0x164a1d["innerText"] = _0xfd1717;
}
function _0x198583(_0x9e23e6) {
  var _0x462f1a = document["querySelector"]("[data-test-id=\x22user-name\x22]");
  _0x462f1a && (_0x462f1a["innerText"] = _0x9e23e6);
}
function _0x498a5f() {
  var _0x33a2c6 = document["querySelector"](".mbg-id"),
    _0x2d9d92 = _0x33a2c6["innerText"]["charAt"](0x1) + "*****";
  _0x33a2c6["innerText"] = _0x2d9d92;
}
function _0x573b92() {
  var _0x5ad56b = document["querySelector"](".m-top-nav__username"),
    _0x179da7 = _0x5ad56b["innerText"]["charAt"](0x1) + "*****";
  _0x5ad56b["innerText"] = _0x179da7;
}
function _0x2099cb() {
  [
    ".shipping-address\x20.address",
    ".phone.ship-itm",
    ".note-content",
    "#amazonEmail",
    "#amazonOrderNumber",
    ".order-info",
    ".clipboard-key",
    ".item__buyer-name",
    ".item__order-number",
    ".user-note",
    ".lineItemCardInfo__sku",
    ".gh-identity",
    ".details",
    ".page-header__user-profile-bookmark",
    ".ux-layout-section__item--table-view",
  ]["forEach"]((_0x101432) => {
    document["querySelectorAll"](_0x101432)["forEach"]((_0x3c33da) => {
      ((_0x3c33da["style"]["filter"] = "blur(5px)"),
        (_0x3c33da["style"]["pointerEvents"] = "none"));
    });
  });
}
async function _0x360c3d() {
  return await new Promise(function (_0x42c47c, _0x40ab6d) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x383682) {
        (console["log"]("result:\x20", _0x383682["membership"]),
          _0x42c47c(_0x383682["membership"]));
      },
    );
  });
}
async function _0x2eb5ba() {
  return await new Promise(function (_0x4227de, _0x494908) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x2741e4) {
        (console["log"]("result:\x20", _0x2741e4["creditsAvailable"]),
          _0x4227de(_0x2741e4["creditsAvailable"]));
      },
    );
  });
}
async function _0x2f5635(_0x358749) {
  if ("ultimate" != (await _0x360c3d()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x2eb5ba()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
console["log"]("ebay/mesh_order_details/functions.js");
async function _0x3c6890(_0x35f87d = document) {
  var _0x57992d = null,
    _0x9970a6 = _0x35f87d["querySelector"](".lineItemCardInfo__sku.spaceTop");
  if (_0x9970a6)
    return (
      (!(_0x57992d =
        _0x9970a6["querySelectorAll"](".sh-secondary")[0x1]["innerText"])[
        "startsWith"
      ]("B") &&
        isNaN(_0x57992d["charAt"](0x0))) ||
        (_0x57992d = btoa(_0x57992d)),
      _0x57992d
    );
  return _0x57992d;
}
function _0x545ada(_0x528886 = document) {
  var _0x9a6419 = _0x528886["querySelector"](".soldPrice__value")["innerText"];
  return (_0x9a6419 = _0x9a6419["replace"](/[^0-9.-]+/g, ""))["replace"](
    ",",
    ".",
  );
}
function _0x1c56c1(_0x4ae48a = document) {
  return _0x4ae48a["querySelectorAll"](
    ".order-info\x20.info-item\x20.info-value",
  )[0x0]["innerText"];
}
function _0x2105f6(_0x4b70aa = document) {
  return (_0xe2522("Date\x20sold", _0x4b70aa) ||
    _0xe2522("Verkauft\x20am", _0x4b70aa) ||
    _0xe2522("Sold", _0x4b70aa) ||
    _0xe2522("Verkauft", _0x4b70aa))["parentElement"]["nextElementSibling"][
    "querySelector"
  ](".info-value")["innerText"];
}
function _0x1397dd(_0x4a72c9 = document) {
  return _0x4a72c9["querySelector"](".item-tile")["innerText"];
}
function _0x452b58(_0xc161e9 = document) {
  return _0xc161e9["querySelector"](".quantity__value\x20.sh-bold")[
    "innerText"
  ];
}
function _0x4ac399(_0x1bd644 = document) {
  return _0x1bd644["querySelector"](
    ".payment-info\x20.earnings\x20.total\x20.amount\x20.sh-bold",
  )["innerText"];
}
function _0xe2522(_0x414eb7, _0xb1e2f2 = document) {
  const _0x331094 = _0xb1e2f2["querySelectorAll"]("*");
  for (let _0x2f6f82 of _0x331094)
    if (_0x2f6f82["innerText"] === _0x414eb7) return _0x2f6f82;
  return null;
}
function _0xe6585a(_0x4ac8eb = document) {
  const _0x5cd1e6 = findFeeItemWith2Negatives(_0x4ac8eb);
  return _0x5cd1e6 ? _0x53b649(_0x217a5e(_0x5cd1e6)[0x0]) : "0";
}
function _0x33561c(_0x5416b9 = document) {
  const _0x53a91a = findFeeItemWith2Negatives(_0x5416b9);
  return _0x53a91a ? _0x53b649(_0x217a5e(_0x53a91a)[0x1]) : "0";
}
function findFeeItemWith2Negatives(_0x2fbac8 = document) {
  const _0x3f171c = _0x2fbac8["querySelectorAll"](".earnings\x20.data-item");
  for (const _0x1590f2 of _0x3f171c)
    if (0x2 === _0x217a5e(_0x1590f2)["length"]) return _0x1590f2;
  return null;
}
function _0x217a5e(_0x3bf117) {
  return Array["from"](
    _0x3bf117["querySelectorAll"](".level-2\x20.amount\x20.value"),
  )
    ["map"]((_0x18d0de) => _0x18d0de["textContent"]["trim"]())
    ["filter"]((_0x145a75) => _0x145a75["startsWith"]("-"));
}
function _0x53b649(_0x49b14a) {
  if (!_0x49b14a || "0" === _0x49b14a) return "0";
  const _0x3b2f03 = _0x49b14a["match"](
    /[-–]\s*([A-Za-z]{1,3}\s?\$)\s*([\d.,]+)/,
  );
  return _0x3b2f03 ? _0x3b2f03[0x1] + _0x3b2f03[0x2] : "0";
}
async function _0x39f436(_0x17a5b8 = document) {
  const _0x48bf4a = _0x17a5b8["querySelector"](".shipping-address\x20.address");
  if (!_0x48bf4a) {
    console["log"]("No\x20shipping\x20address\x20element\x20found.");
    return;
  }
  const _0x5644a8 = Array["from"](_0x48bf4a["querySelectorAll"]("div"));
  let _0x9bc98e = "",
    _0x534180 = "",
    _0x76158a = "",
    _0x2d23d8 = "",
    _0x4b6c62 = "",
    _0x22fe08 = "",
    _0x568cf0 = "";
  function _0x50f3bb(_0x366bd0, _0x201624) {
    const _0x33a0bb = _0x366bd0["querySelectorAll"](".copy-to-clipboard");
    if (!_0x33a0bb[_0x201624]) return "";
    const _0x459ead = _0x33a0bb[_0x201624]["querySelector"]("button");
    if (!_0x459ead) return "";
    for (let _0x55a10e of _0x459ead["childNodes"])
      if (
        _0x55a10e["nodeType"] === Node["TEXT_NODE"] &&
        _0x55a10e["textContent"]["trim"]()
      )
        return _0x55a10e["textContent"]["trim"]();
    return "";
  }
  _0x5644a8[0x0] &&
    ((_0x9bc98e = _0x50f3bb(_0x5644a8[0x0], 0x0)),
    (_0x9bc98e = _0x9bc98e["replace"](
      /[^a-zA-Z0-9äöüÄÖÜßéÉèÈáÁàÀúÚóÓíÍüÜñÑ#,\-./ ]/g,
      "",
    )),
    (_0x9bc98e = _0x9bc98e["replace"](/\s+/g, "\x20")["trim"]()));
  _0x5644a8[0x1] && (_0x534180 = _0x50f3bb(_0x5644a8[0x1], 0x0));
  if (_0x5644a8[0x2]) {
    const _0x206add =
      _0x5644a8[0x2]["querySelectorAll"](".copy-to-clipboard")["length"];
    if (_0x206add <= 0x1) _0x76158a = _0x50f3bb(_0x5644a8[0x2], 0x0);
    else
      0x2 === _0x206add
        ? ((_0x22fe08 = _0x50f3bb(_0x5644a8[0x2], 0x0)),
          (_0x2d23d8 = _0x50f3bb(_0x5644a8[0x2], 0x1)))
        : ((_0x2d23d8 = _0x50f3bb(_0x5644a8[0x2], 0x0)),
          (_0x4b6c62 = _0x50f3bb(_0x5644a8[0x2], 0x1)),
          (_0x22fe08 = _0x50f3bb(_0x5644a8[0x2], 0x2)));
  }
  if (_0x76158a && _0x5644a8[0x3]) {
    const _0x35bcb1 =
      _0x5644a8[0x3]["querySelectorAll"](".copy-to-clipboard")["length"];
    if (0x2 === _0x35bcb1)
      ((_0x22fe08 = _0x50f3bb(_0x5644a8[0x3], 0x0)),
        (_0x2d23d8 = _0x50f3bb(_0x5644a8[0x3], 0x1)));
    else
      0x3 === _0x35bcb1 &&
        ((_0x2d23d8 = _0x50f3bb(_0x5644a8[0x3], 0x0)),
        (_0x4b6c62 = _0x50f3bb(_0x5644a8[0x3], 0x1)),
        (_0x22fe08 = _0x50f3bb(_0x5644a8[0x3], 0x2)));
  }
  const _0x4528e2 = _0x5644a8["length"] - 0x1;
  _0x4528e2 >= 0x0 && (_0x568cf0 = _0x50f3bb(_0x5644a8[_0x4528e2], 0x0));
  let _0x237c29 = "";
  const _0x1ae18e = _0x17a5b8["querySelector"](".phone.ship-itm");
  _0x1ae18e && (_0x237c29 = _0x50f3bb(_0x1ae18e, 0x0));
  /^ebay:[^\s]+$/i["test"](_0x534180) &&
    ((_0x534180 = _0x76158a), (_0x76158a = ""));
  ((_0x534180 = _0x534180["replace"](/\bebay\w*/gi, "")["trim"]()),
    (_0x76158a = _0x76158a["replace"](/\bebay\w*/gi, "")["trim"]()),
    console["log"]({
      name: _0x9bc98e,
      line_1: _0x534180,
      line_2: _0x76158a,
      city: _0x2d23d8,
      state: _0x4b6c62,
      zip: _0x22fe08,
      country: _0x568cf0,
      phone: _0x237c29,
    }));
  var {
    useCustomAmazonPhoneNumber: _0x12f401,
    customAmazonPhoneNumber: _0x56b613,
  } = await chrome["storage"]["local"]["get"]([
    "useCustomAmazonPhoneNumber",
    "customAmazonPhoneNumber",
  ]);
  return (
    _0x12f401 &&
      _0x56b613 &&
      _0x56b613["trim"]()["length"] > 0x0 &&
      (_0x237c29 = _0x56b613["trim"]()),
    {
      phone: _0x237c29,
      name: _0x9bc98e,
      address: {
        line_1: _0x534180,
        line_2: _0x76158a,
        city: _0x2d23d8,
        state: _0x4b6c62,
        zip: _0x22fe08,
        country: _0x568cf0,
      },
    }
  );
}
async function _0x30c030(_0x59566c = document) {
  var _0x4e3a26 = {};
  (console["log"]("Initialized\x20orderDetails:", _0x4e3a26),
    (_0x4e3a26["itemName"] = _0x1397dd(_0x59566c)),
    console["log"]("Item\x20Name:", _0x4e3a26["itemName"]),
    (_0x4e3a26["dateOfSale"] = _0x2105f6(_0x59566c)),
    console["log"]("Date\x20of\x20Sale:", _0x4e3a26["dateOfSale"]),
    (_0x4e3a26["ebayOrderNumber"] = _0x1c56c1(_0x59566c)),
    console["log"]("eBay\x20Order\x20Number:", _0x4e3a26["ebayOrderNumber"]),
    (_0x4e3a26["quantitySold"] = _0x452b58(_0x59566c)),
    console["log"]("Quantity\x20Sold:", _0x4e3a26["quantitySold"]),
    (_0x4e3a26["orderEarnings"] = _0x1c02cf(_0x4ac399(_0x59566c))),
    console["log"]("Order\x20Earnings:", _0x4e3a26["orderEarnings"]),
    (_0x4e3a26["soldPrice"] = _0x1c02cf(_0x545ada(_0x59566c))),
    (_0x4e3a26["ebayFees"] = _0x1c02cf(_0xe6585a(_0x59566c))),
    (_0x4e3a26["addFee"] = _0x1c02cf(_0x33561c(_0x59566c))));
  var _0x26ddac = await _0x3c6890(_0x59566c);
  ((_0x4e3a26["ebaySku"] = _0x26ddac),
    console["log"]("eBay\x20SKU:", _0x4e3a26["ebaySku"]));
  var _0x3f4b26 = await _0x39f436(_0x59566c);
  ((_0x4e3a26["customer"] = _0x3f4b26),
    console["log"]("Customer:", _0x4e3a26["customer"]));
  var { domain: _0x59ff75 } = await chrome["storage"]["local"]["get"]("domain");
  ((_0x4e3a26["domain"] = _0x59ff75),
    console["log"]("Domain:", _0x4e3a26["domain"]));
  try {
    var _0x4c3832 = getFulfillmentDetails();
    if (_0x4c3832) {
      _0x4e3a26 = { ..._0x4e3a26, ..._0x4c3832 };
      var _0x3e5e70 = await calculateProfit(
        _0x4e3a26["orderEarnings"],
        _0x4e3a26["totalBeforeTax"],
        _0x4e3a26["totalTax"],
        _0x4e3a26["amazonDomain"],
      );
      (console["log"]("Profit:", _0x3e5e70), (_0x4e3a26["profit"] = _0x3e5e70));
    }
    var _0x50e918 = getRemark();
    _0x50e918 && (_0x4e3a26["remarks"] = _0x50e918);
    var _0x447cd8 = _0x59566c["querySelector"]("#googleSheetRowNumber");
    _0x447cd8 && (_0x4e3a26["googleSheetRowNumber"] = _0x447cd8["value"]);
  } catch (_0x2b63a7) {}
  var { email: _0x173e83 } = await chrome["storage"]["local"]["get"]("email");
  _0x4e3a26["email"] = _0x173e83;
  var _0x594d98 = await _0x1cf2f2();
  return ((_0x4e3a26["ebayUsername"] = _0x594d98), _0x4e3a26);
}
function _0x1c02cf(_0x11d2b7) {
  if (!_0x11d2b7) return null;
  let _0x1c85f4 = _0x11d2b7["replace"](/[^\d.,-]/g, "")["trim"]();
  if (
    _0x1c85f4["includes"](",") &&
    _0x1c85f4["lastIndexOf"](",") > _0x1c85f4["lastIndexOf"](".")
  )
    ((_0x1c85f4 = _0x1c85f4["replace"](/\./g, "")),
      (_0x1c85f4 = _0x1c85f4["replace"](",", ".")));
  else _0x1c85f4 = _0x1c85f4["replace"](/,/g, "");
  const _0x33a1ff = parseFloat(_0x1c85f4);
  return isNaN(_0x33a1ff) ? null : _0x33a1ff;
}
console["log"]("ebay_order_history\x20functions.js\x20loaded");
async function _0x4cc5e1(_0x282d1) {
  const _0x47408d = "https://www.ebay.com/sh/ord/details?orderid=" + _0x282d1;
  try {
    const _0x19b0bb = await fetchHtmlPage(_0x47408d);
    console["log"]("Fetched\x20HTML:", _0x19b0bb);
    const _0x54a05a = new DOMParser()["parseFromString"](
      _0x19b0bb,
      "text/html",
    );
    return await _0x30c030(_0x54a05a);
  } catch (_0x13473f) {
    return (
      console["error"]("Failed\x20to\x20fetch\x20order:", _0x13473f),
      null
    );
  }
}
function fetchHtmlPage(_0x272ef8) {
  return new Promise((_0x471503, _0x1bd590) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchPageHtml", url: _0x272ef8 },
      (_0x1b35c1) => {
        _0x1b35c1?.["error"]
          ? _0x1bd590(_0x1b35c1["error"])
          : _0x471503(_0x1b35c1["html"]);
      },
    );
  });
}
function _0x13bca7(_0x54486c, _0x13119b = "success") {
  const _0x298c18 = _0x54486c["ebayOrderNumber"];
  let _0x1ca97a = document["getElementById"]("orderId_" + _0x298c18);
  if (!_0x1ca97a) {
    const _0x16ebfe = document["querySelectorAll"]("tr");
    for (let _0x573e62 of _0x16ebfe)
      if (_0x573e62["textContent"]["includes"](_0x298c18)) {
        const _0x3ee932 = _0x573e62["querySelector"](".actions-cell");
        if (_0x3ee932) {
          ((_0x1ca97a = document["createElement"]("div")),
            (_0x1ca97a["id"] = "orderId_" + _0x298c18),
            (_0x1ca97a["className"] = "order-details"),
            (_0x1ca97a["dataset"]["orderId"] = _0x298c18),
            _0x3ee932["appendChild"](_0x1ca97a));
          break;
        }
      }
  }
  !_0x1ca97a &&
    ((_0x1ca97a = document["createElement"]("div")),
    (_0x1ca97a["id"] = "orderId_" + _0x298c18),
    (_0x1ca97a["className"] = "order-details"),
    (_0x1ca97a["dataset"]["orderId"] = _0x298c18),
    document["body"]["insertBefore"](
      _0x1ca97a,
      document["body"]["firstChild"],
    ));
  _0x1ca97a["dataset"]["status"] = _0x13119b;
  const _0x48e16e = _0x54486c?.["customer"]?.["name"] || "",
    _0x558a82 = _0x54486c?.["customer"]?.["address"] || {},
    _0x146026 = _0x54486c?.["customer"]?.["phone"] || "",
    _0x5d62bc = [_0x558a82["line_1"], _0x558a82["line_2"]]
      ["filter"](Boolean)
      ["join"](",\x20"),
    _0x2d2841 = [_0x558a82["city"], _0x558a82["state"], _0x558a82["zip"]]
      ["filter"](Boolean)
      ["join"](",\x20");
  _0x1ca97a["innerHTML"] =
    "\x0a\x20\x20\x20\x20<div\x20class=\x22order-status-icon\x20" +
    _0x13119b +
    "\x22></div>\x0a\x20\x20\x20\x20<div\x20class=\x22order-fields\x22>\x0a\x20\x20\x20\x20\x20\x20" +
    (_0x48e16e
      ? "<div\x20class=\x22order-line\x20order-name\x22>" + _0x48e16e + "</div>"
      : "") +
    "\x0a\x20\x20\x20\x20\x20\x20" +
    (_0x5d62bc
      ? "<div\x20class=\x22order-line\x20order-address\x22>" +
        _0x5d62bc +
        "</div>"
      : "") +
    "\x0a\x20\x20\x20\x20\x20\x20" +
    (_0x2d2841
      ? "<div\x20class=\x22order-line\x20order-citystatezip\x22>" +
        _0x2d2841 +
        "</div>"
      : "") +
    "\x0a\x20\x20\x20\x20\x20\x20" +
    (_0x558a82["country"]
      ? "<div\x20class=\x22order-line\x20order-country\x22>" +
        _0x558a82["country"] +
        "</div>"
      : "") +
    "\x0a\x20\x20\x20\x20\x20\x20" +
    (_0x146026
      ? "<div\x20class=\x22order-line\x20order-phone\x22>" +
        _0x146026 +
        "</div>"
      : "") +
    "\x0a\x20\x20\x20\x20</div>\x0a\x20\x20";
}
function _0x567887() {
  const _0x5bffe5 = document["querySelectorAll"]("[id^=\x22RecordNumber\x22]"),
    _0x1f465a = new Set();
  return (
    _0x5bffe5["forEach"]((_0x3c1970) => {
      const _0x3c9a44 = _0x3c1970["innerText"]["match"](/\d{2}-\d{5}-\d{5}/);
      _0x3c9a44 && _0x1f465a["add"](_0x3c9a44[0x0]);
    }),
    Array["from"](_0x1f465a)
  );
}
async function _0x590a7a(_0x307588) {
  for (let _0x297e4e of _0x307588) {
    const _0x1d51ab = createLoadingBlock(_0x297e4e);
    document["body"]["appendChild"](_0x1d51ab);
    try {
      const _0x1f8fd7 = await _0x4cc5e1(_0x297e4e);
      (_0x43b253(_0x1d51ab),
        _0x13bca7(_0x1f8fd7, _0x1d51ab["querySelector"](".order-text")));
    } catch (_0x233b1f) {
      _0xe96f7f(_0x1d51ab);
    }
  }
}
function _0x567887() {
  const _0x2a0623 = [...document["querySelectorAll"]("tr")],
    _0x294ad2 = new Set();
  for (const _0x31db6d of _0x2a0623) {
    const _0x3a635c = _0x31db6d["textContent"]["match"](/\d{2}-\d{5}-\d{5}/);
    _0x3a635c && _0x294ad2["add"](_0x3a635c[0x0]);
  }
  return [..._0x294ad2];
}
function _0x46919e(_0x4d2560) {
  const _0x79c31a = document["createElement"]("div");
  _0x79c31a["className"] = "order-block";
  const _0x1bc95e = document["createElement"]("div");
  ((_0x1bc95e["className"] = "order-status"),
    (_0x1bc95e["innerHTML"] = "<span\x20class=\x22spinner\x22></span>"));
  const _0x177582 = document["createElement"]("div");
  return (
    (_0x177582["className"] = "order-text"),
    (_0x177582["textContent"] =
      "Fetching\x20details\x20for\x20" + _0x4d2560 + "..."),
    _0x79c31a["appendChild"](_0x1bc95e),
    _0x79c31a["appendChild"](_0x177582),
    _0x79c31a
  );
}
function _0x43b253(_0x567a6) {
  _0x567a6["querySelector"](".order-status")["innerHTML"] =
    "<span\x20class=\x22success-check\x22>✔️</span>";
}
function _0xe96f7f(_0xd27c8d) {
  _0xd27c8d["querySelector"](".order-status")["innerHTML"] =
    "<span\x20class=\x22error-x\x22>❌</span>";
}
document["addEventListener"]("DOMContentLoaded", async () => {
  var { autoDisplayAddress: _0x14d44f } =
    await chrome["storage"]["local"]["get"]("autoDisplayAddress");
  if (!_0x14d44f) return;
  const _0x43708e = _0x567887();
  for (const _0x3a787a of _0x43708e)
    _0x13bca7(
      { ebayOrderNumber: _0x3a787a, customer: { address: {} } },
      "loading",
    );
  const fetchPromises = _0x43708e["map"]((_0x26643e) =>
    _0x4cc5e1(_0x26643e)
      ["then"]((_0x1ec30a) => {
        _0x1ec30a
          ? _0x13bca7(_0x1ec30a, "success")
          : _0x13bca7(
              { ebayOrderNumber: _0x26643e, customer: { address: {} } },
              "error",
            );
      })
      ["catch"]((_0x4d8858) => {
        _0x13bca7(
          { ebayOrderNumber: _0x26643e, customer: { address: {} } },
          "error",
        );
      }),
  );
  await Promise["all"](fetchPromises);
});
