function _0x2ab2f7(_0x401e93, _0x3d6198) {
  return (
    console["log"]("test\x20save\x20to\x20local\x20storage"),
    console["log"]("key\x20" + _0x401e93 + ",\x20value\x20" + _0x3d6198),
    new Promise((_0x5d9558, _0x3c4293) => {
      chrome["storage"]["local"]["set"](
        { [_0x401e93]: _0x3d6198 },
        function () {
          (console["log"]("my\x20key", _0x401e93),
            chrome["storage"]["local"]["get"](_0x401e93, function (_0x39201e) {
              (console["log"](
                "the\x20Value\x20currently\x20is\x20",
                _0x39201e[_0x401e93],
              ),
                _0x5d9558());
            }));
        },
      );
    })
  );
}
function _0x3a2311(_0x3d3b85) {
  return new Promise((_0x3ddb4e, _0x3cb3f2) => {
    chrome["storage"]["local"]["get"](_0x3d3b85, function (_0x108b1c) {
      (console["log"]("Value\x20currently\x20is\x20", _0x108b1c[_0x3d3b85]),
        _0x3ddb4e(_0x108b1c[_0x3d3b85]));
    });
  });
}
const _0x20c6f1 = { URL: "URL", BASE_64: "BASE_64" };
console["log"]("image_utils.js");
async function _0x5665ae(_0x57eb5d) {
  if (!_0x57eb5d) throw new Error("Image\x20URL\x20is\x20required");
  var _0x584ca9 = (_0x584ca9 = await _0x47d8f1(_0x57eb5d))["b64Image"];
  return await b64ToCanvas(_0x584ca9);
}
function _0x47d8f1(_0x173abb) {
  return new Promise((_0x298024, _0x38f1b9) => {
    chrome["runtime"]["sendMessage"](
      { type: "url-to-b64", url: _0x173abb },
      (_0x3a2d75) => {
        _0x3a2d75 && _0x3a2d75["error"]
          ? _0x38f1b9(new Error(_0x3a2d75["error"]))
          : _0x298024(_0x3a2d75);
      },
    );
  });
}
const _0x571b41 = (_0x2af4ed, _0x556f9f) => {
    ((trimmedString = _0x2af4ed),
      _0x2af4ed["startsWith"]("data") &&
        (trimmedString = _0x2af4ed["split"](",")[0x1]));
    const _0x281848 = atob(trimmedString),
      _0x1bceb1 = new ArrayBuffer(_0x281848["length"]),
      _0x5b1f8a = new Uint8Array(_0x1bceb1);
    for (let _0x4e832a = 0x0; _0x4e832a < _0x281848["length"]; _0x4e832a++)
      _0x5b1f8a[_0x4e832a] = _0x281848["charCodeAt"](_0x4e832a);
    const _0x40a70a = new Blob([_0x1bceb1], { type: "image/jpeg" });
    return new File([_0x40a70a], _0x556f9f, {
      lastModified: new Date()["getTime"](),
      type: "image/jpeg",
    });
  },
  _0x6878a5 = (_0x2887ad, _0x5bc2e7) => {
    const _0x204d46 = new DataTransfer();
    (_0x204d46["items"]["add"](_0x2887ad),
      (_0x5bc2e7["files"] = _0x204d46["files"]));
    const _0x40c921 = new Event("change", { bubbles: !0x0 });
    _0x5bc2e7["dispatchEvent"](_0x40c921);
  };
var _0x117209 = async (_0xdc261d, _0x1a42c4, _0x2c93e5, _0x17e34a) => {
  let _0x17a3c9;
  if (_0x17e34a == _0x20c6f1["URL"]) {
    const { b64Image: _0x2a529a } = await _0x47d8f1(_0xdc261d);
    _0x17a3c9 = _0x571b41(_0x2a529a, _0x2c93e5);
  }
  _0x17e34a == _0x20c6f1["BASE_64"] &&
    (_0x17a3c9 = _0x571b41(_0xdc261d, _0x2c93e5));
  var _0x3da030 = document["querySelector"](_0x1a42c4);
  _0x6878a5(_0x17a3c9, _0x3da030);
};
(console["log"]("Sending\x20message\x20to\x20pageLoaded"),
  window["parent"]["postMessage"]({ pageLoaded: !0x0 }, "*"),
  window["addEventListener"]("message", (_0x87dacc) => {
    JSON["stringify"](_0x87dacc["data"]);
    if ("window_upload_pic_to_ebay_iframe" === _0x87dacc["data"]["type"]) {
      var _0x4c5246 = _0x87dacc["data"]["imageObject"];
      _0x117209(
        _0x4c5246["b64Image"],
        _0x4c5246["inputTagSelector"],
        _0x4c5246["imageName"],
        _0x20c6f1["BASE_64"],
      );
    }
  }));
async function _0x47d43b() {
  var _0xf4cc87 = await _0x5665ae(
    "https://m.media-amazon.com/images/I/81mA9Fo-S5L._AC_SL1500_.jpg",
  );
  try {
    chrome["storage"]["local"]["get"]("amazon", function (_0x5b1d40) {
      var _0x2caea0 =
        _0x5b1d40["amazon"]["filteredTitle"]["substring"](0x0, 0x64) + "-0.jpg";
      _0x117209(
        _0xf4cc87["src"],
        "input[id^=\x27upl-\x27]",
        _0x2caea0,
        _0x20c6f1["BASE_64"],
      );
    });
  } catch (_0x1a37d2) {
    console["log"](window["location"]["hostname"], _0x1a37d2);
  }
}
