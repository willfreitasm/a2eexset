function _0x26482a() {
  return new Promise((_0x4dce7a) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x4dce7a();
      });
    });
  });
}
function _0x3a820b() {
  return new Promise((_0x461b81) => {
    requestIdleCallback(() => {
      _0x461b81();
    });
  });
}
function _0x2055ab(_0x219168 = 0x3e8) {
  return new Promise((_0x31d0b5, _0x55c01c) => {
    let _0x47052,
      _0x58a7b8 = Date["now"](),
      _0xc98dc9 = !0x1;
    function _0x3991fa() {
      if (Date["now"]() - _0x58a7b8 > _0x219168)
        (_0xc98dc9 && _0x47052["disconnect"](), _0x31d0b5());
      else setTimeout(_0x3991fa, _0x219168);
    }
    const _0xa45015 = () => {
        _0x58a7b8 = Date["now"]();
      },
      _0x4e03a9 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x47052 = new MutationObserver(_0xa45015)),
        _0x47052["observe"](document["body"], _0x4e03a9),
        (_0xc98dc9 = !0x0),
        setTimeout(_0x3991fa, _0x219168));
    else
      window["onload"] = () => {
        ((_0x47052 = new MutationObserver(_0xa45015)),
          _0x47052["observe"](document["body"], _0x4e03a9),
          (_0xc98dc9 = !0x0),
          setTimeout(_0x3991fa, _0x219168));
      };
  });
}
async function _0x394c31() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x2055ab(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x1565e8() {
  return await new Promise(function (_0x4c8272, _0x821525) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x5d3eae) {
        (console["log"]("result:\x20", _0x5d3eae["membership"]),
          _0x4c8272(_0x5d3eae["membership"]));
      },
    );
  });
}
async function _0x2d972b() {
  return await new Promise(function (_0x2e33d1, _0x10722e) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x229f41) {
        (console["log"]("result:\x20", _0x229f41["creditsAvailable"]),
          _0x2e33d1(_0x229f41["creditsAvailable"]));
      },
    );
  });
}
async function _0x44c946(_0x284184) {
  if ("ultimate" != (await _0x1565e8()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x2d972b()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
const _0x127c65 = { URL: "URL", BASE_64: "BASE_64" };
console["log"]("image_utils.js");
async function _0x90886d(_0x31d009) {
  if (!_0x31d009) throw new Error("Image\x20URL\x20is\x20required");
  var _0x84ab13 = (_0x84ab13 = await _0x34ead3(_0x31d009))["b64Image"];
  return await _0x46b674(_0x84ab13);
}
function _0x34ead3(_0x16236b) {
  return new Promise((_0x218124, _0x13a381) => {
    chrome["runtime"]["sendMessage"](
      { type: "url-to-b64", url: _0x16236b },
      (_0x45fa62) => {
        _0x45fa62 && _0x45fa62["error"]
          ? _0x13a381(new Error(_0x45fa62["error"]))
          : _0x218124(_0x45fa62);
      },
    );
  });
}
const _0xe9120d = (_0x58aec6, _0x25ea9d) => {
    ((trimmedString = _0x58aec6),
      _0x58aec6["startsWith"]("data") &&
        (trimmedString = _0x58aec6["split"](",")[0x1]));
    const _0x40b6aa = atob(trimmedString),
      _0x1f3b18 = new ArrayBuffer(_0x40b6aa["length"]),
      _0x86ab8 = new Uint8Array(_0x1f3b18);
    for (let _0x42d1e0 = 0x0; _0x42d1e0 < _0x40b6aa["length"]; _0x42d1e0++)
      _0x86ab8[_0x42d1e0] = _0x40b6aa["charCodeAt"](_0x42d1e0);
    const _0x40d74b = new Blob([_0x1f3b18], { type: "image/jpeg" });
    return new File([_0x40d74b], _0x25ea9d, {
      lastModified: new Date()["getTime"](),
      type: "image/jpeg",
    });
  },
  _0x26c2f5 = (_0xca6d8, _0x46d8fe) => {
    const _0x3abc4f = new DataTransfer();
    (_0x3abc4f["items"]["add"](_0xca6d8),
      (_0x46d8fe["files"] = _0x3abc4f["files"]));
    const _0x333967 = new Event("change", { bubbles: !0x0 });
    _0x46d8fe["dispatchEvent"](_0x333967);
  };
var _0x9c68ac = async (_0x3cb5b1, _0x34bc31, _0xf89259, _0x5cca0a) => {
  let _0x9be323;
  if (_0x5cca0a == _0x127c65["URL"]) {
    const { b64Image: _0x34412d } = await _0x34ead3(_0x3cb5b1);
    _0x9be323 = _0xe9120d(_0x34412d, _0xf89259);
  }
  _0x5cca0a == _0x127c65["BASE_64"] &&
    (_0x9be323 = _0xe9120d(_0x3cb5b1, _0xf89259));
  var _0x1971ab = document["querySelector"](_0x34bc31);
  _0x26c2f5(_0x9be323, _0x1971ab);
};
async function _0x4dc265(
  _0x32872f,
  _0x2896c7,
  _0x33dd79,
  _0x48b1f7,
  _0x1ace27,
  _0x1fc07d,
  _0x5c6659,
  _0x42c247,
) {
  var _0x574c5b = await _0x90886d(_0x32872f);
  _0x574c5b = await _0x144302(_0x574c5b, _0x1ace27, _0x1fc07d);
  var _0x477b7c = await _0x90886d(_0x33dd79);
  ((_0x477b7c = await _0x144302(_0x477b7c, 0.45 * _0x1fc07d, 0.45 * _0x1ace27)),
    (_0x574c5b = await _0x275918(_0x574c5b, _0x477b7c, 0.75)));
  var _0x4dcdca = await _0x90886d(_0x2896c7);
  return (
    (_0x4dcdca = await _0x144302(
      _0x4dcdca,
      0.45 * _0x1fc07d,
      0.45 * _0x1ace27,
    )),
    await _0x489cc7(_0x574c5b, _0x4dcdca, 0.95)
  );
}
async function _0x5d2b39(
  _0x28c157,
  _0x2b953e,
  _0x56470d,
  _0x2e534c,
  _0x2eb526,
  _0x318f54,
  _0x2fd081,
) {
  var _0x6f91dc = await _0x90886d(_0x28c157);
  _0x6f91dc = await _0x55142f(_0x6f91dc, _0x2e534c, _0x2eb526);
  var _0x2c0178 = await _0x90886d(_0x2b953e);
  return (
    (_0x2c0178 = await _0x55142f(
      _0x2c0178,
      0.45 * _0x2eb526,
      0.45 * _0x2e534c,
    )),
    (_0x6f91dc = await _0x2c4482(_0x6f91dc, _0x2c0178, "right")),
    (_0x2c0178 = await _0x55142f(_0x2c0178, 0.4 * _0x2eb526, 0.4 * _0x2e534c)),
    await _0x7a3ab9(_0x6f91dc, _0x2c0178, 0.7, _0x2b953e)
  );
}
async function _0x26e150(_0x53c1be) {
  var _0x7f6ad3 = _0x53c1be["imageSource"],
    _0x3fd124 = _0x53c1be["waterMarkUrl"],
    _0xd8a3a4 = await _0x90886d(_0x7f6ad3);
  ((_0xd8a3a4 = await _0x402563(_0xd8a3a4)),
    (_0xd8a3a4 = await _0x264f24(_0xd8a3a4)));
  var _0xd760b3 = await _0x90886d(_0x3fd124);
  return (
    (_0xd760b3 = await _0x55142f(
      _0xd760b3,
      0.2 * _0xd8a3a4["height"],
      0.2 * _0xd8a3a4["width"],
    )),
    (_0xd760b3 = await _0x402563(_0xd760b3)),
    (_0xd760b3 = await _0x264f24(_0xd760b3)),
    (_0xd8a3a4 = await _0x2c4482(_0xd8a3a4, _0xd760b3, "right")),
    (_0xd8a3a4 = await _0x7a3ab9(_0xd8a3a4, _0xd760b3, 0.7))["width"] >
    _0xd8a3a4["height"]
      ? (_0xd8a3a4 = await _0x1f6e35({
          imageObject: _0xd8a3a4,
          padding: _0xd8a3a4["width"] - _0xd8a3a4["height"],
          paddingDirection: "height",
        }))
      : (_0xd8a3a4["width"] < _0xd8a3a4["height"] ||
          _0xd8a3a4["width"] == _0xd8a3a4["height"]) &&
        (_0xd8a3a4 = await _0x1f6e35({
          imageObject: _0xd8a3a4,
          padding: _0xd8a3a4["height"] - _0xd8a3a4["width"],
          paddingDirection: "width",
        })),
    _0xd8a3a4
  );
}
async function _0x332fe2(_0x382ff0, _0x3c9f33 = "Look", _0x36e92a = "Inside") {
  var _0x452229 = _0x382ff0["imageSource"],
    _0xc810bc = _0x382ff0["waterMarkUrl"],
    _0x5f4dde = await _0x90886d(_0x452229);
  ((_0x5f4dde = await _0x402563(_0x5f4dde)),
    (_0x5f4dde = await _0x264f24(_0x5f4dde)));
  var _0x129e9f = await _0x90886d(_0xc810bc);
  ((_0x129e9f = await _0x55142f(
    _0x129e9f,
    0.2 * _0x5f4dde["height"],
    0.2 * _0x5f4dde["width"],
  )),
    (_0x129e9f = await _0x402563(_0x129e9f)),
    (_0x129e9f = await _0x264f24(_0x129e9f)));
  var _0x2c02de = getProductDescriptionAndFeatures(),
    _0x14a46b = getFilteredTitle() + "\x0a\x0a" + _0x2c02de,
    _0x36f3a9 = await _0x1fd9a7(
      "http://1.1.1.66:1102/api/ItemSpecifics/GetBuyerIntent",
      { request_type: "get_buyer_intent", productDescription: _0x14a46b },
    );
  console["log"]("twoWordBuyerIntent", _0x36f3a9);
  var _0x3954ec = _0x36f3a9["split"]("\x20");
  _0x3c9f33 = _0x3954ec[0x0];
  for (var _0x17cc81 = 0x1; _0x17cc81 < _0x3954ec["length"]; _0x17cc81++)
    _0x36e92a += "\x20" + _0x3954ec[_0x17cc81];
  return (
    (_0x36e92a = _0x36e92a["trim"]()),
    (_0x3c9f33 = _0x3c9f33["trim"]()),
    (_0x5f4dde = await _0x48294e(_0x5f4dde, _0x3c9f33, _0x36e92a)),
    (_0x5f4dde = await _0x2c4482(_0x5f4dde, _0x129e9f, "right")),
    (_0x5f4dde = await _0x503aee(_0x5f4dde)),
    await _0x7a3ab9(_0x5f4dde, _0x129e9f, 0.7)
  );
}
async function _0x15161e(_0x1b2247) {
  var _0x1ca953 = _0x1b2247["imageSource"],
    _0x4414a6 = _0x1b2247["waterMarkUrl"],
    _0x452730 = await _0x90886d(_0x1ca953);
  ((_0x452730 = await _0x402563(_0x452730)),
    (_0x452730 = await _0x264f24(_0x452730)));
  var _0x7992d9 = await _0x90886d(_0x4414a6);
  return (
    (_0x7992d9 = await _0x55142f(
      _0x7992d9,
      0.2 * _0x452730["height"],
      0.2 * _0x452730["width"],
    )),
    (_0x7992d9 = await _0x402563(_0x7992d9)),
    (_0x7992d9 = await _0x264f24(_0x7992d9)),
    (_0x452730 = await _0x2c4482(_0x452730, _0x7992d9, "right")),
    (_0x452730 = await _0x503aee(_0x452730)),
    (_0x452730 = await _0x7a3ab9(_0x452730, _0x7992d9, 0.7)),
    await _0x45b37c(_0x452730, 0x1f4, 0x1f4)
  );
}
function _0x2e2c1(_0x3d8fe0) {
  ((imgWidth = _0x3d8fe0["width"]), (imgHeight = _0x3d8fe0["height"]));
  var _0x1d6539 = document["createElement"]("canvas");
  (_0x1d6539["setAttribute"]("width", imgWidth),
    _0x1d6539["setAttribute"]("height", imgHeight));
  var _0x32cac3 = _0x1d6539["getContext"]("2d");
  _0x32cac3["drawImage"](_0x3d8fe0, 0x0, 0x0);
  var _0x20c840 = _0x32cac3["getImageData"](0x0, 0x0, imgWidth, imgHeight)[
      "data"
    ],
    _0x46b84a = function (_0x142549, _0x5f1302) {
      var _0x52163f = imgWidth * _0x5f1302 + _0x142549;
      return {
        red: _0x20c840[0x4 * _0x52163f],
        green: _0x20c840[0x4 * _0x52163f + 0x1],
        blue: _0x20c840[0x4 * _0x52163f + 0x2],
        opacity: _0x20c840[0x4 * _0x52163f + 0x3],
      };
    },
    _0xd1ff73 = function (_0x562d4e) {
      return (
        _0x562d4e["red"] > 0xc8 &&
        _0x562d4e["green"] > 0xc8 &&
        _0x562d4e["blue"] > 0xc8
      );
    },
    _0x1efdb4 = function (_0x4634bc) {
      var _0x165c54 = _0x4634bc ? 0x1 : -0x1;
      for (
        var _0x2c4c8d = _0x4634bc ? 0x0 : imgHeight - 0x1;
        _0x4634bc ? _0x2c4c8d < imgHeight : _0x2c4c8d > -0x1;
        _0x2c4c8d += _0x165c54
      )
        for (var _0xd672ff = 0x0; _0xd672ff < imgWidth; _0xd672ff++) {
          var _0x12b1e8 = _0x46b84a(_0xd672ff, _0x2c4c8d);
          if (!_0xd1ff73(_0x12b1e8))
            return _0x4634bc
              ? _0x2c4c8d
              : Math["min"](_0x2c4c8d + 0x1, imgHeight);
        }
      return null;
    },
    _0x5e5967 = function (_0x1f392e) {
      var _0x3d6d09 = _0x1f392e ? 0x1 : -0x1;
      for (
        var _0x30db4a = _0x1f392e ? 0x0 : imgWidth - 0x1;
        _0x1f392e ? _0x30db4a < imgWidth : _0x30db4a > -0x1;
        _0x30db4a += _0x3d6d09
      )
        for (var _0x2c5536 = 0x0; _0x2c5536 < imgHeight; _0x2c5536++) {
          var _0x153374 = _0x46b84a(_0x30db4a, _0x2c5536);
          if (!_0xd1ff73(_0x153374))
            return _0x1f392e
              ? _0x30db4a
              : Math["min"](_0x30db4a + 0x1, imgWidth);
        }
      return null;
    },
    _0x44e0ec = _0x1efdb4(!0x0),
    _0x4f5da7 = _0x1efdb4(!0x1),
    _0x4e474d = _0x5e5967(!0x0),
    _0x1e7850 = _0x5e5967(!0x1) - _0x4e474d,
    _0x57c0cb = _0x4f5da7 - _0x44e0ec;
  return (
    _0x1d6539["setAttribute"]("width", _0x1e7850),
    _0x1d6539["setAttribute"]("height", _0x57c0cb),
    _0x1d6539["getContext"]("2d")["drawImage"](
      _0x3d8fe0,
      _0x4e474d,
      _0x44e0ec,
      _0x1e7850,
      _0x57c0cb,
      0x0,
      0x0,
      _0x1e7850,
      _0x57c0cb,
    ),
    _0x1d6539["toDataURL"]()
  );
}
async function _0x578c45(_0x1c6e34) {
  var _0x9e8e43 = _0x1c6e34["imageSource"],
    _0x2599ab = await _0x90886d(_0x9e8e43);
  ((_0x2599ab = await _0x1f6e35({
    imageObject: _0x2599ab,
    padding: _0x2599ab["width"] - _0x2599ab["height"],
    paddingDirection: "height",
  })),
    (_0x2599ab = await _0x44cf96(_0x2599ab, "black", "30px")),
    document["body"]["prepend"](_0x2599ab));
}
function _0x1f6e35(_0x24dc9b) {
  return new Promise((_0x1884a2, _0x546fd8) => {
    var _0x5b16e6 = _0x24dc9b["imageObject"],
      _0x16a38d = _0x24dc9b["padding"],
      _0x72425d = _0x24dc9b["paddingDirection"] || "all",
      _0x256de6 = document["createElement"]("canvas");
    _0x256de6["id"] = "myCanvas";
    var _0x3029e8 = _0x256de6["getContext"]("2d");
    "all" == _0x72425d &&
      ((_0x256de6["width"] = _0x5b16e6["width"] + _0x16a38d),
      (_0x256de6["height"] = _0x5b16e6["height"] + _0x16a38d),
      (_0x3029e8["fillStyle"] = "white"),
      _0x3029e8["fillRect"](0x0, 0x0, _0x256de6["width"], _0x256de6["height"]),
      _0x3029e8["drawImage"](_0x5b16e6, _0x16a38d / 0x2, _0x16a38d / 0x2));
    "height" == _0x72425d &&
      ((_0x256de6["width"] = _0x5b16e6["width"]),
      (_0x256de6["height"] = _0x5b16e6["height"] + _0x16a38d),
      (_0x3029e8["fillStyle"] = "white"),
      _0x3029e8["fillRect"](0x0, 0x0, _0x256de6["width"], _0x256de6["height"]),
      _0x3029e8["drawImage"](_0x5b16e6, 0x0, _0x16a38d / 0x2));
    "width" == _0x72425d &&
      ((_0x256de6["width"] = _0x5b16e6["width"] + _0x16a38d),
      (_0x256de6["height"] = _0x5b16e6["height"]),
      (_0x3029e8["fillStyle"] = "white"),
      _0x3029e8["fillRect"](0x0, 0x0, _0x256de6["width"], _0x256de6["height"]),
      _0x3029e8["drawImage"](_0x5b16e6, _0x16a38d / 0x2, 0x0));
    var _0x129dba = new Image();
    ((_0x129dba["onload"] = function () {
      _0x1884a2(_0x129dba);
    }),
      (_0x129dba["src"] = _0x256de6["toDataURL"]()));
  });
}
async function _0x15fe48(
  _0x262095,
  _0x4f428b,
  _0x562026,
  _0x22114f,
  _0x344087,
  _0x4a0d8e,
  _0x17131d,
  _0x629d5b,
) {
  var _0x44613c = await _0x90886d(_0x262095);
  ((_0x44613c = await _0x55142f(_0x44613c, _0x344087, _0x4a0d8e)),
    (_0x44613c = await _0x402563(_0x44613c)));
  var _0x6ff912 = await _0x90886d(_0x562026);
  ((_0x6ff912 = await _0x402563(_0x6ff912)),
    (_0x6ff912 = await _0x55142f(
      _0x6ff912,
      0.45 * _0x4a0d8e,
      0.45 * _0x344087,
    )));
  var _0x348ddf = await _0x90886d(_0x4f428b);
  return (
    (_0x348ddf = await _0x55142f(
      _0x348ddf,
      0.45 * _0x4a0d8e,
      0.45 * _0x344087,
    )),
    (_0x44613c = await _0x2c4482(_0x44613c, _0x348ddf, "right")),
    (_0x348ddf = await _0x55142f(_0x348ddf, 0.4 * _0x344087, 0.4 * _0x4a0d8e)),
    (_0x44613c = await _0x345db0(_0x44613c, _0x348ddf, 0x1, 0xc)),
    (_0x6ff912 = await _0x590ca7(
      _0x6ff912,
      0.65 * _0x348ddf["width"],
      0.65 * _0x348ddf["height"],
    )),
    (_0x6ff912 = await _0x264f24(_0x6ff912)),
    (_0x44613c = await _0x7a3ab9(_0x44613c, _0x6ff912, 0.7)),
    (_0x44613c = await _0x503aee(_0x44613c)),
    await _0x45b37c(_0x44613c, 0x1f4, 0x1f4)
  );
}
async function _0x3ca954(
  _0xbf8f13,
  _0x449806,
  _0x5ef3f3,
  _0x1fda5c,
  _0x32946b,
  _0x306fcb,
  _0xf0bca,
  _0x1956eb,
) {
  var _0xd4225c = await _0x90886d(_0xbf8f13);
  ((_0xd4225c = await _0x55142f(_0xd4225c, _0x32946b, _0x306fcb)),
    (_0xd4225c = await _0x402563(_0xd4225c)));
  var _0x53c9a4 = await _0x90886d(_0x5ef3f3);
  ((_0x53c9a4 = await _0x55142f(_0x53c9a4, 0.45 * _0x306fcb, 0.45 * _0x32946b)),
    (waterMarkImg = await _0x402563(_0x53c9a4)),
    (waterMarkImg = await _0x264f24(_0x53c9a4)));
  var _0x1c207c = await _0x90886d(_0x449806);
  return (
    (_0x1c207c = await _0x55142f(
      _0x1c207c,
      0.45 * _0x306fcb,
      0.45 * _0x32946b,
    )),
    (_0xd4225c = await _0x2c4482(_0xd4225c, _0x1c207c, "right")),
    (_0x53c9a4 = await _0x590ca7(
      _0x53c9a4,
      0.65 * _0x1c207c["width"],
      0.65 * _0x1c207c["height"],
    )),
    (_0x53c9a4 = await _0x264f24(_0x53c9a4)),
    (_0xd4225c = await _0x7a3ab9(_0xd4225c, _0x53c9a4, 0.7)),
    (_0xd4225c = await _0x503aee(_0xd4225c)),
    (_0x1c207c = await _0x55142f(_0x1c207c, 0.4 * _0x32946b, 0.4 * _0x306fcb)),
    (_0xd4225c = await _0x345db0(_0xd4225c, _0x1c207c, 0x1, 0xc)),
    await _0x45b37c(_0xd4225c, 0x1f4, 0x1f4)
  );
}
async function _0xaed111(
  _0x435bdd,
  _0x3a0233,
  _0x3ee511,
  _0x585349,
  _0x2103c0,
  _0x5c369b,
  _0x3e670b,
  _0x58c151,
) {
  var _0x556a3b = await _0x90886d(_0x435bdd);
  ((_0x556a3b = await _0x55142f(_0x556a3b, _0x2103c0, _0x5c369b)),
    (_0x556a3b = await _0x402563(_0x556a3b)));
  var _0x3dc1f8 = await _0x90886d(_0x3ee511);
  ((_0x3dc1f8 = await _0x55142f(_0x3dc1f8, 0.45 * _0x5c369b, 0.45 * _0x2103c0)),
    (waterMarkImg = await _0x402563(_0x3dc1f8)),
    (waterMarkImg = await _0x264f24(_0x3dc1f8)));
  var _0x481bfd = await _0x90886d(_0x3a0233);
  return (
    (_0x481bfd = await _0x55142f(
      _0x481bfd,
      0.45 * _0x5c369b,
      0.45 * _0x2103c0,
    )),
    (_0x556a3b = await _0x2c4482(_0x556a3b, _0x481bfd, "right")),
    (_0x556a3b = await _0x503aee(_0x556a3b)),
    (_0x3dc1f8 = await _0x590ca7(
      _0x3dc1f8,
      0.65 * _0x481bfd["width"],
      0.65 * _0x481bfd["height"],
    )),
    (_0x3dc1f8 = await _0x264f24(_0x3dc1f8)),
    (_0x556a3b = await _0x7a3ab9(_0x556a3b, _0x3dc1f8, 0.7)),
    (_0x481bfd = await _0x55142f(_0x481bfd, 0.4 * _0x2103c0, 0.4 * _0x5c369b)),
    (_0x556a3b = await _0x345db0(_0x556a3b, _0x481bfd, 0x1, 0xc)),
    (_0x556a3b = await _0x2c2c39(_0x556a3b)),
    (_0x556a3b = await _0x16eeb8(_0x556a3b)),
    await _0x45b37c(_0x556a3b, 0x1f4, 0x1f4)
  );
}
function _0x135712(_0x1efea7, _0x545e47, _0x425845) {
  return new Promise(async (_0x31fcb6, _0x1d61cd) => {
    let _0x3f99d6 = document["createElement"]("canvas");
    ((_0x3f99d6["width"] = _0x1efea7["width"]),
      (_0x3f99d6["height"] = _0x1efea7["height"]));
    let _0x47f20a = _0x3f99d6["getContext"]("2d");
    ((_0x47f20a["fillStyle"] = _0x425845),
      _0x47f20a["fillRect"](0x0, 0x0, _0x3f99d6["width"], _0x3f99d6["height"]),
      _0x47f20a["drawImage"](
        _0x1efea7,
        0x0,
        0x0,
        _0x1efea7["width"],
        _0x1efea7["height"],
      ));
    var _0x3483d5 = new Image();
    ((_0x3483d5["onload"] = function () {
      _0x31fcb6(_0x3483d5);
    }),
      (_0x3483d5["src"] = _0x3f99d6["toDataURL"]()));
  });
}
async function _0x1d9bed(
  _0x2935ee,
  _0x5b93ab,
  _0x488279,
  _0x5b7487,
  _0x7bd39d,
  _0xa4da8b,
  _0x29965b,
  _0x5875ec,
) {
  var _0x53d8f4 = await _0x90886d(_0x2935ee);
  ((_0x53d8f4 = await _0x55142f(_0x53d8f4, _0x7bd39d, _0xa4da8b)),
    (_0x53d8f4 = await _0x402563(_0x53d8f4)));
  var _0x3b0a82 = await _0x90886d(_0x488279);
  _0x3b0a82 = await _0x55142f(_0x3b0a82, 0.45 * _0xa4da8b, 0.45 * _0x7bd39d);
  var _0x3cf2ab = await _0x90886d(_0x5b93ab);
  return (
    (_0x3cf2ab = await _0x55142f(
      _0x3cf2ab,
      0.45 * _0xa4da8b,
      0.45 * _0x7bd39d,
    )),
    (_0x3cf2ab = await _0x264f24(_0x3cf2ab)),
    (_0x3cf2ab = await _0x135712(_0x3cf2ab, _0x5b93ab, "beige")),
    (_0x53d8f4 = await _0x2c4482(_0x53d8f4, _0x3cf2ab, "right")),
    (_0x3cf2ab = await _0x55142f(_0x3cf2ab, 0.4 * _0x7bd39d, 0.4 * _0xa4da8b)),
    (_0x53d8f4 = await _0x345db0(_0x53d8f4, _0x3cf2ab, 0x1, 0xc)),
    (_0x3b0a82 = await _0x402563(_0x3b0a82)),
    (_0x3b0a82 = await _0x590ca7(
      _0x3b0a82,
      _0x3cf2ab["width"],
      _0x3cf2ab["height"],
    )),
    (_0x3b0a82 = await _0x264f24(_0x3b0a82)),
    (_0x53d8f4 = await _0x7a3ab9(_0x53d8f4, _0x3b0a82, 0.7, _0x488279)),
    (_0x53d8f4 = await _0x503aee(_0x53d8f4)),
    (_0x53d8f4 = await _0x2c2c39(_0x53d8f4)),
    (_0x53d8f4 = await _0x16eeb8(_0x53d8f4)),
    await _0x45b37c(_0x53d8f4, 0x1f4, 0x1f4)
  );
}
async function _0x226846(
  _0x3fa966,
  _0x5f1b8,
  _0x15de15,
  _0x362b9d,
  _0x5d607a,
  _0x5c3373,
  _0x3c5a75,
  _0x2a03d8,
  _0x45ff25,
  _0x29c3fa,
) {
  var _0xf4d503 = await _0x90886d(_0x3fa966);
  _0xf4d503 = await _0x144302(_0xf4d503, _0x3c5a75, _0x2a03d8);
  var _0x36b907 = await _0x90886d(_0x15de15);
  _0x36b907 = await _0x55142f(_0x36b907, 0.45 * _0x2a03d8, 0.45 * _0x3c5a75);
  var _0x3988a9 = await _0x90886d(_0x5f1b8);
  ((_0x3988a9 = await _0x55142f(_0x3988a9, 0.45 * _0x2a03d8, 0.45 * _0x3c5a75)),
    (_0xf4d503 = await _0x2c4482(_0xf4d503, _0x3988a9, "right")),
    (_0x3988a9 = await _0x55142f(_0x3988a9, 0.4 * _0x2a03d8, 0.4 * _0x3c5a75)),
    (_0x36b907 = await _0x55142f(_0x36b907, 0.4 * _0x2a03d8, 0.4 * _0x3c5a75)),
    (_0xf4d503 = await _0x345db0(_0xf4d503, _0x3988a9, 0x1, 0xc)),
    (_0x36b907 = await _0x264f24(_0x36b907)),
    (_0xf4d503 = await _0x7a3ab9(_0xf4d503, _0x36b907, 0.7)));
  var _0xb4773c = await _0x90886d(_0x362b9d);
  ((_0xb4773c = await _0x30fed9(_0xb4773c)),
    (_0xb4773c = await _0x55142f(
      _0xb4773c,
      0.45 * _0x2a03d8,
      0.45 * _0x3c5a75,
    )));
  var _0x3fd51a = await _0x90886d(_0x5d607a);
  _0x3fd51a = await _0x30fed9(_0x3fd51a);
  if (
    (_0x3fd51a = await _0x55142f(
      _0x3fd51a,
      0.45 * _0x2a03d8,
      0.45 * _0x3c5a75,
    ))["width"] >= _0xb4773c["width"]
  )
    ((_0xf4d503 = await _0x2c4482(_0xf4d503, _0x3fd51a, "left")),
      (_0x3fd51a = await _0x55142f(
        _0x3fd51a,
        0.4 * _0x2a03d8,
        0.4 * _0x3c5a75,
      )),
      (_0xb4773c = await _0x55142f(
        _0xb4773c,
        0.4 * _0x2a03d8,
        0.4 * _0x3c5a75,
      )),
      (_0xf4d503 = await _0x4e2f2a(_0xf4d503, _0x3fd51a, 0x1, 0xc)),
      (_0xf4d503 = await _0x76650c(_0xf4d503, _0xb4773c, 0x1)));
  else
    _0xb4773c["width"] > _0x3fd51a["width"] &&
      ((_0xf4d503 = await _0x2c4482(_0xf4d503, _0xb4773c, "left")),
      (_0x3fd51a = await _0x55142f(
        _0x3fd51a,
        0.4 * _0x2a03d8,
        0.4 * _0x3c5a75,
      )),
      (_0xb4773c = await _0x55142f(
        _0xb4773c,
        0.4 * _0x2a03d8,
        0.4 * _0x3c5a75,
      )),
      (_0xf4d503 = await _0x76650c(_0xf4d503, _0xb4773c, 0x1)),
      (_0xf4d503 = await _0x4e2f2a(_0xf4d503, _0x3fd51a, 0x1, 0xc)));
  return await _0x45b37c(_0xf4d503, 0x1f4, 0x1f4);
}
function _0x44cf96(_0x39fbe0, _0x24cee7, _0x5e267e) {
  return new Promise((_0x563df8, _0x31f47e) => {
    var _0x4f76f1 = document["createElement"]("canvas");
    ((_0x4f76f1["width"] = _0x39fbe0["width"]),
      (_0x4f76f1["height"] = _0x39fbe0["height"]));
    var _0x5a898c = _0x4f76f1["getContext"]("2d");
    (_0x5a898c["drawImage"](_0x39fbe0, 0x0, 0x0),
      (_0x5a898c["strokeStyle"] = _0x24cee7),
      (_0x5a898c["lineWidth"] = _0x5e267e),
      _0x5a898c["strokeRect"](
        0x0,
        0x0,
        _0x4f76f1["width"],
        _0x4f76f1["height"],
      ));
    var _0x146c19 = new Image();
    ((_0x146c19["onload"] = function () {
      _0x563df8(_0x146c19);
    }),
      (_0x146c19["src"] = _0x4f76f1["toDataURL"]()));
  });
}
async function _0x2e8049(
  _0x1dde2a,
  _0x5bbc6e,
  _0x34af90,
  _0x4746ee,
  _0x2a50ee,
  _0x347b90,
  _0x5ee5a5,
) {
  var _0x5915f3 = await _0x90886d(_0x1dde2a);
  _0x5915f3 = await _0x144302(_0x5915f3, _0x4746ee, _0x2a50ee);
  var _0x269ce3 = await _0x90886d(
    "https://centreforinquiry.ca/wp-content/uploads/2020/05/68353859-canadian-map-with-canada-flag.jpg",
  );
  ((_0x269ce3 = await _0x144302(_0x269ce3, 0.45 * _0x2a50ee, 0.45 * _0x4746ee)),
    (_0x5915f3 = await _0x275918(_0x5915f3, _0x269ce3, 0.75)));
  var _0x4df359 = await _0x90886d(_0x5bbc6e);
  return (
    (_0x4df359 = await _0x30fed9(_0x4df359)),
    (_0x4df359 = await _0x208411(_0x4df359)),
    (_0x4df359 = await _0x4ac6bb(_0x4df359, 0xa)),
    (_0x4df359 = await _0x144302(
      _0x4df359,
      0.45 * _0x2a50ee,
      0.45 * _0x4746ee,
    )),
    (_0x5915f3 = await _0x489cc7(_0x5915f3, _0x4df359, 0.95)),
    (_0x5915f3 = await _0x3eb182(_0x5915f3, _0x34af90, _0x347b90, _0x5ee5a5)),
    await _0x30fed9(_0x5915f3)
  );
}
function _0x30fed9(_0x2034cd) {
  return new Promise(function (_0x57d8e4, _0xdcaae9) {
    let _0x29bd2d = document["createElement"]("canvas");
    ((_0x29bd2d["width"] = _0x2034cd["width"]),
      (_0x29bd2d["height"] = _0x2034cd["height"]));
    let _0x473ea0 = _0x29bd2d["getContext"]("2d");
    ((_0x473ea0["fillStyle"] = "white"),
      _0x473ea0["fillRect"](0x0, 0x0, _0x29bd2d["width"], _0x29bd2d["height"]),
      _0x473ea0["drawImage"](
        _0x2034cd,
        0x0,
        0x0,
        _0x29bd2d["width"],
        _0x29bd2d["height"],
      ),
      (_0x473ea0["strokeStyle"] = "black"),
      (_0x473ea0["lineWidth"] = 0x1e),
      _0x473ea0["strokeRect"](
        0x0,
        0x0,
        _0x29bd2d["width"],
        _0x29bd2d["height"],
      ));
    var _0x172d1d = new Image();
    ((_0x172d1d["onload"] = function () {
      _0x57d8e4(_0x172d1d);
    }),
      (_0x172d1d["src"] = _0x29bd2d["toDataURL"]()));
  });
}
function _0x489cc7(_0x51c8cb, _0x1efdfe, _0x5a4adc) {
  return new Promise(function (_0x254810, _0x1421d8) {
    let _0x231453 = document["createElement"]("canvas");
    ((_0x231453["width"] = _0x51c8cb["width"]),
      (_0x231453["height"] = _0x51c8cb["height"]));
    let _0x31324 = _0x231453["getContext"]("2d");
    ((_0x31324["fillStyle"] = "white"),
      _0x31324["fillRect"](0x0, 0x0, _0x231453["width"], _0x231453["height"]),
      _0x31324["drawImage"](_0x51c8cb, 0x0, 0x0),
      (_0x31324["globalAlpha"] = _0x5a4adc));
    var _0x1c4b25 =
        _0x231453["width"] - _0x1efdfe["width"] - _0x231453["width"] / 0x32,
      _0x285507 =
        _0x231453["height"] - _0x1efdfe["height"] - _0x231453["height"] / 0xc;
    _0x31324["drawImage"](_0x1efdfe, _0x1c4b25, _0x285507);
    var _0x4131ca = new Image();
    ((_0x4131ca["onload"] = function () {
      _0x254810(_0x4131ca);
    }),
      (_0x4131ca["src"] = _0x231453["toDataURL"]()));
  });
}
async function _0xb24518(
  _0x4619e1,
  _0x23a533,
  _0x5dceda,
  _0x1e219d,
  _0x2aab38,
) {
  var _0x4f92de = localStorage["getItem"]("waterMarkUrl"),
    _0xf1bf8a = await _0x90886d(_0x4619e1);
  _0xf1bf8a = await _0x144302(_0xf1bf8a, _0x1e219d, _0x2aab38);
  var _0x272970 = await _0x90886d(_0x4f92de);
  ((_0x272970 = await _0x144302(_0x272970, 0.4 * _0x2aab38, 0.4 * _0x1e219d)),
    (_0xf1bf8a = await _0x275918(_0xf1bf8a, _0x272970, 0.75)),
    (_0xf1bf8a = await _0x3eb182(_0xf1bf8a, _0x23a533)),
    upload(_0xf1bf8a["src"], _0x23a533, _0x5dceda));
}
async function _0xb9e8ce(
  _0x582525,
  _0x5cd50b,
  _0xd9daba,
  _0x18257c,
  _0x199c63,
) {
  localStorage["getItem"]("waterMarkUrl");
  var _0x3c3edf = await _0x90886d(_0x582525);
  ((_0x3c3edf = await _0x4ac6bb(_0x3c3edf, 0x0)),
    (_0x3c3edf = await _0x144302(_0x3c3edf, _0x18257c, _0x199c63)),
    upload(_0x3c3edf["src"], _0x5cd50b, _0xd9daba));
}
function _0x52f62f(_0x8fb87c) {
  var _0x1b1182 = document["createElement"]("img");
  ((_0x1b1182["src"] = _0x8fb87c),
    document["getElementsByTagName"]("html")[0x0]["appendChild"](_0x1b1182));
}
function _0x32112c(_0x328595) {
  return new Promise(function (_0x7168ae, _0xcbbe07) {
    var _0x2e2857 = new Image();
    ((_0x2e2857["src"] = _0x328595),
      (_0x2e2857["crossOrigin"] = "anonymous"),
      (_0x2e2857["onload"] = function () {
        _0x7168ae(_0x2e2857);
      }));
  });
}
async function _0x3eb182(_0x4b1f3c, _0x5e39ce, _0xbd0ec8, _0x418170) {
  var _0x5272d4 = await _0x4b47b8(_0x4b1f3c, _0x5e39ce, _0xbd0ec8, _0x418170);
  return await _0x2ee05f(_0x4b1f3c, _0x5e39ce, _0x5272d4, _0xbd0ec8, _0x418170);
}
function _0x2ee05f(_0x4fea4c, _0x228a1a, _0x1512dc, _0x53f282, _0x2a296f) {
  return new Promise(function (_0x5efa61, _0x1243dd) {
    var _0x38c5d6 = document["createElement"]("canvas");
    _0x38c5d6["id"] = "myCanvas";
    var _0x7ad9b6 = (_0x4fea4c["height"] / 0xa) * 0.45,
      _0x10e5e5 = _0x7ad9b6 + _0x7ad9b6 / 0x2,
      _0x3a8c82 = _0x7ad9b6;
    ((_0x38c5d6["width"] = _0x4fea4c["width"]),
      (_0x38c5d6["height"] = _0x4fea4c["height"] + _0x10e5e5 * _0x1512dc));
    var _0x1c250a = _0x38c5d6["getContext"]("2d");
    ((_0x1c250a["fillStyle"] = "white"),
      _0x1c250a["fillRect"](0x0, 0x0, _0x38c5d6["width"], _0x38c5d6["height"]));
    var _0x4e6619 = _0x38c5d6["width"],
      _0x2b7910 = _0x38c5d6["height"] * (0x46 / 0x5dc);
    ((_0x1c250a["fillStyle"] = _0x53f282),
      (_0x1c250a["font"] = _0x7ad9b6 + "px\x20" + _0x2a296f),
      _0x5895d8(_0x1c250a, _0x228a1a, 0x0, _0x3a8c82, _0x4e6619, _0x2b7910),
      _0x1c250a["drawImage"](_0x4fea4c, 0x0, _0x10e5e5 * _0x1512dc));
    let _0x22e54b = new Image();
    ((_0x22e54b["crossOrigin"] = "anonymous"),
      (_0x22e54b["src"] = _0x38c5d6["toDataURL"]()),
      (_0x22e54b["onload"] = function () {
        _0x5efa61(_0x22e54b);
      }));
  });
}
function _0x1dfaef(_0x1f88fe) {
  var _0x269e0a = (_0x1f88fe["height"] / 0xa) * 1.5,
    _0x351626 = _0x269e0a + _0x269e0a / 0x2,
    _0xec464f = _0x269e0a;
  return new Promise(function (_0x26699b, _0x2c091f) {
    var _0x24a3ed = document["createElement"]("canvas");
    ((_0x24a3ed["id"] = "myCanvas"),
      (_0x24a3ed["width"] = _0x1f88fe["width"]),
      (_0x24a3ed["height"] = _0x1f88fe["height"] + 0x1 * _0x351626));
    var _0x3074e5 = _0x24a3ed["getContext"]("2d");
    ((_0x3074e5["fillStyle"] = "white"),
      _0x3074e5["fillRect"](0x0, 0x0, _0x24a3ed["width"], _0x24a3ed["height"]),
      _0x24a3ed["width"],
      (_0x3074e5["fillStyle"] = "#F79148"),
      (_0x3074e5["font"] = "bold\x20" + _0x269e0a + "px\x20Arial"),
      _0x3074e5["fillText"]("Look\x20", 0x0, _0xec464f));
    var _0x5e249e = _0x3074e5["measureText"]("Look\x20")["width"];
    ((_0x3074e5["fillStyle"] = "#34B8FF"),
      (_0x3074e5["font"] = "bold\x20" + _0x269e0a + "px\x20Arial"),
      _0x3074e5["fillText"]("Inside\x20⤸", 0x0 + _0x5e249e, _0xec464f),
      _0x3074e5["drawImage"](_0x1f88fe, 0x0, 0x1 * _0x351626));
    var _0x75b561 = new Image();
    ((_0x75b561["crossOrigin"] = "anonymous"),
      (_0x75b561["src"] = _0x24a3ed["toDataURL"]()),
      (_0x75b561["onload"] = function () {
        _0x26699b(_0x75b561);
      }));
  });
}
function _0x48294e(_0x12d1f4, _0x529466, _0x140350) {
  _0x140350 += "\x20⤸";
  var _0x53127a = _0x12d1f4["width"],
    _0x40e703 = _0x12d1f4["width"] / 0xa,
    _0x1ee487 = _0x40e703 + _0x40e703 / 0x2,
    _0x5cd475 = _0x40e703;
  return new Promise(function (_0x5ec2dd, _0x1bedeb) {
    var _0x2275b9 = document["createElement"]("canvas");
    ((_0x2275b9["id"] = "myCanvas"),
      (_0x2275b9["width"] = _0x12d1f4["width"]),
      (_0x2275b9["height"] = _0x12d1f4["height"] + 0x1 * _0x1ee487));
    var _0x2f125a = _0x2275b9["getContext"]("2d");
    ((_0x2f125a["fillStyle"] = "white"),
      _0x2f125a["fillRect"](0x0, 0x0, _0x2275b9["width"], _0x2275b9["height"]),
      (_0x2f125a["fillStyle"] = "#34B8FF"),
      (_0x2f125a["font"] = "bold\x20" + _0x40e703 + "px\x20Arial"),
      _0x2f125a["fillText"](_0x529466, 0x0, _0x5cd475));
    var _0x562092 = _0x2f125a["measureText"](_0x529466)["width"],
      _0x204c89 = ((_0x53127a - _0x562092) / _0x140350["length"]) * 0x2;
    ((_0x2f125a["fillStyle"] = "#F79148"),
      (_0x2f125a["font"] = "bold\x20" + _0x204c89 + "px\x20Arial"),
      _0x2f125a["fillText"](_0x140350, 0x0 + _0x562092, _0x5cd475),
      _0x2f125a["drawImage"](_0x12d1f4, 0x0, 0x1 * _0x1ee487));
    var _0x157d7f = new Image();
    ((_0x157d7f["crossOrigin"] = "anonymous"),
      (_0x157d7f["src"] = _0x2275b9["toDataURL"]()),
      (_0x157d7f["onload"] = function () {
        _0x5ec2dd(_0x157d7f);
      }));
  });
}
function _0x4b47b8(_0x4253da, _0xd79c78, _0x20e074, _0x4144df) {
  return new Promise((_0x20a071) => {
    var _0x468b5d = document["createElement"]("canvas");
    _0x468b5d["id"] = "myCanvas";
    var _0x375cc7 = (_0x4253da["height"] / 0xa) * 0.45,
      _0x297518 = _0x375cc7;
    ((_0x468b5d["width"] = _0x4253da["width"]),
      (_0x468b5d["height"] = _0x4253da["height"]));
    var _0xe8624c = _0x468b5d["getContext"]("2d");
    ((_0xe8624c["fillStyle"] = "white"),
      _0xe8624c["fillRect"](0x0, 0x0, _0x468b5d["width"], _0x468b5d["height"]));
    var _0x4395d6 = _0x468b5d["width"],
      _0x2547a5 = _0x468b5d["height"] * (0x46 / 0x5dc);
    ((_0xe8624c["fillStyle"] = _0x20e074),
      (_0xe8624c["font"] = _0x375cc7 + "px\x20" + _0x4144df));
    var _0x3ff345 = 0x1,
      _0x4c60f4 = _0xd79c78["split"]("\x20"),
      _0x500dc2 = "";
    for (var _0x3126ec = 0x0; _0x3126ec < _0x4c60f4["length"]; _0x3126ec++) {
      var _0x1bd9d2 = _0x500dc2 + _0x4c60f4[_0x3126ec] + "\x20";
      if (
        _0xe8624c["measureText"](_0x1bd9d2)["width"] > _0x4395d6 &&
        _0x3126ec > 0x0
      )
        (_0x3ff345++,
          _0xe8624c["fillText"](_0x500dc2, 0x0, _0x297518),
          (_0x500dc2 = _0x4c60f4[_0x3126ec] + "\x20"),
          (_0x297518 += _0x2547a5));
      else _0x500dc2 = _0x1bd9d2;
    }
    _0x20a071(_0x3ff345);
  });
}
function _0x5895d8(
  _0xaba5ee,
  _0x407d55,
  _0x35a054,
  _0x2e3fb2,
  _0x2889ce,
  _0xceb8d5,
) {
  var _0x23b758 = _0x407d55["split"]("\x20"),
    _0x5e438f = "";
  for (var _0x2cce85 = 0x0; _0x2cce85 < _0x23b758["length"]; _0x2cce85++) {
    var _0x1b3057 = _0x5e438f + _0x23b758[_0x2cce85] + "\x20";
    if (
      _0xaba5ee["measureText"](_0x1b3057)["width"] > _0x2889ce &&
      _0x2cce85 > 0x0
    )
      (_0xaba5ee["fillText"](_0x5e438f, _0x35a054, _0x2e3fb2),
        (_0x5e438f = _0x23b758[_0x2cce85] + "\x20"),
        (_0x2e3fb2 += _0xceb8d5));
    else _0x5e438f = _0x1b3057;
  }
  _0xaba5ee["fillText"](_0x5e438f, _0x35a054, _0x2e3fb2);
}
function _0x208411(_0x4234bc) {
  return new Promise(function (_0x5acc08, _0x44eca1) {
    var _0x2bab6a = document["createElement"]("canvas");
    ((_0x2bab6a["id"] = "myCanvas"),
      (_0x2bab6a["width"] = _0x4234bc["width"]),
      (_0x2bab6a["height"] = _0x4234bc["height"]));
    var _0x1d68c6 = _0x2bab6a["getContext"]("2d");
    ((_0x1d68c6["fillStyle"] = "white"),
      _0x1d68c6["fillRect"](0x0, 0x0, _0x2bab6a["width"], _0x2bab6a["height"]),
      _0x1d68c6["translate"](_0x2bab6a["width"], 0x0),
      _0x1d68c6["scale"](-0x1, 0x1),
      _0x1d68c6["drawImage"](_0x4234bc, 0x0, 0x0));
    let _0x2329ff = new Image();
    ((_0x2329ff["crossOrigin"] = "anonymous"),
      (_0x2329ff["src"] = _0x2bab6a["toDataURL"]()),
      (_0x2329ff["onload"] = function () {
        _0x5acc08(_0x2329ff);
      }));
  });
}
function _0x144302(_0x36ab93, _0x3bb404, _0x21f9ae) {
  return new Promise(function (_0x107a41, _0x1ba03e) {
    var _0x2d552e = document["createElement"]("canvas");
    ((_0x2d552e["id"] = "myCanvas"),
      (_0x2d552e["width"] = _0x3bb404),
      (_0x2d552e["height"] = _0x21f9ae));
    var _0x4c4bab = _0x2d552e["getContext"]("2d");
    ((_0x4c4bab["fillStyle"] = "white"),
      _0x4c4bab["fillRect"](0x0, 0x0, _0x2d552e["width"], _0x2d552e["height"]));
    var _0x277998 = _0x3bb404 / 0x2,
      _0x38ca0f = _0x21f9ae / 0x2,
      _0xc6da4f = 0x1;
    (_0x36ab93["width"] > _0x36ab93["height"] &&
      (_0xc6da4f = _0x3bb404 / _0x36ab93["width"]),
      _0x36ab93["width"] < _0x36ab93["height"] &&
        (_0xc6da4f = _0x3bb404 / _0x36ab93["height"]),
      _0x36ab93["width"] === _0x36ab93["height"] &&
        (_0xc6da4f = _0x3bb404 / _0x36ab93["height"]));
    var _0x218f9b = _0x36ab93["width"] * _0xc6da4f,
      _0xc7d0d9 = _0x36ab93["height"] * _0xc6da4f;
    ((_0x4c4bab["globalAlpha"] = 0x1),
      _0x4c4bab["drawImage"](
        _0x36ab93,
        _0x277998 - _0x218f9b / 0x2,
        _0x38ca0f - _0xc7d0d9 / 0x2,
        _0x218f9b,
        _0xc7d0d9,
      ));
    let _0x39dc2f = new Image();
    ((_0x39dc2f["crossOrigin"] = "anonymous"),
      (_0x39dc2f["src"] = _0x2d552e["toDataURL"]()),
      (_0x39dc2f["onload"] = function () {
        _0x107a41(_0x39dc2f);
      }));
  });
}
function _0x55142f(_0x4de946, _0x4ab8cb, _0x1439bb) {
  return new Promise(function (_0x1c1013, _0x112a33) {
    var _0x41c278 = 0x1;
    (_0x4de946["width"] > _0x4de946["height"] &&
      (_0x41c278 = _0x4ab8cb / _0x4de946["width"]),
      _0x4de946["width"] < _0x4de946["height"] &&
        (_0x41c278 = _0x4ab8cb / _0x4de946["height"]),
      _0x4de946["width"] === _0x4de946["height"] &&
        (_0x41c278 = _0x4ab8cb / _0x4de946["height"]));
    var _0x54eebf = _0x4de946["width"] * _0x41c278,
      _0x7fd4b5 = _0x4de946["height"] * _0x41c278,
      _0x21522a = document["createElement"]("canvas");
    ((_0x21522a["id"] = "myCanvas"),
      (_0x21522a["width"] = _0x54eebf),
      (_0x21522a["height"] = _0x7fd4b5),
      (_0x21522a["style"] = "border:2px\x20solid\x20black;"));
    var _0x589708 = _0x21522a["getContext"]("2d");
    ((_0x589708["fillStyle"] = "white"),
      _0x589708["fillRect"](0x0, 0x0, _0x21522a["width"], _0x21522a["height"]),
      (_0x589708["globalAlpha"] = 0x1),
      _0x589708["drawImage"](_0x4de946, 0x0, 0x0, _0x54eebf, _0x7fd4b5));
    let _0x2291ad = new Image();
    ((_0x2291ad["crossOrigin"] = "anonymous"),
      (_0x2291ad["src"] = _0x21522a["toDataURL"]()),
      (_0x2291ad["onload"] = function () {
        _0x1c1013(_0x2291ad);
      }));
  });
}
function _0x550f22(_0x34b9e2) {
  return new Promise(function (_0x592bc2, _0x5e1400) {
    const _0x18fadf = Math["max"](_0x34b9e2["width"], _0x34b9e2["height"]),
      _0x231d6b = document["createElement"]("canvas");
    ((_0x231d6b["width"] = _0x18fadf), (_0x231d6b["height"] = _0x18fadf));
    const _0x2f0e96 = _0x231d6b["getContext"]("2d");
    ((_0x2f0e96["fillStyle"] = "white"),
      _0x2f0e96["fillRect"](0x0, 0x0, _0x231d6b["width"], _0x231d6b["height"]));
    const _0x53e809 = (_0x18fadf - _0x34b9e2["width"]) / 0x2,
      _0x178b5d = (_0x18fadf - _0x34b9e2["height"]) / 0x2;
    _0x2f0e96["drawImage"](
      _0x34b9e2,
      _0x53e809,
      _0x178b5d,
      _0x34b9e2["width"],
      _0x34b9e2["height"],
    );
    const _0x5d1e86 = new Image();
    ((_0x5d1e86["onload"] = function () {
      _0x592bc2(_0x5d1e86);
    }),
      (_0x5d1e86["src"] = _0x231d6b["toDataURL"]()));
  });
}
function _0x45b37c(_0x663cf5, _0x14dcca, _0xc23789) {
  return new Promise(function (_0xef39c9, _0x5d81ff) {
    var _0x591b6e = _0x663cf5["width"],
      _0x56e1bd = _0x663cf5["height"];
    if (_0x591b6e < _0x14dcca || _0x56e1bd < _0xc23789) {
      var _0x381662 = document["createElement"]("canvas"),
        _0x32fe3d = _0x381662["getContext"]("2d"),
        _0x500bc0 = Math["max"](_0x14dcca / _0x591b6e, _0xc23789 / _0x56e1bd);
      ((_0x591b6e *= _0x500bc0),
        (_0x56e1bd *= _0x500bc0),
        (_0x381662["width"] = _0x591b6e),
        (_0x381662["height"] = _0x56e1bd),
        _0x32fe3d["drawImage"](_0x663cf5, 0x0, 0x0, _0x591b6e, _0x56e1bd));
      var _0x1f93d9 = new Image();
      ((_0x1f93d9["src"] = _0x381662["toDataURL"]()),
        (_0x1f93d9["onload"] = function () {
          _0xef39c9(_0x1f93d9);
        }));
    } else _0xef39c9(_0x663cf5);
  });
}
function _0x590ca7(_0x39dd07, _0x4235ad, _0xd528d) {
  return new Promise(function (_0x1c03bd, _0x3be037) {
    var _0x276ea0 = 0x1;
    (_0x39dd07["width"] > _0x39dd07["height"] &&
      (_0x276ea0 = _0x4235ad / _0x39dd07["width"]),
      _0x39dd07["width"] < _0x39dd07["height"] &&
        (_0x276ea0 = _0x4235ad / _0x39dd07["height"]),
      _0x39dd07["width"] === _0x39dd07["height"] &&
        (_0x276ea0 = _0x4235ad / _0x39dd07["height"]));
    var _0x1291cc = _0x39dd07["width"] * _0x276ea0,
      _0x3390e0 = _0x39dd07["height"] * _0x276ea0,
      _0xa21424 = 0x1;
    for (; _0x1291cc > _0x4235ad; ) {
      ((_0x1291cc = _0x39dd07["width"] * _0xa21424),
        (_0x3390e0 = _0x39dd07["height"] * _0xa21424),
        (_0xa21424 -= 0.01));
    }
    var _0x1ff928 = document["createElement"]("canvas");
    ((_0x1ff928["id"] = "myCanvas"),
      (_0x1ff928["width"] = _0x1291cc),
      (_0x1ff928["height"] = _0x3390e0),
      (_0x1ff928["style"] = "border:2px\x20solid\x20black;"));
    var _0x4610ce = _0x1ff928["getContext"]("2d");
    ((_0x4610ce["fillStyle"] = "white"),
      _0x4610ce["fillRect"](0x0, 0x0, _0x1ff928["width"], _0x1ff928["height"]),
      (_0x4610ce["globalAlpha"] = 0x1),
      _0x4610ce["drawImage"](_0x39dd07, 0x0, 0x0, _0x1291cc, _0x3390e0));
    let _0x2cde49 = new Image();
    ((_0x2cde49["crossOrigin"] = "anonymous"),
      (_0x2cde49["src"] = _0x1ff928["toDataURL"]()),
      (_0x2cde49["onload"] = function () {
        _0x1c03bd(_0x2cde49);
      }));
  });
}
function _0x46b674(_0x18ab0b) {
  return new Promise((_0x2cb67a, _0x483dee) => {
    var _0x22f53d = document["createElement"]("canvas")["getContext"]("2d"),
      _0x5361c2 = new Image();
    ((_0x5361c2["onload"] = function () {
      (_0x22f53d["drawImage"](_0x5361c2, 0x0, 0x0), _0x2cb67a(_0x5361c2));
    }),
      (_0x5361c2["src"] = _0x18ab0b));
  });
}
function _0x275918(_0x1817c3, _0x591104, _0x2fc493) {
  return new Promise(function (_0x2f3f7b, _0x12af37) {
    let _0x25a3a1 = document["createElement"]("canvas");
    ((_0x25a3a1["width"] = _0x1817c3["width"] + _0x591104["width"]),
      (_0x25a3a1["height"] = _0x1817c3["height"]));
    let _0x3b2988 = _0x25a3a1["getContext"]("2d");
    ((_0x3b2988["fillStyle"] = "white"),
      _0x3b2988["fillRect"](0x0, 0x0, _0x25a3a1["width"], _0x25a3a1["height"]),
      _0x3b2988["drawImage"](_0x1817c3, 0x0, 0x0),
      (_0x3b2988["globalAlpha"] = _0x2fc493));
    var _0x5b1a18 = 0.9 * _0x591104["width"],
      _0x3bf275 = 0.9 * _0x591104["height"];
    _0x3b2988["drawImage"](
      _0x591104,
      _0x25a3a1["width"] - _0x5b1a18,
      0x0,
      _0x5b1a18,
      _0x3bf275,
    );
    var _0x3c39b6 = new Image();
    ((_0x3c39b6["onload"] = function () {
      _0x2f3f7b(_0x3c39b6);
    }),
      (_0x3c39b6["src"] = _0x25a3a1["toDataURL"]()));
  });
}
function _0x4ac6bb(_0x8962d1, _0x19a8b3) {
  return new Promise(function (_0x394f54, _0x3b05c4) {
    var _0x4146be = document["createElement"]("canvas"),
      _0x2a3771 = _0x4146be["getContext"]("2d");
    ((_0x2a3771["fillStyle"] = "white"),
      _0x2a3771["fillRect"](0x0, 0x0, _0x4146be["width"], _0x4146be["height"]));
    var _0x267372 = (_0x19a8b3 * Math["PI"]) / 0xb4,
      _0x94aa3c = Math["cos"](_0x267372),
      _0x25fa1b = Math["sin"](_0x267372);
    (_0x25fa1b < 0x0 && (_0x25fa1b = -_0x25fa1b),
      _0x94aa3c < 0x0 && (_0x94aa3c = -_0x94aa3c),
      (_0x4146be["width"] =
        _0x8962d1["height"] * _0x25fa1b + _0x8962d1["width"] * _0x94aa3c),
      (_0x4146be["height"] =
        _0x8962d1["height"] * _0x94aa3c + _0x8962d1["width"] * _0x25fa1b));
    var _0x1d6573 = _0x8962d1["width"],
      _0xa2a1fe = _0x8962d1["height"],
      _0x559ff8 = _0x4146be["width"] / 0x2,
      _0x42019a = _0x4146be["height"] / 0x2,
      _0x395f30 = Math["PI"] / 0xb4;
    (_0x2a3771["translate"](_0x559ff8, _0x42019a),
      _0x2a3771["rotate"](_0x19a8b3 * _0x395f30),
      _0x2a3771["drawImage"](
        _0x8962d1,
        -_0x1d6573 / 0x2,
        -_0xa2a1fe / 0x2,
        _0x1d6573,
        _0xa2a1fe,
      ));
    var _0x24941d = new Image();
    ((_0x24941d["onload"] = function () {
      _0x394f54(_0x24941d);
    }),
      (_0x24941d["src"] = _0x4146be["toDataURL"]()));
  });
}
function _0x2c4482(_0x72c798, _0x587ca9, _0xd1079) {
  return new Promise(function (_0x3cc26c, _0x1ec536) {
    let _0x3e3818 = document["createElement"]("canvas");
    ((_0x3e3818["width"] = _0x72c798["width"] + _0x587ca9["width"]),
      (_0x3e3818["height"] = _0x72c798["height"]));
    let _0x1a89db = _0x3e3818["getContext"]("2d");
    ((_0x1a89db["fillStyle"] = "white"),
      _0x1a89db["fillRect"](0x0, 0x0, _0x3e3818["width"], _0x3e3818["height"]));
    var _0x5b5d66 = _0x587ca9["width"];
    (_0x587ca9["height"],
      "left" === _0xd1079
        ? _0x1a89db["drawImage"](_0x72c798, _0x5b5d66, 0x0)
        : "right" === _0xd1079 && _0x1a89db["drawImage"](_0x72c798, 0x0, 0x0));
    var _0xb8ecb9 = new Image();
    ((_0xb8ecb9["onload"] = function () {
      _0x3cc26c(_0xb8ecb9);
    }),
      (_0xb8ecb9["src"] = _0x3e3818["toDataURL"]()));
  });
}
function _0x49dabb(_0x4feb9d, _0x19324e, _0x583d77) {
  return new Promise(function (_0x247425, _0x48aa4d) {
    let _0x88073c = document["createElement"]("canvas");
    ((_0x88073c["width"] = _0x4feb9d["width"] + _0x19324e),
      (_0x88073c["height"] = _0x4feb9d["height"]));
    let _0x59f6c1 = _0x88073c["getContext"]("2d");
    ((_0x59f6c1["fillStyle"] = "white"),
      _0x59f6c1["fillRect"](0x0, 0x0, _0x88073c["width"], _0x88073c["height"]));
    var _0x4ae787 = _0x19324e;
    "top" === _0x583d77
      ? _0x59f6c1["drawImage"](_0x4feb9d, 0x0, _0x4ae787)
      : "botttom" === _0x583d77 && _0x59f6c1["drawImage"](_0x4feb9d, 0x0, 0x0);
    var _0x4026e4 = new Image();
    ((_0x4026e4["onload"] = function () {
      _0x247425(_0x4026e4);
    }),
      (_0x4026e4["src"] = _0x88073c["toDataURL"]()));
  });
}
function _0x503aee(_0x38d3aa) {
  return new Promise(function (_0x512690, _0x3fd356) {
    let _0x1cbae9 = document["createElement"]("canvas");
    console["log"]("Making\x20image\x20aspect\x20same");
    if (_0x38d3aa["width"] > _0x38d3aa["height"])
      ((_0x1cbae9["width"] = _0x38d3aa["width"]),
        (_0x1cbae9["height"] =
          _0x38d3aa["height"] + (_0x38d3aa["width"] - _0x38d3aa["height"])));
    else
      _0x38d3aa["width"] < _0x38d3aa["height"]
        ? ((_0x1cbae9["height"] = _0x38d3aa["height"]),
          (_0x1cbae9["width"] =
            _0x38d3aa["width"] + (_0x38d3aa["height"] - _0x38d3aa["width"])))
        : (console["log"]("Image\x20is\x20already\x20a\x20square"),
          _0x512690(_0x38d3aa));
    console["log"]("Done\x20making\x20image\x20aspect\x20same");
    let _0x51ed17 = _0x1cbae9["getContext"]("2d");
    ((_0x51ed17["fillStyle"] = "white"),
      _0x51ed17["fillRect"](0x0, 0x0, _0x1cbae9["width"], _0x1cbae9["height"]),
      _0x51ed17["drawImage"](
        _0x38d3aa,
        (_0x1cbae9["width"] - _0x38d3aa["width"]) / 0x2,
        (_0x1cbae9["height"] - _0x38d3aa["height"]) / 0x2,
      ));
    var _0x4a1e64 = new Image();
    ((_0x4a1e64["onload"] = function () {
      _0x512690(_0x4a1e64);
    }),
      (_0x4a1e64["src"] = _0x1cbae9["toDataURL"]()));
  });
}
function _0x76650c(_0x2885d8, _0x4088ec, _0x12c8f3) {
  return new Promise(function (_0x2c9c73, _0x41d1b1) {
    let _0xdeddf8 = document["createElement"]("canvas");
    ((_0xdeddf8["width"] = _0x2885d8["width"]),
      (_0xdeddf8["height"] = _0x2885d8["height"]));
    let _0x5ac275 = _0xdeddf8["getContext"]("2d");
    ((_0x5ac275["fillStyle"] = "white"),
      _0x5ac275["fillRect"](0x0, 0x0, _0xdeddf8["width"], _0xdeddf8["height"]));
    var _0x421504 = _0x4088ec["width"],
      _0x414a53 = _0x4088ec["height"];
    (_0x5ac275["drawImage"](_0x2885d8, 0x0, 0x0),
      (_0x5ac275["globalAlpha"] = _0x12c8f3));
    var _0x1dd093 = 0x0 + _0xdeddf8["width"] / 0x32;
    _0x5ac275["drawImage"](_0x4088ec, _0x1dd093, 0x0, _0x421504, _0x414a53);
    var _0xffa1c6 = new Image();
    ((_0xffa1c6["onload"] = function () {
      _0x2c9c73(_0xffa1c6);
    }),
      (_0xffa1c6["src"] = _0xdeddf8["toDataURL"]()));
  });
}
function _0x7a3ab9(_0x347a61, _0x13678a, _0x4c6b2f) {
  return new Promise(async function (_0x4e9199, _0x589c18) {
    let _0x3abe8b = document["createElement"]("canvas");
    ((_0x3abe8b["width"] = _0x347a61["width"]),
      (_0x3abe8b["height"] = _0x347a61["height"]));
    let _0x2eba06 = _0x3abe8b["getContext"]("2d");
    ((_0x2eba06["fillStyle"] = "white"),
      _0x2eba06["fillRect"](0x0, 0x0, _0x3abe8b["width"], _0x3abe8b["height"]),
      _0x2eba06["drawImage"](_0x347a61, 0x0, 0x0),
      (_0x2eba06["globalAlpha"] = _0x4c6b2f),
      _0x2eba06["drawImage"](
        _0x13678a,
        _0x3abe8b["width"] - _0x13678a["width"],
        0x0,
        _0x13678a["width"],
        _0x13678a["height"],
      ));
    var _0x57e1ae = new Image();
    ((_0x57e1ae["onload"] = function () {
      _0x4e9199(_0x57e1ae);
    }),
      (_0x57e1ae["src"] = _0x3abe8b["toDataURL"]()));
  });
}
function _0x5c2aa1(_0x540f08, _0x484f77, _0x3fda55) {
  return new Promise(function (_0x382137, _0x268458) {
    let _0x3d07ee = document["createElement"]("canvas");
    ((_0x3d07ee["width"] = _0x540f08["width"]),
      (_0x3d07ee["height"] = _0x540f08["height"]));
    let _0x2b262a = _0x3d07ee["getContext"]("2d");
    ((_0x2b262a["fillStyle"] = "white"),
      _0x2b262a["fillRect"](0x0, 0x0, _0x3d07ee["width"], _0x3d07ee["height"]),
      _0x2b262a["drawImage"](_0x540f08, 0x0, 0x0),
      (_0x2b262a["globalAlpha"] = _0x3fda55));
    var _0x47ee07 = _0x484f77["width"],
      _0x2e7080 = _0x484f77["height"];
    _0x2b262a["drawImage"](
      _0x484f77,
      _0x3d07ee["width"] - _0x47ee07,
      0x0,
      _0x47ee07,
      _0x2e7080,
    );
    var _0x2fd924 = new Image();
    ((_0x2fd924["onload"] = function () {
      _0x382137(_0x2fd924);
    }),
      (_0x2fd924["src"] = _0x3d07ee["toDataURL"]()));
  });
}
function _0x42619d(
  _0x546269,
  _0x5ad9c2,
  _0x5da5e9,
  _0x3ce126,
  _0x42dfa6,
  _0xd85ed2,
) {
  (_0x546269["beginPath"](),
    _0x546269["moveTo"](_0x5ad9c2 + _0xd85ed2, _0x5da5e9),
    _0x546269["lineTo"](_0x5ad9c2 + _0x3ce126 - _0xd85ed2, _0x5da5e9),
    _0x546269["quadraticCurveTo"](
      _0x5ad9c2 + _0x3ce126,
      _0x5da5e9,
      _0x5ad9c2 + _0x3ce126,
      _0x5da5e9 + _0xd85ed2,
    ),
    _0x546269["lineTo"](
      _0x5ad9c2 + _0x3ce126,
      _0x5da5e9 + _0x42dfa6 - _0xd85ed2,
    ),
    _0x546269["quadraticCurveTo"](
      _0x5ad9c2 + _0x3ce126,
      _0x5da5e9 + _0x42dfa6,
      _0x5ad9c2 + _0x3ce126 - _0xd85ed2,
      _0x5da5e9 + _0x42dfa6,
    ),
    _0x546269["lineTo"](_0x5ad9c2 + _0xd85ed2, _0x5da5e9 + _0x42dfa6),
    _0x546269["quadraticCurveTo"](
      _0x5ad9c2,
      _0x5da5e9 + _0x42dfa6,
      _0x5ad9c2,
      _0x5da5e9 + _0x42dfa6 - _0xd85ed2,
    ),
    _0x546269["lineTo"](_0x5ad9c2, _0x5da5e9 + _0xd85ed2),
    _0x546269["quadraticCurveTo"](
      _0x5ad9c2,
      _0x5da5e9,
      _0x5ad9c2 + _0xd85ed2,
      _0x5da5e9,
    ),
    _0x546269["closePath"]());
}
function _0x345db0(_0x68c30f, _0x2b31a6, _0x37c7d6, _0x1a88b7) {
  return new Promise(function (_0xa45c15, _0x41086d) {
    let _0x191850 = document["createElement"]("canvas");
    ((_0x191850["width"] = _0x68c30f["width"]),
      (_0x191850["height"] = _0x68c30f["height"]));
    let _0x50c54e = _0x191850["getContext"]("2d");
    ((_0x50c54e["fillStyle"] = "white"),
      _0x50c54e["fillRect"](0x0, 0x0, _0x191850["width"], _0x191850["height"]),
      _0x50c54e["drawImage"](_0x68c30f, 0x0, 0x0),
      (_0x50c54e["globalAlpha"] = _0x37c7d6));
    var _0x177fc5 =
        _0x191850["width"] - _0x2b31a6["width"] - _0x191850["width"] / 0x32,
      _0x34aeee =
        _0x191850["height"] -
        _0x2b31a6["height"] -
        _0x191850["height"] / _0x1a88b7;
    (_0x42619d(
      _0x50c54e,
      _0x177fc5,
      _0x34aeee,
      _0x2b31a6["width"],
      _0x2b31a6["height"],
      0xa,
    ),
      _0x50c54e["clip"](),
      _0x50c54e["drawImage"](_0x2b31a6, _0x177fc5, _0x34aeee));
    var _0x300f9c = new Image();
    ((_0x300f9c["onload"] = function () {
      _0xa45c15(_0x300f9c);
    }),
      (_0x300f9c["src"] = _0x191850["toDataURL"]()));
  });
}
function _0x4e2f2a(_0x19933c, _0x31b974, _0x5b52dd, _0x2b6ffa) {
  return new Promise(function (_0x5d63e8, _0x4e9444) {
    let _0x27a40f = document["createElement"]("canvas");
    ((_0x27a40f["width"] = _0x19933c["width"]),
      (_0x27a40f["height"] = _0x19933c["height"]));
    let _0x2efdec = _0x27a40f["getContext"]("2d");
    ((_0x2efdec["fillStyle"] = "white"),
      _0x2efdec["fillRect"](0x0, 0x0, _0x27a40f["width"], _0x27a40f["height"]),
      _0x2efdec["drawImage"](_0x19933c, 0x0, 0x0),
      (_0x2efdec["globalAlpha"] = _0x5b52dd));
    var _0x4a733b = 0x0 + _0x27a40f["width"] / 0x32,
      _0x321212 =
        _0x27a40f["height"] -
        _0x31b974["height"] -
        _0x27a40f["height"] / _0x2b6ffa;
    _0x2efdec["drawImage"](_0x31b974, _0x4a733b, _0x321212);
    var _0x5812e3 = new Image();
    ((_0x5812e3["onload"] = function () {
      _0x5d63e8(_0x5812e3);
    }),
      (_0x5812e3["src"] = _0x27a40f["toDataURL"]()));
  });
}
function _0x14bc5b(_0x1805f8, _0x27f234, _0x2e9681) {
  return new Promise(function (_0x4e8fa9, _0x7a2b02) {
    let _0x43ff7f = document["createElement"]("canvas");
    ((_0x43ff7f["width"] = _0x1805f8["width"]),
      (_0x43ff7f["height"] = _0x1805f8["height"]));
    let _0x55ff54 = _0x43ff7f["getContext"]("2d");
    ((_0x55ff54["fillStyle"] = "white"),
      _0x55ff54["fillRect"](0x0, 0x0, _0x43ff7f["width"], _0x43ff7f["height"]),
      _0x55ff54["drawImage"](_0x1805f8, 0x0, 0x0),
      _0x55ff54["drawImage"](
        _0x27f234,
        _0x2e9681,
        _0x43ff7f["height"] - _0x27f234["height"],
      ));
    var _0x462854 = new Image();
    ((_0x462854["onload"] = function () {
      _0x4e8fa9(_0x462854);
    }),
      (_0x462854["src"] = _0x43ff7f["toDataURL"]()));
  });
}
function _0x2988c9(_0x3f420e, _0x33ed21) {
  return new Promise(function (_0x5c1081, _0x425f8c) {
    let _0x35018e = document["createElement"]("canvas");
    ((_0x35018e["width"] = _0x3f420e["width"]),
      (_0x35018e["height"] = _0x3f420e["height"]));
    let _0x1e0478 = _0x35018e["getContext"]("2d");
    ((_0x1e0478["fillStyle"] = "white"),
      _0x1e0478["fillRect"](0x0, 0x0, _0x35018e["width"], _0x35018e["height"]),
      (_0x1e0478["globalAlpha"] = _0x33ed21),
      _0x1e0478["drawImage"](_0x3f420e, 0x0, 0x0));
    var _0xa12592 = new Image();
    ((_0xa12592["onload"] = function () {
      _0x5c1081(_0xa12592);
    }),
      (_0xa12592["src"] = _0x35018e["toDataURL"]()));
  });
}
function _0x7edcc4(_0x4653d2, _0x1f9e25) {
  return new Promise(function (_0x55aff6, _0x516de6) {
    let _0x180c19 = document["createElement"]("canvas");
    ((_0x180c19["width"] = _0x4653d2["width"] + imgWatermark["width"]),
      (_0x180c19["height"] = _0x4653d2["height"]));
    let _0x3f06bd = _0x180c19["getContext"]("2d");
    ((_0x3f06bd["fillStyle"] = "white"),
      _0x3f06bd["fillRect"](0x0, 0x0, _0x180c19["width"], _0x180c19["height"]),
      (_0x3f06bd["globalAlpha"] = _0x1f9e25),
      _0x3f06bd["drawImage"](_0x4653d2, 0x0, 0x0));
    var _0x92e0b6 = 0.9 * imgWatermark["width"],
      _0x2ce284 = 0.9 * imgWatermark["height"];
    _0x3f06bd["drawImage"](
      imgWatermark,
      _0x180c19["width"] - _0x92e0b6,
      0x0,
      _0x92e0b6,
      _0x2ce284,
    );
    var _0x33aa08 = new Image();
    ((_0x33aa08["onload"] = function () {
      _0x55aff6(_0x33aa08);
    }),
      (_0x33aa08["src"] = _0x180c19["toDataURL"]()));
  });
}
function _0x467f3f(_0x529dab) {
  return new Promise((_0x2b1fcb, _0x4fd852) => {
    var _0x11ca5d = document["createElement"]("canvas"),
      _0x14854c = _0x11ca5d["getContext"]("2d");
    ((_0x11ca5d["width"] = _0x529dab["width"]),
      (_0x11ca5d["height"] = _0x529dab["height"]));
    var _0x3ef422 = new Image();
    ((_0x3ef422["onload"] = function () {
      (_0x14854c["drawImage"](_0x529dab, 0x0, 0x0), _0x2b1fcb(_0x11ca5d));
    }),
      (_0x3ef422["src"] = _0x529dab["src"]));
  });
}
function _0x144c6b(_0x1d8a46) {
  return new Promise((_0x3d9843, _0x3f7c17) => {
    var _0x2c3e2e = new Image();
    ((_0x2c3e2e["onload"] = function () {
      _0x3d9843(_0x2c3e2e);
    }),
      (_0x2c3e2e["src"] = _0x1d8a46["toDataURL"]()));
  });
}
function _0x402563(_0x5f3a1a) {
  return new Promise((_0x5533c0, _0x499e5b) => {
    var _0x2f3a0e = new Image(),
      _0x33e743 = document["createElement"]("canvas"),
      _0x23778a = _0x33e743["getContext"]("2d"),
      _0x210568 = {};
    ((_0x2f3a0e["onload"] = function () {
      ((_0x33e743["width"] = _0x2f3a0e["width"]),
        (_0x33e743["height"] = _0x2f3a0e["height"]),
        _0x23778a["drawImage"](
          _0x2f3a0e,
          0x0,
          0x0,
          _0x2f3a0e["width"],
          _0x2f3a0e["height"],
        ),
        (_0x210568 = _0x23778a["getImageData"](
          0x0,
          0x0,
          _0x2f3a0e["width"],
          _0x2f3a0e["height"],
        )["data"]));
      var _0x17d553 = _0x486b31(!0x0, _0x2f3a0e, _0x210568),
        _0x48a737 = _0x486b31(!0x1, _0x2f3a0e, _0x210568),
        _0x1267eb = _0x307c53(!0x0, _0x2f3a0e, _0x210568),
        _0x452d2b = _0x307c53(!0x1, _0x2f3a0e, _0x210568) - _0x1267eb,
        _0x5c1f22 = _0x48a737 - _0x17d553;
      ((_0x33e743["width"] = _0x452d2b),
        (_0x33e743["height"] = _0x5c1f22),
        _0x23778a["drawImage"](
          _0x2f3a0e,
          _0x1267eb,
          _0x17d553,
          _0x452d2b,
          _0x5c1f22,
          0x0,
          0x0,
          _0x452d2b,
          _0x5c1f22,
        ));
      let _0x416ae8 = new Image();
      ((_0x416ae8["crossOrigin"] = "anonymous"),
        (_0x416ae8["onload"] = function () {
          _0x5533c0(_0x416ae8);
        }),
        (_0x416ae8["src"] = _0x33e743["toDataURL"]()));
    }),
      (_0x2f3a0e["src"] = _0x5f3a1a["src"]));
  });
}
function _0x307c53(_0x16f561, _0x7a1d57, _0x655d4e) {
  var _0x49f477 = _0x16f561 ? 0x1 : -0x1;
  for (
    var _0x6e35e0 = _0x16f561 ? 0x0 : _0x7a1d57["width"] - 0x1;
    _0x16f561 ? _0x6e35e0 < _0x7a1d57["width"] : _0x6e35e0 > -0x1;
    _0x6e35e0 += _0x49f477
  )
    for (var _0x48103f = 0x0; _0x48103f < _0x7a1d57["height"]; _0x48103f++)
      if (!_0x247db0(_0x171678(_0x6e35e0, _0x48103f, _0x655d4e, _0x7a1d57)))
        return _0x6e35e0;
  return null;
}
function _0x486b31(_0x2100e3, _0x59256d, _0x51ce62) {
  var _0x51127c = _0x2100e3 ? 0x1 : -0x1;
  for (
    var _0x4682b2 = _0x2100e3 ? 0x0 : _0x59256d["height"] - 0x1;
    _0x2100e3 ? _0x4682b2 < _0x59256d["height"] : _0x4682b2 > -0x1;
    _0x4682b2 += _0x51127c
  )
    for (var _0x22f3cc = 0x0; _0x22f3cc < _0x59256d["width"]; _0x22f3cc++)
      if (!_0x247db0(_0x171678(_0x22f3cc, _0x4682b2, _0x51ce62, _0x59256d)))
        return _0x4682b2;
  return null;
}
function _0x247db0(_0x328c17) {
  return (
    0xff == _0x328c17["red"] &&
    0xff == _0x328c17["green"] &&
    0xff == _0x328c17["blue"]
  );
}
function _0x171678(_0x495164, _0xe498e5, _0x5df635, _0x1b6392) {
  return {
    red: _0x5df635[0x4 * (_0x1b6392["width"] * _0xe498e5 + _0x495164)],
    green: _0x5df635[0x4 * (_0x1b6392["width"] * _0xe498e5 + _0x495164) + 0x1],
    blue: _0x5df635[0x4 * (_0x1b6392["width"] * _0xe498e5 + _0x495164) + 0x2],
  };
}
function _0x264f24(_0x1dc82d) {
  return new Promise((_0x50472b, _0x4a9533) => {
    var _0x4f3718 = document["createElement"]("canvas"),
      _0x3b4d3d = _0x4f3718["getContext"]("2d");
    ((_0x4f3718["width"] = _0x1dc82d["width"]),
      (_0x4f3718["height"] = _0x1dc82d["height"]),
      _0x3b4d3d["drawImage"](
        _0x1dc82d,
        0x0,
        0x0,
        _0x1dc82d["width"],
        _0x1dc82d["height"],
      ));
    let _0x22d64e = _0x3b4d3d["getImageData"](
      0x0,
      0x0,
      _0x1dc82d["width"],
      _0x1dc82d["height"],
    );
    var _0x3147e8 = _0x22d64e["data"];
    for (let _0x6b72d7 = 0x0; _0x6b72d7 < _0x3147e8["length"]; _0x6b72d7 += 0x4)
      [
        _0x3147e8[_0x6b72d7],
        _0x3147e8[_0x6b72d7 + 0x1],
        _0x3147e8[_0x6b72d7 + 0x2],
      ]["every"]((_0x336e44) => _0x336e44 < 0x100 && _0x336e44 > 0xf5) &&
        (_0x3147e8[_0x6b72d7 + 0x3] = 0x0);
    _0x3b4d3d["putImageData"](_0x22d64e, 0x0, 0x0);
    var _0x184ffc = new Image();
    ((_0x184ffc["onload"] = function () {
      _0x50472b(_0x184ffc);
    }),
      (_0x184ffc["src"] = _0x4f3718["toDataURL"]()));
  });
}
async function _0x2c2c39(
  _0x309b16,
  _0x47e81e = "/Image_Badges/Best_Seller.png",
) {
  var _0x1fb9f8 = chrome["runtime"]["getURL"](_0x47e81e),
    _0x30a0e1 = await _0x90886d(_0x1fb9f8),
    _0x2ec2a3 = document["createElement"]("canvas"),
    _0x437c39 = _0x2ec2a3["getContext"]("2d");
  ((_0x2ec2a3["width"] = _0x309b16["width"]),
    (_0x2ec2a3["height"] = _0x309b16["height"] + _0x30a0e1["height"]),
    (_0x437c39["fillStyle"] = "white"),
    _0x437c39["fillRect"](0x0, 0x0, _0x2ec2a3["width"], _0x2ec2a3["height"]),
    _0x437c39["drawImage"](_0x309b16, 0x0, _0x30a0e1["height"]),
    _0x437c39["drawImage"](
      _0x30a0e1,
      0x0,
      0x0,
      _0x30a0e1["width"],
      _0x30a0e1["height"],
    ));
  var _0x46088c = new Image();
  return ((_0x46088c["src"] = _0x2ec2a3["toDataURL"]()), _0x46088c);
}
async function _0x16eeb8(
  _0x14890a,
  _0x5b9b16 = "/Image_Badges/Limited-Time-Deal-Badge.jpg",
) {
  var _0x43a50d = chrome["runtime"]["getURL"](_0x5b9b16),
    _0x397043 = await _0x90886d(_0x43a50d),
    _0x13a7b8 = document["createElement"]("canvas"),
    _0x147d3d = _0x13a7b8["getContext"]("2d");
  ((_0x13a7b8["width"] = _0x14890a["width"]),
    (_0x13a7b8["height"] = _0x14890a["height"]),
    (_0x147d3d["fillStyle"] = "white"),
    _0x147d3d["fillRect"](0x0, 0x0, _0x13a7b8["width"], _0x13a7b8["height"]),
    _0x147d3d["drawImage"](_0x14890a, 0x0, 0x0));
  var _0x5d52c5 = _0x14890a["width"] / 2.5,
    _0x474dd0 = _0x397043["height"] * (_0x5d52c5 / _0x397043["width"]);
  _0x147d3d["drawImage"](
    _0x397043,
    _0x14890a["width"] - _0x5d52c5,
    _0x14890a["height"] - _0x474dd0,
    _0x5d52c5,
    _0x474dd0,
  );
  var _0x4075ec = new Image();
  return ((_0x4075ec["src"] = _0x13a7b8["toDataURL"]()), _0x4075ec);
}
async function _0x2e444c(
  _0x20720d,
  _0x2da518,
  _0x40842f,
  _0xa719d6,
  _0x3d0f38,
  _0x56ee81,
  _0x5a5d2b,
  _0x574acf,
  _0x4db360,
  _0x320a87,
  _0x53a328 = !0x1,
) {
  (console["log"]("Creating\x20multi\x20image\x20V2"),
    console["log"]("imageSource", _0x20720d));
  var _0x5af664 = await _0x90886d(_0x20720d);
  ((_0x5af664 = await _0x55142f(_0x5af664, _0x5a5d2b, _0x574acf)),
    (_0x5af664 = await _0x402563(_0x5af664)));
  var _0x1a418d = await _0x90886d(_0x2da518),
    _0x5250f7 = await _0x90886d(_0xa719d6),
    _0x257a9b = await _0x90886d(_0x3d0f38);
  ((_0x1a418d = await _0x55142f(_0x1a418d, 0.45 * _0x5a5d2b, 0.45 * _0x574acf)),
    (_0x5250f7 = await _0x55142f(
      _0x5250f7,
      0.45 * _0x5a5d2b,
      0.45 * _0x574acf,
    )),
    (_0x257a9b = await _0x55142f(
      _0x257a9b,
      0.45 * _0x5a5d2b,
      0.45 * _0x574acf,
    )));
  var _0x3a8c95 = Math["max"](
    _0x1a418d["width"],
    _0x5250f7["width"],
    _0x257a9b["width"],
  );
  ((_0x5af664 = await _0x414dfd(_0x5af664, _0x3a8c95, "right")),
    (_0x5af664 = await _0x503aee(_0x5af664)),
    (_0x1a418d = await _0x55142f(_0x1a418d, 0.4 * _0x5a5d2b, 0.4 * _0x574acf)),
    (_0x5250f7 = await _0x55142f(_0x5250f7, 0.4 * _0x5a5d2b, 0.4 * _0x574acf)),
    (_0x257a9b = await _0x55142f(_0x257a9b, 0.4 * _0x5a5d2b, 0.4 * _0x574acf)));
  var _0x32e629 = 0x0;
  ((_0x5af664 = await _0x15bae9(_0x5af664, _0x1a418d, _0x32e629)),
    (_0x32e629 += _0x1a418d["height"] + _0x5af664["height"] / 0x19),
    (_0x5af664 = await _0x15bae9(_0x5af664, _0x5250f7, _0x32e629)),
    (_0x32e629 += _0x5250f7["height"] + _0x5af664["height"] / 0x19),
    (_0x5af664 = await _0x15bae9(_0x5af664, _0x257a9b, _0x32e629)));
  var _0x55e292 = await _0x90886d(_0x40842f);
  _0x55e292 = await _0x55142f(
    _0x55e292,
    0.2 * _0x5af664["height"],
    0.2 * _0x5af664["width"],
  );
  var _0x11374c = _0x5af664["height"],
    _0xe3eef3 = chrome["runtime"]["getURL"]("/Image_Badges/Best_Seller.png"),
    _0x1d66aa = await _0x90886d(_0xe3eef3),
    _0x502b17 = _0x5af664["height"] / 0x5,
    _0x4f2f4b = _0x1d66aa["width"] * (_0x502b17 / _0x1d66aa["height"]);
  _0x1d66aa = await _0x55142f(_0x1d66aa, _0x4f2f4b, _0x502b17);
  if (_0x53a328) {
    _0x5af664 = await _0x2c2c39(_0x5af664);
    var _0x427e92 =
      (_0x5af664 = await _0x16eeb8(_0x5af664))["height"] - _0x11374c;
    ((_0x55e292 = await _0x55142f(
      _0x55e292,
      _0x427e92,
      0.2 * _0x5af664["width"],
    )),
      (_0x5af664 = await _0x1d2519(_0x5af664, _0x55e292, 0.7)));
  }
  return await _0x45b37c(_0x5af664, 0x1f4, 0x1f4);
}
function _0x3b62f2(_0xe38206, _0x2b5739, _0x1501f8, _0x347cb1 = 0x1) {
  return new Promise(function (_0x431a0b, _0x4e6459) {
    let _0x4d568c = document["createElement"]("canvas");
    ((_0x4d568c["width"] = _0xe38206["width"]),
      (_0x4d568c["height"] = _0xe38206["height"]));
    let _0x407371 = _0x4d568c["getContext"]("2d");
    ((_0x407371["fillStyle"] = "white"),
      _0x407371["fillRect"](0x0, 0x0, _0x4d568c["width"], _0x4d568c["height"]),
      _0x407371["drawImage"](_0xe38206, 0x0, 0x0));
    var _0x55b899 = _0x1501f8;
    (_0x42619d(
      _0x407371,
      0x0,
      _0x55b899,
      _0x2b5739["width"],
      _0x2b5739["height"],
      0xa,
    ),
      (_0x407371["globalAlpha"] = _0x347cb1),
      _0x407371["drawImage"](_0x2b5739, 0x0, _0x55b899));
    let _0x41bd79 = new Image();
    ((_0x41bd79["src"] = _0x4d568c["toDataURL"]()), _0x431a0b(_0x41bd79));
  });
}
function _0x15bae9(_0x11c3d5, _0x4e1304, _0x20e613) {
  return new Promise(function (_0x995c04, _0x3b547b) {
    let _0x2144db = document["createElement"]("canvas");
    ((_0x2144db["width"] = _0x11c3d5["width"]),
      (_0x2144db["height"] = _0x11c3d5["height"]));
    let _0x20f80f = _0x2144db["getContext"]("2d");
    ((_0x20f80f["fillStyle"] = "white"),
      _0x20f80f["fillRect"](0x0, 0x0, _0x2144db["width"], _0x2144db["height"]),
      _0x20f80f["drawImage"](_0x11c3d5, 0x0, 0x0),
      (_0x20f80f["globalAlpha"] = 0.9));
    var _0x54bfe8 =
        _0x2144db["width"] - _0x4e1304["width"] - _0x2144db["width"] / 0x32,
      _0x475c2b = _0x20e613;
    (_0x42619d(
      _0x20f80f,
      _0x54bfe8,
      _0x475c2b,
      _0x4e1304["width"],
      _0x4e1304["height"],
      0xa,
    ),
      _0x20f80f["clip"](),
      _0x20f80f["drawImage"](_0x4e1304, _0x54bfe8, _0x475c2b));
    var _0x42f3ca = new Image();
    ((_0x42f3ca["onload"] = function () {
      _0x995c04(_0x42f3ca);
    }),
      (_0x42f3ca["src"] = _0x2144db["toDataURL"]()));
  });
}
function _0x414dfd(_0x58dd1b, _0x5e5932, _0x30d111) {
  return new Promise(function (_0x38ea27, _0x7b257b) {
    let _0x114036 = document["createElement"]("canvas");
    ((_0x114036["width"] = _0x58dd1b["width"] + _0x5e5932),
      (_0x114036["height"] = _0x58dd1b["height"]));
    let _0x1cfc9c = _0x114036["getContext"]("2d");
    ((_0x1cfc9c["fillStyle"] = "white"),
      _0x1cfc9c["fillRect"](0x0, 0x0, _0x114036["width"], _0x114036["height"]));
    var _0x573848 = _0x5e5932;
    "left" === _0x30d111
      ? _0x1cfc9c["drawImage"](_0x58dd1b, _0x573848, 0x0)
      : "right" === _0x30d111 && _0x1cfc9c["drawImage"](_0x58dd1b, 0x0, 0x0);
    var _0x3cc4e3 = new Image();
    ((_0x3cc4e3["onload"] = function () {
      _0x38ea27(_0x3cc4e3);
    }),
      (_0x3cc4e3["src"] = _0x114036["toDataURL"]()));
  });
}
function _0x3b1851(_0xebd23e, _0x9f4d66, _0x2a0950) {
  return new Promise(function (_0x374f72, _0x4b5d19) {
    let _0xbb996f = document["createElement"]("canvas");
    ((_0xbb996f["width"] = _0xebd23e["width"]),
      (_0xbb996f["height"] = _0xebd23e["height"] + _0x9f4d66));
    let _0x41f46c = _0xbb996f["getContext"]("2d");
    ((_0x41f46c["fillStyle"] = "white"),
      _0x41f46c["fillRect"](0x0, 0x0, _0xbb996f["width"], _0xbb996f["height"]));
    var _0x376630 = _0x9f4d66;
    "top" === _0x2a0950
      ? _0x41f46c["drawImage"](_0xebd23e, 0x0, _0x376630)
      : "bottom" === _0x2a0950 && _0x41f46c["drawImage"](_0xebd23e, 0x0, 0x0);
    var _0x3481d1 = new Image();
    ((_0x3481d1["onload"] = function () {
      _0x374f72(_0x3481d1);
    }),
      (_0x3481d1["src"] = _0xbb996f["toDataURL"]()));
  });
}
function _0x1d2519(_0x51a718, _0x7d69de, _0x190bb4) {
  return new Promise(async function (_0x144bbc, _0x542d2a) {
    let _0x1dc2f4 = document["createElement"]("canvas");
    ((_0x1dc2f4["width"] = _0x51a718["width"]),
      (_0x1dc2f4["height"] = _0x51a718["height"]));
    let _0x1c4b0d = _0x1dc2f4["getContext"]("2d");
    ((_0x1c4b0d["fillStyle"] = "white"),
      _0x1c4b0d["fillRect"](0x0, 0x0, _0x1dc2f4["width"], _0x1dc2f4["height"]),
      _0x1c4b0d["drawImage"](_0x51a718, 0x0, 0x0),
      (_0x1c4b0d["globalAlpha"] = _0x190bb4),
      _0x1c4b0d["drawImage"](
        _0x7d69de,
        _0x1dc2f4["width"] - _0x7d69de["width"],
        0x0,
        _0x7d69de["width"],
        _0x7d69de["height"],
      ));
    var _0x32ef28 = new Image();
    ((_0x32ef28["onload"] = function () {
      _0x144bbc(_0x32ef28);
    }),
      (_0x32ef28["src"] = _0x1dc2f4["toDataURL"]()));
  });
}
function _0x2e32dd(_0x1de7c9) {
  return new Promise(function (_0x51a7a1, _0x43b1e5) {
    let _0x123249 = document["createElement"]("canvas");
    (_0x1de7c9["width"], _0x1de7c9["height"]);
    if (_0x1de7c9["width"] > _0x1de7c9["height"])
      ((_0x123249["width"] = _0x1de7c9["width"]),
        (_0x123249["height"] =
          _0x1de7c9["height"] + (_0x1de7c9["width"] - _0x1de7c9["height"])));
    else {
      if (!(_0x1de7c9["width"] < _0x1de7c9["height"])) return _0x1de7c9;
      ((_0x123249["height"] = _0x1de7c9["height"]),
        (_0x123249["width"] =
          _0x1de7c9["width"] + (_0x1de7c9["height"] - _0x1de7c9["width"])));
    }
    let _0x2135c8 = _0x123249["getContext"]("2d");
    ((_0x2135c8["fillStyle"] = "white"),
      _0x2135c8["fillRect"](0x0, 0x0, _0x123249["width"], _0x123249["height"]),
      _0x2135c8["drawImage"](
        _0x1de7c9,
        _0x123249["width"] - _0x1de7c9["width"],
        _0x123249["height"] - _0x1de7c9["height"],
      ));
    var _0x17897f = new Image();
    ((_0x17897f["onload"] = function () {
      _0x51a7a1(_0x17897f);
    }),
      (_0x17897f["src"] = _0x123249["toDataURL"]()));
  });
}
async function _0x29313e(_0x51b788, _0x1e6191) {
  var _0x45ecaf = await _0x90886d(_0x51b788);
  _0x45ecaf = await _0x55142f(_0x45ecaf, 0x5dc, 0x5dc);
  var _0xe2559b = [];
  for (var _0x2daa5b = 0x0; _0x2daa5b < _0x1e6191["length"]; _0x2daa5b++) {
    var _0x3c1e35 = await _0x90886d(_0x1e6191[_0x2daa5b]);
    ((_0x3c1e35 = await _0x55142f(
      _0x3c1e35,
      _0x45ecaf["width"] / _0x1e6191["length"],
      _0x45ecaf["height"] / _0x1e6191["length"],
    )),
      _0xe2559b["push"](_0x3c1e35));
  }
  var _0x1089a8 = _0xe2559b[0x0];
  for (_0x2daa5b = 0x0; _0x2daa5b < _0xe2559b["length"]; _0x2daa5b++)
    _0xe2559b[_0x2daa5b]["width"] > _0x1089a8["width"] &&
      (_0x1089a8 = _0xe2559b[_0x2daa5b]);
  _0x45ecaf = await _0x3b1851(_0x45ecaf, _0x1089a8["height"], "bottom");
  for (_0x2daa5b = 0x0; _0x2daa5b < _0xe2559b["length"]; _0x2daa5b++)
    _0x45ecaf = await _0x14bc5b(
      _0x45ecaf,
      _0xe2559b[_0x2daa5b],
      _0x2daa5b * (_0x45ecaf["width"] / _0xe2559b["length"]),
    );
  return _0x45ecaf;
}
async function _0x4e8ad3(_0x1152a3, _0x23c480, _0x53982e) {
  ((_0x1152a3 = await _0x55142f(_0x1152a3, 0x5dc, 0x5dc)),
    (_0x1152a3 = await _0x402563(_0x1152a3)));
  var _0x5d0617 = await _0x90886d(_0x53982e);
  ((_0x5d0617 = await _0x402563(_0x5d0617)),
    (_0x5d0617 = await _0x55142f(_0x5d0617, 0x2a3, 0x2a3)));
  var _0x1e7004 = await _0x90886d(_0x23c480);
  return (
    (_0x1e7004 = await _0x55142f(_0x1e7004, 0x2a3, 0x2a3)),
    (_0x1152a3 = await _0x2c4482(_0x1152a3, _0x1e7004, "right")),
    (_0x1e7004 = await _0x55142f(_0x1e7004, 0x258, 0x258)),
    (_0x1152a3 = await _0x345db0(_0x1152a3, _0x1e7004, 0x1, 0xc)),
    (_0x5d0617 = await _0x590ca7(
      _0x5d0617,
      0.65 * _0x1e7004["width"],
      0.65 * _0x1e7004["height"],
    )),
    (_0x5d0617 = await _0x264f24(_0x5d0617)),
    (_0x1152a3 = await _0x7a3ab9(_0x1152a3, _0x5d0617, 0.7)),
    (_0x1152a3 = await _0x503aee(_0x1152a3)),
    await _0x45b37c(_0x1152a3, 0x1f4, 0x1f4)
  );
}
function _0x1f301c(_0x4e366a, _0x2a4a37) {
  return new Promise((_0x1f7b1c, _0x5a6c34) => {
    const _0xd04417 = _0x4e366a,
      _0x4dd016 = document["createElement"]("canvas");
    ((_0x4dd016["width"] = _0xd04417["width"]),
      (_0x4dd016["height"] = _0xd04417["height"]));
    const _0x27dbbc = _0x4dd016["getContext"]("2d");
    (_0x27dbbc["clearRect"](0x0, 0x0, _0x4dd016["width"], _0x4dd016["height"]),
      _0x27dbbc["save"](),
      _0x27dbbc["beginPath"](),
      _0x27dbbc["moveTo"](_0x2a4a37, 0x0),
      _0x27dbbc["lineTo"](_0x4dd016["width"] - _0x2a4a37, 0x0),
      _0x27dbbc["quadraticCurveTo"](
        _0x4dd016["width"],
        0x0,
        _0x4dd016["width"],
        _0x2a4a37,
      ),
      _0x27dbbc["lineTo"](_0x4dd016["width"], _0x4dd016["height"] - _0x2a4a37),
      _0x27dbbc["quadraticCurveTo"](
        _0x4dd016["width"],
        _0x4dd016["height"],
        _0x4dd016["width"] - _0x2a4a37,
        _0x4dd016["height"],
      ),
      _0x27dbbc["lineTo"](_0x2a4a37, _0x4dd016["height"]),
      _0x27dbbc["quadraticCurveTo"](
        0x0,
        _0x4dd016["height"],
        0x0,
        _0x4dd016["height"] - _0x2a4a37,
      ),
      _0x27dbbc["lineTo"](0x0, _0x2a4a37),
      _0x27dbbc["quadraticCurveTo"](0x0, 0x0, _0x2a4a37, 0x0),
      _0x27dbbc["clip"](),
      _0x27dbbc["drawImage"](
        _0xd04417,
        0x0,
        0x0,
        _0x4dd016["width"],
        _0x4dd016["height"],
      ),
      _0x27dbbc["restore"]());
    const _0x2c142e = new Image();
    ((_0x2c142e["onload"] = () => {
      _0x1f7b1c(_0x2c142e);
    }),
      (_0x2c142e["src"] = _0x4dd016["toDataURL"]()));
  });
}
async function _0x2a3942(_0x560521, _0x3dbe6c) {
  var _0x1431be = document["createElement"]("canvas");
  ((_0x1431be["width"] = 0x1f4), (_0x1431be["height"] = 0x1f4));
  var _0x58360b = _0x1431be["getContext"]("2d");
  ((_0x58360b["fillStyle"] = "#E53238"),
    _0x58360b["fillRect"](0x0, 0x0, _0x1431be["width"], 0x14),
    (_0x58360b["fillStyle"] = "#0074E8"),
    _0x58360b["fillRect"](
      _0x1431be["width"] - 0x14,
      0x0,
      0x14,
      _0x1431be["height"],
    ),
    (_0x58360b["fillStyle"] = "#F5AF02"),
    _0x58360b["fillRect"](
      0x0,
      _0x1431be["height"] - 0x14,
      _0x1431be["width"],
      0x14,
    ),
    (_0x58360b["fillStyle"] = "#86B817"),
    _0x58360b["fillRect"](0x0, 0x0, 0x14, _0x1431be["height"]));
  var _0x1f4c58 = _0x1431be["width"] - 0x28,
    _0xf752d = _0x1431be["height"] - 0x28;
  ((_0x58360b["fillStyle"] = "#ffffff"),
    _0x58360b["fillRect"](0x14, 0x14, _0x1f4c58, _0xf752d));
  var _0xdfd24a = "Informationen\x20zur\x20Produktsicherheit";
  ((_0x58360b["font"] = "bold\x2024px\x20Arial"),
    (_0x58360b["fillStyle"] = "#000"));
  var _0x488007 =
    0x14 + (_0x1f4c58 - _0x58360b["measureText"](_0xdfd24a)["width"]) / 0x2;
  (_0x58360b["fillText"](_0xdfd24a, _0x488007, 0x28),
    (_0x58360b["strokeStyle"] = "#cccccc"),
    (_0x58360b["lineWidth"] = 0x1),
    _0x58360b["beginPath"](),
    _0x58360b["moveTo"](0x1e, 0x4b),
    _0x58360b["lineTo"](0x14 + _0x1f4c58 - 0xa, 0x4b),
    _0x58360b["stroke"]());
  var _0x59d0c8 = 0x14 + _0xf752d - 0xa;
  function _0x4881af(
    _0x9431c7,
    _0x1510d7,
    _0x36b3a0,
    _0x1ae90d,
    _0x6d584,
    _0x128ec3,
    _0xf27c38,
  ) {
    ((_0x9431c7["fillStyle"] = "#000"),
      (_0x9431c7["font"] = "bold\x2016px\x20Arial"),
      (_0x9431c7["textBaseline"] = "top"),
      _0x9431c7["fillText"](_0x6d584, _0x1510d7 + 0x8, _0x36b3a0),
      (_0x36b3a0 += 0x14),
      (_0x9431c7["font"] = "14px\x20Arial"));
    var _0x2c2c34 = (function (_0x51f723, _0x433dd0, _0xc55b6f) {
      var _0x491783 = _0x433dd0["split"]("\x0a"),
        _0x8ebb5f = [];
      for (var _0x488b48 = 0x0; _0x488b48 < _0x491783["length"]; _0x488b48++) {
        var _0x5920d5 = _0x491783[_0x488b48]["split"]("\x20"),
          _0x3c5802 = "";
        for (
          var _0x173f73 = 0x0;
          _0x173f73 < _0x5920d5["length"];
          _0x173f73++
        ) {
          var _0x57bd81 = _0x3c5802 + _0x5920d5[_0x173f73] + "\x20";
          if (
            _0x51f723["measureText"](_0x57bd81)["width"] > _0xc55b6f &&
            _0x173f73 > 0x0
          )
            (_0x8ebb5f["push"](_0x3c5802["trim"]()),
              (_0x3c5802 = _0x5920d5[_0x173f73] + "\x20"));
          else _0x3c5802 = _0x57bd81;
        }
        _0x8ebb5f["push"](_0x3c5802["trim"]());
      }
      return _0x8ebb5f;
    })(_0x9431c7, _0x128ec3, _0x1ae90d - 0x10);
    for (
      var _0x308024 = 0x0;
      _0x308024 < _0x2c2c34["length"] && !(_0x36b3a0 + 0x10 > _0xf27c38);
      _0x308024++
    ) {
      (_0x9431c7["fillText"](_0x2c2c34[_0x308024], _0x1510d7 + 0x8, _0x36b3a0),
        (_0x36b3a0 += 0x10));
    }
    return _0x36b3a0;
  }
  var _0x53efa7 = _0x4881af(
    _0x58360b,
    0x14,
    0x55,
    _0x1f4c58,
    "Hersteller:",
    _0x560521,
    0x55 + (0x14 + _0xf752d - 0x55 - 0xa) / 0x2,
  );
  return (
    _0x4881af(
      _0x58360b,
      0x14,
      (_0x53efa7 += 0xa),
      _0x1f4c58,
      "EU\x20Verantwortliche\u00a0Person:",
      _0x3dbe6c,
      _0x59d0c8,
    ),
    (_0x58360b["strokeStyle"] = "#eeeeee"),
    (_0x58360b["lineWidth"] = 0x2),
    _0x58360b["strokeRect"](0x14, 0x14, _0x1f4c58, _0xf752d),
    new Promise(function (_0x56b1c4) {
      var _0x3e0291 = new Image();
      ((_0x3e0291["src"] = _0x1431be["toDataURL"]("image/png")),
        (_0x3e0291["onload"] = function () {
          _0x56b1c4(_0x3e0291);
        }));
    })
  );
}
function _0x279217(_0x4af1ec) {
  return new Promise((_0x5b75f3, _0x747caf) => {
    const _0x27fd01 = btoa(_0x4af1ec);
    chrome["storage"]["local"]["get"]("skuList", (_0x127ede) => {
      const _0x4f728d = _0x127ede["skuList"] || [];
      if (_0x4f728d["includes"](_0x27fd01))
        _0x747caf("SKU\x20already\x20exists\x20in\x20list");
      else
        (_0x4f728d["push"](_0x27fd01),
          chrome["storage"]["local"]["set"]({ skuList: _0x4f728d }, _0x5b75f3));
    });
  });
}
async function _0x1fd9a7(_0x33d253, _0x465897) {
  return new Promise((_0x4d42ae, _0x5e2178) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x33d253, data: _0x465897 },
      function (_0x54c3d7) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x465897),
          console["log"]("fetchData\x20response", _0x54c3d7),
          _0x4d42ae(_0x54c3d7["data"]));
      },
    );
  });
}
async function _0x22ea05(_0x1e9ac1, _0x3234f6) {
  return new Promise((_0x2f8ef1, _0x4aca64) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x1e9ac1, data: _0x3234f6 },
      function (_0x26543c) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x3234f6),
          console["log"]("fetchData\x20response", _0x26543c),
          _0x26543c["error"] && _0x4aca64(_0x26543c["error"]),
          _0x2f8ef1(_0x26543c["data"]));
      },
    );
  });
}
var _0xd9d0d8 = {
  title:
    "Amazon\x20Essentials\x20Mens\x20Athletic-fit\x205-Pocket\x20Stretch\x20Twill\x20PantCasual\x20Pants",
  custom_title:
    "Mens\x20Athletic-fit\x205-Pocket\x20Stretch\x20Twill\x20PantCasual\x20Pants",
  filteredTitle:
    "Mens\x20Athletic-fit\x205-Pocket\x20Stretch\x20Twill\x20PantCasual\x20Pants",
  price: 31.9,
  custom_price: "63.99",
  brand: "Amazon\x20Essentials",
  sku: "B07P2C3XF8",
  upc: "Does\x20Not\x20Apply",
  descriptionHTML:
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p>\x20<span>\x20Essentials\x20is\x20focused\x20on\x20creating\x20affordable,\x20high-quality,\x20and\x20long-lasting\x20everyday\x20clothing\x20you\x20can\x20rely\x20on.\x20Our\x20line\x20of\x20men\x27s\x20must-haves\x20includes\x20polo\x20shirts,\x20chino\x20pants,\x20classic-fit\x20shorts,\x20casual\x20button-downs,\x20and\x20crew-neck\x20tees.\x20Our\x20consistent\x20sizing\x20takes\x20the\x20guesswork\x20out\x20of\x20shopping,\x20and\x20each\x20piece\x20is\x20put\x20to\x20the\x20test\x20to\x20maintain\x20the\x20highest\x20standards\x20in\x20quality\x20and\x20comfort.</span>\x20\x20</p>",
  bullet_points: [
    "ATHLETIC\x20FIT:\x20Our\x20men\x27s\x20athletic\x20pants\x20are\x20designed\x20with\x20a\x20relaxed\x20fit.\x20These\x20casual\x20pants\x20for\x20men\x20offer\x20extra\x20room\x20in\x20the\x20hip\x20and\x20thigh\x20while\x20sitting\x20nicely\x20at\x20the\x20waist,\x20ideal\x20for\x20athletic\x20builds.",
    "STRETCH\x20TWILL:\x20Crafted\x20from\x20stretch\x20cotton\x20twill,\x20these\x20men\x27s\x20stretch\x20pants\x20provide\x20comfort\x20and\x20flexibility,\x20making\x20them\x20ideal\x20for\x20everyday\x20wear\x20and\x20movement.",
    "EVERYDAY\x20CASUAL:\x20Featuring\x20classic\x205\x20pocket\x20pants,\x20these\x20versatile\x20casual\x20pants\x20blend\x20seamlessly\x20into\x20any\x20wardrobe\x20with\x20a\x20timeless,\x20jeans-inspired\x20look.",
    "QUALITY\x20DETAILS:\x20Includes\x20a\x20shank\x20button\x20closure,\x20rivets,\x20and\x20a\x20zipper\x20fly,\x20combining\x20style\x20with\x20durability\x20for\x20lasting\x20wear\x20and\x20functionality.",
    "VERSATILE\x20COMFORT:\x20These\x20men\x27s\x20casual\x20pants\x20provide\x20a\x20reliable\x20fit\x20and\x20comfort\x20with\x20attention\x20to\x20consistent\x20sizing\x20and\x20quality.",
  ],
  bullet_points_html:
    "<li><span>ATHLETIC\x20FIT:\x20Our\x20men\x27s\x20athletic\x20pants\x20are\x20designed\x20with\x20a\x20relaxed\x20fit.\x20These\x20casual\x20pants\x20for\x20men\x20offer\x20extra\x20room\x20in\x20the\x20hip\x20and\x20thigh\x20while\x20sitting\x20nicely\x20at\x20the\x20waist,\x20ideal\x20for\x20athletic\x20builds.</span></li><li><span>STRETCH\x20TWILL:\x20Crafted\x20from\x20stretch\x20cotton\x20twill,\x20these\x20men\x27s\x20stretch\x20pants\x20provide\x20comfort\x20and\x20flexibility,\x20making\x20them\x20ideal\x20for\x20everyday\x20wear\x20and\x20movement.</span></li><li><span>EVERYDAY\x20CASUAL:\x20Featuring\x20classic\x205\x20pocket\x20pants,\x20these\x20versatile\x20casual\x20pants\x20blend\x20seamlessly\x20into\x20any\x20wardrobe\x20with\x20a\x20timeless,\x20jeans-inspired\x20look.</span></li><li><span>QUALITY\x20DETAILS:\x20Includes\x20a\x20shank\x20button\x20closure,\x20rivets,\x20and\x20a\x20zipper\x20fly,\x20combining\x20style\x20with\x20durability\x20for\x20lasting\x20wear\x20and\x20functionality.</span></li><li><span>VERSATILE\x20COMFORT:\x20These\x20men\x27s\x20casual\x20pants\x20provide\x20a\x20reliable\x20fit\x20and\x20comfort\x20with\x20attention\x20to\x20consistent\x20sizing\x20and\x20quality.</span></li>",
  desc_template:
    "<h3>[TITLE]</h3>\x0d\x0a\x0d\x0a<br>\x0d\x0a<br>\x0d\x0a\x0d\x0a\x0d\x0a[BULLETS]\x0d\x0a\x0d\x0a\x0d\x0a\x0d\x0a<br>\x0d\x0a\x0d\x0a\x0d\x0a[DESCRIPTION]\x0d\x0a\x0d\x0a<br>\x0d\x0a<br>\x0d\x0a<h4>Shipping\x20and\x20Handling:</h4>\x0d\x0a<p>\x0d\x0aThe\x20item\x20maybe\x20shipped\x20using\x20alternative\x20carriers\x20(eg.\x20Purolator,\x20FedEx,\x20UPS\x20etc).\x20Shipping\x20to\x20most\x20of\x20Canada\x20for\x20free\x20and\x20normally\x20fairly\x20fast\x20(within\x203-7\x20days),\x20however\x20please\x20note\x20that\x20due\x20to\x20current\x20situation,\x20additional\x20delivery\x20time\x20may\x20be\x20required\x20for\x20some\x20times\x20(up\x20to\x203\x20weeks).\x0d\x0a\x20\x20</p>\x0d\x0a<p>\x0d\x0aShipping\x20to\x20YT,\x20NT,\x20NU,\x20NL,\x20A0K,\x20A0P,\x20A0Q,\x20A0R,\x20and\x20X0A-Y9Z\x20(Canada\x20Post\x20Air\x20Stage\x20Locations)\x20may\x20incur\x20shipping\x20charges\x20or\x20delivery\x20restrictions.\x20eBay\x20currently\x20doesn\x27t\x20have\x20a\x20way\x20for\x20to\x20set\x20the\x20shipping\x20and\x20availability\x20via\x20Postal\x20Code\x20so\x20please\x20contact\x20me\x20before\x20ordering\x20or\x20your\x20order\x20can\x20be\x20refunded\x20/\x20canceled.\x0d\x0a\x20</p>\x0d\x0a<p>\x0d\x0aThere\x20are\x20also\x20maybe\x20restrictions\x20based\x20on\x20your\x20province\x20of\x20purchase.\x20For\x20eg.\x20air\x20gun\x20accessories\x20cannot\x20be\x20shipped\x20to\x20Quebec.\x20In\x20these\x20events\x20a\x20full\x20refund\x20will\x20be\x20issued.\x0d\x0a\x20</p>",
  mpn: [],
  tableSpecifics: [],
  itemSpecifics: [
    { label: "size", value: "32w\x20x\x2032l" },
    { label: "colour\x20name", value: "dark\x20grey" },
    { label: "date\x20first\x20available", value: "april\x202\x202025" },
    { label: "manufacturer", value: "amazon\x20essentials" },
    { label: "asin", value: "b0f3c7qp9t" },
    { label: "department", value: "mens" },
    {
      label: "best\x20sellers\x20rank",
      value: "#17\x20in\x20men\x27s\x20casual\x20pants",
    },
    {
      label: "customer\x20reviews",
      value: "4.3\x20\x0a4.3\x20out\x20of\x205\x20stars",
    },
    { label: "fabric\x20type", value: "98%\x20cotton,\x202%\x20spandex" },
    { label: "care\x20instructions", value: "machine\x20wash" },
    { label: "closure\x20type", value: "zipper" },
    { label: "inseam", value: "32\x20inches" },
    { label: "country\x20of\x20origin", value: "vietnam" },
  ],
  descriptionText:
    "Essentials\x20is\x20focused\x20on\x20creating\x20affordable,\x20high-quality,\x20and\x20long-lasting\x20everyday\x20clothing\x20you\x20can\x20rely\x20on.\x20Our\x20line\x20of\x20men\x27s\x20must-haves\x20includes\x20polo\x20shirts,\x20chino\x20pants,\x20classic-fit\x20shorts,\x20casual\x20button-downs,\x20and\x20crew-neck\x20tees.\x20Our\x20consistent\x20sizing\x20takes\x20the\x20guesswork\x20out\x20of\x20shopping,\x20and\x20each\x20piece\x20is\x20put\x20to\x20the\x20test\x20to\x20maintain\x20the\x20highest\x20standards\x20in\x20quality\x20and\x20comfort.",
  descriptionAndFeatures:
    "Size:\x2032w\x20X\x2032l\x0aColour\x20Name:\x20Dark\x20Grey\x0aDepartment:\x20Mens\x0aFabric\x20Type:\x2098%\x20Cotton,\x202%\x20Spandex\x0aCare\x20Instructions:\x20Machine\x20Wash\x0aClosure\x20Type:\x20Zipper\x0aInseam:\x2032\x20Inches\x0a\x0a\x0aATHLETIC\x20FIT:\x20Our\x20men\x27s\x20athletic\x20pants\x20are\x20designed\x20with\x20a\x20relaxed\x20fit.\x20These\x20casual\x20pants\x20for\x20men\x20offer\x20extra\x20room\x20in\x20the\x20hip\x20and\x20thigh\x20while\x20sitting\x20nicely\x20at\x20the\x20waist,\x20ideal\x20for\x20athletic\x20builds.\x0aSTRETCH\x20TWILL:\x20Crafted\x20from\x20stretch\x20cotton\x20twill,\x20these\x20men\x27s\x20stretch\x20pants\x20provide\x20comfort\x20and\x20flexibility,\x20making\x20them\x20ideal\x20for\x20everyday\x20wear\x20and\x20movement.\x0aEVERYDAY\x20CASUAL:\x20Featuring\x20classic\x205\x20pocket\x20pants,\x20these\x20versatile\x20casual\x20pants\x20blend\x20seamlessly\x20into\x20any\x20wardrobe\x20with\x20a\x20timeless,\x20jeans-inspired\x20look.\x0aQUALITY\x20DETAILS:\x20Includes\x20a\x20shank\x20button\x20closure,\x20rivets,\x20and\x20a\x20zipper\x20fly,\x20combining\x20style\x20with\x20durability\x20for\x20lasting\x20wear\x20and\x20functionality.\x0aVERSATILE\x20COMFORT:\x20These\x20men\x27s\x20casual\x20pants\x20provide\x20a\x20reliable\x20fit\x20and\x20comfort\x20with\x20attention\x20to\x20consistent\x20sizing\x20and\x20quality.\x0a\x0aEssentials\x20is\x20focused\x20on\x20creating\x20affordable,\x20high-quality,\x20and\x20long-lasting\x20everyday\x20clothing\x20you\x20can\x20rely\x20on.\x20Our\x20line\x20of\x20men\x27s\x20must-haves\x20includes\x20polo\x20shirts,\x20chino\x20pants,\x20classic-fit\x20shorts,\x20casual\x20button-downs,\x20and\x20crew-neck\x20tees.\x20Our\x20consistent\x20sizing\x20takes\x20the\x20guesswork\x20out\x20of\x20shopping,\x20and\x20each\x20piece\x20is\x20put\x20to\x20the\x20test\x20to\x20maintain\x20the\x20highest\x20standards\x20in\x20quality\x20and\x20comfort.",
  filteredItemSpecifics: [
    { label: "size", value: "32w\x20x\x2032l" },
    { label: "colour\x20name", value: "dark\x20grey" },
    { label: "department", value: "mens" },
    { label: "fabric\x20type", value: "98%\x20cotton,\x202%\x20spandex" },
    { label: "care\x20instructions", value: "machine\x20wash" },
    { label: "closure\x20type", value: "zipper" },
    { label: "inseam", value: "32\x20inches" },
  ],
  main_sd_images: [],
  main_hd_images: [
    "https://m.media-amazon.com/images/I/81Ft9c9JNtL._AC_SL1500_.jpg",
    "https://m.media-amazon.com/images/I/51CGpV40q8L._AC_SL1000_.jpg",
    "https://m.media-amazon.com/images/I/8193hAfww-L._AC_SL1500_.jpg",
    "https://m.media-amazon.com/images/I/A1RYGB7oD-L._AC_SL1500_.jpg",
    "https://m.media-amazon.com/images/I/81S4wsLG8PL._AC_SL1500_.jpg",
    "https://m.media-amazon.com/images/I/81e7DkM+iKL._AC_SL1500_.jpg",
    "https://m.media-amazon.com/images/I/91NGq8U9DlL._AC_SL1500_.jpg",
    "https://m.media-amazon.com/images/I/814LKjNAXPL._AC_SL1500_.jpg",
  ],
  shippingWeight: {},
  extra: {},
  domain_host: "www.amazon.ca",
  categories: [
    "Clothing,\x20Shoes\x20&\x20Accessories",
    "Men",
    "Clothing",
    "Pants",
    "Casual",
  ],
  promoted_listing_ad_rate: "4",
};
function _0x461ac7(_0x28b101) {
  if (_0x28b101) {
    _0x28b101["focus"]();
    const _0x30f144 = { bubbles: !0x0, cancelable: !0x0 };
    ["keydown", "keypress", "keyup", "input", "change", "blur"]["forEach"](
      (_0x43a055) => {
        const _0x3c89ad = new Event(_0x43a055, _0x30f144);
        _0x28b101["dispatchEvent"](_0x3c89ad);
      },
    );
  }
}
function _0xbba28b(_0x5d03e3) {
  return new Promise((_0x454db7) => setTimeout(_0x454db7, _0x5d03e3));
}
function _0x167e39(_0x1ff398, _0x363578 = 0x7530) {
  return new Promise((_0x18cef2, _0x38c084) => {
    let _0x2b4e70 = 0x0;
    const _0x46036d = setInterval(() => {
      var _0x57853c = document["querySelector"](_0x1ff398);
      _0x57853c
        ? (console["log"]("Element\x20\x22" + _0x1ff398 + "\x22\x20found."),
          clearInterval(_0x46036d),
          _0x18cef2(_0x57853c))
        : ((_0x2b4e70 += 0x64),
          _0x2b4e70 >= _0x363578 &&
            (clearInterval(_0x46036d),
            _0x38c084(
              new Error(
                "Element\x20\x22" +
                  _0x1ff398 +
                  "\x22\x20not\x20found\x20within\x20" +
                  _0x363578 +
                  "\x20ms",
              ),
            )));
    }, 0x64);
  });
}
async function _0x587ffd(_0x3efa74) {
  const _0x54cefa = document["querySelector"]("[data-vv-name=\x22title\x22]");
  (_0x3efa74["length"] > 0x50 &&
    (_0x3efa74 = _0x3efa74["substring"](0x0, 0x50)),
    _0x54cefa && ((_0x54cefa["value"] = _0x3efa74), _0x461ac7(_0x54cefa)));
}
async function _0x3ff4af(_0x251094) {
  const _0x1e3d2c = document["querySelector"](
    "[data-vv-name=\x22originalPrice\x22]",
  );
  _0x1e3d2c && ((_0x1e3d2c["value"] = _0x251094), _0x461ac7(_0x1e3d2c));
}
async function _0x44e2bf(_0x1b3b8d) {
  const _0x32bdb5 = document["querySelector"](
    "[data-vv-name=\x22listingPrice\x22]",
  );
  _0x32bdb5 && ((_0x32bdb5["value"] = _0x1b3b8d), _0x461ac7(_0x32bdb5));
}
async function _0x275a98(_0x30c1dc = 0x1388) {
  const _0x240304 = Date["now"](),
    _0x5178df = document["querySelector"](
      "[data-et-name=\x22listingEditorPricingSection\x22]",
    );
  if (!_0x5178df) throw new Error("Pricing\x20section\x20not\x20found.");
  const _0x26f608 = _0x5178df["querySelector"](
    "[aria-haspopup=\x22true\x22][data-test=\x22dropdown\x22]",
  );
  if (!_0x26f608)
    throw new Error("Discounted\x20Shipping\x20dropdown\x20not\x20found.");
  for (; Date["now"]() - _0x240304 < _0x30c1dc; ) {
    const _0x1aa52b = _0x26f608["getAttribute"]("items");
    if (_0x1aa52b && "" !== _0x1aa52b["trim"]()) return;
    await _0xbba28b(0xc8);
  }
  throw new Error(
    "Discounted\x20shipping\x20dropdown\x20did\x20not\x20become\x20enabled\x20within\x20the\x20expected\x20time.",
  );
}
async function _0x24aff7() {
  let _0x517b91 = 0x0,
    _0x8bd255 = !0x1;
  for (; _0x517b91 < 0x3 && !_0x8bd255; )
    try {
      const _0xdfbfc4 = document["querySelector"](
        "[data-et-name=\x22listingEditorPricingSection\x22]",
      );
      if (!_0xdfbfc4) throw new Error("Pricing\x20section\x20not\x20found.");
      const _0x9d547a =
          "[aria-haspopup=\x22true\x22][data-test=\x22dropdown\x22]",
        _0x355eec = _0xdfbfc4["querySelector"](_0x9d547a);
      if (!_0x355eec)
        throw new Error("Discounted\x20Shipping\x20dropdown\x20not\x20found.");
      (_0x355eec["firstChild"]["firstChild"]["click"](),
        console["log"](
          "Attempt\x20" +
            (_0x517b91 + 0x1) +
            ":\x20Clicked\x20on\x20the\x20discounted\x20shipping\x20dropdown.",
        ),
        await _0x167e39(".dropdown__menu--seller-shipping-discount", 0x1388));
      const _0x297e92 = document["querySelectorAll"](
        ".dropdown__menu--seller-shipping-discount\x20li",
      );
      if (0x0 === _0x297e92["length"])
        throw new Error("No\x20shipping\x20options\x20found.");
      let _0x2a2a70 = null;
      for (let _0x3d04a0 of _0x297e92)
        if (
          _0x3d04a0["innerText"]["trim"]()["toLowerCase"]()["includes"]("free")
        ) {
          _0x2a2a70 = _0x3d04a0;
          break;
        }
      if (!_0x2a2a70)
        throw new Error("Free\x20shipping\x20option\x20not\x20found.");
      (_0x2a2a70["firstChild"]["click"](), await _0xbba28b(0x1f4));
      if (
        !_0xdfbfc4["querySelector"](".tc--dg")
          ["innerText"]["trim"]()
          ["toLowerCase"]()
          ["includes"]("free")
      )
        throw new Error(
          "Failed\x20to\x20set\x20discounted\x20shipping\x20to\x20free.",
        );
      (console["log"](
        "Discounted\x20shipping\x20set\x20to\x20free\x20successfully.",
      ),
        (_0x8bd255 = !0x0));
    } catch (_0x8d619f) {
      (console["error"](
        "Attempt\x20" + (_0x517b91 + 0x1) + "\x20failed:",
        _0x8d619f,
      ),
        _0x517b91++);
      if (_0x517b91 < 0x3)
        (console["log"]("Retrying\x20in\x202\x20seconds..."),
          await _0xbba28b(0x7d0));
      else
        console["error"](
          "Maximum\x20attempts\x20reached.\x20Unable\x20to\x20set\x20discounted\x20shipping\x20to\x20free.",
        );
    }
}
async function _0x47cdd4(_0x17d37f) {
  const _0xd0f8bf = document["querySelector"](
    "[data-vv-name=\x22description\x22]",
  );
  (_0x17d37f["length"] > 0x5dc &&
    (_0x17d37f = _0x17d37f["substring"](0x0, 0x5dc)),
    _0xd0f8bf && ((_0xd0f8bf["value"] = _0x17d37f), _0x461ac7(_0xd0f8bf)));
}
async function _0x2beaff(_0x4a32a9) {
  const _0x1d2d46 = document["querySelector"]("input[type=\x22file\x22]");
  if (_0x1d2d46 && _0x4a32a9["length"] > 0x0) {
    const _0xa86e76 = new DataTransfer();
    for (
      let _0x21ab09 = 0x0;
      _0x21ab09 < _0x4a32a9["length"] && _0x21ab09 < 0x10;
      _0x21ab09++
    ) {
      const _0x1ef5cd = _0x35e587(
        (await _0x90886d(_0x4a32a9[_0x21ab09]))["src"],
        "image" + _0x21ab09 + ".jpeg",
      );
      _0xa86e76["items"]["add"](_0x1ef5cd);
    }
    ((_0x1d2d46["files"] = _0xa86e76["files"]),
      _0x1d2d46["dispatchEvent"](new Event("change", { bubbles: !0x0 })));
  }
}
function _0x35e587(_0x37048c, _0x484ee3) {
  const _0x4e3315 = _0x37048c["split"](","),
    _0x285c7e = _0x4e3315[0x0]["match"](/:(.*?);/),
    _0x309b74 = _0x285c7e ? _0x285c7e[0x1] : "image/jpeg",
    _0x570189 = atob(_0x4e3315[0x1]);
  let _0x4dd54a = _0x570189["length"];
  const _0x2bffce = new Uint8Array(_0x4dd54a);
  for (; _0x4dd54a--; )
    _0x2bffce[_0x4dd54a] = _0x570189["charCodeAt"](_0x4dd54a);
  return new File([_0x2bffce], _0x484ee3, { type: _0x309b74 });
}
async function _0x207e49(_0x5b1ad6, _0x78e9c5) {
  const _0x23d761 = document["querySelector"](".dropdown__selector\x20span");
  if (_0x23d761) {
    (_0x23d761["click"](), await _0xbba28b(0xc8));
    const _0x4631aa = document["querySelectorAll"]("[data-et-name]");
    let _0x5bfeb5 = null;
    _0x4631aa["forEach"]((_0x3542c6) => {
      _0x3542c6["innerText"]["trim"]()["toLowerCase"]() ===
        _0x5b1ad6["trim"]()["toLowerCase"]() && (_0x5bfeb5 = _0x3542c6);
    });
    if (_0x5bfeb5) {
      (_0x5bfeb5["click"](), await _0xbba28b(0xc8));
      const _0x27a564 = document["querySelectorAll"]("li.dropdown__link");
      let _0x4b7cfe = null;
      _0x27a564["forEach"]((_0x4ff313) => {
        _0x4ff313["innerText"]["trim"]()["toLowerCase"]() ===
          _0x78e9c5["trim"]()["toLowerCase"]() && (_0x4b7cfe = _0x4ff313);
      });
      if (_0x4b7cfe) (_0x4b7cfe["click"](), await _0xbba28b(0xc8));
      else
        console["error"](
          "Subcategory\x20\x22" + _0x78e9c5 + "\x22\x20not\x20found.",
        );
    } else
      console["error"](
        "Main\x20category\x20\x22" + _0x5b1ad6 + "\x22\x20not\x20found.",
      );
  } else console["error"]("Category\x20dropdown\x20not\x20found.");
}
async function populatePoshmarkWithDummyData() {
  try {
    const _0xbecb34 = {
      name: "Vintage\x20Denim\x20Jacket",
      description:
        "A\x20stylish\x20vintage\x20denim\x20jacket\x20perfect\x20for\x20any\x20occasion.",
      originalPrice: "100",
      listingPrice: "49",
      images: [
        "https://m.media-amazon.com/images/I/71HPPHSFGTL._AC_UL320_.jpg",
        "https://m.media-amazon.com/images/I/91kXaPqVK5L._AC_SY741_.jpg",
        "https://m.media-amazon.com/images/I/81+lQGoTwXL._AC_SY741_.jpg",
      ],
    };
    (await _0x587ffd(_0xbecb34["name"]),
      await _0x3ff4af(_0xbecb34["originalPrice"]),
      await _0x44e2bf(_0xbecb34["listingPrice"]),
      await _0x47cdd4(_0xbecb34["description"]),
      await _0x2beaff(_0xbecb34["images"]),
      await _0x207e49("Electronics", "Other"),
      console["log"]("Form\x20populated\x20successfully."));
  } catch (_0x2e1db9) {
    console["error"](
      "Error\x20in\x20populatePoshmarkWithDummyData:",
      _0x2e1db9,
    );
  }
}
async function _0x58d035(_0x4dc223) {
  var _0x120a69 = await fetch(
    chrome["runtime"]["getURL"](
      "prompts_json/posh_mark_category_selector/get_main_category.json",
    ),
  )["then"]((_0x1daa29) => _0x1daa29["json"]());
  ((_0x120a69["user_input"] = _0x4dc223),
    console["log"]("jsonPrompt", _0x120a69));
  var _0x1262bb = await new Promise((_0x54896c, _0x41cf25) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x120a69,
      },
      function (_0x248da7) {
        chrome["runtime"]["lastError"]
          ? _0x41cf25(chrome["runtime"]["lastError"])
          : _0x54896c(_0x248da7["data"]);
      },
    );
  });
  console["log"]("data", _0x1262bb);
  var _0x1dc8f9 = (_0x1262bb = JSON["parse"](_0x1262bb))["output"];
  return (
    ["Women", "Men", "Kids", "Home", "Pets", "Electronics"]["includes"](
      _0x1dc8f9,
    ) || (_0x1dc8f9 = "Other"),
    _0x1dc8f9
  );
}
async function _0x2653fb(_0x219bbe, _0x1d930a) {
  var _0x5472d6 = await fetch(
      chrome["runtime"]["getURL"](
        "prompts_json/posh_mark_category_selector/get_sub_category.json",
      ),
    )["then"]((_0x5a5b12) => _0x5a5b12["json"]()),
    _0x265d38 = _0x52d66b(_0x1d930a);
  ((_0x5472d6["system_message"] =
    "You\x20are\x20a\x20product\x20categorization\x20system.\x20Given\x20a\x20product\x20title\x20and\x20a\x20main\x20category,\x20determine\x20the\x20subcategory\x20from\x20the\x20provided\x20list\x20that\x20best\x20fits\x20the\x20item.\x0a\x0aMain\x20Category:\x20" +
    _0x1d930a +
    ".\x0aSubcategories:\x20" +
    _0x265d38["join"](",\x20") +
    "."),
    (_0x5472d6["function_schema"]["parameters"]["properties"]["output"][
      "enum"
    ] = _0x265d38),
    (_0x5472d6["user_input"] = _0x219bbe),
    (_0x5472d6["example_user_input"] = "Sample\x20Product\x20Title"),
    (_0x5472d6["example_assistant_output_arguments"] = {
      output: "Sample\x20Subcategory",
    }),
    console["log"]("jsonPrompt", _0x5472d6));
  var _0x147cfb = await new Promise((_0x461f30, _0x177d12) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x5472d6,
      },
      function (_0xa18308) {
        chrome["runtime"]["lastError"]
          ? _0x177d12(chrome["runtime"]["lastError"])
          : _0x461f30(_0xa18308["data"]);
      },
    );
  });
  console["log"]("data", _0x147cfb);
  var _0x46e3d5 = (_0x147cfb = JSON["parse"](_0x147cfb))["output"];
  return (_0x265d38["includes"](_0x46e3d5) || (_0x46e3d5 = "Other"), _0x46e3d5);
}
var _0x1e6222 = {
  Women: [
    "Accessories",
    "Bags",
    "Dresses",
    "Intimates\x20&\x20Sleepwear",
    "Jackets\x20&\x20Coats",
    "Jeans",
    "Jewelry",
    "Makeup",
    "Pants\x20&\x20Jumpsuits",
    "Shoes",
    "Shorts",
    "Skirts",
    "Sweaters",
    "Swim",
    "Tops",
    "Skincare",
    "Hair",
    "Bath\x20&\x20Body",
    "Global\x20&\x20Traditional\x20Wear",
    "Other",
  ],
  Men: [
    "Accessories",
    "Bags",
    "Jackets\x20&\x20Coats",
    "Jeans",
    "Pants",
    "Shirts",
    "Shoes",
    "Shorts",
    "Suits\x20&\x20Blazers",
    "Sweaters",
    "Swim",
    "Underwear\x20&\x20Socks",
    "Grooming",
    "Global\x20&\x20Traditional\x20Wear",
    "Other",
  ],
  Kids: [
    "Accessories",
    "Bottoms",
    "Dresses",
    "Jackets\x20&\x20Coats",
    "Matching\x20Sets",
    "One\x20Pieces",
    "Pajamas",
    "Shirts\x20&\x20Tops",
    "Shoes",
    "Swim",
    "Costumes",
    "Bath,\x20Skin\x20&\x20Hair",
    "Toys",
    "Other",
  ],
  Home: [
    "Accents",
    "Art",
    "Bath",
    "Bedding",
    "Design",
    "Dining",
    "Games",
    "Holiday",
    "Kitchen",
    "Office",
    "Party\x20Supplies",
    "Storage\x20&\x20Organization",
    "Wall\x20Decor",
    "Other",
  ],
  Pets: ["Dog", "Cat", "Bird", "Fish", "Reptile", "Small\x20Pets", "Other"],
  Electronics: [
    "Cameras,\x20Photo\x20&\x20Video",
    "Computers,\x20Laptops\x20&\x20Parts",
    "Cell\x20Phones\x20&\x20Accessories",
    "Car\x20Audio,\x20Video\x20&\x20GPS",
    "Wearables",
    "Tablets\x20&\x20Accessories",
    "Video\x20Games\x20&\x20Consoles",
    "VR,\x20AR\x20&\x20Accessories",
    "Media",
    "Networking",
    "Headphones",
    "Portable\x20Audio\x20&\x20Video",
    "Other",
  ],
};
function _0x52d66b(_0x2ab534) {
  return _0x1e6222[_0x2ab534] || ["Other"];
}
async function _0x4adfb6(_0x2b8eb4) {
  let _0x138160 = 0x0,
    _0x55f4ed,
    _0x118d3a;
  for (; _0x138160 < 0x3; )
    try {
      return (
        !_0x55f4ed &&
          ((_0x55f4ed = await _0x58d035(_0x2b8eb4)),
          console["log"]("Main\x20Category:", _0x55f4ed)),
        (_0x118d3a = await _0x2653fb(_0x2b8eb4, _0x55f4ed)),
        console["log"]("Subcategory:", _0x118d3a),
        { mainCategory: _0x55f4ed, subcategory: _0x118d3a }
      );
    } catch (_0x577708) {
      (_0x138160++,
        console["error"]("Attempt\x20" + _0x138160 + "\x20failed:", _0x577708));
      if (_0x138160 >= 0x3) {
        console["error"](
          "Error\x20in\x20categorizing\x20product\x20after\x203\x20attempts:",
          _0x577708,
        );
        throw _0x577708;
      }
      _0x55f4ed
        ? console["log"]("Retrying\x20getSubcategory...")
        : console["log"]("Retrying\x20getMainCategory...");
    }
}
function mapToPoshmarkMainCategoryFromTitle(_0x2903be) {
  var _0x3ee677 = ["Women", "Men", "Kids", "Home", "Pets", "Electronics"],
    _0x449174 = _0x3ee677["map"]((_0x3cfc18) => _0x3cfc18["toLowerCase"]()),
    _0x9a9b30 = _0x2903be["split"](/\W+/)
      ["filter"](Boolean)
      ["map"]((_0x4bb223) => _0x4bb223["toLowerCase"]());
  console["log"]("Title\x20words:", _0x9a9b30);
  for (let _0x972da1 = 0x0; _0x972da1 < _0x9a9b30["length"]; _0x972da1++) {
    var _0x137205 = _0x9a9b30[_0x972da1],
      _0x1a213f = _0x137205["endsWith"]("s")
        ? _0x137205["slice"](0x0, -0x1)
        : _0x137205;
    for (let _0x4dcec6 = 0x0; _0x4dcec6 < _0x449174["length"]; _0x4dcec6++) {
      var _0x4b273d = _0x449174[_0x4dcec6];
      if (_0x137205 === _0x4b273d || _0x1a213f === _0x4b273d)
        return (
          console["log"](
            "Match\x20found:\x20\x22" +
              _0x9a9b30[_0x972da1] +
              "\x22\x20matches\x20Poshmark\x20main\x20category\x20\x22" +
              _0x3ee677[_0x4dcec6] +
              "\x22",
          ),
          _0x3ee677[_0x4dcec6]
        );
    }
  }
  return (
    console["log"](
      "No\x20match\x20found\x20for\x20main\x20category\x20in\x20title",
    ),
    null
  );
}
function mapToPoshmarkMainCategory(_0x501298) {
  var _0x106337 = ["Women", "Men", "Kids", "Home", "Pets", "Electronics"];
  for (let _0x32687f = 0x0; _0x32687f < _0x106337["length"]; _0x32687f++) {
    const _0x65592d = _0x106337[_0x32687f]["toLowerCase"]();
    console["log"](
      "Checking\x20Poshmark\x20main\x20category:\x20\x22" +
        _0x106337[_0x32687f] +
        "\x22",
    );
    for (let _0x20056d = 0x0; _0x20056d < _0x501298["length"]; _0x20056d++) {
      const _0x4c6609 = _0x501298[_0x20056d]["toLowerCase"]();
      console["log"](
        "\x20\x20Against\x20Amazon\x20category:\x20\x22" +
          _0x501298[_0x20056d] +
          "\x22",
      );
      const _0x37ad38 = _0x4c6609["split"](/\W+/)["filter"](Boolean),
        _0x575001 = _0x65592d["split"](/\W+/)["filter"](Boolean);
      (console["log"](
        "\x20\x20\x20\x20Amazon\x20words:\x20[" +
          _0x37ad38["join"](",\x20") +
          "]",
      ),
        console["log"](
          "\x20\x20\x20\x20Poshmark\x20words:\x20[" +
            _0x575001["join"](",\x20") +
            "]",
        ));
      for (let _0x190141 = 0x0; _0x190141 < _0x575001["length"]; _0x190141++) {
        const _0x3441df = _0x575001[_0x190141];
        for (
          let _0x4990e6 = 0x0;
          _0x4990e6 < _0x37ad38["length"];
          _0x4990e6++
        ) {
          const _0x1dbbaa = _0x37ad38[_0x4990e6];
          if (_0x1dbbaa === _0x3441df)
            return (
              console["log"](
                "\x20\x20\x20\x20\x20\x20Match\x20found:\x20\x22" +
                  _0x1dbbaa +
                  "\x22\x20matches\x20\x22" +
                  _0x3441df +
                  "\x22",
              ),
              _0x106337[_0x32687f]
            );
        }
      }
    }
  }
  return (
    console["log"]("No\x20match\x20found\x20for\x20main\x20category"),
    null
  );
}
function mapToPoshmarkSubCategory(_0x355def, _0x4a06bb) {
  for (
    let _0x2fc25e = _0x355def["length"] - 0x1;
    _0x2fc25e >= 0x0;
    _0x2fc25e--
  ) {
    const _0xaf304f = _0x355def[_0x2fc25e]["toLowerCase"]();
    console["log"](
      "Checking\x20Amazon\x20category:\x20\x22" + _0x355def[_0x2fc25e] + "\x22",
    );
    const _0x243cd0 = _0xaf304f["split"](/\W+/)["filter"](Boolean);
    console["log"](
      "\x20\x20Amazon\x20words:\x20[" + _0x243cd0["join"](",\x20") + "]",
    );
    for (let _0x3572e0 = 0x0; _0x3572e0 < _0x4a06bb["length"]; _0x3572e0++) {
      const _0x32ef26 = _0x4a06bb[_0x3572e0];
      console["log"](
        "\x20\x20\x20\x20Checking\x20Poshmark\x20subcategory:\x20\x22" +
          _0x32ef26 +
          "\x22",
      );
      const _0xc19f78 = _0x32ef26["toLowerCase"]()
        ["split"](/\W+/)
        ["filter"](Boolean);
      console["log"](
        "\x20\x20\x20\x20\x20\x20Poshmark\x20words:\x20[" +
          _0xc19f78["join"](",\x20") +
          "]",
      );
      for (let _0x23d594 = 0x0; _0x23d594 < _0xc19f78["length"]; _0x23d594++) {
        const _0x174255 = _0xc19f78[_0x23d594];
        for (
          let _0x4498d1 = 0x0;
          _0x4498d1 < _0x243cd0["length"];
          _0x4498d1++
        ) {
          const _0x53bc4f = _0x243cd0[_0x4498d1];
          if (_0x53bc4f === _0x174255)
            return (
              console["log"](
                "\x20\x20\x20\x20\x20\x20\x20\x20Match\x20found:\x20\x22" +
                  _0x53bc4f +
                  "\x22\x20matches\x20\x22" +
                  _0x174255 +
                  "\x22",
              ),
              _0x4a06bb[_0x3572e0]
            );
        }
      }
    }
  }
  return (
    console["log"](
      "No\x20match\x20found\x20for\x20subcategory,\x20returning\x20\x22Other\x22",
    ),
    "Other"
  );
}
async function _0x53b9d1(_0x3235e3) {
  var _0x66219 = mapToPoshmarkMainCategory(_0x3235e3);
  if (!_0x66219) return null;
  var _0x192729 = _0x52d66b(_0x66219);
  return {
    mainCategory: _0x66219,
    subcategory: mapToPoshmarkSubCategory(product["categories"], _0x192729),
  };
}
async function _0x26d961(_0x232de6) {
  document["title"] = "Insert\x20Draft\x20Details";
  var _0x56ce1e, _0x28e5e7;
  if (!_0x56ce1e) {
    console["log"]("Attempting\x20to\x20map\x20to\x20poshmark\x20subcategory");
    try {
      var { mainCategory: _0x56ce1e, subcategory: _0x28e5e7 } = await _0x53b9d1(
        _0x232de6["categories"],
      );
    } catch (_0x584595) {
      console["log"]("Error", _0x584595);
    }
  }
  if (!_0x56ce1e && _0x232de6["categories"]["length"] > 0x0) {
    console["log"](
      "Attempting\x20to\x20map\x20to\x20poshmark\x20main\x20category\x20from\x20title",
    );
    if (
      (_0x56ce1e = mapToPoshmarkMainCategoryFromTitle(
        _0x232de6["custom_title"],
      ))
    ) {
      var _0x27ebbd = _0x52d66b(_0x56ce1e);
      _0x28e5e7 = mapToPoshmarkSubCategory(_0x232de6["categories"], _0x27ebbd);
    }
  }
  !_0x56ce1e &&
    ((_0x56ce1e = mapToPoshmarkMainCategoryFromTitle(
      _0x232de6["custom_title"],
    )),
    (_0x28e5e7 = "Other"));
  !_0x56ce1e &&
    (console["log"]("No\x20main\x20category\x20found"),
    (_0x56ce1e = "Home"),
    (_0x28e5e7 = "Other"));
  (await _0x207e49(_0x56ce1e, _0x28e5e7),
    (document["title"] = "Category\x20Set"),
    await _0x587ffd(_0x232de6["custom_title"]),
    (document["title"] = "Title\x20Set"),
    await _0x47cdd4(_0x232de6["descriptionAndFeatures"]),
    (document["title"] = "Description\x20Set"));
  var _0xfaa1f2,
    _0x3f760d = _0x232de6["main_hd_images"],
    _0x22a8f9 = _0x232de6["main_sd_images"];
  (_0x3f760d,
    (_0xfaa1f2 =
      _0x3f760d["length"] < 0x2 && _0x22a8f9["length"] > 0x2
        ? _0x22a8f9
        : _0x3f760d),
    await _0x2beaff(_0xfaa1f2),
    (document["title"] = "Images\x20Set"),
    await _0x549366(btoa(_0x232de6["sku"])),
    (document["title"] = "SKU\x20Set"));
  var _0x38b800 = Number(_0x232de6["custom_price"]);
  ((_0x38b800 = Math["round"](_0x38b800)),
    await _0x44e2bf(_0x38b800),
    (document["title"] = "Listing\x20Price\x20Set"),
    await _0x3ff4af(1.5 * _0x38b800),
    (document["title"] = "Original\x20Price\x20Set"),
    await _0xbf7392(0x1388),
    (document["title"] = "Cover\x20Shot\x20Selected"));
  var _0x430fcd;
  try {
    for (
      let _0x19975c = 0x0;
      _0x19975c < _0x232de6["itemSpecifics"]["length"];
      _0x19975c++
    ) {
      const _0x5c4a1a = _0x232de6["itemSpecifics"][_0x19975c];
      if ("size" == _0x5c4a1a["label"]["toLowerCase"]()) {
        _0x430fcd = _0x5c4a1a["value"];
        break;
      }
    }
  } catch (_0x9d4a93) {}
  (console["log"]("size", _0x430fcd), await _0x3805da(_0x430fcd));
  var _0x2fcaea = _0x3cd1fc(_0x232de6["itemSpecifics"]);
  (console["log"]("Detected\x20color:", _0x2fcaea),
    _0x2fcaea && (await _0x785c77(_0x2fcaea)),
    _0x36218a(_0x232de6));
  var { autoSubmitEnabled: _0xd7de9a } =
    await chrome["storage"]["local"]["get"]("autoSubmitEnabled");
  _0xd7de9a && (await _0x23983c(), (document["title"] = "Item\x20Listed"));
}
function _0x3cd1fc(_0x3844d7) {
  if (!Array["isArray"](_0x3844d7)) return null;
  const _0x3069e7 = _0x3844d7["find"](({ label: _0x455369 }) => {
    const _0x3237dd = _0x455369["trim"]()["toLowerCase"]();
    return _0x3237dd["includes"]("color") || _0x3237dd["includes"]("colour");
  });
  return _0x3069e7 ? _0x3069e7["value"]["trim"]() : null;
}
async function _0xbf7392(_0x2f97c0 = 0x1388) {
  const _0x3cebcb = Date["now"]();
  for (; Date["now"]() - _0x3cebcb < _0x2f97c0; ) {
    var _0xed1d1 = document["querySelector"](".zoomout");
    _0xed1d1 &&
      (_0xed1d1["click"](),
      await _0xbba28b(0x64),
      _0xed1d1["click"](),
      await _0xbba28b(0x64),
      _0xed1d1["click"](),
      await _0xbba28b(0x64));
    const _0x5b571c = document["querySelector"](
      "[data-et-on-name=\x22select_first_photo\x22]",
    );
    if (_0x5b571c) {
      _0x5b571c["click"]();
      return;
    }
    await _0xbba28b(0x64);
  }
  console["error"](
    "Cover\x20shot\x20button\x20not\x20found\x20within\x20the\x20timeout\x20period.",
  );
}
async function _0x549366(_0x454cef) {
  var _0x4c15c7 = document["querySelector"]("[data-vv-name=\x22sku\x22]");
  _0x4c15c7 && ((_0x4c15c7["value"] = _0x454cef), _0x461ac7(_0x4c15c7));
}
function _0x53f0dd() {
  return document["querySelector"]("[data-et-name=\x22next\x22]");
}
async function _0x23983c() {
  var _0x5f05ea = _0x53f0dd();
  _0x5f05ea && _0x5f05ea["click"]();
  var _0x11c858 = await _0x167e39("[data-et-name=\x22list\x22]", 0x7530);
  _0x11c858 && _0x11c858["click"]();
}
function _0x2b026f() {
  const _0x1c5137 = document["querySelector"](
    "[data-test=\x22size\x22]\x20span",
  );
  if (!_0x1c5137)
    return (console["warn"]("Size\x20selector\x20not\x20found."), !0x1);
  return "select\x20size" !== _0x1c5137["innerText"]["trim"]()["toLowerCase"]();
}
async function _0x3805da(_0x3220c2 = null) {
  if (_0x2b026f()) console["log"]("Size\x20is\x20already\x20selected.");
  else {
    var _0x21f0d3 = document["querySelectorAll"](
        ".listing-editor__section__title",
      ),
      _0x1205cd = null;
    for (let _0x10b3e5 = 0x0; _0x10b3e5 < _0x21f0d3["length"]; _0x10b3e5++) {
      var _0x41bff3 = _0x21f0d3[_0x10b3e5];
      if (
        _0x41bff3 &&
        _0x41bff3["innerText"]["toLowerCase"]()["includes"]("size")
      ) {
        _0x1205cd = _0x41bff3;
        break;
      }
    }
    (console["log"]("sizeElement", _0x1205cd),
      console["log"]("size", _0x3220c2));
    if (_0x1205cd) {
      var _0x31da5d = _0x1205cd["parentElement"];
      for (
        ;
        _0x31da5d &&
        !_0x31da5d["classList"]["contains"]("listing-editor__subsection");

      )
        _0x31da5d = _0x31da5d["parentElement"];
      (_0x31da5d["querySelector"](".dropdown__selector--select-tag")["click"](),
        await _0xbba28b(0x1f4));
      var _0x1f74cf = _0x31da5d["querySelectorAll"](
        ".dropdown__menu\x20.p--3\x20.d--fl\x20li",
      );
      if (_0x3220c2) {
        var _0x4dc5d1 = _0x51ff46(_0x3220c2),
          _0x26c8f5 = _0x374a54(_0x3220c2);
        (console["log"]("sizeNumbers", _0x4dc5d1),
          console["log"]("sizeWords", _0x26c8f5));
        var _0x45f3dc = [];
        for (
          let _0x2568ff = 0x0;
          _0x2568ff < _0x1f74cf["length"];
          _0x2568ff++
        ) {
          var _0x29f83b = _0x1f74cf[_0x2568ff],
            _0x911366 = _0x29f83b["innerText"],
            _0x3c7ffc = _0x51ff46(_0x911366),
            _0x210bae = _0x374a54(_0x911366);
          _0x45f3dc["push"]({
            element: _0x29f83b,
            numbers: _0x3c7ffc,
            words: _0x210bae,
          });
        }
        var _0x4dacde = null,
          _0x2e38c3 = 0x1 / 0x0;
        if (_0x4dc5d1["length"] > 0x0) {
          for (
            let _0x248e3c = 0x0;
            _0x248e3c < _0x45f3dc["length"];
            _0x248e3c++
          )
            if ((_0x2cfa21 = _0x45f3dc[_0x248e3c])["numbers"]["length"] > 0x0)
              for (
                let _0x50c83a = 0x0;
                _0x50c83a < _0x2cfa21["numbers"]["length"];
                _0x50c83a++
              ) {
                var _0x1b8cf8 = _0x2cfa21["numbers"][_0x50c83a];
                for (
                  let _0x50be99 = 0x0;
                  _0x50be99 < _0x4dc5d1["length"];
                  _0x50be99++
                ) {
                  var _0x3a6aca = _0x4dc5d1[_0x50be99],
                    _0x200958 = Math["abs"](_0x1b8cf8 - _0x3a6aca);
                  _0x200958 < _0x2e38c3 &&
                    ((_0x2e38c3 = _0x200958),
                    (_0x4dacde = _0x2cfa21["element"]));
                }
              }
          if (_0x4dacde) {
            (console["log"]("Best\x20numeric\x20match\x20found"),
              _0x4dacde["querySelector"]("button")["click"]());
            return;
          }
        }
        if (_0x26c8f5["length"] > 0x0) {
          var _0x4e6c14 = 0x0;
          for (
            let _0x1d251a = 0x0;
            _0x1d251a < _0x45f3dc["length"];
            _0x1d251a++
          ) {
            var _0x2cfa21 = _0x45f3dc[_0x1d251a],
              _0x71d852 = 0x0;
            for (
              let _0x1c3325 = 0x0;
              _0x1c3325 < _0x2cfa21["words"]["length"];
              _0x1c3325++
            ) {
              var _0x31d709 = _0x2cfa21["words"][_0x1c3325];
              _0x26c8f5["includes"](_0x31d709) && _0x71d852++;
            }
            _0x71d852 > _0x4e6c14 &&
              ((_0x4e6c14 = _0x71d852), (_0x4dacde = _0x2cfa21["element"]));
          }
          if (_0x4dacde) {
            (console["log"]("Best\x20word\x20match\x20found"),
              _0x4dacde["querySelector"]("button")["click"]());
            return;
          }
        }
        (console["log"](
          "Size\x20not\x20found,\x20selecting\x20first\x20option",
        ),
          _0x1f74cf[0x0]["querySelector"]("button")["click"]());
      } else
        (console["log"]("Size\x20is\x20empty,\x20selecting\x20first\x20option"),
          _0x1f74cf[0x0]["querySelector"]("button")["click"]());
    }
  }
  function _0x51ff46(_0x2c14b8) {
    var _0x1df9f6 = _0x2c14b8["match"](/\d+(\.\d+)?/g);
    return _0x1df9f6 ? _0x1df9f6["map"](Number) : [];
  }
  function _0x374a54(_0x21f342) {
    var _0x23a109 = _0x21f342["match"](/\b[A-Za-z]+\b/g);
    return _0x23a109
      ? _0x23a109["map"]((_0x64a231) => _0x64a231["toLowerCase"]())
      : [];
  }
}
async function _0x785c77(_0x42e6a4 = null, _0x48fa4c = 0x1388) {
  if (!_0x42e6a4) return;
  _0x42e6a4 &&
    (_0x42e6a4 = _0x42e6a4["trim"]()
      ["toLowerCase"]()
      ["replace"](/grey/g, "gray"));
  const _0x12d2b2 = Date["now"]();
  let _0xc3246c;
  for (; Date["now"]() - _0x12d2b2 < _0x48fa4c; ) {
    document["querySelectorAll"](".listing-editor__section__title")["forEach"](
      (_0x155df9) => {
        "color" === _0x155df9["innerText"]["trim"]()["toLowerCase"]() &&
          (_0xc3246c = _0x155df9["closest"](".listing-editor__section"));
      },
    );
    if (_0xc3246c) break;
    await _0xbba28b(0x64);
  }
  if (!_0xc3246c) {
    console["warn"]("Color\x20section\x20not\x20found—skipping.");
    return;
  }
  const _0x39691e = _0xc3246c["querySelector"]("[data-test=\x22dropdown\x22]");
  if (!_0x39691e) {
    console["error"]("Color\x20dropdown\x20toggle\x20not\x20found.");
    return;
  }
  (_0x39691e["firstChild"]["firstChild"]["click"](), await _0xbba28b(0xc8));
  if (!_0xc3246c["querySelector"](".dropdown__menu--expanded\x20ul")) {
    console["error"]("Color\x20dropdown\x20menu\x20did\x20not\x20expand.");
    return;
  }
  const _0x456e5e = Array["from"](
    _0xc3246c["querySelectorAll"](".listing-editor__tile--color"),
  );
  if (!_0x456e5e["length"]) {
    console["warn"]("No\x20color\x20options\x20found.");
    return;
  }
  if (_0x42e6a4) {
    const _0x2e728e = _0x42e6a4;
    let _0x3b4c7c = _0x456e5e["find"](
      (_0x445309) =>
        _0x445309["querySelector"]("span")
          ["innerText"]["trim"]()
          ["toLowerCase"]() === _0x2e728e,
    );
    _0x3b4c7c ||
      (_0x3b4c7c = _0x456e5e["find"]((_0x4e9c90) => {
        const _0xa780be = _0x4e9c90["querySelector"]("span")
          ["innerText"]["trim"]()
          ["toLowerCase"]();
        return (
          _0xa780be["includes"](_0x2e728e) || _0x2e728e["includes"](_0xa780be)
        );
      }));
    if (!_0x3b4c7c) {
      const _0x1c0baf = _0x2e728e["split"](/\s+/);
      _0x3b4c7c = _0x456e5e["find"]((_0x77343) => {
        const _0x31ff5c = _0x77343["querySelector"]("span")
          ["innerText"]["trim"]()
          ["toLowerCase"]();
        return _0x1c0baf["some"]((_0x586d51) =>
          _0x31ff5c["includes"](_0x586d51),
        );
      });
    }
    (!_0x3b4c7c &&
      (console["warn"](
        "Color\x20\x22" +
          _0x42e6a4 +
          "\x22\x20not\x20found—defaulting\x20to\x20\x22" +
          _0x456e5e[0x0]["querySelector"]("span")["innerText"]["trim"]() +
          "\x22.",
      ),
      (_0x3b4c7c = _0x456e5e[0x0])),
      _0x3b4c7c["click"]());
  } else _0x456e5e[0x0]["click"]();
  await _0xbba28b(0xc8);
  const _0x27f72b = _0xc3246c["querySelector"](
    "button[data-et-name=\x22apply\x22]",
  );
  _0x27f72b
    ? _0x27f72b["click"]()
    : console["error"]("Color\x20\x22Done\x22\x20button\x20not\x20found.");
}
function _0x36218a(_0x2582ac) {
  var _0x345703 = _0x53f0dd();
  (console["log"]("submitButton\x20initiated", _0x345703),
    _0x345703["addEventListener"]("click", async function () {
      (_0x279217(_0x2582ac["sku"]),
        chrome["runtime"]["sendMessage"]({
          type: "listing_result",
          status: "waiting_for_page_update",
        }));
    }));
}
function findSubsectionByTitle(_0x3d0c32) {
  const _0xa94dd1 = [
    ...document["querySelectorAll"](".listing-editor__section__title"),
  ]["find"]((_0x305f1c) =>
    _0x305f1c["innerText"]
      ["trim"]()
      ["toLowerCase"]()
      ["includes"](_0x3d0c32["toLowerCase"]()),
  );
  if (!_0xa94dd1)
    throw new Error("\x22" + _0x3d0c32 + "\x22\x20section\x20not\x20found");
  let _0x4ec088 = _0xa94dd1["parentElement"];
  for (
    ;
    _0x4ec088 &&
    !_0x4ec088["classList"]["contains"]("listing-editor__subsection");

  )
    _0x4ec088 = _0x4ec088["parentElement"];
  if (!_0x4ec088)
    throw new Error(
      "\x22" + _0x3d0c32 + "\x22\x20subsection\x20container\x20not\x20found",
    );
  return _0x4ec088;
}
async function _0x5cf71e() {
  const _0x456232 = findSubsectionByTitle("size"),
    _0x2d3485 = _0x456232["querySelector"](".dropdown__selector--select-tag");
  if (!_0x2d3485) throw new Error("Size\x20dropdown\x20toggle\x20not\x20found");
  (_0x2d3485["click"](), await _0xbba28b(0x12c));
  const _0x341ffa = [];
  for (const _0x57ee5e of _0x456232["querySelectorAll"](
    "[data-test=\x22horizontal-list\x22]\x20li",
  )) {
    const _0x5dcba0 = _0x57ee5e["innerText"]["trim"]();
    if (!_0x5dcba0 || /custom/i["test"](_0x5dcba0)) continue;
    (_0x57ee5e["querySelector"]("a")?.["click"](), await _0xbba28b(0x12c));
    const _0x2e7660 = [
      ..._0x456232["querySelectorAll"](
        ".dropdown__menu\x20.p--3\x20.d--fl\x20li",
      ),
    ]
      ["map"]((_0x2a2486) => _0x2a2486["innerText"]["trim"]())
      ["filter"](Boolean);
    _0x341ffa["push"]({ group: _0x5dcba0, sizes: _0x2e7660 });
  }
  return (_0x2d3485["click"](), await _0xbba28b(0x64), _0x341ffa);
}
function _0x38bb19(_0x147b48) {
  return Array["from"](
    new Set(_0x147b48["flatMap"]((_0x5bfc0e) => _0x5bfc0e["sizes"])),
  );
}
async function _0x2418ac(_0x22de36, _0x2231a6) {
  const _0xb53a1a = {
      name: "select_closest_size",
      description: "Pick\x20the\x20closest\x20matching\x20size",
      parameters: {
        type: "object",
        properties: {
          selected_size: { type: "string", enum: [..._0x2231a6, "NO_MATCH"] },
          reason: { type: "string" },
        },
        required: ["selected_size"],
      },
    },
    _0x2be353 = {
      system_message:
        "You\x20are\x20a\x20size\x20classifier.\x20Available\x20options:\x20" +
        _0x2231a6["join"](",\x20") +
        ".\x20Reply\x20with\x20\x22NO_MATCH\x22\x20if\x20none\x20apply.",
      user_message: "Based\x20on:\x0a\x0a" + _0x22de36,
      functions: [_0xb53a1a],
      function_call: { name: _0xb53a1a["name"] },
      model: "gpt-4.1-nano",
    },
    _0x4b58e6 = await _0x1fd9a7(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/json_schema",
      _0x2be353,
    );
  if (!_0x4b58e6["success"])
    throw new Error(_0x4b58e6["error"] || "API\x20error");
  return _0x4b58e6["arguments"]["selected_size"];
}
function findGroupForSize(_0x5c1a92, _0x3877b4) {
  return (
    _0x3877b4["find"]((_0xfc1d9c) =>
      _0xfc1d9c["sizes"]["includes"](_0x5c1a92),
    )?.["group"] || null
  );
}
async function _0x2f0fd5(_0x3c53ae, _0x4ca113) {
  if (_0x2b026f()) {
    console["log"]("Size\x20is\x20already\x20selected.");
    return;
  }
  const _0x1df0f0 = findSubsectionByTitle("size"),
    _0x39912b = [
      ..._0x1df0f0["querySelectorAll"](
        "[data-test=\x22horizontal-list\x22]\x20li\x20a",
      ),
    ]["find"](
      (_0x22adac) =>
        _0x22adac["innerText"]["trim"]()["toLowerCase"]() ===
        _0x4ca113["toLowerCase"](),
    );
  if (_0x39912b) (_0x39912b["click"](), await _0xbba28b(0xc8));
  else
    console["warn"](
      "Group\x20\x22" + _0x4ca113 + "\x22\x20not\x20found—using\x20default.",
    );
  const _0x298120 = _0x1df0f0["querySelector"](
    ".dropdown__selector--select-tag",
  );
  if (!_0x298120) throw new Error("Dropdown\x20toggle\x20missing");
  (_0x298120["click"](), await _0xbba28b(0xc8));
  const _0x4f3a53 = [
      ..._0x1df0f0["querySelectorAll"](
        ".dropdown__menu\x20.p--3\x20.d--fl\x20li",
      ),
    ],
    _0x4f853e = _0x4f3a53["find"](
      (_0x212a9b) =>
        _0x212a9b["innerText"]["trim"]()["toLowerCase"]() ===
        _0x3c53ae["toLowerCase"](),
    );
  ((_0x4f853e || _0x4f3a53[0x0])?.["querySelector"]("button")?.["click"](),
    await _0xbba28b(0xc8));
}
function _0x558bdd(_0x55c0e7) {
  return {
    name: "determine_poshmark_category",
    description:
      "Choose\x20the\x20best\x20Poshmark\x20main\x20and\x20sub-category\x20for\x20a\x20listing",
    parameters: {
      type: "object",
      properties: {
        main_category: {
          type: "string",
          enum: Object["keys"](_0x55c0e7),
          description: "The\x20top-level\x20Poshmark\x20category",
        },
        sub_category: {
          type: "string",
          enum: [...new Set(Object["values"](_0x55c0e7)["flat"]())],
          description: "The\x20second-level\x20Poshmark\x20category",
        },
      },
      required: ["main_category", "sub_category"],
    },
  };
}
async function _0x3c541a(_0x2fe198) {
  const _0x359e80 = _0x558bdd(_0x1e6222),
    _0xf06c40 = {
      system_message:
        ("\x0aYou\x20are\x20a\x20Poshmark\x20listing\x20categorizer.\x20\x20\x0aAvailable\x20top-level\x20categories\x20and\x20their\x20sub-categories:\x0a" +
          Object["entries"](_0x1e6222)
            ["map"](
              ([_0x26a1b3, _0x548159]) =>
                "-\x20" + _0x26a1b3 + ":\x20" + _0x548159["join"](",\x20"),
            )
            ["join"]("\x0a") +
          "\x0a\x0aBased\x20on\x20the\x20listing\x20details,\x20choose\x20the\x20single\x20best\x20main_category\x20and\x20sub_category.\x0aIf\x20nothing\x20clearly\x20fits,\x20pick\x20\x22Other\x22\x20for\x20whichever\x20level\x20makes\x20sense.\x0a\x20\x20")[
          "trim"
        ](),
      user_message:
        "Please\x20categorize\x20this\x20listing:\x0a\x0a" + _0x2fe198,
      functions: [_0x359e80],
      function_call: { name: _0x359e80["name"] },
      model: "gpt-4.1-nano",
    },
    _0x505e05 = await _0x1fd9a7(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/json_schema",
      _0xf06c40,
    );
  if (!_0x505e05["success"])
    throw new Error(_0x505e05["error"] || "Category\x20API\x20failure");
  return {
    main: _0x505e05["arguments"]["main_category"],
    sub: _0x505e05["arguments"]["sub_category"],
  };
}
async function _0x4b3221() {
  var _0x251561 = [];
  return (
    document["querySelectorAll"](
      "[data-et-on-name=\x22sub_category_selection\x22]",
    )["forEach"]((_0x5baeeb) => {
      var _0x348fec = _0x5baeeb["getAttribute"]("data-et-prop-content");
      _0x348fec && _0x251561["push"](_0x348fec);
    }),
    console["log"]("subCategories:", _0x251561),
    _0x251561
  );
}
async function _0xb39d87(_0x5ad57c) {
  const _0x7322a = (_0x247183) =>
    new Promise((_0x19ed49) => setTimeout(_0x19ed49, _0x247183));
  if (!_0x5ad57c) {
    console["warn"]("No\x20subCategory\x20provided—skipping.");
    return;
  }
  const _0x35e5ea = document["querySelectorAll"](
    "[data-et-on-name=\x22sub_category_selection\x22]",
  );
  if (!_0x35e5ea["length"]) {
    console["error"]("No\x20sub-category\x20elements\x20found.");
    return;
  }
  const _0x3723ae = _0x5ad57c["trim"]()["toLowerCase"]();
  let _0x4758d9 = !0x1;
  for (const _0x5f4e8d of _0x35e5ea)
    if (
      (_0x5f4e8d["getAttribute"]("data-et-prop-content") || "")
        ["trim"]()
        ["toLowerCase"]() === _0x3723ae
    ) {
      (_0x5f4e8d["click"](),
        await _0x7322a(0xc8),
        _0x5f4e8d["click"](),
        await _0x7322a(0xc8),
        console["log"](
          "✔\x20Sub-category\x20\x22" +
            _0x5ad57c +
            "\x22\x20selected\x20and\x20menu\x20closed.",
        ),
        (_0x4758d9 = !0x0));
      break;
    }
  _0x4758d9 ||
    console["error"](
      "❌\x20Sub-category\x20\x22" +
        _0x5ad57c +
        "\x22\x20not\x20found\x20among:",
      Array["from"](_0x35e5ea)["map"]((_0x19b2d8) =>
        _0x19b2d8["getAttribute"]("data-et-prop-content"),
      ),
    );
}
async function _0x1f439c(_0xff3ea9, _0xd2316e) {
  const _0x49fe4e = [
      {
        name: "select_subcategory",
        description:
          "Choose\x20the\x20best\x20matching\x20Poshmark\x20sub_category\x20from\x20the\x20list,\x20or\x20NO_MATCH,\x20and\x20explain\x20why.",
        parameters: {
          type: "object",
          properties: {
            sub_category: { type: "string", enum: [..._0xd2316e, "NO_MATCH"] },
            reason: {
              type: "string",
              description:
                "A\x20brief\x20explanation\x20of\x20why\x20this\x20sub-category\x20was\x20chosen",
            },
          },
          required: ["sub_category", "reason"],
        },
      },
    ],
    _0x2e47f1 = {
      model: "gpt-4.1-nano",
      system_message:
        "You\x20are\x20a\x20Poshmark\x20sub-category\x20classifier.\x0a\x0aYou\x20MUST\x20only\x20choose\x20from\x20the\x20exact\x20list\x20of\x20sub-categories\x20provided\x20below.\x20Do\x20NOT\x20generate\x20new\x20values\x20or\x20reword\x20anything.\x0a\x0aValid\x20sub-category\x20options:\x0a" +
        _0xd2316e["map"]((_0x3c9864) => "-\x20" + _0x3c9864)["join"]("\x0a") +
        "\x0a\x0aIf\x20no\x20suitable\x20option\x20fits,\x20return\x20\x22NO_MATCH\x22.",
      user_message:
        "Based\x20on\x20the\x20product\x20details\x20below,\x20pick\x20the\x20most\x20appropriate\x20sub-category\x20and\x20explain\x20your\x20choice:\x0a\x0a" +
        _0xff3ea9,
      functions: _0x49fe4e,
      function_call: { name: "select_subcategory" },
    },
    _0x18172d = await _0x1fd9a7(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/json_schema",
      _0x2e47f1,
    );
  if (!_0x18172d["success"])
    return (
      console["error"]("Sub-category\x20API\x20failed:", _0x18172d["error"]),
      { sub_category: null, reason: "" }
    );
  const _0x57456c = _0x18172d["arguments"] || {};
  let _0x218ee4 = _0x57456c["sub_category"] || null;
  return (
    "NO_MATCH" === _0x218ee4 && (_0x218ee4 = null),
    { sub_category: _0x218ee4, reason: _0x57456c["reason"] || "" }
  );
}
async function _0x25ae3b(_0x4535b2) {
  const _0x12731d = [
      "Red",
      "Pink",
      "Orange",
      "Yellow",
      "Green",
      "Blue",
      "Purple",
      "Gold",
      "Silver",
      "Black",
      "Gray",
      "White",
      "Cream",
      "Brown",
      "Tan",
    ],
    _0x5031b7 = [
      {
        name: "select_color",
        description:
          "Choose\x20the\x20best\x20matching\x20Poshmark\x20color\x20from\x20the\x20list,\x20or\x20NO_MATCH\x20if\x20none\x20fit,\x20and\x20explain\x20why.",
        parameters: {
          type: "object",
          properties: {
            color: { type: "string", enum: [..._0x12731d, "NO_MATCH"] },
            reason: {
              type: "string",
              description:
                "A\x20brief\x20explanation\x20for\x20the\x20selection",
            },
          },
          required: ["color", "reason"],
        },
      },
    ],
    _0xb91d97 = {
      model: "gpt-4.1-nano",
      system_message:
        "You\x20are\x20a\x20Poshmark\x20color\x20classifier.\x0aAvailable\x20colors:\x0a" +
        _0x12731d["map"]((_0x5e1f96) => "-\x20" + _0x5e1f96)["join"]("\x0a") +
        "\x0a\x0aIf\x20none\x20applies,\x20return\x20\x22NO_MATCH\x22\x20with\x20a\x20reason.",
      user_message:
        "Based\x20on\x20the\x20product\x20details\x20below,\x20pick\x20the\x20single\x20best\x20color\x20and\x20explain\x20your\x20choice:\x0a\x0a" +
        _0x4535b2,
      functions: _0x5031b7,
      function_call: { name: "select_color" },
    },
    _0x14fee6 = await _0x1fd9a7(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/json_schema",
      _0xb91d97,
    );
  if (!_0x14fee6["success"])
    return (
      console["error"]("Color\x20API\x20error:", _0x14fee6["error"]),
      { color: null, reason: "" }
    );
  const _0x56108b = _0x14fee6["arguments"] || {};
  let _0x220b86 = _0x56108b["color"] || null;
  return (
    "NO_MATCH" === _0x220b86 && (_0x220b86 = null),
    { color: _0x220b86, reason: _0x56108b["reason"] || "" }
  );
}
async function _0x350656(_0x59aa6b) {
  const _0x420732 = [
      "70s",
      "80s",
      "90s",
      "Activewear",
      "Animal\x20Print",
      "Athleisure",
      "Avant\x20Garde",
      "Baggy",
      "Balletcore",
      "Beach",
      "Beaded",
      "Bikercore",
      "Business\x20Casual",
      "Blokecore",
      "Bodycon",
      "Bohemian",
      "Bow",
      "Bridal",
      "Bridesmaid",
      "Cashmere",
      "Casual",
      "Chunky",
      "Cable\x20Knit",
      "Collegiate",
      "Colorblock",
      "Colorful",
      "Contemporary",
      "Coord\x20Sets",
      "Coquette\x20Girl",
      "Corduroy",
      "Cozy",
      "Crochet",
      "Cropped",
      "Cruelty-Free",
      "Cut\x20Out",
      "Denim",
      "Distressed",
      "DIY",
      "Drop\x20Waist",
      "Eclectic\x20Grandpa",
      "Embroidered",
      "Faux\x20Fur",
      "Feminine",
      "Festival",
      "Flannel",
      "Flare",
      "Floral",
      "Formal",
      "Fringe",
      "Gingham",
      "Girlhoodcore",
      "Gorpcore",
      "Goth",
      "Grunge",
      "Handmade",
      "Hand\x20Knit",
      "Herringbone",
      "Houndstooth",
      "Indie\x20Sleeze",
      "Knit",
      "Lace",
      "Leather",
      "Leopard\x20Print",
      "Lightweight",
      "Linen",
      "Luxury",
      "Maximalism",
      "Mesh",
      "Metallic",
      "Minimalist",
      "Monochrome",
      "Monogram",
      "Moto",
      "Neon",
      "Neutral",
      "Nylon",
      "Office",
      "Oversized",
      "Paisley",
      "Pastel",
      "Party",
      "Patchwork",
      "Peplum",
      "Plaid",
      "Platform",
      "Pleated",
      "Polka\x20Dot",
      "Preppy",
      "Punk",
      "Quilted",
      "Quiet\x20Luxury",
      "Relaxed\x20Fit",
      "Resortwear",
      "Retro",
      "Rosette",
      "Ruffle",
      "Satin",
      "Seersucker",
      "Sequins",
      "Sheer",
      "Sherpa",
      "Silk",
      "Sporty",
      "Spring",
      "Strapless",
      "Streetwear",
      "Stripes",
      "Suede",
      "Summer",
      "Tailored",
      "Tennis\x20Prep",
      "Travel",
      "Tropical",
      "Tweed",
      "Two-Tone",
      "Unisex",
      "Upcycled",
      "Utility",
      "Vacation",
      "Vegan",
      "Velour",
      "Vintage",
      "Waterproof",
      "Wedding",
      "Western",
      "Whimsigoth",
      "Wool",
      "Woven",
      "Y2K",
    ],
    _0xaabff6 = [
      {
        name: "select_styles",
        description:
          "Pick\x20up\x20to\x20three\x20style\x20tags\x20from\x20the\x20above\x20list,\x20or\x20NO_MATCH\x20if\x20none\x20apply,\x20and\x20explain\x20your\x20reasoning.",
        parameters: {
          type: "object",
          properties: {
            selected_styles: {
              type: "array",
              items: { type: "string", enum: [..._0x420732, "NO_MATCH"] },
              description:
                "At\x20most\x20three\x20style\x20tags,\x20or\x20[\x27NO_MATCH\x27]\x20if\x20no\x20suitable\x20styles.",
            },
            reason: {
              type: "string",
              description: "Why\x20these\x20styles\x20were\x20chosen",
            },
          },
          required: ["selected_styles", "reason"],
        },
      },
    ],
    _0x4b6fd4 = {
      model: "gpt-4.1-nano",
      system_message:
        "You\x20are\x20a\x20Poshmark\x20style\x20classifier.\x0aAvailable\x20styles\x20(pick\x20up\x20to\x203):\x0a" +
        _0x420732["map"]((_0x4b36ea) => "-\x20" + _0x4b36ea)["join"]("\x0a") +
        "\x0a\x0aIf\x20none\x20fit,\x20return\x20[\x22NO_MATCH\x22]\x20with\x20a\x20reason.",
      user_message:
        "Based\x20on\x20the\x20product\x20details\x20below,\x20pick\x20up\x20to\x20three\x20styles\x20and\x20explain\x20your\x20choice:\x0a\x0a" +
        _0x59aa6b,
      functions: _0xaabff6,
      function_call: { name: "select_styles" },
    },
    _0x39bd75 = await _0x1fd9a7(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/json_schema",
      _0x4b6fd4,
    );
  if (!_0x39bd75["success"])
    return (
      console["error"]("Styles\x20API\x20error:", _0x39bd75["error"]),
      { styles: [], reason: "" }
    );
  const _0x45133a = _0x39bd75["arguments"] || {};
  let _0x36ab50 = Array["isArray"](_0x45133a["selected_styles"])
    ? _0x45133a["selected_styles"]
    : [];
  const _0x852ef5 = _0x45133a["reason"] || "";
  return (
    0x1 === _0x36ab50["length"] &&
      "NO_MATCH" === _0x36ab50[0x0] &&
      (_0x36ab50 = []),
    (_0x36ab50 = _0x36ab50["slice"](0x0, 0x3)),
    { styles: _0x36ab50, reason: _0x852ef5 }
  );
}
async function _0x51d9de(_0x1ebfb6 = []) {
  if (!Array["isArray"](_0x1ebfb6) || 0x0 === _0x1ebfb6["length"]) {
    console["warn"]("selectStyles:\x20no\x20styles\x20provided,\x20skipping.");
    return;
  }
  const _0x4d7f37 = Array["from"](
    document["querySelectorAll"](".listing-editor__section__title"),
  )["find"]((_0x98265c) =>
    _0x98265c["innerText"]
      ["trim"]()
      ["toLowerCase"]()
      ["includes"]("style\x20tag"),
  );
  if (!_0x4d7f37) {
    console["error"](
      "selectStyles:\x20could\x20not\x20find\x20Style\x20Tags\x20section.",
    );
    return;
  }
  const _0x3cc5d3 = _0x4d7f37["closest"](".listing-editor__section");
  if (!_0x3cc5d3) {
    console["error"](
      "selectStyles:\x20Style\x20Tags\x20section\x20wrapper\x20not\x20found.",
    );
    return;
  }
  const _0x5be793 = _0x3cc5d3["querySelector"]("[data-test=\x22dropdown\x22]");
  if (_0x5be793) {
    (_0x5be793["click"](), await _0xbba28b(0x12c));
    for (const _0x469ef0 of _0x1ebfb6["slice"](0x0, 0x3)) {
      const _0x2f1b53 = _0x469ef0["trim"]()["toLowerCase"](),
        _0x3f54ba = Array["from"](
          _0x3cc5d3["querySelectorAll"](".dropdown__menu\x20[data-et-name]"),
        )["find"](
          (_0x1cf951) =>
            _0x1cf951["getAttribute"]("data-et-name")
              ["trim"]()
              ["toLowerCase"]() === _0x2f1b53,
        );
      if (_0x3f54ba)
        (_0x3f54ba["click"](),
          console["log"](
            "✔︎\x20Selected\x20style\x20tag:\x20\x22" + _0x469ef0 + "\x22",
          ));
      else
        console["warn"](
          "⚠︎\x20Style\x20\x22" +
            _0x469ef0 +
            "\x22\x20not\x20found\x20in\x20the\x20list.",
        );
      await _0xbba28b(0xc8);
    }
    (_0x5be793["click"](), await _0xbba28b(0xc8));
  } else
    console["error"]("selectStyles:\x20dropdown\x20toggle\x20not\x20found.");
}
async function _0x34bfc7(_0x472b73) {
  const _0x46faf0 = {
      system_message:
        "You\x27re\x20writing\x20highly\x20personalized,\x20friendly,\x20skimmable\x20Poshmark\x20descriptions\x20for\x20fashion-savvy\x20shoppers.\x0a\x0aUse\x20plain\x20text\x20only\x20—\x20no\x20special\x20formatting.\x20Always\x20include\x20\x22Brand\x20New\x22\x20clearly\x20in\x20the\x20Condition.\x20If\x20a\x20color\x20is\x20mentioned,\x20include\x20a\x20\x22Color:\x22\x20line.\x20Each\x20key\x20detail\x20should\x20be\x20on\x20its\x20own\x20line.\x0a\x0aMake\x20it\x20sound\x20like\x20a\x20real\x20person\x20talking\x20to\x20a\x20style-conscious\x20buyer\x20—\x20imagine\x20you\x27re\x20chatting\x20with\x20a\x20friend\x20who\x20cares\x20about\x20how\x20it\x20fits,\x20how\x20it\x20feels,\x20and\x20where\x20they\x20might\x20wear\x20it.\x20Think\x20like\x20a\x20personal\x20stylist.\x0a\x0aStructure:\x0a\x0a[Brand]\x20[Item]\x20—\x20[optional\x20short\x20vibe\x20tagline,\x20e.g.\x20“A\x20summer\x20staple”]\x0a\x0aSize:\x20[label]\x0aColor:\x20[color\x20if\x20known]\x0aCondition:\x20Brand\x20new,\x20no\x20flaws.\x0aFeatures:\x20[natural-sounding\x20summary\x20—\x20not\x20generic\x20—\x20include\x20silhouette,\x20feel,\x20standout\x20uses,\x20fit]\x0aMaterial:\x20[if\x20known]\x0aMeasurements:\x20[if\x20included\x20—\x20e.g.\x20Bust,\x20Waist,\x20Length]\x0aGreat\x20for:\x20[example\x20occasions\x20or\x20styling\x20ideas\x20—\x20make\x20it\x20*match\x20the\x20item*]\x0a\x0a[optional\x20warm\x20extras\x20—\x20smoke-free\x20home,\x20quick\x20shipping,\x20friendly\x20seller,\x20bundle\x20&\x20save]\x0a\x0aExample:\x0aReformation\x20Slip\x20Dress\x20—\x20Minimalist\x20dream\x20for\x20warm\x20weather.\x0a\x0aSize:\x20S\x20\x20\x0aColor:\x20Black\x20\x20\x0aCondition:\x20Brand\x20new,\x20no\x20flaws.\x20\x20\x0aFeatures:\x20Sleek\x20satin\x20midi\x20dress\x20with\x20clean\x20lines\x20and\x20a\x20flattering\x20drape.\x20Adjustable\x20straps,\x20bias\x20cut,\x20easy\x20to\x20dress\x20up\x20or\x20down.\x20\x20\x0aMaterial:\x20100%\x20satin\x20\x20\x0aMeasurements:\x20Length:\x2034\x20in,\x20Bust:\x2034\x20in\x20\x20\x0aGreat\x20for:\x20Date\x20nights,\x20garden\x20weddings,\x20or\x20layered\x20under\x20a\x20blazer.\x20\x20\x0a\x0aShips\x20quick\x20from\x20smoke-free,\x20pet-free\x20home.\x20Reasonable\x20offers\x20welcome.\x20Bundle\x20to\x20save!\x0a\x0a",
      user_message:
        "Now\x20write\x20a\x20similar\x20description\x20for\x20this\x20item\x20using\x20the\x20template\x20above:\x0a\x0a" +
        _0x472b73 +
        "\x20\x0a\x0a\x20----------\x0aRespond\x20back\x20with\x20only\x20the\x20description",
      functions: [
        {
          name: "generate_poshmark_description",
          description:
            "Generate\x20a\x20plain-text\x20Poshmark\x20description\x20under\x201500\x20characters",
          parameters: {
            type: "object",
            properties: {
              description: {
                type: "string",
                description:
                  "Plain\x20text\x20Poshmark-friendly\x20listing\x20description\x20following\x20the\x20template",
              },
            },
            required: ["description"],
          },
        },
      ],
      function_call: { name: "generate_poshmark_description" },
      model: "gpt-4.1-nano",
    },
    _0x39be91 = await _0x1fd9a7(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/json_schema",
      _0x46faf0,
    );
  console["log"]("Generated\x20Poshmark\x20description:", _0x39be91);
  if (!_0x39be91["success"]) {
    console["error"]("OpenAI\x20function\x20error:", _0x39be91["error"]);
    throw new Error(
      _0x39be91["error"] ||
        "Failed\x20to\x20generate\x20Poshmark\x20description.",
    );
  }
  return _0x39be91["arguments"]["description"];
}
(console["log"]("content/poshmark/listing/content.js"), _0x394c31());
var _0x41eb48;
chrome["runtime"]["onMessage"]["addListener"](
  function (_0x27c752, _0x13aa85, _0x143d10) {
    if ("insert_draft_details" === _0x27c752["type"]) {
      (console["log"]("insert_draft_details"),
        (_0x41eb48 = _0x27c752["productData"]),
        console["log"]("productData:", _0x41eb48));
      var _0x27c99d = _0x41eb48["listingType"];
      _0x167e39("[data-et-name=\x22listingEditorPricingSection\x22]", 0x7530)
        ["then"](async () => {
          "opti" === _0x27c99d
            ? await _0x3cabf5(_0x41eb48)
            : await _0x26d961(_0x41eb48);
        })
        ["catch"]((_0x292052) => {
          (console["error"]("error:", _0x292052),
            chrome["runtime"]["sendMessage"]({
              type: "error",
              error: _0x292052,
            }));
        });
    }
    "poshmark_test" === _0x27c752["type"] &&
      (console["log"]("Poshmark\x20Test"), _0x3cabf5(_0xd9d0d8));
  },
);
async function _0x3cabf5(_0x160cfd) {
  var _0x4626c3 = _0x160cfd["descriptionAndFeatures"],
    _0x530305 = _0x160cfd["custom_title"];
  document["title"] = "🔍\x20Detecting\x20Category...";
  const { main: _0x309c8b, sub: _0x396f9f } = await _0x3c541a(_0x4626c3);
  (console["log"]("→\x20Main:", _0x309c8b, "\x20Sub:", _0x396f9f),
    (document["title"] = "📂\x20Setting\x20Category..."),
    await _0x207e49(_0x309c8b, _0x396f9f),
    (document["title"] = "📑\x20Scraping\x20Subcategories..."));
  const _0x1f2aed = await _0x4b3221();
  var { sub_category: _0xb94758, reason: _0x32479c } = await _0x1f439c(
    _0x4626c3,
    _0x1f2aed,
  );
  (console["log"](
    "→\x20AI\x20chose\x20sub-category:",
    _0xb94758,
    "\x0a\x20\x20\x20because:",
    _0x32479c,
  ),
    (document["title"] = "📂\x20Setting\x20Subcategory..."),
    await _0xb39d87(_0xb94758),
    (document["title"] = "📏\x20Getting\x20Size\x20Groups..."));
  const _0x450cc9 = await _0x5cf71e();
  (console["log"]("Size\x20groups:", _0x450cc9),
    (document["title"] = "🔎\x20Detecting\x20Size..."));
  const _0x474ec1 = _0x38bb19(_0x450cc9);
  console["log"]("Flattened\x20sizes:", _0x474ec1);
  if (0x1 === _0x474ec1["length"]) await _0x3805da("OS");
  else {
    const _0x31c8f3 = await _0x2418ac(_0x4626c3, _0x474ec1);
    console["log"]("Detected\x20size:", _0x31c8f3);
    if (_0x31c8f3 && "NO_MATCH" !== _0x31c8f3) {
      document["title"] = "📁\x20Selecting\x20Size...";
      const _0x23e259 =
        findGroupForSize(_0x31c8f3, _0x450cc9) || _0x450cc9[0x0]["group"];
      (console["log"](
        "Selecting\x20\x22" +
          _0x31c8f3 +
          "\x22\x20under\x20group\x20\x22" +
          _0x23e259 +
          "\x22",
      ),
        await _0x2f0fd5(_0x31c8f3, _0x23e259));
    } else
      ((document["title"] =
        "⚠️\x20No\x20matching\x20size;\x20skipping\x20selection."),
        console["warn"]("No\x20matching\x20size;\x20skipping\x20selection."),
        await _0x3805da("OS"));
  }
  document["title"] = "🎨\x20Detecting\x20Color...";
  var { color: _0x343789, reason: _0x32479c } = await _0x25ae3b(_0x4626c3);
  (console["log"](
    "→\x20AI\x20chose\x20color:",
    _0x343789,
    "\x0abecause:",
    _0x32479c,
  ),
    (document["title"] = "🎨\x20Selecting\x20Color..."),
    await _0x785c77(_0x343789),
    (document["title"] = "🧵\x20Detecting\x20Styles..."));
  var { styles: _0x1c1c75, reason: _0x32479c } = await _0x350656(_0x4626c3);
  (console["log"]("Styles:", _0x1c1c75, "\x0aReason:", _0x32479c),
    (document["title"] = "🧵\x20Selecting\x20Styles..."),
    await _0x51d9de(_0x1c1c75),
    (document["title"] = "📝\x20Generating\x20Description..."));
  var _0x3752fb = await _0x34bfc7(_0x530305 + "\x0a" + _0x4626c3);
  (await _0x47cdd4(_0x3752fb),
    (document["title"] = "🏷️\x20Setting\x20Title..."),
    await _0x587ffd(_0x160cfd["custom_title"]),
    (document["title"] = "🏷️\x20Title\x20Set"),
    (document["title"] = "🖼️\x20Setting\x20Images..."));
  var _0x5c048b,
    _0x2eef5c = _0x160cfd["main_hd_images"],
    _0x36190c = _0x160cfd["main_sd_images"];
  (_0x2eef5c,
    (_0x5c048b =
      _0x2eef5c["length"] < 0x2 && _0x36190c["length"] > 0x2
        ? _0x36190c
        : _0x2eef5c),
    await _0x2beaff(_0x5c048b),
    (document["title"] = "🖼️\x20Images\x20Set"),
    (document["title"] = "🔢\x20Setting\x20SKU..."),
    await _0x549366(btoa(_0x160cfd["sku"])),
    (document["title"] = "🔢\x20SKU\x20Set"),
    (document["title"] = "💲\x20Setting\x20Listing\x20Price..."));
  var _0x319053 = Number(_0x160cfd["custom_price"]);
  ((_0x319053 = Math["round"](_0x319053)),
    await _0x44e2bf(_0x319053),
    (document["title"] = "💲\x20Listing\x20Price\x20Set"),
    (document["title"] = "💲\x20Setting\x20Original\x20Price..."),
    await _0x3ff4af(1.5 * _0x319053),
    (document["title"] = "💲\x20Original\x20Price\x20Set"),
    (document["title"] = "📸\x20Selecting\x20Cover\x20Shot..."),
    await _0xbf7392(0x1388),
    (document["title"] = "📸\x20Cover\x20Shot\x20Selected"),
    _0x36218a(_0x160cfd));
  var { autoSubmitEnabled: _0x378657 } =
    await chrome["storage"]["local"]["get"]("autoSubmitEnabled");
  _0x378657 &&
    ((document["title"] = "🚀\x20Listing\x20Item..."),
    await _0x23983c(),
    (document["title"] = "✅\x20Item\x20Listed"));
}
