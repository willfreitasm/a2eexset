function _0x397189() {
  return new Promise((_0x5209fd) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x5209fd();
      });
    });
  });
}
function _0x20377c() {
  return new Promise((_0x452288) => {
    requestIdleCallback(() => {
      _0x452288();
    });
  });
}
function _0x3f8570(_0x3e7e85 = 0x3e8) {
  return new Promise((_0x144677, _0x152350) => {
    let _0x2f0c0f,
      _0x46d3e2 = Date["now"](),
      _0x189253 = !0x1;
    function _0x345119() {
      if (Date["now"]() - _0x46d3e2 > _0x3e7e85)
        (_0x189253 && _0x2f0c0f["disconnect"](), _0x144677());
      else setTimeout(_0x345119, _0x3e7e85);
    }
    const _0x43f80f = () => {
        _0x46d3e2 = Date["now"]();
      },
      _0x3c6426 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x2f0c0f = new MutationObserver(_0x43f80f)),
        _0x2f0c0f["observe"](document["body"], _0x3c6426),
        (_0x189253 = !0x0),
        setTimeout(_0x345119, _0x3e7e85));
    else
      window["onload"] = () => {
        ((_0x2f0c0f = new MutationObserver(_0x43f80f)),
          _0x2f0c0f["observe"](document["body"], _0x3c6426),
          (_0x189253 = !0x0),
          setTimeout(_0x345119, _0x3e7e85));
      };
  });
}
async function _0x34572a() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x3f8570(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x526f09(
  _0x49bda0 = null,
  _0x19fce2 = null,
  _0x466436 = null,
  _0x2da430 = null,
) {
  var _0xaf937e = document["createElement"]("a");
  (_0xaf937e["setAttribute"]("class", "a-link-text"),
    _0xaf937e["classList"]["add"]("icon"),
    _0xaf937e["classList"]["add"]("amazonSearchLink"),
    _0xaf937e["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x18159a = document["createElement"]("img");
  return (
    _0x18159a["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x18159a["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xaf937e["appendChild"](_0x18159a),
    _0xaf937e["addEventListener"]("click", async function (_0x554443) {
      (_0x554443["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x49bda0) {
        var _0x1e5b97 = _0x172c34(_0x554443);
        if (!_0x1e5b97) return;
        var _0xcbc136 = extractItemData(_0x1e5b97);
        ((_0x49bda0 = _0xcbc136["title"])["endsWith"]("...") &&
          (_0x49bda0 = _0x49bda0["substring"](
            0x0,
            _0x49bda0["lastIndexOf"]("\x20"),
          )),
          _0x49bda0["length"] > 0x4b &&
            (_0x49bda0 = _0x49bda0["substring"](
              0x0,
              _0x49bda0["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x101785 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x101785),
        _0x101785 || (_0x101785 = "reviews"),
        console["log"]("amazonSortType", _0x101785),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x41cf80 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x49bda0["length"] > 0x50; )
        _0x49bda0 = _0x49bda0["substring"](
          0x0,
          _0x49bda0["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x55967d } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x168c0e = _0x49bda0;
      "keywords" == _0x55967d && (_0x168c0e = await _0x398c75(_0x49bda0));
      try {
        _0xcbc136 = extractItemData(_0x1e5b97);
      } catch (_0x366979) {
        console["log"]("error", _0x366979);
      }
      (_0xcbc136 ||
        (_0xcbc136 = {
          title: _0x49bda0,
          price: _0x19fce2,
          itemNumber: _0x466436,
          image: _0x2da430,
        }),
        console["log"]("itemData", _0xcbc136),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x168c0e,
          options: { isTabActive: !0x0, sort: _0x101785 },
          itemData: _0xcbc136,
        }));
    }),
    _0xaf937e
  );
}
function _0x1f4482(_0x1b6a0b) {
  var _0x5e8e55 = document["createElement"]("a");
  (_0x5e8e55["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x5e8e55["setAttribute"]("class", "a-link-text"),
    _0x5e8e55["classList"]["add"]("icon"),
    _0x5e8e55["classList"]["add"]("amazonSearchLink"),
    _0x5e8e55["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x4e0ef2 = document["createElement"]("img");
  return (
    _0x4e0ef2["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4e0ef2["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5e8e55["appendChild"](_0x4e0ef2),
    _0x5e8e55["addEventListener"]("click", async function (_0x45f461) {
      (_0x45f461["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x1b6a0b),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x1b6a0b,
        }));
    }),
    _0x5e8e55
  );
}
function _0x1d2a38(_0x2c6c74) {
  var _0x1620ce = document["createElement"]("a");
  (_0x1620ce["setAttribute"]("id", "amazonLink"),
    _0x1620ce["setAttribute"]("class", "a-link-text"),
    _0x1620ce["classList"]["add"]("icon"),
    _0x1620ce["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x5e8d6a = document["createElement"]("img");
  return (
    _0x5e8d6a["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x5e8d6a["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1620ce["appendChild"](_0x5e8d6a),
    _0x1620ce["addEventListener"]("click", async function (_0x48355b) {
      (_0x48355b["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x1ccd96 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0xdf03fd =
          "https://www.amazon." +
          _0x1ccd96 +
          "/dp/" +
          _0x2c6c74 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0xdf03fd });
    }),
    _0x1620ce
  );
}
function _0x43e0ce(_0x3148de) {
  var _0x4189fe = document["createElement"]("a");
  (_0x4189fe["setAttribute"]("id", "amazonLink"),
    _0x4189fe["setAttribute"]("class", "a-link-text"),
    _0x4189fe["classList"]["add"]("icon"),
    _0x4189fe["classList"]["add"]("amazonLink"),
    _0x4189fe["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x2f2ee4 = document["createElement"]("img");
  return (
    _0x2f2ee4["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x2f2ee4["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4189fe["appendChild"](_0x2f2ee4),
    _0x4189fe["addEventListener"]("click", async function (_0x49495a) {
      (_0x49495a["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x3148de(_0x49495a);
      } catch (_0x30cc33) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x30cc33);
      }
    }),
    _0x4189fe
  );
}
function _0x3bf6ce(
  _0x417ceb = null,
  _0x4ee6d5,
  _0x142b83 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x417ceb, _0x4ee6d5);
  var _0xbea457 = document["createElement"]("a");
  (_0xbea457["setAttribute"]("id", "ebayLink"),
    _0xbea457["setAttribute"]("class", "a-link-text"),
    _0xbea457["classList"]["add"]("icon"),
    _0x4ee6d5 && _0x4ee6d5["soldItems"]
      ? _0xbea457["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0xbea457["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x475e41 = document["createElement"]("img");
  return (
    _0x475e41["setAttribute"]("src", chrome["runtime"]["getURL"](_0x142b83)),
    _0x475e41["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xbea457["appendChild"](_0x475e41),
    _0xbea457["addEventListener"]("click", async function (_0x164e2c) {
      (_0x164e2c["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x417ceb) console["log"]("title\x20found", _0x417ceb);
      else {
        console["log"]("title\x20not\x20found");
        var _0x24b85d = _0x172c34(_0x164e2c);
        if (!_0x24b85d) return;
        var _0x216a77 = extractItemData(_0x24b85d);
        _0x417ceb = _0x216a77["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x265389 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x417ceb["length"] > 0x50; )
        _0x417ceb = _0x417ceb["substring"](
          0x0,
          _0x417ceb["lastIndexOf"]("\x20"),
        );
      var _0x5eb613 =
        "https://www.ebay." +
        _0x265389 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x417ceb) +
        "&_odkw=" +
        encodeURIComponent(_0x417ceb);
      (_0x4ee6d5 && _0x4ee6d5["soldItems"] && (_0x5eb613 += "&LH_Sold=1"),
        _0x4ee6d5 && _0x4ee6d5["sortLowToHigh"] && (_0x5eb613 += "&_sop=15"),
        _0x4ee6d5 && _0x4ee6d5["endedRecently"] && (_0x5eb613 += "&_sop=13"),
        (_0x5eb613 += "&LH_ItemCondition=1000"),
        (_0x5eb613 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x5eb613,
        }));
    }),
    _0xbea457
  );
}
function _0x47b3af(_0x4b695d = null) {
  var _0x4e806f = document["createElement"]("a");
  (_0x4e806f["setAttribute"]("id", "googleLink"),
    _0x4e806f["setAttribute"]("class", "a-link-text"),
    _0x4e806f["classList"]["add"]("icon"),
    _0x4e806f["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x525a2b = document["createElement"]("img");
  return (
    _0x525a2b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x525a2b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4e806f["appendChild"](_0x525a2b),
    _0x4e806f["addEventListener"]("click", async function (_0x5d3bd4) {
      (_0x5d3bd4["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x4b695d) {
        var _0x3cb75d = _0x172c34(_0x5d3bd4);
        if (!_0x3cb75d) return;
        var _0x54eda9 = extractItemData(_0x3cb75d);
        _0x4b695d = _0x54eda9["image"];
      }
      var { domain: _0x36e955 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0xaf9c77(_0x36e955),
        encodeURIComponent(_0x4b695d),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x4b695d,
        }));
    }),
    _0x4e806f
  );
}
function _0x80f3e4(_0x16bd42 = null) {
  var _0x2eee78 = document["createElement"]("a");
  (_0x2eee78["setAttribute"]("id", "googleLink"),
    _0x2eee78["setAttribute"]("class", "a-link-text"),
    _0x2eee78["classList"]["add"]("icon"),
    _0x2eee78["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x11211b = document["createElement"]("img");
  return (
    _0x11211b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x11211b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2eee78["appendChild"](_0x11211b),
    _0x2eee78["addEventListener"]("click", async function (_0x403848) {
      (_0x403848["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x16bd42) {
        var _0x44b2a2 = _0x172c34(_0x403848);
        if (!_0x44b2a2) return;
        var _0x182a2a = extractItemData(_0x44b2a2);
        _0x16bd42 = _0x182a2a["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x16bd42,
      });
    }),
    _0x2eee78
  );
}
function _0x46ab27(_0x3c0072) {
  var _0xfd2d64 = document["createElement"]("a");
  (_0xfd2d64["setAttribute"]("id", "lookUpSkuLink"),
    _0xfd2d64["setAttribute"]("class", "a-link-text"),
    _0xfd2d64["classList"]["add"]("icon"),
    _0xfd2d64["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x539a07 = document["createElement"]("img");
  return (
    _0x539a07["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x539a07["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xfd2d64["appendChild"](_0x539a07),
    _0xfd2d64["addEventListener"]("click", async function (_0x5a552d) {
      (_0x5a552d["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x298abf } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x583557 =
          "https://www.amazon." +
          _0x298abf +
          "/dp/" +
          _0x3c0072 +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x583557,
        options: { active: !0x0 },
      });
    }),
    _0xfd2d64
  );
}
function _0x2cbb09(_0x58c333 = null) {
  var _0x47d0d7 = document["createElement"]("a");
  (_0x47d0d7["setAttribute"]("id", "productHunterLink"),
    _0x47d0d7["setAttribute"]("class", "a-link-text"),
    _0x47d0d7["classList"]["add"]("icon"),
    _0x47d0d7["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0xe9c450 = document["createElement"]("img");
  return (
    _0xe9c450["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0xe9c450["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x47d0d7["appendChild"](_0xe9c450),
    _0x47d0d7["addEventListener"]("click", async function (_0x51c87d) {
      (_0x51c87d["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x58c333) {
        var _0x51ba9e = _0x172c34(_0x51c87d);
        if (!_0x51ba9e) return;
        var _0x1809da = extractItemData(_0x51ba9e);
        _0x58c333 = _0x1809da["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x58c333),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x58c333,
        }));
    }),
    _0x47d0d7
  );
}
function _0xaf9c77(_0x3b4938) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x3b4938] || "en-US";
}
function _0x4b7ddb(_0x338223 = null) {
  console["log"]("createSearchTerapeakButton", _0x338223);
  var _0xacdc81 = document["createElement"]("a");
  (_0xacdc81["setAttribute"]("class", "a-link-text"),
    _0xacdc81["classList"]["add"]("terapeakLink"),
    _0xacdc81["classList"]["add"]("icon"),
    _0xacdc81["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x338223 && _0xacdc81["setAttribute"]("item_title", _0x338223));
  var _0x18537e = document["createElement"]("img");
  return (
    _0x18537e["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x18537e["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xacdc81["appendChild"](_0x18537e),
    _0xacdc81["addEventListener"]("click", async function (_0x1442f4) {
      (_0x1442f4["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x44c4be = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x44c4be),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x44c4be) {
        var _0x2a2134 = _0x172c34(_0x1442f4);
        if (!_0x2a2134) return;
        _0x44c4be = extractItemData(_0x2a2134)["title"];
      }
      console["log"]("title", _0x44c4be);
      var { convertToKeywords: _0x57e8e1 } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x57e8e1) var _0x44c4be = await _0x398c75(_0x44c4be);
      var { domain: _0x33647e } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x4ca39d = _0x343b3f(_0x44c4be, _0x33647e);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x4ca39d });
    }),
    _0xacdc81
  );
}
async function _0x398c75(_0x2b216a) {
  var _0x55d0d8 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x533aad) => _0x533aad["json"]());
  ((_0x55d0d8["user_input"] = _0x2b216a),
    console["log"]("jsonPrompt", _0x55d0d8));
  var _0x1f11ff = await new Promise((_0x325388, _0x1be603) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x55d0d8,
      },
      function (_0x33cefe) {
        _0x325388(_0x33cefe["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x1f11ff),
    (_0x1f11ff = JSON["parse"](_0x1f11ff))["output"]
  );
}
function _0x343b3f(
  _0x429abe,
  _0x362fa5 = "ca",
  _0x20d06f = 0x1e,
  _0x143e72 = 0x0,
  _0xe7186c = 0x0,
  _0x16a917 = 0x32,
  _0x484dd6 = "-itemssold",
  _0x14e6ba = "SOLD",
  _0x241935 = "EBAY-CA",
  _0x5f02d0 = "America/Toronto",
  _0x474960 = "BuyerLocation:::CA",
  _0x53e373 = 0x0,
) {
  _0x241935 = "";
  switch (_0x362fa5) {
    case "ca":
    default:
      _0x241935 = "EBAY-CA";
      break;
    case "com":
      _0x241935 = "EBAY-US";
      break;
    case "co.uk":
      _0x241935 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x362fa5 +
    "/sh/research?" +
    [
      "keywords=" + _0x429abe,
      "dayRange=" + _0x20d06f,
      "categoryId=" + _0x143e72,
      "offset=" + _0xe7186c,
      "limit=" + _0x16a917,
      "sorting=" + _0x484dd6,
      "tabName=" + _0x14e6ba,
      "marketplace=" + _0x241935,
      "tz=" + encodeURIComponent(_0x5f02d0),
      "minPrice=" + _0x53e373,
    ]["join"]("&")
  );
}
async function _0x5d0f16(_0x29ba47) {
  var { domain: _0x27b646 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x30a796 =
      "https://www.ebay." +
      _0x27b646 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x29ba47 +
      "&store_name=" +
      _0x29ba47 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x30a796 });
}
async function _0x507528(_0xaabab2) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0xaabab2,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0xaabab2));
}
async function _0x5a051e(_0x26cc03) {
  var { response: _0x2f241c } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x26cc03,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x2f241c), _0x2f241c);
}
function _0x3ed96b(_0xb33174 = null) {
  console["log"]("createOpenSellerItemsButton", _0xb33174);
  var _0x34606e = document["createElement"]("a");
  (_0x34606e["setAttribute"]("id", "sellerItemsLink"),
    _0x34606e["setAttribute"]("class", "a-link-text"),
    _0x34606e["classList"]["add"]("icon"),
    _0x34606e["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x43c197 = document["createElement"]("img");
  return (
    _0x43c197["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x43c197["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x34606e["appendChild"](_0x43c197),
    _0x34606e["addEventListener"]("click", async function (_0x34b042) {
      (_0x34b042["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0xb33174),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0xb33174));
      var _0xf2dd9a;
      if (!_0xb33174) {
        console["log"]("username\x20not\x20found");
        var _0x22e35 = _0x172c34(_0x34b042);
        console["log"]("item\x20from\x20createOpenSellerItemsButton", _0x22e35);
        if (!_0x22e35) return;
        var _0x41ed0c = extractItemData(_0x22e35);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x41ed0c,
        ),
          (_0xb33174 = _0x41ed0c["username"]),
          (_0xf2dd9a = _0x41ed0c["itemNumber"]));
      }
      if (
        _0xb33174["includes"]("\x20") ||
        _0xb33174 !== _0xb33174["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0xb33174,
        );
        if (!_0xf2dd9a) {
          if (!(_0x22e35 = _0x172c34(_0x34b042))) return;
          _0xf2dd9a = (_0x41ed0c = extractItemData(_0x22e35))["itemNumber"];
        }
        _0x507528(_0xf2dd9a);
      } else
        ((_0xb33174 = _0xb33174["toLowerCase"]()),
          console["log"]("username", _0xb33174),
          _0x5d0f16(_0xb33174));
    }),
    _0x34606e
  );
}
function _0x504645(_0x2f3539) {
  for (
    ;
    _0x2f3539 &&
    !_0x2f3539["classList"]["contains"]("s-item") &&
    !_0x2f3539["classList"]["contains"]("su-card-container");

  )
    _0x2f3539 = _0x2f3539["parentElement"];
  return _0x2f3539;
}
function _0x572fe1(_0x2e0b41 = null) {
  var _0x1172eb = document["createElement"]("a");
  (_0x1172eb["setAttribute"]("id", "purchaseHistoryLink"),
    _0x1172eb["setAttribute"]("class", "a-link-text"),
    _0x1172eb["classList"]["add"]("icon"),
    _0x1172eb["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x4a3863 = document["createElement"]("img");
  return (
    _0x4a3863["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x4a3863["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1172eb["appendChild"](_0x4a3863),
    _0x1172eb["addEventListener"]("click", async function (_0x3f3ea1) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x2e0b41),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x3f3ea1["preventDefault"]());
      var _0x193a22 = _0x172c34(_0x3f3ea1);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x193a22,
      );
      if (_0x193a22) {
        var { selectedFilter: _0x3c652f } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x3c652f &&
          ((_0x3c652f = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x3c652f,
          }));
        var _0x404f9c = _0x3c652f,
          _0x58822 = await checkPurchaseHistoryAndAddToItem(
            _0x193a22,
            _0x404f9c,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x58822);
      } else
        try {
          var _0x514b0d = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x2e0b41,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x514b0d),
            (_0x58822 = _0x514b0d["totalSold"]));
        } catch (_0x45579f) {
          (console["log"]("error", _0x45579f), (_0x58822 = -0x3e7));
        }
    }),
    _0x1172eb
  );
}
function _0x172c34(_0x1fa902) {
  var _0x159ca2 = _0x1fa902["target"];
  return (
    (_0x159ca2 = _0x504645(_0x159ca2)),
    console["log"]("found\x20s-item", _0x159ca2),
    _0x159ca2
  );
}
function _0x3383ca(_0x4c7d22 = null, _0x382303 = null, _0x1555c8 = null) {
  var _0x2cefca = document["createElement"]("a");
  (_0x2cefca["setAttribute"]("id", "copyDataLink"),
    _0x2cefca["setAttribute"]("class", "a-link-text"),
    _0x2cefca["classList"]["add"]("icon"),
    _0x2cefca["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x2428fe = document["createElement"]("img");
  return (
    _0x2428fe["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x2428fe["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2cefca["appendChild"](_0x2428fe),
    _0x2cefca["addEventListener"]("click", async function (_0x5a2b82) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x4c7d22,
        _0x382303,
        _0x1555c8,
      ),
        _0x5a2b82["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x4c7d22 && _0x382303 && _0x1555c8)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x4c7d22,
          _0x382303,
          _0x1555c8,
        ),
          isNaN(_0x382303) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x382303),
            (_0x382303 = _0x382303["replace"](/[^0-9.]/g, ""))),
          _0x4c2606(
            JSON["stringify"]({
              title: _0x4c7d22,
              price: _0x382303,
              itemNumber: _0x1555c8,
            }),
          ));
      else {
        if (!_0x4c7d22 || !_0x382303 || !_0x1555c8) {
          var _0x5d6268 = _0x172c34(_0x5a2b82);
          if (!_0x5d6268) return;
        }
        var _0x2e2ef9 = extractItemData(_0x5d6268);
        (console["log"]("itemData", _0x2e2ef9),
          _0x4c2606(JSON["stringify"](_0x2e2ef9)));
      }
    }),
    _0x2cefca
  );
}
function _0x4c2606(_0x5df253) {
  var _0x3cb18c = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x3cb18c),
    (_0x3cb18c["value"] = _0x5df253),
    _0x3cb18c["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x3cb18c));
}
async function _0x19781b(_0x235071 = null) {
  console["log"]("price", _0x235071);
  if (_0x235071) {
    try {
      _0x235071 = _0x235071["replace"](/[^0-9.]/g, "");
    } catch (_0x4995a1) {}
    _0x235071 = parseFloat(_0x235071);
  }
  var _0x4b0430 = await _0x4616c0(_0x235071),
    _0x101d14 = document["createElement"]("div");
  return (
    _0x101d14["setAttribute"]("id", "breakEvenPrice"),
    _0x101d14["setAttribute"]("class", "break-even-price"),
    (_0x101d14["textContent"] =
      "Break-even\x20price:\x20$" + _0x4b0430["toFixed"](0x2)),
    _0x101d14
  );
}
async function _0x420caa(_0xee778b) {
  var _0x22f6f1 = !0x1,
    _0x403d83 = !0x1,
    { includeCurrencyConversion: _0x403d83 } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x22f6f1 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x2c7db8 =
    0.1325 * _0xee778b +
    0.021 * _0xee778b +
    _0xee778b * (_0x22f6f1 ? 0.004 : 0x0) +
    0.4;
  return (_0x403d83 && (_0x2c7db8 += 0.035 * _0xee778b), _0xee778b - _0x2c7db8);
}
async function _0x4616c0(_0x2d53dc) {
  var { isInternational: _0x5ea831 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x2273b7 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x5ea831 || (_0x5ea831 = !0x1), _0x2273b7 || (_0x2273b7 = !0x0));
  var _0x18095e = 13.25;
  _0x2273b7 && (_0x18095e = 12.35);
  var _0x1c2c5e = _0x2d53dc + 0.0725 * _0x2d53dc,
    _0x43021e =
      _0x1c2c5e * (_0x18095e / 0x64) +
      0.4 +
      (_0x5ea831 ? 0.004 * _0x1c2c5e : 0x0),
    _0x5563d0 =
      _0x2d53dc -
      (_0x43021e + (_0x5ea831 ? 0.05 * _0x43021e : 0x0)) -
      (_0x5ea831 ? 0.035 * _0x1c2c5e : 0x0),
    { isUserTaxExempt: _0x4de624 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x4de624 || (_0x4de624 = !0x1),
    _0x4de624 || (_0x5563d0 /= 1.0725),
    _0x5ea831 && (_0x5563d0 -= (3.5 * _0x5563d0) / 0x64),
    _0x5563d0
  );
}
function _0x462169(_0x127993 = null) {
  console["log"]("createButtonToSaveSeller", _0x127993);
  var _0x2a5886 = document["createElement"]("a");
  (_0x2a5886["setAttribute"]("id", "saveSellerLink"),
    _0x2a5886["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x2a5886["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x17eed6 = document["createElement"]("img");
  return (
    _0x17eed6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x17eed6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2a5886["appendChild"](_0x17eed6),
    _0x2a5886["addEventListener"]("click", async function (_0x4d53bf) {
      (_0x4d53bf["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x127993));
      var _0x2eb324;
      if (!_0x127993) {
        var _0x1effc2 = _0x172c34(_0x4d53bf);
        if (!_0x1effc2) return;
        var _0x2f999c = extractItemData(_0x1effc2);
        ((_0x127993 = _0x2f999c["username"]),
          (_0x2eb324 = _0x2f999c["itemNumber"]));
      }
      if (
        _0x127993["includes"]("\x20") ||
        _0x127993 !== _0x127993["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x127993,
        ),
          (_0x127993 = await _0x5a051e(_0x2eb324)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x127993,
          ));
      else _0x127993 = _0x127993["toLowerCase"]();
      _0x2a5886["setAttribute"]("data-seller-name", _0x127993);
      var { ebayCompetitors: _0x4ebf72 } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x1990b2 = (_0x4ebf72 = _0x4ebf72 || [])["indexOf"](_0x127993);
      console["log"]("ebayCompetitors", _0x4ebf72);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x1990b2
            ? (console["log"]("save-seller\x20clicked\x20username", _0x127993),
              _0x4ebf72["push"](_0x127993),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x17eed6["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x127993,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x17eed6["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x1990b2)
            (console["log"]("remove-seller\x20clicked\x20username", _0x127993),
              _0x4ebf72["splice"](_0x1990b2, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x17eed6["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x127993,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x4ebf72 });
    }),
    _0x2a5886
  );
}
async function _0x4bfae2(_0x211b9d, _0x2cf135) {
  var { ebayCompetitors: _0x5df470 } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x3fdeb6 = (_0x5df470 = _0x5df470 || [])["indexOf"](_0x2cf135),
    _0x407b79 = _0x211b9d["querySelector"]("img");
  -0x1 !== _0x3fdeb6
    ? (_0x211b9d["classList"]["replace"]("save-seller", "remove-seller"),
      _0x407b79["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x211b9d["classList"]["replace"]("remove-seller", "save-seller"),
      _0x407b79["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x5e5e13(
  _0x5cbcf5 = null,
  _0x342cbf = null,
  _0x22ae62 = null,
  _0x1a9c08 = !0x0,
  _0x39e380 = null,
  _0x571b01 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x5cbcf5));
  var _0x1f2398 = _0x462169(_0x342cbf),
    _0x965da4 = _0x4b7ddb(_0x5cbcf5),
    _0x4ce7c3 = _0x572fe1(_0x39e380),
    _0x5615f5 = _0x3bf6ce(_0x5cbcf5),
    _0x103209 = _0x526f09(_0x5cbcf5, _0x571b01, _0x39e380, _0x22ae62),
    _0x4cbb93 = _0x3bf6ce(
      _0x5cbcf5,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x23b0da = _0x47b3af(_0x22ae62),
    _0x12648d = _0x80f3e4(_0x39e380),
    _0x9046e9 = _0x3ed96b(_0x342cbf),
    _0x1a0984 = document["createElement"]("div");
  _0x1a0984["setAttribute"]("id", "search-div");
  var _0x4768cd = document["createElement"]("label");
  ((_0x4768cd["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x1a0984["appendChild"](_0x4768cd),
    _0x1a0984["appendChild"](_0x103209),
    _0x1a0984["appendChild"](_0x5615f5),
    _0x1a0984["appendChild"](_0x965da4),
    _0x1a0984["appendChild"](_0x23b0da),
    _0x1a0984["appendChild"](_0x12648d),
    _0x1a0984["appendChild"](_0x4cbb93),
    console["log"]("CopyDataButton", _0x5cbcf5, _0x571b01, _0x39e380));
  var _0x267d31 = _0x3383ca(_0x5cbcf5, _0x571b01, _0x39e380),
    _0x254f9d = document["createElement"]("div");
  _0x254f9d["setAttribute"]("id", "item-buttons-div");
  var _0x43fa0e = document["createElement"]("div");
  (_0x43fa0e["setAttribute"]("id", "main-buttons-div"),
    _0x43fa0e["appendChild"](_0x9046e9),
    _0x43fa0e["appendChild"](_0x4ce7c3),
    _0x43fa0e["appendChild"](_0x267d31),
    _0x43fa0e["appendChild"](_0x1f2398),
    _0x254f9d["appendChild"](_0x43fa0e));
  if (_0x1a9c08) {
    var _0x5a6db4 = createButtonListToEbay();
    _0x254f9d["appendChild"](_0x5a6db4);
  }
  return (_0x254f9d["appendChild"](_0x1a0984), _0x254f9d);
}
var _0x53a950 = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x53f157) => {
        (console["log"](
          _0x53f157,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x53a950, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x541d0c) => {
        (console["log"](
          _0x541d0c,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x53a950, "search-type", "keywords"));
      },
    },
  },
];
async function _0x212942() {
  var { convertToKeywords: _0x31cefa } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x31cefa &&
    ((_0x31cefa = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x53a950,
      "search-type",
      _0x31cefa ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x53a950 })[
      "init"
    ]());
}
var _0x379f14 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x58c404) => {
        (console["log"](_0x58c404, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x379f14, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x4a2dfc) => {
        (console["log"](_0x4a2dfc, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x379f14, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x348843) => {
        (console["log"](
          _0x348843,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x379f14, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x2e68cd) => {
        (console["log"](
          _0x2e68cd,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x379f14, "search-type", "keywords"));
      },
    },
  },
];
async function _0x16372f() {
  var { amazonSortType: _0xe13ef4 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0xc868f5 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0xc868f5 &&
    ((_0xc868f5 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0xe13ef4 &&
      ((_0xe13ef4 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x379f14, "sort-type", _0xe13ef4),
    updateContextMenu(_0x379f14, "search-type", _0xc868f5),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x379f14 })[
      "init"
    ]());
}
_0x379f14 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x59f33e) => {
        (console["log"](_0x59f33e, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x379f14, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x190b06) => {
        (console["log"](_0x190b06, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x379f14, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0xd84832 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x962655) => {
        (console["log"](_0x962655, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0xd84832, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x39d22f) => {
        (console["log"](_0x39d22f, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0xd84832, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2cb77) => {
        (console["log"](_0x2cb77, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0xd84832, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x57786b) => {
        (console["log"](_0x57786b, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0xd84832, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2b2f05) => {
        (console["log"](_0x2b2f05, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0xd84832, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x1d32a7) => {
        (console["log"](_0x1d32a7, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0xd84832, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x14b272) => {
        (console["log"](_0x14b272, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0xd84832, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x59c8ca) => {
        (console["log"](_0x59c8ca, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0xd84832, "filter-type", "90"));
      },
    },
  },
];
async function _0x2691b5() {
  var { selectedFilter: _0x5af031 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x5af031 &&
    ((_0x5af031 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0xd84832, "filter-type", _0x5af031),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0xd84832 })[
      "init"
    ]());
}
function _0x2c401e() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x1ba35c() {
  const _0x1746dc = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x4d0636 = 0x0;
  const _0x5c95a2 = () =>
    new Promise((_0x2e5282, _0x5526cd) => {
      const _0x5cbe06 = new MutationObserver((_0x1ee673, _0x2f044f) => {
        const _0x1cecf7 = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x1cecf7 &&
          (console["log"]("Details\x20form\x20found!"),
          _0x2f044f["disconnect"](),
          _0x2e5282(_0x1cecf7));
      });
      (_0x5cbe06["observe"](_0x1746dc, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x5cbe06["disconnect"]();
          if (_0x4d0636 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x4d0636 + 0x1) +
                "/3)",
            ),
              _0x4d0636++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x2e5282(_0x5c95a2()), 0x1388));
          else
            _0x5526cd(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x10b4f3 = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x10b4f3) {
    (_0x10b4f3["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x5c95a2(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x1bdf85) {
      console["error"](_0x1bdf85["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0xa3ab9(_0x2df3b3 = null, _0x3891c1 = null, _0x17a902 = null) {
  var _0xe751be = document["createElement"]("a");
  (_0xe751be["setAttribute"]("id", "copyDataLink"),
    _0xe751be["setAttribute"]("class", "a-link-text"),
    _0xe751be["classList"]["add"]("icon"),
    _0xe751be["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0xe44fa8 = document["createElement"]("img");
  return (
    _0xe44fa8["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0xe44fa8["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xe751be["appendChild"](_0xe44fa8),
    _0xe751be["addEventListener"]("click", async function (_0x5993ee) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x2df3b3,
        _0x3891c1,
        _0x17a902,
      ),
        _0x5993ee["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x2df3b3 && _0x3891c1 && _0x17a902) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x2df3b3,
          _0x3891c1,
          _0x17a902,
        );
        isNaN(_0x3891c1) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x3891c1),
          (_0x3891c1 = _0x3891c1["replace"](/[^0-9.]/g, "")));
        var _0x1d2afa = JSON["stringify"]({
          title: _0x2df3b3,
          price: _0x3891c1,
          itemNumber: _0x17a902,
        });
        (_0x30f3f0(
          (_0x3432d2 = await findSimiliarProducts(_0x1d2afa))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x3432d2),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x2df3b3 || !_0x3891c1 || !_0x17a902) {
          var _0x3700ad = _0x172c34(_0x5993ee);
          if (!_0x3700ad) return;
        }
        var _0x1bd265 = extractItemData(_0x3700ad);
        (console["log"]("itemData", _0x1bd265),
          (_0x1d2afa = JSON["stringify"](_0x1bd265)));
        var _0x3432d2;
        (_0x30f3f0(
          (_0x3432d2 = await findSimiliarProducts(_0x1d2afa))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x3432d2),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0xe751be
  );
}
async function findSimiliarProducts(_0x1aa2c9) {
  console["log"]("findSimiliarProducts", _0x1aa2c9);
  var _0x1022f1 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x1aa2c9,
  });
  return (console["log"]("response", _0x1022f1), _0x1022f1["productLinks"]);
}
function _0x30f3f0(_0x4c81e2) {
  const _0xc598ab = document["getElementById"]("productLinksModalOverlay");
  _0xc598ab && _0xc598ab["remove"]();
  const _0xb23a6c = document["createElement"]("div");
  ((_0xb23a6c["id"] = "productLinksModalOverlay"),
    _0xb23a6c["classList"]["add"]("product-links-modal-overlay"));
  const _0x5a9cc2 = document["createElement"]("div");
  _0x5a9cc2["classList"]["add"]("product-links-modal");
  const _0xa85df3 = document["createElement"]("div");
  _0xa85df3["classList"]["add"]("modal-button-container");
  const _0x4c1113 = document["createElement"]("button");
  (_0x4c1113["classList"]["add"]("close-button"),
    (_0x4c1113["innerText"] = "Close"),
    _0x4c1113["addEventListener"]("click", () => {
      _0xb23a6c["remove"]();
    }));
  const _0x496efd = document["createElement"]("button");
  (_0x496efd["classList"]["add"]("copy-button"),
    (_0x496efd["innerText"] = "Copy"),
    _0x496efd["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x4c81e2),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x13a297) {
        console["error"]("Failed\x20to\x20copy:", _0x13a297);
      }
    }));
  const _0x36b4f4 = document["createElement"]("h2");
  _0x36b4f4["innerText"] = "Similar\x20Product\x20Links";
  const _0x1c7319 = document["createElement"]("textarea");
  ((_0x1c7319["value"] = _0x4c81e2),
    _0x1c7319["setAttribute"]("readonly", !0x0),
    (_0x1c7319["style"]["width"] = "100%"),
    (_0x1c7319["style"]["height"] = "300px"),
    _0xa85df3["appendChild"](_0x496efd),
    _0xa85df3["appendChild"](_0x4c1113),
    _0x5a9cc2["appendChild"](_0xa85df3),
    _0x5a9cc2["appendChild"](_0x36b4f4),
    _0x5a9cc2["appendChild"](_0x1c7319),
    _0xb23a6c["appendChild"](_0x5a9cc2),
    document["body"]["appendChild"](_0xb23a6c));
}
async function _0x5167fd(_0xca8286) {
  var { domain: _0x1654fa } = await chrome["storage"]["local"]["get"]("domain");
  try {
    const _0x288f94 = await fetch(
        "https://poshmark." + _0x1654fa + "/edit-listing/" + _0xca8286,
        { credentials: "include" },
      ),
      _0x4e44fc = (await _0x288f94["text"]())["match"](/"sku":\s*"([^"]+)"/);
    if (!_0x4e44fc) {
      console["error"]("SKU\x20not\x20found\x20in\x20response");
      return;
    }
    return _0x4e44fc[0x1];
  } catch (_0x197ff1) {
    console["error"]("Error\x20fetching\x20SKU:", _0x197ff1);
  }
}
async function _0xf8aba3(_0x15c617, _0x563aa3 = {}) {
  const {
      available: _0x25b173,
      price: _0x349f76,
      originalPrice: _0x3acd2b,
      region: region = "us",
    } = _0x563aa3,
    _0x2a6f99 = "ca" === region ? "poshmark.ca" : "poshmark.com",
    _0x1a6a66 = "ca" === region ? "CAD" : "USD",
    _0x1f1265 =
      "https://" +
      _0x2a6f99 +
      "/vm-rest/posts/" +
      _0x15c617 +
      "?pm_version=2025.37.1";
  var _0x4fbeef = { post: {} };
  _0x563aa3["hasOwnProperty"]("available") &&
    (_0x4fbeef["post"]["inventory"] = {
      status: _0x25b173 ? "available" : "not_for_sale",
    });
  "number" == typeof _0x349f76 &&
    ((_0x4fbeef["post"]["price_amount"] = {
      val: _0x349f76["toFixed"](0x2),
      currency_code: _0x1a6a66,
    }),
    _0x563aa3["hasOwnProperty"]("originalPrice") ||
      (_0x4fbeef["post"]["original_price_amount"] = {
        val: (1.5 * _0x349f76)["toFixed"](0x2),
        currency_code: _0x1a6a66,
      }));
  ("number" == typeof _0x3acd2b &&
    (_0x4fbeef["post"]["original_price_amount"] = {
      val: _0x3acd2b["toFixed"](0x2),
      currency_code: _0x1a6a66,
    }),
    _0x563aa3["hasOwnProperty"]("set_offers") &&
      (_0x4fbeef["post"]["offer_auto_actions_v2_enabled"] =
        !!_0x563aa3["set_offers"]),
    _0x563aa3["hasOwnProperty"]("min_offer") &&
      (_0x4fbeef["post"]["offer_auto_actions_min_price_amount"] = {
        val: _0x563aa3["min_offer"],
        currency_code: _0x1a6a66,
      }),
    console["log"](
      "Updating\x20listing\x20[" + _0x15c617 + "@" + _0x2a6f99 + "]\x20with:",
      _0x4fbeef,
    ));
  if (0x0 === Object["keys"](_0x4fbeef["post"])["length"])
    return (
      console["warn"](
        "[" +
          _0x15c617 +
          "]\x20No\x20update\x20options\x20specified—skipping\x20request.",
      ),
      Promise["resolve"]()
    );
  return (
    console["log"]("postData:", _0x4fbeef),
    fetch(_0x1f1265, {
      method: "POST",
      credentials: "include",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON["stringify"](_0x4fbeef),
    })
      ["then"]((_0x593e9c) => {
        if (!_0x593e9c["ok"]) throw new Error("HTTP\x20" + _0x593e9c["status"]);
        return _0x593e9c["json"]();
      })
      ["then"]((_0x414765) => {
        return (
          console["log"](
            "✅\x20[" + _0x15c617 + "@" + _0x2a6f99 + "]\x20updated:",
            _0x4fbeef["post"],
            _0x414765,
          ),
          _0x414765
        );
      })
      ["catch"]((_0x2e7328) => {
        console["error"](
          "❌\x20[" + _0x15c617 + "@" + _0x2a6f99 + "]\x20update\x20failed:",
          _0x2e7328,
        );
        throw _0x2e7328;
      })
  );
}
function fetchProductData(
  _0x523a5f,
  _0x515223 = "https://www.amazon.com/dp/" + atob(_0x523a5f) + "?th=1&psc=1",
) {
  return (
    console["log"](
      "fetchProductData\x20called\x20with\x20cl:",
      _0x523a5f,
      "and\x20url:",
      _0x515223,
    ),
    new Promise((_0x1fee6d, _0x21485d) => {
      chrome["runtime"]["sendMessage"](
        {
          type: "fetch_product_data",
          supplier: "amazon",
          customLabel: _0x523a5f,
          itemUrl: _0x515223,
        },
        (_0x56c838) => {
          if (chrome["runtime"]["lastError"])
            return _0x21485d(chrome["runtime"]["lastError"]);
          if (!_0x56c838 || _0x56c838["error"])
            return _0x21485d(
              new Error(_0x56c838?.["error"] || "Unknown\x20error"),
            );
          _0x1fee6d(_0x56c838["productData"] || {});
        },
      );
    })
  );
}
async function _0x42dadf(_0x4e9d2c, _0x23c752 = {}) {
  const {
    minPrice: _0x1877be,
    currency: currency = "USD",
    region: region = "us",
    userId: _0x58fb8c,
    pmVersion: pmVersion = "2025.37.1",
  } = _0x23c752;
  if (!_0x58fb8c)
    throw new Error("previewOfferEarnings\x20requires\x20opts.userId");
  if (null == _0x1877be)
    throw new Error("previewOfferEarnings\x20requires\x20opts.minPrice");
  const _0x515d66 =
    "https://" +
    ("ca" === region ? "poshmark.ca" : "poshmark.com") +
    "/vm-rest/users/" +
    _0x58fb8c +
    "/seller_earnings/post?" +
    new URLSearchParams({
      price_amount: JSON["stringify"]({
        val: String(_0x1877be),
        currency_code: currency,
      }),
      object_id: _0x4e9d2c,
      pm_version: pmVersion,
    })["toString"]();
  console["log"]("Fetching\x20earnings\x20preview\x20from:", _0x515d66);
  const _0x152627 = await fetch(_0x515d66, {
    method: "GET",
    credentials: "include",
    headers: {
      Accept: "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!_0x152627["ok"])
    throw new Error(
      "previewOfferEarnings\x20failed:\x20HTTP\x20" + _0x152627["status"],
    );
  const _0x44ea29 = await _0x152627["json"]();
  return (
    console["log"](
      "💡\x20Earnings\x20preview\x20for\x20post\x20" + _0x4e9d2c + ":",
      _0x44ea29,
    ),
    _0x44ea29
  );
}
function _0x59ec7d() {
  const _0x4c7c23 = document["querySelectorAll"]("a[href^=\x22/listing/\x22]");
  for (let _0x35efce of _0x4c7c23) {
    const _0x39b283 = _0x35efce["getAttribute"]("href")["match"](/-(\w{24})$/);
    if (_0x39b283) {
      const _0x538899 = _0x39b283[0x1];
      return (console["log"]("Listing\x20ID:", _0x538899), _0x538899);
    }
  }
  return (console["warn"]("No\x20listing\x20ID\x20found."), null);
}
function _0x625a84() {
  const _0x5c575f = window["location"]["pathname"]["match"](
    /\/listing\/.*-(\w{24})$/,
  );
  if (_0x5c575f) {
    const _0x1d530f = _0x5c575f[0x1];
    return (
      console["log"]("Listing\x20ID\x20from\x20URL:", _0x1d530f),
      _0x1d530f
    );
  }
  return (console["warn"]("No\x20listing\x20ID\x20found\x20in\x20URL."), null);
}
function _0x5c623d() {
  var _0x47f769 = _0x59ec7d();
  return (_0x47f769 || (_0x47f769 = _0x625a84()), _0x47f769);
}
async function _0x192247() {
  var _0x435672 = _0x5c623d(),
    _0x20ebd6 = await _0x5167fd(_0x435672);
  return atob(_0x20ebd6);
}
async function _0x1b2a55() {
  var _0x483e4c = await _0x192247();
  if (!_0x483e4c) throw new Error("ASIN\x20not\x20found");
  const { domain: _0x58c290 } =
      await chrome["storage"]["local"]["get"]("domain"),
    _0x1b485c =
      "https://www.amazon." + _0x58c290 + "/dp/" + _0x483e4c + "?th=1&psc=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x1b485c });
}
console["log"]("Poshmark\x20Bundles\x20Functions\x20Loaded");
function _0x2c8264() {
  return document["querySelectorAll"](".bundle-item\x20li");
}
function _0x3f31a2(_0x3c3252) {
  var _0x29d6ca,
    _0x22e39e = _0x3c3252["querySelector"]("a")?.["getAttribute"]("href");
  return (
    _0x22e39e &&
      (_0x29d6ca = (_0x29d6ca = _0x22e39e["split"]("-")["pop"]())["trim"]()),
    { itemId: _0x29d6ca }
  );
}
function _0xd36698() {
  _0x2c8264()["forEach"]((_0x64093) => {
    const _0x203c7a = _0x43e0ce(_0x1b2a55);
    (console["log"]("Adding\x20button\x20to\x20item:", _0x64093),
      _0x64093?.["appendChild"](_0x203c7a));
  });
}
async function _0x1b2a55(_0x15f2ff) {
  _0x15f2ff["preventDefault"]();
  try {
    var _0x256698 = _0x15f2ff["target"]["closest"](".bundle-item\x20li");
    if (!_0x256698) {
      console["error"]("Item\x20not\x20found");
      return;
    }
    var { itemId: _0x25c1bb } = _0x3f31a2(_0x256698);
    if (!_0x25c1bb) {
      console["error"]("Item\x20ID\x20not\x20found");
      return;
    }
    const _0x1a992d = await _0x5167fd(_0x25c1bb);
    if (!_0x1a992d) throw new Error("Poshmark\x20SKU\x20not\x20found");
    var _0x2e7770 = atob(_0x1a992d);
    const { domain: _0x3b40d8 } =
        await chrome["storage"]["local"]["get"]("domain"),
      _0x2aa35f =
        "https://www.amazon." + _0x3b40d8 + "/dp/" + _0x2e7770 + "?th=1&psc=1";
    chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x2aa35f });
  } catch (_0x51953e) {
    console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x51953e);
  }
}
console["log"]("Poshmark\x20Bundles\x20Content\x20Script\x20Loaded");
async function _0x2cc237() {
  (await _0x3f8570(),
    console["log"]("Page\x20loaded\x20and\x20stable,\x20adding\x20buttons..."),
    _0xd36698());
}
_0x2cc237();
