console["log"](
  "content/amazon/auto_order/order_history/functions.js\x20loaded",
);
function findOrderContainerWithName(_0x4758d1) {
  console["log"]("Searching\x20for\x20order\x20with\x20name:", _0x4758d1);
  var _0x3151e9 = document["querySelectorAll"](".order-card");
  for (var _0x3d9967 = 0x0; _0x3d9967 < _0x3151e9["length"]; _0x3d9967++) {
    var _0x3d48ef = _0x3151e9[_0x3d9967];
    console["log"](
      "Order\x20container\x20inner\x20text:",
      _0x3d48ef["innerText"],
    );
    if (_0x3d48ef["innerText"]["includes"](_0x4758d1)) return _0x3d48ef;
  }
  return null;
}
function _0x31a112(_0x398fc6) {
  var _0x135b50 = _0x398fc6["querySelector"](
    "a[href*=\x22/order-details?\x22]",
  );
  _0x135b50
    ? _0x135b50["click"]()
    : console["log"](
        "View\x20Order\x20Details\x20button\x20not\x20found\x20in\x20the\x20order\x20container.",
      );
}
(console["log"]("content/amazon/auto_order/order_history/content.js\x20loaded"),
  chrome["runtime"]["onMessage"]["addListener"](
    function (_0x132e89, _0x4ec228, _0x74425d) {
      "autoOrder" === _0x132e89["type"] &&
        "navigate_to_order_details" === _0x132e89["action"] &&
        (console["log"](
          "Received\x20request\x20to\x20get\x20order\x20history:",
          _0x132e89["orderDetails"],
        ),
        _0x4d1fda(_0x132e89["orderDetails"]));
    },
  ));
async function _0x4d1fda(_0x1b1ff5) {
  var _0x1695e6 = findOrderContainerWithName(_0x1b1ff5["customer"]["name"]);
  if (_0x1695e6)
    (console["log"]("Order\x20container\x20found:", _0x1695e6),
      _0x31a112(_0x1695e6));
  else
    console["log"](
      "No\x20order\x20container\x20found\x20with\x20the\x20specified\x20name.",
    );
}
