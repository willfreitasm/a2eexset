function _0x3445b6() {
  return new Promise((_0x3423eb) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x3423eb();
      });
    });
  });
}
function _0x28426e() {
  return new Promise((_0x46b913) => {
    requestIdleCallback(() => {
      _0x46b913();
    });
  });
}
function _0x4873a8(_0x5ad89f = 0x3e8) {
  return new Promise((_0x146f3e, _0x2b30f5) => {
    let _0x345eee,
      _0xd5fb44 = Date["now"](),
      _0x3e56f7 = !0x1;
    function _0x192ba5() {
      if (Date["now"]() - _0xd5fb44 > _0x5ad89f)
        (_0x3e56f7 && _0x345eee["disconnect"](), _0x146f3e());
      else setTimeout(_0x192ba5, _0x5ad89f);
    }
    const _0xf70e95 = () => {
        _0xd5fb44 = Date["now"]();
      },
      _0x506a9d = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x345eee = new MutationObserver(_0xf70e95)),
        _0x345eee["observe"](document["body"], _0x506a9d),
        (_0x3e56f7 = !0x0),
        setTimeout(_0x192ba5, _0x5ad89f));
    else
      window["onload"] = () => {
        ((_0x345eee = new MutationObserver(_0xf70e95)),
          _0x345eee["observe"](document["body"], _0x506a9d),
          (_0x3e56f7 = !0x0),
          setTimeout(_0x192ba5, _0x5ad89f));
      };
  });
}
async function _0x3c7a4b() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x4873a8(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x15900c(
  _0x234aba = null,
  _0x1ca724 = null,
  _0x4af286 = null,
  _0x48fd68 = null,
) {
  var _0xed6e2e = document["createElement"]("a");
  (_0xed6e2e["setAttribute"]("class", "a-link-text"),
    _0xed6e2e["classList"]["add"]("icon"),
    _0xed6e2e["classList"]["add"]("amazonSearchLink"),
    _0xed6e2e["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0xd8b6f4 = document["createElement"]("img");
  return (
    _0xd8b6f4["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0xd8b6f4["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xed6e2e["appendChild"](_0xd8b6f4),
    _0xed6e2e["addEventListener"]("click", async function (_0x11f410) {
      (_0x11f410["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x234aba) {
        var _0x1a3d66 = _0x250696(_0x11f410);
        if (!_0x1a3d66) return;
        var _0x713913 = extractItemData(_0x1a3d66);
        ((_0x234aba = _0x713913["title"])["endsWith"]("...") &&
          (_0x234aba = _0x234aba["substring"](
            0x0,
            _0x234aba["lastIndexOf"]("\x20"),
          )),
          _0x234aba["length"] > 0x4b &&
            (_0x234aba = _0x234aba["substring"](
              0x0,
              _0x234aba["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x40a25e } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x40a25e),
        _0x40a25e || (_0x40a25e = "reviews"),
        console["log"]("amazonSortType", _0x40a25e),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0xd1df39 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x234aba["length"] > 0x50; )
        _0x234aba = _0x234aba["substring"](
          0x0,
          _0x234aba["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x518466 } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0xc6c427 = _0x234aba;
      "keywords" == _0x518466 && (_0xc6c427 = await _0x4f39f5(_0x234aba));
      try {
        _0x713913 = extractItemData(_0x1a3d66);
      } catch (_0x432725) {
        console["log"]("error", _0x432725);
      }
      (_0x713913 ||
        (_0x713913 = {
          title: _0x234aba,
          price: _0x1ca724,
          itemNumber: _0x4af286,
          image: _0x48fd68,
        }),
        console["log"]("itemData", _0x713913),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0xc6c427,
          options: { isTabActive: !0x0, sort: _0x40a25e },
          itemData: _0x713913,
        }));
    }),
    _0xed6e2e
  );
}
function _0x1788a5(_0x39d429) {
  var _0x1dfa16 = document["createElement"]("a");
  (_0x1dfa16["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x1dfa16["setAttribute"]("class", "a-link-text"),
    _0x1dfa16["classList"]["add"]("icon"),
    _0x1dfa16["classList"]["add"]("amazonSearchLink"),
    _0x1dfa16["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x54fa90 = document["createElement"]("img");
  return (
    _0x54fa90["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x54fa90["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1dfa16["appendChild"](_0x54fa90),
    _0x1dfa16["addEventListener"]("click", async function (_0x1d2d9f) {
      (_0x1d2d9f["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x39d429),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x39d429,
        }));
    }),
    _0x1dfa16
  );
}
function _0x3c56f3(_0x12459d) {
  var _0x193034 = document["createElement"]("a");
  (_0x193034["setAttribute"]("id", "amazonLink"),
    _0x193034["setAttribute"]("class", "a-link-text"),
    _0x193034["classList"]["add"]("icon"),
    _0x193034["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x4bb142 = document["createElement"]("img");
  return (
    _0x4bb142["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4bb142["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x193034["appendChild"](_0x4bb142),
    _0x193034["addEventListener"]("click", async function (_0x4a3e35) {
      (_0x4a3e35["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x76937 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0xedb239 =
          "https://www.amazon." + _0x76937 + "/dp/" + _0x12459d + "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0xedb239 });
    }),
    _0x193034
  );
}
function _0x1d5318(_0x27eb68) {
  var _0x1d4e6e = document["createElement"]("a");
  (_0x1d4e6e["setAttribute"]("id", "amazonLink"),
    _0x1d4e6e["setAttribute"]("class", "a-link-text"),
    _0x1d4e6e["classList"]["add"]("icon"),
    _0x1d4e6e["classList"]["add"]("amazonLink"),
    _0x1d4e6e["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x3738ab = document["createElement"]("img");
  return (
    _0x3738ab["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x3738ab["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1d4e6e["appendChild"](_0x3738ab),
    _0x1d4e6e["addEventListener"]("click", async function (_0xa0c9da) {
      (_0xa0c9da["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x27eb68(_0xa0c9da);
      } catch (_0x280345) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x280345);
      }
    }),
    _0x1d4e6e
  );
}
function _0x2764e4(
  _0x3c5d45 = null,
  _0x3c5d2e,
  _0xaeb5be = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x3c5d45, _0x3c5d2e);
  var _0x2a8e57 = document["createElement"]("a");
  (_0x2a8e57["setAttribute"]("id", "ebayLink"),
    _0x2a8e57["setAttribute"]("class", "a-link-text"),
    _0x2a8e57["classList"]["add"]("icon"),
    _0x3c5d2e && _0x3c5d2e["soldItems"]
      ? _0x2a8e57["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x2a8e57["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x277eff = document["createElement"]("img");
  return (
    _0x277eff["setAttribute"]("src", chrome["runtime"]["getURL"](_0xaeb5be)),
    _0x277eff["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2a8e57["appendChild"](_0x277eff),
    _0x2a8e57["addEventListener"]("click", async function (_0x29e27b) {
      (_0x29e27b["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x3c5d45) console["log"]("title\x20found", _0x3c5d45);
      else {
        console["log"]("title\x20not\x20found");
        var _0x1cd049 = _0x250696(_0x29e27b);
        if (!_0x1cd049) return;
        var _0x161a71 = extractItemData(_0x1cd049);
        _0x3c5d45 = _0x161a71["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x3e86ad } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x3c5d45["length"] > 0x50; )
        _0x3c5d45 = _0x3c5d45["substring"](
          0x0,
          _0x3c5d45["lastIndexOf"]("\x20"),
        );
      var _0xd23719 =
        "https://www.ebay." +
        _0x3e86ad +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x3c5d45) +
        "&_odkw=" +
        encodeURIComponent(_0x3c5d45);
      (_0x3c5d2e && _0x3c5d2e["soldItems"] && (_0xd23719 += "&LH_Sold=1"),
        _0x3c5d2e && _0x3c5d2e["sortLowToHigh"] && (_0xd23719 += "&_sop=15"),
        _0x3c5d2e && _0x3c5d2e["endedRecently"] && (_0xd23719 += "&_sop=13"),
        (_0xd23719 += "&LH_ItemCondition=1000"),
        (_0xd23719 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0xd23719,
        }));
    }),
    _0x2a8e57
  );
}
function _0x119b2e(_0x750bf3 = null) {
  var _0x9ec243 = document["createElement"]("a");
  (_0x9ec243["setAttribute"]("id", "googleLink"),
    _0x9ec243["setAttribute"]("class", "a-link-text"),
    _0x9ec243["classList"]["add"]("icon"),
    _0x9ec243["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x1686a5 = document["createElement"]("img");
  return (
    _0x1686a5["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x1686a5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x9ec243["appendChild"](_0x1686a5),
    _0x9ec243["addEventListener"]("click", async function (_0x361645) {
      (_0x361645["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x750bf3) {
        var _0x11f999 = _0x250696(_0x361645);
        if (!_0x11f999) return;
        var _0x17a972 = extractItemData(_0x11f999);
        _0x750bf3 = _0x17a972["image"];
      }
      var { domain: _0x5db6fa } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x443909(_0x5db6fa),
        encodeURIComponent(_0x750bf3),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x750bf3,
        }));
    }),
    _0x9ec243
  );
}
function _0x7c9975(_0x154cc2 = null) {
  var _0x3a7f0c = document["createElement"]("a");
  (_0x3a7f0c["setAttribute"]("id", "googleLink"),
    _0x3a7f0c["setAttribute"]("class", "a-link-text"),
    _0x3a7f0c["classList"]["add"]("icon"),
    _0x3a7f0c["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x401d52 = document["createElement"]("img");
  return (
    _0x401d52["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x401d52["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3a7f0c["appendChild"](_0x401d52),
    _0x3a7f0c["addEventListener"]("click", async function (_0x5704ee) {
      (_0x5704ee["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x154cc2) {
        var _0x5911d1 = _0x250696(_0x5704ee);
        if (!_0x5911d1) return;
        var _0x42815e = extractItemData(_0x5911d1);
        _0x154cc2 = _0x42815e["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x154cc2,
      });
    }),
    _0x3a7f0c
  );
}
function _0x1f626d(_0x594936) {
  var _0x546b08 = document["createElement"]("a");
  (_0x546b08["setAttribute"]("id", "lookUpSkuLink"),
    _0x546b08["setAttribute"]("class", "a-link-text"),
    _0x546b08["classList"]["add"]("icon"),
    _0x546b08["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x579bab = document["createElement"]("img");
  return (
    _0x579bab["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x579bab["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x546b08["appendChild"](_0x579bab),
    _0x546b08["addEventListener"]("click", async function (_0x402e92) {
      (_0x402e92["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x332d82 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x4685ea =
          "https://www.amazon." +
          _0x332d82 +
          "/dp/" +
          _0x594936 +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x4685ea,
        options: { active: !0x0 },
      });
    }),
    _0x546b08
  );
}
function _0x30f2c8(_0x2334bb = null) {
  var _0x24b5ae = document["createElement"]("a");
  (_0x24b5ae["setAttribute"]("id", "productHunterLink"),
    _0x24b5ae["setAttribute"]("class", "a-link-text"),
    _0x24b5ae["classList"]["add"]("icon"),
    _0x24b5ae["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x27ded0 = document["createElement"]("img");
  return (
    _0x27ded0["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x27ded0["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x24b5ae["appendChild"](_0x27ded0),
    _0x24b5ae["addEventListener"]("click", async function (_0x2ea935) {
      (_0x2ea935["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x2334bb) {
        var _0x6f16b6 = _0x250696(_0x2ea935);
        if (!_0x6f16b6) return;
        var _0x589e80 = extractItemData(_0x6f16b6);
        _0x2334bb = _0x589e80["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x2334bb),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x2334bb,
        }));
    }),
    _0x24b5ae
  );
}
function _0x443909(_0x5169b8) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x5169b8] || "en-US";
}
function _0x3e824e(_0x338044 = null) {
  console["log"]("createSearchTerapeakButton", _0x338044);
  var _0x4f1147 = document["createElement"]("a");
  (_0x4f1147["setAttribute"]("class", "a-link-text"),
    _0x4f1147["classList"]["add"]("terapeakLink"),
    _0x4f1147["classList"]["add"]("icon"),
    _0x4f1147["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x338044 && _0x4f1147["setAttribute"]("item_title", _0x338044));
  var _0x1c8d64 = document["createElement"]("img");
  return (
    _0x1c8d64["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x1c8d64["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4f1147["appendChild"](_0x1c8d64),
    _0x4f1147["addEventListener"]("click", async function (_0x35a3df) {
      (_0x35a3df["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x14c769 = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x14c769),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x14c769) {
        var _0x34b023 = _0x250696(_0x35a3df);
        if (!_0x34b023) return;
        _0x14c769 = extractItemData(_0x34b023)["title"];
      }
      console["log"]("title", _0x14c769);
      var { convertToKeywords: _0xe9b25f } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0xe9b25f) var _0x14c769 = await _0x4f39f5(_0x14c769);
      var { domain: _0x403aca } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x150ef8 = _0x244e83(_0x14c769, _0x403aca);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x150ef8 });
    }),
    _0x4f1147
  );
}
async function _0x4f39f5(_0x16d66d) {
  var _0x1ae80f = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x56b7eb) => _0x56b7eb["json"]());
  ((_0x1ae80f["user_input"] = _0x16d66d),
    console["log"]("jsonPrompt", _0x1ae80f));
  var _0x234aa2 = await new Promise((_0x581b5b, _0x36f4c1) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x1ae80f,
      },
      function (_0x38eb70) {
        _0x581b5b(_0x38eb70["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x234aa2),
    (_0x234aa2 = JSON["parse"](_0x234aa2))["output"]
  );
}
function _0x244e83(
  _0x4929fe,
  _0x4fc574 = "ca",
  _0x5391c9 = 0x1e,
  _0x550ee0 = 0x0,
  _0x431af5 = 0x0,
  _0x5186ab = 0x32,
  _0x335e76 = "-itemssold",
  _0x2b21f0 = "SOLD",
  _0x3f5950 = "EBAY-CA",
  _0xff603b = "America/Toronto",
  _0x201009 = "BuyerLocation:::CA",
  _0xbceba3 = 0x0,
) {
  _0x3f5950 = "";
  switch (_0x4fc574) {
    case "ca":
    default:
      _0x3f5950 = "EBAY-CA";
      break;
    case "com":
      _0x3f5950 = "EBAY-US";
      break;
    case "co.uk":
      _0x3f5950 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x4fc574 +
    "/sh/research?" +
    [
      "keywords=" + _0x4929fe,
      "dayRange=" + _0x5391c9,
      "categoryId=" + _0x550ee0,
      "offset=" + _0x431af5,
      "limit=" + _0x5186ab,
      "sorting=" + _0x335e76,
      "tabName=" + _0x2b21f0,
      "marketplace=" + _0x3f5950,
      "tz=" + encodeURIComponent(_0xff603b),
      "minPrice=" + _0xbceba3,
    ]["join"]("&")
  );
}
async function _0x760d5e(_0x233080) {
  var { domain: _0x41ce63 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x16f00d =
      "https://www.ebay." +
      _0x41ce63 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x233080 +
      "&store_name=" +
      _0x233080 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x16f00d });
}
async function _0x6aa8f7(_0x4d5739) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x4d5739,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x4d5739));
}
async function _0x515890(_0x2be797) {
  var { response: _0x18a300 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x2be797,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x18a300), _0x18a300);
}
function _0x409697(_0x4e5abb = null) {
  console["log"]("createOpenSellerItemsButton", _0x4e5abb);
  var _0x3c1c5d = document["createElement"]("a");
  (_0x3c1c5d["setAttribute"]("id", "sellerItemsLink"),
    _0x3c1c5d["setAttribute"]("class", "a-link-text"),
    _0x3c1c5d["classList"]["add"]("icon"),
    _0x3c1c5d["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x4700dc = document["createElement"]("img");
  return (
    _0x4700dc["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x4700dc["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3c1c5d["appendChild"](_0x4700dc),
    _0x3c1c5d["addEventListener"]("click", async function (_0x1e0594) {
      (_0x1e0594["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x4e5abb),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x4e5abb));
      var _0x1f3897;
      if (!_0x4e5abb) {
        console["log"]("username\x20not\x20found");
        var _0x5fedba = _0x250696(_0x1e0594);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x5fedba,
        );
        if (!_0x5fedba) return;
        var _0x174e3d = extractItemData(_0x5fedba);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x174e3d,
        ),
          (_0x4e5abb = _0x174e3d["username"]),
          (_0x1f3897 = _0x174e3d["itemNumber"]));
      }
      if (
        _0x4e5abb["includes"]("\x20") ||
        _0x4e5abb !== _0x4e5abb["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x4e5abb,
        );
        if (!_0x1f3897) {
          if (!(_0x5fedba = _0x250696(_0x1e0594))) return;
          _0x1f3897 = (_0x174e3d = extractItemData(_0x5fedba))["itemNumber"];
        }
        _0x6aa8f7(_0x1f3897);
      } else
        ((_0x4e5abb = _0x4e5abb["toLowerCase"]()),
          console["log"]("username", _0x4e5abb),
          _0x760d5e(_0x4e5abb));
    }),
    _0x3c1c5d
  );
}
function _0xc2cc6d(_0xa40b0e) {
  for (
    ;
    _0xa40b0e &&
    !_0xa40b0e["classList"]["contains"]("s-item") &&
    !_0xa40b0e["classList"]["contains"]("su-card-container");

  )
    _0xa40b0e = _0xa40b0e["parentElement"];
  return _0xa40b0e;
}
function _0x3b2bc5(_0x4fe600 = null) {
  var _0x58009f = document["createElement"]("a");
  (_0x58009f["setAttribute"]("id", "purchaseHistoryLink"),
    _0x58009f["setAttribute"]("class", "a-link-text"),
    _0x58009f["classList"]["add"]("icon"),
    _0x58009f["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x2958df = document["createElement"]("img");
  return (
    _0x2958df["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x2958df["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x58009f["appendChild"](_0x2958df),
    _0x58009f["addEventListener"]("click", async function (_0x1e1c17) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x4fe600),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x1e1c17["preventDefault"]());
      var _0x3555ea = _0x250696(_0x1e1c17);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x3555ea,
      );
      if (_0x3555ea) {
        var { selectedFilter: _0x3d7d5d } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x3d7d5d &&
          ((_0x3d7d5d = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x3d7d5d,
          }));
        var _0x4b1199 = _0x3d7d5d,
          _0x32ff59 = await checkPurchaseHistoryAndAddToItem(
            _0x3555ea,
            _0x4b1199,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x32ff59);
      } else
        try {
          var _0x4974b0 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x4fe600,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x4974b0),
            (_0x32ff59 = _0x4974b0["totalSold"]));
        } catch (_0x54de17) {
          (console["log"]("error", _0x54de17), (_0x32ff59 = -0x3e7));
        }
    }),
    _0x58009f
  );
}
function _0x250696(_0x4eb7cc) {
  var _0x18892f = _0x4eb7cc["target"];
  return (
    (_0x18892f = _0xc2cc6d(_0x18892f)),
    console["log"]("found\x20s-item", _0x18892f),
    _0x18892f
  );
}
function _0x961f80(_0x273302 = null, _0x2951c5 = null, _0x54e860 = null) {
  var _0x102743 = document["createElement"]("a");
  (_0x102743["setAttribute"]("id", "copyDataLink"),
    _0x102743["setAttribute"]("class", "a-link-text"),
    _0x102743["classList"]["add"]("icon"),
    _0x102743["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x47152f = document["createElement"]("img");
  return (
    _0x47152f["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x47152f["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x102743["appendChild"](_0x47152f),
    _0x102743["addEventListener"]("click", async function (_0x117c9d) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x273302,
        _0x2951c5,
        _0x54e860,
      ),
        _0x117c9d["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x273302 && _0x2951c5 && _0x54e860)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x273302,
          _0x2951c5,
          _0x54e860,
        ),
          isNaN(_0x2951c5) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x2951c5),
            (_0x2951c5 = _0x2951c5["replace"](/[^0-9.]/g, ""))),
          _0xfd3e7b(
            JSON["stringify"]({
              title: _0x273302,
              price: _0x2951c5,
              itemNumber: _0x54e860,
            }),
          ));
      else {
        if (!_0x273302 || !_0x2951c5 || !_0x54e860) {
          var _0x5ede5f = _0x250696(_0x117c9d);
          if (!_0x5ede5f) return;
        }
        var _0x368927 = extractItemData(_0x5ede5f);
        (console["log"]("itemData", _0x368927),
          _0xfd3e7b(JSON["stringify"](_0x368927)));
      }
    }),
    _0x102743
  );
}
function _0xfd3e7b(_0x8088cb) {
  var _0x10b783 = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x10b783),
    (_0x10b783["value"] = _0x8088cb),
    _0x10b783["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x10b783));
}
async function _0x282b76(_0x20ec22 = null) {
  console["log"]("price", _0x20ec22);
  if (_0x20ec22) {
    try {
      _0x20ec22 = _0x20ec22["replace"](/[^0-9.]/g, "");
    } catch (_0x5b4d35) {}
    _0x20ec22 = parseFloat(_0x20ec22);
  }
  var _0x5f2442 = await _0x540e79(_0x20ec22),
    _0x5ab7f9 = document["createElement"]("div");
  return (
    _0x5ab7f9["setAttribute"]("id", "breakEvenPrice"),
    _0x5ab7f9["setAttribute"]("class", "break-even-price"),
    (_0x5ab7f9["textContent"] =
      "Break-even\x20price:\x20$" + _0x5f2442["toFixed"](0x2)),
    _0x5ab7f9
  );
}
async function _0x46aa0e(_0x274529) {
  var _0x40f735 = !0x1,
    _0x315ad2 = !0x1,
    { includeCurrencyConversion: _0x315ad2 } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x40f735 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x490fc6 =
    0.1325 * _0x274529 +
    0.021 * _0x274529 +
    _0x274529 * (_0x40f735 ? 0.004 : 0x0) +
    0.4;
  return (_0x315ad2 && (_0x490fc6 += 0.035 * _0x274529), _0x274529 - _0x490fc6);
}
async function _0x540e79(_0xecf154) {
  var { isInternational: _0x4e5447 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x25889 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x4e5447 || (_0x4e5447 = !0x1), _0x25889 || (_0x25889 = !0x0));
  var _0xad548c = 13.25;
  _0x25889 && (_0xad548c = 12.35);
  var _0x482e90 = _0xecf154 + 0.0725 * _0xecf154,
    _0x3681e2 =
      _0x482e90 * (_0xad548c / 0x64) +
      0.4 +
      (_0x4e5447 ? 0.004 * _0x482e90 : 0x0),
    _0x1f9139 =
      _0xecf154 -
      (_0x3681e2 + (_0x4e5447 ? 0.05 * _0x3681e2 : 0x0)) -
      (_0x4e5447 ? 0.035 * _0x482e90 : 0x0),
    { isUserTaxExempt: _0x125515 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x125515 || (_0x125515 = !0x1),
    _0x125515 || (_0x1f9139 /= 1.0725),
    _0x4e5447 && (_0x1f9139 -= (3.5 * _0x1f9139) / 0x64),
    _0x1f9139
  );
}
function _0x234ae0(_0x6909a = null) {
  console["log"]("createButtonToSaveSeller", _0x6909a);
  var _0x1948fe = document["createElement"]("a");
  (_0x1948fe["setAttribute"]("id", "saveSellerLink"),
    _0x1948fe["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x1948fe["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x576e79 = document["createElement"]("img");
  return (
    _0x576e79["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x576e79["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1948fe["appendChild"](_0x576e79),
    _0x1948fe["addEventListener"]("click", async function (_0x37bc64) {
      (_0x37bc64["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x6909a));
      var _0xac4077;
      if (!_0x6909a) {
        var _0x589e = _0x250696(_0x37bc64);
        if (!_0x589e) return;
        var _0x181372 = extractItemData(_0x589e);
        ((_0x6909a = _0x181372["username"]),
          (_0xac4077 = _0x181372["itemNumber"]));
      }
      if (
        _0x6909a["includes"]("\x20") ||
        _0x6909a !== _0x6909a["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x6909a,
        ),
          (_0x6909a = await _0x515890(_0xac4077)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x6909a,
          ));
      else _0x6909a = _0x6909a["toLowerCase"]();
      _0x1948fe["setAttribute"]("data-seller-name", _0x6909a);
      var { ebayCompetitors: _0x73b91d } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x4474d8 = (_0x73b91d = _0x73b91d || [])["indexOf"](_0x6909a);
      console["log"]("ebayCompetitors", _0x73b91d);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x4474d8
            ? (console["log"]("save-seller\x20clicked\x20username", _0x6909a),
              _0x73b91d["push"](_0x6909a),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x576e79["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x6909a,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x576e79["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x4474d8)
            (console["log"]("remove-seller\x20clicked\x20username", _0x6909a),
              _0x73b91d["splice"](_0x4474d8, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x576e79["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x6909a,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x73b91d });
    }),
    _0x1948fe
  );
}
async function _0x2e075c(_0x1f85fe, _0x46b4bf) {
  var { ebayCompetitors: _0x538b97 } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x48c7c9 = (_0x538b97 = _0x538b97 || [])["indexOf"](_0x46b4bf),
    _0x2a0d08 = _0x1f85fe["querySelector"]("img");
  -0x1 !== _0x48c7c9
    ? (_0x1f85fe["classList"]["replace"]("save-seller", "remove-seller"),
      _0x2a0d08["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x1f85fe["classList"]["replace"]("remove-seller", "save-seller"),
      _0x2a0d08["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x2a831c(
  _0x2d4ca6 = null,
  _0x2ac828 = null,
  _0x4992ad = null,
  _0x3025fd = !0x0,
  _0x2ee6cf = null,
  _0x18bc82 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x2d4ca6));
  var _0x536c21 = _0x234ae0(_0x2ac828),
    _0x39ac10 = _0x3e824e(_0x2d4ca6),
    _0xc783c9 = _0x3b2bc5(_0x2ee6cf),
    _0xf34a8e = _0x2764e4(_0x2d4ca6),
    _0x3f6cca = _0x15900c(_0x2d4ca6, _0x18bc82, _0x2ee6cf, _0x4992ad),
    _0x44fc15 = _0x2764e4(
      _0x2d4ca6,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x88b713 = _0x119b2e(_0x4992ad),
    _0x30c31f = _0x7c9975(_0x2ee6cf),
    _0x472fe0 = _0x409697(_0x2ac828),
    _0x496524 = document["createElement"]("div");
  _0x496524["setAttribute"]("id", "search-div");
  var _0x588144 = document["createElement"]("label");
  ((_0x588144["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x496524["appendChild"](_0x588144),
    _0x496524["appendChild"](_0x3f6cca),
    _0x496524["appendChild"](_0xf34a8e),
    _0x496524["appendChild"](_0x39ac10),
    _0x496524["appendChild"](_0x88b713),
    _0x496524["appendChild"](_0x30c31f),
    _0x496524["appendChild"](_0x44fc15),
    console["log"]("CopyDataButton", _0x2d4ca6, _0x18bc82, _0x2ee6cf));
  var _0x5b9296 = _0x961f80(_0x2d4ca6, _0x18bc82, _0x2ee6cf),
    _0x4a41ca = document["createElement"]("div");
  _0x4a41ca["setAttribute"]("id", "item-buttons-div");
  var _0x260380 = document["createElement"]("div");
  (_0x260380["setAttribute"]("id", "main-buttons-div"),
    _0x260380["appendChild"](_0x472fe0),
    _0x260380["appendChild"](_0xc783c9),
    _0x260380["appendChild"](_0x5b9296),
    _0x260380["appendChild"](_0x536c21),
    _0x4a41ca["appendChild"](_0x260380));
  if (_0x3025fd) {
    var _0x1c94b6 = createButtonListToEbay();
    _0x4a41ca["appendChild"](_0x1c94b6);
  }
  return (_0x4a41ca["appendChild"](_0x496524), _0x4a41ca);
}
var _0x218ddb = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x46a2c0) => {
        (console["log"](
          _0x46a2c0,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x218ddb, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x4fb2ab) => {
        (console["log"](
          _0x4fb2ab,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x218ddb, "search-type", "keywords"));
      },
    },
  },
];
async function _0x53a8fc() {
  var { convertToKeywords: _0x4efda1 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x4efda1 &&
    ((_0x4efda1 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x218ddb,
      "search-type",
      _0x4efda1 ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x218ddb })[
      "init"
    ]());
}
var _0x114fc9 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x1824d7) => {
        (console["log"](_0x1824d7, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x114fc9, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x1da55a) => {
        (console["log"](_0x1da55a, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x114fc9, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x401038) => {
        (console["log"](
          _0x401038,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x114fc9, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x584e75) => {
        (console["log"](
          _0x584e75,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x114fc9, "search-type", "keywords"));
      },
    },
  },
];
async function _0x457f69() {
  var { amazonSortType: _0x691310 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0xf961e0 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0xf961e0 &&
    ((_0xf961e0 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x691310 &&
      ((_0x691310 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x114fc9, "sort-type", _0x691310),
    updateContextMenu(_0x114fc9, "search-type", _0xf961e0),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x114fc9 })[
      "init"
    ]());
}
_0x114fc9 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x12d6be) => {
        (console["log"](_0x12d6be, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x114fc9, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x4a30ab) => {
        (console["log"](_0x4a30ab, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x114fc9, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x5ddb5b = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x3fa5b0) => {
        (console["log"](_0x3fa5b0, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x18c5c4) => {
        (console["log"](_0x18c5c4, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x113edc) => {
        (console["log"](_0x113edc, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x290efd) => {
        (console["log"](_0x290efd, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3bce65) => {
        (console["log"](_0x3bce65, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x542150) => {
        (console["log"](_0x542150, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2a2fbe) => {
        (console["log"](_0x2a2fbe, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3a76c4) => {
        (console["log"](_0x3a76c4, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0x5ddb5b, "filter-type", "90"));
      },
    },
  },
];
async function _0x5ac4bf() {
  var { selectedFilter: _0x15d0fd } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x15d0fd &&
    ((_0x15d0fd = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0x5ddb5b, "filter-type", _0x15d0fd),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0x5ddb5b })[
      "init"
    ]());
}
function _0x291107() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x4302d3() {
  const _0x38efb0 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x5e6047 = 0x0;
  const _0x38170d = () =>
    new Promise((_0x180535, _0x2055cb) => {
      const _0x541962 = new MutationObserver((_0xb1401b, _0x5773f2) => {
        const _0x122377 = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x122377 &&
          (console["log"]("Details\x20form\x20found!"),
          _0x5773f2["disconnect"](),
          _0x180535(_0x122377));
      });
      (_0x541962["observe"](_0x38efb0, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x541962["disconnect"]();
          if (_0x5e6047 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x5e6047 + 0x1) +
                "/3)",
            ),
              _0x5e6047++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x180535(_0x38170d()), 0x1388));
          else
            _0x2055cb(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x639ddc = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x639ddc) {
    (_0x639ddc["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x38170d(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x35c79c) {
      console["error"](_0x35c79c["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x4261bb(_0x64f4f1 = null, _0x1fb740 = null, _0x40326c = null) {
  var _0x118d56 = document["createElement"]("a");
  (_0x118d56["setAttribute"]("id", "copyDataLink"),
    _0x118d56["setAttribute"]("class", "a-link-text"),
    _0x118d56["classList"]["add"]("icon"),
    _0x118d56["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x9dc589 = document["createElement"]("img");
  return (
    _0x9dc589["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x9dc589["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x118d56["appendChild"](_0x9dc589),
    _0x118d56["addEventListener"]("click", async function (_0x2093c1) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x64f4f1,
        _0x1fb740,
        _0x40326c,
      ),
        _0x2093c1["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x64f4f1 && _0x1fb740 && _0x40326c) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x64f4f1,
          _0x1fb740,
          _0x40326c,
        );
        isNaN(_0x1fb740) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x1fb740),
          (_0x1fb740 = _0x1fb740["replace"](/[^0-9.]/g, "")));
        var _0x351b7b = JSON["stringify"]({
          title: _0x64f4f1,
          price: _0x1fb740,
          itemNumber: _0x40326c,
        });
        (_0x149c49(
          (_0x48a231 = await findSimiliarProducts(_0x351b7b))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x48a231),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x64f4f1 || !_0x1fb740 || !_0x40326c) {
          var _0x2a2257 = _0x250696(_0x2093c1);
          if (!_0x2a2257) return;
        }
        var _0x3b99ce = extractItemData(_0x2a2257);
        (console["log"]("itemData", _0x3b99ce),
          (_0x351b7b = JSON["stringify"](_0x3b99ce)));
        var _0x48a231;
        (_0x149c49(
          (_0x48a231 = await findSimiliarProducts(_0x351b7b))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x48a231),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x118d56
  );
}
async function findSimiliarProducts(_0x17c831) {
  console["log"]("findSimiliarProducts", _0x17c831);
  var _0x5adf3f = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x17c831,
  });
  return (console["log"]("response", _0x5adf3f), _0x5adf3f["productLinks"]);
}
function _0x149c49(_0x264c3e) {
  const _0xf6cbe0 = document["getElementById"]("productLinksModalOverlay");
  _0xf6cbe0 && _0xf6cbe0["remove"]();
  const _0x26b7a0 = document["createElement"]("div");
  ((_0x26b7a0["id"] = "productLinksModalOverlay"),
    _0x26b7a0["classList"]["add"]("product-links-modal-overlay"));
  const _0x2abc01 = document["createElement"]("div");
  _0x2abc01["classList"]["add"]("product-links-modal");
  const _0x3111fc = document["createElement"]("div");
  _0x3111fc["classList"]["add"]("modal-button-container");
  const _0x409843 = document["createElement"]("button");
  (_0x409843["classList"]["add"]("close-button"),
    (_0x409843["innerText"] = "Close"),
    _0x409843["addEventListener"]("click", () => {
      _0x26b7a0["remove"]();
    }));
  const _0x3be9ca = document["createElement"]("button");
  (_0x3be9ca["classList"]["add"]("copy-button"),
    (_0x3be9ca["innerText"] = "Copy"),
    _0x3be9ca["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x264c3e),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x2fbe43) {
        console["error"]("Failed\x20to\x20copy:", _0x2fbe43);
      }
    }));
  const _0x3c6b21 = document["createElement"]("h2");
  _0x3c6b21["innerText"] = "Similar\x20Product\x20Links";
  const _0x5dae05 = document["createElement"]("textarea");
  ((_0x5dae05["value"] = _0x264c3e),
    _0x5dae05["setAttribute"]("readonly", !0x0),
    (_0x5dae05["style"]["width"] = "100%"),
    (_0x5dae05["style"]["height"] = "300px"),
    _0x3111fc["appendChild"](_0x3be9ca),
    _0x3111fc["appendChild"](_0x409843),
    _0x2abc01["appendChild"](_0x3111fc),
    _0x2abc01["appendChild"](_0x3c6b21),
    _0x2abc01["appendChild"](_0x5dae05),
    _0x26b7a0["appendChild"](_0x2abc01),
    document["body"]["appendChild"](_0x26b7a0));
}
async function _0x496773(_0x14c4e1) {
  var { domain: _0x3e28a2 } = await chrome["storage"]["local"]["get"]("domain");
  try {
    const _0x187ab8 = await fetch(
        "https://poshmark." + _0x3e28a2 + "/edit-listing/" + _0x14c4e1,
        { credentials: "include" },
      ),
      _0x4c02a6 = (await _0x187ab8["text"]())["match"](/"sku":\s*"([^"]+)"/);
    if (!_0x4c02a6) {
      console["error"]("SKU\x20not\x20found\x20in\x20response");
      return;
    }
    return _0x4c02a6[0x1];
  } catch (_0x136cd6) {
    console["error"]("Error\x20fetching\x20SKU:", _0x136cd6);
  }
}
async function _0x24fc62(_0x4b5dd5, _0x4b03ba = {}) {
  const {
      available: _0x3c68eb,
      price: _0x412d5e,
      originalPrice: _0x598c3c,
      region: region = "us",
    } = _0x4b03ba,
    _0x2800e6 = "ca" === region ? "poshmark.ca" : "poshmark.com",
    _0x396713 = "ca" === region ? "CAD" : "USD",
    _0x15767e =
      "https://" +
      _0x2800e6 +
      "/vm-rest/posts/" +
      _0x4b5dd5 +
      "?pm_version=2025.37.1";
  var _0x71399a = { post: {} };
  _0x4b03ba["hasOwnProperty"]("available") &&
    (_0x71399a["post"]["inventory"] = {
      status: _0x3c68eb ? "available" : "not_for_sale",
    });
  "number" == typeof _0x412d5e &&
    ((_0x71399a["post"]["price_amount"] = {
      val: _0x412d5e["toFixed"](0x2),
      currency_code: _0x396713,
    }),
    _0x4b03ba["hasOwnProperty"]("originalPrice") ||
      (_0x71399a["post"]["original_price_amount"] = {
        val: (1.5 * _0x412d5e)["toFixed"](0x2),
        currency_code: _0x396713,
      }));
  ("number" == typeof _0x598c3c &&
    (_0x71399a["post"]["original_price_amount"] = {
      val: _0x598c3c["toFixed"](0x2),
      currency_code: _0x396713,
    }),
    _0x4b03ba["hasOwnProperty"]("set_offers") &&
      (_0x71399a["post"]["offer_auto_actions_v2_enabled"] =
        !!_0x4b03ba["set_offers"]),
    _0x4b03ba["hasOwnProperty"]("min_offer") &&
      (_0x71399a["post"]["offer_auto_actions_min_price_amount"] = {
        val: _0x4b03ba["min_offer"],
        currency_code: _0x396713,
      }),
    console["log"](
      "Updating\x20listing\x20[" + _0x4b5dd5 + "@" + _0x2800e6 + "]\x20with:",
      _0x71399a,
    ));
  if (0x0 === Object["keys"](_0x71399a["post"])["length"])
    return (
      console["warn"](
        "[" +
          _0x4b5dd5 +
          "]\x20No\x20update\x20options\x20specified—skipping\x20request.",
      ),
      Promise["resolve"]()
    );
  return (
    console["log"]("postData:", _0x71399a),
    fetch(_0x15767e, {
      method: "POST",
      credentials: "include",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON["stringify"](_0x71399a),
    })
      ["then"]((_0x543e59) => {
        if (!_0x543e59["ok"]) throw new Error("HTTP\x20" + _0x543e59["status"]);
        return _0x543e59["json"]();
      })
      ["then"]((_0x48f2e5) => {
        return (
          console["log"](
            "✅\x20[" + _0x4b5dd5 + "@" + _0x2800e6 + "]\x20updated:",
            _0x71399a["post"],
            _0x48f2e5,
          ),
          _0x48f2e5
        );
      })
      ["catch"]((_0x1e8ed1) => {
        console["error"](
          "❌\x20[" + _0x4b5dd5 + "@" + _0x2800e6 + "]\x20update\x20failed:",
          _0x1e8ed1,
        );
        throw _0x1e8ed1;
      })
  );
}
function fetchProductData(
  _0x4a8aeb,
  _0x2cf81c = "https://www.amazon.com/dp/" + atob(_0x4a8aeb) + "?th=1&psc=1",
) {
  return (
    console["log"](
      "fetchProductData\x20called\x20with\x20cl:",
      _0x4a8aeb,
      "and\x20url:",
      _0x2cf81c,
    ),
    new Promise((_0x382667, _0xf3a6fb) => {
      chrome["runtime"]["sendMessage"](
        {
          type: "fetch_product_data",
          supplier: "amazon",
          customLabel: _0x4a8aeb,
          itemUrl: _0x2cf81c,
        },
        (_0x5da09b) => {
          if (chrome["runtime"]["lastError"])
            return _0xf3a6fb(chrome["runtime"]["lastError"]);
          if (!_0x5da09b || _0x5da09b["error"])
            return _0xf3a6fb(
              new Error(_0x5da09b?.["error"] || "Unknown\x20error"),
            );
          _0x382667(_0x5da09b["productData"] || {});
        },
      );
    })
  );
}
async function _0x1e765f(_0xc5c172, _0x556999 = {}) {
  const {
    minPrice: _0x5a7e4f,
    currency: currency = "USD",
    region: region = "us",
    userId: _0x10d567,
    pmVersion: pmVersion = "2025.37.1",
  } = _0x556999;
  if (!_0x10d567)
    throw new Error("previewOfferEarnings\x20requires\x20opts.userId");
  if (null == _0x5a7e4f)
    throw new Error("previewOfferEarnings\x20requires\x20opts.minPrice");
  const _0x39ec58 =
    "https://" +
    ("ca" === region ? "poshmark.ca" : "poshmark.com") +
    "/vm-rest/users/" +
    _0x10d567 +
    "/seller_earnings/post?" +
    new URLSearchParams({
      price_amount: JSON["stringify"]({
        val: String(_0x5a7e4f),
        currency_code: currency,
      }),
      object_id: _0xc5c172,
      pm_version: pmVersion,
    })["toString"]();
  console["log"]("Fetching\x20earnings\x20preview\x20from:", _0x39ec58);
  const _0x2934cd = await fetch(_0x39ec58, {
    method: "GET",
    credentials: "include",
    headers: {
      Accept: "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!_0x2934cd["ok"])
    throw new Error(
      "previewOfferEarnings\x20failed:\x20HTTP\x20" + _0x2934cd["status"],
    );
  const _0x2b6aae = await _0x2934cd["json"]();
  return (
    console["log"](
      "💡\x20Earnings\x20preview\x20for\x20post\x20" + _0xc5c172 + ":",
      _0x2b6aae,
    ),
    _0x2b6aae
  );
}
function _0x13985c() {
  const _0x46e7b3 = document["querySelectorAll"]("a[href^=\x22/listing/\x22]");
  for (let _0x5e686d of _0x46e7b3) {
    const _0x5a751d = _0x5e686d["getAttribute"]("href")["match"](/-(\w{24})$/);
    if (_0x5a751d) {
      const _0x5ad014 = _0x5a751d[0x1];
      return (console["log"]("Listing\x20ID:", _0x5ad014), _0x5ad014);
    }
  }
  return (console["warn"]("No\x20listing\x20ID\x20found."), null);
}
function _0x55f96a() {
  const _0x4c7243 = window["location"]["pathname"]["match"](
    /\/listing\/.*-(\w{24})$/,
  );
  if (_0x4c7243) {
    const _0x12b5e9 = _0x4c7243[0x1];
    return (
      console["log"]("Listing\x20ID\x20from\x20URL:", _0x12b5e9),
      _0x12b5e9
    );
  }
  return (console["warn"]("No\x20listing\x20ID\x20found\x20in\x20URL."), null);
}
function _0x4b7d2a() {
  var _0x46862a = _0x13985c();
  return (_0x46862a || (_0x46862a = _0x55f96a()), _0x46862a);
}
async function _0x28a8ac() {
  var _0x706cb4 = _0x4b7d2a(),
    _0xcf75a7 = await _0x496773(_0x706cb4);
  return atob(_0xcf75a7);
}
async function _0x503012() {
  var _0x277a02 = await _0x28a8ac();
  if (!_0x277a02) throw new Error("ASIN\x20not\x20found");
  const { domain: _0x177570 } =
      await chrome["storage"]["local"]["get"]("domain"),
    _0x32535b =
      "https://www.amazon." + _0x177570 + "/dp/" + _0x277a02 + "?th=1&psc=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x32535b });
}
_0x2e32d0();
async function _0x2e32d0() {
  await _0x4873a8();
  var _0x57ca18 = _0x1d5318(_0x503012);
  document["querySelector"]("[data-et-name=\x27listing\x27]")["parentElement"][
    "appendChild"
  ](_0x57ca18);
}
