function _0x2e291f() {
  return new Promise((_0x38887a) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x38887a();
      });
    });
  });
}
function _0x3f9da0() {
  return new Promise((_0x4d9754) => {
    requestIdleCallback(() => {
      _0x4d9754();
    });
  });
}
function _0x98e7b7(_0x300d43 = 0x3e8) {
  return new Promise((_0x27363a, _0xb02648) => {
    let _0x399148,
      _0xc24a = Date["now"](),
      _0x3da18b = !0x1;
    function _0x55aef3() {
      if (Date["now"]() - _0xc24a > _0x300d43)
        (_0x3da18b && _0x399148["disconnect"](), _0x27363a());
      else setTimeout(_0x55aef3, _0x300d43);
    }
    const _0x810fe8 = () => {
        _0xc24a = Date["now"]();
      },
      _0xf7a0b5 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x399148 = new MutationObserver(_0x810fe8)),
        _0x399148["observe"](document["body"], _0xf7a0b5),
        (_0x3da18b = !0x0),
        setTimeout(_0x55aef3, _0x300d43));
    else
      window["onload"] = () => {
        ((_0x399148 = new MutationObserver(_0x810fe8)),
          _0x399148["observe"](document["body"], _0xf7a0b5),
          (_0x3da18b = !0x0),
          setTimeout(_0x55aef3, _0x300d43));
      };
  });
}
async function _0x401768() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x98e7b7(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x25056c() {
  return await new Promise(function (_0x2ae64e, _0x44a3f1) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x4a635b) {
        (console["log"]("result:\x20", _0x4a635b["membership"]),
          _0x2ae64e(_0x4a635b["membership"]));
      },
    );
  });
}
async function _0x584b9b() {
  return await new Promise(function (_0x38f138, _0x2782ff) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x19f3ef) {
        (console["log"]("result:\x20", _0x19f3ef["creditsAvailable"]),
          _0x38f138(_0x19f3ef["creditsAvailable"]));
      },
    );
  });
}
async function _0x3689c0(_0x5f4e65) {
  if ("ultimate" != (await _0x25056c()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x584b9b()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
console["log"]("content/amazon/seller_profile/functions.js");
function _0x3343ee() {
  var _0x1eae39 = document["getElementById"]("page-section-detail-seller-info");
  if (!_0x1eae39) return !0x1;
  var locationElements = _0x1eae39["querySelectorAll"](
    ".a-row.a-spacing-none.indent-left",
  );
  for (
    var _0x2b8f72 = 0x0;
    _0x2b8f72 < locationElements["length"];
    _0x2b8f72++
  ) {
    var locationElement = locationElements[_0x2b8f72];
    if (locationElement && locationElement["textContent"]) {
      var location = locationElement["textContent"]["trim"]();
      if ("CN" === location || "HK" === location) return !0x0;
    }
  }
  return !0x1;
}
(console["log"]("content/amazon/seller_profile/content.js"),
  _0x98e7b7()["then"](function () {
    var _0x1268e7 = _0x3343ee();
    (console["log"]("isChineseSeller:", _0x1268e7),
      chrome["runtime"]["sendMessage"]({
        type: "detect_chinese_seller",
        isChineseSeller: _0x1268e7,
      }));
  }));
