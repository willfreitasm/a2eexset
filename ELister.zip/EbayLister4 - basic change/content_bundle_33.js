function _0x329f60() {
  return new Promise((_0x113410) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x113410();
      });
    });
  });
}
function _0x1ad4c9() {
  return new Promise((_0x23f5ef) => {
    requestIdleCallback(() => {
      _0x23f5ef();
    });
  });
}
function _0x2eacb8(_0x4bbce3 = 0x3e8) {
  return new Promise((_0x5a3134, _0x44a695) => {
    let _0x53d0ca,
      _0x273eb2 = Date["now"](),
      _0x4109d2 = !0x1;
    function _0x229654() {
      if (Date["now"]() - _0x273eb2 > _0x4bbce3)
        (_0x4109d2 && _0x53d0ca["disconnect"](), _0x5a3134());
      else setTimeout(_0x229654, _0x4bbce3);
    }
    const _0x32d54b = () => {
        _0x273eb2 = Date["now"]();
      },
      _0x74a2ef = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x53d0ca = new MutationObserver(_0x32d54b)),
        _0x53d0ca["observe"](document["body"], _0x74a2ef),
        (_0x4109d2 = !0x0),
        setTimeout(_0x229654, _0x4bbce3));
    else
      window["onload"] = () => {
        ((_0x53d0ca = new MutationObserver(_0x32d54b)),
          _0x53d0ca["observe"](document["body"], _0x74a2ef),
          (_0x4109d2 = !0x0),
          setTimeout(_0x229654, _0x4bbce3));
      };
  });
}
async function _0xc647ae() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x2eacb8(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function findAmazonItem() {
  var { domain: _0x3ccab6 } = await chrome["storage"]["local"]["get"]("domain"),
    _0xb5677a = Array["from"](document["querySelectorAll"]("a"))
      ["filter"]((_0x7f2635) =>
        _0x7f2635["href"]["toLowerCase"]()["includes"]("amazon.com"),
      )
      ["map"]((_0x787927) => _0x787927["href"]);
  console["log"]("amazonLinks:", _0xb5677a);
  var _0x476303 = _0xb5677a[0x0];
  return (console["log"]("amazonLink:", _0x476303), _0x476303);
}
async function _0x17838d() {
  var _0x2130a5 = await findAmazonItem();
  window["location"]["href"] = _0x2130a5;
}
chrome["runtime"]["onMessage"]["addListener"](
  function (_0x288962, _0x5620bb, _0x51761d) {
    console["log"]("request", _0x288962);
    if ("find_amazon_item" === _0x288962["type"])
      return (
        console["log"]("find_amazon_item\x20message\x20received"),
        _0x2eacb8()["then"](() => {
          (console["log"]("onPageLoadAndStable\x20callback"), _0x17838d());
        }),
        !0x0
      );
    return !0x0;
  },
);
