function _0x4b68e3() {
  return new Promise((_0x331172) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x331172();
      });
    });
  });
}
function _0x45164a() {
  return new Promise((_0x57ab63) => {
    requestIdleCallback(() => {
      _0x57ab63();
    });
  });
}
function _0x3bb150(_0x64ebf4 = 0x3e8) {
  return new Promise((_0x504688, _0x1ab4e6) => {
    let _0x3d5d08,
      _0x2ebbf5 = Date["now"](),
      _0x5567d5 = !0x1;
    function _0x5560b7() {
      if (Date["now"]() - _0x2ebbf5 > _0x64ebf4)
        (_0x5567d5 && _0x3d5d08["disconnect"](), _0x504688());
      else setTimeout(_0x5560b7, _0x64ebf4);
    }
    const _0x4d9138 = () => {
        _0x2ebbf5 = Date["now"]();
      },
      _0x29229e = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x3d5d08 = new MutationObserver(_0x4d9138)),
        _0x3d5d08["observe"](document["body"], _0x29229e),
        (_0x5567d5 = !0x0),
        setTimeout(_0x5560b7, _0x64ebf4));
    else
      window["onload"] = () => {
        ((_0x3d5d08 = new MutationObserver(_0x4d9138)),
          _0x3d5d08["observe"](document["body"], _0x29229e),
          (_0x5567d5 = !0x0),
          setTimeout(_0x5560b7, _0x64ebf4));
      };
  });
}
async function _0x292a7f() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x3bb150(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x133178(_0x1a70e0) {
  var _0x4416a5 = document["querySelector"](".sh-core-header__username");
  _0x4416a5 && (_0x4416a5["innerText"] = _0x1a70e0);
}
function _0x336b47(_0xdd80b0) {
  var _0x2e506f = document["querySelector"]("#user-name");
  _0x2e506f && (_0x2e506f["innerText"] = _0xdd80b0);
}
function _0x37da26(_0x576eeb) {
  var _0x5a255c = document["querySelector"](
    ".site-preferences-top-nav__feedback",
  );
  _0x5a255c && (_0x5a255c["innerText"] = _0x576eeb);
}
function _0x152533(_0x490041, _0x4c2187) {
  !(function _0x1e5888(_0x29bcd4) {
    _0x29bcd4["nodeType"] === Node["TEXT_NODE"]
      ? (_0x29bcd4["nodeValue"] = _0x29bcd4["nodeValue"]["replace"](
          new RegExp(_0x490041, "gi"),
          _0x4c2187,
        ))
      : _0x29bcd4["nodeType"] === Node["ELEMENT_NODE"] &&
        Array["from"](_0x29bcd4["childNodes"])["forEach"](_0x1e5888);
  })(document["body"]);
}
function _0x142c8f(_0x2164cb, _0x148e5a) {
  var _0x592648 = document["querySelector"]("#gh-uid");
  if (_0x592648) {
    var _0x33ccaf = _0x592648["innerText"]["replace"](
      new RegExp(_0x2164cb, "i"),
      _0x148e5a,
    );
    _0x592648["innerText"] = _0x33ccaf;
  }
}
async function _0xf6af3d() {
  var { fullName: _0x51b21d } =
    await chrome["storage"]["local"]["get"]("fullName");
  console["log"](_0x51b21d);
  if (_0x51b21d && "string" == typeof _0x51b21d) return _0x51b21d;
  var _0x51b21d = await fetchFullName();
  return (
    console["log"]("Fullname\x20that\x20is\x20fetched:\x20" + _0x51b21d),
    chrome["storage"]["local"]["set"]({ fullName: _0x51b21d }),
    _0x51b21d
  );
}
async function _0x5944f0() {
  var { storeName: _0xa14230 } =
    await chrome["storage"]["local"]["get"]("storeName");
  if (_0xa14230 && "string" == typeof _0xa14230) return _0xa14230;
  var _0xa14230 = await fetchStoreName();
  return (
    console["log"]("Storename\x20that\x20is\x20fetched:\x20" + _0xa14230),
    chrome["storage"]["local"]["set"]({ storeName: _0xa14230 }),
    _0xa14230
  );
}
async function fetchStoreName() {
  return document["querySelector"](".str-seller-card__user-name")["innerText"][
    "trim"
  ]();
}
async function fetchFullName() {
  return (
    await _0x3cff6a(),
    _0x757d08()["parentElement"]["firstChild"]["innerText"]["trim"]()
  );
}
async function _0x3cff6a() {
  if (!_0x757d08()) {
    var _0x48cdc3 = document["querySelector"](".gh-identity\x20button");
    _0x48cdc3 &&
      (_0x48cdc3["click"](),
      !_0x757d08() &&
        (await new Promise((_0x4902d2) => setTimeout(_0x4902d2, 0x3e8)),
        _0x48cdc3["click"]()));
  }
}
function _0x757d08() {
  return document["querySelector"](".gh-identity-signed-in__user-ratings");
}
async function _0x1d8e18() {
  var { ebayUsername: _0x3ebd0b } =
    await chrome["storage"]["local"]["get"]("ebayUsername");
  if (_0x3ebd0b && "string" == typeof _0x3ebd0b) return _0x3ebd0b;
  var _0x3ebd0b = await fetchUserName();
  return (
    console["log"]("ebayUsername\x20that\x20is\x20fetched:\x20" + _0x3ebd0b),
    chrome["storage"]["local"]["set"]({ ebayUsername: _0x3ebd0b }),
    _0x3ebd0b
  );
}
async function fetchUserName() {
  return (
    await _0x3cff6a(),
    _0x757d08()["children"][0x0]["innerText"]["trim"]()
  );
}
function _0x36ef12(_0x1d7faf) {
  return _0x1d7faf["charAt"](0x1) + "*****";
}
function _0x360050(_0x202d2d, _0x4bdbad) {
  var _0x5032b2 = document["getElementById"]("gh-ug");
  if (_0x5032b2) {
    var _0x350f68 = _0x202d2d["split"]("\x20"),
      _0x21ad3d = _0x5032b2["innerText"];
    (_0x350f68["forEach"]((_0x1cae46) => {
      _0x21ad3d = _0x21ad3d["replace"](new RegExp(_0x1cae46, "i"), _0x4bdbad);
    }),
      (_0x5032b2["innerText"] = _0x21ad3d));
    var _0x1d0ea0 = document["querySelector"]("#gh-un");
    _0x1d0ea0 &&
      (_0x1d0ea0["textContent"] = _0x1d0ea0["textContent"]["replace"](
        new RegExp(_0x202d2d, "i"),
        _0x4bdbad,
      ));
  }
}
function _0x203b2b() {
  var _0x1f9c93 = document["querySelector"]("#me-badge"),
    _0x3b7274 =
      _0x1f9c93["querySelector"]("a")["innerText"]["charAt"](0x1) + "*****";
  _0x1f9c93["querySelector"]("a")["innerText"] = _0x3b7274;
}
function _0x141ae2() {
  var _0x5058d5 = document["querySelector"](
      ".ux-seller-section__item--seller\x20.ux-textspans",
    ),
    _0x51aa4a = _0x5058d5["innerText"]["charAt"](0x1) + "*****";
  _0x5058d5["innerText"] = _0x51aa4a;
}
function _0x80da73(_0x2da424) {
  var _0x588f22 = document["querySelector"]("[data-test-id=\x22user-name\x22]");
  _0x588f22 && (_0x588f22["innerText"] = _0x2da424);
}
function _0xe57bff() {
  var _0x5587d1 = document["querySelector"](".mbg-id"),
    _0x3c5298 = _0x5587d1["innerText"]["charAt"](0x1) + "*****";
  _0x5587d1["innerText"] = _0x3c5298;
}
function _0x5053ab() {
  var _0xa8e77f = document["querySelector"](".m-top-nav__username"),
    _0x1779a9 = _0xa8e77f["innerText"]["charAt"](0x1) + "*****";
  _0xa8e77f["innerText"] = _0x1779a9;
}
function _0x436d68() {
  [
    ".shipping-address\x20.address",
    ".phone.ship-itm",
    ".note-content",
    "#amazonEmail",
    "#amazonOrderNumber",
    ".order-info",
    ".clipboard-key",
    ".item__buyer-name",
    ".item__order-number",
    ".user-note",
    ".lineItemCardInfo__sku",
    ".gh-identity",
    ".details",
    ".page-header__user-profile-bookmark",
    ".ux-layout-section__item--table-view",
  ]["forEach"]((_0x2cb36e) => {
    document["querySelectorAll"](_0x2cb36e)["forEach"]((_0x5df060) => {
      ((_0x5df060["style"]["filter"] = "blur(5px)"),
        (_0x5df060["style"]["pointerEvents"] = "none"));
    });
  });
}
(console["log"]("ebay/all_ebay/content.js"),
  console["log"]("URL:\x20" + window["location"]["href"]),
  window["addEventListener"]("load", async function () {
    await _0x3bb150();
    var _0xe3e183 = document["documentElement"]["innerHTML"]["includes"](
      "upstream\x20connect\x20error\x20or\x20disconnect/reset\x20before\x20headers.\x20reset\x20reason:\x20connection\x20termination",
    );
    (console["log"]("Is\x20comment\x20found:\x20" + _0xe3e183),
      _0xe3e183 &&
        (console["log"]("comment\x20found"),
        chrome["runtime"]["sendMessage"]({
          type: "itemFailed",
          sku: "error",
          message:
            "upstream\x20connect\x20error\x20or\x20disconnect/reset\x20before\x20headers.\x20reset\x20reason:\x20connection\x20termination",
        })));
  }),
  chrome["storage"]["local"]["get"](
    ["shouldHidePersonalInformation"],
    async function (_0x4b8ae5) {
      if (_0x4b8ae5["shouldHidePersonalInformation"]) {
        async function _0x576681() {
          (console["log"]("Anonymizing\x20page..."),
            (document["documentElement"]["style"]["filter"] = "blur(10px)"),
            await _0x3bb150());
          var _0x520407 = await _0x1d8e18(),
            _0xcfae06 = await _0xf6af3d(),
            _0x3e1abf;
          try {
            _0x3e1abf = await _0x5944f0();
          } catch (_0xa96052) {
            (alert("Store\x20name\x20not\x20found"),
              (_0x3e1abf = prompt(
                "Please\x20enter\x20the\x20store\x20name",
                "Store\x20Name",
              )),
              console["log"]("Store\x20name:\x20" + _0x3e1abf),
              chrome["storage"]["local"]["set"](
                { storeName: _0x3e1abf },
                function () {
                  console["log"](
                    "Store\x20name\x20is\x20set\x20to\x20" + _0x3e1abf,
                  );
                },
              ));
          }
          var _0x26b5bc = _0x36ef12(_0x520407),
            _0x15715e = _0x36ef12(_0xcfae06),
            _0x2b0979 = _0x36ef12(_0x3e1abf);
          (_0x142c8f(_0x520407, _0x26b5bc),
            _0x360050(_0xcfae06, _0x15715e),
            _0x133178(_0x26b5bc),
            _0x80da73(_0x26b5bc),
            _0x336b47(_0x26b5bc),
            _0x37da26(_0x26b5bc),
            _0x152533(_0x520407, _0x26b5bc),
            _0x152533(_0xcfae06, _0x15715e));
          var _0x4e2010 = _0xcfae06["split"]("\x20");
          for (
            let _0x19736a = 0x0;
            _0x19736a < _0x4e2010["length"];
            _0x19736a++
          ) {
            var _0x1cb804 = _0x4e2010[_0x19736a];
            _0x152533(_0x1cb804, _0x36ef12(_0x1cb804));
          }
          (_0x152533(_0x3e1abf, _0x2b0979),
            _0x152533(/\d{12}/g, "************"),
            _0x436d68(),
            (document["documentElement"]["style"]["filter"] = "none"));
        }
        _0x576681();
        let _0x4029f6;
        new MutationObserver(function (_0x33d510, _0x31af01) {
          (_0x4029f6 && clearTimeout(_0x4029f6),
            (_0x4029f6 = setTimeout(() => {
              _0x576681();
            }, 0x32)));
        })["observe"](document["body"], { childList: !0x0, subtree: !0x0 });
      }
    },
  ));
