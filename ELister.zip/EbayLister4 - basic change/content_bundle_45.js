(console["log"]("content/amazon/auto_order/product_page/content.js\x20loaded"),
  console["log"](
    "content/amazon/auto_order/product_page/content.js\x20loaded",
  ));
async function _0xd5e881() {
  var _0x564620 = window["location"]["href"];
  console["log"]("url\x20getOrderDetailsUrl", _0x564620);
  var _0x3d8243 = await new URLSearchParams(window["location"]["search"]);
  console["log"]("urlParams", _0x3d8243);
  var _0x100911 = await _0x3d8243["get"]("orderDetails");
  console["log"]("rawParam", _0x100911);
  var _0x4bbf6c;
  try {
    _0x4bbf6c = await JSON["parse"](decodeURIComponent(_0x100911));
  } catch (_0x376887) {
    console["log"]("error", _0x376887);
  }
  return (
    !_0x4bbf6c &&
      (console["log"](
        "order\x20details\x20not\x20found\x20in\x20url\x20param,\x20trying\x20to\x20parse\x20raw\x20param",
      ),
      (_0x4bbf6c = await JSON["parse"](_0x100911))),
    console["log"]("orderDetails", _0x4bbf6c),
    _0x4bbf6c
  );
}
async function _0x4dae27() {
  var _0x22b91d = await _0xd5e881();
  (console["log"]("orderDetails", _0x22b91d),
    chrome["runtime"]["sendMessage"]({
      type: "order_item_same_browser",
      orderDetails: _0x22b91d,
    }));
}
_0x4dae27();
