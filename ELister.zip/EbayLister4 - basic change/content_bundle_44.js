function _0x1975f0(
  _0x184d73,
  _0x4d8482 = 0x3e8,
  {
    titlePrefix: titlePrefix = "Auto\x20Order",
    position: position = "top-left",
    scale: scale = 1.25,
    autoShowHud: autoShowHud = !0x0,
    fadeOutMs: fadeOutMs = 0x5dc,
  } = {},
) {
  let _0x593342 = Promise["resolve"](),
    _0xccdbe0 = null,
    _0x475492 = 0x0,
    _0x1217e0 = null;
  function _0x36f6c3(_0x4d86e0, _0x9674b8 = "#fff") {
    (function () {
      return (
        !_0x1217e0 &&
          (document["querySelectorAll"]("link[rel*=\x27icon\x27]")["forEach"](
            (_0x5b8918) => _0x5b8918["remove"](),
          ),
          (_0x1217e0 = document["createElement"]("link")),
          (_0x1217e0["rel"] = "icon"),
          document["head"]["appendChild"](_0x1217e0)),
        _0x1217e0
      );
    })()["href"] = (function (_0x13768e, _0x5f5010 = "#fff") {
      const _0x552ad2 = document["createElement"]("canvas");
      ((_0x552ad2["width"] = 0x40), (_0x552ad2["height"] = 0x40));
      const _0xef82aa = _0x552ad2["getContext"]("2d");
      return (
        (_0xef82aa["fillStyle"] = _0x5f5010),
        _0xef82aa["fillRect"](0x0, 0x0, 0x40, 0x40),
        (_0xef82aa["font"] = "48px\x20serif"),
        (_0xef82aa["textAlign"] = "center"),
        (_0xef82aa["textBaseline"] = "middle"),
        _0xef82aa["fillText"](_0x13768e, 0x20, 0x28),
        _0x552ad2["toDataURL"]("image/png")
      );
    })(_0x4d86e0, _0x9674b8);
  }
  const _0xca04e2 = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
  let _0x2d2429 = null,
    _0x948f8c = 0x0,
    _0x322693 = "";
  function _0x38d9c3(_0xc2c05a) {
    ((_0x322693 = _0xc2c05a), _0x3075a6());
    const _0x3a0df9 = titlePrefix + ":\x20" + _0xc2c05a,
      _0x345a8c = () => {
        document["title"] =
          _0xca04e2[_0x948f8c++ % _0xca04e2["length"]] + "\x20" + _0x3a0df9;
      };
    _0x345a8c();
    const _0x188950 = () => (document["hidden"] ? 0x190 : 0x78);
    ((_0x2d2429 = setInterval(_0x345a8c, _0x188950())),
      document["addEventListener"](
        "visibilitychange",
        () => {
          _0x2d2429 &&
            (clearInterval(_0x2d2429),
            (_0x2d2429 = setInterval(_0x345a8c, _0x188950())));
        },
        { once: !0x0 },
      ));
  }
  function _0x3075a6(_0x4a81c2 = "") {
    (_0x2d2429 && (clearInterval(_0x2d2429), (_0x2d2429 = null)),
      _0x4a81c2
        ? (document["title"] = titlePrefix + ":\x20" + _0x4a81c2)
        : _0x322693 && (document["title"] = titlePrefix + ":\x20" + _0x322693));
  }
  let _0x296c66 = null,
    _0x1c35e9 = !0x1;
  function _0x3a91b9() {
    if (_0x296c66) return _0x296c66;
    return (
      !(function () {
        if (_0x1c35e9) return;
        _0x1c35e9 = !0x0;
        const _0x5892cf = document["createElement"]("style");
        ((_0x5892cf["textContent"] =
          "\x0a\x20\x20\x20\x20\x20\x20.ao-hud{position:fixed;z-index:2147483647;display:inline-flex;align-items:flex-start;gap:12px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20background:rgba(18,20,23,.96);color:#e7f3ff;border:1px\x20solid\x20rgba(255,255,255,.1);\x0a\x20\x20\x20\x20\x20\x20\x20\x20padding:12px\x2014px;border-radius:14px;box-shadow:0\x2010px\x2030px\x20rgba(0,0,0,.35);\x0a\x20\x20\x20\x20\x20\x20\x20\x20font:600\x2014px/1.35\x20system-ui,-apple-system,Segoe\x20UI,Roboto,sans-serif;pointer-events:none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20opacity:0;transform:translateY(-6px);transition:opacity\x20.18s,transform\x20.18s}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.show{opacity:1;transform:translateY(0)}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.tl{top:16px;left:16px;transform-origin:\x20top\x20left}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.tr{top:16px;right:16px;transform-origin:\x20top\x20right}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.bl{bottom:16px;left:16px;transform-origin:\x20bottom\x20left}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.br{bottom:16px;right:16px;transform-origin:\x20bottom\x20right}\x0a\x0a\x20\x20\x20\x20\x20\x20.ao-spin{width:22px;height:22px;border-radius:50%;border:3px\x20solid\x20currentColor;border-right-color:transparent;animation:ao-rot\x20.7s\x20linear\x20infinite}\x0a\x20\x20\x20\x20\x20\x20@keyframes\x20ao-rot{to{transform:rotate(360deg)}}\x0a\x20\x20\x20\x20\x20\x20.ao-icon{font-size:20px;display:none}\x0a\x0a\x20\x20\x20\x20\x20\x20/*\x20Allow\x20wrapping\x20instead\x20of\x20single-line\x20ellipsis\x20*/\x0a\x20\x20\x20\x20\x20\x20.ao-text{\x0a\x20\x20\x20\x20\x20\x20\x20\x20white-space:\x20normal;\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20was:\x20nowrap\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20word-break:\x20break-word;\x0a\x20\x20\x20\x20\x20\x20\x20\x20overflow:\x20visible;\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20was:\x20hidden\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20text-overflow:\x20initial;\x20\x20\x20\x20\x20\x20/*\x20was:\x20ellipsis\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20max-width:\x20min(60vw,\x20720px);\x20/*\x20keep\x20it\x20readable\x20on\x20wide\x20screens\x20*/\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20.ao-hud.done{color:#19c37d}.ao-hud.error{color:#ff6b6b}\x0a\x20\x20\x20\x20"),
          document["head"]["appendChild"](_0x5892cf));
      })(),
      (_0x296c66 = document["createElement"]("div")),
      (_0x296c66["className"] =
        "ao-hud\x20" +
        ("top-right" === position
          ? "tr"
          : "bottom-left" === position
            ? "bl"
            : "bottom-right" === position
              ? "br"
              : "tl")),
      (_0x296c66["style"]["scale"] = String(scale)),
      (_0x296c66["innerHTML"] =
        "\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-spin\x22\x20aria-hidden=\x22true\x22></div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-icon\x22\x20aria-hidden=\x22true\x22>✅</div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-text\x22\x20aria-live=\x22polite\x22\x20aria-atomic=\x22true\x22></div>\x0a\x20\x20\x20\x20"),
      document["body"]["appendChild"](_0x296c66),
      _0x296c66
    );
  }
  function _0x570ef1() {
    return _0x593342;
  }
  return (
    _0x36f6c3("🟡", "#fff"),
    {
      update: function (
        _0x45dabc,
        {
          delayMs: delayMs = _0x4d8482,
          coalesce: coalesce = !0x0,
          showHud: showHud = autoShowHud,
        } = {},
      ) {
        if (coalesce && _0x45dabc === _0xccdbe0) return _0x593342;
        _0xccdbe0 = _0x45dabc;
        const _0x5088ba = _0x475492;
        return (
          _0x36f6c3("🟡", "#fff"),
          showHud
            ? (function (_0x34ea0a) {
                if (!autoShowHud) {
                  _0x38d9c3(_0x34ea0a);
                  return;
                }
                const _0x1f3448 = _0x3a91b9();
                (_0x1f3448["classList"]["remove"]("done", "error"),
                  _0x1f3448["classList"]["add"]("show"),
                  (_0x1f3448["querySelector"](".ao-spin")["style"]["display"] =
                    ""),
                  (_0x1f3448["querySelector"](".ao-icon")["style"]["display"] =
                    "none"),
                  (_0x1f3448["querySelector"](".ao-text")["textContent"] =
                    _0x34ea0a),
                  _0x38d9c3(_0x34ea0a));
              })(_0x45dabc)
            : _0x38d9c3(_0x45dabc),
          (_0x593342 = _0x593342["then"](async () => {
            if (_0x5088ba !== _0x475492) return;
            const _0x22fcb8 = document["getElementById"](_0x184d73);
            (_0x22fcb8 && (_0x22fcb8["innerText"] = _0x45dabc),
              await ((_0x424685 = delayMs),
              new Promise((_0x534463) => setTimeout(_0x534463, _0x424685))));
            var _0x424685;
          })["catch"](() => {})),
          _0x593342
        );
      },
      cancel: function () {
        _0x475492++;
      },
      whenIdle: _0x570ef1,
      finish: async function (_0x2aa755 = "Complete") {
        (await _0x570ef1(),
          _0x36f6c3("✅", "#fff"),
          !(function (_0x46e5cd) {
            (autoShowHud &&
              (_0x3a91b9(),
              _0x296c66["classList"]["remove"]("error"),
              _0x296c66["classList"]["add"]("done", "show"),
              (_0x296c66["querySelector"](".ao-spin")["style"]["display"] =
                "none"),
              (_0x296c66["querySelector"](".ao-icon")["style"]["display"] = ""),
              (_0x296c66["querySelector"](".ao-icon")["textContent"] = "✅"),
              (_0x296c66["querySelector"](".ao-text")["textContent"] =
                _0x46e5cd),
              fadeOutMs > 0x0 &&
                setTimeout(
                  () => _0x296c66["classList"]["remove"]("show"),
                  fadeOutMs,
                )),
              _0x3075a6(_0x46e5cd));
          })(_0x2aa755));
      },
      error: function (_0x4e75db = "Failed") {
        (_0x36f6c3("❌", "#fff"),
          !(function (_0x49929c) {
            (autoShowHud &&
              (_0x3a91b9(),
              _0x296c66["classList"]["remove"]("done"),
              _0x296c66["classList"]["add"]("error", "show"),
              (_0x296c66["querySelector"](".ao-spin")["style"]["display"] =
                "none"),
              (_0x296c66["querySelector"](".ao-icon")["style"]["display"] = ""),
              (_0x296c66["querySelector"](".ao-icon")["textContent"] = "❌"),
              (_0x296c66["querySelector"](".ao-text")["textContent"] =
                _0x49929c)),
              _0x3075a6(_0x49929c));
          })(_0x4e75db));
      },
    }
  );
}
function _0x5b562c() {
  return new Promise((_0x4d097e) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x4d097e();
      });
    });
  });
}
function _0x68c248() {
  return new Promise((_0x4b2127) => {
    requestIdleCallback(() => {
      _0x4b2127();
    });
  });
}
function _0x3a704d(_0x47fb49 = 0x3e8) {
  return new Promise((_0xeb16f1, _0x517cc7) => {
    let _0x58f244,
      _0x1900b0 = Date["now"](),
      _0x223aa8 = !0x1;
    function _0x2f83a0() {
      if (Date["now"]() - _0x1900b0 > _0x47fb49)
        (_0x223aa8 && _0x58f244["disconnect"](), _0xeb16f1());
      else setTimeout(_0x2f83a0, _0x47fb49);
    }
    const _0x10318 = () => {
        _0x1900b0 = Date["now"]();
      },
      _0x535818 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x58f244 = new MutationObserver(_0x10318)),
        _0x58f244["observe"](document["body"], _0x535818),
        (_0x223aa8 = !0x0),
        setTimeout(_0x2f83a0, _0x47fb49));
    else
      window["onload"] = () => {
        ((_0x58f244 = new MutationObserver(_0x10318)),
          _0x58f244["observe"](document["body"], _0x535818),
          (_0x223aa8 = !0x0),
          setTimeout(_0x2f83a0, _0x47fb49));
      };
  });
}
async function _0x3f24f7() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x3a704d(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x4c0935() {
  return await new Promise(function (_0xc2af60, _0x135ca0) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x529ab1) {
        (console["log"]("result:\x20", _0x529ab1["membership"]),
          _0xc2af60(_0x529ab1["membership"]));
      },
    );
  });
}
async function _0x563f4d() {
  return await new Promise(function (_0x1f6866, _0x2044e7) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x2d2e03) {
        (console["log"]("result:\x20", _0x2d2e03["creditsAvailable"]),
          _0x1f6866(_0x2d2e03["creditsAvailable"]));
      },
    );
  });
}
async function _0x1fdb64(_0x229550) {
  if ("ultimate" != (await _0x4c0935()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x563f4d()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
var _0x90a471 = (_0x1dcece, _0x26c6a2) => {
  var _0x2174e7 = document["querySelector"](_0x1dcece);
  console["log"]("Checking");
  if (_0x2174e7) return (console["log"]("Found"), _0x26c6a2(_0x2174e7));
  setTimeout(() => _0x90a471(_0x1dcece, _0x26c6a2), 0x1f4);
};
function _0x4fc79a(_0x24285b, _0x460555 = 0x32, _0x443c91 = 0x64) {
  const _0x7b5b48 = document["querySelector"](_0x24285b);
  !window["__" + _0x24285b] &&
    ((window["__" + _0x24285b] = 0x0),
    (window["__" + _0x24285b + "__delay"] = _0x460555),
    (window["__" + _0x24285b + "__tries"] = _0x443c91));
  if (null === _0x7b5b48) {
    if (window["__" + _0x24285b] >= window["__" + _0x24285b + "__tries"])
      return ((window["__" + _0x24285b] = 0x0), Promise["resolve"](null));
    return new Promise((_0x36e2c3) => {
      (window["__" + _0x24285b]++,
        setTimeout(_0x36e2c3, window["__" + _0x24285b + "__delay"]));
    })["then"](() => _0x4fc79a(_0x24285b));
  }
  return Promise["resolve"](_0x7b5b48);
}
function _0x4a22cf(
  _0x521e62 = document,
  _0x6ee35,
  _0x140507 = 0x32,
  _0x5b2093 = 0x64,
) {
  const _0x573370 = _0x521e62["querySelector"](_0x6ee35);
  !window["__" + _0x6ee35] &&
    ((window["__" + _0x6ee35] = 0x0),
    (window["__" + _0x6ee35 + "__delay"] = _0x140507),
    (window["__" + _0x6ee35 + "__tries"] = _0x5b2093));
  if (null === _0x573370) {
    if (window["__" + _0x6ee35] >= window["__" + _0x6ee35 + "__tries"])
      return ((window["__" + _0x6ee35] = 0x0), Promise["resolve"](null));
    return new Promise((_0x367164) => {
      (window["__" + _0x6ee35]++,
        setTimeout(_0x367164, window["__" + _0x6ee35 + "__delay"]));
    })["then"](() => _0x4fc79a(_0x6ee35));
  }
  return Promise["resolve"](_0x573370);
}
async function _0x35b77b(_0x2e4cc8, _0x9e560d = 0xea60) {
  return new Promise((_0x13fc3a, _0x391029) => {
    const _0x380c21 = setInterval(() => {
      const _0x1b2457 = document["querySelector"](_0x2e4cc8);
      if (_0x1b2457)
        (console["log"]("Found\x20element\x20for\x20selector\x20" + _0x2e4cc8),
          clearInterval(_0x380c21),
          _0x13fc3a(_0x1b2457));
      else
        console["log"](
          "Waiting\x20for\x20element\x20for\x20selector\x20" + _0x2e4cc8,
        );
    }, 0x64);
    setTimeout(() => {
      (console["log"](
        "Timed\x20out\x20after\x20" +
          _0x9e560d +
          "\x20ms\x20for\x20selector\x20" +
          _0x2e4cc8,
      ),
        clearInterval(_0x380c21),
        _0x391029(
          new Error(
            "Timed\x20out\x20after\x20" +
              _0x9e560d +
              "\x20ms\x20for\x20selector\x20" +
              _0x2e4cc8,
          ),
        ));
    }, _0x9e560d);
  });
}
async function _0x73409(_0x360a93, _0x214899 = 0x2710, _0x51c5a2 = 0x1f4) {
  const _0xd0bb7e = Date["now"]() + _0x214899;
  for (; Date["now"]() < _0xd0bb7e; ) {
    const _0x3bf493 = document["querySelector"](_0x360a93);
    if (_0x3bf493) return _0x3bf493;
    await new Promise((_0xbeb75) => setTimeout(_0xbeb75, _0x51c5a2));
  }
  return (
    console["error"](
      "Timed\x20out\x20waiting\x20for\x20element:\x20" + _0x360a93,
    ),
    null
  );
}
async function _0x47f1c3(_0x14b500, _0x162eb7 = 0x2710, _0x5f43c7 = 0x1f4) {
  const _0x4aa64c = Date["now"]() + _0x162eb7;
  for (; Date["now"]() < _0x4aa64c; ) {
    for (let _0x24b8e2 = 0x0; _0x24b8e2 < _0x14b500["length"]; _0x24b8e2++) {
      const _0x12e9b3 = document["querySelector"](_0x14b500[_0x24b8e2]);
      if (_0x12e9b3) return _0x12e9b3;
    }
    await new Promise((_0x4e8cfd) => setTimeout(_0x4e8cfd, _0x5f43c7));
  }
  return (
    console["error"](
      "Timed\x20out\x20waiting\x20for\x20any\x20of\x20these\x20elements:\x20" +
        _0x14b500,
    ),
    null
  );
}
const _0x35ee0a = {
  Afghanistan: "AF",
  "Aland\x20Islands": "AX",
  Albania: "AL",
  Algeria: "DZ",
  "American\x20Samoa": "AS",
  Andorra: "AD",
  Angola: "AO",
  Anguilla: "AI",
  Antarctica: "AQ",
  "Antigua\x20and\x20Barbuda": "AG",
  Argentina: "AR",
  Armenia: "AM",
  Aruba: "AW",
  Australia: "AU",
  Austria: "AT",
  Azerbaijan: "AZ",
  "Bahamas,\x20The": "BS",
  Bahrain: "BH",
  Bangladesh: "BD",
  Barbados: "BB",
  Belarus: "BY",
  Belgium: "BE",
  Belize: "BZ",
  Benin: "BJ",
  Bermuda: "BM",
  Bhutan: "BT",
  Bolivia: "BO",
  "Bonaire,\x20Saint\x20Eustatius\x20and\x20Saba": "BQ",
  "Bosnia\x20and\x20Herzegovina": "BA",
  Botswana: "BW",
  "Bouvet\x20Island": "BV",
  Brazil: "BR",
  "British\x20Indian\x20Ocean\x20Territory": "IO",
  "Brunei\x20Darussalam": "BN",
  Bulgaria: "BG",
  "Burkina\x20Faso": "BF",
  Burundi: "BI",
  Cambodia: "KH",
  Cameroon: "CM",
  Canada: "CA",
  "Canary\x20Islands": "IC",
  "Cape\x20Verde": "CV",
  "Cayman\x20Islands": "KY",
  "Central\x20African\x20Republic": "CF",
  Chad: "TD",
  Chile: "CL",
  China: "CN",
  "Christmas\x20Island": "CX",
  "Cocos\x20(Keeling)\x20Islands": "CC",
  Colombia: "CO",
  Comoros: "KM",
  Congo: "CG",
  "Congo,\x20The\x20Democratic\x20Republic\x20of\x20the": "CD",
  "Cook\x20Islands": "CK",
  "Costa\x20Rica": "CR",
  "Cote\x20D\x27ivoire": "CI",
  Croatia: "HR",
  Curaçao: "CW",
  Cyprus: "CY",
  "Czech\x20Republic": "CZ",
  Denmark: "DK",
  Djibouti: "DJ",
  Dominica: "DM",
  "Dominican\x20Republic": "DO",
  Ecuador: "EC",
  Egypt: "EG",
  "El\x20Salvador": "SV",
  "Equatorial\x20Guinea": "GQ",
  Eritrea: "ER",
  Estonia: "EE",
  Ethiopia: "ET",
  "Falkland\x20Islands\x20(Malvinas)": "FK",
  "Faroe\x20Islands": "FO",
  Fiji: "FJ",
  Finland: "FI",
  France: "FR",
  "French\x20Guiana": "GF",
  "French\x20Polynesia": "PF",
  "French\x20Southern\x20Territories": "TF",
  Gabon: "GA",
  "Gambia,\x20The": "GM",
  Georgia: "GE",
  Germany: "DE",
  Ghana: "GH",
  Gibraltar: "GI",
  Greece: "GR",
  Greenland: "GL",
  Grenada: "GD",
  Guadeloupe: "GP",
  Guam: "GU",
  Guatemala: "GT",
  Guernsey: "GG",
  Guinea: "GN",
  "Guinea-Bissau": "GW",
  Guyana: "GY",
  Haiti: "HT",
  "Heard\x20Island\x20and\x20the\x20McDonald\x20Islands": "HM",
  "Holy\x20See": "VA",
  Honduras: "HN",
  "Hong\x20Kong": "HK",
  Hungary: "HU",
  Iceland: "IS",
  India: "IN",
  Indonesia: "ID",
  Iraq: "IQ",
  Ireland: "IE",
  "Isle\x20of\x20Man": "IM",
  Israel: "IL",
  Italy: "IT",
  Jamaica: "JM",
  Japan: "JP",
  Jersey: "JE",
  Jordan: "JO",
  Kazakhstan: "KZ",
  Kenya: "KE",
  Kiribati: "KI",
  Kosovo: "XK",
  Kuwait: "KW",
  Kyrgyzstan: "KG",
  "Lao\x20People\x27s\x20Democratic\x20Republic": "LA",
  Latvia: "LV",
  Lebanon: "LB",
  Lesotho: "LS",
  Liberia: "LR",
  Libya: "LY",
  Liechtenstein: "LI",
  Lithuania: "LT",
  Luxembourg: "LU",
  Macao: "MO",
  "Macedonia,\x20The\x20Former\x20Yugoslav\x20Republic\x20of": "MK",
  Madagascar: "MG",
  Malawi: "MW",
  Malaysia: "MY",
  Maldives: "MV",
  Mali: "ML",
  Malta: "MT",
  "Marshall\x20Islands": "MH",
  Martinique: "MQ",
  Mauritania: "MR",
  Mauritius: "MU",
  Mayotte: "YT",
  Mexico: "MX",
  "Micronesia,\x20Federated\x20States\x20of": "FM",
  "Moldova,\x20Republic\x20of": "MD",
  Monaco: "MC",
  Mongolia: "MN",
  Montenegro: "ME",
  Montserrat: "MS",
  Morocco: "MA",
  Mozambique: "MZ",
  Myanmar: "MM",
  Namibia: "NA",
  Nauru: "NR",
  Nepal: "NP",
  Netherlands: "NL",
  "Netherlands\x20Antilles": "AN",
  "New\x20Caledonia": "NC",
  "New\x20Zealand": "NZ",
  Nicaragua: "NI",
  Niger: "NE",
  Nigeria: "NG",
  Niue: "NU",
  "Norfolk\x20Island": "NF",
  "Northern\x20Mariana\x20Islands": "MP",
  Norway: "NO",
  Oman: "OM",
  Pakistan: "PK",
  Palau: "PW",
  "Palestinian\x20Territories": "PS",
  Panama: "PA",
  "Papua\x20New\x20Guinea": "PG",
  Paraguay: "PY",
  Peru: "PE",
  Philippines: "PH",
  Pitcairn: "PN",
  Poland: "PL",
  Portugal: "PT",
  "Puerto\x20Rico": "PR",
  Qatar: "QA",
  "Republic\x20of\x20Korea": "KR",
  Reunion: "RE",
  Romania: "RO",
  "Russian\x20Federation": "RU",
  Rwanda: "RW",
  "Saint\x20Barthelemy": "BL",
  "Saint\x20Helena,\x20Ascension\x20and\x20Tristan\x20da\x20Cunha": "SH",
  "Saint\x20Kitts\x20and\x20Nevis": "KN",
  "Saint\x20Lucia": "LC",
  "Saint\x20Martin": "MF",
  "Saint\x20Pierre\x20and\x20Miquelon": "PM",
  "Saint\x20Vincent\x20and\x20the\x20Grenadines": "VC",
  Samoa: "WS",
  "San\x20Marino": "SM",
  "Sao\x20Tome\x20and\x20Principe": "ST",
  "Saudi\x20Arabia": "SA",
  Senegal: "SN",
  Serbia: "RS",
  Seychelles: "SC",
  "Sierra\x20Leone": "SL",
  Singapore: "SG",
  "Sint\x20Maarten": "SX",
  Slovakia: "SK",
  Slovenia: "SI",
  "Solomon\x20Islands": "SB",
  Somalia: "SO",
  "South\x20Africa": "ZA",
  "South\x20Georgia\x20and\x20the\x20South\x20Sandwich\x20Islands": "GS",
  Spain: "ES",
  "Sri\x20Lanka": "LK",
  Suriname: "SR",
  "Svalbard\x20and\x20Jan\x20Mayen": "SJ",
  Swaziland: "SZ",
  Sweden: "SE",
  Switzerland: "CH",
  Taiwan: "TW",
  Tajikistan: "TJ",
  "Tanzania,\x20United\x20Republic\x20of": "TZ",
  Thailand: "TH",
  "Timor-leste": "TL",
  Togo: "TG",
  Tokelau: "TK",
  Tonga: "TO",
  "Trinidad\x20and\x20Tobago": "TT",
  Tunisia: "TN",
  Turkey: "TR",
  Turkmenistan: "TM",
  "Turks\x20and\x20Caicos\x20Islands": "TC",
  Tuvalu: "TV",
  Uganda: "UG",
  Ukraine: "UA",
  "United\x20Arab\x20Emirates": "AE",
  "United\x20Kingdom": "GB",
  "United\x20States": "US",
  "United\x20States\x20Minor\x20Outlying\x20Islands": "UM",
  Uruguay: "UY",
  Uzbekistan: "UZ",
  Vanuatu: "VU",
  Venezuela: "VE",
  Vietnam: "VN",
  "Virgin\x20Islands,\x20British": "VG",
  "Virgin\x20Islands,\x20U.S.": "VI",
  "Wallis\x20and\x20Futuna": "WF",
  "Western\x20Sahara": "EH",
  Yemen: "YE",
  Zambia: "ZM",
  Zimbabwe: "ZW",
};
function _0x3a552f(_0x2d1a34) {
  const _0x523daf = _0x2d1a34["toLowerCase"](),
    _0x434738 = Object["keys"](_0x35ee0a)["find"](
      (_0x2a7874) => _0x2a7874["toLowerCase"]() === _0x523daf,
    );
  return _0x434738 ? _0x35ee0a[_0x434738] : _0x2d1a34;
}
const _0x2c2aca = {
  Alabama: "AL",
  Alaska: "AK",
  Arizona: "AZ",
  Arkansas: "AR",
  California: "CA",
  Colorado: "CO",
  Connecticut: "CT",
  Delaware: "DE",
  Florida: "FL",
  Georgia: "GA",
  Hawaii: "HI",
  Idaho: "ID",
  Illinois: "IL",
  Indiana: "IN",
  Iowa: "IA",
  Kansas: "KS",
  Kentucky: "KY",
  Louisiana: "LA",
  Maine: "ME",
  Maryland: "MD",
  Massachusetts: "MA",
  Michigan: "MI",
  Minnesota: "MN",
  Mississippi: "MS",
  Missouri: "MO",
  Montana: "MT",
  Nebraska: "NE",
  Nevada: "NV",
  "New\x20Hampshire": "NH",
  "New\x20Jersey": "NJ",
  "New\x20Mexico": "NM",
  "New\x20York": "NY",
  "North\x20Carolina": "NC",
  "North\x20Dakota": "ND",
  Ohio: "OH",
  Oklahoma: "OK",
  Oregon: "OR",
  Pennsylvania: "PA",
  "Rhode\x20Island": "RI",
  "South\x20Carolina": "SC",
  "South\x20Dakota": "SD",
  Tennessee: "TN",
  Texas: "TX",
  Utah: "UT",
  Vermont: "VT",
  Virginia: "VA",
  Washington: "WA",
  "West\x20Virginia": "WV",
  Wisconsin: "WI",
  Wyoming: "WY",
  Alberta: "AB",
  "British\x20Columbia": "BC",
  Manitoba: "MB",
  "New\x20Brunswick": "NB",
  "Newfoundland\x20and\x20Labrador": "NL",
  "Northwest\x20Territories": "NT",
  "Nova\x20Scotia": "NS",
  Ontario: "ON",
  "Prince\x20Edward\x20Island": "PE",
  Quebec: "QC",
  Saskatchewan: "SK",
  Yukon: "YT",
};
function _0x4352dd(_0x20a054) {
  const _0x129ad0 = _0x20a054["toLowerCase"](),
    _0x314835 = Object["keys"](_0x2c2aca)["find"](
      (_0x2e63f8) => _0x2e63f8["toLowerCase"]() === _0x129ad0,
    );
  return _0x314835 ? _0x2c2aca[_0x314835] : _0x20a054;
}
function _0x2cac62(_0x44893b) {
  const _0x2a7374 = _0x44893b["toUpperCase"]();
  return (
    Object["keys"](_0x2c2aca)["find"](
      (_0x50427b) => _0x2c2aca[_0x50427b] === _0x2a7374,
    ) || _0x44893b
  );
}
console["log"]("content/amazon/auto_order/checkout/functions.js\x20loaded");
async function _0x239cc7(_0x301e3d) {
  console["log"](
    "Checking\x20if\x20address\x20is\x20already\x20set",
    _0x301e3d,
  );
  const _0x53754b = [
      ".displayAddressLI.displayAddressFullName",
      "#deliver-to-customer-text",
    ],
    _0x2841d1 = (_0x301e3d?.["customer"]?.["name"] || "")
      ["trim"]()
      ["toLowerCase"]();
  console["log"]("customerName", _0x2841d1);
  for (let _0x27e08e of _0x53754b) {
    const _0x52b63d = document["querySelector"](_0x27e08e);
    if (_0x52b63d && _0x52b63d["innerText"]) {
      const _0x4a261a = _0x52b63d["innerText"]["trim"]()["toLowerCase"]();
      console["log"](
        "Found\x20Amazon\x20address\x20name",
        _0x4a261a,
        "with\x20selector",
        _0x27e08e,
      );
      if (_0x4a261a["includes"](_0x2841d1))
        return (console["log"]("Address\x20already\x20set"), !0x0);
    }
  }
  return (console["log"]("Address\x20not\x20set"), !0x1);
}
async function _0x19bd47(_0x46c57a) {
  ((document["title"] = "#1\x20Setting\x20Delivery\x20Address"),
    console["log"]("Setting\x20delivery\x20address", _0x46c57a));
  if (await _0x239cc7(_0x46c57a))
    console["log"](
      "Address\x20already\x20set,\x20skipping\x20setting\x20address",
    );
  else {
    (await _0x1391de(),
      console["log"]("showAddressForm\x20function\x20done"),
      (document["title"] =
        "#8\x20Waiting\x20for\x20Update\x20Address\x20Button"),
      await new Promise((_0x3d517c) => setTimeout(_0x3d517c, 0x3e8)));
    var _0xc5e14d = await _0x47f1c3(
      [
        ".a-popover-wrapper\x20#address-ui-widgets-form-submit-button",
        ".a-popover-wrapper\x20[data-csa-c-slot-id=\x22address-ui-widgets-continue-edit-address-btn-bottom\x22]",
        ".a-popover-wrapper\x20[data-csa-c-slot-id=\x22address-ui-widgets-continue-address-btn-bottom\x22]",
        ".a-popover-wrapper\x20[address-ui-widgets-form-submit-button-announce]",
      ],
      0x61a8,
      0x64,
    );
    (console["log"]("updateAddressButton\x20Element", _0xc5e14d),
      (document["title"] = "#9\x20Clicking\x20Update\x20Address\x20Button"),
      await _0xd6f4a3(_0x46c57a["customer"]),
      (document["title"] =
        "#9.9\x20address\x20set,\x20attempting\x20to\x20click\x20update\x20address\x20button"),
      console["log"]("address\x20set"),
      console["log"]("updateAddressButton", _0xc5e14d));
    var _0x417bd5 = _0x23453f();
    (console["log"]("submitButton", _0x417bd5),
      _0x417bd5 &&
        (_0x417bd5["click"](),
        await _0x2d3c1c(),
        console["log"]("Delivery\x20form\x20closed,\x20address\x20set.")));
  }
}
async function _0x2d3c1c(_0x43180e = 0x4e20) {
  Date["now"]();
  for (;;) {
    if (
      !document["querySelector"](
        ".a-popover\x20#address-ui-widgets-enterAddressFullName,\x20\x20\x20\x20\x20\x20\x20\x20.a-popover\x20#address-ui-widgets-enterAddressLine1,\x20\x20\x20\x20\x20\x20\x20\x20.a-popover\x20#address-ui-widgets-enterAddressPostalCode",
      )
    )
      return !0x0;
    await new Promise((_0x5c2c8f) => setTimeout(_0x5c2c8f, 0x96));
  }
}
async function _0x377cd2(_0x15fec6 = 0x4e20) {
  var _0x3ead07 = document["querySelector"](
    "#address-ui-widgets-enterAddressFormContainer",
  );
  if (_0x3ead07) {
    var _0x481f8b = _0x3ead07["querySelectorAll"](".a-box");
    if (0x0 != _0x481f8b["length"]) {
      var _0x5dec28 = _0x481f8b[0x0]["querySelector"](
        "input[type=\x22radio\x22]",
      );
      if (_0x5dec28) {
        (_0x5dec28["click"](),
          await new Promise((_0x5d5aa8) => setTimeout(_0x5d5aa8, 0x7d0)));
        var _0x118e18 = document["querySelector"](
          "#pagelet-layout-section\x20#checkout-primary-continue-button-id",
        );
        _0x118e18 && _0x118e18["click"]();
        var _0x16b89f = Date["now"]();
        for (
          ;
          document["querySelector"](
            "#pagelet-layout-section\x20#checkout-primary-continue-button-id",
          );

        ) {
          if (Date["now"]() - _0x16b89f > _0x15fec6) {
            console["log"](
              "Timeout\x20waiting\x20for\x20delivery\x20form\x20to\x20close",
            );
            return;
          }
          await new Promise((_0x54cfd3) => setTimeout(_0x54cfd3, 0x1f4));
        }
        (console["log"]("Delivery\x20form\x20closed"),
          await new Promise((_0x1197e2) => setTimeout(_0x1197e2, 0x7d0)));
      } else
        console["log"](
          "No\x20radio\x20button\x20found,\x20assuming\x20form\x20is\x20closed",
        );
    } else
      console["log"](
        "No\x20a-box\x20elements\x20found,\x20assuming\x20form\x20is\x20closed",
      );
  } else
    console["log"](
      "Popover\x20not\x20found,\x20assuming\x20form\x20is\x20closed",
    );
}
function _0x23453f() {
  var _0x102b9b = [
      ".a-popover-wrapper\x20#address-ui-widgets-form-submit-button",
      ".a-popover-wrapper\x20[data-csa-c-slot-id=\x22address-ui-widgets-continue-edit-address-btn-bottom\x22]",
      ".a-popover-wrapper\x20[data-csa-c-slot-id=\x22address-ui-widgets-continue-address-btn-bottom\x22]",
      ".a-popover-wrapper\x20[address-ui-widgets-form-submit-button-announce]",
    ],
    _0x16756e = null;
  for (var _0x1f0df2 = 0x0; _0x102b9b["length"]; _0x1f0df2++) {
    console["log"]("updateAddressButtonSelectors[i]", _0x102b9b[_0x1f0df2]);
    var _0x2e74b9 = document["querySelector"](_0x102b9b[_0x1f0df2]);
    if (_0x2e74b9)
      return (
        console["log"]("updateAddressButton\x20found", _0x2e74b9),
        "INPUT" == _0x2e74b9["tagName"] && "submit" == _0x2e74b9["type"]
          ? _0x2e74b9
          : _0x2e74b9["querySelector"]("input[type=\x22submit\x22]")
      );
  }
  return _0x16756e;
}
async function _0x1391de() {
  document["title"] = "#2\x20Showing\x20Address\x20Form";
  if (
    !(_0x4d8c58 = document["querySelector"]("a[id*=\x22add-new-address\x22]"))
  ) {
    (console["log"](
      "Add\x20New\x20Address\x20Button\x20not\x20found,\x20trying\x20to\x20click\x20change\x20address\x20link",
    ),
      (document["title"] = "#3\x20Clicking\x20Address\x20Change\x20Link"),
      document["querySelector"](
        "a[id*=\x22addressChangeLinkId\x22],\x20[data-args=\x22redirectReason=shipaddressselectChangeClicked\x22]",
      )["click"]());
    try {
      ((document["title"] = "#4\x20Waiting\x20for\x20Address\x20Form"),
        await _0x360ab3("a[id*=\x22add-new-address\x22]", 0x4e20),
        console["log"]("Add\x20New\x20Address\x20Button\x20appeared"));
    } catch (_0x30d932) {
      ((document["title"] = "#5\x20Error\x20Waiting\x20for\x20Address\x20Form"),
        await _0x1391de(),
        console["log"](
          "Error\x20waiting\x20for\x20Add\x20New\x20Address\x20Button",
          _0x30d932,
        ));
    }
  }
  document["title"] = "#6\x20Clicking\x20Add\x20New\x20Address\x20Button";
  var { whichAmazonAddressToEdit: _0x4d01da } = await chrome["storage"][
    "local"
  ]["get"](["whichAmazonAddressToEdit"]);
  ((_0x4d01da = _0x4d01da || "4"),
    (_0x4d01da = parseInt(_0x4d01da)),
    (_0x4d01da -= 0x1));
  var _0x28f082 = document["querySelectorAll"]("a[id*=\x22edit-address\x22]");
  if (_0x28f082["length"] > _0x4d01da)
    (console["log"]("Clicking\x20Edit\x20Address\x20Button"),
      _0x28f082[_0x4d01da]["click"]());
  else {
    var _0x136375 = document["querySelectorAll"](
      "span[class*=\x22address-edit-link\x22]",
    );
    if (_0x136375["length"] > _0x4d01da)
      (console["log"]("Clicking\x20Edit\x20Address\x20Link"),
        _0x136375[_0x4d01da]["querySelector"]("a")["click"]());
    else {
      var _0x4d8c58;
      if (
        !(_0x4d8c58 = document["querySelector"](
          "a[id*=\x22add-new-address\x22]",
        ))
      )
        return (
          (document["title"] =
            "#7\x20Waiting\x20for\x20Add\x20New\x20Address\x20Button"),
          null
        );
      (console["log"]("Clicking\x20Add\x20New\x20Address\x20Button"),
        _0x4d8c58["click"]());
    }
  }
}
function _0x27d656() {
  var _0xf2ad54 = document["querySelector"](
    "select[id*=\x22address-ui-widgets-enterAddressCity\x22]",
  );
  return (
    _0xf2ad54 ||
      (_0xf2ad54 = document["querySelector"](
        ".a-popover\x20[id*=\x22address-ui-widgets-enterAddressCity\x22]",
      )),
    _0xf2ad54
  );
}
async function _0xd6f4a3(_0x54b0a2) {
  var _0x29b551 = document["querySelector"](
    ".a-popover\x20select[name=\x22address-ui-widgets-countryCode\x22]",
  );
  if (_0x29b551) {
    const _0xb06943 = _0x29b551["value"],
      _0x422512 = _0x3a552f(_0x54b0a2["address"]["country"]) || "US";
    _0xb06943 !== _0x422512 &&
      ((_0x29b551["value"] = _0x422512),
      _0x29b551["dispatchEvent"](new Event("change", { bubbles: !0x0 })),
      await new Promise((_0x447ce6) => setTimeout(_0x447ce6, 0x7d0)));
  }
  var _0x1a09a3 = document["querySelector"](
    ".a-popover\x20#address-ui-widgets-enterAddressFullName",
  );
  if (_0x1a09a3) {
    var _0x2cce89 = _0x54b0a2["name"];
    ((document["title"] = "#9.1\x20Setting\x20Full\x20Name:\x20" + _0x2cce89),
      (_0x1a09a3["value"] = _0x2cce89 || ""),
      _0x1a09a3["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
  }
  if (
    "Deutschland" == _0x54b0a2["address"]["country"] ||
    "Germany" == _0x54b0a2["address"]["country"]
  ) {
    var _0x40b4dd = _0x54b0a2["address"]["line_1"];
    ((_0x54b0a2["address"]["line_1"] = _0x54b0a2["address"]["line_2"]),
      (_0x54b0a2["address"]["line_2"] = _0x40b4dd));
  }
  var _0x3e2c12 = document["querySelector"](
    ".a-popover\x20#address-ui-widgets-enterAddressLine1",
  );
  _0x3e2c12 &&
    ((_0x3e2c12["value"] = _0x54b0a2["address"]["line_1"] || ""),
    _0x3e2c12["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    _0x3e2c12["dispatchEvent"](new Event("change", { bubbles: !0x0 })));
  var _0x2cdc5d = document["querySelector"](
    ".a-popover\x20#address-ui-widgets-enterAddressLine2",
  );
  _0x2cdc5d &&
    ((_0x2cdc5d["value"] = _0x54b0a2["address"]["line_2"] || ""),
    _0x2cdc5d["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
  var _0x5d6416 = document["querySelector"](
    ".a-popover\x20#address-ui-widgets-enterAddressPostalCode",
  );
  _0x5d6416 &&
    ((_0x5d6416["value"] = _0x54b0a2["address"]["zip"] || ""),
    _0x5d6416["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
  var _0x185944 = _0x27d656();
  if (_0x185944) {
    var _0x5985da = "SELECT" === _0x185944["tagName"],
      _0x75864 = 0x0;
    for (; _0x185944["disabled"] && _0x5985da && _0x75864 < 0xf; ) {
      (await new Promise((_0x5493fd) => setTimeout(_0x5493fd, 0x3e8)),
        console["log"](
          "Waiting\x20for\x20city\x20select\x20to\x20be\x20enabled...",
        ),
        (_0x5985da = "SELECT" === (_0x185944 = _0x27d656())["tagName"]),
        _0x75864++);
      if (!_0x185944["disabled"]) {
        (console["log"]("City\x20select\x20is\x20now\x20enabled"),
          await new Promise((_0x4ae335) => setTimeout(_0x4ae335, 0xfa0)));
        break;
      }
    }
    ((_0x185944["value"] = _0x54b0a2["address"]["city"] || ""),
      _0x185944["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
      _0x5985da && (await _0x52bc5f(_0x54b0a2["address"]["city"])));
  }
  var _0x426bf5 = document["querySelector"](
    ".a-popover\x20select[name=\x22address-ui-widgets-enterAddressStateOrRegion\x22]",
  );
  if (_0x426bf5) {
    var _0x493bcb = _0x54b0a2["address"]["state"];
    ("Canada" == _0x54b0a2["address"]["country"] &&
      (_0x493bcb = _0x2cac62(_0x54b0a2["address"]["state"])),
      console["log"]("State", _0x493bcb),
      (_0x426bf5["value"] = _0x493bcb),
      _0x426bf5["dispatchEvent"](new Event("change", { bubbles: !0x0 })));
  }
  var _0x21196a = document["querySelector"](
    ".a-popover\x20#address-ui-widgets-enterAddressPhoneNumber",
  );
  _0x21196a &&
    ((_0x21196a["value"] = _0x54b0a2["phone"] || ""),
    _0x21196a["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
}
async function _0x52bc5f(_0x4c5b35) {
  await new Promise((_0x379782) => setTimeout(_0x379782, 0xbb8));
  var _0x429d90 = _0x27d656();
  console["log"]("City\x20select\x20element:", _0x429d90);
  const _0x388cca = (_0xf99c0) => (_0xf99c0 || "")["trim"]()["toLowerCase"](),
    _0x145022 = Array["from"](_0x429d90["options"]),
    _0x5462bd =
      _0x145022["find"](
        (_0xe52371) => _0x388cca(_0xe52371["value"]) === _0x388cca(_0x4c5b35),
      ) ||
      _0x145022["find"](
        (_0x4bd22e) =>
          _0x388cca(_0x4bd22e["textContent"]) === _0x388cca(_0x4c5b35),
      );
  if (!_0x5462bd)
    return (
      console["error"](
        "City\x20\x22" + _0x4c5b35 + "\x22\x20not\x20found\x20in\x20dropdown",
      ),
      !0x1
    );
  return (
    _0x429d90["focus"](),
    (_0x429d90["value"] = _0x5462bd["value"]),
    _0x429d90["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    _0x429d90["dispatchEvent"](new Event("change", { bubbles: !0x0 })),
    _0x429d90["dispatchEvent"](new Event("blur", { bubbles: !0x0 })),
    console["log"]("City\x20set\x20to:\x20" + _0x5462bd["value"]),
    !0x0
  );
}
function _0x360ab3(_0x1cd5d1, _0x248fce = 0x1388) {
  return new Promise((_0xad5940, _0x38b2fe) => {
    const _0x219b06 = document["querySelector"](_0x1cd5d1);
    if (_0x219b06) {
      _0xad5940(_0x219b06);
      return;
    }
    const _0x5cbc03 = new MutationObserver((_0x7ed491, _0x3d5326) => {
      const _0x25c999 = document["querySelector"](_0x1cd5d1);
      _0x25c999 &&
        (_0x3d5326["disconnect"](),
        clearTimeout(_0x4e5790),
        _0xad5940(_0x25c999));
    });
    _0x5cbc03["observe"](document["body"], { childList: !0x0, subtree: !0x0 });
    const _0x4e5790 = setTimeout(() => {
      (_0x5cbc03["disconnect"](),
        _0x38b2fe(
          new Error(
            "Timeout:\x20Selector\x20\x22" +
              _0x1cd5d1 +
              "\x22\x20did\x20not\x20appear\x20within\x20" +
              _0x248fce +
              "ms",
          ),
        ));
    }, _0x248fce);
  });
}
async function _0x2b7fee(_0x21faa3, _0x53fd92, _0x2ac7c2, _0x451f06 = 0x61a8) {
  return new Promise((_0x4b938a, _0x5556c0) => {
    const _0x3a6a00 = new MutationObserver(() => {
      _0x21faa3["getAttribute"](_0x53fd92) === _0x2ac7c2 &&
        (_0x3a6a00["disconnect"](), _0x4b938a());
    });
    (_0x3a6a00["observe"](_0x21faa3, { attributes: !0x0 }),
      setTimeout(() => {
        (_0x3a6a00["disconnect"](),
          _0x5556c0(
            new Error(
              "Timeout:\x20Element\x20did\x20not\x20reach\x20state\x20\x22" +
                _0x53fd92 +
                "=" +
                _0x2ac7c2 +
                "\x22\x20within\x20" +
                _0x451f06 +
                "ms",
            ),
          ));
      }, _0x451f06));
  });
}
async function _0x45925b(_0x52c715, _0x3f4ae6, _0x437135 = 0x61a8) {
  return new Promise((_0x231774, _0x2542cf) => {
    const _0x5a6b9e = new MutationObserver(() => {
      !_0x52c715["hasAttribute"](_0x3f4ae6) &&
        (_0x5a6b9e["disconnect"](), _0x231774());
    });
    (_0x5a6b9e["observe"](_0x52c715, { attributes: !0x0 }),
      setTimeout(() => {
        (_0x5a6b9e["disconnect"](),
          _0x2542cf(
            new Error(
              "Timeout:\x20Element\x20did\x20not\x20lose\x20attribute\x20\x22" +
                _0x3f4ae6 +
                "\x22\x20within\x20" +
                _0x437135 +
                "ms",
            ),
          ));
      }, _0x437135));
  });
}
async function _0x41e7c9(_0x51d210) {
  var _0x5a5c12 = document["querySelector"]("#gift-message-sender-input-0");
  for (var _0x226c8f = 0x0; _0x226c8f < 0xa && !_0x5a5c12; _0x226c8f++) {
    (await new Promise((_0x4c64ca) => setTimeout(_0x4c64ca, 0x3e8)),
      (_0x5a5c12 = document["querySelector"]("#gift-message-sender-input-0")));
  }
  var _0x5dc96b;
  try {
    if (null == _0x51d210["giftMessage"])
      throw new Error("Gift\x20Message\x20is\x20undefined");
    _0x5dc96b = _0x51d210["giftMessage"];
  } catch (_0xef1e02) {
    (console["log"]("Gift\x20Message\x20is\x20undefined"), (_0x5dc96b = "-"));
  }
  var _0x1ba9dd;
  try {
    if (null == _0x51d210["giftMessageSender"])
      throw new Error("Gift\x20Message\x20Sender\x20is\x20undefined");
    _0x1ba9dd = _0x51d210["giftMessageSender"];
  } catch (_0x245b48) {
    (console["log"]("Gift\x20Message\x20Sender\x20is\x20undefined"),
      (_0x1ba9dd = "-"));
  }
  if (_0x5a5c12) {
    ((_0x5a5c12["value"] = _0x1ba9dd),
      _0x5a5c12["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
      (document["title"] = "#11\x20Setting\x20Gift\x20Message\x20Sender"),
      await new Promise((_0x5dc096) => setTimeout(_0x5dc096, 0x3e8)));
    var _0x40895f = document["querySelector"]("#message-area-0");
    _0x40895f &&
      (console["log"]("Setting\x20Gift\x20Message"),
      (_0x40895f["value"] = _0x5dc96b),
      _0x40895f["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
      (document["title"] = "#12\x20Setting\x20Gift\x20Message"),
      await new Promise((_0x283990) => setTimeout(_0x283990, 0x3e8)));
    var _0x61f03d = document["querySelector"](
      "[data-csa-c-slot-id=\x22checkout-primary-continue-giftselect\x22]",
    );
    if (_0x61f03d)
      (console["log"](
        "Clicking\x20Continue\x20Button\x20from\x20Gift\x20Message",
      ),
        _0x61f03d["click"](),
        await new Promise((_0x4772a4) => setTimeout(_0x4772a4, 0x3e8)));
    else {
      var _0x111f8a = document["querySelector"](
        "[data-a-modal*=\x22changeGiftOptionsPopover\x22]",
      );
      if (_0x111f8a) {
        (console["log"](
          "Clicking\x20Continue\x20Button\x20from\x20Gift\x20Message",
        ),
          _0x111f8a["click"](),
          await new Promise((_0x2c10c2) => setTimeout(_0x2c10c2, 0x3e8)));
        var _0x22d5e4 = document["querySelector"](
          "[data-testid=\x22GiftOptions_saveButton-0\x22]",
        );
        _0x22d5e4 &&
          (console["log"](
            "Clicking\x20Save\x20Button\x20from\x20Gift\x20Message",
          ),
          _0x22d5e4["click"](),
          await new Promise((_0x56b952) => setTimeout(_0x56b952, 0x3e8)));
      }
    }
  } else {
    var _0x1206d1 = document["querySelector"](
      "[data-pipeline-link-args=\x22redirectReason=ChooseGiftOptions\x22]",
    );
    if (_0x1206d1)
      return (
        _0x1206d1["click"](),
        await new Promise((_0x1a5df4) => setTimeout(_0x1a5df4, 0x3e8)),
        _0x41e7c9(_0x51d210)
      );
    console["log"]("Gift\x20Message\x20Sender\x20Input\x20not\x20found");
  }
}
async function _0x205af2() {
  var _0x5c1a99 = document["querySelectorAll"](
    "button[data-action=\x27a-popover-close\x27]",
  );
  for (var _0xfeea7d = 0x0; _0xfeea7d < _0x5c1a99["length"]; _0xfeea7d++) {
    (await new Promise((_0x169931) => setTimeout(_0x169931, 0x3e8)),
      _0x5c1a99[_0xfeea7d]["click"](),
      await new Promise((_0x427bbc) => setTimeout(_0x427bbc, 0x7d0)));
  }
}
console["log"]("content/amazon/auto_order/content.js\x20loaded");
var _0x26e83a = !0x1;
chrome["runtime"]["onMessage"]["addListener"](
  (_0x356b0a, _0x5aaa80, _0x3d06e2) => {
    console["log"]("Message\x20received", _0x356b0a);
    if (
      "autoOrder" === _0x356b0a["type"] &&
      "addToCart" === _0x356b0a["action"]
    ) {
      var _0x240077 = _0x356b0a["orderDetails"];
      (console["log"]("addToCart\x20message\x20received", _0x240077),
        _0x2810de(_0x240077));
    }
    ("autoOrder" === _0x356b0a["type"] &&
      "checkout" === _0x356b0a["action"] &&
      !_0x26e83a &&
      ((_0x26e83a = !0x0),
      console["log"]("checkout\x20message\x20received"),
      _0x3a704d()["then"](() => {
        _0x193d92(_0x356b0a["orderDetails"]);
      })),
      "autoOrder" === _0x356b0a["type"] &&
        "navigate_to_orders" === _0x356b0a["action"] &&
        console["log"]("navigate_to_orders\x20message\x20received"),
      "fill_address" === _0x356b0a["type"] &&
        (console["log"]("fill_address\x20message\x20received"),
        navigator["clipboard"]["readText"]()["then"]((_0x441fb9) => {
          console["log"]("Pasted\x20text:\x20", _0x441fb9);
          var _0x3848ed = JSON["parse"](_0x441fb9);
          (console["log"]("Parsed\x20JSON:\x20", _0x3848ed),
            _0xd6f4a3(_0x3848ed["customer"]));
        })));
  },
);
async function _0x19bd25(_0x18b887) {
  var _0xbb5b2c = null,
    _0x321a58 = await getAmazonItemData();
  console["log"]("Amazon\x20Data:\x20", _0x321a58);
  if (_0x321a58["isItemDeliveryExtended"])
    return {
      canOrder: !0x1,
      error: (_0xbb5b2c = "Item\x20delivery\x20is\x20extended"),
    };
  if (!_0x321a58["hasFreeShipping"])
    return {
      canOrder: !0x1,
      error: (_0xbb5b2c = "Item\x20does\x20not\x20have\x20free\x20shipping"),
    };
  if (!_0x321a58["isItemAvailable"])
    return {
      canOrder: !0x1,
      error: (_0xbb5b2c = "Item\x20is\x20not\x20available"),
    };
  var _0x4b0ac7 = _0x18b887["ebaySku"],
    _0x55cd83 = atob(_0x4b0ac7);
  return _0x321a58["sku"] !== _0x55cd83
    ? {
        canOrder: !0x1,
        error: (_0xbb5b2c =
          "The\x20Product\x20on\x20Amazon\x20CHANGED\x20-\x20Cannot\x20order\x20-\x20PLEASE\x20CHECK\x20BEFORE\x20PROCEEDING\x20TO\x20ORDER"),
      }
    : { canOrder: !0x0, error: _0xbb5b2c };
}
async function _0x2810de(_0x15bc01) {
  console["log"]("fullOrder", _0x15bc01);
  var { canOrder: _0x47eb2c, error: _0x2f8e98 } = await _0x19bd25(_0x15bc01);
  console["log"]("canOrder", _0x47eb2c, _0x2f8e98);
  if (_0x47eb2c) {
    var _0x5ce2f7 = _0x15bc01["quantitySold"];
    _0x5ce2f7 = parseInt(_0x5ce2f7);
    try {
      _0x5ce2f7 > 0x1 &&
        (await setQuantity(_0x5ce2f7),
        await new Promise((_0x7c9ef8) => setTimeout(_0x7c9ef8, 0x3e8)));
    } catch (_0x4ad481) {
      console["log"]("Error\x20setting\x20quantity", _0x4ad481);
    }
    (await checkCouponCode(),
      await _0x23dcdc(),
      console["log"]("Turbo\x20Checkout\x20check"));
    var _0x33c8eb = await new Promise((_0x50f9a8, _0x226887) => {
      var _0x3d7c6e = setInterval(() => {
        var _0x43c0f5 = document["querySelector"]("#turbo-checkout-frame");
        _0x43c0f5 && (clearInterval(_0x3d7c6e), _0x50f9a8(_0x43c0f5));
      }, 0x64);
    });
    console["log"]("Turbo\x20Checkout\x20Frame:\x20", _0x33c8eb);
    var _0x30e628 = await getAddToCartButton();
    (console["log"]("Add\x20to\x20Cart\x20Button:\x20", _0x30e628),
      _0x30e628["click"](),
      await new Promise((_0x39d0bd) => setTimeout(_0x39d0bd, 0x3e8)),
      _0x30e628["click"]());
    for (let _0x3016f9 = 0x0; _0x3016f9 < 0xa; _0x3016f9++) {
      var _0x556367 = document["querySelector"]("#attachSiNoCoverage");
      if (_0x556367) {
        _0x556367["click"]();
        break;
      }
      await new Promise((_0x1a39a3) => setTimeout(_0x1a39a3, 0x3e8));
    }
  } else {
    document["title"] =
      "❌\x20ERROR:\x20" +
      _0x2f8e98 +
      "\x20-\x20PLEASE\x20CHECK\x20BEFORE\x20PROCEEDING\x20TO\x20ORDER\x20-\x20" +
      document["title"];
    var _0x1a3050 = "ERROR:\x20" + _0x2f8e98;
    _0x15bc01["remarks"] = _0x1a3050;
    var _0x7a00e = await new Promise((_0x2abef6, _0x57b080) => {
      chrome["runtime"]["sendMessage"](
        { type: "submit_order_details", orderDetails: _0x15bc01 },
        (_0x2d9ea8) => {
          _0x2abef6(_0x2d9ea8);
        },
      );
    });
    console["log"](
      "Response\x20from\x20submitting\x20order\x20details\x20with\x20error",
      _0x7a00e,
    );
  }
}
async function _0x193d92(_0x4e0adb) {
  var _0x4dce51 = _0x1975f0("orderButton");
  (_0x4dce51["update"]("Setting\x20delivery\x20Address"),
    await _0x19bd47(_0x4e0adb),
    (document["title"] = "#10\x20Navigating\x20to\x20Checkout"),
    _0x4dce51["update"]("Navigating\x20to\x20Checkout,\x20Please\x20wait..."),
    console["log"]("Navigating\x20to\x20Checkout"),
    await new Promise((_0x3b9b60) => setTimeout(_0x3b9b60, 0xbb8)),
    await _0x377cd2());
  _0x4e0adb["shouldUseGiftOption"] &&
    (_0x4dce51["update"]("Setting\x20gift\x20message,\x20Please\x20wait..."),
    await _0x41e7c9(_0x4e0adb));
  (_0x4dce51["update"]("Proceeding\x20to\x20Checkout"),
    (document["title"] = "#11.1\x20Proceeding\x20to\x20Checkout"),
    console["log"]("Proceeding\x20to\x20payment"));
  if (_0x4e0adb["autoConfirmPurchase"]) {
    (_0x4dce51["update"]("Auto-Confirming\x20Purchase,\x20Please\x20wait..."),
      await new Promise((_0x29303d) => setTimeout(_0x29303d, 0x3e8)));
    for (let _0xa671a2 = 0x0; _0xa671a2 < 0xa; _0xa671a2++) {
      (0x0 === _0xa671a2
        ? _0x4dce51["update"](
            "Auto-Confirming\x20Purchase,\x20Please\x20wait...",
          )
        : _0x4dce51["update"](
            "Auto-Confirming\x20Purchase,\x20Please\x20wait...\x20(" +
              _0xa671a2 +
              ")",
          ),
        await _0x40314f(),
        await new Promise((_0x711b3f) => setTimeout(_0x711b3f, 0x7d0)));
    }
  } else _0x4dce51["update"]("Waiting\x20for\x20user\x20confirmation");
}
async function _0x40314f() {
  var _0x1e424d = document["querySelector"]("#placeOrder");
  _0x1e424d && _0x1e424d["click"]();
}
async function _0x23dcdc() {
  var _0x47cb1a = await getBuyNowButton();
  if (_0x47cb1a) _0x47cb1a["click"]();
  else {
    var _0x26b0fc = await getAddToCartButton();
    _0x26b0fc && _0x26b0fc["click"]();
  }
}
