function _0x3c5e0a() {
  return document["documentElement"]["innerHTML"]["includes"](
    "upstream\x20connect\x20error\x20or\x20disconnect/reset\x20before\x20headers.\x20reset\x20reason:\x20connection\x20termination",
  );
}
function _0x152d8c() {
  return new Promise((_0x20fede) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x20fede();
      });
    });
  });
}
function _0xf8db20() {
  return new Promise((_0x3265e4) => {
    requestIdleCallback(() => {
      _0x3265e4();
    });
  });
}
function _0x56b855(_0x57862a = 0x3e8) {
  return new Promise((_0xddf132, _0x35caac) => {
    let _0x3793f5,
      _0x244121 = Date["now"](),
      _0x15987c = !0x1;
    function _0x324ff2() {
      if (Date["now"]() - _0x244121 > _0x57862a)
        (_0x15987c && _0x3793f5["disconnect"](), _0xddf132());
      else setTimeout(_0x324ff2, _0x57862a);
    }
    const _0xf09c0f = () => {
        _0x244121 = Date["now"]();
      },
      _0x14a441 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x3793f5 = new MutationObserver(_0xf09c0f)),
        _0x3793f5["observe"](document["body"], _0x14a441),
        (_0x15987c = !0x0),
        setTimeout(_0x324ff2, _0x57862a));
    else
      window["onload"] = () => {
        ((_0x3793f5 = new MutationObserver(_0xf09c0f)),
          _0x3793f5["observe"](document["body"], _0x14a441),
          (_0x15987c = !0x0),
          setTimeout(_0x324ff2, _0x57862a));
      };
  });
}
async function _0x559bda() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x56b855(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
var _0x264da2 = !0x1;
function _0x38f7f7(_0xb09bb7, _0x5568c2 = "image/x-icon") {
  var _0x5ceae4 = "shortcut\x20icon";
  "image/gif" == _0x5568c2 || "image/png" == _0x5568c2
    ? (_0x5ceae4 = "icon")
    : (_0x264da2 = !0x1);
  var _0x2dd71e =
    document["querySelector"]("link[rel*=\x27icon\x27]") ||
    document["createElement"]("link");
  ((_0x2dd71e["type"] = _0x5568c2),
    (_0x2dd71e["rel"] = _0x5ceae4),
    (_0x2dd71e["href"] = _0xb09bb7),
    document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x2dd71e));
}
function _0x392a85(_0x193937, _0x4cbf7e = "image/x-icon") {
  let _0x18247a =
      "image/gif" == _0x4cbf7e || "image/png" == _0x4cbf7e
        ? "icon"
        : "shortcut\x20icon",
    _0x58f07e = document["querySelectorAll"]("link[rel*=\x27icon\x27]");
  if (0x0 === _0x58f07e["length"]) {
    let _0x1cd12b = document["createElement"]("link");
    ((_0x1cd12b["type"] = _0x4cbf7e),
      (_0x1cd12b["rel"] = _0x18247a),
      (_0x1cd12b["href"] = _0x193937),
      document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x1cd12b));
    return;
  }
  for (let _0xf18fcf of _0x58f07e) {
    ((_0xf18fcf["type"] = _0x4cbf7e),
      (_0xf18fcf["rel"] = _0x18247a),
      (_0xf18fcf["href"] = _0x193937));
  }
}
function _0x48f092() {
  _0x264da2 = !0x0;
  var _0x1bf25d = 0x0,
    _0x4ee496 = chrome["runtime"]["getURL"](
      "Favicons/Gifs/Gear/frame_" + _0x1bf25d + "_delay-0.04s.gif",
    ),
    _0x3b1857 = setInterval(function () {
      if (_0x264da2 && _0x1bf25d < 0x1c)
        (_0x38f7f7(_0x4ee496, "image/gif"),
          _0x1bf25d++,
          (_0x4ee496 = chrome["runtime"]["getURL"](
            "Favicons/Gifs/Gear/frame_" + _0x1bf25d + "_delay-0.04s.gif",
          )));
      else {
        if (_0x264da2 && _0x1bf25d >= 0x1c)
          ((_0x1bf25d = 0x0),
            (_0x4ee496 = chrome["runtime"]["getURL"](
              "Favicons/Gifs/Gear/frame_" + _0x1bf25d + "_delay-0.04s.gif",
            )));
        else clearInterval(_0x3b1857);
      }
    }, 0x28);
}
function _0x468a7e() {
  _0x264da2 = !0x0;
  var _0x238803 = 0x0,
    _0x3b1234 = chrome["runtime"]["getURL"](
      "Favicons/Task_Bar/" + _0x238803 + ".png",
    ),
    _0x2fe4b9 = setInterval(function () {
      if (_0x264da2 && _0x238803 < 0x1b)
        (_0x38f7f7(_0x3b1234, "image/gif"),
          _0x238803++,
          (_0x3b1234 = chrome["runtime"]["getURL"](
            "Favicons/Task_Bar/" + _0x238803 + ".png",
          )));
      else {
        if (_0x264da2 && _0x238803 >= 0x1b)
          ((_0x238803 = 0x0),
            (_0x3b1234 = chrome["runtime"]["getURL"](
              "Favicons/Task_Bar/" + _0x238803 + ".png",
            )));
        else clearInterval(_0x2fe4b9);
      }
    }, 0x28);
}
function _0x2658f5() {
  _0x264da2 = !0x0;
  var _0x372b34 = 0x0,
    _0x3c0297 = [0x2, 0x8, 0xe, 0x14, 0x1a, 0x1b],
    _0x5a02a9 = 0x28,
    _0x2adb90 = "0.04s",
    _0x6e301e = setInterval(function () {
      if (_0x264da2) {
        _0x2adb90 = _0x3c0297["includes"](_0x372b34) ? "0.05s" : "0.04s";
        var _0x2df5d3 =
          "frame_" +
          _0x372b34["toString"]()["padStart"](0x2, "0") +
          "_delay-" +
          _0x2adb90 +
          ".gif";
        (_0x38f7f7(
          chrome["runtime"]["getURL"]("Favicons/Sniper/" + _0x2df5d3),
          "image/gif",
        ),
          ++_0x372b34 >= 0x1b && (_0x372b34 = 0x0),
          (_0x5a02a9 = "0.05s" === _0x2adb90 ? 0x32 : 0x28));
      } else clearInterval(_0x6e301e);
    }, _0x5a02a9);
}
async function _0x4a8bd9() {
  ((_0x264da2 = !0x1),
    await new Promise((_0x2ff1d7) => setTimeout(_0x2ff1d7, 0x7d0)));
}
console["log"]("bulksell\x20functions.js\x20loaded");
async function _0x4d686f(_0x245609 = "Offers", _0x4c17b6 = 0x0) {
  var _0x48bf9e = 0x0;
  const _0x47da98 = setInterval(() => {
    chrome["runtime"]["sendMessage"]({ type: "makeTabActive" });
  }, 0x493e0);
  (setTimeout(() => {
    return (
      clearInterval(_0x47da98),
      "timed\x20out\x20took\x20too\x20long\x20to\x20complete"
    );
  }, 0x927c0),
    await _0x56b855(),
    console["log"]("submitBulkEditForm"),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20waiting\x20for\x20submit\x20button\x20to\x20enable"),
    await _0xd82a4b(),
    await new Promise((_0x16f03e) => setTimeout(_0x16f03e, 0x3e8)),
    _0x392c10(),
    console["log"]("waiting\x20for\x20selectAllItems\x20to\x20be\x20checked"),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20waiting\x20for\x20select\x20all\x20items\x20to\x20be\x20checked"),
    await _0x11ff49(),
    await new Promise((_0x596411) => setTimeout(_0x596411, 0x3e8)),
    console["log"]("selectAllItems"),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20waiting\x20for\x20bulk\x20edit\x20button\x20to\x20be\x20clicked"),
    _0x2f1263(_0x245609)["click"](),
    console["log"]("waiting\x20for\x20apply\x20button\x20to\x20appear"));
  var _0x309d90 = null;
  document["title"] =
    "Bulk\x20Edit\x20Items,\x20waiting\x20for\x20apply\x20button\x20to\x20appear";
  for (; !_0x309d90; ) {
    (document["querySelectorAll"](".right-panel\x20button"),
      !(_0x309d90 = _0x5e728b()) &&
        (console["log"]("waiting\x20for\x20apply\x20button\x20to\x20appear"),
        await new Promise((_0x466bed) => setTimeout(_0x466bed, 0x3e8)),
        (_0x48bf9e += 0x3e8)),
      _0x48bf9e % 0x2710 == 0x0 &&
        chrome["runtime"]["sendMessage"]({ type: "makeTabActive" }));
  }
  (console["log"]("apply\x20button\x20found"),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20apply\x20button\x20found,\x20waiting\x20for\x20page\x20to\x20be\x20stable"),
    console["log"]("option\x20index", _0x4c17b6),
    document["querySelectorAll"](".se-radio-group__option")
      [_0x4c17b6]["querySelector"]("input[type=\x22radio\x22]")
      ["click"](),
    console["log"]("radio\x20input\x20clicked"),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20radio\x20input\x20clicked,\x20waiting\x20for\x20page\x20to\x20be\x20stable"),
    await new Promise((_0x20c28e) => setTimeout(_0x20c28e, 0x7d0)),
    _0x309d90["click"](),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20apply\x20button\x20clicked,\x20waiting\x20for\x20page\x20to\x20be\x20stable"),
    console["log"](
      "apply\x20button\x20clicked,\x20waiting\x20for\x20page\x20to\x20be\x20stable",
    ),
    await new Promise((_0x29cf8d) => setTimeout(_0x29cf8d, 0x7d0)),
    await _0x56b855(),
    console["log"]("waiting\x20for\x20submit\x20button\x20to\x20appear"),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20waiting\x20for\x20submit\x20button\x20to\x20appear"));
  var _0x5c6132 = await _0xd82a4b();
  (await new Promise((_0x3ef4eb) => setTimeout(_0x3ef4eb, 0x7d0)),
    _0x5c6132["click"](),
    (await _0x162d3a())["click"](),
    console["log"]("submit\x20button\x20clicked"),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20waiting\x20for\x20done\x20link\x20to\x20appear"),
    await _0x57b5ad());
  var _0x12f45d = _0x266a0b();
  return (
    console["log"]("confirmationMessage", _0x12f45d),
    (document["title"] =
      "Bulk\x20Edit\x20Items,\x20confirmation\x20message\x20received"),
    _0x12f45d
  );
}
function _0x5e728b() {
  var _0xdad4f5 = document["querySelectorAll"](".right-panel\x20button");
  return Array["from"](_0xdad4f5)["find"](
    (_0x179e86) =>
      _0x179e86["innerText"]["toLowerCase"]()["includes"]("apply") ||
      _0x179e86["innerText"]["toLowerCase"]()["includes"]("übernehmen"),
  );
}
async function _0xd82a4b() {
  var _0x177e8d = null;
  for (; !_0x177e8d; ) {
    var _0x325c3a = document["querySelectorAll"]("button");
    _0x177e8d = Array["from"](_0x325c3a)["find"](
      (_0x43366f) =>
        (_0x43366f["textContent"]
          ["trim"]()
          ["toLowerCase"]()
          ["includes"]("submit\x20all") &&
          !_0x43366f["disabled"]) ||
        (_0x43366f["textContent"]
          ["trim"]()
          ["toLowerCase"]()
          ["includes"]("senden\x20alle") &&
          !_0x43366f["disabled"]),
    );
    if (!_0x177e8d)
      for (var _0x394968 of _0x325c3a) {
        if (
          _0x394968["innerText"]["toLowerCase"]()["includes"]("submit\x20(") &&
          !_0x394968["disabled"]
        ) {
          _0x177e8d = _0x394968;
          break;
        }
        if (
          _0x394968["innerText"]["toLowerCase"]()["includes"]("senden\x20(") &&
          !_0x394968["disabled"]
        ) {
          _0x177e8d = _0x394968;
          break;
        }
      }
    !_0x177e8d &&
      (console["log"](
        "waiting\x20for\x20enabled\x20submit\x20button\x20to\x20appear",
      ),
      await new Promise((_0x5bda80) => setTimeout(_0x5bda80, 0x3e8)));
  }
  return _0x177e8d;
}
async function _0x162d3a() {
  var _0x4f75ac = null;
  for (; !_0x4f75ac; ) {
    var _0x413079 = document["querySelectorAll"]("button");
    !(_0x4f75ac = Array["from"](_0x413079)["find"](
      (_0xd0faee) =>
        "submit" === _0xd0faee["textContent"]["trim"]()["toLowerCase"]() ||
        "submit\x20with\x20displayed\x20fees" ===
          _0xd0faee["textContent"]["trim"]()["toLowerCase"]() ||
        "senden" === _0xd0faee["textContent"]["trim"]()["toLowerCase"]() ||
        "zu\x20genannten\x20gebühren\x20senden" ===
          _0xd0faee["textContent"]["trim"]()["toLowerCase"](),
    )) &&
      (console["log"]("waiting\x20for\x20submit\x20button\x20to\x20appear"),
      await new Promise((_0x152b04) => setTimeout(_0x152b04, 0x3e8)));
  }
  return _0x4f75ac;
}
function _0x2f1263(_0x837b0d = "Offers") {
  var _0x20bf82 = "Preisvorschläge",
    _0x59cb1a = document["querySelectorAll"](".bulk-edit-menu--clickable-item"),
    _0x96d533 = null;
  for (var _0x96d533 of _0x59cb1a)
    if (
      "Offers" == _0x96d533["innerText"] ||
      _0x96d533["innerText"] == _0x20bf82
    )
      break;
  return _0x96d533;
}
function _0x3dc44a() {
  var _0x12760d = document["querySelectorAll"]("button"),
    _0x206c5b = null;
  for (var _0x1dbece of _0x12760d)
    if ("Bulk\x20edit" == _0x1dbece["innerText"]) {
      _0x206c5b = _0x1dbece;
      break;
    }
  return _0x206c5b;
}
async function _0x69d1bc() {
  (await _0x56b855(),
    console["log"]("submitBulkEditForm"),
    _0x392c10(),
    console["log"]("waiting\x20for\x20selectAllItems\x20to\x20be\x20checked"),
    await _0x11ff49(),
    await new Promise((_0x47bb02) => setTimeout(_0x47bb02, 0x3e8)),
    console["log"]("selectAllItems"),
    _0x25e863(),
    console["log"]("waiting\x20for\x20submit\x20button\x20to\x20appear"));
  var _0x5117b9 = null;
  ((_0x5117b9 = await _0x162d3a()),
    console["log"]("submit\x20button\x20found"),
    _0x5117b9["click"](),
    await _0x57b5ad());
  var _0x5091c5 = _0x266a0b();
  return (console["log"]("confirmationMessage", _0x5091c5), _0x5091c5);
}
function _0x25e863() {
  var _0x1d8169 = document["querySelectorAll"]("button"),
    _0x16715c = null;
  for (var _0x148035 of _0x1d8169)
    if (
      _0x148035["innerText"]["toLowerCase"]()["includes"]("submit\x20all") ||
      _0x148035["innerText"]["toLowerCase"]()["includes"]("senden\x20alle")
    ) {
      _0x16715c = _0x148035;
      break;
    }
  if (!_0x16715c) {
    for (var _0x148035 of _0x1d8169)
      if (
        _0x148035["innerText"]["toLowerCase"]()["includes"]("submit") ||
        _0x148035["innerText"]["toLowerCase"]()["includes"]("senden\x20(")
      ) {
        _0x16715c = _0x148035;
        break;
      }
  }
  return (_0x16715c["click"](), !0x0);
}
function _0x392c10() {
  var _0x5c765a = _0x366a9d();
  if (_0x5c765a) {
    var _0x511384 = new MouseEvent("click", {
      view: window,
      bubbles: !0x0,
      cancelable: !0x0,
    });
    return (_0x5c765a["dispatchEvent"](_0x511384), !0x0);
  }
  return !0x1;
}
async function _0x11ff49() {
  if (!(_0x5b5fd5 = _0x366a9d()))
    var _0x5b5fd5 = document["querySelector"](
      ".checkbox__control:not([id*=\x27draft\x27]):not([class*=\x27draft\x27])",
    );
  if (_0x5b5fd5["checked"]) return !0x0;
  return (
    await new Promise((_0xc6f4a3) => setTimeout(_0xc6f4a3, 0x3e8)),
    _0x11ff49()
  );
}
function _0x366a9d() {
  if (
    !(_0x27ed7f = document["querySelector"](
      "input[aria-label=\x22Select\x20all\x20items\x20for\x20bulk\x20edit.\x22]",
    ))
  )
    var _0x27ed7f = document["querySelector"](
      ".table-wrapper\x20.checkbox__control:not([id*=\x27draft\x27]):not([class*=\x27draft\x27])",
    );
  return _0x27ed7f;
}
async function _0x57b5ad() {
  console["log"]("waiting\x20for\x20done\x20link\x20to\x20appear");
  var _0x34f4ab = document["querySelectorAll"]("a"),
    _0xa17871 = null;
  for (var _0x57933f of _0x34f4ab)
    if (
      _0x57933f["innerText"]["toLowerCase"]()["includes"]("done") ||
      _0x57933f["innerText"]["toLowerCase"]()["includes"]("exit") ||
      _0x57933f["innerText"]["toLowerCase"]()["includes"]("fertig") ||
      _0x57933f["innerText"]["toLowerCase"]()["includes"]("beenden")
    ) {
      _0xa17871 = _0x57933f;
      break;
    }
  if (_0xa17871) return (console["log"]("done\x20link\x20found"), _0xa17871);
  var _0x14ae91 = document["querySelectorAll"]("button"),
    _0x42afaa = null;
  for (var _0x5d0c73 of _0x14ae91)
    if (_0x5d0c73["innerText"]["toLowerCase"]()["includes"]("fix\x20errors")) {
      _0x42afaa = _0x5d0c73;
      break;
    }
  if (_0x42afaa) return _0x42afaa;
  return (
    await new Promise((_0x5ea795) => setTimeout(_0x5ea795, 0x3e8)),
    _0x57b5ad()
  );
}
function _0x266a0b() {
  var _0x4d8b51 = document["querySelector"](
    ".cta-confirmation-publish-dialog__success-section",
  );
  console["log"]("confirmationElement", _0x4d8b51);
  if (_0x4d8b51) return _0x4d8b51["innerText"];
  var _0x1ce7eb = document["querySelector"](
    ".cta-confirmation-publish-dialog__failure-section",
  );
  return (
    console["log"]("errorElement", _0x1ce7eb),
    _0x1ce7eb ? _0x1ce7eb["innerText"] : null
  );
}
async function _0x5e0a2b() {
  var _0x4c8357 = document["querySelectorAll"]("button"),
    _0x55754c = null;
  for (var _0x4541f1 of _0x4c8357)
    if (
      "exit" == _0x4541f1["innerText"]["toLowerCase"]() ||
      "beenden" == _0x4541f1["innerText"]["toLowerCase"]()
    ) {
      _0x55754c = _0x4541f1;
      break;
    }
  _0x55754c["click"]();
}
async function _0x5ccbef() {
  var _0x3343b2,
    _0x5f0d97 = document["querySelectorAll"]("button");
  for (var _0x3981c7 of _0x5f0d97)
    if (
      _0x3981c7["innerText"]["toLowerCase"]()["includes"]("got\x20it") ||
      _0x3981c7["innerText"]["toLowerCase"]()["includes"]("verstanden")
    ) {
      _0x3343b2 = _0x3981c7;
      break;
    }
  return _0x3343b2;
}
async function _0x58bde1() {
  var _0x2c16c1 = document["querySelectorAll"]("button"),
    _0x2a677a = null;
  for (var _0x4254c1 of _0x2c16c1)
    if (
      _0x4254c1["innerText"]["toLowerCase"]()["includes"]("fix\x20errors") ||
      _0x4254c1["innerText"]["toLowerCase"]()["includes"]("fehler\x20beheben")
    ) {
      _0x2a677a = _0x4254c1;
      break;
    }
  return _0x2a677a;
}
function _0x32f782() {
  const _0x40dba7 = setInterval(async () => {
    var _0x12931f = await _0x5ccbef();
    _0x12931f &&
      (console["log"]("got\x20it\x20button\x20found"),
      (document["title"] = "got\x20it\x20button\x20found"),
      clearInterval(_0x40dba7),
      await new Promise((_0xbd4636) => setTimeout(_0xbd4636, 0x1b58)),
      _0x12931f["click"](),
      await new Promise((_0x54720d) => setTimeout(_0x54720d, 0x1b58)),
      (await _0xd82a4b())["click"](),
      await new Promise((_0x63de9b) => setTimeout(_0x63de9b, 0x1b58)),
      Promise["race"]([_0x162d3a(), _0x58bde1()])["then"]((_0x39b09a) => {
        if (_0x39b09a) {
          if (
            _0x39b09a["innerText"]["toLowerCase"]()["includes"]("submit") ||
            _0x39b09a["innerText"]["toLowerCase"]()["includes"]("senden")
          )
            (console["log"]("Submit\x20button\x20clicked"),
              _0x39b09a["click"]());
          else
            (_0x39b09a["innerText"]
              ["toLowerCase"]()
              ["includes"]("fix\x20errors") ||
              _0x39b09a["innerText"]
                ["toLowerCase"]()
                ["includes"]("fehler\x20beheben")) &&
              (console["log"]("Fix\x20Errors\x20button\x20clicked"),
              _0x39b09a["click"]());
        }
      }));
  }, 0x1770);
}
(console["log"]("bulksell\x20content.js\x20loaded"),
  _0x559bda(),
  chrome["runtime"]["onMessage"]["addListener"](
    function (_0x446b77, _0x130676, _0x189f55) {
      console["log"](
        "bulksell\x20content.js\x20message\x20received",
        _0x446b77,
      );
      if ("submit-bulk-edit-form" == _0x446b77["type"]) {
        console["log"]("submit-bulk-edit-form\x20message\x20received");
        if (_0x3c5e0a()) {
          (chrome["runtime"]["sendMessage"]({
            type: "resend_message_to_tab_on_update_and_notified",
            message: request,
          }),
            location["reload"](),
            console["log"](
              "upstream\x20connect\x20error\x20or\x20disconnect/reset\x20before\x20headers.\x20reset\x20reason:\x20connection\x20termination",
            ));
          return;
        }
        (0x0 == _0x446b77["automatic"]
          ? chrome["runtime"]["sendMessage"]({
              type: "bulk-edit-button-clicked",
            })
          : _0x189f55({ response: "waiting_for_bulk_edit_to_be_clicked" }),
          _0x69d1bc()["then"]((_0x14f255) => {
            chrome["runtime"]["sendMessage"]({
              type: "bulk-edit-form-submitted",
              status: _0x14f255,
            });
          }));
      }
      if ("revise_items" == _0x446b77["type"]) {
        if (_0x3c5e0a()) {
          (chrome["runtime"]["sendMessage"]({
            type: "resend_message_to_tab_on_update_and_notified",
            message: request,
          }),
            location["reload"](),
            console["log"](
              "upstream\x20connect\x20error\x20or\x20disconnect/reset\x20before\x20headers.\x20reset\x20reason:\x20connection\x20termination",
            ));
          return;
        }
        return (
          console["log"]("revise_items\x20message\x20received"),
          _0x48f092(),
          _0x4d686f(_0x446b77["menuOption"], _0x446b77["optionIndex"])["then"](
            (_0x2eb2b8) => {
              _0x189f55(_0x2eb2b8);
            },
          ),
          !0x0
        );
      }
      return ("exit" == _0x446b77["type"] && _0x5e0a2b(), !0x0);
    },
  ));
async function _0x479169() {
  (await _0x56b855(), console["log"]("main\x20function\x20called"));
  var _0x5b6e20 = await _0x4d686f("Offers", 0x0);
  console["log"]("status", _0x5b6e20);
}
