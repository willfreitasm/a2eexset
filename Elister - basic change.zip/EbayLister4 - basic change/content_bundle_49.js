console["log"]("captcha_solver.js\x20loaded");
function _0x5b5906(_0x24273e) {
  return (
    console["log"]("Converting\x20image\x20to\x20base64:\x20" + _0x24273e),
    fetch(_0x24273e)
      ["then"]((_0x3ae393) => _0x3ae393["blob"]())
      ["then"](
        (_0x36284d) =>
          new Promise((_0x570fa3, _0x421dd9) => {
            const _0x26b3b2 = new FileReader();
            ((_0x26b3b2["onloadend"] = () => _0x570fa3(_0x26b3b2["result"])),
              (_0x26b3b2["onerror"] = _0x421dd9),
              _0x26b3b2["readAsDataURL"](_0x36284d));
          }),
      )
  );
}
function _0x4e9ef4(_0x34f10c) {
  return _0x5b5906(_0x34f10c)["then"]((_0x48c53) =>
    _0x48c53["replace"]("data:image/jpeg;base64,", ""),
  );
}
async function _0x1c6803(_0x109b3c) {
  const _0x140df4 = {
      signature_name: "serving_default",
      inputs: { input: { b64: await _0x4e9ef4(_0x109b3c) } },
    },
    _0x4ffb88 = await fetch(
      "https://text-solver-service-708081384154.us-central1.run.app/v1/models/text_solver:predict",
      {
        method: "POST",
        body: JSON["stringify"](_0x140df4),
        headers: {
          "cache-control": "no-cache",
          "content-type": "application/json",
        },
      },
    )
      ["then"]((_0x3e882e) => _0x3e882e["json"]())
      ["then"]((_0x51e9e0) => _0x51e9e0["outputs"]["output"]);
  return (console["log"]("Solved\x20Captcha:\x20" + _0x4ffb88), _0x4ffb88);
}
function _0xae6a87() {
  const _0x292bd8 = document["querySelectorAll"]("#captchacharacters");
  return "Robot\x20Check" === document["title"] || _0x292bd8["length"] > 0x0;
}
function _0x4e22ed() {
  (console["log"]("Handling\x20Captcha"),
    console["log"]("Robot\x20Check\x20Doc\x20Found"));
  const _0x1d0555 = document["querySelectorAll"](".a-text-center.a-row")[0x1]
    ["querySelectorAll"]("img")[0x0]
    ["getAttribute"]("src");
  chrome["runtime"]["sendMessage"](
    { type: "solve_captcha", captchaImgUrl: _0x1d0555 },
    function (_0x301b54) {
      "solved_captcha" === _0x301b54["type"] &&
        (console["log"]("code:\x20" + _0x301b54["captchaKey"]),
        (document["getElementById"]("captchacharacters")["value"] =
          _0x301b54["captchaKey"]),
        document["querySelectorAll"]("button[type=\x22submit\x22]")[0x0][
          "click"
        ]());
    },
  );
}
async function _0x417f66() {
  var _0x1952e6 = _0xae6a87();
  console["log"]("isCaptcha", _0x1952e6);
  if (_0x1952e6) {
    var _0x2d04b1 = document["querySelectorAll"](".a-text-center.a-row")[0x1]
        ["querySelectorAll"]("img")[0x0]
        ["getAttribute"]("src"),
      _0x4b29b5 = await new Promise((_0xd98ca, _0x5c40d2) => {
        chrome["runtime"]["sendMessage"](
          { type: "solve_captcha", captchaImgUrl: _0x2d04b1 },
          function (_0x5a99e7) {
            _0xd98ca(_0x5a99e7["captchaKey"]);
          },
        );
      });
    (console["log"]("captchaKey", _0x4b29b5),
      (document["getElementById"]("captchacharacters")["value"] = _0x4b29b5),
      document["querySelectorAll"]("button[type=\x22submit\x22]")[0x0][
        "click"
      ]());
  }
}
function _0x4356b5() {
  return document["querySelectorAll"](".a-text-center.a-row")[0x1]
    ["querySelectorAll"]("img")[0x0]
    ["getAttribute"]("src");
}
async function _0x306317(_0x5c1245) {
  return await new Promise((_0x402383, _0xf07709) => {
    chrome["runtime"]["sendMessage"](
      { type: "solve_captcha", captchaImgUrl: _0x5c1245 },
      function (_0x5a6a67) {
        _0x402383(_0x5a6a67["captchaKey"]);
      },
    );
  });
}
function _0x320029(_0x158d1f) {
  chrome["runtime"]["sendMessage"]({
    type: "wait_for_solved_captcha_reload",
    messageOptions: _0x158d1f,
  });
}
function _0x394be5(_0xad0223) {
  document["getElementById"]("captchacharacters")["value"] = _0xad0223;
}
function _0x123a1a() {
  document["querySelectorAll"]("button[type=\x22submit\x22]")[0x0]["click"]();
}
async function _0x1c2c79() {
  var _0x814afd = _0x4356b5();
  (_0x394be5(await _0x306317(_0x814afd)), _0x123a1a());
}
function _0xe22cfb() {
  var _0x271322 = _0x11307d();
  return _0x271322 && null !== _0x271322["offsetParent"];
}
function _0x11307d() {
  return document["querySelector"](
    "form[action=\x27/errors/validateCaptcha\x27]\x20button",
  );
}
console["log"]("amazon.functions.js");
let _0x28f930 = (_0x20f999) => document["querySelectorAll"](_0x20f999),
  _0x3ff88d = () => _0x28f930("#dp")["length"];
function _0x562b2b() {
  let _0x11e3c3 = "";
  return (
    _0x28f930("#ebooksProductTitle")["length"]
      ? (_0x11e3c3 = $("#ebooksProductTitle")["text"]()["trim"]())
      : _0x28f930("h1.product-name")["length"]
        ? (_0x11e3c3 = $("h1.product-name")["text"]()["trim"]())
        : _0x28f930("#productTitle")["length"] &&
          (_0x11e3c3 = $("#productTitle")["text"]()["trim"]()),
    _0x11e3c3
  );
}
function _0x16b78b() {
  var _0x19f5ae = [];
  try {
    var _0x2140af = document["getElementById"](
      "wayfinding-breadcrumbs_feature_div",
    )["getElementsByClassName"]("a-link-normal");
    _0x2140af = Array["from"](_0x2140af)["filter"](
      (_0x2ddbd2) => "breadcrumb-back-link" != _0x2ddbd2["id"],
    );
    for (var _0x2f396b of _0x2140af) {
      var _0x54cf06 = _0x2f396b["innerText"];
      _0x19f5ae["push"](_0x54cf06);
    }
    try {
      var _0x346ab0 =
        document["getElementById"]("nav-subnav")["getElementsByClassName"](
          "nav-a",
        )[0x0]["innerText"];
      _0x346ab0 && "" != _0x346ab0 && _0x19f5ae["unshift"](_0x346ab0);
    } catch (_0x18ee9f) {
      console["log"]("error\x20getting\x20main\x20category", _0x18ee9f);
    }
  } catch (_0x5faae4) {
    console["log"]("error\x20getting\x20categories", _0x5faae4);
  }
  return _0x19f5ae;
}
function _0x452d40(_0x32eeb4) {
  var _0x4b590c = [];
  for (let _0x419a7c = 0x0; _0x419a7c < _0x32eeb4["length"]; _0x419a7c++)
    0x200e == _0x32eeb4["charCodeAt"](_0x419a7c) ||
      0x200f == _0x32eeb4["charCodeAt"](_0x419a7c) ||
      _0x4b590c["push"](_0x32eeb4["charAt"](_0x419a7c));
  return _0x4b590c["join"]("");
}
function _0x35eef9() {
  return _0x562b2b();
}
function _0x4964ca() {
  var _0x574fdb = _0x562b2b(),
    _0x447d02 = _0x38cbe5();
  _0x447d02 = _0x447d02["trim"]();
  var filteredTitle = _0x574fdb,
    _0x217343 = _0x574fdb["split"]("\x20"),
    filteredTitleWords = [];
  for (var _0xdc3b21 = 0x0; _0xdc3b21 < _0x217343["length"]; _0xdc3b21++)
    (0x0 !== (_0x5c0d69 = _0x217343[_0xdc3b21])["indexOf"](_0x447d02) ||
      _0xdc3b21 > 0x0) &&
      filteredTitleWords["push"](_0x5c0d69);
  filteredTitle = filteredTitleWords["join"]("\x20");
  var _0x3e43d0 = (filteredTitle = (filteredTitle = insensitiveReplaceAll(
    filteredTitle,
    _0x447d02,
    "",
  ))
    ["replace"](_0x447d02, "")
    ["trim"]())["split"]("\x20-\x20")[0x0];
  ((_0x3e43d0 = _0x3e43d0["trim"]()),
    _0x447d02["toLowerCase"]()["includes"](_0x3e43d0["toLowerCase"]()) &&
      (filteredTitle = filteredTitle["split"]("\x20-\x20")[0x1]));
  var _0x411115 = _0x447d02["replace"](/\s/g, "");
  filteredTitle = filteredTitle["replace"](_0x411115, "")["trim"]();
  var _0x588ad2 = _0x452d40(_0x447d02);
  ((filteredTitle = filteredTitle["replace"](_0x588ad2, "")),
    (filteredTitle = insensitiveReplaceAll(filteredTitle, _0x588ad2, "")));
  var _0x148513 = insensitiveReplaceAll(_0x447d02, "ltd", "");
  ((_0x148513 = _0x148513["trim"]()),
    (filteredTitle = (filteredTitle = insensitiveReplaceAll(
      filteredTitle,
      _0x148513,
      "",
    ))["replace"](/\b([A-Z]{3}[0-9].*?)\b/g, "")));
  var _0x3cfb64 = _0x105a02();
  if (_0x3cfb64["length"] > 0x0)
    for (_0xdc3b21 = 0x0; _0xdc3b21 < _0x3cfb64["length"]; _0xdc3b21++) {
      ((_0x3788db = _0x452d40(
        (_0x3788db = _0x3cfb64[_0xdc3b21]["toLowerCase"]()),
      )),
        (filteredTitle = (filteredTitle = insensitiveReplaceAll(
          filteredTitle,
          _0x3788db,
          "",
        ))["replaceAll"](_0x3788db, "")));
    }
  if (_0x3cfb64["length"] > 0x0)
    for (_0xdc3b21 = 0x0; _0xdc3b21 < _0x3cfb64["length"]; _0xdc3b21++) {
      var _0x57ba92 = (_0x3788db = _0x452d40(
        (_0x3788db = _0x3cfb64[_0xdc3b21]["toLowerCase"]()),
      ))["split"]("-");
      for (var _0x5bbc6a = 0x0; _0x5bbc6a < _0x57ba92["length"]; _0x5bbc6a++) {
        var _0x3788db;
        (_0x3788db = _0x57ba92[_0x5bbc6a])["length"] > 0x5 &&
          (filteredTitle = (filteredTitle = insensitiveReplaceAll(
            filteredTitle,
            _0x3788db,
            "",
          ))["replaceAll"](_0x3788db, ""));
      }
    }
  filteredTitleWords = filteredTitle["split"]("\x20");
  for (_0xdc3b21 = 0x0; _0xdc3b21 < filteredTitleWords["length"]; _0xdc3b21++) {
    var _0x5c0d69;
    (_0x5c0d69 = filteredTitleWords[_0xdc3b21])["includes"]("#") &&
      (filteredTitle = (filteredTitle = insensitiveReplaceAll(
        filteredTitle,
        _0x5c0d69,
        "",
      ))["replaceAll"](_0x5c0d69, ""));
  }
  filteredTitle = (filteredTitle = filteredTitle["replaceAll"]("(", ""))[
    "replaceAll"
  ](")", "");
  var _0x21d0dd = findSpecific("manufacturer");
  (_0x21d0dd &&
    (filteredTitle = insensitiveReplaceAll(filteredTitle, _0x21d0dd, "")),
    (filteredTitle = (filteredTitle = (filteredTitle = (filteredTitle =
      (filteredTitle = (filteredTitle = (filteredTitle = (filteredTitle =
        (filteredTitle = (filteredTitle = (filteredTitle = (filteredTitle =
          (filteredTitle = (filteredTitle = (filteredTitle = filteredTitle[
            "replace"
          ](/®/g, ""))["replace"](/™/g, ""))["replace"](/©/g, ""))[
            "replace"
          ](/^[^a-zA-Z \d]/, ""))["replace"](/^ /, ""))["replace"](
          /amazonbasics/i,
          "",
        ))["replace"](/amazon basics/i, ""))["replace"](/^ /, ""))["replace"](
        /\s\s+/g,
        "\x20",
      ))["replace"](/made in usa/i, ""))["replace"](/united states/i, ""))[
        "replace"
      ](/united states of america/i, ""))["replace"](/\busa\b/i, ""))[
      "replace"
    ](/\bus\b/i, ""))["replace"](/warranty/i, "")));
  try {
    var _0x14ce34 = _0x447d02["replace"](/ /g, "");
    filteredTitle = insensitiveReplaceAll(filteredTitle, _0x14ce34, "");
  } catch (_0x4229d0) {
    console["log"]("error", _0x4229d0);
  }
  try {
    filteredTitle = (filteredTitle = filteredTitle["trim"]())["replace"](
      /^ /,
      "",
    );
  } catch (_0x5f0338) {}
  return filteredTitle;
}
function filterText(_0x35536e) {
  var _0x3ff15a = _0x38cbe5();
  _0x3ff15a = _0x3ff15a["trim"]();
  var filteredTitle = _0x35536e;
  console["log"]("filteredTitle()\x20original", filteredTitle);
  var _0x3e51e6 = _0x35536e["split"]("\x20"),
    filteredTitleWords = [];
  for (var _0x2dceee = 0x0; _0x2dceee < _0x3e51e6["length"]; _0x2dceee++)
    (0x0 !== (_0x4bab0d = _0x3e51e6[_0x2dceee])["indexOf"](_0x3ff15a) ||
      _0x2dceee > 0x0) &&
      filteredTitleWords["push"](_0x4bab0d);
  ((filteredTitle = filteredTitleWords["join"]("\x20")),
    (filteredTitle = insensitiveReplaceAll(filteredTitle, _0x3ff15a, "")),
    console["log"](
      "filterText()\x20after\x20replacing\x20brand\x201",
      filteredTitle,
    ),
    (filteredTitle = filteredTitle["replace"](_0x3ff15a, "")["trim"]()),
    console["log"](
      "filterText()\x20after\x20replacing\x20brand\x202",
      filteredTitle,
    ));
  var _0x15a6cb = filteredTitle["split"]("\x20-\x20")[0x0];
  ((_0x15a6cb = _0x15a6cb["trim"]()),
    _0x3ff15a["toLowerCase"]()["includes"](_0x15a6cb["toLowerCase"]()) &&
      (filteredTitle = filteredTitle["split"]("\x20-\x20")[0x1]),
    console["log"](
      "filterText()\x20after\x20removing\x20titleBeforeDash",
      filteredTitle,
    ));
  var _0x4f7f11 = _0x3ff15a["replace"](/\s/g, "");
  (console["log"]("filterText()\x20noSpaceBrand", _0x4f7f11),
    console["log"]("filterText()\x20filteredTitle", filteredTitle));
  if (!filteredTitle || 0x0 == filteredTitle["length"]) return "";
  filteredTitle = filteredTitle["replace"](_0x4f7f11, "")["trim"]();
  var _0x1e7d3c = _0x452d40(_0x3ff15a);
  ((filteredTitle = filteredTitle["replace"](_0x1e7d3c, "")),
    (filteredTitle = insensitiveReplaceAll(filteredTitle, _0x1e7d3c, "")));
  var _0x22e48e = insensitiveReplaceAll(_0x3ff15a, "ltd", "");
  ((_0x22e48e = _0x22e48e["trim"]()),
    (filteredTitle = (filteredTitle = insensitiveReplaceAll(
      filteredTitle,
      _0x22e48e,
      "",
    ))["replace"](/\b([A-Z]{3}[0-9].*?)\b/g, "")));
  var _0x2bcc1e = _0x105a02();
  if (_0x2bcc1e["length"] > 0x0)
    for (_0x2dceee = 0x0; _0x2dceee < _0x2bcc1e["length"]; _0x2dceee++) {
      ((_0x5d2546 = _0x452d40(
        (_0x5d2546 = _0x2bcc1e[_0x2dceee]["toLowerCase"]()),
      )),
        (filteredTitle = (filteredTitle = insensitiveReplaceAll(
          filteredTitle,
          _0x5d2546,
          "",
        ))["replaceAll"](_0x5d2546, "")));
    }
  if (_0x2bcc1e["length"] > 0x0)
    for (_0x2dceee = 0x0; _0x2dceee < _0x2bcc1e["length"]; _0x2dceee++) {
      var _0xc7f903 = (_0x5d2546 = _0x452d40(
        (_0x5d2546 = _0x2bcc1e[_0x2dceee]["toLowerCase"]()),
      ))["split"]("-");
      for (var _0x5a73df = 0x0; _0x5a73df < _0xc7f903["length"]; _0x5a73df++) {
        var _0x5d2546;
        (_0x5d2546 = _0xc7f903[_0x5a73df])["length"] > 0x5 &&
          (filteredTitle = (filteredTitle = insensitiveReplaceAll(
            filteredTitle,
            _0x5d2546,
            "",
          ))["replaceAll"](_0x5d2546, ""));
      }
    }
  filteredTitleWords = filteredTitle["split"]("\x20");
  for (_0x2dceee = 0x0; _0x2dceee < filteredTitleWords["length"]; _0x2dceee++) {
    var _0x4bab0d;
    (_0x4bab0d = filteredTitleWords[_0x2dceee])["includes"]("#") &&
      (filteredTitle = (filteredTitle = insensitiveReplaceAll(
        filteredTitle,
        _0x4bab0d,
        "",
      ))["replaceAll"](_0x4bab0d, ""));
  }
  var _0x1ba3f6 = filteredTitle["match"](/\((.*?)\)/g);
  if (_0x1ba3f6)
    for (_0x2dceee = 0x0; _0x2dceee < _0x1ba3f6["length"]; _0x2dceee++) {
      var _0x4cf3e6 = _0x1ba3f6[_0x2dceee];
      filteredTitle = (filteredTitle = insensitiveReplaceAll(
        filteredTitle,
        _0x4cf3e6,
        "",
      ))["replaceAll"](_0x4cf3e6, "");
    }
  var _0x4f4a74 = findSpecific("manufacturer");
  return (
    _0x4f4a74 &&
      (filteredTitle = insensitiveReplaceAll(filteredTitle, _0x4f4a74, "")),
    (filteredTitle = (filteredTitle = (filteredTitle = (filteredTitle =
      (filteredTitle = (filteredTitle = (filteredTitle = (filteredTitle =
        (filteredTitle = (filteredTitle = (filteredTitle = (filteredTitle =
          (filteredTitle = filteredTitle["replace"](/^[^a-zA-Z \d]/, ""))[
            "replace"
          ](/^ /, ""))["replace"](/amazonbasics/i, ""))["replace"](
          /amazon basics/i,
          "",
        ))["replace"](/^ /, ""))["replace"](/\s\s+/g, "\x20"))["replace"](
        /warranty/i,
        "",
      ))["replace"](/united states/i, ""))["replace"](/united kingdom/i, ""))[
        "replace"
      ](/canada/i, ""))["replace"](/germany/i, ""))["replace"](/france/i, ""))[
      "replace"
    ](/italy/i, ""))["replace"](/[^\x00-\x7F]/g, "\x20")
  );
}
function _0x53f51b() {
  return _0x28f930("#priceblock_ourprice")["length"]
    ? $("#priceblock_ourprice")
        ["text"]()
        ["trim"]()
        ["replace"](/[^\d.]+/g, "")
    : "0.00";
}
function _0x3aa96a(_0x3960bc = null) {
  _0x3960bc || (_0x3960bc = document);
  var filteredPrice = "-1";
  try {
    var _0x2b2028 = _0x50f88d(_0x3960bc);
    priceString = _0x2b2028["innerText"];
  } catch (_0x2f3e1e) {
    return Number(filteredPrice);
  }
  try {
    if (Number(priceString) < 0x0) return Number(priceString);
  } catch (_0xd82510) {}
  if (priceString["includes"]("€"))
    return (
      (priceString = priceString["replace"](",", ".")),
      (filteredPrice = (filteredPrices =
        priceString["match"](/\d{1,5}\.\d{0,2}/))[0x0]),
      Number(filteredPrice)
    );
  ((priceString = priceString["replace"]("CDN$\u00a0", "")),
    (priceString = priceString["replace"](/,/g, "")));
  var filteredPrices = priceString["match"](/\d{1,5}\.\d{0,2}/);
  try {
    filteredPrice = filteredPrices[0x0];
  } catch (_0x359ed8) {
    return (
      console["log"]("error\x20getting\x20filteredPrice", _0x359ed8),
      Number(filteredPrice)
    );
  }
  return Number(filteredPrice);
}
function _0x50f88d(_0x3f1160 = null) {
  _0x3f1160 || (_0x3f1160 = document);
  var _0x24ffbd =
    _0x3f1160["getElementById"]("price_inside_buybox") ||
    _0x3f1160["getElementById"]("newBuyBoxPrice") ||
    _0x3f1160["getElementById"]("priceblock_ourprice") ||
    _0x3f1160["getElementById"]("priceblock_saleprice") ||
    _0x3f1160["getElementById"]("buyNewSection") ||
    _0x3f1160["getElementById"]("buyNew_noncbb") ||
    _0x3f1160["getElementById"]("priceblock_dealprice") ||
    _0x3f1160["getElementById"]("usedBuyBoxPrice") ||
    _0x3f1160["getElementById"]("newBuyBoxPrice") ||
    _0x3f1160["getElementById"]("priceblock_ourprice") ||
    _0x3f1160["getElementById"]("tp_price_block_total_price_ww") ||
    _0x3f1160["getElementById"]("apex_offerDisplay_desktop");
  return (
    _0x3f1160["querySelectorAll"]("#buybox-see-all-buying-choices-announce")[
      "length"
    ] > 0x0 &&
      ((_0x24ffbd = _0x3f1160["createElement"]("div"))["innerText"] =
        "-99999.00"),
    _0x3f1160["querySelectorAll"]("#price")["length"] > 0x0 &&
      !_0x24ffbd &&
      (_0x24ffbd = _0x3f1160["getElementById"]("price"))["innerText"]["search"](
        "\x09See\x20price\x20in\x20cart",
      ) &&
      ((_0x24ffbd = _0x3f1160["createElement"]("div"))["innerText"] =
        "-99999.00"),
    _0x3f1160["querySelectorAll"]("#corePrice_desktop")["length"] > 0x0 &&
      !_0x24ffbd &&
      (_0x24ffbd = (_0x24ffbd =
        _0x3f1160["getElementById"]("corePrice_desktop"))[
        "getElementsByClassName"
      ]("apexPriceToPay")[0x0]),
    _0x24ffbd
  );
}
function _0x666331() {
  var _0x48be4a = "-1";
  try {
    _0x48be4a = _0x50f88d()["innerText"]["replace"]("CDN$\u00a0", "");
  } catch (_0x103701) {}
  return Number(_0x48be4a);
}
function _0x4679e6() {
  var _0x558a22 =
    document["getElementById"]("price_inside_buybox") ||
    document["getElementById"]("newBuyBoxPrice") ||
    document["getElementById"]("priceblock_ourprice") ||
    document["getElementById"]("priceblock_saleprice") ||
    document["getElementById"]("buyNewSection") ||
    document["getElementById"]("buyNew_noncbb") ||
    document["getElementById"]("priceblock_dealprice");
  return (
    document["querySelectorAll"]("#buybox-see-all-buying-choices-announce")[
      "length"
    ] > 0x0 &&
      ((_0x558a22 = document["createElement"]("div"))["innerText"] =
        "-99999.00"),
    _0x558a22
  );
}
function _0x38cbe5() {
  console["log"]("getProductBrand");
  var _0x4f924e = "";
  ((_0x4f924e = findSpecific("brand")),
    console["log"]("getProductBrand\x20findSpecific\x20BRAND", _0x4f924e),
    _0x4f924e || (_0x4f924e = findSpecific("marke")));
  if (!_0x4f924e) {
    if (_0x28f930("#bylineInfo")["length"])
      (console["log"](
        "getProductBrand\x20does\x20exist,\x20trying\x20to\x20find\x20it\x20with\x20#bylineInfo",
      ),
        (_0x4f924e = $("#bylineInfo")["text"]()["trim"]()));
    else {
      if (_0x28f930("#brand")["length"])
        (console["log"](
          "getProductBrand\x20does\x20exist,\x20trying\x20to\x20find\x20it\x20with\x20#brand",
        ),
          (_0x4f924e = $("#brand")["text"]()["trim"]()));
      else
        _0x28f930("#merchant-info\x20.a-link-normal")["length"] &&
          (console["log"](
            "getProductBrand\x20does\x20exist,\x20trying\x20to\x20find\x20it\x20with\x20#merchant-info\x20.a-link-normal",
          ),
          (_0x4f924e = $("#merchant-info\x20.a-link-normal")
            ["text"]()
            ["trim"]()));
    }
    (console["log"]("getProductBrand\x20aftter", _0x4f924e),
      _0x4f924e &&
        "" != _0x4f924e &&
        ((_0x4f924e = insensitiveReplaceAll(_0x4f924e, "Brand:\x20", "")),
        (_0x4f924e = insensitiveReplaceAll(_0x4f924e, "brand", "")),
        (_0x4f924e = insensitiveReplaceAll(_0x4f924e, ":", ""))),
      console["log"]("getProductBrand\x20aftter\x20replace", _0x4f924e));
  }
  return (
    _0x4f924e &&
      (_0x4f924e["includes"]("Visit\x20the") &&
        (_0x4f924e = _0x4f924e["substring"](
          _0x4f924e["indexOf"]("Visit\x20the") + 0x9,
          _0x4f924e["indexOf"]("Store"),
        )),
      (_0x4f924e = (_0x4f924e = _0x4f924e["replace"](/^\s+/, ""))["replace"](
        /\s+$/,
        "",
      ))),
    console["log"]("getProductBrand:", _0x4f924e),
    (!_0x4f924e || "" == _0x4f924e) &&
      (console["log"]("brand\x20doesnt\x20exist"),
      (_0x4f924e = "DoesNotExist"),
      console["log"]("getProductBrand:", _0x4f924e)),
    _0x4f924e
  );
}
function _0x41486c() {
  try {
    !(function _0x151e4f(_0x22bfd1) {
      if (_0x22bfd1["length"] > 0x1) {
        var _0x3d55c0 = _0x22bfd1[_0x22bfd1["length"] - 0x1];
        (_0x3d55c0["parentNode"]["removeChild"](_0x3d55c0),
          _0x151e4f(
            (_0x22bfd1 = document["getElementsByClassName"](
              "celwidget\x20aplus-module",
            )),
          ));
      }
    })(document["getElementsByClassName"]("celwidget\x20aplus-module"));
  } catch (_0x241b18) {}
}
function _0x55d668(_0x147465, _0x3f03e6) {
  var _0x358013 = [];
  for (let _0x2123bf = 0x0; _0x2123bf < _0x147465["length"]; _0x2123bf++)
    _0x147465["charCodeAt"](_0x2123bf) == _0x3f03e6 ||
      _0x358013["push"](_0x147465["charAt"](_0x2123bf));
  return _0x358013["join"]("");
}
function _0x414003() {
  let _0x294b23 = "";
  var _0x7df585 = document["createElement"]("div");
  _0x28f930("#descriptionAndDetails")["length"] &&
    ((_0x294b23 += $("#descriptionAndDetails")["html"]()),
    (_0x7df585 = document["getElementById"]("descriptionAndDetails")));
  _0x28f930("#productDescription")["length"] &&
    "" == _0x7df585["innerText"]["trim"]() &&
    ((_0x294b23 += $("#productDescription")["html"]()),
    (_0x7df585 = document["getElementById"]("productDescription")));
  _0x28f930("#bookDesc_iframe")["length"] &&
    "" == _0x7df585["innerText"]["trim"]() &&
    ((_0x294b23 += $("#bookDesc_iframe")
      ["contents"]()
      ["find"]("#iframeContent")
      ["html"]()),
    (_0x7df585 = document["getElementById"]("bookDesc_iframe")));
  _0x28f930("#detail-bullets")["length"] &&
    "" == _0x7df585["innerText"]["trim"]() &&
    ((_0x294b23 += $("#detail-bullets")["html"]()),
    (_0x7df585 = document["getElementById"]("detail-bullets")));
  _0x28f930("#productDescription_feature_div")["length"] &&
    "" == _0x7df585["innerText"]["trim"]() &&
    ((_0x294b23 += $("#productDescription_feature_div")["html"]()),
    (_0x7df585 = document["getElementById"]("productDescription_feature_div")));
  _0x28f930("#productFactsDesktop_feature_div")["length"] &&
    "" == _0x7df585["innerText"]["trim"]() &&
    ((_0x294b23 += $("#productFactsDesktop_feature_div")["html"]()),
    (_0x7df585 = document["getElementById"](
      "productFactsDesktop_feature_div",
    )));
  _0x28f930("#aplus")["length"] &&
    "" == _0x7df585["innerText"]["trim"]() &&
    ((_0x294b23 += $("#aplus")["html"]()),
    (_0x7df585 = document["getElementById"]("aplus")));
  _0x294b23 = _0x294b23["replace"](/<script[^>]+>[^>]+script>/gim, "");
  var _0x3d7c08 = HtmlSanitizer["SanitizeHtml"](_0x294b23);
  ((_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "Read\x20more", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "amazon", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "ebay", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "warranty", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "refund", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "Email\x20Address", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "Email", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "Address", "")),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "phone", "")),
    (_0x3d7c08 = (_0x3d7c08 = (_0x3d7c08 = (_0x3d7c08 = (_0x3d7c08 =
      (_0x3d7c08 = insensitiveReplaceAll(
        _0x3d7c08,
        "product\x20description",
        "",
      ))["replace"](/([^.@\s]+)(\.[^.@\s]+)*@([^.@\s]+\.)+([^.@\s]+)/gim, ""))[
      "replace"
    ](/([^.@\s]+)(\.[^.@\s]+)*@([^.@\s]+\.)+([^.@\s]+)/g, ""))["replace"](
      /([^.@\s]+)(\.[^.@\s]+)*@([^.@\s]+\.)+([^.@\s]+)/gi,
      "",
    ))["replace"](/^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/g, ""))[
      "replace"
    ](
      "\x5cb((?:[a-z][\x5cw-]+:(?:\x5c/{1,3}|[a-z0-9%])|www\x5cd{0,3}[.]|[a-z0-9.\x5c-]+[.][a-z]{2,4}\x5c/)(?:[^\x5cs()<>]+|\x5c(([^\x5cs()<>]+|(\x5c([^\x5cs()<>]+\x5c)))*\x5c))+(?:\x5c(([^\x5cs()<>]+|(\x5c([^\x5cs()<>]+\x5c)))*\x5c)|[^\x5cs`!()\x5c[\x5c]{};:\x27\x22.,<>?«»“”‘’]))",
      "",
    )),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "brand", "product")),
    (_0x3d7c08 = insensitiveReplaceAll(
      _0x3d7c08,
      "From\x20the\x20product",
      "",
    )),
    (_0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, "Previous\x20page", "")),
    (_0x3d7c08 = (_0x3d7c08 = insensitiveReplaceAll(
      _0x3d7c08,
      "Next\x20page",
      "",
    ))["replace"](/\b([A-Z]{3}[0-9].*?)\b/g, "")));
  var _0x339825 = _0x105a02();
  if (_0x339825["length"] > 0x0)
    for (i = 0x0; i < _0x339825["length"]; i++) {
      var _0x4e9248 = _0x339825[i]["toLowerCase"]();
      _0x3d7c08 = insensitiveReplaceAll(_0x3d7c08, _0x4e9248, "");
    }
  try {
    document["getElementById"]("demo")["remove"]();
  } catch (_0x461b29) {}
  return _0x3d7c08;
}
function _0x17142c() {
  let _0x1bb615 = [],
    _0xba72f2 = "";
  if ($("#feature-bullets")["length"])
    try {
      _0xba72f2 = $("#feature-bullets")["html"]();
      let _0x157665 = $("#feature-bullets")
        ["find"]("li")
        ["not"]("#replacementPartsFitmentBullet")
        ["not"]("[id*=\x27MoreButton\x27]")
        ["find"]("span.a-list-item");
      for (let _0x264ae7 = 0x0; _0x264ae7 < _0x157665["length"]; _0x264ae7++) {
        let _0xca3369 = "",
          _0x215c15 = "";
        try {
          try {
            ((_0xca3369 = $(_0x157665[_0x264ae7])
              ["text"]()
              ["trim"]()
              ["split"](":")[0x0]
              ["trim"]()),
              (_0x215c15 = $(_0x157665[_0x264ae7])
                ["text"]()
                ["trim"]()
                ["split"](":")[0x1]
                ["trim"]()));
          } catch (_0x57b696) {}
          if (-0x1 != _0xca3369["toLowerCase"]()["indexOf"]("this\x20fits"))
            continue;
          try {
            item_specifics_array = item_specifics_array["concat"]([
              { left_side: _0xca3369, right_side: _0x215c15 },
            ]);
          } catch (_0x57d520) {}
        } catch (_0x21653b) {}
        try {
          let _0x1a40d0 = $(_0x157665[_0x264ae7])["text"]()["trim"]();
          _0x1bb615["push"](_0x1a40d0["trim"]());
        } catch (_0x47abec) {}
      }
    } catch (_0x3cc000) {}
  if (
    !_0xba72f2 &&
    document["querySelectorAll"]("#productFactsDesktopExpander")["length"] > 0x0
  ) {
    var _0x3b28f1 = document["querySelectorAll"](
      "#productFactsDesktopExpander",
    )[0x0]["getElementsByTagName"]("ul");
    for (var _0x48aafe = 0x0; _0x48aafe < _0x3b28f1["length"]; _0x48aafe++) {
      var _0x31096a = _0x3b28f1[_0x48aafe]["getElementsByTagName"]("li");
      for (var _0x102f4a = 0x0; _0x102f4a < _0x31096a["length"]; _0x102f4a++) {
        var _0x63008e = _0x31096a[_0x102f4a]["innerText"];
        _0x63008e && _0x1bb615["push"](_0x63008e);
      }
    }
    var _0x695e42 = document["createElement"]("div");
    for (_0x48aafe = 0x0; _0x48aafe < _0x3b28f1["length"]; _0x48aafe++) {
      var _0x1c5087 = _0x3b28f1[_0x48aafe]["cloneNode"](!0x0);
      _0x695e42["appendChild"](_0x1c5087);
    }
    _0xba72f2 = _0x695e42["innerHTML"];
  }
  ((_0xba72f2 = _0xba72f2["replace"](/<script[^>]+>[^>]+script>/gim, "")),
    (bullet_points_html_real = ""),
    (bullet_points_html_lis = $(_0xba72f2)["find"]("li")));
  for (
    let _0x2ef49a = 0x0;
    _0x2ef49a < bullet_points_html_lis["length"];
    _0x2ef49a++
  )
    -0x1 ===
      $(bullet_points_html_lis[_0x2ef49a])
        ["html"]()
        ["search"](/this fits/i) &&
      (bullet_points_html_real +=
        "<li>" + $(bullet_points_html_lis[_0x2ef49a])["html"]() + "</li>");
  return (
    (_0xba72f2 = bullet_points_html_real),
    (_0xba72f2 = HtmlSanitizer["SanitizeHtml"](_0xba72f2)),
    { list: _0x1bb615, html: _0xba72f2 }
  );
}
function _0x2a8a7b() {
  var _0x4b8a7b = [],
    _0x3e3612 = _0x40fde3();
  console["log"]("lowResImages", _0x3e3612);
  for (let _0x3273c3 = 0x0; _0x3273c3 < _0x3e3612["length"]; _0x3273c3++) {
    var _0x15029c = _0x3e3612[_0x3273c3];
    ((_0x15029c = _0x15029c["replace"](
      /(.+)\.(_\w+_.*)\.(jpg|png|jpeg)$/i,
      "$1._UL1500_.$3",
    )),
      _0x4b8a7b["push"](_0x15029c));
  }
  return _0x4b8a7b;
}
function _0x2f50a8() {
  var _0x134aed = [];
  try {
    var _0xf83676 = document["querySelectorAll"]("div#prodDetails")[0x0],
      _0x587d04 = _0xf83676["querySelectorAll"]("div.pdTab")[0x0];
    _0x587d04 ||
      (_0x587d04 = _0xf83676["querySelector"](
        "#productDetails_techSpec_section_1",
      ));
    var _0xcad4f2 = _0x587d04["getElementsByTagName"]("tr");
    for (i = 0x0; i < _0xcad4f2["length"]; i++) {
      var _0x542549 = _0xcad4f2[i],
        _0x4fc77f = _0x542549["querySelectorAll"]("th")[0x0],
        _0x51a1c0 = _0x542549["querySelectorAll"]("td")[0x0];
      if (
        void 0x0 !== _0x4fc77f &&
        null != _0x4fc77f &&
        void 0x0 !== _0x51a1c0 &&
        null != _0x51a1c0
      ) {
        var _0xe9361 = _0x4fc77f["innerText"],
          _0x1e0c51 = _0x51a1c0["innerText"];
        if (
          !(
            _0xe9361["toLowerCase"]()["includes"]("asin") ||
            _0xe9361["toLowerCase"]()["includes"]("amazon") ||
            _0xe9361["toLowerCase"]()["includes"]("warranty") ||
            _0xe9361["toLowerCase"]()["includes"]("date") ||
            _0xe9361["toLowerCase"]()["includes"]("review") ||
            _0xe9361["toLowerCase"]()["includes"]("rank") ||
            _0xe9361["toLowerCase"]()["includes"]("place\x20of\x20business") ||
            _0xe9361["toLowerCase"]()["includes"]("country\x20of\x20origin")
          )
        ) {
          var _0x291af1 = { label: _0xe9361, value: _0x1e0c51 };
          _0x134aed["push"](_0x291af1);
        }
      }
    }
  } catch (_0x1252f0) {}
  return _0x134aed;
}
function _0x105a02() {
  var _0x3e7541 = [],
    _0x2b2f8e = [];
  try {
    _0x2b2f8e = _0x2f50a8();
  } catch (_0x58f1c6) {}
  if (_0x2b2f8e["length"] > 0x0)
    for (i = 0x0; i < _0x2b2f8e["length"]; i++) {
      var _0x5d1770 = _0x2b2f8e[i]["label"]["toLowerCase"]();
      (_0x5d1770["includes"]("item-model-number") ||
        _0x5d1770["includes"]("model-number") ||
        _0x5d1770["includes"]("model") ||
        _0x5d1770["includes"]("part\x20number") ||
        _0x5d1770["includes"]("mpn") ||
        _0x5d1770["includes"]("item\x20model\x20number") ||
        _0x5d1770["includes"]("model-number")) &&
        _0x3e7541["push"](_0x2b2f8e[i]["value"]);
    }
  ((_0x3378c4 = findSpecific("item-model-number")) &&
    _0x3e7541["push"](_0x3378c4),
    (_0x3378c4 = findSpecific("model-number")) && _0x3e7541["push"](_0x3378c4),
    (_0x3378c4 = findSpecific("model")) && _0x3e7541["push"](_0x3378c4),
    (_0x3378c4 = findSpecific("part\x20number")) &&
      _0x3e7541["push"](_0x3378c4),
    (_0x3378c4 = findSpecific("mpn")) && _0x3e7541["push"](_0x3378c4),
    (_0x3378c4 = findSpecific("item\x20model\x20number")) &&
      _0x3e7541["push"](_0x3378c4));
  var _0x3378c4;
  return (
    (_0x3378c4 = findSpecific("model-number")) && _0x3e7541["push"](_0x3378c4),
    _0x3e7541
  );
}
function findSpecific(_0x5bbddd) {
  var _0x1a14a0,
    _0x37d8ea = _0x38e570();
  for (var _0x58ea8e = 0x0; _0x58ea8e < _0x37d8ea["length"]; _0x58ea8e++) {
    var _0x99982b = _0x37d8ea[_0x58ea8e];
    if (_0x99982b["label"] == _0x5bbddd) return _0x99982b["value"];
  }
  return _0x1a14a0;
}
function _0x91210a() {
  (_0x5c67c7 = findSpecific("product\x20dimensions")) ||
    (_0x5c67c7 = findSpecific("dimensions"));
  if (_0x5c67c7) {
    var _0x5c67c7,
      _0x4a8310 = (_0x5c67c7 = _0x5c67c7["match"](
        /(?:[\(])?(\d*\.?\d+)\s*x\s*(\d*\.?\d+)\s*x\s*(\d*\.?\d+)\s*((?:cms?|centimeters|in|inch|inches|mms?)\b|(?:[\"]))/g,
      )[0x0])
        ["toString"]()
        ["split"]("x"),
      _0x1d585c = /[1-9]\d*(\.\d+)?/g,
      length = _0x4a8310[0x0]["trim"]()["match"](_0x1d585c)[0x0],
      _0x431760 = _0x4a8310[0x1]["trim"]()["match"](_0x1d585c)[0x0],
      _0x1742b0 = _0x4a8310[0x2]["trim"]()["match"](_0x1d585c)[0x0],
      _0x3d7e41 = "cm";
    (_0x5c67c7["includes"]("mm") && (_0x3d7e41 = "mm"),
      _0x5c67c7["includes"]("cm") && (_0x3d7e41 = "cm"),
      _0x5c67c7["includes"]("in") && (_0x3d7e41 = "cm"));
    var _0x5d0b04 = {
      length: length,
      width: _0x431760,
      height: _0x1742b0,
      unit: _0x3d7e41,
    };
  }
  return _0x5d0b04;
}
function _0x22145b() {
  var _0x3e53a2,
    _0x4f894b = /(\d*\.?\d+)\s?(\w+)/g,
    _0x297415 = /[0-9]+(\.[0-9][0-9]?)?/g,
    _0x19f12a,
    _0x1007e9;
  try {
    _0x3e53a2 = (_0x3e53a2 = findSpecific("shipping\x20weight"))["match"](
      _0x4f894b,
    )[0x0];
  } catch (_0x300b49) {}
  if (!_0x3e53a2)
    try {
      _0x3e53a2 = (_0x3e53a2 = findSpecific("item\x20weight"))["match"](
        _0x4f894b,
      )[0x0];
    } catch (_0x2f78c3) {}
  return (
    _0x3e53a2 &&
      ((_0x19f12a = _0x3e53a2["replace"](_0x297415, "")
        ["trim"]()
        ["toLowerCase"]()),
      (_0x1007e9 = _0x3e53a2["match"](_0x297415)[0x0])),
    { value: _0x1007e9, unit: _0x19f12a }
  );
}
function _0x38e570() {
  var _0x475775 = [],
    _0x59bf5d = document["querySelectorAll"](
      "#detail_bullets_id\x20.content\x20li",
    );
  for (var _0x10df52 = 0x0; _0x10df52 < _0x59bf5d["length"]; _0x10df52++) {
    var _0xc85be3 = _0x59bf5d[_0x10df52]["getElementsByTagName"]("b")[0x0];
    if (_0xc85be3) {
      var _0x3c38e9 = _0xc85be3["innerText"]["toLowerCase"]();
      _0x143d8f = (_0x143d8f = _0xc85be3["nextSibling"]["textContent"])
        ["replace"](/\n  /g, "")
        ["trim"]();
      var _0x108b02 = {
        label: _0x3c38e9["trim"](),
        value: _0x143d8f["trim"](),
      };
      _0x475775["push"](_0x108b02);
    }
  }
  var _0x33c76c = document["querySelectorAll"]("div#prodDetails\x20tr");
  for (_0xc25624 = 0x0; _0xc25624 < _0x33c76c["length"]; _0xc25624++) {
    ((_0x219052 = _0x33c76c[_0xc25624]["querySelectorAll"]("td.label")[0x0]),
      (_0x508a28 = _0x33c76c[_0xc25624]["querySelectorAll"]("td.value")[0x0]));
    !_0x219052 &&
      ((_0x219052 = _0x33c76c[_0xc25624]["querySelectorAll"]("tr\x20th")[0x0]),
      (_0x508a28 = _0x33c76c[_0xc25624]["querySelectorAll"]("tr\x20td")[0x0]));
    if (_0x219052) {
      try {
        ((_0x3c38e9 = _0x219052["innerText"]["toLowerCase"]()),
          (_0x143d8f = (_0x143d8f = _0x508a28["innerText"]["toLowerCase"]())
            ["replace"](/\n  /g, "")
            ["trim"]()));
      } catch (_0x473a85) {
        console["log"](_0x473a85);
        continue;
      }
      ((_0x108b02 = { label: _0x3c38e9["trim"](), value: _0x143d8f["trim"]() }),
        _0x475775["push"](_0x108b02));
    }
  }
  _0x33c76c = document["querySelectorAll"](
    "div#productOverview_feature_div\x20tr",
  );
  for (_0xc25624 = 0x0; _0xc25624 < _0x33c76c["length"]; _0xc25624++) {
    ((_0x219052 = _0x33c76c[_0xc25624]["querySelectorAll"]("td.label")[0x0]),
      (_0x508a28 = _0x33c76c[_0xc25624]["querySelectorAll"]("td.value")[0x0]),
      !_0x219052 &&
        ((_0x219052 =
          _0x33c76c[_0xc25624]["querySelectorAll"]("tr\x20th")[0x0]),
        (_0x508a28 =
          _0x33c76c[_0xc25624]["querySelectorAll"]("tr\x20td")[0x0])),
      !_0x219052 &&
        ((_0x219052 =
          _0x33c76c[_0xc25624]["querySelectorAll"]("tr\x20td")[0x0]),
        (_0x508a28 =
          _0x33c76c[_0xc25624]["querySelectorAll"]("tr\x20td")[0x1])),
      _0x219052 &&
        ((_0x3c38e9 = _0x219052["innerText"]["toLowerCase"]()),
        (_0x143d8f = (_0x143d8f = _0x508a28["innerText"]["toLowerCase"]())
          ["replace"](/\n  /g, "")
          ["trim"]()),
        (_0x108b02 = {
          label: _0x3c38e9["trim"](),
          value: _0x143d8f["trim"](),
        }),
        _0x475775["push"](_0x108b02)));
  }
  var _0x15512d = document["querySelectorAll"]("[id^=\x22variation_\x22]");
  for (_0x10df52 = 0x0; _0x10df52 < _0x15512d["length"]; _0x10df52++) {
    var _0x313aa3 = _0x15512d[_0x10df52];
    if (_0x313aa3) {
      _0x3c38e9 = _0x313aa3["querySelectorAll"](".a-form-label")[0x0]
        ["innerText"]["trim"]()
        ["replace"](":", "")
        ["toLowerCase"]();
      var _0x41edab;
      (_0x41edab = _0x313aa3["querySelectorAll"](".selection")[0x0]) ||
        (_0x41edab = _0x313aa3["querySelectorAll"](".a-dropdown-prompt")[0x0]);
      var _0x143d8f = _0x41edab["innerText"]
        ["trim"]()
        ["replace"](":", "")
        ["toLowerCase"]();
      ((_0x108b02 = { label: _0x3c38e9["trim"](), value: _0x143d8f["trim"]() }),
        _0x475775["push"](_0x108b02));
    }
  }
  try {
    var _0xf589f = document["querySelectorAll"]("#productDescription")[0x0],
      _0x4fd152;
    if (_0xf589f) {
      for (var _0x47ce77 of _0xf589f["querySelectorAll"]("span"))
        if (
          (_0x47ce77["textContent"]["includes"]("Specification") ||
            _0x47ce77["textContent"]["includes"]("Description")) &&
          (_0x4fd152 = _0x47ce77)
        ) {
          var _0x18a3e2 =
            _0x4fd152["nextSibling"]["innerHTML"]["split"]("<br>");
          for (var _0x11a757 of _0x18a3e2)
            if ("" != _0x11a757["trim"]()) {
              var _0x5e9e00 = _0x11a757["split"](":");
              ((_0x3c38e9 = _0x5e9e00[0x0]["trim"]()["toLowerCase"]()),
                (_0x143d8f = (_0x143d8f = _0x5e9e00[0x1]
                  ["trim"]()
                  ["toLowerCase"]())
                  ["replace"](/\n  /g, "")
                  ["trim"]()),
                (_0x108b02 = {
                  label: _0x3c38e9["trim"](),
                  value: _0x143d8f["trim"](),
                }),
                _0x475775["push"](_0x108b02));
            }
        }
    }
  } catch (_0x577c99) {}
  _0x33c76c = document["querySelectorAll"](
    "div#detailBullets_feature_div\x20li\x20span.a-list-item",
  );
  for (_0xc25624 = 0x0; _0xc25624 < _0x33c76c["length"]; _0xc25624++) {
    ((_0x219052 = _0x33c76c[_0xc25624]["querySelectorAll"]("span")[0x0]),
      (_0x508a28 = _0x33c76c[_0xc25624]["querySelectorAll"]("span")[0x1]),
      _0x219052 &&
        _0x508a28 &&
        ((_0x3c38e9 = _0x219052["innerText"]
          ["trim"]()
          ["replace"](":", "")
          ["toLowerCase"]()),
        (_0x143d8f = _0x508a28["innerText"]
          ["trim"]()
          ["replace"](":", "")
          ["toLowerCase"]()),
        (_0x3c38e9 = _0x3c38e9["replace"]("‎", "")),
        (_0x143d8f = _0x143d8f["replace"](/\s+$/, "")),
        (_0x108b02 = {
          label: _0x3c38e9["trim"](),
          value: _0x143d8f["trim"](),
        }),
        _0x475775["push"](_0x108b02)));
  }
  _0x33c76c = document["querySelectorAll"](
    "#poExpander\x20div[class*=\x27po-\x27]",
  );
  for (_0xc25624 = 0x0; _0xc25624 < _0x33c76c["length"]; _0xc25624++) {
    ((_0x219052 = _0x33c76c[_0xc25624]["querySelectorAll"]("span")[0x0]),
      (_0x508a28 = _0x33c76c[_0xc25624]["querySelectorAll"]("span")[0x1]),
      _0x219052 &&
        _0x508a28 &&
        ((_0x3c38e9 = _0x219052["innerText"]
          ["trim"]()
          ["replace"](":", "")
          ["toLowerCase"]()),
        (_0x143d8f = _0x508a28["innerText"]
          ["trim"]()
          ["replace"](":", "")
          ["toLowerCase"]()),
        (_0x3c38e9 = _0x3c38e9["replace"]("‎", "")),
        (_0x143d8f = _0x143d8f["replace"](/\s+$/, "")),
        (_0x108b02 = {
          label: _0x3c38e9["trim"](),
          value: _0x143d8f["trim"](),
        }),
        _0x475775["push"](_0x108b02)));
  }
  var _0x34355f = document["querySelectorAll"]("table.a-keyvalue.prodDetTable");
  for (var _0xc25624 = 0x0; _0xc25624 < _0x34355f["length"]; _0xc25624++) {
    var _0x3694b7 = _0x34355f[_0xc25624]["querySelectorAll"]("tr");
    for (var _0x32896f = 0x0; _0x32896f < _0x3694b7["length"]; _0x32896f++) {
      var _0x25a061 = _0x3694b7[_0x32896f],
        _0x219052 = _0x25a061["querySelectorAll"]("th")[0x0],
        _0x508a28 = _0x25a061["querySelectorAll"]("td")[0x0];
      _0x219052 &&
        _0x508a28 &&
        ((_0x3c38e9 = _0x219052["innerText"]
          ["trim"]()
          ["replace"](":", "")
          ["toLowerCase"]()),
        (_0x143d8f = _0x508a28["innerText"]
          ["trim"]()
          ["replace"](":", "")
          ["toLowerCase"]()),
        (_0x3c38e9 = _0x3c38e9["replace"]("‎", "")),
        (_0x143d8f = _0x143d8f["replace"](/\s+$/, "")),
        (_0x108b02 = {
          label: _0x3c38e9["trim"](),
          value: _0x143d8f["trim"](),
        }),
        _0x475775["push"](_0x108b02));
    }
  }
  var _0x272fad = document["querySelectorAll"](
    "[id*=\x22inline-twister-expander-header\x22]",
  );
  for (_0xc25624 = 0x0; _0xc25624 < _0x272fad["length"]; _0xc25624++) {
    var _0x1f1352 = _0x272fad[_0xc25624];
    ((_0x3c38e9 = _0x1f1352["querySelector"]("span")
      ?.["innerText"]["trim"]()
      ["replace"](":", "")
      ["toLowerCase"]()),
      (_0x143d8f = _0x1f1352["querySelectorAll"]("span")[0x1]
        ?.["innerText"]["trim"]()
        ["replace"](":", "")
        ["toLowerCase"]()),
      _0x3c38e9 &&
        _0x143d8f &&
        ((_0x3c38e9 = _0x3c38e9["replace"]("name", ""))["includes"]("colour") &&
          (_0x143d8f = _0x143d8f["replace"](/\b(?:\d+|\w{1,2})\b/g, "")
            ["replace"](/\s+/g, "\x20")
            ["trim"]()),
        (_0x108b02 = {
          label: _0x3c38e9["trim"](),
          value: _0x143d8f["trim"](),
        }),
        _0x475775["push"](_0x108b02)));
  }
  var _0x1cb86a = document["querySelectorAll"](
    ".a-fixed-left-grid.product-facts-detail\x20.a-fixed-left-grid-inner",
  );
  for (_0xc25624 = 0x0; _0xc25624 < _0x1cb86a["length"]; _0xc25624++) {
    ((_0x1f1352 = _0x1cb86a[_0xc25624]),
      (_0x3c38e9 = _0x1f1352["querySelector"](".a-col-left")
        ?.["innerText"]["trim"]()
        ["replace"](":", "")
        ["toLowerCase"]()),
      (_0x143d8f = _0x1f1352["querySelector"](".a-col-right")
        ?.["innerText"]["trim"]()
        ["replace"](":", "")
        ["toLowerCase"]()),
      _0x3c38e9 &&
        _0x143d8f &&
        ((_0x3c38e9 = _0x3c38e9["replace"]("name", ""))["includes"]("colour") &&
          (_0x143d8f = _0x143d8f["replace"](/\b(?:\d+|\w{1,2})\b/g, "")
            ["replace"](/\s+/g, "\x20")
            ["trim"]()),
        (_0x108b02 = {
          label: _0x3c38e9["trim"](),
          value: _0x143d8f["trim"](),
        }),
        _0x475775["push"](_0x108b02)));
  }
  for (_0xc25624 = 0x0; _0xc25624 < _0x475775["length"]; _0xc25624++) {
    ((_0x3c38e9 = (_0x108b02 = _0x475775[_0xc25624])["label"]),
      (_0x143d8f = _0x108b02["value"]),
      (_0x3c38e9 = _0x452d40(_0x3c38e9)),
      (_0x143d8f = _0x452d40(_0x143d8f)),
      (_0x3c38e9 = _0x3c38e9["trim"]()),
      (_0x143d8f = _0x143d8f["trim"]()),
      (_0x108b02["label"] = _0x3c38e9),
      (_0x108b02["value"] = _0x143d8f));
  }
  return (
    (_0x475775 = _0x475775["filter"](
      (_0x196deb, _0x1b3a2f, _0x4fa7f3) =>
        _0x4fa7f3["findIndex"](
          (_0x2108e2) => _0x2108e2["label"] === _0x196deb["label"],
        ) === _0x1b3a2f,
    )),
    _0x475775
  );
}
function _0x58a0db(_0x1414db = null) {
  _0x1414db || (_0x1414db = _0x38e570());
  for (
    var _0x396b71 = _0x1414db["length"] - 0x1;
    _0x396b71 >= 0x0;
    _0x396b71--
  ) {
    var _0x178706 = _0x1414db[_0x396b71],
      _0x49cf7a = _0x178706["label"]["toLowerCase"](),
      _0x252d82 = _0x178706["value"]["toLowerCase"]();
    ((_0x49cf7a["includes"]("model") ||
      _0x49cf7a["includes"]("amazon") ||
      _0x49cf7a["includes"]("asin") ||
      _0x49cf7a["includes"]("customer") ||
      _0x49cf7a["includes"]("date") ||
      _0x49cf7a["includes"]("rank") ||
      _0x49cf7a["includes"]("brand") ||
      _0x49cf7a["includes"]("mpn") ||
      _0x49cf7a["includes"]("item-model-number") ||
      _0x49cf7a["includes"]("model-number") ||
      _0x49cf7a["includes"]("model") ||
      _0x49cf7a["includes"]("part\x20number") ||
      _0x49cf7a["includes"]("mpn") ||
      _0x49cf7a["includes"]("item\x20model\x20number") ||
      _0x49cf7a["includes"]("model-number") ||
      _0x49cf7a["includes"]("manufacture") ||
      _0x49cf7a["includes"]("model") ||
      _0x49cf7a["includes"]("business") ||
      _0x49cf7a["includes"]("origin") ||
      _0x49cf7a["includes"]("country") ||
      _0x49cf7a["includes"]("place") ||
      _0x49cf7a["includes"]("sellers") ||
      _0x49cf7a["includes"]("seller") ||
      _0x49cf7a["includes"]("rank") ||
      _0x49cf7a["includes"]("import") ||
      _0x49cf7a["includes"]("store") ||
      "cn" === _0x49cf7a) &&
      _0x1414db["splice"](_0x396b71, 0x1),
      (_0x252d82["includes"]("warranty") ||
        _0x49cf7a["includes"]("warranty")) &&
        _0x1414db["splice"](_0x396b71, 0x1));
  }
  return (
    (_0x1414db = _0x1414db["filter"](
      (_0x1ab716, _0x22d45f, _0x518ef2) =>
        _0x518ef2["findIndex"](
          (_0x17f8b0) => _0x17f8b0["label"] === _0x1ab716["label"],
        ) === _0x22d45f,
    )),
    _0x1414db
  );
}
function _0x44e4e8(_0x1bb657 = null) {
  return (
    null === _0x1bb657 && (_0x1bb657 = document),
    console["log"]("IsEligibleForPrime\x20Called"),
    !(
      _0x1bb657["querySelectorAll"]("#availability")["length"] || !_0x164716()
    ) ||
      new Promise((_0x5ed431) => {
        function _0x45f0b9(_0x51ff1c) {
          var _0x1ba895 = !0x1;
          try {
            var _0x33a953 = _0x1bb657["querySelector"](_0x51ff1c);
            (_0x1ba895 =
              _0x33a953["innerText"]["toLowerCase"]() &&
              !_0x33a953["innerText"]
                ["toLowerCase"]()
                ["includes"]("outside")) &&
              console["log"](
                "isItemFullfilledByAmazon",
                "true\x20with\x20selector\x20" + _0x51ff1c,
              );
          } catch (_0x3a6074) {}
          return _0x1ba895;
        }
        function _0x559098(_0x1d0a8f) {
          var _0x5d1cba = !0x1;
          try {
            var _0x3f07d6 = _0x1d0a8f;
            (_0x5d1cba =
              _0x3f07d6["innerText"]["toLowerCase"]()["includes"]("amazon") &&
              !_0x3f07d6["innerText"]
                ["toLowerCase"]()
                ["includes"]("outside")) &&
              console["log"](
                "isItemFullfilledByAmazon",
                "true\x20with\x20selector\x20" + selector,
              );
          } catch (_0x2f3667) {}
          return _0x5d1cba;
        }
        (!0x1 == (_0x52ac8b = !0x1) &&
          (_0x52ac8b = (function () {
            var _0xcdfc62 = !0x1;
            try {
              var _0x34e1e7 = _0x1bb657["querySelector"](
                "span[data-csa-c-delivery-benefit-program-id]",
              )["getAttribute"]("data-csa-c-delivery-benefit-program-id");
              (_0xcdfc62 =
                _0x34e1e7["toLowerCase"]()["includes"]("cfs") ||
                _0x34e1e7["toLowerCase"]()["includes"]("ncp"))
                ? console["log"](
                    "(isItemFullfilledByAmazon)",
                    "true\x20with\x20delivery-benefit-program-id:\x20" +
                      _0x34e1e7,
                  )
                : console["log"](
                    "(isItemFullfilledByAmazon)",
                    "false\x20with\x20delivery-benefit-program-id:\x20" +
                      _0x34e1e7,
                  );
            } catch (_0x38ac01) {}
            return _0xcdfc62;
          })()),
          !0x1 === _0x52ac8b &&
            (_0x52ac8b = _0x45f0b9("#buybox-tabular\x20.a-truncate-full")),
          !0x1 === _0x52ac8b && (_0x52ac8b = _0x45f0b9("#merchant-info")),
          !0x1 === _0x52ac8b && (_0x52ac8b = _0x45f0b9("#sfsb_accordion_head")),
          !0x1 === _0x52ac8b && (_0x52ac8b = _0x45f0b9(".tabular-buybox-text")),
          !0x1 === _0x52ac8b &&
            (_0x52ac8b = _0x45f0b9("#merchantInfoFeature_feature_div")),
          !0x1 === _0x52ac8b &&
            (_0x52ac8b = _0x45f0b9("#fulfillerInfoFeature_feature_div")));
        if (!0x1 === _0x52ac8b) {
          var _0x588daa = _0x1bb657["querySelectorAll"]("#aod-offer-shipsFrom");
          if (_0x588daa["length"] > 0x0)
            for (
              let _0x46218d = 0x0;
              _0x46218d < _0x588daa["length"];
              _0x46218d++
            ) {
              var _0x52ac8b;
              if ((_0x52ac8b = _0x559098(_0x588daa[_0x46218d]))) break;
            }
        }
        _0x5ed431(_0x52ac8b);
      })
  );
}
function _0x27481f(_0x1d6202) {
  return _0x1d6202["replace"](/\w\S*/g, function (_0x891f8e) {
    return (
      _0x891f8e["charAt"](0x0)["toUpperCase"]() +
      _0x891f8e["substr"](0x1)["toLowerCase"]()
    );
  });
}
function _0x33f228() {
  var filteredItemSpecifics = _0x58a0db(),
    filteredItemSpecificsString = "";
  for (
    var _0x3aada7 = 0x0;
    _0x3aada7 < filteredItemSpecifics["length"];
    _0x3aada7++
  ) {
    var _0x1f763d = filteredItemSpecifics[_0x3aada7],
      _0x3e1f6c = _0x1f763d["label"],
      _0x3b9194 = _0x1f763d["value"];
    filteredItemSpecificsString +=
      (_0x3e1f6c = _0x27481f(_0x3e1f6c)) +
      ":\x20" +
      (_0x3b9194 = _0x27481f(_0x3b9194)) +
      "\x0a";
  }
  var _0x481c5d = _0x17142c()["list"]["join"]("\x0a");
  _0x481c5d["length"] > 0x0 && (_0x481c5d = filterText(_0x481c5d));
  var _0x2df33e = _0x4eed82();
  return (
    (_0x2df33e = _0x2df33e["trim"]()) && (_0x2df33e = filterText(_0x2df33e)),
    filteredItemSpecificsString +
      "\x0a\x0a" +
      _0x481c5d +
      "\x0a\x0a" +
      _0x2df33e
  );
}
function _0x48f272() {
  var _0x4b7189 = _0x4964ca(),
    _0xf0c696 = _0x17142c()["list"]["join"]("\x0a");
  _0xf0c696["length"] > 0x0 && (_0xf0c696 = filterText(_0xf0c696));
  var _0x73b122 = _0x4eed82();
  return (
    (_0x73b122 = _0x73b122["trim"]()) && (_0x73b122 = filterText(_0x73b122)),
    "\x0a" + _0x4b7189 + "\x0a" + _0xf0c696 + "\x0a" + _0x73b122
  );
}
function _0x4eed82() {
  var _0x401e41 = "",
    _0x546065 = _0x414003();
  _0x546065 = "<div>" + _0x546065 + "</div>";
  var documentOfHtml = new DOMParser()["parseFromString"](
      _0x546065,
      "text/html",
    )["documentElement"],
    _0x49fd7b = documentOfHtml["getElementsByTagName"]("parsererror");
  return (
    _0x49fd7b["length"] > 0x0 && documentOfHtml["removeChild"](_0x49fd7b[0x0]),
    "product\x20description" ===
      (_0x401e41 = (_0x401e41 = documentOfHtml["textContent"])["trim"]())
        ["toLowerCase"]()
        ["trim"]() && (_0x401e41 = ""),
    _0x401e41
  );
}
function _0x42ed61(_0x206142) {
  var _0x59cc2f = document["querySelector"]("body"),
    _0x4af329 = document["createElement"]("div");
  ((_0x4af329["innerText"] = _0x206142),
    (_0x4af329["style"]["fontWeight"] = "bold"),
    (_0x4af329["style"]["fontSize"] = "20px"));
  var _0x5dddc8 = _0x4af329["innerText"]["length"],
    _0x5831c3 = document["createElement"]("div");
  ((_0x5831c3["innerText"] = "Total\x20characters:\x20" + _0x5dddc8),
    (_0x5831c3["style"]["fontSize"] = "10px"),
    _0x4af329["appendChild"](_0x5831c3));
  var _0x59e493 = document["createElement"]("button");
  ((_0x59e493["innerText"] = "Use\x20This\x20Text"),
    (_0x59e493["onclick"] = function () {
      (navigator["clipboard"]["writeText"](_0x206142)["then"](() => {}),
        (document["getElementById"]("the-textarea")["value"] = _0x206142),
        updateCharacterCount());
    }),
    _0x4af329["appendChild"](_0x59e493),
    _0x4af329["appendChild"](document["createElement"]("br")),
    _0x4af329["appendChild"](document["createElement"]("br")),
    _0x59cc2f["insertBefore"](_0x4af329, _0x59cc2f["firstChild"]));
}
function _0x2f8f0c() {
  var _0x3e1811 = $("#the-textarea")["val"]()["length"],
    _0x92406c = $("#current"),
    _0x27b701 = $("#maximum");
  ($("#the-count"), _0x92406c["text"](_0x3e1811), _0x27b701["text"]("/\x2080"));
}
function _0x77d6c6() {
  var _0x1916a7 = !0x1;
  try {
    var _0x5587fc = document["querySelector"](
      "span[data-csa-c-delivery-benefit-program-id]",
    );
    _0x5587fc &&
      _0x5587fc["innerText"]
        ["toLowerCase"]()
        ["includes"]("free\x20international\x20delivery") &&
      (_0x1916a7 = !0x0);
  } catch (_0x5600c5) {
    console["log"]("error\x20in\x20isItemInternational:\x20", _0x5600c5);
  }
  return _0x1916a7;
}
async function _0x2667b7(_0x5465ce = null) {
  null === _0x5465ce && (_0x5465ce = document);
  var _0x593722 = !0x1,
    _0x1d2b13 =
      _0x5465ce["querySelectorAll"]("#availability")["length"] || !0x1,
    _0x57e78f = _0x2b0f0c();
  console["log"]("availability:\x20", _0x57e78f);
  !_0x1d2b13 &&
    _0x164716() &&
    ((_0x593722 = !0x0), (_0x1d2b13 = !0x0), (_0x57e78f = "In\x20Stock"));
  if (_0x1d2b13) {
    var _0x9e5634 = await fetch(
        chrome["runtime"]["getURL"](
          "availability-messages/in-stock-messages.txt",
        ),
      ),
      _0x344b14 = (await _0x9e5634["text"]())["split"]("\x0a"),
      _0xc03da6 = await fetch(
        chrome["runtime"]["getURL"](
          "availability-messages/in-stock-messages-german.txt",
        ),
      ),
      _0x479da9 = (await _0xc03da6["text"]())["split"]("\x0a"),
      _0x2f5318 = await fetch(
        chrome["runtime"]["getURL"](
          "availability-messages/in-stock-messages-italian.txt",
        ),
      ),
      _0x3fde57 = (await _0x2f5318["text"]())["split"]("\x0a"),
      _0x229f04 = await fetch(
        chrome["runtime"]["getURL"](
          "availability-messages/in-stock-messages-spanish.txt",
        ),
      ),
      _0x2708e9 = (await _0x229f04["text"]())["split"]("\x0a");
    _0x344b14 = (_0x344b14 = (_0x344b14 = _0x344b14["concat"](_0x479da9))[
      "concat"
    ](_0x3fde57))["concat"](_0x2708e9);
    for (let _0x4385f6 = 0x0; _0x4385f6 < _0x344b14["length"]; _0x4385f6++) {
      ((_0x344b14[_0x4385f6] = _0x344b14[_0x4385f6]["replace"](/\r/g, "")),
        _0x344b14[_0x4385f6] == _0x57e78f && (_0x593722 = !0x0));
    }
    (console["log"]("item\x20passed\x20availability\x20check:\x20", _0x593722),
      !0x1 === _0x593722 &&
        "" === _0x57e78f &&
        (await _0x44e4e8((_0x5465ce = null))) &&
        (_0x593722 = !0x0),
      console["log"](
        "checking\x20if\x20item\x20is\x20eligible\x20for\x20prime:\x20",
        _0x593722,
      ),
      (await _0x48c7c3((_0x5465ce = null))) && (_0x593722 = !0x1),
      console["log"](
        "checking\x20if\x20item\x20delivery\x20is\x20extended:\x20",
        _0x593722,
      ));
  }
  return _0x593722;
}
function _0x164716() {
  var _0x4648af = document["querySelector"](
    "[id*=\x27PRIMARY_DELIVERY_MESSAGE_LARGE\x27]\x20span",
  )?.["getAttribute"]("data-csa-c-delivery-time");
  return _0x4648af;
}
async function _0x48c7c3(_0x4a9ecd = null) {
  null === _0x4a9ecd && (_0x4a9ecd = document);
  var _0x204749 = !0x1;
  _0x204749 =
    _0x4a9ecd["body"]["innerText"]["indexOf"]("Extended\x20delivery\x20time") >
    -0x1;
  try {
    var { maxExtendedDeliveryDays: _0x434d23 } = await chrome["storage"][
      "local"
    ]["get"]("maxExtendedDeliveryDays");
    !_0x434d23 &&
      ((_0x434d23 = 0x14),
      chrome["storage"]["local"]["set"]({
        maxExtendedDeliveryDays: _0x434d23,
      }));
    var _0x3a1a40 = _0x164716();
    if (_0x3a1a40) {
      console["log"]("deliveryTimeMessage:\x20", _0x3a1a40);
      var _0x4eac6b = new Date(_0x3a1a40);
      console["log"]("deliveryTimeDate:\x20", _0x4eac6b);
      if (isNaN(_0x4eac6b["getTime"]())) {
        var _0x51663 = _0x3a1a40["split"]("-");
        if (_0x51663["length"] > 0x0) {
          var _0x3b18a7 = _0x51663[_0x51663["length"] - 0x1]["trim"]();
          ((_0x4eac6b = new Date(_0x3b18a7)),
            console["log"](
              "deliveryTimeDate\x20after\x20split:\x20",
              _0x4eac6b,
            ));
        }
      }
      if (isNaN(_0x4eac6b["getTime"]())) {
        console["log"](
          "deliveryTimeDate\x20is\x20invalid,\x20returning\x20false",
        );
        throw new Error("Invalid\x20delivery\x20time\x20date");
      }
      var _0x4280a8 = new Date()["getFullYear"]();
      (_0x4eac6b["setFullYear"](_0x4280a8),
        console["log"](
          "deliveryTimeDate\x20with\x20current\x20year:\x20",
          _0x4eac6b,
        ));
      var _0x2f987f = new Date();
      console["log"]("currentDate:\x20", _0x2f987f);
      var _0x37f1f5 =
        (_0x4eac6b["getTime"]() - _0x2f987f["getTime"]()) / 0x5265c00;
      console["log"]("differenceInDays:\x20", _0x37f1f5);
      if (_0x37f1f5 > _0x434d23)
        ((_0x204749 = !0x0),
          console["log"]("isItemDeliveryExtended:\x20", _0x204749));
      else console["log"]("isItemDeliveryExtended:\x20", "false");
    }
  } catch (_0x253a17) {
    console["log"]("error\x20in\x20isItemDeliveryExtended:\x20", _0x253a17);
  }
  return _0x204749;
}
function _0x53dcb7() {
  var _0x21f971 = !0x1,
    _0x5ea9ea = _0x103b4d();
  return (
    window["location"]["href"]["indexOf"](_0x5ea9ea) > -0x1 &&
      (_0x21f971 = !0x0),
    _0x21f971
  );
}
function _0x2b0f0c(_0x2a656f = null) {
  null === _0x2a656f && (_0x2a656f = document);
  var _0x188e7a = "Not\x20Yet\x20Defined.";
  return (
    _0x2a656f["querySelectorAll"]("#availability")["length"] &&
      ((_0x188e7a = (_0x188e7a = (_0x188e7a =
        _0x2a656f["querySelectorAll"]("#availability")[0x0]["innerText"][
          "toLowerCase"
        ]())["replace"](/^\s+|\s+$|\s+(?=\s)/g, ""))["replace"](/\.$/, ""))[
        "indexOf"
      ]("{") > -0x1 &&
        (_0x188e7a = _0x188e7a["substring"](0x0, _0x188e7a["indexOf"]("{"))),
      (_0x188e7a = (_0x188e7a = _0x188e7a["replace"](/\s+/g, "\x20"))[
        "trim"
      ]())),
    _0x188e7a
  );
}
function _0x314b94(_0xdd5a7) {
  var _0x61d51 = _0xdd5a7["split"]("\x0a");
  (_0x61d51["splice"](0x0, 0x1),
    (_0x61d51 = _0x61d51["filter"](function (_0x193936) {
      return _0x193936["trim"]()["length"] > 0x0;
    })));
  for (var _0x1341a5 = 0x0; _0x1341a5 < _0x61d51["length"]; _0x1341a5++)
    !_0x1097e5(_0x61d51[_0x1341a5]) &&
      (_0x61d51["splice"](_0x1341a5, 0x1), _0x1341a5--);
  return "{" + _0x61d51["join"]("")["replace"](/,$/, "") + "}";
}
function _0x1097e5(_0x15d499) {
  if (-0x1 === _0x15d499["indexOf"](":")) return !0x1;
  if (-0x1 === _0x15d499["indexOf"](",")) return !0x1;
  var _0x5ead4f = _0x15d499["split"](":")[0x1]["trim"]();
  return (
    "{" === _0x5ead4f[0x0] ||
    "\x22" === _0x5ead4f[0x0] ||
    "[" === _0x5ead4f[0x0]
  );
}
function _0x285e92() {
  var _0x850de8 = document["querySelector"]("#leftCol")["querySelectorAll"](
      "script[type=\x22text/javascript\x22]",
    ),
    _0x98b7e;
  for (var _0x35530b = 0x0; _0x35530b < _0x850de8["length"]; _0x35530b++) {
    var _0x265d58 = _0x850de8[_0x35530b];
    _0x265d58["innerHTML"]["indexOf"]("var\x20data\x20=") > -0x1 &&
      (_0x98b7e = _0x265d58);
  }
  var _0x2a6980 = _0x98b7e["innerHTML"]["match"](
    /var data = (\{[\s\S]*?\});/,
  )[0x1];
  _0x2a6980 = _0x314b94((_0x2a6980 = _0x2a6980["replace"](/'/g, "\x22")));
  var _0x3ce3ce;
  try {
    _0x3ce3ce = JSON["parse"](_0x2a6980);
  } catch (_0x328bd9) {
    (console["log"]("error\x20parsing\x20json"),
      (_0x3ce3ce = jsonrepair(_0x2a6980)),
      (_0x3ce3ce = JSON["parse"](_0x3ce3ce)),
      console["log"](_0x328bd9));
  }
  return _0x3ce3ce;
}
function _0x128e12() {
  var _0x4f3ecd = _0x285e92();
  if (!_0x4f3ecd["colorImages"]) return [];
  var _0x23fb54 = [];
  for (
    var _0x915842 = 0x0;
    _0x915842 < _0x4f3ecd["colorImages"]["initial"]["length"];
    _0x915842++
  ) {
    var _0x57deb6 = _0x4f3ecd["colorImages"]["initial"][_0x915842];
    _0x57deb6["hiRes"]
      ? _0x23fb54["push"](_0x57deb6["hiRes"])
      : _0x57deb6["large"] && _0x23fb54["push"](_0x57deb6["large"]);
  }
  return _0x23fb54;
}
function _0x40fde3() {
  var _0x44a396 = _0x285e92();
  return _0x44a396["imageGalleryData"]
    ? Object["keys"](_0x44a396["imageGalleryData"])
        ["filter"](function (_0x4f6554) {
          return _0x44a396["imageGalleryData"][_0x4f6554]["mainUrl"];
        })
        ["map"](function (_0x23eae9) {
          return _0x44a396["imageGalleryData"][_0x23eae9]["mainUrl"];
        })
    : [];
}
function _0x3bd59b() {
  var _0x5eecf2 = _0x285e92();
  return _0x5eecf2["colorImages"]
    ? Object["keys"](_0x5eecf2["colorImages"]["initial"])
        ["filter"](function (_0x3170e4) {
          return _0x5eecf2["colorImages"]["initial"][_0x3170e4]["large"];
        })
        ["map"](function (_0x103839) {
          return _0x5eecf2["colorImages"]["initial"][_0x103839]["large"];
        })
    : [];
}
function _0x28e60e(_0x564480 = null) {
  return (
    null === _0x564480 && (_0x564480 = document),
    !!_0x564480["querySelectorAll"]("#imageBlock")["length"]
  );
}
function _0x2f0d80(_0x1a85c3 = null) {
  null === _0x1a85c3 && (_0x1a85c3 = document);
  var _0x4e43d9 = _0x1a85c3["getElementById"]("buybox");
  console["log"]("buyBox", _0x4e43d9);
  if (_0x4e43d9) {
    for (let _0x3efe95 of [
      "free\x20shipping",
      "free\x20delivery",
      "gratis\x20lieferung",
      "livraison\x20gratuite",
      "spedizione\x20gratuita",
      "consegna\x20gratuita",
      "envío\x20gratis",
      "entrega\x20gratis",
      "für\x203,99",
    ])
      if (_0x4e43d9["innerText"]["toLowerCase"]()["includes"](_0x3efe95))
        return !0x0;
  }
  return !0x1;
}
function _0xc77d69(_0x4f5378 = null) {
  null === _0x4f5378 && (_0x4f5378 = document);
  var _0x56e24d = _0x4f5378["querySelector"]("#usedbuyBox,\x20#buyNewSection");
  return _0x56e24d && "usedbuyBox" === _0x56e24d["id"] ? "used" : "unknown";
}
function _0x164716() {
  var _0x37f779 = "No\x20Delivery\x20Message";
  return (
    document["querySelectorAll"]("#delivery-message")["length"] &&
      (_0x37f779 = document["getElementById"]("delivery-message")["innerText"][
        "replace"
      ](/^\s+|\s+$|\s+(?=\s)/g, "")),
    _0x37f779
  );
}
function _0x103b4d(_0x5712c5 = null) {
  null === _0x5712c5 && (_0x5712c5 = document);
  let _0x51aa94 = _0x5712c5["getElementById"]("ASIN");
  if (_0x51aa94) return _0x51aa94["value"];
  const _0x546088 = _0x5712c5["getElementsByTagName"]("meta");
  for (let _0x134f31 = 0x0; _0x134f31 < _0x546088["length"]; _0x134f31++)
    if ("ASIN" === _0x546088[_0x134f31]["getAttribute"]("name"))
      return _0x546088[_0x134f31]["getAttribute"]("content");
  const _0x1e5fb1 =
    _0x5712c5["location"]["href"]["match"](/\/dp\/([A-Z0-9]{10})/);
  return _0x1e5fb1 && _0x1e5fb1[0x1] ? _0x1e5fb1[0x1] : "unknown";
}
async function _0x10d238(_0x46c35d = null) {
  (console["log"]("getAmazonItemData"),
    null === _0x46c35d && (_0x46c35d = document));
  var _0x561b1a = _0x3aa96a(_0x46c35d),
    _0x471cdf = await _0x2667b7(_0x46c35d),
    _0x39a10c = {
      isPageCorrectlyOpened: _0x28e60e(_0x46c35d),
      isItemAvailable: _0x471cdf,
      availabilityMessage: _0x2b0f0c(_0x46c35d),
      isItemDeliveryExtended: await _0x48c7c3(_0x46c35d),
      deliveryTimeMessage: _0x164716(_0x46c35d),
      amazonItemUrl: _0x46c35d["location"]["href"],
      price: _0x561b1a,
      isEligibleForPrime: await _0x44e4e8(_0x46c35d),
      hasFreeShipping: _0x2f0d80(_0x46c35d),
      itemCondition: _0xc77d69(_0x46c35d),
      sku: _0x103b4d(_0x46c35d),
      hasNetworkError: !0x1,
      isIpBlocked: !0x1,
      brand: _0x38cbe5(),
    };
  return (
    /\b503\b/["test"](_0x46c35d["title"]["toLowerCase"]()) &&
      (_0x39a10c["isIpBlocked"] = !0x0),
    "number" == typeof _0x561b1a &&
      _0x561b1a > 0x1 &&
      _0x39a10c["brand"] &&
      (_0x39a10c["isIpBlocked"] = !0x1),
    document["querySelector"]("#priceNotAvailable_feature_div") &&
      (_0x39a10c["isIpBlocked"] = !0x0),
    console["log"]("amazonItemData", _0x39a10c),
    -0x1 === _0x561b1a &&
      ((_0x39a10c["isItemAvailable"] = !0x1),
      (_0x39a10c["availabilityMessage"] = "Price\x20not\x20available")),
    _0x39a10c
  );
}
function _0x55dbe6() {
  var _0x48f7fb = document["querySelector"](
    "#merchantInfoFeature_feature_div\x20.offer-display-feature-text",
  );
  return _0x48f7fb && _0x48f7fb
    ? _0x48f7fb["innerText"]["toLowerCase"]()
    : null;
}
function _0x573b10() {
  var _0x41f2c0 = document["getElementById"]("merchantID");
  return _0x41f2c0 && _0x41f2c0["value"] ? _0x41f2c0["value"] : null;
}
async function _0x59e8cd() {
  console["log"]("checkIfChineseSeller\x20started\x20");
  var _0x11fd69 = _0x55dbe6();
  if (_0x11fd69?.["toLowerCase"]()["includes"]("amazon")) return !0x1;
  var _0x114195 = _0x573b10();
  if (!_0x114195) return !0x1;
  if ("A3JWKAKR8XB7XF" === _0x114195) return !0x1;
  console["log"](
    "asking\x20background\x20script\x20if\x20seller\x20is\x20chinese",
  );
  var { response: _0x1226cc } = await chrome["runtime"]["sendMessage"]({
    type: "is_amazon_seller_chinese",
    merchantId: _0x114195,
  });
  return _0x1226cc;
}
async function _0x480b8f(_0x1051b6, _0x2ef094 = 0x4e20) {
  const _0x4a8095 = Date["now"]();
  return new Promise((_0xc7eeb5, _0x264dbe) => {
    !(function _0x3a18b1() {
      const _0x147868 = document["querySelector"](_0x1051b6);
      _0x147868
        ? _0xc7eeb5(_0x147868)
        : Date["now"]() - _0x4a8095 > _0x2ef094
          ? _0x264dbe(
              new Error(
                "Timeout:\x20Element\x20" +
                  _0x1051b6 +
                  "\x20not\x20found\x20within\x20" +
                  _0x2ef094 +
                  "ms",
              ),
            )
          : setTimeout(_0x3a18b1, 0x64);
    })();
  });
}
async function fetchGSPR(_0x2bfb56 = 0x0) {
  var _0xa7c0fd = document["querySelector"]("#buffet-sidesheet-ingress");
  if (_0xa7c0fd) {
    var _0x55aec4 = await chrome["runtime"]["sendMessage"]({
      type: "makeTabActive",
    });
    (console["log"]("response", _0x55aec4),
      await new Promise((_0x23b99b) => setTimeout(_0x23b99b, 0x3e8)),
      _0xa7c0fd["click"](),
      (document["title"] =
        "2\x20open\x20security\x20contacts\x20button\x20clicked,\x20waiting\x20for\x20manufacturer\x20content\x20container\x20to\x20appear"));
    var _0x402702;
    try {
      _0x402702 = await _0x480b8f(
        "#buffet-sidesheet-manufacturer-content-container\x20._YnVmZ_box-cont_1XNpR",
        0xbb8,
      );
    } catch (_0x148414) {
      document["title"] =
        "3\x20manufacturer\x20content\x20container\x20not\x20found";
    }
    document["title"] =
      "4\x20manufacturer\x20content\x20container\x20appeared,\x20waiting\x20for\x20manufacturer\x20info\x20text";
    if (!_0x402702) {
      for (let _0x2f15a4 = 0x0; _0x2f15a4 < 0x5; _0x2f15a4++)
        try {
          ((document["title"] =
            "Attempt\x20" +
            (_0x2f15a4 + 0x5) +
            "\x20to\x20open\x20security\x20contacts"),
            (_0x55aec4 = await chrome["runtime"]["sendMessage"]({
              type: "makeTabActive",
            })),
            console["log"]("response", _0x55aec4),
            _0xa7c0fd["click"](),
            await new Promise((_0x5f0afd) => setTimeout(_0x5f0afd, 0x3e8)));
          if (
            (_0x402702 = await _0x480b8f(
              "#buffet-sidesheet-manufacturer-content-container\x20._YnVmZ_box-cont_1XNpR",
              0xbb8,
            ))
          )
            break;
        } catch (_0x2ef46d) {
          console["log"]("Attempt", _0x2f15a4 + 0x1, "failed");
        }
    }
    document["title"] =
      "manufacturer\x20content\x20container\x20appeared,\x20waiting\x20for\x20manufacturer\x20info\x20text";
    var _0x370f7c = _0x2cd2ab(),
      _0x140538 = _0x48dd84();
    (console["log"]("Manufacturer\x20Info\x20Text:", _0x370f7c),
      console["log"]("Responsible\x20Person\x20EU\x20Text:", _0x140538));
    var _0xa7d41e = parseFirstAddress(_0x370f7c),
      _0x10b5e5 = parseFirstAddress(_0x140538);
    return (
      (document["title"] =
        "parsed\x20manufacturer\x20info\x20and\x20responsible\x20person\x20eu"),
      console["log"]("Parsed\x20Manufacturer\x20Info:", _0xa7d41e),
      console["log"]("Parsed\x20Responsible\x20Person\x20EU:", _0x10b5e5),
      {
        manufacturerInfo: _0xa7d41e,
        responsiblePersonEU: _0x10b5e5,
        manufacturerInfoText: _0x370f7c,
        responsiblePersonEUText: _0x140538,
      }
    );
  }
  (console["error"]("Open\x20security\x20contacts\x20button\x20not\x20found."),
    (document["title"] =
      "1\x20open\x20security\x20contacts\x20button\x20not\x20found"));
}
function _0x467363(_0x1c675a) {
  var _0xa2b7f3 = document["querySelector"](_0x1c675a);
  if (!_0xa2b7f3) return "";
  var _0xeb654e = _0xa2b7f3["querySelector"](".a-size-base.a-text-bold"),
    _0x20d694 = _0xeb654e ? _0xeb654e["innerText"]["trim"]() : "",
    _0x20b4ea = _0xa2b7f3["querySelectorAll"]("ul"),
    _0x3e84ca = [_0x20d694];
  return (
    _0x20b4ea["forEach"]((_0xd7e524) => {
      var _0x38f532 = Array["from"](_0xd7e524["querySelectorAll"]("li"))
        ["map"]((_0x20c373) => _0x20c373["innerText"]["trim"]())
        ["filter"](Boolean);
      _0x38f532["length"] > 0x0 && _0x3e84ca["push"](..._0x38f532, "");
    }),
    _0x3e84ca["join"]("\x0a")
  );
}
function _0x2cd2ab() {
  return _0x467363(
    "#buffet-sidesheet-manufacturer-content-container\x20._YnVmZ_box-cont_1XNpR",
  );
}
function _0x48dd84() {
  return _0x467363(
    "#buffet-sidesheet-rsp-content-container\x20._YnVmZ_box-cont_1XNpR",
  );
}
async function _0x19174e() {
  const { domain: _0x28c356 } =
    await chrome["storage"]["local"]["get"]("domain");
  if ("de" !== _0x28c356) return { matched: !0x1, phrase: null };
  const { blacklist: _0x174bd5 } =
      await chrome["storage"]["local"]["get"]("blacklist"),
    _0x670b8d = Array["isArray"](_0x174bd5) ? _0x174bd5 : [];
  if (0x0 === _0x670b8d["length"]) return { matched: !0x1, phrase: null };
  function _0x360d89(_0x526538) {
    const _0x5445fe = (function (_0x4138af) {
      return _0x4138af
        ? String(_0x4138af)
            ["replace"](/<[^>]*>/g, "\x20")
            ["replace"](/&[a-z0-9#]+;/gi, "\x20")
            ["replace"](/\s+/g, "\x20")
            ["trim"]()
            ["toLowerCase"]()
        : "";
    })(_0x526538)["normalize"]("NFKC");
    return _0x5445fe["match"](/[\p{L}\p{N}]+/gu) || [];
  }
  const _0x29671a = [
    ..._0x360d89(_0x562b2b() || ""),
    ..._0x360d89(_0x414003() || ""),
    ..._0x360d89((_0x17142c()?.["list"] || [])["join"]("\x20")),
    ..._0x360d89(Object["values"](_0x38e570() || {})["join"]("\x20")),
  ];
  if (0x0 === _0x29671a["length"]) return { matched: !0x1, phrase: null };
  const _0x6ad6b6 = "\x20" + _0x29671a["join"]("\x20") + "\x20";
  for (const _0x7cdb8d of _0x670b8d) {
    const _0x5d6995 = _0x360d89(_0x7cdb8d || "");
    if (0x0 === _0x5d6995["length"]) continue;
    const _0x5c1dfc = "\x20" + _0x5d6995["join"]("\x20") + "\x20";
    if (_0x6ad6b6["includes"](_0x5c1dfc)) {
      (console["log"]("🚫\x20Blacklisted\x20phrase\x20found:", _0x7cdb8d),
        (document["title"] = _0x7cdb8d));
      const _0x4ba208 = _0x29671a["findIndex"](
        (_0x8ee4fd, _0xefc6c0) =>
          _0x29671a["slice"](_0xefc6c0, _0xefc6c0 + _0x5d6995["length"])[
            "join"
          ]("\x20") === _0x5d6995["join"]("\x20"),
      );
      if (-0x1 !== _0x4ba208) {
        const _0x3e432b = Math["max"](0x0, _0x4ba208 - 0x5),
          _0x16e138 = Math["min"](
            _0x29671a["length"],
            _0x4ba208 + _0x5d6995["length"] + 0x5,
          ),
          _0x4ebc92 = _0x29671a["slice"](_0x3e432b, _0x16e138)["join"]("\x20");
        console["log"]("🧩\x20Context:", "...\x20" + _0x4ebc92 + "\x20...");
      }
      return { matched: !0x0, phrase: _0x7cdb8d };
    }
  }
  return { matched: !0x1, phrase: null };
}
console["log"]("loaded\x20content/amazon/DP_Page/content.js");
var _0x474743;
chrome["runtime"]["onMessage"]["addListener"](
  (_0x4997e7, _0x198124, _0x5244db) => {
    _0x474743 = _0x4997e7;
    if ("get_amazon_data" === _0x4997e7["type"]) {
      (console["log"]("get_amazon_data"),
        _0x5244db({ message_received: !0x0 }));
      if (_0xae6a87())
        (chrome["runtime"]["sendMessage"]({
          type: "resend_message_to_tab_on_update",
          message: _0x474743,
        }),
          _0x1c2c79());
      else
        _0x10d238()["then"](function (_0x337ce1) {
          chrome["runtime"]["sendMessage"]({
            type: "amazon_data",
            amazonData: _0x337ce1,
          });
        });
    }
  },
);
