function _0x12a796(
  _0x5ead0e,
  _0x53aeab = 0x3e8,
  {
    titlePrefix: titlePrefix = "Auto\x20Order",
    position: position = "top-left",
    scale: scale = 1.25,
    autoShowHud: autoShowHud = !0x0,
    fadeOutMs: fadeOutMs = 0x5dc,
  } = {},
) {
  let _0x288cc2 = Promise["resolve"](),
    _0x270ad4 = null,
    _0x4b0a82 = 0x0,
    _0x59954a = null;
  function _0x2d6829(_0x444443, _0x2b19c4 = "#fff") {
    (function () {
      return (
        !_0x59954a &&
          (document["querySelectorAll"]("link[rel*=\x27icon\x27]")["forEach"](
            (_0x3904f8) => _0x3904f8["remove"](),
          ),
          (_0x59954a = document["createElement"]("link")),
          (_0x59954a["rel"] = "icon"),
          document["head"]["appendChild"](_0x59954a)),
        _0x59954a
      );
    })()["href"] = (function (_0x4206c7, _0x3315fb = "#fff") {
      const _0x4d20f0 = document["createElement"]("canvas");
      ((_0x4d20f0["width"] = 0x40), (_0x4d20f0["height"] = 0x40));
      const _0x586b46 = _0x4d20f0["getContext"]("2d");
      return (
        (_0x586b46["fillStyle"] = _0x3315fb),
        _0x586b46["fillRect"](0x0, 0x0, 0x40, 0x40),
        (_0x586b46["font"] = "48px\x20serif"),
        (_0x586b46["textAlign"] = "center"),
        (_0x586b46["textBaseline"] = "middle"),
        _0x586b46["fillText"](_0x4206c7, 0x20, 0x28),
        _0x4d20f0["toDataURL"]("image/png")
      );
    })(_0x444443, _0x2b19c4);
  }
  const _0x35d6f5 = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
  let _0x40b2c5 = null,
    _0x263b02 = 0x0,
    _0x77834c = "";
  function _0x33243e(_0x369f02) {
    ((_0x77834c = _0x369f02), stopTitleSpin());
    const _0x420383 = titlePrefix + ":\x20" + _0x369f02,
      _0x462176 = () => {
        document["title"] =
          _0x35d6f5[_0x263b02++ % _0x35d6f5["length"]] + "\x20" + _0x420383;
      };
    _0x462176();
    const _0x39fc8d = () => (document["hidden"] ? 0x190 : 0x78);
    ((_0x40b2c5 = setInterval(_0x462176, _0x39fc8d())),
      document["addEventListener"](
        "visibilitychange",
        () => {
          _0x40b2c5 &&
            (clearInterval(_0x40b2c5),
            (_0x40b2c5 = setInterval(_0x462176, _0x39fc8d())));
        },
        { once: !0x0 },
      ));
  }
  function stopTitleSpin(_0x3e0ade = "") {
    (_0x40b2c5 && (clearInterval(_0x40b2c5), (_0x40b2c5 = null)),
      _0x3e0ade
        ? (document["title"] = titlePrefix + ":\x20" + _0x3e0ade)
        : _0x77834c && (document["title"] = titlePrefix + ":\x20" + _0x77834c));
  }
  let _0x3fedbd = null,
    _0x1b36da = !0x1;
  function _0x30c3a2() {
    if (_0x3fedbd) return _0x3fedbd;
    return (
      !(function () {
        if (_0x1b36da) return;
        _0x1b36da = !0x0;
        const _0x248a5c = document["createElement"]("style");
        ((_0x248a5c["textContent"] =
          "\x0a\x20\x20\x20\x20\x20\x20.ao-hud{position:fixed;z-index:2147483647;display:inline-flex;align-items:flex-start;gap:12px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20background:rgba(18,20,23,.96);color:#e7f3ff;border:1px\x20solid\x20rgba(255,255,255,.1);\x0a\x20\x20\x20\x20\x20\x20\x20\x20padding:12px\x2014px;border-radius:14px;box-shadow:0\x2010px\x2030px\x20rgba(0,0,0,.35);\x0a\x20\x20\x20\x20\x20\x20\x20\x20font:600\x2014px/1.35\x20system-ui,-apple-system,Segoe\x20UI,Roboto,sans-serif;pointer-events:none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20opacity:0;transform:translateY(-6px);transition:opacity\x20.18s,transform\x20.18s}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.show{opacity:1;transform:translateY(0)}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.tl{top:16px;left:16px;transform-origin:\x20top\x20left}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.tr{top:16px;right:16px;transform-origin:\x20top\x20right}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.bl{bottom:16px;left:16px;transform-origin:\x20bottom\x20left}\x0a\x20\x20\x20\x20\x20\x20.ao-hud.br{bottom:16px;right:16px;transform-origin:\x20bottom\x20right}\x0a\x0a\x20\x20\x20\x20\x20\x20.ao-spin{width:22px;height:22px;border-radius:50%;border:3px\x20solid\x20currentColor;border-right-color:transparent;animation:ao-rot\x20.7s\x20linear\x20infinite}\x0a\x20\x20\x20\x20\x20\x20@keyframes\x20ao-rot{to{transform:rotate(360deg)}}\x0a\x20\x20\x20\x20\x20\x20.ao-icon{font-size:20px;display:none}\x0a\x0a\x20\x20\x20\x20\x20\x20/*\x20Allow\x20wrapping\x20instead\x20of\x20single-line\x20ellipsis\x20*/\x0a\x20\x20\x20\x20\x20\x20.ao-text{\x0a\x20\x20\x20\x20\x20\x20\x20\x20white-space:\x20normal;\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20was:\x20nowrap\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20word-break:\x20break-word;\x0a\x20\x20\x20\x20\x20\x20\x20\x20overflow:\x20visible;\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20was:\x20hidden\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20text-overflow:\x20initial;\x20\x20\x20\x20\x20\x20/*\x20was:\x20ellipsis\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20max-width:\x20min(60vw,\x20720px);\x20/*\x20keep\x20it\x20readable\x20on\x20wide\x20screens\x20*/\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20.ao-hud.done{color:#19c37d}.ao-hud.error{color:#ff6b6b}\x0a\x20\x20\x20\x20"),
          document["head"]["appendChild"](_0x248a5c));
      })(),
      (_0x3fedbd = document["createElement"]("div")),
      (_0x3fedbd["className"] =
        "ao-hud\x20" +
        ("top-right" === position
          ? "tr"
          : "bottom-left" === position
            ? "bl"
            : "bottom-right" === position
              ? "br"
              : "tl")),
      (_0x3fedbd["style"]["scale"] = String(scale)),
      (_0x3fedbd["innerHTML"] =
        "\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-spin\x22\x20aria-hidden=\x22true\x22></div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-icon\x22\x20aria-hidden=\x22true\x22>✅</div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22ao-text\x22\x20aria-live=\x22polite\x22\x20aria-atomic=\x22true\x22></div>\x0a\x20\x20\x20\x20"),
      document["body"]["appendChild"](_0x3fedbd),
      _0x3fedbd
    );
  }
  function _0x13c04b() {
    return _0x288cc2;
  }
  return (
    _0x2d6829("🟡", "#fff"),
    {
      update: function (
        _0xa8d297,
        {
          delayMs: delayMs = _0x53aeab,
          coalesce: coalesce = !0x0,
          showHud: showHud = autoShowHud,
        } = {},
      ) {
        if (coalesce && _0xa8d297 === _0x270ad4) return _0x288cc2;
        _0x270ad4 = _0xa8d297;
        const _0x5a1b05 = _0x4b0a82;
        return (
          _0x2d6829("🟡", "#fff"),
          showHud
            ? (function (_0x298d90) {
                if (!autoShowHud) {
                  _0x33243e(_0x298d90);
                  return;
                }
                const _0x1733be = _0x30c3a2();
                (_0x1733be["classList"]["remove"]("done", "error"),
                  _0x1733be["classList"]["add"]("show"),
                  (_0x1733be["querySelector"](".ao-spin")["style"]["display"] =
                    ""),
                  (_0x1733be["querySelector"](".ao-icon")["style"]["display"] =
                    "none"),
                  (_0x1733be["querySelector"](".ao-text")["textContent"] =
                    _0x298d90),
                  _0x33243e(_0x298d90));
              })(_0xa8d297)
            : _0x33243e(_0xa8d297),
          (_0x288cc2 = _0x288cc2["then"](async () => {
            if (_0x5a1b05 !== _0x4b0a82) return;
            const _0x5e0d6f = document["getElementById"](_0x5ead0e);
            (_0x5e0d6f && (_0x5e0d6f["innerText"] = _0xa8d297),
              await ((_0x4080c2 = delayMs),
              new Promise((_0x4293ce) => setTimeout(_0x4293ce, _0x4080c2))));
            var _0x4080c2;
          })["catch"](() => {})),
          _0x288cc2
        );
      },
      cancel: function () {
        _0x4b0a82++;
      },
      whenIdle: _0x13c04b,
      finish: async function (_0xa44e3a = "Complete") {
        (await _0x13c04b(),
          _0x2d6829("✅", "#fff"),
          !(function (_0x5647fc) {
            (autoShowHud &&
              (_0x30c3a2(),
              _0x3fedbd["classList"]["remove"]("error"),
              _0x3fedbd["classList"]["add"]("done", "show"),
              (_0x3fedbd["querySelector"](".ao-spin")["style"]["display"] =
                "none"),
              (_0x3fedbd["querySelector"](".ao-icon")["style"]["display"] = ""),
              (_0x3fedbd["querySelector"](".ao-icon")["textContent"] = "✅"),
              (_0x3fedbd["querySelector"](".ao-text")["textContent"] =
                _0x5647fc),
              fadeOutMs > 0x0 &&
                setTimeout(
                  () => _0x3fedbd["classList"]["remove"]("show"),
                  fadeOutMs,
                )),
              stopTitleSpin(_0x5647fc));
          })(_0xa44e3a));
      },
      error: function (_0x584ecf = "Failed") {
        (_0x2d6829("❌", "#fff"),
          !(function (_0x2d31a6) {
            (autoShowHud &&
              (_0x30c3a2(),
              _0x3fedbd["classList"]["remove"]("done"),
              _0x3fedbd["classList"]["add"]("error", "show"),
              (_0x3fedbd["querySelector"](".ao-spin")["style"]["display"] =
                "none"),
              (_0x3fedbd["querySelector"](".ao-icon")["style"]["display"] = ""),
              (_0x3fedbd["querySelector"](".ao-icon")["textContent"] = "❌"),
              (_0x3fedbd["querySelector"](".ao-text")["textContent"] =
                _0x2d31a6)),
              stopTitleSpin(_0x2d31a6));
          })(_0x584ecf));
      },
    }
  );
}
(!(function () {
  var _0x57a4db = "iframe_utils";
  function _0x4f747f(_0x7dcd94, _0x5d0c9a, _0x15f508, _0x370eb8) {
    (_0x370eb8 || (_0x370eb8 = "*"),
      _0x7dcd94["postMessage"](
        { namespace: _0x57a4db, type: _0x5d0c9a, payload: _0x15f508 || {} },
        _0x370eb8,
      ));
  }
  function _0x1ed346(_0x32fac3, _0x405bcf) {
    window["addEventListener"]("message", function (_0x5b841c) {
      var _0x149b19 = _0x5b841c && _0x5b841c["data"];
      _0x149b19 &&
        _0x149b19["namespace"] === _0x57a4db &&
        (("*" !== _0x32fac3 && _0x149b19["type"] !== _0x32fac3) ||
          _0x405bcf(_0x149b19["payload"], _0x5b841c));
    });
  }
  function _0x425646(_0x4578f1, _0x5b20aa, _0x5d700f) {
    return (
      "number" != typeof _0x5d700f && (_0x5d700f = 0x2710),
      new Promise(function (_0x154e45, _0x1e451f) {
        function _0xc09d71(_0x3f618d) {
          var _0x3c7f24 = _0x3f618d && _0x3f618d["data"];
          _0x3c7f24 &&
            _0x3f618d["source"] === _0x4578f1 &&
            _0x3c7f24["namespace"] === _0x57a4db &&
            _0x3c7f24["type"] === _0x5b20aa &&
            (window["removeEventListener"]("message", _0xc09d71),
            _0x154e45(_0x3c7f24["payload"]));
        }
        (window["addEventListener"]("message", _0xc09d71),
          _0x5d700f &&
            setTimeout(function () {
              (window["removeEventListener"]("message", _0xc09d71),
                _0x1e451f(
                  new Error(
                    "Timed\x20out\x20waiting\x20for\x20message\x20from\x20source:\x20" +
                      _0x5b20aa,
                  ),
                ));
            }, _0x5d700f));
      })
    );
  }
  var parent = {
      waitForIframe: function (_0x5446cb, _0x259a08) {
        return (
          "number" != typeof _0x259a08 && (_0x259a08 = 0x2710),
          new Promise(function (_0x166e0c, _0x11f081) {
            var _0x338914 =
              "string" == typeof _0x5446cb
                ? document["querySelector"](_0x5446cb)
                : _0x5446cb;
            function _0x37e128(_0x6d3d27) {
              if (
                _0x6d3d27 &&
                "IFRAME" === _0x6d3d27["tagName"] &&
                _0x6d3d27["contentWindow"]
              ) {
                if (
                  _0x6d3d27["contentDocument"] &&
                  "complete" === _0x6d3d27["contentDocument"]["readyState"]
                )
                  return (_0x166e0c(_0x6d3d27), !0x0);
                return (
                  _0x6d3d27["addEventListener"](
                    "load",
                    function () {
                      _0x166e0c(_0x6d3d27);
                    },
                    { once: !0x0 },
                  ),
                  !0x0
                );
              }
              return !0x1;
            }
            if (!_0x37e128(_0x338914)) {
              var _0x30dee9 = new MutationObserver(function () {
                _0x37e128(
                  (_0x338914 =
                    "string" == typeof _0x5446cb
                      ? document["querySelector"](_0x5446cb)
                      : _0x5446cb),
                ) && _0x30dee9["disconnect"]();
              });
              (_0x30dee9["observe"](document["body"], {
                childList: !0x0,
                subtree: !0x0,
              }),
                setTimeout(function () {
                  try {
                    _0x30dee9["disconnect"]();
                  } catch (_0xb8a45d) {}
                  _0x11f081(new Error("Timeout\x20waiting\x20for\x20iframe"));
                }, _0x259a08));
            }
          })
        );
      },
      waitForIframeReady: function (_0x396985, _0x14d86a) {
        return (
          "number" != typeof _0x14d86a && (_0x14d86a = 0x3a98),
          new Promise(function (_0x274729, _0x3a70db) {
            parent["waitForIframe"](_0x396985, _0x14d86a)
              ["then"](function (_0x3f586a) {
                var _0xbb888 = _0x3f586a && _0x3f586a["contentWindow"];
                _0xbb888
                  ? (function (_0x406640, _0x84c13) {
                      "number" != typeof _0x84c13 && (_0x84c13 = 0x3a98);
                      var _0x379a51 = Math["max"](
                        0xbb8,
                        Math["floor"](_0x84c13 / 0x2),
                      );
                      return new Promise(function (_0x575cb8, _0x3fbc1a) {
                        _0x425646(_0x406640, "iframe_ready", _0x379a51)
                          ["then"](function () {
                            _0x575cb8(!0x0);
                          })
                          ["catch"](function () {
                            try {
                              _0x4f747f(
                                _0x406640,
                                "ping_iframe_ready",
                                { ts: Date["now"]() },
                                "*",
                              );
                            } catch (_0x24e874) {}
                            _0x425646(_0x406640, "iframe_ready", _0x379a51)
                              ["then"](function () {
                                _0x575cb8(!0x0);
                              })
                              ["catch"](function () {
                                _0x3fbc1a(
                                  new Error(
                                    "Timed\x20out\x20waiting\x20for\x20targeted\x20iframe_ready",
                                  ),
                                );
                              });
                          });
                      });
                    })(_0xbb888, _0x14d86a)
                      ["then"](function () {
                        _0x274729(_0x3f586a);
                      })
                      ["catch"](function (_0x5423fe) {
                        _0x3a70db(_0x5423fe);
                      })
                  : _0x3a70db(
                      new Error("Iframe\x20has\x20no\x20contentWindow"),
                    );
              })
              ["catch"](function (_0x4c34a5) {
                _0x3a70db(_0x4c34a5);
              });
          })
        );
      },
      sendMessage: function (_0x4e91b4, _0x4bc01c, _0x1a084b) {
        if (!_0x4e91b4 || !_0x4e91b4["contentWindow"])
          throw new Error("iframe\x20element\x20not\x20ready");
        _0x4f747f(_0x4e91b4["contentWindow"], _0x4bc01c, _0x1a084b || {}, "*");
      },
      askIframe: function (_0x4d29ce, _0x46f553, _0x44ec15, _0x1b0aa2) {
        return (
          _0x44ec15 || (_0x44ec15 = {}),
          "number" != typeof _0x1b0aa2 && (_0x1b0aa2 = 0x2710),
          parent["sendMessage"](_0x4d29ce, _0x46f553, _0x44ec15),
          _0x425646(_0x4d29ce["contentWindow"], _0x46f553 + ":reply", _0x1b0aa2)
        );
      },
    },
    _0x44d4f9 = {
      sendMessage: function (_0x38686c, _0x42c863) {
        _0x4f747f(window["parent"], _0x38686c, _0x42c863 || {}, "*");
      },
      askParent: function (_0x216fc6, _0x228eec, _0x2a4e9b) {
        return (
          _0x228eec || (_0x228eec = {}),
          "number" != typeof _0x2a4e9b && (_0x2a4e9b = 0x2710),
          _0x44d4f9["sendMessage"](_0x216fc6, _0x228eec),
          _0x425646(window["parent"], _0x216fc6 + ":reply", _0x2a4e9b)
        );
      },
      announceReady: function () {
        _0x44d4f9["sendMessage"]("iframe_ready", { ready: !0x0 });
      },
    };
  (_0x1ed346("ping_iframe_ready", function (_0x347ea7, _0x4d75ef) {
    try {
      _0x4d75ef["source"]["postMessage"](
        {
          namespace: _0x57a4db,
          type: "iframe_ready",
          payload: { ready: !0x0 },
        },
        "*",
      );
    } catch (_0x402fd3) {}
  }),
    (window["iframeUtils"] = {
      core: {
        onMessage: _0x1ed346,
        waitForMessage: function (_0x22b91b, _0x12462c) {
          return (
            "number" != typeof _0x12462c && (_0x12462c = 0x2710),
            new Promise(function (_0x3de161, _0x3d0af7) {
              function _0x27a32f(_0x56ecc3) {
                var _0x86f13 = _0x56ecc3 && _0x56ecc3["data"];
                _0x86f13 &&
                  _0x86f13["namespace"] === _0x57a4db &&
                  _0x86f13["type"] === _0x22b91b &&
                  (window["removeEventListener"]("message", _0x27a32f),
                  _0x3de161(_0x86f13["payload"]));
              }
              (window["addEventListener"]("message", _0x27a32f),
                _0x12462c &&
                  setTimeout(function () {
                    (window["removeEventListener"]("message", _0x27a32f),
                      _0x3d0af7(
                        new Error(
                          "Timed\x20out\x20waiting\x20for\x20message:\x20" +
                            _0x22b91b,
                        ),
                      ));
                  }, _0x12462c));
            })
          );
        },
        waitForMessageFrom: _0x425646,
      },
      parent: parent,
      child: _0x44d4f9,
      responders: {
        handleRequest: function (_0x2454a1, _0x47b42a) {
          _0x1ed346(_0x2454a1, function (_0x5ed4b7, _0xa3ec1f) {
            Promise["resolve"]()
              ["then"](function () {
                return _0x47b42a(_0x5ed4b7, _0xa3ec1f);
              })
              ["then"](function (_0x37bb2b) {
                _0xa3ec1f["source"]["postMessage"](
                  {
                    namespace: _0x57a4db,
                    type: _0x2454a1 + ":reply",
                    payload: _0x37bb2b,
                  },
                  "*",
                );
              })
              ["catch"](function (_0x648a3c) {
                _0xa3ec1f["source"]["postMessage"](
                  {
                    namespace: _0x57a4db,
                    type: _0x2454a1 + ":reply",
                    payload: {
                      error:
                        _0x648a3c && _0x648a3c["message"]
                          ? _0x648a3c["message"]
                          : String(_0x648a3c),
                    },
                  },
                  "*",
                );
              });
          });
        },
      },
    }));
  if (window["self"] !== window["top"])
    try {
      _0x44d4f9["announceReady"]();
    } catch (_0x342f2a) {}
})(),
  !(function () {
    var _0x2a6324 = "gpt-5-nano",
      _0x44a54f =
        "https://us-central1-ecomsniper-cb046.cloudfunctions.net/structured_output",
      _0x3a28e9 = null;
    function _0x50bb1f(_0x1e1360) {
      return new Promise(async function (_0x858d4e) {
        try {
          if (!_0x1e1360 || !_0x1e1360["system"] || !_0x1e1360["user"]) {
            _0x858d4e({
              ok: !0x1,
              error: "system\x20and\x20user\x20are\x20required",
            });
            return;
          }
          !(function (_0x37cf61) {
            if (!_0x37cf61 || "object" != typeof _0x37cf61)
              throw new Error("fields\x20must\x20be\x20an\x20object");
            var _0x203f3e = {
                string: !0x0,
                number: !0x0,
                integer: !0x0,
                boolean: !0x0,
              },
              _0x388dc5;
            for (_0x388dc5 in _0x37cf61)
              if (
                Object["prototype"]["hasOwnProperty"]["call"](
                  _0x37cf61,
                  _0x388dc5,
                )
              ) {
                var _0x2539d5 = _0x37cf61[_0x388dc5];
                if ("string" != typeof _0x2539d5)
                  throw new Error(
                    "Type\x20for\x20\x27" +
                      _0x388dc5 +
                      "\x27\x20must\x20be\x20a\x20string",
                  );
                if (
                  0x0 === _0x2539d5["indexOf"]("array[") &&
                  "]" === _0x2539d5["slice"](-0x1)
                ) {
                  var _0x21b663 = _0x2539d5["slice"](0x6, -0x1)["trim"]();
                  if (!_0x203f3e[_0x21b663])
                    throw new Error(
                      "Unsupported\x20array\x20type\x20for\x20\x27" +
                        _0x388dc5 +
                        "\x27:\x20" +
                        _0x21b663,
                    );
                } else {
                  if (!_0x203f3e[_0x2539d5])
                    throw new Error(
                      "Unsupported\x20type\x20for\x20\x27" +
                        _0x388dc5 +
                        "\x27:\x20" +
                        _0x2539d5,
                    );
                }
              }
          })(_0x1e1360["fields"]);
          var _0x18d0df = (function (_0x43e6a2) {
              var mapped = {},
                _0x276cec;
              for (_0x276cec in _0x43e6a2)
                if (
                  Object["prototype"]["hasOwnProperty"]["call"](
                    _0x43e6a2,
                    _0x276cec,
                  )
                ) {
                  var _0x42ad58 = _0x43e6a2[_0x276cec];
                  if (
                    0x0 !== _0x42ad58["indexOf"]("array[") ||
                    "]" !== _0x42ad58["slice"](-0x1)
                  ) {
                    var _0x189094 =
                      "string" === _0x42ad58
                        ? "str"
                        : "number" === _0x42ad58
                          ? "float"
                          : "integer" === _0x42ad58
                            ? "int"
                            : "boolean" === _0x42ad58
                              ? "bool"
                              : null;
                    if (!_0x189094)
                      throw new Error(
                        "Unsupported\x20type\x20for\x20\x27" +
                          _0x276cec +
                          "\x27:\x20" +
                          _0x42ad58,
                      );
                    mapped[_0x276cec] = _0x189094;
                  } else {
                    var _0x50fcb0 = _0x42ad58["slice"](0x6, -0x1)["trim"](),
                      _0x201f46 =
                        "string" === _0x50fcb0
                          ? "str"
                          : "number" === _0x50fcb0
                            ? "float"
                            : "integer" === _0x50fcb0
                              ? "int"
                              : "boolean" === _0x50fcb0
                                ? "bool"
                                : null;
                    if (!_0x201f46)
                      throw new Error(
                        "Unsupported\x20inner\x20array\x20type\x20for\x20\x27" +
                          _0x276cec +
                          "\x27:\x20" +
                          _0x50fcb0,
                      );
                    mapped[_0x276cec] = "list[" + _0x201f46 + "]";
                  }
                }
              return mapped;
            })(_0x1e1360["fields"]),
            _0x4ab065 = {
              system_message: _0x1e1360["system"],
              user_message: _0x1e1360["user"],
              model_definition: _0x18d0df,
              openai_model: _0x1e1360["model"] || _0x2a6324,
            },
            _0x221c2e = _0x1e1360["openaiKey"] || _0x3a28e9;
          if (_0x221c2e) _0x4ab065["openai_key"] = _0x221c2e;
          else {
            var _0xe45917 = await new Promise(function (_0x880e41, _0x1b957f) {
              chrome["storage"]["local"]["get"](
                ["email"],
                function (_0xb4c987) {
                  if (chrome["runtime"]["lastError"])
                    _0x1b957f(
                      new Error(
                        "Could\x20not\x20read\x20email\x20from\x20storage",
                      ),
                    );
                  else {
                    var _0x5baa9e =
                      _0xb4c987 && _0xb4c987["email"]
                        ? _0xb4c987["email"]
                        : null;
                    _0x880e41(_0x5baa9e);
                  }
                },
              );
            });
            if (!_0xe45917) {
              _0x858d4e({
                ok: !0x1,
                error: "missing\x20email\x20in\x20storage",
              });
              return;
            }
            _0x4ab065["email"] = _0xe45917;
          }
          var _0x5884dd = await ((_0x4bc8d2 = _0x44a54f),
          (_0x3fd77d = _0x4ab065),
          new Promise(function (_0x1f7d06, _0x129643) {
            chrome["runtime"]["sendMessage"](
              { type: "fetchData", url: _0x4bc8d2, data: _0x3fd77d },
              function (_0x4e2d8b) {
                _0x4e2d8b
                  ? _0x4e2d8b["error"]
                    ? _0x129643(new Error(_0x4e2d8b["error"]))
                    : _0x1f7d06(_0x4e2d8b["data"])
                  : _0x129643(new Error("No\x20background\x20response"));
              },
            );
          }));
          if (_0x5884dd && _0x5884dd["success"]) {
            _0x858d4e({ ok: !0x0, data: _0x5884dd["result"] });
            return;
          }
          _0x858d4e({
            ok: !0x1,
            error:
              _0x5884dd && _0x5884dd["errorMessage"]
                ? _0x5884dd["errorMessage"]
                : "structured\x20output\x20failed",
          });
        } catch (_0x1de414) {
          _0x858d4e({
            ok: !0x1,
            error:
              _0x1de414 && _0x1de414["message"]
                ? _0x1de414["message"]
                : String(_0x1de414),
          });
        }
        var _0x4bc8d2, _0x3fd77d;
      });
    }
    window["openaiLibrary"] = {
      setDefaultModel: function (_0x565537) {
        return ((_0x2a6324 = _0x565537), window["openaiLibrary"]);
      },
      setStructuredEndpoint: function (_0x209c35) {
        return ((_0x44a54f = _0x209c35), window["openaiLibrary"]);
      },
      useOpenAIKey: function (_0x10592a) {
        return ((_0x3a28e9 = _0x10592a || null), window["openaiLibrary"]);
      },
      requestStructuredJson: _0x50bb1f,
      requestStructuredField: function (_0x55587d) {
        return new Promise(async function (_0x755579) {
          try {
            if (!_0x55587d) {
              _0x755579({ ok: !0x1, error: "options\x20are\x20required" });
              return;
            }
            var _0xc45ad5 =
                "string" == typeof _0x55587d["name"]
                  ? _0x55587d["name"]["trim"]()
                  : "",
              _0x40a390 =
                "string" == typeof _0x55587d["type"]
                  ? _0x55587d["type"]["trim"]()
                  : "";
            if (!_0xc45ad5 || !_0x40a390) {
              _0x755579({
                ok: !0x1,
                error: "name\x20and\x20type\x20are\x20required",
              });
              return;
            }
            var _0x238905 = {};
            _0x238905[_0xc45ad5] = _0x40a390;
            var _0x265d11 = await _0x50bb1f({
              system: _0x55587d["system"],
              user: _0x55587d["user"],
              fields: _0x238905,
              model: _0x55587d["model"],
              openaiKey: _0x55587d["openaiKey"],
            });
            if (!_0x265d11["ok"]) {
              _0x755579(_0x265d11);
              return;
            }
            var _0x45e8ce = _0x265d11["data"]
              ? _0x265d11["data"][_0xc45ad5]
              : void 0x0;
            if (void 0x0 === _0x45e8ce) {
              _0x755579({
                ok: !0x1,
                error: "field\x20missing\x20in\x20response:\x20" + _0xc45ad5,
              });
              return;
            }
            _0x755579({ ok: !0x0, data: _0x45e8ce });
          } catch (_0x375350) {
            _0x755579({
              ok: !0x1,
              error:
                _0x375350 && _0x375350["message"]
                  ? _0x375350["message"]
                  : String(_0x375350),
            });
          }
        });
      },
    };
  })());
function _0x2471d3(
  _0x467c91,
  _0x42a21e,
  _0xa41a8b,
  _0x40a4cf,
  _0x5b763d = 0x0,
) {
  const _0x516dff = document["createElement"]("a");
  (_0x516dff["setAttribute"]("id", _0x42a21e + "-link"),
    (_0x516dff["className"] = "icon-button"),
    _0x516dff["setAttribute"]("title", _0xa41a8b));
  const _0x53d2b0 = document["createElement"]("img");
  ((_0x53d2b0["src"] = chrome["runtime"]["getURL"](_0x467c91)),
    (_0x53d2b0["className"] = "icon-button-img"),
    _0x516dff["appendChild"](_0x53d2b0));
  const _0x4ac368 = document["createElement"]("span");
  ((_0x4ac368["className"] = "icon-button-status"),
    _0x516dff["appendChild"](_0x4ac368));
  if (_0x5b763d > 0x0) {
    const _0x5eaf67 = document["createElement"]("span");
    ((_0x5eaf67["className"] = "icon-button-number"),
      (_0x5eaf67["textContent"] = _0x5b763d),
      _0x516dff["appendChild"](_0x5eaf67),
      _0x516dff["classList"]["add"]("with-number"));
  }
  return (
    _0x516dff["addEventListener"]("click", async function (_0x34bac5) {
      (_0x34bac5["preventDefault"](),
        (_0x4ac368["textContent"] = "⏳"),
        _0x4ac368["classList"]["add"]("rotating"));
      try {
        (await _0x40a4cf(),
          (_0x4ac368["textContent"] = "✅"),
          setTimeout(() => {
            _0x4ac368["textContent"] = "";
          }, 0xbb8));
      } catch (_0x57aa93) {
        ((_0x4ac368["textContent"] = "❌"),
          setTimeout(() => {
            _0x4ac368["textContent"] = "";
          }, 0xbb8));
      }
      _0x4ac368["classList"]["remove"]("rotating");
    }),
    _0x516dff
  );
}
var _0x39c37b = (_0x5826bd, _0x24bab2) => {
  var _0x3ae95d = document["querySelector"](_0x5826bd);
  console["log"]("Checking");
  if (_0x3ae95d) return (console["log"]("Found"), _0x24bab2(_0x3ae95d));
  setTimeout(() => _0x39c37b(_0x5826bd, _0x24bab2), 0x1f4);
};
function _0xa343f6(_0x569e31, _0x9f1694 = 0x32, _0x344896 = 0x64) {
  const _0x2e905e = document["querySelector"](_0x569e31);
  !window["__" + _0x569e31] &&
    ((window["__" + _0x569e31] = 0x0),
    (window["__" + _0x569e31 + "__delay"] = _0x9f1694),
    (window["__" + _0x569e31 + "__tries"] = _0x344896));
  if (null === _0x2e905e) {
    if (window["__" + _0x569e31] >= window["__" + _0x569e31 + "__tries"])
      return ((window["__" + _0x569e31] = 0x0), Promise["resolve"](null));
    return new Promise((_0x4f2ab0) => {
      (window["__" + _0x569e31]++,
        setTimeout(_0x4f2ab0, window["__" + _0x569e31 + "__delay"]));
    })["then"](() => _0xa343f6(_0x569e31));
  }
  return Promise["resolve"](_0x2e905e);
}
function _0x2c7b14(
  _0x6aa37 = document,
  _0x39204d,
  _0x5374d9 = 0x32,
  _0x3f940f = 0x64,
) {
  const _0x42055e = _0x6aa37["querySelector"](_0x39204d);
  !window["__" + _0x39204d] &&
    ((window["__" + _0x39204d] = 0x0),
    (window["__" + _0x39204d + "__delay"] = _0x5374d9),
    (window["__" + _0x39204d + "__tries"] = _0x3f940f));
  if (null === _0x42055e) {
    if (window["__" + _0x39204d] >= window["__" + _0x39204d + "__tries"])
      return ((window["__" + _0x39204d] = 0x0), Promise["resolve"](null));
    return new Promise((_0x276fe6) => {
      (window["__" + _0x39204d]++,
        setTimeout(_0x276fe6, window["__" + _0x39204d + "__delay"]));
    })["then"](() => _0xa343f6(_0x39204d));
  }
  return Promise["resolve"](_0x42055e);
}
async function _0x13a12a(_0x4640b5, _0x4ced77 = 0xea60) {
  return new Promise((_0x16b759, _0x4c2033) => {
    const _0x49cf63 = setInterval(() => {
      const _0x56bc76 = document["querySelector"](_0x4640b5);
      if (_0x56bc76)
        (console["log"]("Found\x20element\x20for\x20selector\x20" + _0x4640b5),
          clearInterval(_0x49cf63),
          _0x16b759(_0x56bc76));
      else
        console["log"](
          "Waiting\x20for\x20element\x20for\x20selector\x20" + _0x4640b5,
        );
    }, 0x64);
    setTimeout(() => {
      (console["log"](
        "Timed\x20out\x20after\x20" +
          _0x4ced77 +
          "\x20ms\x20for\x20selector\x20" +
          _0x4640b5,
      ),
        clearInterval(_0x49cf63),
        _0x4c2033(
          new Error(
            "Timed\x20out\x20after\x20" +
              _0x4ced77 +
              "\x20ms\x20for\x20selector\x20" +
              _0x4640b5,
          ),
        ));
    }, _0x4ced77);
  });
}
async function _0x139e0e(_0x482cf3, _0x4faaee = 0x2710, _0x1f1dfb = 0x1f4) {
  const _0x5c0af2 = Date["now"]() + _0x4faaee;
  for (; Date["now"]() < _0x5c0af2; ) {
    const _0x53f03d = document["querySelector"](_0x482cf3);
    if (_0x53f03d) return _0x53f03d;
    await new Promise((_0x171eda) => setTimeout(_0x171eda, _0x1f1dfb));
  }
  return (
    console["error"](
      "Timed\x20out\x20waiting\x20for\x20element:\x20" + _0x482cf3,
    ),
    null
  );
}
async function _0x4f7544(_0x12c8cc, _0x4d596e = 0x2710, _0x522186 = 0x1f4) {
  const _0x188ec4 = Date["now"]() + _0x4d596e;
  for (; Date["now"]() < _0x188ec4; ) {
    for (let _0x463f8f = 0x0; _0x463f8f < _0x12c8cc["length"]; _0x463f8f++) {
      const _0x10ba7a = document["querySelector"](_0x12c8cc[_0x463f8f]);
      if (_0x10ba7a) return _0x10ba7a;
    }
    await new Promise((_0xd031eb) => setTimeout(_0xd031eb, _0x522186));
  }
  return (
    console["error"](
      "Timed\x20out\x20waiting\x20for\x20any\x20of\x20these\x20elements:\x20" +
        _0x12c8cc,
    ),
    null
  );
}
function _0x347a5b() {
  return new Promise((_0x50a836) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x50a836();
      });
    });
  });
}
function _0x5b566d() {
  return new Promise((_0x4766a4) => {
    requestIdleCallback(() => {
      _0x4766a4();
    });
  });
}
function _0x187192(_0x528af0 = 0x3e8) {
  return new Promise((_0x2a1949, _0x4e348a) => {
    let _0x4a5602,
      _0x551a36 = Date["now"](),
      _0x5916e3 = !0x1;
    function _0x162e0b() {
      if (Date["now"]() - _0x551a36 > _0x528af0)
        (_0x5916e3 && _0x4a5602["disconnect"](), _0x2a1949());
      else setTimeout(_0x162e0b, _0x528af0);
    }
    const _0x5a4cf3 = () => {
        _0x551a36 = Date["now"]();
      },
      _0x26c7e8 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x4a5602 = new MutationObserver(_0x5a4cf3)),
        _0x4a5602["observe"](document["body"], _0x26c7e8),
        (_0x5916e3 = !0x0),
        setTimeout(_0x162e0b, _0x528af0));
    else
      window["onload"] = () => {
        ((_0x4a5602 = new MutationObserver(_0x5a4cf3)),
          _0x4a5602["observe"](document["body"], _0x26c7e8),
          (_0x5916e3 = !0x0),
          setTimeout(_0x162e0b, _0x528af0));
      };
  });
}
async function _0x29fef8() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x187192(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x124812() {
  return await new Promise(function (_0xe38810, _0x37303f) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x22932a) {
        (console["log"]("result:\x20", _0x22932a["membership"]),
          _0xe38810(_0x22932a["membership"]));
      },
    );
  });
}
async function _0x579cdf() {
  return await new Promise(function (_0x189219, _0x5bc1d3) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x416dd1) {
        (console["log"]("result:\x20", _0x416dd1["creditsAvailable"]),
          _0x189219(_0x416dd1["creditsAvailable"]));
      },
    );
  });
}
async function _0x23c7ba(_0x9e42d4) {
  if ("ultimate" != (await _0x124812()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x579cdf()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
function _0x2f5aa4(_0x28b834) {
  var _0x398a09 = document["querySelector"](".sh-core-header__username");
  _0x398a09 && (_0x398a09["innerText"] = _0x28b834);
}
function _0xacfd79(_0x2acb48) {
  var _0x49ed72 = document["querySelector"]("#user-name");
  _0x49ed72 && (_0x49ed72["innerText"] = _0x2acb48);
}
function _0x468336(_0x2aaae4) {
  var _0x14f65d = document["querySelector"](
    ".site-preferences-top-nav__feedback",
  );
  _0x14f65d && (_0x14f65d["innerText"] = _0x2aaae4);
}
function _0x51ba68(_0x4b1ef1, _0x3fcc51) {
  !(function _0x1f50c5(_0x38b5cf) {
    _0x38b5cf["nodeType"] === Node["TEXT_NODE"]
      ? (_0x38b5cf["nodeValue"] = _0x38b5cf["nodeValue"]["replace"](
          new RegExp(_0x4b1ef1, "gi"),
          _0x3fcc51,
        ))
      : _0x38b5cf["nodeType"] === Node["ELEMENT_NODE"] &&
        Array["from"](_0x38b5cf["childNodes"])["forEach"](_0x1f50c5);
  })(document["body"]);
}
function _0x265a0f(_0x1593d3, _0x3dae8c) {
  var _0x3dcff4 = document["querySelector"]("#gh-uid");
  if (_0x3dcff4) {
    var _0x42ca63 = _0x3dcff4["innerText"]["replace"](
      new RegExp(_0x1593d3, "i"),
      _0x3dae8c,
    );
    _0x3dcff4["innerText"] = _0x42ca63;
  }
}
async function _0x2b1e98() {
  var { fullName: _0xe114a7 } =
    await chrome["storage"]["local"]["get"]("fullName");
  console["log"](_0xe114a7);
  if (_0xe114a7 && "string" == typeof _0xe114a7) return _0xe114a7;
  var _0xe114a7 = await fetchFullName();
  return (
    console["log"]("Fullname\x20that\x20is\x20fetched:\x20" + _0xe114a7),
    chrome["storage"]["local"]["set"]({ fullName: _0xe114a7 }),
    _0xe114a7
  );
}
async function _0x13ec90() {
  var { storeName: _0x2c0dc5 } =
    await chrome["storage"]["local"]["get"]("storeName");
  if (_0x2c0dc5 && "string" == typeof _0x2c0dc5) return _0x2c0dc5;
  var _0x2c0dc5 = await fetchStoreName();
  return (
    console["log"]("Storename\x20that\x20is\x20fetched:\x20" + _0x2c0dc5),
    chrome["storage"]["local"]["set"]({ storeName: _0x2c0dc5 }),
    _0x2c0dc5
  );
}
async function fetchStoreName() {
  return document["querySelector"](".str-seller-card__user-name")["innerText"][
    "trim"
  ]();
}
async function fetchFullName() {
  return (
    await _0x33e542(),
    _0x240935()["parentElement"]["firstChild"]["innerText"]["trim"]()
  );
}
async function _0x33e542() {
  if (!_0x240935()) {
    var _0x281721 = document["querySelector"](".gh-identity\x20button");
    _0x281721 &&
      (_0x281721["click"](),
      !_0x240935() &&
        (await new Promise((_0x5d8d42) => setTimeout(_0x5d8d42, 0x3e8)),
        _0x281721["click"]()));
  }
}
function _0x240935() {
  return document["querySelector"](".gh-identity-signed-in__user-ratings");
}
async function _0x58ea01() {
  var { ebayUsername: _0x255422 } =
    await chrome["storage"]["local"]["get"]("ebayUsername");
  if (_0x255422 && "string" == typeof _0x255422) return _0x255422;
  var _0x255422 = await fetchUserName();
  return (
    console["log"]("ebayUsername\x20that\x20is\x20fetched:\x20" + _0x255422),
    chrome["storage"]["local"]["set"]({ ebayUsername: _0x255422 }),
    _0x255422
  );
}
async function fetchUserName() {
  return (
    await _0x33e542(),
    _0x240935()["children"][0x0]["innerText"]["trim"]()
  );
}
function _0x163ff6(_0x17c0bd) {
  return _0x17c0bd["charAt"](0x1) + "*****";
}
function _0x2d5c3e(_0x242c51, _0x6a9e51) {
  var _0x33e2a9 = document["getElementById"]("gh-ug");
  if (_0x33e2a9) {
    var _0x4321de = _0x242c51["split"]("\x20"),
      _0x5356d4 = _0x33e2a9["innerText"];
    (_0x4321de["forEach"]((_0x337fa0) => {
      _0x5356d4 = _0x5356d4["replace"](new RegExp(_0x337fa0, "i"), _0x6a9e51);
    }),
      (_0x33e2a9["innerText"] = _0x5356d4));
    var _0x5bb4b2 = document["querySelector"]("#gh-un");
    _0x5bb4b2 &&
      (_0x5bb4b2["textContent"] = _0x5bb4b2["textContent"]["replace"](
        new RegExp(_0x242c51, "i"),
        _0x6a9e51,
      ));
  }
}
function _0x259ce4() {
  var _0x5c8523 = document["querySelector"]("#me-badge"),
    _0x4f985c =
      _0x5c8523["querySelector"]("a")["innerText"]["charAt"](0x1) + "*****";
  _0x5c8523["querySelector"]("a")["innerText"] = _0x4f985c;
}
function _0x1ab302() {
  var _0x59b2c6 = document["querySelector"](
      ".ux-seller-section__item--seller\x20.ux-textspans",
    ),
    _0x456887 = _0x59b2c6["innerText"]["charAt"](0x1) + "*****";
  _0x59b2c6["innerText"] = _0x456887;
}
function _0x58224e(_0x57c8e9) {
  var _0x51f0ba = document["querySelector"]("[data-test-id=\x22user-name\x22]");
  _0x51f0ba && (_0x51f0ba["innerText"] = _0x57c8e9);
}
function _0x556a94() {
  var _0x138ebd = document["querySelector"](".mbg-id"),
    _0x7f59be = _0x138ebd["innerText"]["charAt"](0x1) + "*****";
  _0x138ebd["innerText"] = _0x7f59be;
}
function _0x444fd3() {
  var _0x96adea = document["querySelector"](".m-top-nav__username"),
    _0x2d5019 = _0x96adea["innerText"]["charAt"](0x1) + "*****";
  _0x96adea["innerText"] = _0x2d5019;
}
function _0x53b891() {
  [
    ".shipping-address\x20.address",
    ".phone.ship-itm",
    ".note-content",
    "#amazonEmail",
    "#amazonOrderNumber",
    ".order-info",
    ".clipboard-key",
    ".item__buyer-name",
    ".item__order-number",
    ".user-note",
    ".lineItemCardInfo__sku",
    ".gh-identity",
    ".details",
    ".page-header__user-profile-bookmark",
    ".ux-layout-section__item--table-view",
  ]["forEach"]((_0xb19251) => {
    document["querySelectorAll"](_0xb19251)["forEach"]((_0x33904f) => {
      ((_0x33904f["style"]["filter"] = "blur(5px)"),
        (_0x33904f["style"]["pointerEvents"] = "none"));
    });
  });
}
console["log"]("ebay/mesh_order_details/functions.js");
async function _0x3bc7ff(_0x3ac26e = document) {
  var _0x57aa19 = null,
    _0x256f99 = _0x3ac26e["querySelector"](".lineItemCardInfo__sku.spaceTop");
  if (_0x256f99)
    return (
      (!(_0x57aa19 =
        _0x256f99["querySelectorAll"](".sh-secondary")[0x1]["innerText"])[
        "startsWith"
      ]("B") &&
        isNaN(_0x57aa19["charAt"](0x0))) ||
        (_0x57aa19 = btoa(_0x57aa19)),
      _0x57aa19
    );
  return _0x57aa19;
}
function _0x40583f(_0x109008 = document) {
  var _0x1bd46a = _0x109008["querySelector"](".soldPrice__value")["innerText"];
  return (_0x1bd46a = _0x1bd46a["replace"](/[^0-9.-]+/g, ""))["replace"](
    ",",
    ".",
  );
}
function _0x6207b7(_0x5348fd = document) {
  return _0x5348fd["querySelectorAll"](
    ".order-info\x20.info-item\x20.info-value",
  )[0x0]["innerText"];
}
function _0x467ebb(_0x40cd55 = document) {
  return (_0x4eb8d9("Date\x20sold", _0x40cd55) ||
    _0x4eb8d9("Verkauft\x20am", _0x40cd55) ||
    _0x4eb8d9("Sold", _0x40cd55) ||
    _0x4eb8d9("Verkauft", _0x40cd55))["parentElement"]["nextElementSibling"][
    "querySelector"
  ](".info-value")["innerText"];
}
function _0x2eebbe(_0x30e115 = document) {
  return _0x30e115["querySelector"](".item-tile")["innerText"];
}
function _0x3892b7(_0x18e838 = document) {
  return _0x18e838["querySelector"](".quantity__value\x20.sh-bold")[
    "innerText"
  ];
}
function _0x454d86(_0x3c47b5 = document) {
  return _0x3c47b5["querySelector"](
    ".payment-info\x20.earnings\x20.total\x20.amount\x20.sh-bold",
  )["innerText"];
}
function _0x4eb8d9(_0x11a426, _0x1a6c87 = document) {
  const _0x1874af = _0x1a6c87["querySelectorAll"]("*");
  for (let _0x42aa2c of _0x1874af)
    if (_0x42aa2c["innerText"] === _0x11a426) return _0x42aa2c;
  return null;
}
function _0x319b61(_0x37d5c6 = document) {
  const _0x2c73f0 = findFeeItemWith2Negatives(_0x37d5c6);
  return _0x2c73f0 ? _0x2ac38e(_0x3d0938(_0x2c73f0)[0x0]) : "0";
}
function _0x34bc10(_0x2e17a4 = document) {
  const _0x15488d = findFeeItemWith2Negatives(_0x2e17a4);
  return _0x15488d ? _0x2ac38e(_0x3d0938(_0x15488d)[0x1]) : "0";
}
function findFeeItemWith2Negatives(_0x2af0ac = document) {
  const _0x1187e7 = _0x2af0ac["querySelectorAll"](".earnings\x20.data-item");
  for (const _0x437f17 of _0x1187e7)
    if (0x2 === _0x3d0938(_0x437f17)["length"]) return _0x437f17;
  return null;
}
function _0x3d0938(_0x2e949a) {
  return Array["from"](
    _0x2e949a["querySelectorAll"](".level-2\x20.amount\x20.value"),
  )
    ["map"]((_0x455187) => _0x455187["textContent"]["trim"]())
    ["filter"]((_0x45bdae) => _0x45bdae["startsWith"]("-"));
}
function _0x2ac38e(_0x413677) {
  if (!_0x413677 || "0" === _0x413677) return "0";
  const _0x2b8a54 = _0x413677["match"](
    /[-–]\s*([A-Za-z]{1,3}\s?\$)\s*([\d.,]+)/,
  );
  return _0x2b8a54 ? _0x2b8a54[0x1] + _0x2b8a54[0x2] : "0";
}
async function _0x1cea98(_0x2b188b = document) {
  const _0x435c98 = _0x2b188b["querySelector"](".shipping-address\x20.address");
  if (!_0x435c98) {
    console["log"]("No\x20shipping\x20address\x20element\x20found.");
    return;
  }
  const _0x2e8ec8 = Array["from"](_0x435c98["querySelectorAll"]("div"));
  let _0x9978fd = "",
    _0x55d73b = "",
    _0x423a9d = "",
    _0x54b0ff = "",
    _0x1171af = "",
    _0x3ebfe4 = "",
    _0x3147ca = "";
  function _0x32e2cc(_0x3cc759, _0x16d59c) {
    const _0x1f4930 = _0x3cc759["querySelectorAll"](".copy-to-clipboard");
    if (!_0x1f4930[_0x16d59c]) return "";
    const _0x59704d = _0x1f4930[_0x16d59c]["querySelector"]("button");
    if (!_0x59704d) return "";
    for (let _0x40df38 of _0x59704d["childNodes"])
      if (
        _0x40df38["nodeType"] === Node["TEXT_NODE"] &&
        _0x40df38["textContent"]["trim"]()
      )
        return _0x40df38["textContent"]["trim"]();
    return "";
  }
  _0x2e8ec8[0x0] &&
    ((_0x9978fd = _0x32e2cc(_0x2e8ec8[0x0], 0x0)),
    (_0x9978fd = _0x9978fd["replace"](
      /[^a-zA-Z0-9äöüÄÖÜßéÉèÈáÁàÀúÚóÓíÍüÜñÑ#,\-./ ]/g,
      "",
    )),
    (_0x9978fd = _0x9978fd["replace"](/\s+/g, "\x20")["trim"]()));
  _0x2e8ec8[0x1] && (_0x55d73b = _0x32e2cc(_0x2e8ec8[0x1], 0x0));
  if (_0x2e8ec8[0x2]) {
    const _0x1f58d2 =
      _0x2e8ec8[0x2]["querySelectorAll"](".copy-to-clipboard")["length"];
    if (_0x1f58d2 <= 0x1) _0x423a9d = _0x32e2cc(_0x2e8ec8[0x2], 0x0);
    else
      0x2 === _0x1f58d2
        ? ((_0x3ebfe4 = _0x32e2cc(_0x2e8ec8[0x2], 0x0)),
          (_0x54b0ff = _0x32e2cc(_0x2e8ec8[0x2], 0x1)))
        : ((_0x54b0ff = _0x32e2cc(_0x2e8ec8[0x2], 0x0)),
          (_0x1171af = _0x32e2cc(_0x2e8ec8[0x2], 0x1)),
          (_0x3ebfe4 = _0x32e2cc(_0x2e8ec8[0x2], 0x2)));
  }
  if (_0x423a9d && _0x2e8ec8[0x3]) {
    const _0x43ef25 =
      _0x2e8ec8[0x3]["querySelectorAll"](".copy-to-clipboard")["length"];
    if (0x2 === _0x43ef25)
      ((_0x3ebfe4 = _0x32e2cc(_0x2e8ec8[0x3], 0x0)),
        (_0x54b0ff = _0x32e2cc(_0x2e8ec8[0x3], 0x1)));
    else
      0x3 === _0x43ef25 &&
        ((_0x54b0ff = _0x32e2cc(_0x2e8ec8[0x3], 0x0)),
        (_0x1171af = _0x32e2cc(_0x2e8ec8[0x3], 0x1)),
        (_0x3ebfe4 = _0x32e2cc(_0x2e8ec8[0x3], 0x2)));
  }
  const _0x286b84 = _0x2e8ec8["length"] - 0x1;
  _0x286b84 >= 0x0 && (_0x3147ca = _0x32e2cc(_0x2e8ec8[_0x286b84], 0x0));
  let _0x557649 = "";
  const _0x46054a = _0x2b188b["querySelector"](".phone.ship-itm");
  _0x46054a && (_0x557649 = _0x32e2cc(_0x46054a, 0x0));
  /^ebay:[^\s]+$/i["test"](_0x55d73b) &&
    ((_0x55d73b = _0x423a9d), (_0x423a9d = ""));
  ((_0x55d73b = _0x55d73b["replace"](/\bebay\w*/gi, "")["trim"]()),
    (_0x423a9d = _0x423a9d["replace"](/\bebay\w*/gi, "")["trim"]()),
    console["log"]({
      name: _0x9978fd,
      line_1: _0x55d73b,
      line_2: _0x423a9d,
      city: _0x54b0ff,
      state: _0x1171af,
      zip: _0x3ebfe4,
      country: _0x3147ca,
      phone: _0x557649,
    }));
  var {
    useCustomAmazonPhoneNumber: _0x3b5608,
    customAmazonPhoneNumber: _0xdfc948,
  } = await chrome["storage"]["local"]["get"]([
    "useCustomAmazonPhoneNumber",
    "customAmazonPhoneNumber",
  ]);
  return (
    _0x3b5608 &&
      _0xdfc948 &&
      _0xdfc948["trim"]()["length"] > 0x0 &&
      (_0x557649 = _0xdfc948["trim"]()),
    {
      phone: _0x557649,
      name: _0x9978fd,
      address: {
        line_1: _0x55d73b,
        line_2: _0x423a9d,
        city: _0x54b0ff,
        state: _0x1171af,
        zip: _0x3ebfe4,
        country: _0x3147ca,
      },
    }
  );
}
async function _0x131a7c(_0xb8c87f = document) {
  var _0x5a6184 = {};
  (console["log"]("Initialized\x20orderDetails:", _0x5a6184),
    (_0x5a6184["itemName"] = _0x2eebbe(_0xb8c87f)),
    console["log"]("Item\x20Name:", _0x5a6184["itemName"]),
    (_0x5a6184["dateOfSale"] = _0x467ebb(_0xb8c87f)),
    console["log"]("Date\x20of\x20Sale:", _0x5a6184["dateOfSale"]),
    (_0x5a6184["ebayOrderNumber"] = _0x6207b7(_0xb8c87f)),
    console["log"]("eBay\x20Order\x20Number:", _0x5a6184["ebayOrderNumber"]),
    (_0x5a6184["quantitySold"] = _0x3892b7(_0xb8c87f)),
    console["log"]("Quantity\x20Sold:", _0x5a6184["quantitySold"]),
    (_0x5a6184["orderEarnings"] = _0x10d44d(_0x454d86(_0xb8c87f))),
    console["log"]("Order\x20Earnings:", _0x5a6184["orderEarnings"]),
    (_0x5a6184["soldPrice"] = _0x10d44d(_0x40583f(_0xb8c87f))),
    (_0x5a6184["ebayFees"] = _0x10d44d(_0x319b61(_0xb8c87f))),
    (_0x5a6184["addFee"] = _0x10d44d(_0x34bc10(_0xb8c87f))));
  var _0x11eac6 = await _0x3bc7ff(_0xb8c87f);
  ((_0x5a6184["ebaySku"] = _0x11eac6),
    console["log"]("eBay\x20SKU:", _0x5a6184["ebaySku"]));
  var _0x95ead6 = await _0x1cea98(_0xb8c87f);
  ((_0x5a6184["customer"] = _0x95ead6),
    console["log"]("Customer:", _0x5a6184["customer"]));
  var { domain: _0x6ca51f } = await chrome["storage"]["local"]["get"]("domain");
  ((_0x5a6184["domain"] = _0x6ca51f),
    console["log"]("Domain:", _0x5a6184["domain"]));
  try {
    var _0x1079bf = _0x18e666();
    if (_0x1079bf) {
      _0x5a6184 = { ..._0x5a6184, ..._0x1079bf };
      var _0x44135b = await _0xbea765(
        _0x5a6184["orderEarnings"],
        _0x5a6184["totalBeforeTax"],
        _0x5a6184["totalTax"],
        _0x5a6184["amazonDomain"],
      );
      (console["log"]("Profit:", _0x44135b), (_0x5a6184["profit"] = _0x44135b));
    }
    var _0xc7157d = _0x3cdbde();
    _0xc7157d && (_0x5a6184["remarks"] = _0xc7157d);
    var _0x5261b5 = _0xb8c87f["querySelector"]("#googleSheetRowNumber");
    _0x5261b5 && (_0x5a6184["googleSheetRowNumber"] = _0x5261b5["value"]);
  } catch (_0x587168) {}
  var { email: _0x11342c } = await chrome["storage"]["local"]["get"]("email");
  _0x5a6184["email"] = _0x11342c;
  var _0x4a3a1e = await _0x58ea01();
  return ((_0x5a6184["ebayUsername"] = _0x4a3a1e), _0x5a6184);
}
function _0x10d44d(_0x492104) {
  if (!_0x492104) return null;
  let _0x48e251 = _0x492104["replace"](/[^\d.,-]/g, "")["trim"]();
  if (
    _0x48e251["includes"](",") &&
    _0x48e251["lastIndexOf"](",") > _0x48e251["lastIndexOf"](".")
  )
    ((_0x48e251 = _0x48e251["replace"](/\./g, "")),
      (_0x48e251 = _0x48e251["replace"](",", ".")));
  else _0x48e251 = _0x48e251["replace"](/,/g, "");
  const _0x4c321e = parseFloat(_0x48e251);
  return isNaN(_0x4c321e) ? null : _0x4c321e;
}
console["log"]("ebay/mesh_order_details/functions.js");
var _0x3efd8f;
function _0x293f66() {
  return document["querySelector"](".lineItemCardInfo__itemId.spaceTop");
}
async function _0x59dacd() {
  console["log"]("createSkuElementButton");
  var _0x126d05 = await _0x3bc7ff();
  console["log"]("skuTest", _0x126d05);
  if (_0x126d05 && _0x126d05["endsWith"]("=="))
    (console["log"]("skuTest", _0x126d05),
      console["log"](
        "No\x20need\x20to\x20create\x20SKU\x20button.\x20SKU\x20ends\x20with\x20\x22==\x22.",
      ));
  else {
    var _0x1740ef = document["querySelector"](
      ".lineItemCardInfo__content\x20.details",
    );
    _0x1740ef || (_0x1740ef = document["body"]);
    var _0xf996a1 = document["createElement"]("button");
    ((_0xf996a1["textContent"] = "Get\x20SKU"),
      _0x1740ef["insertBefore"](_0xf996a1, _0x1740ef["children"][0x1]),
      _0xf996a1["addEventListener"]("click", async function (_0x40ae2f) {
        _0x40ae2f["preventDefault"]();
        var _0x374b14 = document["createElement"]("div");
        _0x374b14["classList"]["add"]("lineItemCardInfo__sku", "spaceTop");
        var _0x5ea2ac = document["createElement"]("span");
        (_0x5ea2ac["classList"]["add"]("sh-secondary"),
          (_0x5ea2ac["textContent"] = "Custom\x20label\x20(SKU):\x20"));
        var _0x5fb46d = document["createElement"]("span");
        _0x5fb46d["classList"]["add"]("sh-secondary");
        var _0x27f2ea = _0x12afa4(),
          _0x52f249 = await _0x1c21f9(_0x27f2ea);
        ((_0x5fb46d["textContent"] = _0x52f249),
          _0x374b14["appendChild"](_0x5ea2ac),
          _0x374b14["appendChild"](_0x5fb46d),
          _0x1740ef["replaceChild"](_0x374b14, _0xf996a1));
      }));
  }
}
async function _0xd0f970() {
  var _0x6189d1 = document["createElement"]("button");
  return (
    (_0x6189d1["innerText"] = "Copy"),
    _0x6189d1["classList"]["add"]("amazon-copy-link-button"),
    _0x6189d1["addEventListener"]("click", async function () {
      var _0x5a27f4 = await _0x3bc7ff();
      if (!_0x5a27f4) return null;
      console["log"]("sku", _0x5a27f4);
      var _0x59c943 = await _0x492821(_0x5a27f4);
      (navigator["clipboard"]["writeText"](_0x59c943),
        _0x6189d1["classList"]["add"]("amazon-copy-link-button-clicked"),
        (_0x6189d1["innerText"] = "Copied"));
    }),
    _0x6189d1
  );
}
async function _0x22bbc1(_0x4615ff = !0x1, _0x2ed9d6) {
  console["log"]("copyOrderDetails");
  var _0x413cf2 = await _0x131a7c();
  (console["log"]("orderDetails", _0x413cf2),
    await chrome["storage"]["local"]["set"]({ orderDetails: _0x413cf2 }));
  var _0x1dd0d9 = JSON["stringify"](_0x413cf2);
  console["log"]("stringified\x20orderDetails", _0x1dd0d9);
  if (_0x4615ff) {
    console["log"]("orderDetailsString", _0x1dd0d9);
    var _0x2b98d7 = {
      clipKey: _0x2ed9d6,
      content: JSON["stringify"](_0x413cf2),
    };
    console["log"]("data", _0x2b98d7);
    try {
      console["log"]("making\x20request");
      var _0x28ff00 = await fetch(
        "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/virtualClipboard/",
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON["stringify"](_0x2b98d7),
        },
      );
      console["log"]("response", _0x28ff00);
      if (!_0x28ff00["ok"])
        throw new Error("Failed\x20to\x20save\x20order\x20details");
      var _0x422444 = await _0x28ff00["json"]();
      return (
        console["log"]("Order\x20details\x20saved\x20successfully:", _0x422444),
        _0x422444
      );
    } catch (_0x22b908) {
      console["error"]("Error\x20saving\x20order\x20details:", _0x22b908);
      throw _0x22b908;
    }
  } else navigator["clipboard"]["writeText"](_0x1dd0d9);
}
async function _0x3168e0() {
  var { shouldCopyAddress: _0x749510 } =
    await chrome["storage"]["local"]["get"]("shouldCopyAddress");
  void 0x0 === _0x749510 &&
    ((_0x749510 = !0x0),
    await chrome["storage"]["local"]["set"]({ shouldCopyAddress: _0x749510 }));
  var _0x58ef1f = document["createElement"]("input");
  (_0x58ef1f["setAttribute"]("type", "checkbox"),
    _0x58ef1f["classList"]["add"]("amazon-copy-address-field"),
    _0x58ef1f["setAttribute"]("id", "amazon-copy-address-field"));
  var _0x1843e1 = document["createElement"]("label");
  ((_0x1843e1["innerText"] = "Copy\x20Address"),
    _0x1843e1["setAttribute"]("for", "amazon-copy-address-field"),
    _0x1843e1["classList"]["add"]("amazon-copy-address-label"));
  var _0x266a5c = document["createElement"]("div");
  return (
    (_0x266a5c["id"] = "amazon-copy-address-div"),
    _0x266a5c["appendChild"](_0x1843e1),
    _0x266a5c["appendChild"](_0x58ef1f),
    (_0x58ef1f["checked"] = _0x749510),
    _0x58ef1f["addEventListener"]("change", async function () {
      await chrome["storage"]["local"]["set"]({
        shouldCopyAddress: _0x58ef1f["checked"],
      });
    }),
    _0x266a5c
  );
}
function _0x276474() {
  var _0x280d2f = document["createElement"]("div");
  _0x280d2f["classList"]["add"]("amazon-quantity-container");
  var _0x1472d7 = document["createElement"]("label");
  ((_0x1472d7["innerText"] = "Increase\x20Quantity"),
    _0x1472d7["classList"]["add"]("amazon-quantity-label"),
    _0x280d2f["appendChild"](_0x1472d7));
  var _0x4d4eae = document["createElement"]("button");
  ((_0x4d4eae["innerText"] = "Increase\x20Quantity"),
    _0x4d4eae["classList"]["add"]("amazon-update-quantity-button"),
    _0x280d2f["appendChild"](_0x4d4eae),
    _0x4d4eae["addEventListener"]("click", async function () {
      _0x4d4eae["classList"]["add"]("amazon-update-quantity-button-working");
      var _0x2d873b = document["querySelector"](
        ".lineItemCardInfo__itemId.spaceTop",
      )["querySelectorAll"](".sh-secondary")[0x1]["innerText"];
      _0x4d4eae["innerText"] = "In\x20Progress";
      try {
        var _0x28280d = await new Promise((_0x22eeeb) => {
          chrome["runtime"]["sendMessage"](
            { type: "increaseQuantityOfItem", itemNumber: _0x2d873b },
            function (_0x515874) {
              (console["log"](_0x515874), _0x22eeeb(_0x515874));
            },
          );
        });
        _0x4d4eae["classList"]["remove"](
          "amazon-update-quantity-button-working",
        );
        if (!_0x28280d || !_0x28280d["response"])
          throw new Error("Response\x20Error");
        (_0x4d4eae["classList"]["add"]("amazon-update-quantity-button-success"),
          (_0x4d4eae["innerText"] = "Updated"),
          _0x4d4eae["dispatchEvent"](
            new CustomEvent("increase:done", {
              detail: { ok: !0x0, response: _0x28280d },
            }),
          ));
      } catch (_0x4fc8fa) {
        (_0x4d4eae["classList"]["remove"](
          "amazon-update-quantity-button-working",
        ),
          _0x4d4eae["classList"]["add"]("amazon-update-quantity-button-error"),
          (_0x4d4eae["innerText"] = "Error"),
          console["log"]("error", _0x4fc8fa),
          _0x4d4eae["dispatchEvent"](
            new CustomEvent("increase:done", {
              detail: { ok: !0x1, error: _0x4fc8fa },
            }),
          ));
      }
    }));
  var _0x5eb237 = document["createElement"]("select");
  _0x5eb237["classList"]["add"]("amazon-quantity-select");
  for (var _0x38726f = 0x0; _0x38726f <= 0xa; _0x38726f++) {
    var _0x56e979 = document["createElement"]("option");
    ((_0x56e979["value"] = _0x38726f),
      (_0x56e979["text"] = _0x38726f),
      _0x5eb237["appendChild"](_0x56e979));
  }
  return (
    chrome["storage"]["local"]["get"]("quantityToUpdate", function (_0x40c614) {
      if (_0x40c614["quantityToUpdate"])
        _0x5eb237["value"] = _0x40c614["quantityToUpdate"];
      else
        ((_0x5eb237["value"] = 0x1),
          chrome["storage"]["local"]["set"]({ quantityToUpdate: 0x1 }));
    }),
    _0x5eb237["addEventListener"]("change", function () {
      var _0x510d6c = _0x5eb237["value"];
      chrome["storage"]["local"]["set"]({ quantityToUpdate: _0x510d6c });
    }),
    _0x280d2f["appendChild"](_0x5eb237),
    _0x280d2f
  );
}
function _0x268bfe() {
  var _0x2f945b = document["createElement"]("button");
  return (
    (_0x2f945b["innerText"] = "Copy\x20ETA\x20Message"),
    _0x2f945b["classList"]["add"]("amazon-copy-eta-button"),
    _0x2f945b["addEventListener"]("click", async function () {
      var _0x4f6184 = _0x217d9e(),
        { etaMessage: _0x36ee79 } =
          await chrome["storage"]["local"]["get"]("etaMessage");
      !_0x36ee79 &&
        ((_0x36ee79 = await fetch(
          chrome["runtime"]["getURL"](
            "content/ebay/mesh_order_details/eta_options/eta_message_default.txt",
          ),
        )),
        (_0x36ee79 = await _0x36ee79["text"]()));
      var _0x1ceef7 = document["querySelectorAll"](
        ".shipping-address\x20.tooltip",
      )[0x1]["innerText"];
      ((_0x1ceef7 =
        (_0x1ceef7 = _0x1ceef7["split"]("\x20")[0x0])
          ["charAt"](0x0)
          ["toUpperCase"]() + _0x1ceef7["slice"](0x1)["toLowerCase"]()),
        (_0x36ee79 = (_0x36ee79 = _0x36ee79["replace"](
          "{{Customer_Name}}",
          _0x1ceef7,
        ))["replace"]("{{Delivery_Date}}", _0x4f6184)),
        navigator["clipboard"]["writeText"](_0x36ee79),
        _0x2f945b["classList"]["add"]("amazon-copy-eta-button-clicked"),
        (_0x2f945b["innerText"] = "Copied"));
    }),
    _0x2f945b
  );
}
function _0x1087a7() {
  var _0xf0fae4 = document["createElement"]("button");
  return (
    (_0xf0fae4["innerText"] = "Copy\x20Feedback\x20Message"),
    _0xf0fae4["classList"]["add"]("amazon-copy-feedback-button"),
    _0xf0fae4["addEventListener"]("click", async function () {
      var { feedbackMessage: _0x4582ae } =
        await chrome["storage"]["local"]["get"]("feedbackMessage");
      !_0x4582ae &&
        ((_0x4582ae = await fetch(
          chrome["runtime"]["getURL"](
            "content/ebay/mesh_order_details/feedback_options/feedback_message_default.txt",
          ),
        )),
        (_0x4582ae = await _0x4582ae["text"]()));
      var _0xe84bb = (await _0x131a7c())["customer"]["name"]["split"](
          "\x20",
        )[0x0],
        _0x23ac48 = _0x4582ae["replace"]("{{Customer_Name}}", _0xe84bb);
      navigator["clipboard"]["writeText"](_0x23ac48);
    }),
    _0xf0fae4
  );
}
function _0xd839ca() {
  var _0x1bd2b2 = document["createElement"]("input");
  (_0x1bd2b2["setAttribute"]("type", "date"),
    _0x1bd2b2["classList"]["add"]("amazon-eta-field"));
  var _0x4a587b = document["createElement"]("label");
  ((_0x4a587b["innerText"] = "ETA"),
    _0x4a587b["setAttribute"]("for", "amazon-eta-field"),
    _0x4a587b["classList"]["add"]("amazon-eta-label"));
  var _0x47d146 = document["createElement"]("div");
  (_0x47d146["appendChild"](_0x4a587b), _0x47d146["appendChild"](_0x1bd2b2));
  var _0x5c92cf = document["createElement"]("a");
  return (
    (_0x5c92cf["innerText"] = "Change\x20ETA\x20Message"),
    _0x5c92cf["classList"]["add"]("amazon-eta-link"),
    _0x5c92cf["setAttribute"]("target", "_blank"),
    _0x5c92cf["setAttribute"](
      "href",
      chrome["runtime"]["getURL"](
        "content/ebay/mesh_order_details/eta_options/eta_options.html",
      ),
    ),
    _0x47d146["appendChild"](_0x5c92cf),
    _0x47d146
  );
}
function _0x482772() {
  var _0x41bbf9 = document["createElement"]("div"),
    _0x5ebb08 = document["createElement"]("a");
  return (
    (_0x5ebb08["innerText"] = "Change\x20Feedback\x20Message"),
    _0x5ebb08["classList"]["add"]("amazon-feedback-link"),
    _0x5ebb08["setAttribute"]("target", "_blank"),
    _0x5ebb08["setAttribute"](
      "href",
      chrome["runtime"]["getURL"](
        "content/ebay/mesh_order_details/feedback_options/feedback_options.html",
      ),
    ),
    _0x41bbf9["appendChild"](_0x5ebb08),
    _0x41bbf9
  );
}
function _0x217d9e() {
  var _0x16dcbb = document["querySelector"](".amazon-eta-field"),
    _0xfccb1f = new Date(_0x16dcbb["value"]);
  return (
    _0xfccb1f["setDate"](_0xfccb1f["getDate"]() + 0x1),
    _0xfccb1f["toLocaleDateString"]("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  );
}
async function _0x492821(_0x13df9f) {
  var { domain: _0x34bef0 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x1da41d =
      "https://www.amazon." +
      _0x34bef0 +
      "/dp/" +
      atob(_0x13df9f) +
      "?th=1&psc=1",
    { applyAmazonAffiliateTag: _0x1775b7 } = await chrome["storage"]["local"][
      "get"
    ]("applyAmazonAffiliateTag");
  return (_0x1775b7 && (_0x1da41d += "&tag=bestbatteri00-20"), _0x1da41d);
}
async function _0x42f64d(_0xc332d7) {
  var { email: _0x43aa12 } = await chrome["storage"]["local"]["get"]("email");
  _0xc332d7["email"] = _0x43aa12;
  try {
    var _0x3bed99 = await fetch(
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/ebayOrders",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON["stringify"](_0xc332d7),
      },
    );
    if (!_0x3bed99["ok"])
      throw new Error("Failed\x20to\x20submit\x20eBay\x20order");
    var _0x31733e = await _0x3bed99["json"]();
    return (
      console["log"]("eBay\x20order\x20submitted\x20successfully:", _0x31733e),
      _0x31733e
    );
  } catch (_0x1d7601) {
    console["error"]("Error\x20submitting\x20eBay\x20order:", _0x1d7601);
    throw _0x1d7601;
  }
}
function _0x2824e9() {
  var _0x1e5f13 = document["querySelector"](".shipping-address\x20.address");
  console["log"]("shippingAddressElement:", _0x1e5f13);
  var _0x1988aa = _0x1e5f13["childNodes"];
  console["log"]("children:", _0x1988aa);
  var _0x462979 = _0x1988aa[0x0]["innerText"];
  console["log"]("name:", _0x462979);
  var _0x2d152c, _0x14cd8a, _0x5171e7, _0x1b8d7d, _0x3106e9, _0x313d35;
  if (0x5 == _0x1988aa["length"])
    ((_0x2d152c = _0x1988aa[0x1]["innerText"]),
      console["log"]("line_1:", _0x2d152c),
      (_0x14cd8a = _0x1988aa[0x2]["innerText"]),
      console["log"]("line_2:", _0x14cd8a),
      (_0x5171e7 = (_0x36995a =
        _0x1988aa[0x3]["querySelectorAll"](".copy-to-clipboard"))[0x0][
        "innerText"
      ]),
      console["log"]("city:", _0x5171e7),
      (_0x1b8d7d = _0x36995a[0x1]["innerText"]),
      console["log"]("state:", _0x1b8d7d),
      (_0x3106e9 = _0x36995a[0x2]["innerText"]),
      console["log"]("zip:", _0x3106e9),
      (_0x313d35 = _0x1988aa[0x4]["innerText"]),
      console["log"]("country:", _0x313d35));
  else {
    if (0x4 == _0x1988aa["length"]) {
      ((_0x2d152c = _0x1988aa[0x1]["innerText"]),
        console["log"]("line_1:", _0x2d152c));
      var _0x36995a;
      ((_0x5171e7 = (_0x36995a =
        _0x1988aa[0x2]["querySelectorAll"](".copy-to-clipboard"))[0x0][
        "innerText"
      ]),
        console["log"]("city:", _0x5171e7),
        (_0x1b8d7d = _0x36995a[0x1]["innerText"]),
        console["log"]("state:", _0x1b8d7d),
        (_0x3106e9 = _0x36995a[0x2]["innerText"]),
        console["log"]("zip:", _0x3106e9),
        (_0x313d35 = _0x1988aa[0x3]["innerText"]),
        console["log"]("country:", _0x313d35));
    }
  }
  var _0x5716af = document["querySelector"](".phone.ship-itm");
  console["log"]("phoneNumberElement:", _0x5716af);
  var _0x2aeb51 = "";
  _0x5716af &&
    ((_0x2aeb51 = _0x5716af["querySelector"](".info-value")["innerText"]),
    console["log"]("phone:", _0x2aeb51));
  var _0x7be3af = {
    name: _0x462979,
    phone: _0x2aeb51,
    address: {
      line_1: _0x2d152c,
      line_2: _0x14cd8a,
      city: _0x5171e7,
      state: _0x1b8d7d,
      zip: _0x3106e9,
      country: _0x313d35,
    },
  };
  return (console["log"]("customer:", _0x7be3af), _0x7be3af);
}
function _0x3cdbde() {
  var _0x1c487a = document["querySelector"](".note-content");
  return _0x1c487a ? _0x1c487a["innerText"] : null;
}
function _0x18e666() {
  var _0xb3f31e =
      document["querySelector"]("#amazonOrderNumber")?.["innerText"],
    _0x91f1c1 = document["querySelector"]("#totalBeforeTax")?.["innerText"],
    _0x26a4b2 = document["querySelector"]("#totalTax")?.["innerText"],
    _0x454bcc = document["querySelector"]("#estimatedDeliveryDate")?.[
      "innerText"
    ],
    _0xd1e554 = document["querySelector"]("#amazonEmail")?.["innerText"],
    _0x2b887f = document["querySelector"]("#fulfillmentDate")?.["innerText"],
    _0x18c593 = document["querySelector"]("#amazonSku")?.["innerText"],
    _0x1d300d = document["querySelector"]("#amazonDomain")?.["innerText"];
  if (
    _0xb3f31e &&
    _0x91f1c1 &&
    _0x26a4b2 &&
    _0x454bcc &&
    _0xd1e554 &&
    _0x2b887f
  )
    return {
      amazonOrderNumber: _0xb3f31e,
      totalBeforeTax: _0x91f1c1,
      totalTax: _0x26a4b2,
      estimatedDeliveryDate: _0x454bcc,
      amazonEmail: _0xd1e554,
      fulfillmentDate: _0x2b887f,
      amazonSku: _0x18c593,
      amazonDomain: _0x1d300d,
    };
}
function _0xf56b9d() {
  var _0x5cdd3a = document["createElement"]("button");
  return (
    (_0x5cdd3a["innerText"] = "Export\x20to\x20EcomSniper"),
    _0x5cdd3a["classList"]["add"]("ebay-submit-order-details-button"),
    _0x5cdd3a["addEventListener"]("click", async function () {
      _0x5cdd3a["classList"]["add"]("ebay-submit-order-details-button-working");
      var _0x3dd866 = await _0x131a7c();
      console["log"]("orderDetails", _0x3dd866);
      try {
        var _0x13363e = await _0x42f64d(_0x3dd866);
        (console["log"]("response", _0x13363e),
          _0x5cdd3a["classList"]["remove"](
            "ebay-submit-order-details-button-working",
          ),
          _0x5cdd3a["classList"]["add"](
            "ebay-submit-order-details-button-success",
          ),
          (_0x5cdd3a["innerText"] = "Exported!"));
      } catch (_0x46fc18) {
        (_0x5cdd3a["classList"]["remove"](
          "ebay-submit-order-details-button-working",
        ),
          _0x5cdd3a["classList"]["add"](
            "ebay-submit-order-details-button-error",
          ),
          (_0x5cdd3a["innerText"] = "Error\x20Exporting\x20Data"),
          console["log"]("error", _0x46fc18));
      }
    }),
    _0x5cdd3a
  );
}
async function _0x94da9d() {
  var _0xf11a4a = await _0x131a7c();
  console["log"]("orderDetails", _0xf11a4a);
  try {
    var _0x3b0b66 = await _0x42f64d(_0xf11a4a);
    console["log"]("response", _0x3b0b66);
  } catch (_0x2bfcc9) {
    console["log"]("error", _0x2bfcc9);
  }
}
async function _0x5d3b42() {
  var _0x2c16d7 = await _0x131a7c();
  console["log"]("orderDetails", _0x2c16d7);
  var _0xffb950 = [
    null,
    null,
    "7999",
    _0x2c16d7["ebayOrderNumber"],
    _0x2c16d7["ebaySku"],
    _0x2c16d7["customer"]["name"],
    _0x2c16d7["customer"]["address"]["line_1"],
    _0x2c16d7["customer"]["address"]["line_2"],
    _0x2c16d7["customer"]["address"]["city"],
    _0x2c16d7["customer"]["address"]["state"],
    _0x2c16d7["customer"]["address"]["zip"],
    _0x2c16d7["customer"]["phone"],
    _0x2c16d7["quantitySold"],
    _0x2c16d7["dateOfSale"],
    _0x2c16d7["itemName"],
    _0x2c16d7["soldPrice"],
    _0x2c16d7["ebayFees"],
    _0x2c16d7["addFee"],
  ];
  console["log"]("rowValues", _0xffb950);
  var _0x33ee52 = await new Promise((_0x113ef) => {
    chrome["runtime"]["sendMessage"](
      { type: "createSheetRow", rowValues: _0xffb950 },
      function (_0x4abc79) {
        (console["log"](_0x4abc79), _0x113ef(_0x4abc79));
      },
    );
  });
  console["log"]("response", _0x33ee52);
  if (_0x33ee52 && "success" == _0x33ee52["result"]) {
    var _0x57ee1b = _0x33ee52["rowNumber"],
      _0x34b681 = document["createElement"]("div");
    ((_0x34b681["id"] = "googleSheetRowNumber"),
      (_0x34b681["value"] = _0x57ee1b),
      (_0x34b681["innerHTML"] = "Row\x20Number:\x20" + _0x57ee1b),
      (_0x34b681["style"]["color"] = "green"),
      (_0x34b681["style"]["fontWeight"] = "bold"),
      _0x293f66()["appendChild"](_0x34b681));
  }
  return _0x33ee52;
}
async function _0x4f537f() {
  document["querySelectorAll"](".actions\x20a")["forEach"]((_0x3e1059) => {
    _0x3e1059["setAttribute"]("target", "_blank");
  });
}
function _0x5e89fe() {
  var _0x17331b = document["createElement"]("button");
  return (
    (_0x17331b["innerHTML"] = "Import\x20Fulfillment\x20Details"),
    (_0x17331b["className"] = "importButton"),
    (_0x17331b["onclick"] = async function () {
      _0x4071ee();
    }),
    _0x17331b
  );
}
async function _0x4071ee(_0x43b1ee = !0x1, _0x1cab3c) {
  try {
    if (_0x43b1ee) {
      var _0x2630f3 = await fetch(
        "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/virtualClipboard/" +
          _0x1cab3c,
      );
      ((_0x2630f3 = await _0x2630f3["json"]()),
        console["log"]("response", _0x2630f3),
        console["log"](_0x2630f3["data"]["content"]),
        (_0x56444b = JSON["parse"](_0x2630f3["data"]["content"])),
        console["log"]("fullfilmentData", _0x56444b));
    } else {
      const _0x2265a4 = await navigator["clipboard"]["readText"]();
      _0x56444b = JSON["parse"](_0x2265a4);
    }
    await _0x34d86e(_0x56444b);
  } catch (_0x5b25db) {
    console["error"](
      "Error\x20importing\x20fulfillment\x20details:",
      _0x5b25db,
    );
    throw _0x5b25db;
  }
}
async function _0x34d86e(_0x25f250) {
  const _0x34d3ad =
      "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22fulfillmentDetails\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h2>Fulfillment\x20Details</h2>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Customer\x20Address:</strong>\x20<span\x20id=\x22customerAddress\x22>" +
      _0x25f250["customerAddress"]["replace"](/\n/g, "<br>") +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Order\x20Number:</strong>\x20<span\x20id=\x22amazonOrderNumber\x22>" +
      _0x25f250["amazonOrderNumber"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Total\x20Before\x20Tax:</strong>\x20<span\x20id=\x22totalBeforeTax\x22>" +
      _0x25f250["totalBeforeTax"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Total\x20Tax:</strong>\x20<span\x20id=\x22totalTax\x22>" +
      _0x25f250["totalTax"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Estimated\x20Delivery\x20Date:</strong>\x20<span\x20id=\x22estimatedDeliveryDate\x22>" +
      _0x25f250["estimatedDeliveryDate"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Amazon\x20Email:</strong>\x20<span\x20id=\x22amazonEmail\x22>" +
      _0x25f250["amazonEmail"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>fulfillment\x20Date:</strong>\x20<span\x20id=\x22fulfillmentDate\x22>" +
      _0x25f250["fulfillmentDate"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Amazon\x20SKU:</strong>\x20<span\x20id=\x22amazonSku\x22>" +
      _0x25f250["amazonSku"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p><strong>Amazon\x20Domain:</strong>\x20<span\x20id=\x22amazonDomain\x22>" +
      _0x25f250["amazonDomain"] +
      "</span></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20",
    _0x255f43 = document["createElement"]("div");
  ((_0x255f43["innerHTML"] = _0x34d3ad),
    document["querySelector"](".soldPrice")["parentElement"]["parentElement"][
      "appendChild"
    ](_0x255f43));
  var _0x3b55ef = await _0x131a7c();
  _0x485291(
    _0x3b55ef["customer"]["name"],
    _0x25f250["customerAddress"]["split"]("\x0a")[0x0],
    atob(_0x3b55ef["ebaySku"]),
    _0x25f250["amazonSku"],
  );
  var _0x559c85 = _0x26d91d(
    document["querySelector"]("#estimatedDeliveryDate")["innerText"],
  );
  if (_0x559c85)
    (console["log"]("Date\x20found:", _0x559c85), _0x593d59(_0x559c85));
  else console["log"]("No\x20date\x20found");
  var _0x172868 = await _0xbea765(
    _0x3b55ef["orderEarnings"],
    _0x25f250["totalBeforeTax"],
    _0x25f250["totalTax"],
    _0x25f250["amazonDomain"],
  );
  console["log"]("Profit:", _0x172868);
}
function _0x485291(_0x580bcc, _0x1189e8, _0x5b54b1, _0x2fbfbc) {
  (_0x1189e8 !== _0x580bcc &&
    alert(
      "WARNING:\x20Customer\x20name\x20does\x20not\x20match!\x20Please\x20verify\x20the\x20fulfillment\x20details.",
    ),
    _0x5b54b1 !== _0x2fbfbc &&
      alert(
        "WARNING:\x20SKU\x20does\x20not\x20match!\x20Please\x20verify\x20the\x20fulfillment\x20details.",
      ));
}
function _0x26d91d(_0x30d16c) {
  const _0x382d32 = new Date(),
    _0x3e3e77 = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
  function _0x487a29(_0x201f4c, _0x30a2d4) {
    const _0x310842 = new Date(_0x201f4c);
    return (
      _0x310842["setDate"](_0x310842["getDate"]() + _0x30a2d4),
      _0x310842
    );
  }
  function _0x1c9c06(_0x41179c, _0xf7539b) {
    let [_0x5ded44, _0x5d63ea] = _0xf7539b["split"]("\x20"),
      [_0x16ca7d, _0x21eb45] = _0x5ded44["split"](":");
    return (
      "PM" === _0x5d63ea &&
        _0x16ca7d < 0xc &&
        (_0x16ca7d = parseInt(_0x16ca7d) + 0xc),
      _0x41179c["setHours"](_0x16ca7d, _0x21eb45 || 0x0, 0x0, 0x0),
      _0x41179c
    );
  }
  const _0x25a058 = [
    { regex: /Delivered today/, date: new Date(_0x382d32) },
    { regex: /Arriving today/, date: new Date(_0x382d32) },
    { regex: /Arriving tomorrow/, date: _0x487a29(new Date(_0x382d32), 0x1) },
    {
      regex: /Delivered (\w+ \d+)/,
      dateFunction: (_0x5e6a9e) =>
        new Date(_0x5e6a9e[0x1] + ",\x20" + _0x382d32["getFullYear"]()),
    },
    {
      regex: /Arriving (\w+)$/,
      dateFunction: (_0x388ca0) =>
        (function (_0x5231c4, _0x5e19b5) {
          const _0x411be9 = _0x3e3e77["indexOf"](_0x5e19b5),
            _0x43341a = new Date(_0x5231c4);
          return (
            _0x43341a["setDate"](
              _0x43341a["getDate"]() +
                ((0x7 + _0x411be9 - _0x5231c4["getDay"]()) % 0x7),
            ),
            _0x43341a
          );
        })(_0x382d32, _0x388ca0[0x1]),
    },
    {
      regex: /Now expected by (\w+ \d+)/,
      dateFunction: (_0x424b8e) =>
        new Date(_0x424b8e[0x1] + ",\x20" + _0x382d32["getFullYear"]()),
    },
    {
      regex: /Arriving tomorrow by (\d+ [AP]M)/,
      dateFunction: (_0x236a94) =>
        _0x1c9c06(_0x487a29(new Date(_0x382d32), 0x1), _0x236a94[0x1]),
    },
    {
      regex: /Arriving today by (\d+ [AP]M)/,
      dateFunction: (_0x22f02f) =>
        _0x1c9c06(new Date(_0x382d32), _0x22f02f[0x1]),
    },
    {
      regex: /Arriving by (\w+ \d+)/,
      dateFunction: (_0x3b0ff4) =>
        new Date(_0x3b0ff4[0x1] + ",\x20" + _0x382d32["getFullYear"]()),
    },
    {
      regex: /Delivered (\w+ \d+),/,
      dateFunction: (_0x33158e) =>
        new Date(_0x33158e[0x1] + ",\x20" + _0x382d32["getFullYear"]()),
    },
    {
      regex: /Expected by (\w+ \d+)/,
      dateFunction: (_0x1cf809) =>
        new Date(_0x1cf809[0x1] + ",\x20" + _0x382d32["getFullYear"]()),
    },
    {
      regex: /Arriving (\w+, \d+ \w+)/,
      dateFunction: (_0x47172e) =>
        (function (_0x4bdc64) {
          const [_0x4c4664, _0x46d571] = _0x4bdc64["split"](",\x20"),
            [_0x21e41d, _0x3da530] = _0x46d571["split"]("\x20"),
            _0x4a4a73 = [
              "Jan",
              "Feb",
              "Mar",
              "Apr",
              "May",
              "Jun",
              "Jul",
              "Aug",
              "Sep",
              "Oct",
              "Nov",
              "Dec",
            ]["indexOf"](_0x3da530);
          if (-0x1 === _0x4a4a73) return null;
          const _0x245e72 =
            _0x382d32["getMonth"]() > _0x4a4a73
              ? _0x382d32["getFullYear"]() + 0x1
              : _0x382d32["getFullYear"]();
          return new Date(_0x245e72, _0x4a4a73, _0x21e41d);
        })(_0x47172e[0x1]),
    },
  ];
  for (let _0x23c0d0 of _0x25a058) {
    const {
        regex: _0x2444e8,
        date: _0x3d81a8,
        dateFunction: _0x32aedd,
      } = _0x23c0d0,
      _0x201a4b = _0x30d16c["match"](_0x2444e8);
    if (_0x201a4b) return _0x32aedd ? _0x32aedd(_0x201a4b) : _0x3d81a8;
  }
  return null;
}
function _0x593d59(_0x302ea) {
  if (_0x302ea instanceof Date && !isNaN(_0x302ea)) {
    var _0x5874b7 = [
      _0x302ea["getFullYear"](),
      ("0" + (_0x302ea["getMonth"]() + 0x1))["slice"](-0x2),
      ("0" + _0x302ea["getDate"]())["slice"](-0x2),
    ]["join"]("-");
    console["log"]("updateEta:\x20Formatted\x20date", _0x5874b7);
    var _0x38cff7 = document["querySelector"](".amazon-eta-field");
    if (_0x38cff7) {
      if (_0x38cff7["disabled"] || _0x38cff7["readOnly"])
        console["error"](
          "updateEta:\x20.amazon-eta-field\x20is\x20disabled\x20or\x20read-only",
        );
      else
        ((_0x38cff7["value"] = _0x5874b7),
          console["log"]("updateEta:\x20ETA\x20updated\x20successfully"));
    } else
      console["error"](
        "updateEta:\x20.amazon-eta-field\x20element\x20not\x20found",
      );
  } else
    console["error"]("updateEta:\x20Invalid\x20date\x20provided", _0x302ea);
}
const _0x26563d = {
  CAD_TO_USD: 0x1 / 1.3507,
  USD_TO_CAD: 1.3507,
  GBP_TO_USD: 0x1 / 0.789173,
  USD_TO_GBP: 0.789173,
  AUD_TO_USD: 0x1 / 1.64866,
  USD_TO_AUD: 1.64866,
  EUR_TO_USD: 0x1 / 1.0821,
  USD_TO_EUR: 1.0821,
};
function _0x26ded3(_0x4c5fee) {
  let _0x1fed7c = _0x4c5fee["match"](/(C \$|\$|£|A \$|€)/);
  return {
    currencySymbol: _0x1fed7c ? _0x1fed7c[0x0] : null,
    amount: parseFloat(_0x4c5fee["replace"](/[^\d.-]/g, "")),
  };
}
function _0x27fac8(_0x4447e2) {
  switch (_0x4447e2) {
    case "www.amazon.ca":
      return "CAD";
    case "www.amazon.com":
      return "USD";
    case "www.amazon.co.uk":
      return "GBP";
    case "www.amazon.com.au":
      return "AUD";
    case "www.amazon.de":
      return "EUR";
    default:
      return "UNKNOWN";
  }
}
function _0x5c5968(_0x168a3b) {
  return parseFloat(_0x168a3b["replace"](/[^\d.-]/g, ""));
}
async function _0xbea765(_0x431aac, _0x573bfc, _0x562de7, _0xbd0b1) {
  console["log"]("Raw\x20Order\x20Earnings:", _0x431aac);
  var { currencySymbol: _0x38114b, amount: _0x3dfd86 } = _0x26ded3(_0x431aac);
  (console["log"]("Currency\x20Symbol:", _0x38114b),
    console["log"]("Order\x20Earnings:", _0x3dfd86),
    console["log"]("Total\x20Before\x20Tax:", _0x573bfc),
    console["log"]("Total\x20Tax:", _0x562de7),
    console["log"]("Amazon\x20Domain:", _0xbd0b1));
  var _0x205984 = _0x27fac8(_0xbd0b1);
  console["log"]("Domain\x20Currency:", _0x205984);
  if ("UNKNOWN" === _0x205984)
    return (
      console["error"]("Unsupported\x20Amazon\x20domain"),
      "Unsupported\x20domain"
    );
  var _0x4d3eb2 =
    (_0x573bfc = _0x5c5968(_0x573bfc)) + (_0x562de7 = _0x5c5968(_0x562de7));
  console["log"]("Total\x20Cost:", _0x4d3eb2);
  var _0x5d5c55 = _0x4d3eb2;
  let _0xbd1f50 =
    { "C\x20$": "CAD", $: "USD", "£": "GBP", "A\x20$": "AUD", "€": "EUR" }[
      _0x38114b
    ] || "USD";
  console["log"]("Earnings\x20Currency:", _0xbd1f50);
  if (_0xbd1f50 !== _0x205984) {
    let _0x82397c = _0x205984 + "_TO_" + _0xbd1f50,
      _0x783c31 = _0x26563d[_0x82397c] || 0x1;
    ((_0x5d5c55 = _0x4d3eb2 * _0x783c31),
      console["log"]("Conversion\x20Key:", _0x82397c),
      console["log"]("Conversion\x20Rate:", _0x783c31),
      console["log"]("Converted\x20Cost:", _0x5d5c55));
  }
  let _0x51572b = _0x3dfd86 - _0x5d5c55;
  console["log"]("Profit:", _0x51572b);
  let _0x455b37 = "" + _0x38114b + _0x51572b["toFixed"](0x2);
  return (console["log"]("Formatted\x20Profit:", _0x455b37), _0x455b37);
}
async function _0x304d0b() {
  var _0x45e3dc = document["querySelector"](
    ".vod-dialog\x20\x20button.lightbox-dialog__close",
  );
  _0x45e3dc && _0x45e3dc["click"]();
}
async function _0x39e254(_0x37b7f6) {
  var _0x12d374 = document["querySelector"](".edit-note");
  console["log"]("editNoteElement", _0x12d374);
  if (_0x12d374) _0x12d374["click"]();
  else {
    var _0x3a7fc0 = document["querySelector"](
      "[data-action-id=\x22ADD_NOTE\x22]",
    );
    (console["log"]("addNote", _0x3a7fc0), _0x3a7fc0["click"]());
  }
  var _0x2972aa = await _0x13a12a("textarea[name=\x22note-content\x22]");
  ((_0x2972aa["value"] = _0x37b7f6),
    _0x2972aa["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    _0x2972aa["dispatchEvent"](new Event("change", { bubbles: !0x0 })),
    await new Promise((_0x3b2264) => setTimeout(_0x3b2264, 0x3e8)));
  var _0x1793d1 = _0x2972aa["closest"](".lightbox-dialog__window")[
    "querySelector"
  ](".btn.btn--primary");
  (console["log"]("saveButton", _0x1793d1),
    _0x1793d1["dispatchEvent"](new MouseEvent("click", { bubbles: !0x0 })),
    await new Promise((_0x22c7de) => setTimeout(_0x22c7de, 0x3e8)),
    await _0x304d0b());
}
function _0x14355f() {
  var _0x4076a4 = document["createElement"]("button");
  return (
    (_0x4076a4["innerText"] = "Add\x20Note"),
    _0x4076a4["classList"]["add"]("add-note-button"),
    _0x4076a4["addEventListener"]("click", async function () {
      await createAndAppendNote();
    }),
    _0x4076a4
  );
}
async function _0xee2cb1() {
  var _0x1971e5 = _0x1c422c(),
    _0x372adf = await _0x1fd68f(),
    _0x3e47a9 = _0x1971e5 ? _0x1971e5 + "\x0a" + _0x372adf : _0x372adf;
  await _0x39e254(_0x3e47a9);
}
function _0x1c422c() {
  var _0x167cf2 = document["querySelector"](".note-content");
  return _0x167cf2 ? _0x167cf2["innerText"] : null;
}
async function _0x1fd68f() {
  var _0x281187 = document["querySelector"]("#amazonEmail")["innerText"],
    _0x3212ee = document["querySelector"]("#estimatedDeliveryDate")[
      "innerText"
    ],
    _0x5c1c62 = document["querySelector"]("#fulfillmentDate")["innerText"],
    { agentName: _0xe44abc } =
      await chrome["storage"]["local"]["get"]("agentName");
  return (
    "SS/" + _0x281187 + "/" + _0x3212ee + "/" + _0x5c1c62 + "-" + _0xe44abc
  );
}
const _0x1a3547 = (() => {
  let _0x2716fc = null,
    _0x4724e8 = null,
    _0x120d27 = null;
  function _0x38d49() {
    return (
      !_0x2716fc &&
        ((_0x2716fc = document["createElement"]("div")),
        (_0x2716fc["className"] = "sniper-help-popover-portal"),
        _0x2716fc["setAttribute"]("hidden", ""),
        document["body"]["appendChild"](_0x2716fc),
        _0x2716fc["addEventListener"]("mouseenter", () => {
          _0x120d27 && (clearTimeout(_0x120d27), (_0x120d27 = null));
        }),
        _0x2716fc["addEventListener"]("mouseleave", () => _0x2f9cb8(0x78)),
        _0x2716fc["addEventListener"]("click", (_0x3c045c) =>
          _0x3c045c["stopPropagation"](),
        )),
      _0x2716fc
    );
  }
  function _0x1b6bf5(_0x1e182e) {
    const _0x43ead9 = _0x38d49(),
      _0x5cc0e8 = _0x1e182e["getBoundingClientRect"](),
      _0x34e944 = window["innerWidth"],
      _0x34a56d = window["innerHeight"];
    ((_0x43ead9["style"]["visibility"] = "hidden"),
      _0x43ead9["removeAttribute"]("hidden"));
    const _0x23f443 = _0x43ead9["offsetWidth"],
      _0x1d6bce = _0x43ead9["offsetHeight"];
    let _0x32d842 = Math["min"](
        Math["max"](_0x5cc0e8["left"], 0x8),
        _0x34e944 - _0x23f443 - 0x8,
      ),
      _0x547d13 = _0x5cc0e8["bottom"] + 0x8;
    (_0x547d13 + _0x1d6bce > _0x34a56d - 0x8 &&
      (_0x547d13 = Math["max"](_0x5cc0e8["top"] - 0x8 - _0x1d6bce, 0x8)),
      _0x32d842 + _0x23f443 > _0x34e944 - 0x8 &&
        (_0x32d842 = _0x34e944 - _0x23f443 - 0x8),
      _0x32d842 < 0x8 && (_0x32d842 = 0x8),
      (_0x43ead9["style"]["left"] = _0x32d842 + "px"),
      (_0x43ead9["style"]["top"] = _0x547d13 + "px"),
      (_0x43ead9["style"]["visibility"] = "visible"));
  }
  function _0x2dc3a5(_0x36aa55, _0x2012d6) {
    (_0x120d27 && (clearTimeout(_0x120d27), (_0x120d27 = null)),
      (_0x38d49()["textContent"] = String(_0x2012d6 || "")),
      (_0x4724e8 = _0x36aa55),
      _0x1b6bf5(_0x36aa55),
      document["addEventListener"]("click", _0x429223, !0x0),
      document["addEventListener"]("keydown", _0x57402e, !0x0),
      window["addEventListener"]("scroll", _0x36d2bc, !0x0),
      window["addEventListener"]("resize", _0x36d2bc));
  }
  function _0x547df6() {
    (_0x38d49()["setAttribute"]("hidden", ""),
      (_0x4724e8 = null),
      document["removeEventListener"]("click", _0x429223, !0x0),
      document["removeEventListener"]("keydown", _0x57402e, !0x0),
      window["removeEventListener"]("scroll", _0x36d2bc, !0x0),
      window["removeEventListener"]("resize", _0x36d2bc));
  }
  function _0x2ba8fd(_0x4bacbc, _0x2a188c) {
    _0x4724e8 === _0x4bacbc ? _0x547df6() : _0x2dc3a5(_0x4bacbc, _0x2a188c);
  }
  function _0x2f9cb8(_0x244d41) {
    _0x120d27 = setTimeout(_0x547df6, _0x244d41);
  }
  function _0x429223(_0x1913dd) {
    const _0x119676 = _0x38d49();
    _0x4724e8 &&
      (_0x4724e8["contains"](_0x1913dd["target"]) ||
        _0x119676["contains"](_0x1913dd["target"]) ||
        _0x547df6());
  }
  function _0x57402e(_0x3ecf22) {
    "Escape" === _0x3ecf22["key"] && _0x547df6();
  }
  function _0x36d2bc() {
    _0x4724e8 && _0x1b6bf5(_0x4724e8);
  }
  return {
    makeIcon(_0x1a9b75) {
      const _0x4e0367 = document["createElement"]("span");
      return (
        (_0x4e0367["className"] = "sniper-help-icon"),
        (_0x4e0367["tabIndex"] = 0x0),
        _0x4e0367["setAttribute"]("role", "button"),
        _0x4e0367["setAttribute"]("aria-label", "More\x20info"),
        (_0x4e0367["textContent"] = "i"),
        _0x4e0367["addEventListener"]("click", (_0x75bd66) => {
          (_0x75bd66["stopPropagation"](), _0x2ba8fd(_0x4e0367, _0x1a9b75));
        }),
        _0x4e0367["addEventListener"]("mouseenter", () =>
          _0x2dc3a5(_0x4e0367, _0x1a9b75),
        ),
        _0x4e0367["addEventListener"]("mouseleave", () => _0x2f9cb8(0x78)),
        _0x4e0367["addEventListener"]("keydown", (_0x134df0) => {
          ("Enter" === _0x134df0["key"] || "\x20" === _0x134df0["key"]) &&
            (_0x134df0["preventDefault"](), _0x2ba8fd(_0x4e0367, _0x1a9b75));
        }),
        _0x4e0367
      );
    },
  };
})();
async function _0x21f9ca() {
  var _0x168360 = [
    {
      key: "shouldGetLinkInstead",
      type: "checkbox",
      label: "Copy\x20Auto\x20Link\x20instead\x20of\x20Auto\x20Order",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
      help: "Copies\x20a\x20special\x20Amazon\x20checkout\x20link\x20with\x20your\x20order\x20details\x20so\x20you\x20can\x20place\x20the\x20order\x20from\x20another\x20Chrome\x20profile/device.\x20That\x20other\x20browser\x20must\x20have\x20EcomSniper\x20installed.\x20Tip:\x20set\x20the\x20Amazon\x20email\x20in\x20that\x20profile’s\x20Options\x20→\x20Order\x20Settings\x20so\x20EcomSniper\x20can\x20attribute/track\x20the\x20order\x20to\x20the\x20right\x20Amazon\x20account.\x20No\x20auto\x20order\x20happens\x20in\x20this\x20browser.",
    },
    {
      key: "shouldUseGiftOption",
      type: "checkbox",
      label: "Checkout\x20as\x20Gift",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Uses\x20Amazon’s\x20gift\x20checkout\x20option.\x20This\x20hides\x20the\x20item\x20price\x20and\x20lets\x20you\x20include\x20your\x20own\x20Gift\x20Message.",
    },
    {
      key: "giftMessage",
      type: "textarea",
      label: "Gift\x20Message",
      defaultValue: "-",
      includeInOrderDetails: !0x0,
      help: "Text\x20shown\x20on\x20Amazon’s\x20gift\x20slip\x20when\x20you\x20use\x20‘Checkout\x20as\x20Gift’.",
    },
    {
      key: "giftMessageSender",
      type: "text",
      label: "Gift\x20Message\x20Sender",
      defaultValue: "-",
      includeInOrderDetails: !0x0,
      help: "Name\x20shown\x20as\x20the\x20sender\x20on\x20the\x20gift\x20slip.",
    },
    {
      key: "autoConfirmPurchase",
      type: "checkbox",
      label: "Place\x20order\x20automatically\x20(skip\x20final\x20click)",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Automatically\x20places\x20the\x20order\x20on\x20Amazon’s\x20final\x20review\x20page,\x20skipping\x20the\x20last\x20manual\x20click.\x20Make\x20sure\x20your\x20payment\x20details\x20are\x20correct\x20in\x20Amazon\x20beforehand.",
    },
    {
      key: "sendToSpreadsheet",
      type: "checkbox",
      label: "Auto\x20Bookkeeping\x20(Spreadsheet)",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Automatically\x20logs\x20each\x20order\x20into\x20your\x20connected\x20EcomSniper\x20bookkeeping\x20spreadsheet.\x20Saves\x20all\x20sales,\x20fees,\x20costs,\x20and\x20profit\x20data\x20—\x20no\x20more\x20manual\x20entry.",
    },
    {
      key: "shouldSendETAWithAI",
      type: "checkbox",
      label: "Send\x20ETA\x20message\x20(AI)",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
      help: "Generates\x20a\x20short,\x20friendly\x20delivery\x20update\x20and\x20sends\x20it\x20to\x20the\x20buyer\x20on\x20eBay.\x20Language\x20is\x20inferred\x20from\x20the\x20site/country.\x20You\x20can\x20customize\x20the\x20tone/prompt\x20in\x20Options\x20→\x20Order\x20Settings.",
    },
    {
      key: "shouldMarkAsShipped",
      type: "checkbox",
      label: "Mark\x20eBay\x20order\x20as\x20shipped\x20automatically",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
    },
    {
      key: "shouldIncreaseQuantity",
      type: "checkbox",
      label: "Increase\x20quantity\x20of\x20eBay\x20order\x20automatically",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
    },
    {
      key: "shouldWriteNote",
      type: "checkbox",
      label: "Write\x20note\x20on\x20eBay\x20order",
      defaultValue: !0x1,
      includeInOrderDetails: !0x1,
      help: "Adds\x20a\x20note\x20to\x20the\x20eBay\x20order\x20(e.g.,\x20Amazon\x20email,\x20ETA,\x20date,\x20your\x20agent\x20name).\x20You\x20can\x20switch\x20to\x20a\x20custom\x20template\x20in\x20Options\x20→\x20Custom\x20Note\x20Template;\x20tokens\x20like\x20{{amazonEmail}},\x20{{eta}},\x20{{date}},\x20{{agent}}\x20are\x20supported.",
    },
    {
      key: "autoCloseAmazonTabAfterOrder",
      type: "checkbox",
      label: "Auto-close\x20Amazon\x20tab\x20after\x20order",
      defaultValue: !0x1,
      includeInOrderDetails: !0x0,
      help: "Closes\x20the\x20Amazon\x20tab\x20a\x20few\x20seconds\x20after\x20the\x20order\x20completes—useful\x20for\x20multi-tasking\x20or\x20if\x20you\x20place\x20many\x20orders\x20at\x20once.",
    },
    {
      key: "agentName",
      type: "text",
      label: "Your\x20Name\x20(for\x20notes)",
      defaultValue: "Agent",
      includeInOrderDetails: !0x1,
      help: "Used\x20in\x20eBay\x20order\x20notes\x20(e.g.,\x20“–\x20Aug\x2029,\x202025\x20Sammy”).\x20Useful\x20if\x20you\x20have\x20VAs\x20or\x20team\x20members\x20placing\x20orders.",
    },
  ];
  function _0x37c7be() {
    var _0x5ab198 = {};
    for (var _0x14a094 = 0x0; _0x14a094 < _0x168360["length"]; _0x14a094++) {
      var _0x3dd7e4 = _0x168360[_0x14a094];
      _0x5ab198[_0x3dd7e4["key"]] = _0x3dd7e4["defaultValue"];
    }
    return _0x5ab198;
  }
  var _0x14dbc2 = {
      currentValues: _0x37c7be(),
      loadFromChromeStorage: async function () {
        var _0x110fb7 = _0x37c7be(),
          _0x21b358 = await chrome["storage"]["local"]["get"](_0x110fb7);
        for (var _0xffb339 in _0x110fb7)
          Object["prototype"]["hasOwnProperty"]["call"](_0x21b358, _0xffb339) &&
            (this["currentValues"][_0xffb339] = _0x21b358[_0xffb339]);
        return (_0x33212b(), this["getSnapshot"]());
      },
      saveSingleSettingToChromeStorage: async function (_0x27f253, _0x46b186) {
        this["currentValues"][_0x27f253] = _0x46b186;
        var _0x101b0d = {};
        ((_0x101b0d[_0x27f253] = _0x46b186),
          await chrome["storage"]["local"]["set"](_0x101b0d),
          _0x33212b());
      },
      getSnapshot: function () {
        return JSON["parse"](JSON["stringify"](this["currentValues"]));
      },
    },
    _0x2be3f7 = [];
  function _0x33212b() {
    var _0x288b0c = _0x14dbc2["getSnapshot"]();
    _0x2be3f7["forEach"](function (_0x5f8d90) {
      try {
        _0x5f8d90(_0x288b0c);
      } catch (_0x2c1023) {}
    });
  }
  function _0x3d771d(_0xdcdb49, _0x596f16) {
    for (var _0x405715 = 0x0; _0x405715 < _0x168360["length"]; _0x405715++) {
      var _0x429f73 = _0x168360[_0x405715];
      if (_0x429f73["includeInOrderDetails"]) {
        var _0x1aa34b = _0x429f73["key"];
        _0xdcdb49[_0x429f73["orderDetailsKey"] || _0x429f73["key"]] =
          _0x596f16[_0x1aa34b];
      }
    }
    return _0xdcdb49;
  }
  await _0x14dbc2["loadFromChromeStorage"]();
  var _0x5a1453 = document["createElement"]("div");
  _0x5a1453["className"] = "auto-order-container";
  var _0x6eed4d = (function (_0x5dd8a2) {
      var _0x1c7559 = document["createElement"]("button");
      return (
        (_0x1c7559["className"] = "auto-order-button"),
        (_0x1c7559["id"] = "autoOrderButton"),
        (_0x1c7559["textContent"] = _0x5dd8a2["shouldGetLinkInstead"]
          ? "Copy\x20Auto\x20Link"
          : "Auto\x20Order"),
        _0x2be3f7["push"](function (_0x4aafc5) {
          _0x1c7559["textContent"] = _0x4aafc5["shouldGetLinkInstead"]
            ? "Copy\x20Auto\x20Link"
            : "Auto\x20Order";
        }),
        _0x1c7559["addEventListener"]("click", async function (_0x29a0b1) {
          (_0x29a0b1["preventDefault"](), (_0x1c7559["disabled"] = !0x0));
          try {
            var _0x53c7cb = _0x14dbc2["getSnapshot"]();
            if (_0x53c7cb["shouldGetLinkInstead"]) {
              var _0x5459fb = await _0x3bc7ff();
              if (!_0x5459fb) {
                alert(
                  "SKU\x20not\x20found.\x20Please\x20enter\x20the\x20SKU\x20manually.",
                );
                return;
              }
              var _0x4c80aa = await _0x492821(_0x5459fb),
                _0x5b8ab7 = await _0x131a7c();
              (_0x3d771d(_0x5b8ab7, _0x53c7cb),
                (_0x4c80aa =
                  _0x4c80aa +
                  "?autoOrder=true&orderDetails=" +
                  encodeURIComponent(JSON["stringify"](_0x5b8ab7))),
                await navigator["clipboard"]["writeText"](_0x4c80aa),
                _0x1c7559["classList"]["add"](
                  "amazon-copy-link-button-clicked",
                ),
                setTimeout(function () {
                  _0x1c7559["classList"]["remove"](
                    "amazon-copy-link-button-clicked",
                  );
                }, 0x4b0),
                _0x53c7cb["sendToSpreadsheet"] && (await _0x405a50(_0x5b8ab7)),
                _0x1c7559["dispatchEvent"](
                  new CustomEvent("order:done", {
                    detail: {
                      ok: !0x0,
                      profit: document["querySelector"](
                        ".profit-final\x20.value-visible",
                      )?.["innerText"],
                    },
                  }),
                ));
            } else {
              var _0x3608e2 = await _0x131a7c();
              (_0x3d771d(_0x3608e2, _0x53c7cb),
                await _0x5222ad(_0x3608e2),
                _0x53c7cb["sendToSpreadsheet"] && (await _0x405a50(_0x3608e2)),
                _0x1c7559["dispatchEvent"](
                  new CustomEvent("order:done", {
                    detail: {
                      ok: !0x0,
                      profit: document["querySelector"](
                        ".profit-final\x20.value-visible",
                      )?.["innerText"],
                    },
                  }),
                ));
            }
          } catch (_0x1dbdb0) {
            (console["error"]("Auto\x20order\x20action\x20error:", _0x1dbdb0),
              _0x1c7559["dispatchEvent"](
                new CustomEvent("order:done", { detail: { ok: !0x1 } }),
              ));
          } finally {
            _0x1c7559["disabled"] = !0x1;
          }
        }),
        _0x1c7559
      );
    })(_0x14dbc2["getSnapshot"]()),
    _0x2c589e = (function () {
      var _0x504ad5 = document["createElement"]("div");
      ((_0x504ad5["className"] = "settings-modal"),
        _0x504ad5["setAttribute"]("hidden", ""));
      var _0xa1dd41 = document["createElement"]("div");
      _0xa1dd41["className"] = "settings-modal-content";
      var _0x452517 = document["createElement"]("span");
      return (
        (_0x452517["className"] = "settings-modal-close"),
        (_0x452517["textContent"] = "×"),
        _0x452517["addEventListener"]("click", function () {
          _0x504ad5["setAttribute"]("hidden", "");
        }),
        _0xa1dd41["appendChild"](_0x452517),
        _0x504ad5["appendChild"](_0xa1dd41),
        _0x504ad5["addEventListener"]("click", function (_0x7baaa6) {
          _0x7baaa6["target"] === _0x504ad5 &&
            _0x504ad5["setAttribute"]("hidden", "");
        }),
        { overlay: _0x504ad5, content: _0xa1dd41 }
      );
    })(),
    _0x3605b4 = (function () {
      var _0xfb4e39 = document["createElement"]("div");
      ((_0xfb4e39["style"]["display"] = "grid"),
        (_0xfb4e39["style"]["gridTemplateColumns"] = "1fr"),
        (_0xfb4e39["style"]["rowGap"] = "10px"));
      for (var _0x50b75f = 0x0; _0x50b75f < _0x168360["length"]; _0x50b75f++) {
        var _0x6c12ce = _0x168360[_0x50b75f];
        if ("checkbox" === _0x6c12ce["type"]) {
          var _0x5b8c96 = document["createElement"]("div");
          ((_0x5b8c96["style"]["display"] = "flex"),
            (_0x5b8c96["style"]["alignItems"] = "center"),
            (_0x5b8c96["style"]["gap"] = "8px"));
          var _0x1be5ba = document["createElement"]("label");
          ((_0x1be5ba["style"]["display"] = "inline-flex"),
            (_0x1be5ba["style"]["alignItems"] = "center"),
            (_0x1be5ba["style"]["gap"] = "8px"),
            (_0x1be5ba["style"]["flex"] = "1\x201\x20auto"));
          var _0x5121fa = document["createElement"]("input");
          ((_0x5121fa["type"] = "checkbox"),
            (_0x5121fa["checked"] =
              !!_0x14dbc2["currentValues"][_0x6c12ce["key"]]),
            (function (_0x415691, _0xa83961) {
              _0xa83961["addEventListener"]("change", async function () {
                await _0x14dbc2["saveSingleSettingToChromeStorage"](
                  _0x415691,
                  _0xa83961["checked"],
                );
              });
            })(_0x6c12ce["key"], _0x5121fa));
          var _0x278167 = document["createElement"]("span");
          ((_0x278167["textContent"] = _0x6c12ce["label"]),
            _0x1be5ba["appendChild"](_0x5121fa),
            _0x1be5ba["appendChild"](_0x278167));
          if (_0x6c12ce["help"]) {
            const _0x182127 = _0x1a3547["makeIcon"](_0x6c12ce["help"]);
            ((_0x182127["style"]["marginLeft"] = "2px"),
              _0x5b8c96["appendChild"](_0x1be5ba),
              _0x5b8c96["appendChild"](_0x182127));
          } else _0x5b8c96["appendChild"](_0x1be5ba);
          _0xfb4e39["appendChild"](_0x5b8c96);
        } else {
          if ("text" === _0x6c12ce["type"]) {
            (((_0x3caea9 = document["createElement"]("div"))["style"][
              "display"
            ] = "grid"),
              (_0x3caea9["style"]["rowGap"] = "6px"),
              ((_0x57ebdd = document["createElement"]("div"))["style"][
                "display"
              ] = "flex"),
              (_0x57ebdd["style"]["alignItems"] = "center"),
              (_0x57ebdd["style"]["gap"] = "6px"));
            var _0x35b087 = document["createElement"]("div");
            ((_0x35b087["textContent"] = _0x6c12ce["label"]),
              (_0x35b087["style"]["fontWeight"] = "600"),
              _0x57ebdd["appendChild"](_0x35b087));
            if (_0x6c12ce["help"]) {
              const _0x25adcf = _0x1a3547["makeIcon"](_0x6c12ce["help"]);
              _0x57ebdd["appendChild"](_0x25adcf);
            }
            var _0x11ef69 = document["createElement"]("input");
            ((_0x11ef69["type"] = "text"),
              (_0x11ef69["value"] =
                _0x14dbc2["currentValues"][_0x6c12ce["key"]] || ""),
              _0x6c12ce["placeholder"] &&
                (_0x11ef69["placeholder"] = _0x6c12ce["placeholder"]),
              (_0x11ef69["style"]["width"] = "100%"),
              (function (_0x1032dd, _0x353f0d) {
                _0x353f0d["addEventListener"]("input", async function () {
                  await _0x14dbc2["saveSingleSettingToChromeStorage"](
                    _0x1032dd,
                    _0x353f0d["value"],
                  );
                });
              })(_0x6c12ce["key"], _0x11ef69),
              _0x3caea9["appendChild"](_0x57ebdd),
              _0x3caea9["appendChild"](_0x11ef69),
              _0xfb4e39["appendChild"](_0x3caea9));
          } else {
            if ("textarea" === _0x6c12ce["type"]) {
              var _0x3caea9;
              (((_0x3caea9 = document["createElement"]("div"))["style"][
                "display"
              ] = "grid"),
                (_0x3caea9["style"]["rowGap"] = "6px"));
              var _0x57ebdd;
              (((_0x57ebdd = document["createElement"]("div"))["style"][
                "display"
              ] = "flex"),
                (_0x57ebdd["style"]["alignItems"] = "center"),
                (_0x57ebdd["style"]["gap"] = "6px"));
              var _0x53c9f7 = document["createElement"]("div");
              ((_0x53c9f7["textContent"] = _0x6c12ce["label"]),
                (_0x53c9f7["style"]["fontWeight"] = "600"),
                _0x57ebdd["appendChild"](_0x53c9f7));
              if (_0x6c12ce["help"]) {
                const _0x4e9e75 = _0x1a3547["makeIcon"](_0x6c12ce["help"]);
                _0x57ebdd["appendChild"](_0x4e9e75);
              }
              var _0x242a46 = document["createElement"]("textarea");
              ((_0x242a46["rows"] = _0x6c12ce["rows"] || 0x3),
                (_0x242a46["value"] =
                  _0x14dbc2["currentValues"][_0x6c12ce["key"]] || ""),
                _0x6c12ce["placeholder"] &&
                  (_0x242a46["placeholder"] = _0x6c12ce["placeholder"]),
                (_0x242a46["style"]["width"] = "100%"),
                (function (_0x420385, _0x16b870) {
                  _0x16b870["addEventListener"]("input", async function () {
                    await _0x14dbc2["saveSingleSettingToChromeStorage"](
                      _0x420385,
                      _0x16b870["value"],
                    );
                  });
                })(_0x6c12ce["key"], _0x242a46),
                _0x3caea9["appendChild"](_0x57ebdd),
                _0x3caea9["appendChild"](_0x242a46),
                _0xfb4e39["appendChild"](_0x3caea9));
            }
          }
        }
      }
      return _0xfb4e39;
    })();
  return (
    _0x2c589e["content"]["appendChild"](_0x3605b4),
    _0x5a1453["appendChild"](_0x6eed4d),
    _0x5a1453["appendChild"](
      (function (_0x40a3ac) {
        var _0x4d1fc2 = document["createElement"]("span");
        return (
          (_0x4d1fc2["className"] = "settings-icon"),
          (_0x4d1fc2["textContent"] = "⚙"),
          (_0x4d1fc2["title"] = "Auto\x20Order\x20Settings"),
          _0x4d1fc2["addEventListener"]("click", function (_0x5538d5) {
            (_0x5538d5["preventDefault"](),
              _0x40a3ac["removeAttribute"]("hidden"));
          }),
          _0x4d1fc2
        );
      })(_0x2c589e["overlay"]),
    ),
    _0x5a1453["appendChild"](_0x2c589e["overlay"]),
    _0x5a1453
  );
}
async function _0x5222ad(_0x3c4d53) {
  chrome["runtime"]["sendMessage"]({
    type: "order_item_same_browser",
    orderDetails: _0x3c4d53,
  });
}
function _0x12afa4() {
  return document["querySelector"](".lineItemCardInfo__itemId")[
    "querySelectorAll"
  ](".sh-secondary")[0x1]["innerText"];
}
async function _0x1c21f9(_0xe0cf64) {
  var _0x1f58ce = await new Promise((_0x2bd284) => {
    chrome["runtime"]["sendMessage"](
      { type: "get_sku_from_description", itemNumber: _0xe0cf64 },
      function (_0x1e3ab6) {
        _0x2bd284(_0x1e3ab6);
      },
    );
  });
  return _0x1f58ce?.["sku"];
}
async function _0x1288b5(_0x54ad89, _0x2d8acf, _0x2ccb46) {
  const _0x58781f = {
    spreadsheetId: _0x54ad89,
    range: _0x2d8acf,
    values: _0x2ccb46,
  };
  try {
    const _0x5a74f5 = await fetch(
        "https://script.google.com/macros/s/AKfycbwTOktup4oRvsKGNPtMSwUTNX41Z93HZt_PqFDzzgu0jPysi9Tmmrcs-LPf86z2nc8tnQ/exec",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON["stringify"](_0x58781f),
        },
      ),
      _0x4315ae = await _0x5a74f5["json"]();
    console["log"]("Update\x20result:", _0x4315ae);
  } catch (_0x46bcfb) {
    console["error"]("Error\x20updating\x20sheet:", _0x46bcfb);
  }
}
async function _0x48208e() {
  const _0x33ffbf = document["createElement"]("div");
  _0x33ffbf["classList"]["add"]("utility-buttons");
  var _0x3382db = await _0xd0f970(),
    _0x2ee7d0 = await _0x21f9ca();
  if (_0x3382db) {
    var _0x27ce5e = document["createElement"]("div");
    (_0x27ce5e["classList"]["add"]("automation-div"),
      _0x27ce5e["appendChild"](_0x3382db),
      _0x27ce5e["appendChild"](_0x2ee7d0),
      _0x33ffbf["appendChild"](_0x27ce5e));
  }
  return (_0x33ffbf["appendChild"](_0x276474()), _0x33ffbf);
}
async function _0x405a50(_0x4dffb6) {
  (console["log"]("order\x20details", _0x4dffb6),
    (_0x3efd8f = _0x12a796("autoOrderBtn", 0x4b0, {
      titlePrefix: "Auto\x20Order",
      mount: "body",
      autoShowHud: !0x0,
      fadeOutMs: 0x5dc,
    })),
    (document["title"] = "Auto\x20Order\x20Begins"),
    (document["getElementById"]("autoOrderButton")["disabled"] = !0x0),
    _0x3efd8f["update"]("Ordering..."));
  var _0x27a540 = 0x0,
    _0x2db634 = !0x1,
    _0x9b5d51;
  for (; !_0x2db634 && _0x27a540 < 0x3; ) {
    if (++_0x27a540 > 0x1) {
      _0x3efd8f["update"](
        "Failed\x20to\x20submit\x20order\x20details,\x20retrying\x20(" +
          _0x27a540 +
          "/3)...",
      );
      var _0x42b320 = _0x333086(_0x4dffb6["domain"]);
      ((_0x4dffb6["orderEarningsCurrency"] = _0x42b320),
        (_0x4dffb6["grandTotalCurrency"] = _0x42b320),
        await new Promise((_0x333d71) => setTimeout(_0x333d71, 0x1388)));
    }
    try {
      ((_0x9b5d51 = await _0x42f64d(_0x4dffb6)),
        console["log"]("submissionResponse", _0x9b5d51),
        (_0x2db634 = !0x0));
    } catch (_0x4c4851) {
      console["error"]("Error\x20submitting\x20eBay\x20order:", _0x4c4851);
    }
  }
  (console["log"]("orderDetails:", _0x4dffb6),
    console["log"]("Submission\x20response:", _0x9b5d51));
  if (
    "success" === _0x9b5d51?.["code"] ||
    "duplicate" === _0x9b5d51?.["code"] ||
    "updated" === _0x9b5d51?.["code"] ||
    "created" === _0x9b5d51?.["code"]
  ) {
    var _0x44383b;
    try {
      (_0x3efd8f["update"](
        "Waiting\x20For\x20Amazon\x20Order\x20To\x20Be\x20Placed...",
      ),
        (_0x44383b = await _0x141096(_0x4dffb6["ebayOrderNumber"])),
        _0x3efd8f["update"]("Order\x20Placed!"));
    } catch (_0x46ebfd) {
      (console["error"](
        "Error\x20looking\x20up\x20Amazon\x20order:",
        _0x46ebfd,
      ),
        _0x3efd8f["error"](_0x46ebfd));
      return;
    }
    if (_0x44383b?.["error"]) {
      (_0x3efd8f["error"](_0x44383b?.["error"]),
        console["error"](
          "Error\x20looking\x20up\x20Amazon\x20order:",
          _0x44383b["error"],
        ));
      var _0x411610 = "" + _0x44383b["error"],
        _0x2e00dd = _0x1c422c();
      (_0x2e00dd && (_0x411610 = _0x2e00dd + "\x20-\x20" + _0x411610),
        await _0x39e254(_0x411610));
    } else {
      console["log"]("fullOrderDetails:", _0x44383b);
      var { shouldWriteNote: _0x5252af } = await chrome["storage"]["local"][
        "get"
      ]({ shouldWriteNote: !0x1 });
      if (_0x5252af) {
        _0x3efd8f["update"]("Creating\x20note...");
        var { useCustomNoteTemplate: _0x4858f9 } = await chrome["storage"][
            "local"
          ]["get"]({ useCustomNoteTemplate: !0x1 }),
          _0x89dc71;
        ((_0x89dc71 = _0x4858f9
          ? await _0x11df81(_0x44383b)
          : await _0x339970(_0x44383b)),
          await _0x39e254(_0x89dc71));
      }
      var { shouldSendETAWithAI: _0x14ea75 } = await chrome["storage"]["local"][
        "get"
      ]({ shouldSendETAWithAI: !0x1 });
      if (_0x14ea75) {
        var _0x2f4ed9 = _0x26d91d(_0x44383b["estimatedDeliveryDate"]);
        if (_0x2f4ed9)
          (_0x3efd8f["update"]("ETA:\x20" + _0x2f4ed9),
            console["log"]("Date\x20found:", _0x2f4ed9),
            _0x593d59(_0x2f4ed9),
            _0x3efd8f["update"]("ETA\x20Updated"));
        else console["log"]("No\x20date\x20found");
        _0x3efd8f["update"]("Building\x20ETA\x20message...");
        var { useCustomEtaMessagePrompt: _0x15baa9 } = await chrome["storage"][
            "local"
          ]["get"]({ useCustomEtaMessagePrompt: !0x1 }),
          _0x30ca69;
        if (
          !(_0x30ca69 = _0x15baa9
            ? await _0x321ecd(_0x44383b)
            : await _0x27fe1a(_0x44383b))["ok"]
        ) {
          console["error"]("ETA\x20error:", _0x30ca69["error"]);
          return;
        }
        console["log"]("ETA\x20message:", _0x30ca69["data"]);
        var _0x51429c = _0x30ca69["data"];
        (_0x3efd8f["update"]("Sending\x20ETA\x20to\x20eBay\x20buyer..."),
          await _0x3af588(_0x51429c),
          _0x3efd8f["update"]("ETA\x20Sent"));
      }
      var { shouldMarkAsShipped: _0x14526a } = await chrome["storage"]["local"][
        "get"
      ]({ shouldMarkAsShipped: !0x1 });
      _0x14526a &&
        (_0x3efd8f["update"]("Marking\x20item\x20as\x20shipped..."),
        (await _0xaccd82())
          ? (_0x3efd8f["update"]("Item\x20marked\x20as\x20shipped"),
            await _0x368bf8())
          : (_0x3efd8f["update"](
              "Failed\x20to\x20mark\x20item\x20as\x20shipped",
            ),
            await new Promise((_0x4646ed) => setTimeout(_0x4646ed, 0xbb8))));
      var _0x1ac909 = parseFloat(_0x44383b["orderEarnings"]) || 0x0,
        _0x3a4e4c = parseFloat(_0x44383b["grandTotal"]) || 0x0;
      _0x9bee2d(
        _0x44383b["orderEarningsCurrency"],
        _0x44383b["grandTotalCurrency"],
      ) &&
        (_0x3efd8f["update"](
          "Converting\x20" +
            _0x44383b["grandTotalCurrency"] +
            "\x20to\x20" +
            _0x44383b["orderEarningsCurrency"] +
            "...",
        ),
        (_0x3a4e4c = await _0x2c775d(
          _0x44383b["grandTotal"],
          _0x44383b["grandTotalCurrency"],
          _0x44383b["orderEarningsCurrency"],
        )));
      _0x3efd8f["update"]("Calculating\x20profit...");
      var _0x20d8dd = _0xbea765(_0x1ac909, _0x3a4e4c);
      await _0x170472(_0x20d8dd);
      var { shouldIncreaseQuantity: _0x4154 } = await chrome["storage"][
        "local"
      ]["get"]({ shouldIncreaseQuantity: !0x1 });
      if (_0x4154) {
        _0x3efd8f["update"]("Updating\x20quantity...");
        var _0x11294f = document["querySelector"](
          ".amazon-update-quantity-button",
        );
        (await _0x5f0ed1(_0x11294f, "increase"))["ok"] &&
          _0x3efd8f["update"]("Quantity\x20Increased");
      }
      _0x3efd8f["finish"]("Order\x20placed");
    }
  } else
    (console["error"](
      "Failed\x20to\x20submit\x20eBay\x20order:",
      _0x9b5d51?.["error"],
    ),
      _0x3efd8f["error"]("Failed\x20to\x20submit\x20order\x20details"));
}
function _0x333086(_0x4211e4) {
  switch (_0x4211e4) {
    case "com":
    default:
      return "USD";
    case "co.uk":
      return "GBP";
    case "ca":
      return "CAD";
    case "de":
    case "fr":
    case "it":
    case "es":
    case "nl":
      return "EUR";
    case "com.mx":
      return "MXN";
    case "com.au":
      return "AUD";
    case "se":
      return "SEK";
    case "pl":
      return "PLN";
    case "in":
      return "INR";
  }
}
async function _0x170472(_0x132a7a, _0x1dc61d = {}) {
  try {
    const {
        durationMs: _0xa8f57,
        scrollMs: scrollMs = 0x12c,
        minMs: minMs = 0x64,
        maxMs: maxMs = 0x320,
      } = _0x1dc61d,
      _0x562c9f =
        document["querySelector"](".payment-info\x20.earnings\x20.total") ||
        document["querySelector"](".payment-info\x20.total") ||
        document["querySelector"](".payment-info\x20[class*=\x27total\x27]");
    if (!_0x562c9f)
      return (
        console["warn"]("Order\x20earnings\x20row\x20not\x20found"),
        !0x1
      );
    let _0x5ea86b = document["querySelector"](".profit-inline");
    !_0x5ea86b &&
      ((_0x5ea86b = document["createElement"]("div")),
      (_0x5ea86b["className"] = "profit-inline"),
      (_0x5ea86b["innerHTML"] =
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22label\x22>Profit</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22value\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22value-sign\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22value-int\x22>0</span><span\x20class=\x22value-sep\x22>.</span><span\x20class=\x22value-dec\x22>00</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22profit-inline__halo\x22\x20aria-hidden=\x22true\x22></div>\x0a\x20\x20\x20\x20\x20\x20"),
      _0x562c9f["parentNode"]["insertBefore"](
        _0x5ea86b,
        _0x562c9f["nextSibling"],
      ));
    const _0x5e6f43 = _0x5ea86b["querySelector"](".value-sign"),
      _0xef4f2d = _0x5ea86b["querySelector"](".value-int"),
      _0x50d158 = _0x5ea86b["querySelector"](".value-dec"),
      _0x1691e9 = _0x5ea86b["querySelector"](".value"),
      _0x1ae192 = Number(_0x132a7a) || 0x0,
      _0x523856 = _0x1ae192 < 0x0,
      _0x270da6 = Math["abs"](_0x1ae192);
    (_0x5ea86b["classList"]["toggle"]("profit-inline--neg", _0x523856),
      (_0x5e6f43["textContent"] = _0x523856 ? "-" : ""),
      _0x5ea86b["classList"]["remove"]("profit-final"),
      _0x5ea86b["classList"]["add"]("profit-rolling"),
      _0x1691e9["classList"]["add"]("value-visible"),
      await (async function (_0x31a76f) {
        const _0x4dd5ee = window["scrollY"],
          _0x540496 =
            Math["max"](
              document["documentElement"]["scrollHeight"] -
                window["innerHeight"],
              0x0,
            ) - _0x4dd5ee;
        if (Math["abs"](_0x540496) < 0x6) return;
        const _0x29286a = performance["now"]();
        await new Promise((_0x30cb5b) => {
          const _0x25aa9 = (_0x1cab95) => {
            const _0x1d68dd = Math["min"](
              0x1,
              (_0x1cab95 - _0x29286a) / _0x31a76f,
            );
            window["scrollTo"](
              0x0,
              _0x4dd5ee +
                _0x540496 *
                  ((_0x5e0291 = _0x1d68dd) < 0.5
                    ? 0x2 * _0x5e0291 * _0x5e0291
                    : 0x1 - Math["pow"](-0x2 * _0x5e0291 + 0x2, 0x2) / 0x2),
            );
            var _0x5e0291;
            _0x1d68dd < 0x1 ? requestAnimationFrame(_0x25aa9) : _0x30cb5b();
          };
          requestAnimationFrame(_0x25aa9);
        });
      })(scrollMs),
      _0x5ea86b["scrollIntoView"]({ behavior: "auto", block: "center" }));
    const _0x54b1ae =
      ((_0x3313f9 =
        _0xa8f57 ??
        0x708 + 0x384 * Math["log10"](Math["max"](0xa, _0x270da6 + 0x1))),
      (_0x3ed839 = minMs),
      (_0x2fc80b = maxMs),
      Math["max"](_0x3ed839, Math["min"](_0x2fc80b, _0x3313f9)));
    await (async function (_0x1e7089, _0x5d738b, _0x467bf9) {
      const _0x23f67f = performance["now"]();
      return new Promise((_0x4c7689) => {
        const _0x58fe82 = (_0x3807e9) => {
          const _0x499f2c = _0x3807e9 - _0x23f67f,
            _0xcf7f2b = Math["min"](0x1, _0x499f2c / _0x467bf9),
            _0x2c6d29 = ((_0x59e54f) => _0x59e54f * _0x59e54f * _0x59e54f)(
              _0xcf7f2b,
            );
          (((_0x20f892, _0x30569a) => {
            const _0x44f256 = Math["floor"](_0x20f892),
              _0x29f737 = Math["floor"](0x64 * (_0x20f892 - _0x44f256));
            ((_0xef4f2d["textContent"] = _0x44f256["toLocaleString"]()),
              (_0x50d158["textContent"] = _0x29f737["toString"]()["padStart"](
                0x2,
                "0",
              )),
              _0x5ea86b["style"]["setProperty"](
                "--sniper-intensity",
                (_0x30569a * _0x30569a)["toFixed"](0x3),
              ));
          })(0x0 + (_0x5d738b - 0x0) * _0x2c6d29, _0xcf7f2b),
            _0xcf7f2b < 0x1 ? requestAnimationFrame(_0x58fe82) : _0x4c7689());
        };
        requestAnimationFrame(_0x58fe82);
      });
    })(0x0, _0x270da6, _0x54b1ae);
    const _0x4ec7bb = Math["floor"](_0x270da6),
      _0x14b6a8 = Math["round"](0x64 * (_0x270da6 - _0x4ec7bb));
    return (
      (_0xef4f2d["textContent"] = _0x4ec7bb["toLocaleString"]()),
      (_0x50d158["textContent"] = _0x14b6a8["toString"]()["padStart"](
        0x2,
        "0",
      )),
      _0x5ea86b["classList"]["remove"]("profit-rolling"),
      _0x5ea86b["classList"]["add"]("profit-final"),
      await new Promise((_0x3a81b1) => setTimeout(_0x3a81b1, 0x12c)),
      !0x0
    );
  } catch (_0x3d8f91) {
    return (
      console["error"](
        "Failed\x20to\x20insert\x20profit\x20inline:",
        _0x3d8f91,
      ),
      !0x1
    );
  }
  var _0x3313f9, _0x3ed839, _0x2fc80b;
}
async function _0x321ecd(_0x4b205e) {
  try {
    const { customEtaMessagePrompt: _0x570715 } = await chrome["storage"][
        "local"
      ]["get"]({ customEtaMessagePrompt: "" }),
      _0x41b17b = _0x4b205e?.["customer"]?.["name"] || "",
      _0x53d302 = _0x41b17b ? _0x41b17b["split"]("\x20")[0x0] : "",
      _0x106da8 = _0x4b205e?.["itemName"] ? String(_0x4b205e["itemName"]) : "",
      _0x58d22d = _0x4b205e?.["estimatedDeliveryDate"]
        ? String(_0x4b205e["estimatedDeliveryDate"])
        : "",
      _0x3b8820 = String(_0x570715 || ""),
      _0x139e13 = JSON["stringify"]({
        buyer_first_name: _0x53d302,
        item_name: _0x106da8,
        raw_eta_text: _0x58d22d,
      }),
      _0x4436f2 = await openaiLibrary["requestStructuredField"]({
        system: _0x3b8820,
        user: _0x139e13,
        name: "eta_message",
        type: "string",
        model: "gpt-4o-mini",
      });
    return _0x4436f2 && _0x4436f2["ok"]
      ? { ok: !0x0, data: (_0x4436f2["data"] || "")["trim"]() }
      : {
          ok: !0x1,
          error:
            _0x4436f2?.["error"] ||
            "Failed\x20to\x20build\x20custom\x20ETA\x20message",
        };
  } catch (_0xe1eb48) {
    return { ok: !0x1, error: _0xe1eb48?.["message"] || String(_0xe1eb48) };
  }
}
async function _0x27fe1a(_0x3e7fa5) {
  try {
    var _0x415c3e =
        (_0x3e7fa5 && _0x3e7fa5["customer"] && _0x3e7fa5["customer"]["name"]) ||
        "",
      _0x2b2e0c = _0x415c3e ? _0x415c3e["split"]("\x20")[0x0] : "there",
      _0x46d699 =
        _0x3e7fa5 && _0x3e7fa5["itemName"] ? String(_0x3e7fa5["itemName"]) : "",
      _0x53d21e =
        _0x3e7fa5 && _0x3e7fa5["estimatedDeliveryDate"]
          ? String(_0x3e7fa5["estimatedDeliveryDate"])
          : "",
      _0x52f0c8 =
        "language_code:\x20" +
        (function (_0x1c7f84, _0x1dc459) {
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.de")) return "de";
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.fr")) return "fr";
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.es")) return "es";
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.it")) return "it";
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.com")) return "en";
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.ca")) return "en";
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.co.uk")) return "en";
          if (-0x1 !== _0x1c7f84["indexOf"]("ebay.com.au")) return "en";
          if (_0x1dc459) {
            var _0x267c26 = _0x1dc459["toLowerCase"]();
            if (-0x1 !== _0x267c26["indexOf"]("germany") || "de" === _0x267c26)
              return "de";
            if (-0x1 !== _0x267c26["indexOf"]("france") || "fr" === _0x267c26)
              return "fr";
            if (-0x1 !== _0x267c26["indexOf"]("spain") || "es" === _0x267c26)
              return "es";
            if (-0x1 !== _0x267c26["indexOf"]("italy") || "it" === _0x267c26)
              return "it";
            if (-0x1 !== _0x267c26["indexOf"]("canada") || "ca" === _0x267c26)
              return "en";
            if (
              -0x1 !== _0x267c26["indexOf"]("united\x20kingdom") ||
              "uk" === _0x267c26 ||
              "gb" === _0x267c26
            )
              return "en";
            if (
              -0x1 !== _0x267c26["indexOf"]("australia") ||
              "au" === _0x267c26
            )
              return "en";
            if (
              -0x1 !== _0x267c26["indexOf"]("united\x20states") ||
              "us" === _0x267c26
            )
              return "en";
          }
          return "en";
        })(
          window["location"]["hostname"] || "",
          (_0x3e7fa5 &&
            _0x3e7fa5["customer"] &&
            _0x3e7fa5["customer"]["address"] &&
            _0x3e7fa5["customer"]["address"]["country"]) ||
            "",
        ) +
        "\x0abuyer_first_name:\x20" +
        _0x2b2e0c +
        "\x0aitem_name:\x20" +
        _0x46d699 +
        "\x0araw_eta_text:\x20" +
        _0x53d21e +
        "\x0anotes:\x0a-\x20raw_eta_text\x20can\x20be\x20a\x20date\x20or\x20a\x20phrase\x20like\x20\x27Arriving\x20today\x27\x20or\x20\x27Arriving\x20tomorrow\x27.\x0a-\x20Do\x20not\x20include\x20sender\x20name\x20or\x20store\x20name.\x0a-\x20Keep\x20the\x20tone\x20friendly\x20and\x20brief.\x0a",
      _0x1d94bc = await openaiLibrary["requestStructuredField"]({
        system:
          "You\x20are\x20writing\x20a\x20short,\x20casual,\x20friendly\x20order\x20update\x20for\x20an\x20eBay\x20buyer.\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20Tone\x20rules:\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Write\x20like\x20you\x27re\x20texting\x20a\x20friend,\x20not\x20a\x20customer.\x20Warm,\x20human,\x20and\x20easygoing.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Always\x20thank\x20them\x20for\x20supporting\x20a\x20small\x20family\x20business.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Never\x20apologize,\x20never\x20say\x20sorry.\x20We\x20elevate\x20ourselves,\x20not\x20lower\x20status.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Mention\x20their\x20first\x20name\x20if\x20provided,\x20otherwise\x20use\x20a\x20friendly\x20greeting.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Simplify\x20the\x20product\x20name\x20so\x20it\x20sounds\x20natural.\x20Do\x20not\x20repeat\x20long\x20or\x20clunky\x20catalog\x20titles.\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20State\x20clearly\x20when\x20they\x20can\x20expect\x20the\x20order,\x20using\x20the\x20provided\x20ETA\x20text,\x20but\x20keep\x20it\x20conversational\x20(e.g.,\x20\x22Your\x20treadmill\x20should\x20be\x20at\x20your\x20door\x20tomorrow\x22).\x0a\x20\x20\x20\x20\x20\x20\x20\x20-\x20Keep\x20it\x20short,\x20cheerful,\x20and\x20memorable.\x20No\x20emojis,\x20no\x20signatures,\x20no\x20store\x20names.\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20Your\x20only\x20output\x20is\x20the\x20exact\x20message\x20text\x20to\x20send.\x0a\x20\x20\x20\x20\x20\x20\x20\x20",
        user: _0x52f0c8,
        name: "eta_message",
        type: "string",
        model: "gpt-4o-mini",
      });
    return _0x1d94bc && _0x1d94bc["ok"]
      ? { ok: !0x0, data: _0x1d94bc["data"] }
      : {
          ok: !0x1,
          error:
            _0x1d94bc && _0x1d94bc["error"]
              ? _0x1d94bc["error"]
              : "Failed\x20to\x20build\x20ETA\x20message",
        };
  } catch (_0x5c1ccd) {
    return {
      ok: !0x1,
      error:
        _0x5c1ccd && _0x5c1ccd["message"]
          ? _0x5c1ccd["message"]
          : String(_0x5c1ccd),
    };
  }
}
async function _0x339970(_0x4c9b9f) {
  var { agentName: _0x1b5eb9 } =
      await chrome["storage"]["local"]["get"]("agentName"),
    _0x7e640d = new Date()["toLocaleDateString"](),
    _0x3f98fb = "SS";
  ((_0x3f98fb += "\x20" + _0x4c9b9f["amazonEmail"]),
    (_0x3f98fb += "\x20-\x20ETA:\x20" + _0x4c9b9f["estimatedDeliveryDate"]),
    (_0x3f98fb += "\x20-\x20" + _0x7e640d + "\x20" + _0x1b5eb9));
  var _0x560eca = _0x1c422c();
  return (
    _0x560eca && (_0x3f98fb = _0x560eca + "\x20-\x20" + _0x3f98fb),
    _0x3f98fb
  );
}
async function _0x11df81(_0x3e7e74) {
  const { customNoteTemplate: customNoteTemplate = "" } = await chrome[
      "storage"
    ]["local"]["get"]({ customNoteTemplate: "" }),
    { agentName: agentName = "" } = await chrome["storage"]["local"]["get"]({
      agentName: "",
    });
  let _0x52c71b = (customNoteTemplate ||
    "SS\x20{{amazonEmail}}\x20-\x20#{{amazonOrderNumber}}\x20-\x20ETA:\x20{{eta}}\x20-\x20{{date}}\x20{{agent}}")[
    "trim"
  ]();
  const _0x4e662f = {
    agent: agentName,
    agentname: agentName,
    date: new Date()["toLocaleDateString"]("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }),
    ebayordernumber: _0x3e7e74["ebayOrderNumber"] || "",
    amazonordernumber: _0x3e7e74["amazonOrderNumber"] || "",
    itemname: _0x3e7e74["itemName"] || "",
    quantitysold: _0x3e7e74["quantitySold"] || "",
    customername: _0x3e7e74["customer"]?.["name"] || "",
    customerfirstname:
      (_0x3e7e74["customer"]?.["name"] || "")["split"]("\x20")[0x0] || "",
    customeraddress: _0x3e7e74["customerAddress"] || "",
    customercity: _0x3e7e74["customer"]?.["address"]?.["city"] || "",
    customerstate: _0x3e7e74["customer"]?.["address"]?.["state"] || "",
    customerzip: _0x3e7e74["customer"]?.["address"]?.["zip"] || "",
    customercountry: _0x3e7e74["customer"]?.["address"]?.["country"] || "",
    customerphone: _0x3e7e74["customer"]?.["phone"] || "",
    eta: _0x3e7e74["estimatedDeliveryDate"] || "",
    estimateddeliverydate: _0x3e7e74["estimatedDeliveryDate"] || "",
    fulfillmentdate: _0x3e7e74["fulfillmentDate"] || "",
    trackingnumber: _0x3e7e74["trackingNumber"] || "",
    soldprice: _0x3e7e74["soldPrice"] || "",
    grandtotal: _0x3e7e74["grandTotal"] || "",
    orderearnings: _0x3e7e74["orderEarnings"] || "",
    profit: _0x3e7e74["profit"] || "",
    orderearningscurrency: _0x3e7e74["orderEarningsCurrency"] || "",
    grandtotalcurrency: _0x3e7e74["grandTotalCurrency"] || "",
    domain: _0x3e7e74["domain"] || "",
    ebayusername: _0x3e7e74["ebayUsername"] || "",
    amazonemail: _0x3e7e74["amazonEmail"] || "",
    amazondomain: _0x3e7e74["amazonDomain"] || "",
  };
  _0x52c71b = _0x52c71b["replace"](
    /\{\{\s*([^}]+)\s*\}\}/gi,
    (_0x45f979, _0x245b4e) => {
      const _0x38565d = _0x245b4e["trim"]()["toLowerCase"]();
      return void 0x0 !== _0x4e662f[_0x38565d]
        ? String(_0x4e662f[_0x38565d])
        : "";
    },
  );
  const _0x1e9113 = ("function" == typeof _0x1c422c && _0x1c422c()) || "";
  return (
    _0x1e9113 && (_0x52c71b = _0x1e9113 + "\x20-\x20" + _0x52c71b),
    _0x52c71b["trim"]()
  );
}
async function _0x141096(_0x250d7b, _0x509a94 = 0x493e0, _0x538dd7 = 0x1388) {
  const _0x3b238a = (_0x1d1846) =>
      new Promise((_0x1acfca) => setTimeout(_0x1acfca, _0x1d1846)),
    _0x4f2530 =
      "https://us-central1-ecomsniper-cb046.cloudfunctions.net/app/api/v1/ebayOrders/check/" +
      _0x250d7b,
    _0x37fde3 = Date["now"]() + _0x509a94;
  for (; Date["now"]() < _0x37fde3; ) {
    console["log"]("polling\x20for\x20Amazon\x20order");
    const _0x45beb1 = await fetch(_0x4f2530, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    });
    if (!_0x45beb1["ok"]) return { error: "HTTP\x20" + _0x45beb1["status"] };
    const _0x58ba36 = await _0x45beb1["json"]();
    console["log"]("Amazon\x20order\x20lookup\x20response:", _0x58ba36);
    if (_0x58ba36?.["data"]?.["remarks"]?.["includes"]("ERROR"))
      return { error: _0x58ba36["data"]["remarks"] };
    if (
      _0x58ba36?.["data"]?.["amazonOrderNumber"] ||
      _0x58ba36?.["data"]?.["amazonOrderDetails"]
    )
      return (
        console["log"](
          "Polling\x20for\x20Amazon\x20order\x20was\x20successful",
        ),
        _0x58ba36["data"]
      );
    await _0x3b238a(_0x538dd7);
  }
  return {
    error:
      "Couldn\x27t\x20find\x20the\x20supplier\x20order\x20after\x20checking\x20for\x20a\x20while.",
  };
}
async function _0xaccd82() {
  try {
    const _0x34e5b0 = document["querySelector"](
      "[data-action-id=\x22MARK_SHIPPED\x22]\x20a",
    );
    if (!_0x34e5b0) return !0x1;
    const _0xe0b68e = _0x34e5b0["getAttribute"]("href");
    if (!_0xe0b68e) return !0x1;
    const _0x4c3adf = await fetch(_0xe0b68e, {
        method: "GET",
        credentials: "include",
      }),
      _0x27ad6b = await _0x4c3adf["text"]();
    let _0x339726;
    try {
      _0x339726 = JSON["parse"](_0x27ad6b);
    } catch {
      _0x339726 = null;
    }
    return (
      !(!_0x339726 || "SUCCESS" !== _0x339726["ack"]) ||
      !(
        "string" != typeof _0x27ad6b ||
        !_0x27ad6b["includes"]("Update\x20Shipment\x20operation\x20success")
      )
    );
  } catch (_0x4d5ad5) {
    return (
      console["error"]("❌\x20Error\x20marking\x20as\x20shipped:", _0x4d5ad5),
      !0x1
    );
  }
}
async function _0x368bf8() {
  if (!document["getElementById"]("sniper-power-css")) {
    const _0x222c6d = document["createElement"]("style");
    ((_0x222c6d["id"] = "sniper-power-css"),
      (_0x222c6d["textContent"] =
        "\x0a:root{\x0a\x20\x20--sniper-ink:#0b0f13;\x0a\x20\x20--sniper-sub:#5b626a;\x0a\x20\x20--sniper-card:#ffffff;\x0a\x20\x20--sniper-border:rgba(0,0,0,.08);\x0a\x20\x20--sniper-green:#16a34a;\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20brand\x20accent\x20*/\x0a\x20\x20--sniper-green-rgb:22,163,74;\x0a\x20\x20--sniper-steel-1:#eef1f4;\x0a\x20\x20--sniper-steel-2:#dfe5ea;\x0a}\x0a\x0a/*\x20host\x20prep\x20*/\x0a.sniper-power-host{\x20position:relative\x20!important;\x20overflow:hidden\x20!important;\x20border-radius:12px\x20!important;\x20}\x0a.sniper-mask-all\x20\x20\x20>\x20*:not(.sniper-power-replace){\x20visibility:hidden\x20!important;\x20pointer-events:none\x20!important;\x20}\x0a\x0a/*\x20FULL\x20replacement\x20*/\x0a.sniper-power-replace{\x0a\x20\x20position:absolute;\x20inset:-1px;\x20border-radius:inherit;\x20z-index:5;\x20pointer-events:auto;\x0a\x20\x20background:\x20var(--sniper-card);\x0a\x20\x20box-shadow:\x20inset\x200\x200\x200\x201px\x20var(--sniper-border);\x0a\x20\x20display:grid;\x20grid-template-rows:auto\x201fr;\x20opacity:0;\x0a}\x0a\x0a/*\x20Forged\x20gradient\x20border\x20(power\x20feel)\x20*/\x0a.sniper-power-replace::before{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20inset:-2px;\x20border-radius:inherit;\x20pointer-events:none;\x0a\x20\x20background:\x20linear-gradient(135deg,\x20rgba(var(--sniper-green-rgb),.45),\x20rgba(0,0,0,.0)\x2035%,\x20rgba(0,110,255,.35)\x2065%,\x20rgba(0,0,0,.0));\x0a\x20\x20mask:\x20linear-gradient(#000\x200\x200)\x20content-box,\x20linear-gradient(#000\x200\x200);\x0a\x20\x20-webkit-mask:\x20linear-gradient(#000\x200\x200)\x20content-box,\x20linear-gradient(#000\x200\x200);\x0a\x20\x20padding:2px;\x20-webkit-mask-composite:\x20xor;\x20mask-composite:\x20exclude;\x0a\x20\x20filter:\x20blur(.2px);\x0a\x20\x20opacity:.85;\x0a}\x0a\x0a/*\x20Header:\x20icon\x20+\x20titles\x20*/\x0a.sniper-power-head{\x0a\x20\x20position:relative;\x20display:grid;\x20grid-template-columns:auto\x201fr;\x20align-items:center;\x20column-gap:14px;\x0a\x20\x20padding:18px;\x0a\x20\x20background:\x20linear-gradient(180deg,\x20#fff,\x20#fafbfc);\x0a\x20\x20border-bottom:1px\x20solid\x20var(--sniper-border);\x0a}\x0a\x0a/*\x20Command\x20sweep\x20bar\x20(charges\x20fast,\x20conveys\x20power)\x20*/\x0a.sniper-power-head::after{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20left:0;\x20right:0;\x20top:0;\x20height:3px;\x20pointer-events:none;\x0a\x20\x20background:\x20linear-gradient(90deg,\x20rgba(var(--sniper-green-rgb),.0)\x200%,\x20rgba(var(--sniper-green-rgb),.85)\x2020%,\x20rgba(var(--sniper-green-rgb),.0)\x20100%);\x0a\x20\x20transform-origin:left;\x20transform:\x20scaleX(0);\x0a}\x0a\x0a/*\x20Body\x20*/\x0a.sniper-power-body{\x20padding:16px\x2018px\x2018px;\x20display:flex;\x20flex-wrap:wrap;\x20gap:10px;\x20align-content:start;\x20}\x0a\x0a/*\x20Halo\x20crest\x20check\x20(decisive,\x20not\x20cutesy)\x20*/\x0a.sniper-power-crest{\x0a\x20\x20position:relative;\x20width:46px;\x20height:46px;\x20display:grid;\x20place-items:center;\x0a}\x0a.sniper-power-crest::before{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20inset:-6px;\x20border-radius:999px;\x0a\x20\x20background:\x20radial-gradient(circle\x20at\x2050%\x2050%,\x20rgba(var(--sniper-green-rgb),.35),\x20rgba(var(--sniper-green-rgb),0)\x2060%);\x0a\x20\x20transform:\x20scale(.85);\x20opacity:0;\x0a}\x0a.sniper-power-crest::after{\x0a\x20\x20content:\x22\x22;\x20position:absolute;\x20inset:0;\x20border-radius:999px;\x0a\x20\x20background:\x20conic-gradient(from\x200deg,\x20rgba(var(--sniper-green-rgb),.0),\x20rgba(var(--sniper-green-rgb),.6),\x20rgba(var(--sniper-green-rgb),.0)\x2070%);\x0a\x20\x20filter:\x20blur(10px);\x20opacity:0;\x20transform:\x20rotate(-12deg);\x0a}\x0a.sniper-power-crest\x20.tick{\x0a\x20\x20width:34px;\x20height:34px;\x20border-radius:999px;\x20display:grid;\x20place-items:center;\x0a\x20\x20background:\x20var(--sniper-green);\x20color:#fff;\x20font-weight:900;\x20box-shadow:0\x206px\x2016px\x20rgba(var(--sniper-green-rgb),.35);\x0a}\x0a\x0a/*\x20Titles\x20*/\x0a.sniper-power-title{\x20font:800\x2018px/1.2\x20system-ui,-apple-system,Segoe\x20UI,Roboto,Arial,sans-serif;\x20color:var(--sniper-ink);\x20}\x0a.sniper-power-sub\x20\x20{\x20font:600\x2012px/1.2\x20system-ui,-apple-system,Segoe\x20UI,Roboto,Arial,sans-serif;\x20color:var(--sniper-sub);\x20margin-top:2px;\x20}\x0a\x0a/*\x20Chips\x20*/\x0a.sniper-chip{\x0a\x20\x20display:inline-flex;\x20align-items:center;\x20gap:8px;\x20padding:8px\x2012px;\x20border-radius:999px;\x0a\x20\x20font:700\x2012px/1\x20system-ui,-apple-system,Segoe\x20UI,Roboto,Arial,sans-serif;\x20color:var(--sniper-ink);\x0a\x20\x20background:\x20linear-gradient(180deg,\x20var(--sniper-steel-1),\x20var(--sniper-steel-2));\x0a\x20\x20border:1px\x20solid\x20rgba(0,0,0,.08);\x0a}\x0a.sniper-chip--ok{\x0a\x20\x20background:\x20linear-gradient(180deg,\x20rgba(var(--sniper-green-rgb),.14),\x20rgba(var(--sniper-green-rgb),.10));\x0a\x20\x20border-color:\x20rgba(var(--sniper-green-rgb),.35);\x0a}\x0a\x0a/*\x20Subtle\x20tech\x20grid\x20(barely\x20there,\x20conveys\x20control)\x20*/\x0a.sniper-power-grid{\x0a\x20\x20position:absolute;\x20inset:0;\x20pointer-events:none;\x20opacity:.045;\x0a\x20\x20background:\x0a\x20\x20\x20\x20repeating-linear-gradient(0deg,\x20#000\x200\x201px,\x20transparent\x201px\x2024px),\x0a\x20\x20\x20\x20repeating-linear-gradient(90deg,\x20#000\x200\x201px,\x20transparent\x201px\x2024px);\x0a}\x0a\x0a/*\x20ARM\x20=\x20start\x20the\x20show\x20(we\x20add\x20this\x20after\x20centering)\x20*/\x0a.sniper-armed\x20.sniper-power-replace{\x20animation:\x20power-fade\x20.18s\x20ease-out\x20forwards;\x20}\x0a.sniper-armed\x20.sniper-power-head::after{\x20animation:\x20power-sweep\x20.7s\x20cubic-bezier(.2,.8,.2,1)\x20.05s\x20forwards;\x20}\x0a.sniper-armed\x20.sniper-power-crest::before{\x20animation:\x20halo-pulse\x20.7s\x20ease-out\x20.06s\x20forwards;\x20}\x0a.sniper-armed\x20.sniper-power-crest::after{\x20animation:\x20halo-arc\x201.1s\x20ease-out\x20.08s\x20forwards;\x20}\x0a\x0a/*\x20Animations\x20*/\x0a@keyframes\x20power-fade\x20{\x20from{opacity:0}\x20to{opacity:1}\x20}\x0a@keyframes\x20power-sweep\x20{\x0a\x20\x200%{\x20transform:scaleX(0)\x20}\x0a\x20\x2060%{\x20transform:scaleX(1.06)\x20}\x0a\x20\x20100%{\x20transform:scaleX(1)\x20}\x0a}\x0a@keyframes\x20halo-pulse\x20{\x0a\x20\x200%{\x20opacity:0;\x20transform:scale(.85)\x20}\x0a\x20\x2060%{\x20opacity:1;\x20transform:scale(1.05)\x20}\x0a\x20\x20100%{\x20opacity:.85;\x20transform:scale(1)\x20}\x0a}\x0a@keyframes\x20halo-arc\x20{\x0a\x20\x200%{\x20opacity:0;\x20transform:rotate(-12deg)\x20}\x0a\x20\x20100%{\x20opacity:.85;\x20transform:rotate(0deg)\x20}\x0a}\x0a\x0a/*\x20Reduced\x20motion:\x20keep\x20the\x20authority,\x20skip\x20motion\x20*/\x0a@media\x20(prefers-reduced-motion:reduce){\x0a\x20\x20.sniper-armed\x20.sniper-power-replace,\x0a\x20\x20.sniper-armed\x20.sniper-power-head::after,\x0a\x20\x20.sniper-armed\x20.sniper-power-crest::before,\x0a\x20\x20.sniper-armed\x20.sniper-power-crest::after\x20{\x20animation:none\x20!important;\x20opacity:1\x20!important;\x20transform:none\x20!important;\x20}\x0a}\x0a\x20\x20\x20\x20"),
      document["head"]["appendChild"](_0x222c6d));
  }
  const _0x43e6bf =
    document["querySelector"]("[data-action-id=\x22MARK_SHIPPED\x22]") ||
    document["querySelector"]("[data-action-id=\x22ADD_TRACKING_NUMBER\x22]") ||
    document["querySelector"]("[data-action-id]");
  if (!_0x43e6bf) return !0x1;
  const _0x4216f7 =
    _0x43e6bf["closest"](".status-summary.widget") ||
    _0x43e6bf["closest"](".status-summary") ||
    _0x43e6bf["closest"]("[class*=\x22status-summary\x22]") ||
    _0x43e6bf["closest"](".widget");
  if (!_0x4216f7) return !0x1;
  (_0x4216f7["classList"]["add"]("sniper-power-host", "sniper-mask-all"),
    _0x4216f7["querySelectorAll"]("[data-action-id=\x22MARK_SHIPPED\x22]")[
      "forEach"
    ]((_0x372095) => {
      _0x372095["style"]["display"] = "none";
    }),
    _0x4216f7["querySelector"](".sniper-power-replace")?.["remove"]());
  const _0x43aef6 = document["createElement"]("div");
  return (
    (_0x43aef6["className"] = "sniper-power-replace"),
    (_0x43aef6["innerHTML"] =
      "\x0a\x20\x20\x20\x20<div\x20class=\x22sniper-power-grid\x22\x20aria-hidden=\x22true\x22></div>\x0a\x20\x20\x20\x20<div\x20class=\x22sniper-power-head\x22>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22sniper-power-crest\x22><div\x20class=\x22tick\x22>✔</div></div>\x0a\x20\x20\x20\x20\x20\x20<div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22sniper-power-title\x22>Marked\x20as\x20Shipped</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22sniper-power-sub\x22>Updated\x20by\x20EcomSniper</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20<div\x20class=\x22sniper-power-body\x22>\x0a\x20\x20\x20\x20\x20\x20<span\x20class=\x22sniper-chip\x20sniper-chip--ok\x22>Status:\x20Shipped</span>\x0a\x20\x20\x20\x20\x20\x20<span\x20class=\x22sniper-chip\x22>You\x20can\x20add\x20tracking\x20anytime</span>\x0a\x20\x20\x20\x20</div>\x0a\x20\x20"),
    _0x4216f7["appendChild"](_0x43aef6),
    window["scrollTo"](0x0, 0x0),
    await new Promise((_0x1b29d9) =>
      requestAnimationFrame(() => requestAnimationFrame(_0x1b29d9)),
    ),
    _0x4216f7["scrollIntoView"]({ behavior: "auto", block: "center" }),
    document["documentElement"]["classList"]["add"]("sniper-armed"),
    await new Promise((_0x5b830c) => setTimeout(_0x5b830c, 0x320)),
    !0x0
  );
}
async function _0x3af588(_0x42d914) {
  chrome["runtime"]["sendMessage"]({
    type: "makeTabActive",
    shouldSwitchBack: !0x0,
  });
  function findMessageButton() {
    return document["querySelector"](
      ".order-info\x20.actions\x20.btn--secondary",
    );
  }
  function _0x33df86() {
    var _0x55a7f1 = document["querySelector"](".panel-dialog__close");
    _0x55a7f1 && _0x55a7f1["click"]();
  }
  for (let _0x518ac5 = 0x1; _0x518ac5 <= 0x4; _0x518ac5++)
    try {
      const _0x1aceaa = findMessageButton();
      if (!_0x1aceaa)
        throw new Error(
          "Unable\x20to\x20find\x20\x27Message\x20Buyer\x27\x20button",
        );
      (_0x1aceaa["scrollIntoView"]({ block: "center" }), _0x1aceaa["click"]());
      const _0x47e432 = await iframeUtils["parent"]["waitForIframeReady"](
          ".ordui-m2m-panel__iframe",
          0x4e20,
        ),
        _0x63520b = await iframeUtils["parent"]["askIframe"](
          _0x47e432,
          "send_message_to_buyer",
          { message: _0x42d914 },
          0x4e20,
        );
      return (console["log"]("Iframe\x20reply:", _0x63520b), _0x33df86(), !0x0);
    } catch (_0x5404c4) {
      console["warn"](
        "sendEbayBuyerETA\x20attempt\x20" + _0x518ac5 + "\x20failed:",
        _0x5404c4 && _0x5404c4["message"] ? _0x5404c4["message"] : _0x5404c4,
      );
      if (0x4 === _0x518ac5) throw _0x5404c4;
      (_0x33df86(),
        await new Promise((_0x2685ad) => setTimeout(_0x2685ad, 0x1388)));
    }
}
function _0xbea765(_0x2394c6, _0xedd0e3) {
  function _0x1ff35e(_0x34299e) {
    if (null == _0x34299e) return 0x0;
    return (
      (_0x34299e = _0x34299e["toString"]()["trim"]())["includes"](",") &&
        /,\d{1,2}$/["test"](_0x34299e) &&
        (_0x34299e = (_0x34299e = _0x34299e["replace"](/\./g, ""))["replace"](
          /,/g,
          ".",
        )),
      (_0x34299e = _0x34299e["replace"](/[^0-9.-]/g, "")),
      parseFloat(_0x34299e) || 0x0
    );
  }
  return +(_0x1ff35e(_0x2394c6) - _0x1ff35e(_0xedd0e3))["toFixed"](0x2);
}
function _0x2c775d(_0x4e9181, _0x42e78d, _0x39f7e3) {
  const _0x252634 = {
      CAD_TO_USD: 0.727,
      USD_TO_CAD: 0x1 / 0.727,
      EUR_TO_USD: 1.1712,
      USD_TO_EUR: 0x1 / 1.1712,
      GBP_TO_USD: 1.3,
      USD_TO_GBP: 0x1 / 1.3,
    },
    _0x42cdc1 = (_0x42e78d || "")["trim"]()["toUpperCase"](),
    _0x17bedb = (_0x39f7e3 || "")["trim"]()["toUpperCase"](),
    _0x30ec17 = _0x42cdc1 + "_TO_" + _0x17bedb;
  if (!_0x252634[_0x30ec17])
    return (
      console["warn"](
        "No\x20conversion\x20rate\x20available\x20for\x20" +
          _0x42cdc1 +
          "\x20to\x20" +
          _0x17bedb +
          ".\x20Returning\x20original\x20amount.",
      ),
      Number(_0x4e9181["toFixed"](0x2))
    );
  return Number((_0x4e9181 * _0x252634[_0x30ec17])["toFixed"](0x2));
}
function _0x9bee2d(_0x4ede71, _0x4727a3) {
  const _0x4300ea = (_0x4ede71 || "")["trim"]()["toUpperCase"](),
    _0x38f6ef = (_0x4727a3 || "")["trim"]()["toUpperCase"]();
  return !(!_0x4300ea || !_0x38f6ef) && _0x4300ea !== _0x38f6ef;
}
function _0x5f0ed1(_0x30b974, _0xc4f8 = "increase") {
  return new Promise((_0x2280a0) => {
    (_0x30b974["addEventListener"](
      _0xc4f8 + ":done",
      (_0x28aeda) => _0x2280a0(_0x28aeda["detail"]),
      { once: !0x0 },
    ),
      _0x30b974["click"]());
  });
}
console["log"]("ebay/mesh_order_details/content.js");
var _0x56444b;
chrome["runtime"]["onMessage"]["addListener"](
  function (_0x5338c5, _0x337cb6, _0xe35b3f) {
    if ("order_item_from_ebay_order_details" === _0x5338c5["type"])
      return (
        _0x187192()["then"](() => {
          _0x53bcde()["then"]((_0x16d941) => {
            _0xe35b3f(_0x16d941);
          });
        }),
        !0x0
      );
  },
);
async function _0x53bcde() {
  var _0x4ec5f3 = document["querySelector"]("#autoOrderButton");
  return await _0x5f0ed1(_0x4ec5f3, "order");
}
document["addEventListener"]("DOMContentLoaded", async () => {
  await _0x347a5b();
  var _0x51c9d0 = await _0x124812();
  console["log"]("membership", _0x51c9d0);
  if ("ultimate" != _0x51c9d0) {
    alert(
      "Upgrade\x20to\x20Ultimate\x20Membership\x20to\x20use\x20this\x20feature.",
    );
    return;
  }
  const _0x2b5ce8 = async () => {
    var _0x38c6e2 = _0x293f66();
    if (!_0x38c6e2["querySelector"](".utility-buttons-div")) {
      const _0x1ea8ce = await _0x48208e();
      _0x38c6e2["appendChild"](_0x1ea8ce);
    }
    if (!_0x38c6e2["querySelector"](".eta-div")) {
      const _0x25a731 = _0x1143cb();
      _0x38c6e2["appendChild"](_0x25a731);
    }
    if (!_0x38c6e2["querySelector"](".feedback-div")) {
      const _0x1f16f5 = _0x5ea896();
      _0x38c6e2["appendChild"](_0x1f16f5);
    }
    if (!_0x38c6e2["querySelector"](".action-buttons-div")) {
      const _0x5cca6d = await _0x1181f0();
      _0x38c6e2["appendChild"](_0x5cca6d);
    }
    (_0x56444b && (await _0x34d86e(_0x56444b)), await _0x59dacd());
  };
  (_0x2b5ce8(),
    new MutationObserver((_0x170758, _0x584b59) => {
      let _0xa36b3b = !0x1;
      for (let _0x148bac of _0x170758)
        if (_0x148bac["removedNodes"]["length"]) {
          _0xa36b3b = !0x0;
          break;
        }
      _0xa36b3b &&
        (_0x584b59["disconnect"](),
        _0x2b5ce8(),
        _0x584b59["observe"](_0x293f66(), { childList: !0x0 }));
    })["observe"](_0x293f66(), { childList: !0x0 }));
});
function _0x1143cb() {
  const _0x5b8185 = document["createElement"]("div");
  return (
    (_0x5b8185["id"] = "ETA-div"),
    _0x5b8185["appendChild"](_0xd839ca()),
    _0x5b8185["appendChild"](_0x268bfe()),
    _0x5b8185
  );
}
function _0x5ea896() {
  const _0x83c149 = document["createElement"]("div");
  return (
    (_0x83c149["id"] = "feedback-div"),
    _0x83c149["appendChild"](_0x482772()),
    _0x83c149["appendChild"](_0x1087a7()),
    _0x83c149
  );
}
async function _0x1181f0() {
  const _0x352a5d = document["createElement"]("div");
  _0x352a5d["classList"]["add"]("action-buttons-container");
  const _0x5187ad = document["createElement"]("div");
  _0x5187ad["classList"]["add"]("action-buttons-row");
  const _0x173e3c = document["createElement"]("label");
  ((_0x173e3c["textContent"] = "Regular\x20Clipboard:"),
    _0x173e3c["classList"]["add"]("clipboard-label"),
    _0x5187ad["appendChild"](_0x173e3c),
    _0x5187ad["appendChild"](
      _0x2471d3(
        "icons/note.png",
        "shipped-note",
        "Click\x20here\x20to\x20add\x20shipped\x20note",
        _0xee2cb1,
        0x0,
      ),
    ),
    _0x5187ad["appendChild"](
      _0x2471d3(
        "icons/ebayUpload2.png",
        "Write\x20To\x20Sheets\x20in\x20EcomSniper",
        "Click\x20here\x20to\x20submit\x20order\x20details\x20to\x20EcomSniper",
        _0x94da9d,
        0x0,
      ),
    ),
    _0x5187ad["appendChild"](
      _0x2471d3(
        "icons/arrowUp.png",
        "copy-order-details",
        "Click\x20here\x20to\x20copy\x20order\x20details\x20to\x20your\x20Clipboard",
        () => _0x22bbc1(),
        0x0,
      ),
    ),
    _0x5187ad["appendChild"](
      _0x2471d3(
        "icons/arrowDown.png",
        "amazon-import",
        "Click\x20here\x20to\x20bring\x20Amazon\x20Order\x20Details\x20To\x20Ebay",
        () => _0x4071ee(),
        0x0,
      ),
    ),
    _0x352a5d["appendChild"](_0x5187ad),
    _0x352a5d["appendChild"](document["createElement"]("br")));
  const { virtualClipboard1Key: _0x5db36b } = await chrome["storage"]["local"][
      "get"
    ]("virtualClipboard1Key"),
    { virtualClipboard2Key: _0x164ec2 } = await chrome["storage"]["local"][
      "get"
    ]("virtualClipboard2Key");
  if (_0x5db36b) {
    const _0xf5e138 = document["createElement"]("div");
    (_0xf5e138["classList"]["add"]("clipboard-buttons-row"),
      _0xf5e138["appendChild"](
        _0x55849b("Virtual\x20Clipboard\x201:", _0x5db36b, "clipboard-label"),
      ),
      _0xf5e138["appendChild"](
        _0x2471d3(
          "icons/copy.png",
          "copy-order-details",
          "Click\x20here\x20to\x20copy\x20order\x20details\x20to\x20your\x20Virtual\x20Clipboard",
          () => _0x22bbc1(!0x0, _0x5db36b),
          0x1,
        ),
      ),
      _0xf5e138["appendChild"](
        _0x2471d3(
          "icons/clipboard.png",
          "amazon-import",
          "Click\x20here\x20to\x20bring\x20Amazon\x20Order\x20Details\x20To\x20Ebay",
          () => _0x4071ee(!0x0, _0x5db36b),
          0x1,
        ),
      ),
      _0x352a5d["appendChild"](_0xf5e138));
  }
  if (_0x164ec2) {
    const _0x567194 = document["createElement"]("div");
    (_0x567194["classList"]["add"]("clipboard-buttons-row"),
      _0x567194["appendChild"](
        _0x55849b("Virtual\x20Clipboard\x202:", _0x164ec2, "clipboard-label"),
      ),
      _0x567194["appendChild"](
        _0x2471d3(
          "icons/copy.png",
          "copy-order-details",
          "Click\x20here\x20to\x20copy\x20order\x20details\x20to\x20your\x20Virtual\x20Clipboard",
          () => _0x22bbc1(!0x0, _0x164ec2),
          0x2,
        ),
      ),
      _0x567194["appendChild"](
        _0x2471d3(
          "icons/clipboard.png",
          "amazon-import",
          "Click\x20here\x20to\x20bring\x20Amazon\x20Order\x20Details\x20To\x20Ebay",
          () => _0x4071ee(!0x0, _0x164ec2),
          0x2,
        ),
      ),
      _0x352a5d["appendChild"](_0x567194));
  }
  return _0x352a5d;
}
function _0x55849b(_0x3fada6, _0x4b4f20, _0x389282) {
  const _0x1313ef = document["createElement"]("label");
  return (
    _0x1313ef["classList"]["add"](_0x389282),
    (_0x1313ef["innerHTML"] =
      _0x3fada6 +
      "<br><span\x20class=\x27clipboard-key\x27>" +
      _0x4b4f20 +
      "</span>"),
    _0x1313ef
  );
}
