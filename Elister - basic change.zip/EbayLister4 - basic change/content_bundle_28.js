function _0x5d17bb() {
  return new Promise((_0x4ec4e3) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x4ec4e3();
      });
    });
  });
}
function _0x421420() {
  return new Promise((_0x274d3e) => {
    requestIdleCallback(() => {
      _0x274d3e();
    });
  });
}
function _0x3e3659(_0x1bcdaf = 0x3e8) {
  return new Promise((_0x25c77f, _0x410391) => {
    let _0x534622,
      _0x27ab81 = Date["now"](),
      _0x538513 = !0x1;
    function _0x2d9a22() {
      if (Date["now"]() - _0x27ab81 > _0x1bcdaf)
        (_0x538513 && _0x534622["disconnect"](), _0x25c77f());
      else setTimeout(_0x2d9a22, _0x1bcdaf);
    }
    const _0x1c7084 = () => {
        _0x27ab81 = Date["now"]();
      },
      _0x797323 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x534622 = new MutationObserver(_0x1c7084)),
        _0x534622["observe"](document["body"], _0x797323),
        (_0x538513 = !0x0),
        setTimeout(_0x2d9a22, _0x1bcdaf));
    else
      window["onload"] = () => {
        ((_0x534622 = new MutationObserver(_0x1c7084)),
          _0x534622["observe"](document["body"], _0x797323),
          (_0x538513 = !0x0),
          setTimeout(_0x2d9a22, _0x1bcdaf));
      };
  });
}
async function _0x47e85a() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x3e3659(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x34cf2f(
  _0x401040 = null,
  _0x27264c = null,
  _0x1b4157 = null,
  _0x9d3d84 = null,
) {
  var _0x2e6d23 = document["createElement"]("a");
  (_0x2e6d23["setAttribute"]("class", "a-link-text"),
    _0x2e6d23["classList"]["add"]("icon"),
    _0x2e6d23["classList"]["add"]("amazonSearchLink"),
    _0x2e6d23["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x263142 = document["createElement"]("img");
  return (
    _0x263142["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x263142["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2e6d23["appendChild"](_0x263142),
    _0x2e6d23["addEventListener"]("click", async function (_0x403058) {
      (_0x403058["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x401040) {
        var _0x443b47 = _0x213a1b(_0x403058);
        if (!_0x443b47) return;
        var _0x5bed55 = extractItemData(_0x443b47);
        ((_0x401040 = _0x5bed55["title"])["endsWith"]("...") &&
          (_0x401040 = _0x401040["substring"](
            0x0,
            _0x401040["lastIndexOf"]("\x20"),
          )),
          _0x401040["length"] > 0x4b &&
            (_0x401040 = _0x401040["substring"](
              0x0,
              _0x401040["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x33f425 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x33f425),
        _0x33f425 || (_0x33f425 = "reviews"),
        console["log"]("amazonSortType", _0x33f425),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0xf3e54c } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x401040["length"] > 0x50; )
        _0x401040 = _0x401040["substring"](
          0x0,
          _0x401040["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x157578 } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x4420f8 = _0x401040;
      "keywords" == _0x157578 && (_0x4420f8 = await _0x45619a(_0x401040));
      try {
        _0x5bed55 = extractItemData(_0x443b47);
      } catch (_0x537af1) {
        console["log"]("error", _0x537af1);
      }
      (_0x5bed55 ||
        (_0x5bed55 = {
          title: _0x401040,
          price: _0x27264c,
          itemNumber: _0x1b4157,
          image: _0x9d3d84,
        }),
        console["log"]("itemData", _0x5bed55),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x4420f8,
          options: { isTabActive: !0x0, sort: _0x33f425 },
          itemData: _0x5bed55,
        }));
    }),
    _0x2e6d23
  );
}
function _0x429c85(_0x4fea8a) {
  var _0xe8d603 = document["createElement"]("a");
  (_0xe8d603["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0xe8d603["setAttribute"]("class", "a-link-text"),
    _0xe8d603["classList"]["add"]("icon"),
    _0xe8d603["classList"]["add"]("amazonSearchLink"),
    _0xe8d603["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x274427 = document["createElement"]("img");
  return (
    _0x274427["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x274427["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xe8d603["appendChild"](_0x274427),
    _0xe8d603["addEventListener"]("click", async function (_0x3258bd) {
      (_0x3258bd["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x4fea8a),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x4fea8a,
        }));
    }),
    _0xe8d603
  );
}
function openAmazonSkuButton(_0x3ae8a9) {
  var _0x34eb6b = document["createElement"]("a");
  (_0x34eb6b["setAttribute"]("id", "amazonLink"),
    _0x34eb6b["setAttribute"]("class", "a-link-text"),
    _0x34eb6b["classList"]["add"]("icon"),
    _0x34eb6b["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x4763a7 = document["createElement"]("img");
  return (
    _0x4763a7["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4763a7["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x34eb6b["appendChild"](_0x4763a7),
    _0x34eb6b["addEventListener"]("click", async function (_0x47ceff) {
      (_0x47ceff["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x11022c } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x189b67 =
          "https://www.amazon." +
          _0x11022c +
          "/dp/" +
          _0x3ae8a9 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x189b67 });
    }),
    _0x34eb6b
  );
}
function _0x396733(openAmazonItem) {
  var _0x477fc2 = document["createElement"]("a");
  (_0x477fc2["setAttribute"]("id", "amazonLink"),
    _0x477fc2["setAttribute"]("class", "a-link-text"),
    _0x477fc2["classList"]["add"]("icon"),
    _0x477fc2["classList"]["add"]("amazonLink"),
    _0x477fc2["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x47c375 = document["createElement"]("img");
  return (
    _0x47c375["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x47c375["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x477fc2["appendChild"](_0x47c375),
    _0x477fc2["addEventListener"]("click", async function (_0xb3d68d) {
      (_0xb3d68d["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        openAmazonItem(_0xb3d68d);
      } catch (_0x371a7c) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x371a7c);
      }
    }),
    _0x477fc2
  );
}
function _0xc41625(
  _0x5f1ccf = null,
  _0x318aa3,
  _0x448d87 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x5f1ccf, _0x318aa3);
  var _0x3ec3b7 = document["createElement"]("a");
  (_0x3ec3b7["setAttribute"]("id", "ebayLink"),
    _0x3ec3b7["setAttribute"]("class", "a-link-text"),
    _0x3ec3b7["classList"]["add"]("icon"),
    _0x318aa3 && _0x318aa3["soldItems"]
      ? _0x3ec3b7["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x3ec3b7["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x425b13 = document["createElement"]("img");
  return (
    _0x425b13["setAttribute"]("src", chrome["runtime"]["getURL"](_0x448d87)),
    _0x425b13["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3ec3b7["appendChild"](_0x425b13),
    _0x3ec3b7["addEventListener"]("click", async function (_0x50a777) {
      (_0x50a777["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x5f1ccf) console["log"]("title\x20found", _0x5f1ccf);
      else {
        console["log"]("title\x20not\x20found");
        var _0x3c8be6 = _0x213a1b(_0x50a777);
        if (!_0x3c8be6) return;
        var _0xce13ff = extractItemData(_0x3c8be6);
        _0x5f1ccf = _0xce13ff["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x522158 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x5f1ccf["length"] > 0x50; )
        _0x5f1ccf = _0x5f1ccf["substring"](
          0x0,
          _0x5f1ccf["lastIndexOf"]("\x20"),
        );
      var _0x5a5fec =
        "https://www.ebay." +
        _0x522158 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x5f1ccf) +
        "&_odkw=" +
        encodeURIComponent(_0x5f1ccf);
      (_0x318aa3 && _0x318aa3["soldItems"] && (_0x5a5fec += "&LH_Sold=1"),
        _0x318aa3 && _0x318aa3["sortLowToHigh"] && (_0x5a5fec += "&_sop=15"),
        _0x318aa3 && _0x318aa3["endedRecently"] && (_0x5a5fec += "&_sop=13"),
        (_0x5a5fec += "&LH_ItemCondition=1000"),
        (_0x5a5fec += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x5a5fec,
        }));
    }),
    _0x3ec3b7
  );
}
function _0x7c9e54(_0x1fcf0b = null) {
  var _0x28b1ba = document["createElement"]("a");
  (_0x28b1ba["setAttribute"]("id", "googleLink"),
    _0x28b1ba["setAttribute"]("class", "a-link-text"),
    _0x28b1ba["classList"]["add"]("icon"),
    _0x28b1ba["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x2ca791 = document["createElement"]("img");
  return (
    _0x2ca791["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x2ca791["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x28b1ba["appendChild"](_0x2ca791),
    _0x28b1ba["addEventListener"]("click", async function (_0x216eed) {
      (_0x216eed["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x1fcf0b) {
        var _0xb79831 = _0x213a1b(_0x216eed);
        if (!_0xb79831) return;
        var _0x10e072 = extractItemData(_0xb79831);
        _0x1fcf0b = _0x10e072["image"];
      }
      var { domain: _0x487a4a } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x413f69(_0x487a4a),
        encodeURIComponent(_0x1fcf0b),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x1fcf0b,
        }));
    }),
    _0x28b1ba
  );
}
function _0x208019(_0x3927e1 = null) {
  var _0x21d188 = document["createElement"]("a");
  (_0x21d188["setAttribute"]("id", "googleLink"),
    _0x21d188["setAttribute"]("class", "a-link-text"),
    _0x21d188["classList"]["add"]("icon"),
    _0x21d188["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x27665e = document["createElement"]("img");
  return (
    _0x27665e["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x27665e["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x21d188["appendChild"](_0x27665e),
    _0x21d188["addEventListener"]("click", async function (_0xf57f98) {
      (_0xf57f98["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x3927e1) {
        var _0x4fbd3e = _0x213a1b(_0xf57f98);
        if (!_0x4fbd3e) return;
        var _0x357075 = extractItemData(_0x4fbd3e);
        _0x3927e1 = _0x357075["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x3927e1,
      });
    }),
    _0x21d188
  );
}
function _0xb3ecc7(_0x3c590a) {
  var _0x425689 = document["createElement"]("a");
  (_0x425689["setAttribute"]("id", "lookUpSkuLink"),
    _0x425689["setAttribute"]("class", "a-link-text"),
    _0x425689["classList"]["add"]("icon"),
    _0x425689["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x514f71 = document["createElement"]("img");
  return (
    _0x514f71["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x514f71["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x425689["appendChild"](_0x514f71),
    _0x425689["addEventListener"]("click", async function (_0x21f71c) {
      (_0x21f71c["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x1ffd06 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x5008ea =
          "https://www.amazon." +
          _0x1ffd06 +
          "/dp/" +
          _0x3c590a +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x5008ea,
        options: { active: !0x0 },
      });
    }),
    _0x425689
  );
}
function _0xbff5c7(_0xaeda1f = null) {
  var _0x5ab1c8 = document["createElement"]("a");
  (_0x5ab1c8["setAttribute"]("id", "productHunterLink"),
    _0x5ab1c8["setAttribute"]("class", "a-link-text"),
    _0x5ab1c8["classList"]["add"]("icon"),
    _0x5ab1c8["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x14cda5 = document["createElement"]("img");
  return (
    _0x14cda5["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x14cda5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5ab1c8["appendChild"](_0x14cda5),
    _0x5ab1c8["addEventListener"]("click", async function (_0x2d252d) {
      (_0x2d252d["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0xaeda1f) {
        var _0x5f5293 = _0x213a1b(_0x2d252d);
        if (!_0x5f5293) return;
        var _0x5ad379 = extractItemData(_0x5f5293);
        _0xaeda1f = _0x5ad379["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0xaeda1f),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0xaeda1f,
        }));
    }),
    _0x5ab1c8
  );
}
function _0x413f69(_0x16ccd0) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x16ccd0] || "en-US";
}
function _0x1a9523(_0x3912fc = null) {
  console["log"]("createSearchTerapeakButton", _0x3912fc);
  var _0x359a18 = document["createElement"]("a");
  (_0x359a18["setAttribute"]("class", "a-link-text"),
    _0x359a18["classList"]["add"]("terapeakLink"),
    _0x359a18["classList"]["add"]("icon"),
    _0x359a18["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x3912fc && _0x359a18["setAttribute"]("item_title", _0x3912fc));
  var _0x1a3ff2 = document["createElement"]("img");
  return (
    _0x1a3ff2["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x1a3ff2["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x359a18["appendChild"](_0x1a3ff2),
    _0x359a18["addEventListener"]("click", async function (_0x134d20) {
      (_0x134d20["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x338cd4 = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x338cd4),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x338cd4) {
        var _0x17db63 = _0x213a1b(_0x134d20);
        if (!_0x17db63) return;
        _0x338cd4 = extractItemData(_0x17db63)["title"];
      }
      console["log"]("title", _0x338cd4);
      var { convertToKeywords: _0x1c20a9 } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x1c20a9) var _0x338cd4 = await _0x45619a(_0x338cd4);
      var { domain: _0x3ceab4 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x46378b = _0x32be69(_0x338cd4, _0x3ceab4);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x46378b });
    }),
    _0x359a18
  );
}
async function _0x45619a(_0x5aae39) {
  var _0x4fcf47 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x47ed1d) => _0x47ed1d["json"]());
  ((_0x4fcf47["user_input"] = _0x5aae39),
    console["log"]("jsonPrompt", _0x4fcf47));
  var _0x453e50 = await new Promise((_0x10aa11, _0x3b400e) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x4fcf47,
      },
      function (_0x435c7e) {
        _0x10aa11(_0x435c7e["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x453e50),
    (_0x453e50 = JSON["parse"](_0x453e50))["output"]
  );
}
function _0x32be69(
  _0x15d46b,
  _0x199c5a = "ca",
  _0x181e2e = 0x1e,
  _0x1507b2 = 0x0,
  _0x3d8466 = 0x0,
  _0x5c7eb2 = 0x32,
  _0x726994 = "-itemssold",
  _0x4883c6 = "SOLD",
  _0x1581a1 = "EBAY-CA",
  _0x1de541 = "America/Toronto",
  _0x3380ec = "BuyerLocation:::CA",
  _0x2ccc41 = 0x0,
) {
  _0x1581a1 = "";
  switch (_0x199c5a) {
    case "ca":
    default:
      _0x1581a1 = "EBAY-CA";
      break;
    case "com":
      _0x1581a1 = "EBAY-US";
      break;
    case "co.uk":
      _0x1581a1 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x199c5a +
    "/sh/research?" +
    [
      "keywords=" + _0x15d46b,
      "dayRange=" + _0x181e2e,
      "categoryId=" + _0x1507b2,
      "offset=" + _0x3d8466,
      "limit=" + _0x5c7eb2,
      "sorting=" + _0x726994,
      "tabName=" + _0x4883c6,
      "marketplace=" + _0x1581a1,
      "tz=" + encodeURIComponent(_0x1de541),
      "minPrice=" + _0x2ccc41,
    ]["join"]("&")
  );
}
async function openSellerItemsPage(_0xa11d90) {
  var { domain: _0x4b3a59 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x431f40 =
      "https://www.ebay." +
      _0x4b3a59 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0xa11d90 +
      "&store_name=" +
      _0xa11d90 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x431f40 });
}
async function openItemPageThenSellerItemsPage(_0x3c25e9) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x3c25e9,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x3c25e9));
}
async function openItemPageThenGetSeller(_0x51b98f) {
  var { response: _0x4452b6 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x51b98f,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x4452b6), _0x4452b6);
}
function _0x46d281(_0x17fd89 = null) {
  console["log"]("createOpenSellerItemsButton", _0x17fd89);
  var _0x2464b5 = document["createElement"]("a");
  (_0x2464b5["setAttribute"]("id", "sellerItemsLink"),
    _0x2464b5["setAttribute"]("class", "a-link-text"),
    _0x2464b5["classList"]["add"]("icon"),
    _0x2464b5["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x323ddf = document["createElement"]("img");
  return (
    _0x323ddf["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x323ddf["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2464b5["appendChild"](_0x323ddf),
    _0x2464b5["addEventListener"]("click", async function (_0xc6998e) {
      (_0xc6998e["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x17fd89),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x17fd89));
      var _0x5b96f7;
      if (!_0x17fd89) {
        console["log"]("username\x20not\x20found");
        var _0x52664c = _0x213a1b(_0xc6998e);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x52664c,
        );
        if (!_0x52664c) return;
        var _0x34c303 = extractItemData(_0x52664c);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x34c303,
        ),
          (_0x17fd89 = _0x34c303["username"]),
          (_0x5b96f7 = _0x34c303["itemNumber"]));
      }
      if (
        _0x17fd89["includes"]("\x20") ||
        _0x17fd89 !== _0x17fd89["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x17fd89,
        );
        if (!_0x5b96f7) {
          if (!(_0x52664c = _0x213a1b(_0xc6998e))) return;
          _0x5b96f7 = (_0x34c303 = extractItemData(_0x52664c))["itemNumber"];
        }
        openItemPageThenSellerItemsPage(_0x5b96f7);
      } else
        ((_0x17fd89 = _0x17fd89["toLowerCase"]()),
          console["log"]("username", _0x17fd89),
          openSellerItemsPage(_0x17fd89));
    }),
    _0x2464b5
  );
}
function _0x5842e6(_0x3d602a) {
  for (
    ;
    _0x3d602a &&
    !_0x3d602a["classList"]["contains"]("s-item") &&
    !_0x3d602a["classList"]["contains"]("su-card-container");

  )
    _0x3d602a = _0x3d602a["parentElement"];
  return _0x3d602a;
}
function _0x3d6652(_0x1e8aca = null) {
  var _0x190e45 = document["createElement"]("a");
  (_0x190e45["setAttribute"]("id", "purchaseHistoryLink"),
    _0x190e45["setAttribute"]("class", "a-link-text"),
    _0x190e45["classList"]["add"]("icon"),
    _0x190e45["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x2a7b4b = document["createElement"]("img");
  return (
    _0x2a7b4b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x2a7b4b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x190e45["appendChild"](_0x2a7b4b),
    _0x190e45["addEventListener"]("click", async function (_0x51c343) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x1e8aca),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x51c343["preventDefault"]());
      var _0x190dc0 = _0x213a1b(_0x51c343);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x190dc0,
      );
      if (_0x190dc0) {
        var { selectedFilter: _0x4810eb } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x4810eb &&
          ((_0x4810eb = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x4810eb,
          }));
        var _0x3f6fad = _0x4810eb,
          _0x3ae3cc = await checkPurchaseHistoryAndAddToItem(
            _0x190dc0,
            _0x3f6fad,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x3ae3cc);
      } else
        try {
          var _0x5de7db = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x1e8aca,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x5de7db),
            (_0x3ae3cc = _0x5de7db["totalSold"]));
        } catch (_0x2a586e) {
          (console["log"]("error", _0x2a586e), (_0x3ae3cc = -0x3e7));
        }
    }),
    _0x190e45
  );
}
function _0x213a1b(_0x3440ca) {
  var _0x1d5ac3 = _0x3440ca["target"];
  return (
    (_0x1d5ac3 = _0x5842e6(_0x1d5ac3)),
    console["log"]("found\x20s-item", _0x1d5ac3),
    _0x1d5ac3
  );
}
function _0x434689(_0x1f5c49 = null, _0x31a0b9 = null, _0x3a60fc = null) {
  var _0x4786fa = document["createElement"]("a");
  (_0x4786fa["setAttribute"]("id", "copyDataLink"),
    _0x4786fa["setAttribute"]("class", "a-link-text"),
    _0x4786fa["classList"]["add"]("icon"),
    _0x4786fa["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x2b32c0 = document["createElement"]("img");
  return (
    _0x2b32c0["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x2b32c0["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4786fa["appendChild"](_0x2b32c0),
    _0x4786fa["addEventListener"]("click", async function (_0x2af755) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x1f5c49,
        _0x31a0b9,
        _0x3a60fc,
      ),
        _0x2af755["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x1f5c49 && _0x31a0b9 && _0x3a60fc)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x1f5c49,
          _0x31a0b9,
          _0x3a60fc,
        ),
          isNaN(_0x31a0b9) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x31a0b9),
            (_0x31a0b9 = _0x31a0b9["replace"](/[^0-9.]/g, ""))),
          _0x3357f4(
            JSON["stringify"]({
              title: _0x1f5c49,
              price: _0x31a0b9,
              itemNumber: _0x3a60fc,
            }),
          ));
      else {
        if (!_0x1f5c49 || !_0x31a0b9 || !_0x3a60fc) {
          var _0x453bb4 = _0x213a1b(_0x2af755);
          if (!_0x453bb4) return;
        }
        var _0x42438a = extractItemData(_0x453bb4);
        (console["log"]("itemData", _0x42438a),
          _0x3357f4(JSON["stringify"](_0x42438a)));
      }
    }),
    _0x4786fa
  );
}
function _0x3357f4(_0x4ad464) {
  var _0x2f5482 = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x2f5482),
    (_0x2f5482["value"] = _0x4ad464),
    _0x2f5482["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x2f5482));
}
async function _0x1ddf3e(_0x239127 = null) {
  console["log"]("price", _0x239127);
  if (_0x239127) {
    try {
      _0x239127 = _0x239127["replace"](/[^0-9.]/g, "");
    } catch (_0x4a12b8) {}
    _0x239127 = parseFloat(_0x239127);
  }
  var _0xc5e013 = await _0x2587d6(_0x239127),
    _0x215748 = document["createElement"]("div");
  return (
    _0x215748["setAttribute"]("id", "breakEvenPrice"),
    _0x215748["setAttribute"]("class", "break-even-price"),
    (_0x215748["textContent"] =
      "Break-even\x20price:\x20$" + _0xc5e013["toFixed"](0x2)),
    _0x215748
  );
}
async function _0x3caea2(_0x262d37) {
  var _0x5d6b01 = !0x1,
    _0x790189 = !0x1,
    { includeCurrencyConversion: _0x790189 } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x5d6b01 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x1dcf82 =
    0.1325 * _0x262d37 +
    0.021 * _0x262d37 +
    _0x262d37 * (_0x5d6b01 ? 0.004 : 0x0) +
    0.4;
  return (_0x790189 && (_0x1dcf82 += 0.035 * _0x262d37), _0x262d37 - _0x1dcf82);
}
async function _0x2587d6(_0xcfd47b) {
  var { isInternational: _0x17d4d9 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x5f3fd5 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x17d4d9 || (_0x17d4d9 = !0x1), _0x5f3fd5 || (_0x5f3fd5 = !0x0));
  var _0x1a9e36 = 13.25;
  _0x5f3fd5 && (_0x1a9e36 = 12.35);
  var _0xb3bda6 = _0xcfd47b + 0.0725 * _0xcfd47b,
    _0x1ca59f =
      _0xb3bda6 * (_0x1a9e36 / 0x64) +
      0.4 +
      (_0x17d4d9 ? 0.004 * _0xb3bda6 : 0x0),
    _0x4ca5f7 =
      _0xcfd47b -
      (_0x1ca59f + (_0x17d4d9 ? 0.05 * _0x1ca59f : 0x0)) -
      (_0x17d4d9 ? 0.035 * _0xb3bda6 : 0x0),
    { isUserTaxExempt: _0x3458c8 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x3458c8 || (_0x3458c8 = !0x1),
    _0x3458c8 || (_0x4ca5f7 /= 1.0725),
    _0x17d4d9 && (_0x4ca5f7 -= (3.5 * _0x4ca5f7) / 0x64),
    _0x4ca5f7
  );
}
function _0xe1324f(_0x2569bb = null) {
  console["log"]("createButtonToSaveSeller", _0x2569bb);
  var _0x2e6e58 = document["createElement"]("a");
  (_0x2e6e58["setAttribute"]("id", "saveSellerLink"),
    _0x2e6e58["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x2e6e58["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x103c62 = document["createElement"]("img");
  return (
    _0x103c62["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x103c62["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2e6e58["appendChild"](_0x103c62),
    _0x2e6e58["addEventListener"]("click", async function (_0x4eaf37) {
      (_0x4eaf37["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x2569bb));
      var _0x59d18e;
      if (!_0x2569bb) {
        var _0x209596 = _0x213a1b(_0x4eaf37);
        if (!_0x209596) return;
        var _0x4ea3a7 = extractItemData(_0x209596);
        ((_0x2569bb = _0x4ea3a7["username"]),
          (_0x59d18e = _0x4ea3a7["itemNumber"]));
      }
      if (
        _0x2569bb["includes"]("\x20") ||
        _0x2569bb !== _0x2569bb["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x2569bb,
        ),
          (_0x2569bb = await openItemPageThenGetSeller(_0x59d18e)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x2569bb,
          ));
      else _0x2569bb = _0x2569bb["toLowerCase"]();
      _0x2e6e58["setAttribute"]("data-seller-name", _0x2569bb);
      var { ebayCompetitors: _0x1a96da } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0xba1bff = (_0x1a96da = _0x1a96da || [])["indexOf"](_0x2569bb);
      console["log"]("ebayCompetitors", _0x1a96da);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0xba1bff
            ? (console["log"]("save-seller\x20clicked\x20username", _0x2569bb),
              _0x1a96da["push"](_0x2569bb),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x103c62["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x2569bb,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x103c62["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0xba1bff)
            (console["log"]("remove-seller\x20clicked\x20username", _0x2569bb),
              _0x1a96da["splice"](_0xba1bff, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x103c62["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x2569bb,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x1a96da });
    }),
    _0x2e6e58
  );
}
async function _0x1bd36a(_0x1c6fb8, _0x1af896) {
  var { ebayCompetitors: _0x1e58af } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x45a658 = (_0x1e58af = _0x1e58af || [])["indexOf"](_0x1af896),
    _0x42362a = _0x1c6fb8["querySelector"]("img");
  -0x1 !== _0x45a658
    ? (_0x1c6fb8["classList"]["replace"]("save-seller", "remove-seller"),
      _0x42362a["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x1c6fb8["classList"]["replace"]("remove-seller", "save-seller"),
      _0x42362a["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x231b53(
  _0x387a0b = null,
  _0x2be3ca = null,
  _0x4b8c0b = null,
  _0x355782 = !0x0,
  _0x1fb4b4 = null,
  _0x5595b3 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x387a0b));
  var _0x62db03 = _0xe1324f(_0x2be3ca),
    _0x365564 = _0x1a9523(_0x387a0b),
    _0x199158 = _0x3d6652(_0x1fb4b4),
    _0x722daf = _0xc41625(_0x387a0b),
    _0x128c23 = _0x34cf2f(_0x387a0b, _0x5595b3, _0x1fb4b4, _0x4b8c0b),
    _0x1ce00f = _0xc41625(
      _0x387a0b,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x30458e = _0x7c9e54(_0x4b8c0b),
    _0x2a7092 = _0x208019(_0x1fb4b4),
    openSellerItemsButton = _0x46d281(_0x2be3ca),
    _0x13924d = document["createElement"]("div");
  _0x13924d["setAttribute"]("id", "search-div");
  var _0x7e8224 = document["createElement"]("label");
  ((_0x7e8224["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x13924d["appendChild"](_0x7e8224),
    _0x13924d["appendChild"](_0x128c23),
    _0x13924d["appendChild"](_0x722daf),
    _0x13924d["appendChild"](_0x365564),
    _0x13924d["appendChild"](_0x30458e),
    _0x13924d["appendChild"](_0x2a7092),
    _0x13924d["appendChild"](_0x1ce00f),
    console["log"]("CopyDataButton", _0x387a0b, _0x5595b3, _0x1fb4b4));
  var _0x5ed4fa = _0x434689(_0x387a0b, _0x5595b3, _0x1fb4b4),
    _0x38069e = document["createElement"]("div");
  _0x38069e["setAttribute"]("id", "item-buttons-div");
  var _0x1ce4f6 = document["createElement"]("div");
  (_0x1ce4f6["setAttribute"]("id", "main-buttons-div"),
    _0x1ce4f6["appendChild"](openSellerItemsButton),
    _0x1ce4f6["appendChild"](_0x199158),
    _0x1ce4f6["appendChild"](_0x5ed4fa),
    _0x1ce4f6["appendChild"](_0x62db03),
    _0x38069e["appendChild"](_0x1ce4f6));
  if (_0x355782) {
    var _0x88f359 = createButtonListToEbay();
    _0x38069e["appendChild"](_0x88f359);
  }
  return (_0x38069e["appendChild"](_0x13924d), _0x38069e);
}
var _0x3db12 = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x200776) => {
        (console["log"](
          _0x200776,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x3db12, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x5b2751) => {
        (console["log"](
          _0x5b2751,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x3db12, "search-type", "keywords"));
      },
    },
  },
];
async function _0x52f528() {
  var { convertToKeywords: _0x331bc6 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x331bc6 &&
    ((_0x331bc6 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x3db12,
      "search-type",
      _0x331bc6 ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x3db12 })[
      "init"
    ]());
}
var _0x50518f = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x31ac78) => {
        (console["log"](_0x31ac78, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x50518f, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x58b046) => {
        (console["log"](_0x58b046, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x50518f, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0xc983f8) => {
        (console["log"](
          _0xc983f8,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x50518f, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x2c1a20) => {
        (console["log"](
          _0x2c1a20,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x50518f, "search-type", "keywords"));
      },
    },
  },
];
async function _0x5c61bb() {
  var { amazonSortType: _0x56c438 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x5f1574 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x5f1574 &&
    ((_0x5f1574 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x56c438 &&
      ((_0x56c438 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x50518f, "sort-type", _0x56c438),
    updateContextMenu(_0x50518f, "search-type", _0x5f1574),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x50518f })[
      "init"
    ]());
}
_0x50518f = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x4ccb8f) => {
        (console["log"](_0x4ccb8f, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x50518f, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x1ed8f4) => {
        (console["log"](_0x1ed8f4, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x50518f, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0xa92786 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x11e046) => {
        (console["log"](_0x11e046, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0xa92786, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3e79d7) => {
        (console["log"](_0x3e79d7, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0xa92786, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x50fc71) => {
        (console["log"](_0x50fc71, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0xa92786, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2275bf) => {
        (console["log"](_0x2275bf, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0xa92786, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3b9b04) => {
        (console["log"](_0x3b9b04, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0xa92786, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x43fe07) => {
        (console["log"](_0x43fe07, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0xa92786, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5bece2) => {
        (console["log"](_0x5bece2, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0xa92786, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x35fb86) => {
        (console["log"](_0x35fb86, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0xa92786, "filter-type", "90"));
      },
    },
  },
];
async function _0x1e8876() {
  var { selectedFilter: _0x2560d5 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x2560d5 &&
    ((_0x2560d5 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0xa92786, "filter-type", _0x2560d5),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0xa92786 })[
      "init"
    ]());
}
function _0x19648a() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x269aea() {
  const _0x9743eb = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x46f9db = 0x0;
  const _0x4d4be5 = () =>
    new Promise((_0x4f32aa, _0x1b3499) => {
      const _0x40b1f3 = new MutationObserver((_0x39104e, _0x24009d) => {
        const _0x5e27f9 = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x5e27f9 &&
          (console["log"]("Details\x20form\x20found!"),
          _0x24009d["disconnect"](),
          _0x4f32aa(_0x5e27f9));
      });
      (_0x40b1f3["observe"](_0x9743eb, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x40b1f3["disconnect"]();
          if (_0x46f9db < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x46f9db + 0x1) +
                "/3)",
            ),
              _0x46f9db++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x4f32aa(_0x4d4be5()), 0x1388));
          else
            _0x1b3499(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x10fa10 = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x10fa10) {
    (_0x10fa10["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x4d4be5(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x1f12d2) {
      console["error"](_0x1f12d2["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x19a59d(_0x14de3f = null, _0x44c008 = null, _0x66c48 = null) {
  var _0xddd2f0 = document["createElement"]("a");
  (_0xddd2f0["setAttribute"]("id", "copyDataLink"),
    _0xddd2f0["setAttribute"]("class", "a-link-text"),
    _0xddd2f0["classList"]["add"]("icon"),
    _0xddd2f0["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x755e99 = document["createElement"]("img");
  return (
    _0x755e99["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x755e99["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xddd2f0["appendChild"](_0x755e99),
    _0xddd2f0["addEventListener"]("click", async function (_0x3dc73f) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x14de3f,
        _0x44c008,
        _0x66c48,
      ),
        _0x3dc73f["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x14de3f && _0x44c008 && _0x66c48) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x14de3f,
          _0x44c008,
          _0x66c48,
        );
        isNaN(_0x44c008) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x44c008),
          (_0x44c008 = _0x44c008["replace"](/[^0-9.]/g, "")));
        var _0x4b0669 = JSON["stringify"]({
          title: _0x14de3f,
          price: _0x44c008,
          itemNumber: _0x66c48,
        });
        (_0x168ed5(
          (_0x1f54af = await findSimiliarProducts(_0x4b0669))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x1f54af),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x14de3f || !_0x44c008 || !_0x66c48) {
          var _0x552164 = _0x213a1b(_0x3dc73f);
          if (!_0x552164) return;
        }
        var _0xbc3c0a = extractItemData(_0x552164);
        (console["log"]("itemData", _0xbc3c0a),
          (_0x4b0669 = JSON["stringify"](_0xbc3c0a)));
        var _0x1f54af;
        (_0x168ed5(
          (_0x1f54af = await findSimiliarProducts(_0x4b0669))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x1f54af),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0xddd2f0
  );
}
async function findSimiliarProducts(_0x1d0813) {
  console["log"]("findSimiliarProducts", _0x1d0813);
  var _0x46ec78 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x1d0813,
  });
  return (console["log"]("response", _0x46ec78), _0x46ec78["productLinks"]);
}
function _0x168ed5(_0xe6a6fa) {
  const _0x445f1f = document["getElementById"]("productLinksModalOverlay");
  _0x445f1f && _0x445f1f["remove"]();
  const _0x16d244 = document["createElement"]("div");
  ((_0x16d244["id"] = "productLinksModalOverlay"),
    _0x16d244["classList"]["add"]("product-links-modal-overlay"));
  const _0x32e0cb = document["createElement"]("div");
  _0x32e0cb["classList"]["add"]("product-links-modal");
  const _0xf012a3 = document["createElement"]("div");
  _0xf012a3["classList"]["add"]("modal-button-container");
  const _0x1afb62 = document["createElement"]("button");
  (_0x1afb62["classList"]["add"]("close-button"),
    (_0x1afb62["innerText"] = "Close"),
    _0x1afb62["addEventListener"]("click", () => {
      _0x16d244["remove"]();
    }));
  const _0x228068 = document["createElement"]("button");
  (_0x228068["classList"]["add"]("copy-button"),
    (_0x228068["innerText"] = "Copy"),
    _0x228068["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0xe6a6fa),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x4bf1ea) {
        console["error"]("Failed\x20to\x20copy:", _0x4bf1ea);
      }
    }));
  const _0x2552e3 = document["createElement"]("h2");
  _0x2552e3["innerText"] = "Similar\x20Product\x20Links";
  const _0x52fae3 = document["createElement"]("textarea");
  ((_0x52fae3["value"] = _0xe6a6fa),
    _0x52fae3["setAttribute"]("readonly", !0x0),
    (_0x52fae3["style"]["width"] = "100%"),
    (_0x52fae3["style"]["height"] = "300px"),
    _0xf012a3["appendChild"](_0x228068),
    _0xf012a3["appendChild"](_0x1afb62),
    _0x32e0cb["appendChild"](_0xf012a3),
    _0x32e0cb["appendChild"](_0x2552e3),
    _0x32e0cb["appendChild"](_0x52fae3),
    _0x16d244["appendChild"](_0x32e0cb),
    document["body"]["appendChild"](_0x16d244));
}
console["log"]("my_ebay_sold/content.js\x20loaded");
function _0x8616cd() {
  var _0x469567 = document["querySelectorAll"](".item__cta-wrapper\x20a");
  for (let _0xab5d54 = 0x0; _0xab5d54 < _0x469567["length"]; _0xab5d54++) {
    const _0x14f7f6 = _0x469567[_0xab5d54];
    console["log"]("link", _0x14f7f6);
    var _0x3acd9f = new URL(_0x14f7f6["href"]);
    (_0x3acd9f["searchParams"]["delete"]("mode"),
      (_0x14f7f6["href"] = _0x3acd9f),
      (_0x14f7f6["target"] = "_blank"));
  }
}
function _0x1c6b0d() {
  return document["querySelectorAll"](".sold-itemcard");
}
function _0x3bfd17(_0xc9850c) {
  var _0x195cfd = _0xc9850c["querySelector"](".item__itemid")["textContent"];
  return _0x195cfd["split"](":")[0x1]["trim"]();
}
function _0x5dc962(_0x2b8d1f) {
  const _0x5e3152 = _0x2b8d1f["querySelector"](".item__order-number");
  if (_0x5e3152) {
    const _0x382fe7 = _0x5e3152["textContent"]["match"](/Order:\s*([0-9-]+)/i);
    if (_0x382fe7) return _0x382fe7[0x1];
  }
  const _0x3a6557 = _0x2b8d1f["querySelector"](
    "input.checkbox__control[value]",
  );
  return _0x3a6557 && _0x3a6557["value"] ? _0x3a6557["value"]["trim"]() : null;
}
function findOrderDetailsLink(_0x503d30) {
  let _0x3f535a = _0x503d30["querySelector"](
    "a[href*=\x22/mesh/ord/details\x22]",
  );
  if (_0x3f535a) return _0x3f535a["href"];
  _0x3f535a = _0x503d30["querySelector"]("a[href*=\x22/ord/details\x22]");
  if (_0x3f535a) return _0x3f535a["href"];
  const _0x45c50a = _0x5dc962(_0x503d30);
  return _0x45c50a
    ? "https://www.ebay.com/mesh/ord/details?orderid=" +
        encodeURIComponent(_0x45c50a)
    : null;
}
function _0x594a1d(_0x7a27e1) {
  const _0x254fae = document["createElement"]("button");
  return (
    (_0x254fae["textContent"] = "Auto\x20Order"),
    (_0x254fae["className"] = "auto-order-button"),
    Object["assign"](_0x254fae["style"], {
      marginLeft: "10px",
      padding: "5px\x2010px",
      backgroundColor: "#4CAF50",
      color: "white",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
    }),
    _0x254fae["addEventListener"]("click", (_0x4901cc) => {
      (_0x4901cc["preventDefault"](), _0x4901cc["stopPropagation"]());
      const _0x5e7416 = findOrderDetailsLink(
        _0x4901cc["currentTarget"]["closest"](".sold-itemcard") || _0x7a27e1,
      );
      if (_0x5e7416)
        ((_0x254fae["textContent"] = "Ordering..."),
          _0x5634e0(_0x5e7416)["then"]((_0x2cee0e) => {
            (console["log"]("Order\x20Item\x20Response:", _0x2cee0e),
              _0x2cee0e["isOrdered"]
                ? ((_0x254fae["textContent"] =
                    "Ordered!\x20Profit:\x20" + (_0x2cee0e["profit"] || "N/A")),
                  (_0x254fae["disabled"] = !0x0),
                  (_0x254fae["style"]["backgroundColor"] = "#888"))
                : ((_0x254fae["textContent"] = "Failed"),
                  (_0x254fae["style"]["backgroundColor"] = "#f44336"),
                  setTimeout(() => {
                    ((_0x254fae["textContent"] = "Auto\x20Order"),
                      (_0x254fae["style"]["backgroundColor"] = "#4CAF50"));
                  }, 0xbb8)),
              _0x254fae["dispatchEvent"](
                new CustomEvent("order:done", {
                  detail: { ok: !0x0, response: _0x2cee0e },
                }),
              ));
          }));
      else
        console["warn"](
          "Auto\x20Order:\x20could\x20not\x20locate\x20order\x20details\x20link\x20or\x20order\x20id.",
        );
    }),
    _0x254fae
  );
}
async function _0x5634e0(_0x10c400) {
  var _0x4b896a = await new Promise((_0x31ab7a, _0x311784) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "order_item_from_ebay_order_details",
        orderDetailsLink: _0x10c400,
      },
      function (_0x3cfa02) {
        _0x31ab7a(_0x3cfa02);
      },
    );
  });
  console["log"]("orderItem\x20response", _0x4b896a);
  var _0x19dc92 = !!_0x4b896a?.["ok"],
    _0x183190 = _0x4b896a?.["profit"] ?? null;
  return (
    _0x183190 && (_0x183190 = _0x183190["replace"](/[^0-9.,-]/g, "")),
    { isOrdered: _0x19dc92, profit: _0x183190 }
  );
}
function _0x490726() {
  const _0x5aac69 = document["createElement"]("button");
  return (
    (_0x5aac69["textContent"] = "Order\x20Selected\x20Items\x20on\x20Page"),
    (_0x5aac69["className"] = "order-all-items-button"),
    Object["assign"](_0x5aac69["style"], {
      margin: "10px",
      padding: "10px\x2020px",
      backgroundColor: "#008CBA",
      color: "white",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
    }),
    _0x5aac69["addEventListener"]("click", async (_0x2e912f) => {
      (_0x2e912f["preventDefault"](),
        _0x2e912f["stopPropagation"](),
        (_0x5aac69["textContent"] = "Ordering\x20All..."),
        (_0x5aac69["disabled"] = !0x0),
        (_0x5aac69["style"]["backgroundColor"] = "#888"),
        await _0x298173(),
        (_0x5aac69["textContent"] = "Done\x20Ordering"));
    }),
    _0x5aac69
  );
}
async function _0x298173() {
  var _0x4c0e6b = document["querySelectorAll"](
    ".sold-itemcard\x20input[type=\x22checkbox\x22]:checked",
  );
  _0x4c0e6b = Array["from"](_0x4c0e6b)["reverse"]();
  for (let _0xaa3ee8 = 0x0; _0xaa3ee8 < _0x4c0e6b["length"]; _0xaa3ee8++) {
    const _0x435ef4 = _0x4c0e6b[_0xaa3ee8];
    (console["log"]("Processing\x20checkbox", _0x435ef4),
      _0x435ef4["scrollIntoView"]({ behavior: "smooth", block: "center" }),
      await new Promise((_0x7fe5c6) => setTimeout(_0x7fe5c6, 0x3e8)));
    const _0x28f5f0 =
      _0x435ef4["closest"](".sold-itemcard")["querySelector"](
        ".auto-order-button",
      );
    if (_0x28f5f0) {
      var _0x3c95f7 = await _0x5b4753(_0x28f5f0, "order");
      (console["log"]("Result", _0x3c95f7),
        await new Promise((_0x4f9004) => setTimeout(_0x4f9004, 0x1388)));
    } else
      console["warn"](
        "No\x20auto\x20order\x20button\x20found\x20for\x20checked\x20item.",
      );
  }
}
function _0x5b4753(_0x2b5641, _0x1a65be = "increase") {
  return new Promise((_0x14e2ea) => {
    (_0x2b5641["addEventListener"](
      _0x1a65be + ":done",
      (_0x22357f) => _0x14e2ea(_0x22357f["detail"]),
      { once: !0x0 },
    ),
      _0x2b5641["click"]());
  });
}
console["log"]("my_ebay_sold/content.js\x20loaded");
async function _0x2599b6() {
  (await _0x3e3659(), _0x8616cd());
  const _0x39827c = (_0x459bd4, _0xa1ffa = document) =>
      _0xa1ffa["querySelector"](_0x459bd4),
    _0x5593e1 = (_0x451e2a, _0x1b3ce6 = null) => {
      try {
        return _0x451e2a();
      } catch {
        return _0x1b3ce6;
      }
    };
  function _0x12f24a(_0x114438) {
    const _0x6adab = _0x5593e1(() => _0x3bfd17(_0x114438));
    if (!_0x6adab) return;
    const _0x4c36f5 =
      ((_0xea8404 = _0x114438),
      _0x5593e1(
        () => _0xea8404["querySelector"](".item__itemid")?.["parentElement"],
      ) ||
        _0xea8404["querySelector"](".me-item-card-top-bar") ||
        _0xea8404["querySelector"](".meui-item-tile\x20.columns") ||
        _0xea8404);
    var _0xea8404;
    if (!_0x4c36f5) return;
    const _0x219c63 = "es-tools-" + _0x6adab;
    let _0x319ac7 = _0x4c36f5["querySelector"]("#" + CSS["escape"](_0x219c63));
    if (!_0x319ac7) {
      ((_0x319ac7 = document["createElement"]("span")),
        (_0x319ac7["id"] = _0x219c63),
        (_0x319ac7["className"] = "es-toolbar"));
      const _0x3d2c27 = _0x114438["querySelector"](".item__itemid");
      _0x3d2c27 && _0x3d2c27["parentElement"] === _0x4c36f5
        ? _0x3d2c27["insertAdjacentElement"]("afterend", _0x319ac7)
        : _0x4c36f5["appendChild"](_0x319ac7);
    }
    if (!_0x319ac7["querySelector"](".es-btn.es-amz")) {
      const _0x427cf7 = _0x429c85(_0x6adab);
      (_0x427cf7["classList"]["add"]("es-btn", "es-amz"),
        _0x319ac7["appendChild"](_0x427cf7));
    }
    if (!_0x319ac7["querySelector"](".es-btn.es-order")) {
      const _0x3008c6 = _0x594a1d(_0x114438);
      (_0x3008c6["classList"]["add"]("es-btn", "es-order"),
        _0x319ac7["appendChild"](_0x3008c6));
    }
  }
  function _0x4d7602() {
    const _0x5ec296 = _0x1c6b0d();
    for (let _0x936598 = 0x0; _0x936598 < _0x5ec296["length"]; _0x936598++)
      _0x12f24a(_0x5ec296[_0x936598]);
  }
  function _0x4fd13e() {
    const _0xf59eab =
      _0x39827c(".carousel__viewport") ||
      _0x39827c("header") ||
      _0x39827c("#gh-top") ||
      document["body"];
    if (_0xf59eab && !_0xf59eab["querySelector"](".es-btn.es-order-all")) {
      const _0x5251a0 = _0x490726();
      (_0x5251a0["classList"]["add"]("es-btn", "es-order-all"),
        _0xf59eab["appendChild"](_0x5251a0));
    }
  }
  (_0x4d7602(), _0x4fd13e());
  let _0x3cadb0 = !0x1;
  new MutationObserver(() => {
    !_0x3cadb0 &&
      ((_0x3cadb0 = !0x0),
      requestAnimationFrame(() => {
        ((_0x3cadb0 = !0x1), _0x4d7602(), _0x4fd13e());
      }));
  })["observe"](document["body"], { childList: !0x0, subtree: !0x0 });
  if (!document["getElementById"]("es-toolbar-style")) {
    const _0x284e0c = document["createElement"]("style");
    ((_0x284e0c["id"] = "es-toolbar-style"),
      (_0x284e0c["textContent"] =
        "\x0a\x20\x20\x20\x20\x20\x20.es-toolbar\x20{\x20display:inline-flex;\x20gap:8px;\x20margin-left:8px;\x20vertical-align:middle;\x20}\x0a\x20\x20\x20\x20\x20\x20.es-btn\x20{\x20padding:4px\x208px;\x20border:1px\x20solid\x20rgba(0,0,0,.2);\x20border-radius:6px;\x20font:500\x2012px/1.2\x20system-ui,Segoe\x20UI,Roboto,Arial,sans-serif;\x20cursor:pointer;\x20}\x0a\x20\x20\x20\x20\x20\x20.es-btn:hover\x20{\x20filter:\x20brightness(0.95);\x20}\x0a\x20\x20\x20\x20"),
      document["head"]["appendChild"](_0x284e0c));
  }
}
_0x2599b6();
