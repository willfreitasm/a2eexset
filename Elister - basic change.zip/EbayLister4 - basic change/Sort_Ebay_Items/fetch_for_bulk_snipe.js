// Fetch All Filtered Items for Bulk Snipe
document.addEventListener("DOMContentLoaded", function () {
  const fetchButton = document.getElementById("fetch_all_filtered_items");

  if (fetchButton) {
    fetchButton.addEventListener("click", async function () {
      console.log("Fetching all filtered items for bulk snipe...");

      // Disable button during processing
      fetchButton.disabled = true;
      fetchButton.textContent = "Fetching...";

      try {
        const ebayUrls = await fetchAllItemsFromAllPages();

        if (ebayUrls.length === 0) {
          alert(
            "No items found. Please run filters first or make sure items are displayed on the page.",
          );
          return;
        }

        console.log("Total items collected:", ebayUrls.length);

        // Get domain from storage
        chrome.storage.local.get(["domain"], function (result) {
          const domain = result.domain || "com";

          // Store in chrome.storage for bulk_snipe to read
          chrome.storage.local.set(
            {
              bulk_snipe_items: ebayUrls,
              bulk_snipe_auto_load: true,
            },
            function () {
              console.log("Stored", ebayUrls.length, "items for bulk snipe");

              // Open bulk_snipe tool
              const bulkSnipeUrl = chrome.runtime.getURL(
                "bulk_snipe/bulk_snipe_settings.html",
              );
              window.open(bulkSnipeUrl, "_blank");

              // Re-enable button
              fetchButton.disabled = false;
              fetchButton.textContent = "Fetch All for Bulk Snipe";
            },
          );
        });
      } catch (error) {
        console.error("Error fetching items:", error);
        alert("Error: " + error.message);
        fetchButton.disabled = false;
        fetchButton.textContent = "Fetch All for Bulk Snipe";
      }
    });
  }
});

function getDomain() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["domain"], function (result) {
      resolve(result.domain || "com");
    });
  });
}

async function fetchAllItemsFromAllPages() {
  const allUrls = [];
  let currentPage = 1;
  const totalPages = getTotalPages();

  console.log(`Total pages to process: ${totalPages || "Unknown"}`);

  // Get domain once at the start
  const domain = await getDomain();

  // Process current page first
  const urlsFromCurrentPage = extractItemsFromCurrentPage(domain);
  console.log(`Page ${currentPage}: Found ${urlsFromCurrentPage.length} items`);
  allUrls.push(...urlsFromCurrentPage);

  // Process remaining pages
  if (totalPages > 1) {
    for (let page = 2; page <= totalPages; page++) {
      console.log(`Navigating to page ${page}...`);

      // Click next page button
      const nextPageClicked = clickNextPage();
      if (!nextPageClicked) {
        console.log("No more pages or next button not found");
        break;
      }

      // Wait for page to update
      await waitForPageUpdate();

      // Extract items from this page
      const urlsFromPage = extractItemsFromCurrentPage(domain);
      console.log(`Page ${page}: Found ${urlsFromPage.length} items`);
      allUrls.push(...urlsFromPage);

      currentPage = page;
    }
  }

  console.log(
    `Finished! Collected ${allUrls.length} items from ${currentPage} pages`,
  );
  return allUrls;
}

function extractItemsFromCurrentPage(domain) {
  const urls = [];

  // Strategy 1: Look for links in the items list
  const itemLinks = document.querySelectorAll('#items-list a[href*="/itm/"]');
  console.log(`Strategy 1: Found ${itemLinks.length} item links`);

  itemLinks.forEach((link) => {
    const href = link.href;
    if (href && href.includes("/itm/")) {
      urls.push(href);
    }
  });

  // Strategy 2: Look for item numbers in data attributes
  if (urls.length === 0) {
    const itemElements = document.querySelectorAll(
      "#items-list [data-item-number], #items-list [data-item-id]",
    );
    console.log(
      `Strategy 2: Found ${itemElements.length} items with data attributes`,
    );

    itemElements.forEach((el) => {
      const itemNumber =
        el.getAttribute("data-item-number") || el.getAttribute("data-item-id");
      if (itemNumber) {
        urls.push(`https://www.ebay.${domain}/itm/${itemNumber}`);
      }
    });
  }

  // Strategy 3: Look in the DOM for any eBay item URLs
  if (urls.length === 0) {
    const allLinks = document.querySelectorAll("#items-list a[href]");
    console.log(
      `Strategy 3: Checking ${allLinks.length} total links for eBay URLs`,
    );

    allLinks.forEach((link) => {
      const href = link.href;
      // Match eBay item URLs
      const match = href.match(/ebay\.[a-z.]+\/itm\/(\d+)/);
      if (match) {
        urls.push(href);
      }
    });
  }

  // Strategy 4: Look for item rows and extract from images or any element
  if (urls.length === 0) {
    const itemRows = document.querySelectorAll("#items-list > *");
    console.log(
      `Strategy 4: Found ${itemRows.length} item rows, extracting from full row`,
    );

    itemRows.forEach((row) => {
      // Look for item number in any child element
      const rowHTML = row.innerHTML;
      const match = rowHTML.match(/(\d{12,13})/); // eBay item numbers are 12-13 digits
      if (match) {
        const itemNumber = match[1];
        urls.push(`https://www.ebay.${domain}/itm/${itemNumber}`);
      }
    });
  }

  // Remove duplicates
  return [...new Set(urls)];
}

function getTotalPages() {
  // Look for page info text like "Page 1 of 10"
  const pageInfo = document.getElementById("page_info");
  if (pageInfo && pageInfo.textContent) {
    const match = pageInfo.textContent.match(/of\s+(\d+)/i);
    if (match) {
      return parseInt(match[1]);
    }
  }

  // Look for pagination elements
  const paginationElements = document.querySelectorAll(
    ".pagination span, .pagination button",
  );
  if (paginationElements.length > 0) {
    const numbers = Array.from(paginationElements)
      .map((el) => parseInt(el.textContent))
      .filter((num) => !isNaN(num));
    if (numbers.length > 0) {
      return Math.max(...numbers);
    }
  }

  return 1; // Default to 1 page if can't determine
}

function clickNextPage() {
  // Try to find and click the next page button
  const nextButton = document.getElementById("next_page");

  if (nextButton && !nextButton.disabled) {
    nextButton.click();
    return true;
  }

  return false;
}

function waitForPageUpdate() {
  return new Promise((resolve) => {
    // Wait for 1 second for page to update
    setTimeout(resolve, 1000);
  });
}
