!(function (_0x3c89b4, _0x72dda9) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module["exports"] = _0x72dda9())
    : "function" == typeof define && define["amd"]
      ? define(_0x72dda9)
      : ((_0x3c89b4 = _0x3c89b4 || self)["Sortable"] = _0x72dda9());
})(this, function () {
  "use strict";
  function _0x3dcbaa(_0x1a837b, _0x55b26f) {
    var _0x10da84,
      _0x4bc3da = Object["keys"](_0x1a837b);
    return (
      Object["getOwnPropertySymbols"] &&
        ((_0x10da84 = Object["getOwnPropertySymbols"](_0x1a837b)),
        _0x55b26f &&
          (_0x10da84 = _0x10da84["filter"](function (_0x202f9e) {
            return Object["getOwnPropertyDescriptor"](_0x1a837b, _0x202f9e)[
              "enumerable"
            ];
          })),
        _0x4bc3da["push"]["apply"](_0x4bc3da, _0x10da84)),
      _0x4bc3da
    );
  }
  function _0x2826a5(_0xa29713) {
    for (var _0x5c8224 = 0x1; _0x5c8224 < arguments["length"]; _0x5c8224++) {
      var _0x212c76 = null != arguments[_0x5c8224] ? arguments[_0x5c8224] : {};
      _0x5c8224 % 0x2
        ? _0x3dcbaa(Object(_0x212c76), !0x0)["forEach"](function (_0x3e0e28) {
            var _0x3123e7, _0x10ff22;
            ((_0x3123e7 = _0xa29713),
              (_0x3e0e28 = _0x212c76[(_0x10ff22 = _0x3e0e28)]),
              _0x10ff22 in _0x3123e7
                ? Object["defineProperty"](_0x3123e7, _0x10ff22, {
                    value: _0x3e0e28,
                    enumerable: !0x0,
                    configurable: !0x0,
                    writable: !0x0,
                  })
                : (_0x3123e7[_0x10ff22] = _0x3e0e28));
          })
        : Object["getOwnPropertyDescriptors"]
          ? Object["defineProperties"](
              _0xa29713,
              Object["getOwnPropertyDescriptors"](_0x212c76),
            )
          : _0x3dcbaa(Object(_0x212c76))["forEach"](function (_0x95f923) {
              Object["defineProperty"](
                _0xa29713,
                _0x95f923,
                Object["getOwnPropertyDescriptor"](_0x212c76, _0x95f923),
              );
            });
    }
    return _0xa29713;
  }
  function _0x2d4107(_0x4d6fe7) {
    return (_0x2d4107 =
      "function" == typeof Symbol && "symbol" == typeof Symbol["iterator"]
        ? function (_0x47dc38) {
            return typeof _0x47dc38;
          }
        : function (_0x38becf) {
            return _0x38becf &&
              "function" == typeof Symbol &&
              _0x38becf["constructor"] === Symbol &&
              _0x38becf !== Symbol["prototype"]
              ? "symbol"
              : typeof _0x38becf;
          })(_0x4d6fe7);
  }
  function _0x35b1a3() {
    return (_0x35b1a3 =
      Object["assign"] ||
      function (_0x1eca74) {
        for (
          var _0xc06480 = 0x1;
          _0xc06480 < arguments["length"];
          _0xc06480++
        ) {
          var _0x1f8857,
            _0x34f959 = arguments[_0xc06480];
          for (_0x1f8857 in _0x34f959)
            Object["prototype"]["hasOwnProperty"]["call"](
              _0x34f959,
              _0x1f8857,
            ) && (_0x1eca74[_0x1f8857] = _0x34f959[_0x1f8857]);
        }
        return _0x1eca74;
      })["apply"](this, arguments);
  }
  function _0x7067(_0x470665) {
    return (
      (function (_0x223f9a) {
        if (Array["isArray"](_0x223f9a)) return _0x429207(_0x223f9a);
      })(_0x470665) ||
      (function (_0x2363c3) {
        if (
          ("undefined" != typeof Symbol &&
            null != _0x2363c3[Symbol["iterator"]]) ||
          null != _0x2363c3["@@iterator"]
        )
          return Array["from"](_0x2363c3);
      })(_0x470665) ||
      (function (_0x5588da, _0x498252) {
        if (_0x5588da) {
          if ("string" == typeof _0x5588da)
            return _0x429207(_0x5588da, _0x498252);
          var _0x2a6fc5 = Object["prototype"]["toString"]
            ["call"](_0x5588da)
            ["slice"](0x8, -0x1);
          return "Map" ===
            (_0x2a6fc5 =
              "Object" === _0x2a6fc5 && _0x5588da["constructor"]
                ? _0x5588da["constructor"]["name"]
                : _0x2a6fc5) || "Set" === _0x2a6fc5
            ? Array["from"](_0x5588da)
            : "Arguments" === _0x2a6fc5 ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/["test"](_0x2a6fc5)
              ? _0x429207(_0x5588da, _0x498252)
              : void 0x0;
        }
      })(_0x470665) ||
      (function () {
        throw new TypeError(
          "Invalid\x20attempt\x20to\x20spread\x20non-iterable\x20instance.\x0aIn\x20order\x20to\x20be\x20iterable,\x20non-array\x20objects\x20must\x20have\x20a\x20[Symbol.iterator]()\x20method.",
        );
      })()
    );
  }
  function _0x429207(_0x1d422c, _0x9ce52) {
    (null == _0x9ce52 || _0x9ce52 > _0x1d422c["length"]) &&
      (_0x9ce52 = _0x1d422c["length"]);
    for (
      var _0x53d667 = 0x0, _0xe8d631 = new Array(_0x9ce52);
      _0x53d667 < _0x9ce52;
      _0x53d667++
    )
      _0xe8d631[_0x53d667] = _0x1d422c[_0x53d667];
    return _0xe8d631;
  }
  function _0x105c88(_0x44ab18) {
    if ("undefined" != typeof window && window["navigator"])
      return !!navigator["userAgent"]["match"](_0x44ab18);
  }
  var _0x127cc2 = _0x105c88(
      /(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i,
    ),
    _0x6f6279 = _0x105c88(/Edge/i),
    _0x1cf95c = _0x105c88(/firefox/i),
    _0x1e8f4e =
      _0x105c88(/safari/i) && !_0x105c88(/chrome/i) && !_0x105c88(/android/i),
    _0x177758 = _0x105c88(/iP(ad|od|hone)/i),
    _0x13cfb5 = _0x105c88(/chrome/i) && _0x105c88(/android/i),
    _0x3c1d98 = { capture: !0x1, passive: !0x1 };
  function _0x25f753(_0x1e9117, _0x69b481, _0x3ca7e4) {
    _0x1e9117["addEventListener"](
      _0x69b481,
      _0x3ca7e4,
      !_0x127cc2 && _0x3c1d98,
    );
  }
  function _0x5ec097(_0x27cf95, _0x5c099, _0x53a621) {
    _0x27cf95["removeEventListener"](
      _0x5c099,
      _0x53a621,
      !_0x127cc2 && _0x3c1d98,
    );
  }
  function _0x4fd27b(_0x2746f2, _0xd53c79) {
    if (
      _0xd53c79 &&
      (">" === _0xd53c79[0x0] && (_0xd53c79 = _0xd53c79["substring"](0x1)),
      _0x2746f2)
    )
      try {
        if (_0x2746f2["matches"]) return _0x2746f2["matches"](_0xd53c79);
        if (_0x2746f2["msMatchesSelector"])
          return _0x2746f2["msMatchesSelector"](_0xd53c79);
        if (_0x2746f2["webkitMatchesSelector"])
          return _0x2746f2["webkitMatchesSelector"](_0xd53c79);
      } catch (_0x49de10) {
        return;
      }
  }
  function _0x460dec(_0x18ba58, _0x123623, _0x579eca, _0x1fbeb8) {
    if (_0x18ba58) {
      _0x579eca = _0x579eca || document;
      do {
        if (
          (null != _0x123623 &&
            (">" !== _0x123623[0x0] || _0x18ba58["parentNode"] === _0x579eca) &&
            _0x4fd27b(_0x18ba58, _0x123623)) ||
          (_0x1fbeb8 && _0x18ba58 === _0x579eca)
        )
          return _0x18ba58;
      } while (
        _0x18ba58 !== _0x579eca &&
        (_0x18ba58 =
          (_0x102d56 = _0x18ba58)["host"] &&
          _0x102d56 !== document &&
          _0x102d56["host"]["nodeType"]
            ? _0x102d56["host"]
            : _0x102d56["parentNode"])
      );
    }
    var _0x102d56;
    return null;
  }
  var _0x4864bd,
    _0x5b3980 = /\s+/g;
  function _0x42f20d(_0x18c0e7, _0x1eb1f6, _0x18ccf0) {
    var _0x36af1f;
    _0x18c0e7 &&
      _0x1eb1f6 &&
      (_0x18c0e7["classList"]
        ? _0x18c0e7["classList"][_0x18ccf0 ? "add" : "remove"](_0x1eb1f6)
        : ((_0x36af1f = ("\x20" + _0x18c0e7["className"] + "\x20")
            ["replace"](_0x5b3980, "\x20")
            ["replace"]("\x20" + _0x1eb1f6 + "\x20", "\x20")),
          (_0x18c0e7["className"] = (_0x36af1f +
            (_0x18ccf0 ? "\x20" + _0x1eb1f6 : ""))["replace"](
            _0x5b3980,
            "\x20",
          ))));
  }
  function _0x307908(_0x3ca34e, _0x5b955d, _0x215b48) {
    var _0x50e12b = _0x3ca34e && _0x3ca34e["style"];
    if (_0x50e12b) {
      if (void 0x0 === _0x215b48)
        return (
          document["defaultView"] && document["defaultView"]["getComputedStyle"]
            ? (_0x215b48 = document["defaultView"]["getComputedStyle"](
                _0x3ca34e,
                "",
              ))
            : _0x3ca34e["currentStyle"] &&
              (_0x215b48 = _0x3ca34e["currentStyle"]),
          void 0x0 === _0x5b955d ? _0x215b48 : _0x215b48[_0x5b955d]
        );
      _0x50e12b[
        (_0x5b955d =
          _0x5b955d in _0x50e12b || -0x1 !== _0x5b955d["indexOf"]("webkit")
            ? _0x5b955d
            : "-webkit-" + _0x5b955d)
      ] = _0x215b48 + ("string" == typeof _0x215b48 ? "" : "px");
    }
  }
  function _0x9185c4(_0x4a3639, _0x1e2b73) {
    var _0x5909da = "";
    if ("string" == typeof _0x4a3639) _0x5909da = _0x4a3639;
    else
      do {
        var _0x332fc3 = _0x307908(_0x4a3639, "transform");
      } while (
        (_0x332fc3 &&
          "none" !== _0x332fc3 &&
          (_0x5909da = _0x332fc3 + "\x20" + _0x5909da),
        !_0x1e2b73 && (_0x4a3639 = _0x4a3639["parentNode"]))
      );
    var _0x4fa757 =
      window["DOMMatrix"] ||
      window["WebKitCSSMatrix"] ||
      window["CSSMatrix"] ||
      window["MSCSSMatrix"];
    return _0x4fa757 && new _0x4fa757(_0x5909da);
  }
  function _0x5145cb(_0x298215, _0xfbb84c, _0x2f6877) {
    if (_0x298215) {
      var _0x3dadce = _0x298215["getElementsByTagName"](_0xfbb84c),
        _0x3e39c5 = 0x0,
        _0x1522d0 = _0x3dadce["length"];
      if (_0x2f6877) {
        for (; _0x3e39c5 < _0x1522d0; _0x3e39c5++)
          _0x2f6877(_0x3dadce[_0x3e39c5], _0x3e39c5);
      }
      return _0x3dadce;
    }
    return [];
  }
  function _0x23897c() {
    return document["scrollingElement"] || document["documentElement"];
  }
  function _0x156da0(_0x240814, _0x6543da, _0x452c4f, _0xfbd45d, _0x3821c6) {
    if (_0x240814["getBoundingClientRect"] || _0x240814 === window) {
      var _0x557cb5,
        _0xec5f4b,
        _0x300368,
        _0x1cbd79,
        _0x5ea137,
        _0x28d252,
        _0x55bb2e =
          _0x240814 !== window &&
          _0x240814["parentNode"] &&
          _0x240814 !== _0x23897c()
            ? ((_0xec5f4b = (_0x557cb5 = _0x240814["getBoundingClientRect"]())[
                "top"
              ]),
              (_0x300368 = _0x557cb5["left"]),
              (_0x1cbd79 = _0x557cb5["bottom"]),
              (_0x5ea137 = _0x557cb5["right"]),
              (_0x28d252 = _0x557cb5["height"]),
              _0x557cb5["width"])
            : ((_0x300368 = _0xec5f4b = 0x0),
              (_0x1cbd79 = window["innerHeight"]),
              (_0x5ea137 = window["innerWidth"]),
              (_0x28d252 = window["innerHeight"]),
              window["innerWidth"]);
      if (
        (_0x6543da || _0x452c4f) &&
        _0x240814 !== window &&
        ((_0x3821c6 = _0x3821c6 || _0x240814["parentNode"]), !_0x127cc2)
      )
        do {
          if (
            _0x3821c6 &&
            _0x3821c6["getBoundingClientRect"] &&
            ("none" !== _0x307908(_0x3821c6, "transform") ||
              (_0x452c4f && "static" !== _0x307908(_0x3821c6, "position")))
          ) {
            var _0x6988ae = _0x3821c6["getBoundingClientRect"]();
            ((_0xec5f4b -=
              _0x6988ae["top"] +
              parseInt(_0x307908(_0x3821c6, "border-top-width"))),
              (_0x300368 -=
                _0x6988ae["left"] +
                parseInt(_0x307908(_0x3821c6, "border-left-width"))),
              (_0x1cbd79 = _0xec5f4b + _0x557cb5["height"]),
              (_0x5ea137 = _0x300368 + _0x557cb5["width"]));
            break;
          }
        } while ((_0x3821c6 = _0x3821c6["parentNode"]));
      return (
        _0xfbd45d &&
          _0x240814 !== window &&
          ((_0xfbd45d =
            (_0x6543da = _0x9185c4(_0x3821c6 || _0x240814)) && _0x6543da["a"]),
          (_0x240814 = _0x6543da && _0x6543da["d"]),
          _0x6543da &&
            ((_0x1cbd79 = (_0xec5f4b /= _0x240814) + (_0x28d252 /= _0x240814)),
            (_0x5ea137 = (_0x300368 /= _0xfbd45d) + (_0x55bb2e /= _0xfbd45d)))),
        {
          top: _0xec5f4b,
          left: _0x300368,
          bottom: _0x1cbd79,
          right: _0x5ea137,
          width: _0x55bb2e,
          height: _0x28d252,
        }
      );
    }
  }
  function _0x1c4eb3(_0x3d14e0, _0x4c4f0c, _0x5270a8) {
    for (
      var _0x353b48 = _0x1524ea(_0x3d14e0, !0x0),
        _0x31ee83 = _0x156da0(_0x3d14e0)[_0x4c4f0c];
      _0x353b48;

    ) {
      var _0x544a94 = _0x156da0(_0x353b48)[_0x5270a8];
      if (
        !("top" === _0x5270a8 || "left" === _0x5270a8
          ? _0x544a94 <= _0x31ee83
          : _0x31ee83 <= _0x544a94)
      )
        return _0x353b48;
      if (_0x353b48 === _0x23897c()) break;
      _0x353b48 = _0x1524ea(_0x353b48, !0x1);
    }
    return !0x1;
  }
  function _0x350cbb(_0x2c49d9, _0x24847f, _0x4352e2, _0x3d5689) {
    for (
      var _0x8a3433 = 0x0, _0x1581f5 = 0x0, _0x1153af = _0x2c49d9["children"];
      _0x1581f5 < _0x1153af["length"];

    ) {
      if (
        "none" !== _0x1153af[_0x1581f5]["style"]["display"] &&
        _0x1153af[_0x1581f5] !== _0x1d4300["ghost"] &&
        (_0x3d5689 || _0x1153af[_0x1581f5] !== _0x1d4300["dragged"]) &&
        _0x460dec(_0x1153af[_0x1581f5], _0x4352e2["draggable"], _0x2c49d9, !0x1)
      ) {
        if (_0x8a3433 === _0x24847f) return _0x1153af[_0x1581f5];
        _0x8a3433++;
      }
      _0x1581f5++;
    }
    return null;
  }
  function _0x58f526(_0x445665, _0x49379a) {
    for (
      var _0x38652b = _0x445665["lastElementChild"];
      _0x38652b &&
      (_0x38652b === _0x1d4300["ghost"] ||
        "none" === _0x307908(_0x38652b, "display") ||
        (_0x49379a && !_0x4fd27b(_0x38652b, _0x49379a)));

    )
      _0x38652b = _0x38652b["previousElementSibling"];
    return _0x38652b || null;
  }
  function _0x5085eb(_0x5a83b7, _0x584f43) {
    var _0x18032d = 0x0;
    if (!_0x5a83b7 || !_0x5a83b7["parentNode"]) return -0x1;
    for (; (_0x5a83b7 = _0x5a83b7["previousElementSibling"]); )
      "TEMPLATE" === _0x5a83b7["nodeName"]["toUpperCase"]() ||
        _0x5a83b7 === _0x1d4300["clone"] ||
        (_0x584f43 && !_0x4fd27b(_0x5a83b7, _0x584f43)) ||
        _0x18032d++;
    return _0x18032d;
  }
  function _0x1e26ad(_0x3c41c6) {
    var _0x19f1d6 = 0x0,
      _0x4d3426 = 0x0,
      _0x478256 = _0x23897c();
    if (_0x3c41c6)
      do {
        var _0xd50f39 = (_0x1d1707 = _0x9185c4(_0x3c41c6))["a"],
          _0x1d1707 = _0x1d1707["d"];
      } while (
        ((_0x19f1d6 += _0x3c41c6["scrollLeft"] * _0xd50f39),
        (_0x4d3426 += _0x3c41c6["scrollTop"] * _0x1d1707),
        _0x3c41c6 !== _0x478256 && (_0x3c41c6 = _0x3c41c6["parentNode"]))
      );
    return [_0x19f1d6, _0x4d3426];
  }
  function _0x1524ea(_0x57db36, _0x2efe52) {
    if (!_0x57db36 || !_0x57db36["getBoundingClientRect"]) return _0x23897c();
    var _0x3149d2 = _0x57db36,
      _0x46bdba = !0x1;
    do {
      if (
        _0x3149d2["clientWidth"] < _0x3149d2["scrollWidth"] ||
        _0x3149d2["clientHeight"] < _0x3149d2["scrollHeight"]
      ) {
        var _0x4d2cf6 = _0x307908(_0x3149d2);
        if (
          (_0x3149d2["clientWidth"] < _0x3149d2["scrollWidth"] &&
            ("auto" == _0x4d2cf6["overflowX"] ||
              "scroll" == _0x4d2cf6["overflowX"])) ||
          (_0x3149d2["clientHeight"] < _0x3149d2["scrollHeight"] &&
            ("auto" == _0x4d2cf6["overflowY"] ||
              "scroll" == _0x4d2cf6["overflowY"]))
        ) {
          if (
            !_0x3149d2["getBoundingClientRect"] ||
            _0x3149d2 === document["body"]
          )
            return _0x23897c();
          if (_0x46bdba || _0x2efe52) return _0x3149d2;
          _0x46bdba = !0x0;
        }
      }
    } while ((_0x3149d2 = _0x3149d2["parentNode"]));
    return _0x23897c();
  }
  function _0x524c52(_0x1519c6, _0x274734) {
    return (
      Math["round"](_0x1519c6["top"]) === Math["round"](_0x274734["top"]) &&
      Math["round"](_0x1519c6["left"]) === Math["round"](_0x274734["left"]) &&
      Math["round"](_0x1519c6["height"]) ===
        Math["round"](_0x274734["height"]) &&
      Math["round"](_0x1519c6["width"]) === Math["round"](_0x274734["width"])
    );
  }
  function _0x24aa9f(_0x2a5fab, _0x2bdf2f) {
    return function () {
      var _0x1fcda1;
      _0x4864bd ||
        (0x1 === (_0x1fcda1 = arguments)["length"]
          ? _0x2a5fab["call"](this, _0x1fcda1[0x0])
          : _0x2a5fab["apply"](this, _0x1fcda1),
        (_0x4864bd = setTimeout(function () {
          _0x4864bd = void 0x0;
        }, _0x2bdf2f)));
    };
  }
  function _0x2f90a0(_0x79bc9b, _0xdc11ef, _0x4b0e03) {
    ((_0x79bc9b["scrollLeft"] += _0xdc11ef),
      (_0x79bc9b["scrollTop"] += _0x4b0e03));
  }
  function _0x3e007f(_0x4805b4) {
    var _0x509c73 = window["Polymer"],
      _0x1da4e3 = window["jQuery"] || window["Zepto"];
    return _0x509c73 && _0x509c73["dom"]
      ? _0x509c73["dom"](_0x4805b4)["cloneNode"](!0x0)
      : _0x1da4e3
        ? _0x1da4e3(_0x4805b4)["clone"](!0x0)[0x0]
        : _0x4805b4["cloneNode"](!0x0);
  }
  function _0x16af76(_0xee1951, _0xc5149f) {
    (_0x307908(_0xee1951, "position", "absolute"),
      _0x307908(_0xee1951, "top", _0xc5149f["top"]),
      _0x307908(_0xee1951, "left", _0xc5149f["left"]),
      _0x307908(_0xee1951, "width", _0xc5149f["width"]),
      _0x307908(_0xee1951, "height", _0xc5149f["height"]));
  }
  function _0x1a3dff(_0x3d954f) {
    (_0x307908(_0x3d954f, "position", ""),
      _0x307908(_0x3d954f, "top", ""),
      _0x307908(_0x3d954f, "left", ""),
      _0x307908(_0x3d954f, "width", ""),
      _0x307908(_0x3d954f, "height", ""));
  }
  var _0x2848d7 = "Sortable" + new Date()["getTime"](),
    _0x206306 = [],
    _0x34f96d = { initializeByDefault: !0x0 },
    _0x249677 = {
      mount: function (_0x4eb06c) {
        for (var _0x3041ba in _0x34f96d)
          !_0x34f96d["hasOwnProperty"](_0x3041ba) ||
            _0x3041ba in _0x4eb06c ||
            (_0x4eb06c[_0x3041ba] = _0x34f96d[_0x3041ba]);
        (_0x206306["forEach"](function (_0x46f6c4) {
          if (_0x46f6c4["pluginName"] === _0x4eb06c["pluginName"])
            throw "Sortable:\x20Cannot\x20mount\x20plugin\x20"["concat"](
              _0x4eb06c["pluginName"],
              "\x20more\x20than\x20once",
            );
        }),
          _0x206306["push"](_0x4eb06c));
      },
      pluginEvent: function (_0x2abe19, _0x1932c, _0x27300e) {
        var _0x44c54f = this;
        ((this["eventCanceled"] = !0x1),
          (_0x27300e["cancel"] = function () {
            _0x44c54f["eventCanceled"] = !0x0;
          }));
        var _0x557d89 = _0x2abe19 + "Global";
        _0x206306["forEach"](function (_0x140b1c) {
          _0x1932c[_0x140b1c["pluginName"]] &&
            (_0x1932c[_0x140b1c["pluginName"]][_0x557d89] &&
              _0x1932c[_0x140b1c["pluginName"]][_0x557d89](
                _0x2826a5({ sortable: _0x1932c }, _0x27300e),
              ),
            _0x1932c["options"][_0x140b1c["pluginName"]] &&
              _0x1932c[_0x140b1c["pluginName"]][_0x2abe19] &&
              _0x1932c[_0x140b1c["pluginName"]][_0x2abe19](
                _0x2826a5({ sortable: _0x1932c }, _0x27300e),
              ));
        });
      },
      initializePlugins: function (_0x40cd45, _0x45aec8, _0x37bb5e, _0x2b54bb) {
        for (var _0x4a9407 in (_0x206306["forEach"](function (_0xddebf0) {
          var _0x3ffe56 = _0xddebf0["pluginName"];
          (_0x40cd45["options"][_0x3ffe56] ||
            _0xddebf0["initializeByDefault"]) &&
            (((_0xddebf0 = new _0xddebf0(
              _0x40cd45,
              _0x45aec8,
              _0x40cd45["options"],
            ))["sortable"] = _0x40cd45),
            (_0xddebf0["options"] = _0x40cd45["options"]),
            (_0x40cd45[_0x3ffe56] = _0xddebf0),
            _0x35b1a3(_0x37bb5e, _0xddebf0["defaults"]));
        }),
        _0x40cd45["options"])) {
          var _0x5ae23a;
          _0x40cd45["options"]["hasOwnProperty"](_0x4a9407) &&
            void 0x0 !==
              (_0x5ae23a = this["modifyOption"](
                _0x40cd45,
                _0x4a9407,
                _0x40cd45["options"][_0x4a9407],
              )) &&
            (_0x40cd45["options"][_0x4a9407] = _0x5ae23a);
        }
      },
      getEventProperties: function (_0x3b9e86, _0x3f68b4) {
        var _0xb68b6e = {};
        return (
          _0x206306["forEach"](function (_0x13627a) {
            "function" == typeof _0x13627a["eventProperties"] &&
              _0x35b1a3(
                _0xb68b6e,
                _0x13627a["eventProperties"]["call"](
                  _0x3f68b4[_0x13627a["pluginName"]],
                  _0x3b9e86,
                ),
              );
          }),
          _0xb68b6e
        );
      },
      modifyOption: function (_0x22763d, _0x37a594, _0x482bfd) {
        var _0x1a2acb;
        return (
          _0x206306["forEach"](function (_0xbc26f7) {
            _0x22763d[_0xbc26f7["pluginName"]] &&
              _0xbc26f7["optionListeners"] &&
              "function" == typeof _0xbc26f7["optionListeners"][_0x37a594] &&
              (_0x1a2acb = _0xbc26f7["optionListeners"][_0x37a594]["call"](
                _0x22763d[_0xbc26f7["pluginName"]],
                _0x482bfd,
              ));
          }),
          _0x1a2acb
        );
      },
    };
  function _0x2ef43f(_0xac3c3e) {
    var _0x2fdbbd = _0xac3c3e["sortable"],
      _0x153067 = _0xac3c3e["rootEl"],
      _0x1b2efc = _0xac3c3e["name"],
      _0x3b521c = _0xac3c3e["targetEl"],
      _0x320b8e = _0xac3c3e["cloneEl"],
      _0xb19cea = _0xac3c3e["toEl"],
      _0x327eaf = _0xac3c3e["fromEl"],
      _0x4fc8bb = _0xac3c3e["oldIndex"],
      _0x40df29 = _0xac3c3e["newIndex"],
      _0x2d36de = _0xac3c3e["oldDraggableIndex"],
      _0x78dbad = _0xac3c3e["newDraggableIndex"],
      _0x40f115 = _0xac3c3e["originalEvent"],
      _0x415a6e = _0xac3c3e["putSortable"],
      _0x22412d = _0xac3c3e["extraEventProperties"];
    if ((_0x2fdbbd = _0x2fdbbd || (_0x153067 && _0x153067[_0x2848d7]))) {
      var _0x405621,
        _0x2ab2ed = _0x2fdbbd["options"];
      ((_0xac3c3e =
        "on" +
        _0x1b2efc["charAt"](0x0)["toUpperCase"]() +
        _0x1b2efc["substr"](0x1)),
        (!window["CustomEvent"] || _0x127cc2 || _0x6f6279
          ? (_0x405621 = document["createEvent"]("Event"))["initEvent"](
              _0x1b2efc,
              !0x0,
              !0x0,
            )
          : (_0x405621 = new CustomEvent(_0x1b2efc, {
              bubbles: !0x0,
              cancelable: !0x0,
            })),
        (_0x405621["to"] = _0xb19cea || _0x153067),
        (_0x405621["from"] = _0x327eaf || _0x153067),
        (_0x405621["item"] = _0x3b521c || _0x153067),
        (_0x405621["clone"] = _0x320b8e),
        (_0x405621["oldIndex"] = _0x4fc8bb),
        (_0x405621["newIndex"] = _0x40df29),
        (_0x405621["oldDraggableIndex"] = _0x2d36de),
        (_0x405621["newDraggableIndex"] = _0x78dbad),
        (_0x405621["originalEvent"] = _0x40f115),
        (_0x405621["pullMode"] = _0x415a6e
          ? _0x415a6e["lastPutMode"]
          : void 0x0)));
      var _0x34d5cd,
        _0x5ca54d = _0x2826a5(
          _0x2826a5({}, _0x22412d),
          _0x249677["getEventProperties"](_0x1b2efc, _0x2fdbbd),
        );
      for (_0x34d5cd in _0x5ca54d) _0x405621[_0x34d5cd] = _0x5ca54d[_0x34d5cd];
      (_0x153067 && _0x153067["dispatchEvent"](_0x405621),
        _0x2ab2ed[_0xac3c3e] &&
          _0x2ab2ed[_0xac3c3e]["call"](_0x2fdbbd, _0x405621));
    }
  }
  function _0x338aab(_0x13413e, _0x5298fc) {
    var _0x450e9f = (_0xba733 =
        0x2 < arguments["length"] && void 0x0 !== arguments[0x2]
          ? arguments[0x2]
          : {})["evt"],
      _0xba733 = (function (_0x2d240a, _0x3462dd) {
        if (null == _0x2d240a) return {};
        var _0x4f3f54,
          _0x5d850c = (function (_0x1be7eb, _0x31a4bf) {
            if (null == _0x1be7eb) return {};
            for (
              var _0x1ddf9c,
                _0x15bb5b = {},
                _0x185d10 = Object["keys"](_0x1be7eb),
                _0x30a044 = 0x0;
              _0x30a044 < _0x185d10["length"];
              _0x30a044++
            )
              ((_0x1ddf9c = _0x185d10[_0x30a044]),
                0x0 <= _0x31a4bf["indexOf"](_0x1ddf9c) ||
                  (_0x15bb5b[_0x1ddf9c] = _0x1be7eb[_0x1ddf9c]));
            return _0x15bb5b;
          })(_0x2d240a, _0x3462dd);
        if (Object["getOwnPropertySymbols"]) {
          for (
            var _0x53da76 = Object["getOwnPropertySymbols"](_0x2d240a),
              _0x2142be = 0x0;
            _0x2142be < _0x53da76["length"];
            _0x2142be++
          )
            ((_0x4f3f54 = _0x53da76[_0x2142be]),
              0x0 <= _0x3462dd["indexOf"](_0x4f3f54) ||
                (Object["prototype"]["propertyIsEnumerable"]["call"](
                  _0x2d240a,
                  _0x4f3f54,
                ) &&
                  (_0x5d850c[_0x4f3f54] = _0x2d240a[_0x4f3f54])));
        }
        return _0x5d850c;
      })(_0xba733, _0x3becdb);
    _0x249677["pluginEvent"]["bind"](_0x1d4300)(
      _0x13413e,
      _0x5298fc,
      _0x2826a5(
        {
          dragEl: _0x4c8404,
          parentEl: _0x150448,
          ghostEl: _0x52d46f,
          rootEl: _0x3a1157,
          nextEl: _0x3122f4,
          lastDownEl: _0x5b9424,
          cloneEl: _0x32a4c0,
          cloneHidden: _0x46438b,
          dragStarted: _0x19e098,
          putSortable: _0x40fc4e,
          activeSortable: _0x1d4300["active"],
          originalEvent: _0x450e9f,
          oldIndex: _0x369c7c,
          oldDraggableIndex: _0x292c3c,
          newIndex: _0xf8d987,
          newDraggableIndex: _0xfc74fa,
          hideGhostForTarget: _0x5d4fc1,
          unhideGhostForTarget: _0x420b67,
          cloneNowHidden: function () {
            _0x46438b = !0x0;
          },
          cloneNowShown: function () {
            _0x46438b = !0x1;
          },
          dispatchSortableEvent: function (_0x1f6024) {
            _0x1c8304({
              sortable: _0x5298fc,
              name: _0x1f6024,
              originalEvent: _0x450e9f,
            });
          },
        },
        _0xba733,
      ),
    );
  }
  var _0x3becdb = ["evt"];
  function _0x1c8304(_0x42867e) {
    _0x2ef43f(
      _0x2826a5(
        {
          putSortable: _0x40fc4e,
          cloneEl: _0x32a4c0,
          targetEl: _0x4c8404,
          rootEl: _0x3a1157,
          oldIndex: _0x369c7c,
          oldDraggableIndex: _0x292c3c,
          newIndex: _0xf8d987,
          newDraggableIndex: _0xfc74fa,
        },
        _0x42867e,
      ),
    );
  }
  var _0x4c8404,
    _0x150448,
    _0x52d46f,
    _0x3a1157,
    _0x3122f4,
    _0x5b9424,
    _0x32a4c0,
    _0x46438b,
    _0x369c7c,
    _0xf8d987,
    _0x292c3c,
    _0xfc74fa,
    _0x2a49d0,
    _0x40fc4e,
    _0x1d3175,
    _0x360dc8,
    _0x2686bf,
    _0x195f1e,
    _0x572bcd,
    _0x125e6a,
    _0x19e098,
    _0x15d8bc,
    _0x28ce9e,
    _0x97e304,
    _0x11e334,
    _0x55ee58 = !0x1,
    _0x138e44 = !0x1,
    _0xd20cce = [],
    _0x11aa71 = !0x1,
    _0x5597e6 = !0x1,
    _0x1b4f9a = [],
    _0x5237f9 = !0x1,
    _0x48c6c5 = [],
    _0x4d9932 = "undefined" != typeof document,
    _0x274a64 = _0x177758,
    _0x15e284 = _0x6f6279 || _0x127cc2 ? "cssFloat" : "float",
    _0x3b97af =
      _0x4d9932 &&
      !_0x13cfb5 &&
      !_0x177758 &&
      "draggable" in document["createElement"]("div"),
    _0xbfbc37 = (function () {
      if (_0x4d9932) {
        if (_0x127cc2) return !0x1;
        var _0x162644 = document["createElement"]("x");
        return (
          (_0x162644["style"]["cssText"] = "pointer-events:auto"),
          "auto" === _0x162644["style"]["pointerEvents"]
        );
      }
    })(),
    _0x4c1e8e = function (_0x5f3161, _0x5584e2) {
      var _0x3e35b5 = _0x307908(_0x5f3161),
        _0x497c68 =
          parseInt(_0x3e35b5["width"]) -
          parseInt(_0x3e35b5["paddingLeft"]) -
          parseInt(_0x3e35b5["paddingRight"]) -
          parseInt(_0x3e35b5["borderLeftWidth"]) -
          parseInt(_0x3e35b5["borderRightWidth"]),
        _0x31ed4c = _0x350cbb(_0x5f3161, 0x0, _0x5584e2),
        _0x2833bd = _0x350cbb(_0x5f3161, 0x1, _0x5584e2),
        _0x28485f = _0x31ed4c && _0x307908(_0x31ed4c),
        _0x274665 = _0x2833bd && _0x307908(_0x2833bd),
        _0x37dabc =
          _0x28485f &&
          parseInt(_0x28485f["marginLeft"]) +
            parseInt(_0x28485f["marginRight"]) +
            _0x156da0(_0x31ed4c)["width"];
      _0x5f3161 =
        _0x274665 &&
        parseInt(_0x274665["marginLeft"]) +
          parseInt(_0x274665["marginRight"]) +
          _0x156da0(_0x2833bd)["width"];
      if ("flex" === _0x3e35b5["display"])
        return "column" === _0x3e35b5["flexDirection"] ||
          "column-reverse" === _0x3e35b5["flexDirection"]
          ? "vertical"
          : "horizontal";
      if ("grid" === _0x3e35b5["display"])
        return _0x3e35b5["gridTemplateColumns"]["split"]("\x20")["length"] <=
          0x1
          ? "vertical"
          : "horizontal";
      if (_0x31ed4c && _0x28485f["float"] && "none" !== _0x28485f["float"])
        return (
          (_0x5584e2 = "left" === _0x28485f["float"] ? "left" : "right"),
          !_0x2833bd ||
          ("both" !== _0x274665["clear"] && _0x274665["clear"] !== _0x5584e2)
            ? "horizontal"
            : "vertical"
        );
      return _0x31ed4c &&
        ("block" === _0x28485f["display"] ||
          "flex" === _0x28485f["display"] ||
          "table" === _0x28485f["display"] ||
          "grid" === _0x28485f["display"] ||
          (_0x497c68 <= _0x37dabc && "none" === _0x3e35b5[_0x15e284]) ||
          (_0x2833bd &&
            "none" === _0x3e35b5[_0x15e284] &&
            _0x497c68 < _0x37dabc + _0x5f3161))
        ? "vertical"
        : "horizontal";
    },
    _0x396b8d = function (_0x5a722b) {
      function _0x455675(_0x54a51d, _0x3abf3d) {
        return function (_0x4019e4, _0x236760, _0x347693, _0x24f585) {
          var _0x4da691 =
            _0x4019e4["options"]["group"]["name"] &&
            _0x236760["options"]["group"]["name"] &&
            _0x4019e4["options"]["group"]["name"] ===
              _0x236760["options"]["group"]["name"];
          if (null == _0x54a51d && (_0x3abf3d || _0x4da691)) return !0x0;
          if (null == _0x54a51d || !0x1 === _0x54a51d) return !0x1;
          if (_0x3abf3d && "clone" === _0x54a51d) return _0x54a51d;
          if ("function" == typeof _0x54a51d)
            return _0x455675(
              _0x54a51d(_0x4019e4, _0x236760, _0x347693, _0x24f585),
              _0x3abf3d,
            )(_0x4019e4, _0x236760, _0x347693, _0x24f585);
          return (
            (_0x236760 = (_0x3abf3d ? _0x4019e4 : _0x236760)["options"][
              "group"
            ]["name"]),
            !0x0 === _0x54a51d ||
              ("string" == typeof _0x54a51d && _0x54a51d === _0x236760) ||
              (_0x54a51d["join"] && -0x1 < _0x54a51d["indexOf"](_0x236760))
          );
        };
      }
      var _0x1123b9 = {},
        _0x25ee64 = _0x5a722b["group"];
      ((_0x25ee64 && "object" == _0x2d4107(_0x25ee64)) ||
        (_0x25ee64 = { name: _0x25ee64 }),
        (_0x1123b9["name"] = _0x25ee64["name"]),
        (_0x1123b9["checkPull"] = _0x455675(_0x25ee64["pull"], !0x0)),
        (_0x1123b9["checkPut"] = _0x455675(_0x25ee64["put"])),
        (_0x1123b9["revertClone"] = _0x25ee64["revertClone"]),
        (_0x5a722b["group"] = _0x1123b9));
    },
    _0x5d4fc1 = function () {
      !_0xbfbc37 && _0x52d46f && _0x307908(_0x52d46f, "display", "none");
    },
    _0x420b67 = function () {
      !_0xbfbc37 && _0x52d46f && _0x307908(_0x52d46f, "display", "");
    };
  _0x4d9932 &&
    document["addEventListener"](
      "click",
      function (_0x497d09) {
        if (_0x138e44)
          return (
            _0x497d09["preventDefault"](),
            _0x497d09["stopPropagation"] && _0x497d09["stopPropagation"](),
            _0x497d09["stopImmediatePropagation"] &&
              _0x497d09["stopImmediatePropagation"](),
            (_0x138e44 = !0x1)
          );
      },
      !0x0,
    );
  function _0x562723(_0x39d7f8) {
    if (_0x4c8404) {
      _0x39d7f8 = _0x39d7f8["touches"] ? _0x39d7f8["touches"][0x0] : _0x39d7f8;
      var _0x2ab597 =
        ((_0x49b9f9 = _0x39d7f8["clientX"]),
        (_0x2b1e48 = _0x39d7f8["clientY"]),
        _0xd20cce["some"](function (_0x4a40a2) {
          if (
            (_0x38e655 =
              _0x4a40a2[_0x2848d7]["options"]["emptyInsertThreshold"]) &&
            !_0x58f526(_0x4a40a2)
          ) {
            var _0x8717d2 = _0x156da0(_0x4a40a2),
              _0x7e39a0 =
                _0x49b9f9 >= _0x8717d2["left"] - _0x38e655 &&
                _0x49b9f9 <= _0x8717d2["right"] + _0x38e655,
              _0x38e655 =
                _0x2b1e48 >= _0x8717d2["top"] - _0x38e655 &&
                _0x2b1e48 <= _0x8717d2["bottom"] + _0x38e655;
            return _0x7e39a0 && _0x38e655 ? (_0x20a86d = _0x4a40a2) : void 0x0;
          }
        }),
        _0x20a86d);
      if (_0x2ab597) {
        var _0x53fe9a,
          _0x1d3f5d = {};
        for (_0x53fe9a in _0x39d7f8)
          _0x39d7f8["hasOwnProperty"](_0x53fe9a) &&
            (_0x1d3f5d[_0x53fe9a] = _0x39d7f8[_0x53fe9a]);
        ((_0x1d3f5d["target"] = _0x1d3f5d["rootEl"] = _0x2ab597),
          (_0x1d3f5d["preventDefault"] = void 0x0),
          (_0x1d3f5d["stopPropagation"] = void 0x0),
          _0x2ab597[_0x2848d7]["_onDragOver"](_0x1d3f5d));
      }
    }
    var _0x49b9f9, _0x2b1e48, _0x20a86d;
  }
  function _0xea0740(_0x148a72) {
    _0x4c8404 &&
      _0x4c8404["parentNode"][_0x2848d7]["_isOutsideThisEl"](
        _0x148a72["target"],
      );
  }
  function _0x1d4300(_0x50b541, _0x1bbfb3) {
    if (!_0x50b541 || !_0x50b541["nodeType"] || 0x1 !== _0x50b541["nodeType"])
      throw "Sortable:\x20`el`\x20must\x20be\x20an\x20HTMLElement,\x20not\x20"[
        "concat"
      ]({}["toString"]["call"](_0x50b541));
    ((this["el"] = _0x50b541),
      (this["options"] = _0x1bbfb3 = _0x35b1a3({}, _0x1bbfb3)),
      (_0x50b541[_0x2848d7] = this));
    var _0x1c3ef3,
      _0x5a6a11,
      _0x566ab8 = {
        group: null,
        sort: !0x0,
        disabled: !0x1,
        store: null,
        handle: null,
        draggable: /^[uo]l$/i["test"](_0x50b541["nodeName"]) ? ">li" : ">*",
        swapThreshold: 0x1,
        invertSwap: !0x1,
        invertedSwapThreshold: null,
        removeCloneOnHide: !0x0,
        direction: function () {
          return _0x4c1e8e(_0x50b541, this["options"]);
        },
        ghostClass: "sortable-ghost",
        chosenClass: "sortable-chosen",
        dragClass: "sortable-drag",
        ignore: "a,\x20img",
        filter: null,
        preventOnFilter: !0x0,
        animation: 0x0,
        easing: null,
        setData: function (_0x815b15, _0x1a7dae) {
          _0x815b15["setData"]("Text", _0x1a7dae["textContent"]);
        },
        dropBubble: !0x1,
        dragoverBubble: !0x1,
        dataIdAttr: "data-id",
        delay: 0x0,
        delayOnTouchOnly: !0x1,
        touchStartThreshold:
          (Number["parseInt"] ? Number : window)["parseInt"](
            window["devicePixelRatio"],
            0xa,
          ) || 0x1,
        forceFallback: !0x1,
        fallbackClass: "sortable-fallback",
        fallbackOnBody: !0x1,
        fallbackTolerance: 0x0,
        fallbackOffset: { x: 0x0, y: 0x0 },
        supportPointer:
          !0x1 !== _0x1d4300["supportPointer"] &&
          "PointerEvent" in window &&
          !_0x1e8f4e,
        emptyInsertThreshold: 0x5,
      };
    for (_0x1c3ef3 in (_0x249677["initializePlugins"](
      this,
      _0x50b541,
      _0x566ab8,
    ),
    _0x566ab8))
      _0x1c3ef3 in _0x1bbfb3 || (_0x1bbfb3[_0x1c3ef3] = _0x566ab8[_0x1c3ef3]);
    for (_0x5a6a11 in (_0x396b8d(_0x1bbfb3), this))
      "_" === _0x5a6a11["charAt"](0x0) &&
        "function" == typeof this[_0x5a6a11] &&
        (this[_0x5a6a11] = this[_0x5a6a11]["bind"](this));
    ((this["nativeDraggable"] = !_0x1bbfb3["forceFallback"] && _0x3b97af),
      this["nativeDraggable"] && (this["options"]["touchStartThreshold"] = 0x1),
      _0x1bbfb3["supportPointer"]
        ? _0x25f753(_0x50b541, "pointerdown", this["_onTapStart"])
        : (_0x25f753(_0x50b541, "mousedown", this["_onTapStart"]),
          _0x25f753(_0x50b541, "touchstart", this["_onTapStart"])),
      this["nativeDraggable"] &&
        (_0x25f753(_0x50b541, "dragover", this),
        _0x25f753(_0x50b541, "dragenter", this)),
      _0xd20cce["push"](this["el"]),
      _0x1bbfb3["store"] &&
        _0x1bbfb3["store"]["get"] &&
        this["sort"](_0x1bbfb3["store"]["get"](this) || []),
      _0x35b1a3(
        this,
        (function () {
          var _0x142849,
            _0x29bd7a = [];
          return {
            captureAnimationState: function () {
              ((_0x29bd7a = []),
                this["options"]["animation"] &&
                  []["slice"]
                    ["call"](this["el"]["children"])
                    ["forEach"](function (_0x2a4947) {
                      var _0x5de961, _0x380b01;
                      "none" !== _0x307908(_0x2a4947, "display") &&
                        _0x2a4947 !== _0x1d4300["ghost"] &&
                        (_0x29bd7a["push"]({
                          target: _0x2a4947,
                          rect: _0x156da0(_0x2a4947),
                        }),
                        (_0x5de961 = _0x2826a5(
                          {},
                          _0x29bd7a[_0x29bd7a["length"] - 0x1]["rect"],
                        )),
                        !_0x2a4947["thisAnimationDuration"] ||
                          ((_0x380b01 = _0x9185c4(_0x2a4947, !0x0)) &&
                            ((_0x5de961["top"] -= _0x380b01["f"]),
                            (_0x5de961["left"] -= _0x380b01["e"]))),
                        (_0x2a4947["fromRect"] = _0x5de961));
                    }));
            },
            addAnimationState: function (_0xde06b5) {
              _0x29bd7a["push"](_0xde06b5);
            },
            removeAnimationState: function (_0x3fe222) {
              _0x29bd7a["splice"](
                (function (_0x530d18, _0x4cbeec) {
                  for (var _0x570801 in _0x530d18)
                    if (_0x530d18["hasOwnProperty"](_0x570801)) {
                      for (var _0x10afe8 in _0x4cbeec)
                        if (
                          _0x4cbeec["hasOwnProperty"](_0x10afe8) &&
                          _0x4cbeec[_0x10afe8] ===
                            _0x530d18[_0x570801][_0x10afe8]
                        )
                          return Number(_0x570801);
                    }
                  return -0x1;
                })(_0x29bd7a, { target: _0x3fe222 }),
                0x1,
              );
            },
            animateAll: function (_0x5d773e) {
              var _0xa2799a = this;
              if (!this["options"]["animation"])
                return (
                  clearTimeout(_0x142849),
                  void ("function" == typeof _0x5d773e && _0x5d773e())
                );
              var _0x387178 = !0x1,
                _0x1c5ea3 = 0x0;
              (_0x29bd7a["forEach"](function (_0x3a9276) {
                var _0x58531a = 0x0,
                  _0x5c903e = _0x3a9276["target"],
                  _0x19a8a0 = _0x5c903e["fromRect"],
                  _0x421578 = _0x156da0(_0x5c903e),
                  _0x2e1f4c = _0x5c903e["prevFromRect"],
                  _0x1c9b51 = _0x5c903e["prevToRect"],
                  _0x380056 = _0x3a9276["rect"],
                  _0x3c8192 = _0x9185c4(_0x5c903e, !0x0);
                (_0x3c8192 &&
                  ((_0x421578["top"] -= _0x3c8192["f"]),
                  (_0x421578["left"] -= _0x3c8192["e"])),
                  (_0x5c903e["toRect"] = _0x421578),
                  _0x5c903e["thisAnimationDuration"] &&
                    _0x524c52(_0x2e1f4c, _0x421578) &&
                    !_0x524c52(_0x19a8a0, _0x421578) &&
                    (_0x380056["top"] - _0x421578["top"]) /
                      (_0x380056["left"] - _0x421578["left"]) ==
                      (_0x19a8a0["top"] - _0x421578["top"]) /
                        (_0x19a8a0["left"] - _0x421578["left"]) &&
                    ((_0x3a9276 = _0x380056),
                    (_0x3c8192 = _0x2e1f4c),
                    (_0x2e1f4c = _0x1c9b51),
                    (_0x1c9b51 = _0xa2799a["options"]),
                    (_0x58531a =
                      (Math["sqrt"](
                        Math["pow"](_0x3c8192["top"] - _0x3a9276["top"], 0x2) +
                          Math["pow"](
                            _0x3c8192["left"] - _0x3a9276["left"],
                            0x2,
                          ),
                      ) /
                        Math["sqrt"](
                          Math["pow"](
                            _0x3c8192["top"] - _0x2e1f4c["top"],
                            0x2,
                          ) +
                            Math["pow"](
                              _0x3c8192["left"] - _0x2e1f4c["left"],
                              0x2,
                            ),
                        )) *
                      _0x1c9b51["animation"])),
                  _0x524c52(_0x421578, _0x19a8a0) ||
                    ((_0x5c903e["prevFromRect"] = _0x19a8a0),
                    (_0x5c903e["prevToRect"] = _0x421578),
                    (_0x58531a =
                      _0x58531a || _0xa2799a["options"]["animation"]),
                    _0xa2799a["animate"](
                      _0x5c903e,
                      _0x380056,
                      _0x421578,
                      _0x58531a,
                    )),
                  _0x58531a &&
                    ((_0x387178 = !0x0),
                    (_0x1c5ea3 = Math["max"](_0x1c5ea3, _0x58531a)),
                    clearTimeout(_0x5c903e["animationResetTimer"]),
                    (_0x5c903e["animationResetTimer"] = setTimeout(function () {
                      ((_0x5c903e["animationTime"] = 0x0),
                        (_0x5c903e["prevFromRect"] = null),
                        (_0x5c903e["fromRect"] = null),
                        (_0x5c903e["prevToRect"] = null),
                        (_0x5c903e["thisAnimationDuration"] = null));
                    }, _0x58531a)),
                    (_0x5c903e["thisAnimationDuration"] = _0x58531a)));
              }),
                clearTimeout(_0x142849),
                _0x387178
                  ? (_0x142849 = setTimeout(function () {
                      "function" == typeof _0x5d773e && _0x5d773e();
                    }, _0x1c5ea3))
                  : "function" == typeof _0x5d773e && _0x5d773e(),
                (_0x29bd7a = []));
            },
            animate: function (_0x4c1a58, _0x5d546e, _0x40d686, _0x487e42) {
              var _0x20fb32, _0x57f97a;
              _0x487e42 &&
                (_0x307908(_0x4c1a58, "transition", ""),
                _0x307908(_0x4c1a58, "transform", ""),
                (_0x20fb32 =
                  (_0x57f97a = _0x9185c4(this["el"])) && _0x57f97a["a"]),
                (_0x57f97a = _0x57f97a && _0x57f97a["d"]),
                (_0x20fb32 =
                  (_0x5d546e["left"] - _0x40d686["left"]) / (_0x20fb32 || 0x1)),
                (_0x57f97a =
                  (_0x5d546e["top"] - _0x40d686["top"]) / (_0x57f97a || 0x1)),
                (_0x4c1a58["animatingX"] = !!_0x20fb32),
                (_0x4c1a58["animatingY"] = !!_0x57f97a),
                _0x307908(
                  _0x4c1a58,
                  "transform",
                  "translate3d(" + _0x20fb32 + "px," + _0x57f97a + "px,0)",
                ),
                (this["forRepaintDummy"] = _0x4c1a58["offsetWidth"]),
                _0x307908(
                  _0x4c1a58,
                  "transition",
                  "transform\x20" +
                    _0x487e42 +
                    "ms" +
                    (this["options"]["easing"]
                      ? "\x20" + this["options"]["easing"]
                      : ""),
                ),
                _0x307908(_0x4c1a58, "transform", "translate3d(0,0,0)"),
                "number" == typeof _0x4c1a58["animated"] &&
                  clearTimeout(_0x4c1a58["animated"]),
                (_0x4c1a58["animated"] = setTimeout(function () {
                  (_0x307908(_0x4c1a58, "transition", ""),
                    _0x307908(_0x4c1a58, "transform", ""),
                    (_0x4c1a58["animated"] = !0x1),
                    (_0x4c1a58["animatingX"] = !0x1),
                    (_0x4c1a58["animatingY"] = !0x1));
                }, _0x487e42)));
            },
          };
        })(),
      ));
  }
  function _0x3ffb7a(
    _0x4827d6,
    _0x257458,
    _0x52d124,
    _0x1c9405,
    _0x5f39f9,
    _0x381ba9,
    _0x59bbab,
    _0x5f2bc6,
  ) {
    var _0x15c84c,
      _0x27b5bd = _0x4827d6[_0x2848d7],
      _0x537dc8 = _0x27b5bd["options"]["onMove"];
    return (
      !window["CustomEvent"] || _0x127cc2 || _0x6f6279
        ? (_0x15c84c = document["createEvent"]("Event"))["initEvent"](
            "move",
            !0x0,
            !0x0,
          )
        : (_0x15c84c = new CustomEvent("move", {
            bubbles: !0x0,
            cancelable: !0x0,
          })),
      (_0x15c84c["to"] = _0x257458),
      (_0x15c84c["from"] = _0x4827d6),
      (_0x15c84c["dragged"] = _0x52d124),
      (_0x15c84c["draggedRect"] = _0x1c9405),
      (_0x15c84c["related"] = _0x5f39f9 || _0x257458),
      (_0x15c84c["relatedRect"] = _0x381ba9 || _0x156da0(_0x257458)),
      (_0x15c84c["willInsertAfter"] = _0x5f2bc6),
      (_0x15c84c["originalEvent"] = _0x59bbab),
      _0x4827d6["dispatchEvent"](_0x15c84c),
      _0x537dc8 ? _0x537dc8["call"](_0x27b5bd, _0x15c84c, _0x59bbab) : undefined
    );
  }
  function _0x28f66e(_0x153de1) {
    _0x153de1["draggable"] = !0x1;
  }
  function _0x4a57a2() {
    _0x5237f9 = !0x1;
  }
  function _0x158053(_0x56022a) {
    return setTimeout(_0x56022a, 0x0);
  }
  function _0x2c8d3e(_0x301823) {
    return clearTimeout(_0x301823);
  }
  ((_0x1d4300["prototype"] = {
    constructor: _0x1d4300,
    _isOutsideThisEl: function (_0x3691b9) {
      this["el"]["contains"](_0x3691b9) ||
        _0x3691b9 === this["el"] ||
        (_0x15d8bc = null);
    },
    _getDirection: function (_0xea260e, _0x1a48e9) {
      return "function" == typeof this["options"]["direction"]
        ? this["options"]["direction"]["call"](
            this,
            _0xea260e,
            _0x1a48e9,
            _0x4c8404,
          )
        : this["options"]["direction"];
    },
    _onTapStart: function (_0x2806e5) {
      if (_0x2806e5["cancelable"]) {
        var _0x28525b = this,
          _0x259f57 = this["el"],
          _0x59627f = this["options"],
          _0x3d2d78 = _0x59627f["preventOnFilter"],
          _0x295e13 = _0x2806e5["type"],
          _0x17d537 =
            (_0x2806e5["touches"] && _0x2806e5["touches"][0x0]) ||
            (_0x2806e5["pointerType"] &&
              "touch" === _0x2806e5["pointerType"] &&
              _0x2806e5),
          _0x3cdea0 = (_0x17d537 || _0x2806e5)["target"],
          _0x10a5a7 =
            (_0x2806e5["target"]["shadowRoot"] &&
              ((_0x2806e5["path"] && _0x2806e5["path"][0x0]) ||
                (_0x2806e5["composedPath"] &&
                  _0x2806e5["composedPath"]()[0x0]))) ||
            _0x3cdea0,
          _0x16f730 = _0x59627f["filter"];
        if (
          ((function (_0x5003d3) {
            _0x48c6c5["length"] = 0x0;
            var _0x176f5d = _0x5003d3["getElementsByTagName"]("input"),
              _0x435f2e = _0x176f5d["length"];
            for (; _0x435f2e--; ) {
              var _0x358fbc = _0x176f5d[_0x435f2e];
              _0x358fbc["checked"] && _0x48c6c5["push"](_0x358fbc);
            }
          })(_0x259f57),
          !_0x4c8404 &&
            !(
              (/mousedown|pointerdown/["test"](_0x295e13) &&
                0x0 !== _0x2806e5["button"]) ||
              _0x59627f["disabled"]
            ) &&
            !_0x10a5a7["isContentEditable"] &&
            (this["nativeDraggable"] ||
              !_0x1e8f4e ||
              !_0x3cdea0 ||
              "SELECT" !== _0x3cdea0["tagName"]["toUpperCase"]()) &&
            !(
              ((_0x3cdea0 = _0x460dec(
                _0x3cdea0,
                _0x59627f["draggable"],
                _0x259f57,
                !0x1,
              )) &&
                _0x3cdea0["animated"]) ||
              _0x5b9424 === _0x3cdea0
            ))
        ) {
          if (
            ((_0x369c7c = _0x5085eb(_0x3cdea0)),
            (_0x292c3c = _0x5085eb(_0x3cdea0, _0x59627f["draggable"])),
            "function" == typeof _0x16f730)
          ) {
            if (_0x16f730["call"](this, _0x2806e5, _0x3cdea0, this))
              return (
                _0x1c8304({
                  sortable: _0x28525b,
                  rootEl: _0x10a5a7,
                  name: "filter",
                  targetEl: _0x3cdea0,
                  toEl: _0x259f57,
                  fromEl: _0x259f57,
                }),
                _0x338aab("filter", _0x28525b, { evt: _0x2806e5 }),
                void (
                  _0x3d2d78 &&
                  _0x2806e5["cancelable"] &&
                  _0x2806e5["preventDefault"]()
                )
              );
          } else {
            if (
              (_0x16f730 =
                _0x16f730 &&
                _0x16f730["split"](",")["some"](function (_0x357e9c) {
                  if (
                    (_0x357e9c = _0x460dec(
                      _0x10a5a7,
                      _0x357e9c["trim"](),
                      _0x259f57,
                      !0x1,
                    ))
                  )
                    return (
                      _0x1c8304({
                        sortable: _0x28525b,
                        rootEl: _0x357e9c,
                        name: "filter",
                        targetEl: _0x3cdea0,
                        fromEl: _0x259f57,
                        toEl: _0x259f57,
                      }),
                      _0x338aab("filter", _0x28525b, { evt: _0x2806e5 }),
                      !0x0
                    );
                }))
            )
              return void (
                _0x3d2d78 &&
                _0x2806e5["cancelable"] &&
                _0x2806e5["preventDefault"]()
              );
          }
          (_0x59627f["handle"] &&
            !_0x460dec(_0x10a5a7, _0x59627f["handle"], _0x259f57, !0x1)) ||
            this["_prepareDragStart"](_0x2806e5, _0x17d537, _0x3cdea0);
        }
      }
    },
    _prepareDragStart: function (_0x5ce150, _0x2f636b, _0x8a4fe2) {
      var _0x3c8865,
        _0xe240a = this,
        _0x18553d = _0xe240a["el"],
        _0x194a05 = _0xe240a["options"],
        _0x1bc0db = _0x18553d["ownerDocument"];
      _0x8a4fe2 &&
        !_0x4c8404 &&
        _0x8a4fe2["parentNode"] === _0x18553d &&
        ((_0x3c8865 = _0x156da0(_0x8a4fe2)),
        (_0x3a1157 = _0x18553d),
        (_0x150448 = (_0x4c8404 = _0x8a4fe2)["parentNode"]),
        (_0x3122f4 = _0x4c8404["nextSibling"]),
        (_0x5b9424 = _0x8a4fe2),
        (_0x2a49d0 = _0x194a05["group"]),
        (_0x1d3175 = {
          target: (_0x1d4300["dragged"] = _0x4c8404),
          clientX: (_0x2f636b || _0x5ce150)["clientX"],
          clientY: (_0x2f636b || _0x5ce150)["clientY"],
        }),
        (_0x572bcd = _0x1d3175["clientX"] - _0x3c8865["left"]),
        (_0x125e6a = _0x1d3175["clientY"] - _0x3c8865["top"]),
        (this["_lastX"] = (_0x2f636b || _0x5ce150)["clientX"]),
        (this["_lastY"] = (_0x2f636b || _0x5ce150)["clientY"]),
        (_0x4c8404["style"]["will-change"] = "all"),
        (_0x3c8865 = function () {
          (_0x338aab("delayEnded", _0xe240a, { evt: _0x5ce150 }),
            _0x1d4300["eventCanceled"]
              ? _0xe240a["_onDrop"]()
              : (_0xe240a["_disableDelayedDragEvents"](),
                !_0x1cf95c &&
                  _0xe240a["nativeDraggable"] &&
                  (_0x4c8404["draggable"] = !0x0),
                _0xe240a["_triggerDragStart"](_0x5ce150, _0x2f636b),
                _0x1c8304({
                  sortable: _0xe240a,
                  name: "choose",
                  originalEvent: _0x5ce150,
                }),
                _0x42f20d(_0x4c8404, _0x194a05["chosenClass"], !0x0)));
        }),
        _0x194a05["ignore"]["split"](",")["forEach"](function (_0x39fb64) {
          _0x5145cb(_0x4c8404, _0x39fb64["trim"](), _0x28f66e);
        }),
        _0x25f753(_0x1bc0db, "dragover", _0x562723),
        _0x25f753(_0x1bc0db, "mousemove", _0x562723),
        _0x25f753(_0x1bc0db, "touchmove", _0x562723),
        _0x25f753(_0x1bc0db, "mouseup", _0xe240a["_onDrop"]),
        _0x25f753(_0x1bc0db, "touchend", _0xe240a["_onDrop"]),
        _0x25f753(_0x1bc0db, "touchcancel", _0xe240a["_onDrop"]),
        _0x1cf95c &&
          this["nativeDraggable"] &&
          ((this["options"]["touchStartThreshold"] = 0x4),
          (_0x4c8404["draggable"] = !0x0)),
        _0x338aab("delayStart", this, { evt: _0x5ce150 }),
        !_0x194a05["delay"] ||
        (_0x194a05["delayOnTouchOnly"] && !_0x2f636b) ||
        (this["nativeDraggable"] && (_0x6f6279 || _0x127cc2))
          ? _0x3c8865()
          : _0x1d4300["eventCanceled"]
            ? this["_onDrop"]()
            : (_0x25f753(_0x1bc0db, "mouseup", _0xe240a["_disableDelayedDrag"]),
              _0x25f753(_0x1bc0db, "touchend", _0xe240a["_disableDelayedDrag"]),
              _0x25f753(
                _0x1bc0db,
                "touchcancel",
                _0xe240a["_disableDelayedDrag"],
              ),
              _0x25f753(
                _0x1bc0db,
                "mousemove",
                _0xe240a["_delayedDragTouchMoveHandler"],
              ),
              _0x25f753(
                _0x1bc0db,
                "touchmove",
                _0xe240a["_delayedDragTouchMoveHandler"],
              ),
              _0x194a05["supportPointer"] &&
                _0x25f753(
                  _0x1bc0db,
                  "pointermove",
                  _0xe240a["_delayedDragTouchMoveHandler"],
                ),
              (_0xe240a["_dragStartTimer"] = setTimeout(
                _0x3c8865,
                _0x194a05["delay"],
              ))));
    },
    _delayedDragTouchMoveHandler: function (_0x3ec5ea) {
      ((_0x3ec5ea = _0x3ec5ea["touches"]
        ? _0x3ec5ea["touches"][0x0]
        : _0x3ec5ea),
        Math["max"](
          Math["abs"](_0x3ec5ea["clientX"] - this["_lastX"]),
          Math["abs"](_0x3ec5ea["clientY"] - this["_lastY"]),
        ) >=
          Math["floor"](
            this["options"]["touchStartThreshold"] /
              ((this["nativeDraggable"] && window["devicePixelRatio"]) || 0x1),
          ) && this["_disableDelayedDrag"]());
    },
    _disableDelayedDrag: function () {
      (_0x4c8404 && _0x28f66e(_0x4c8404),
        clearTimeout(this["_dragStartTimer"]),
        this["_disableDelayedDragEvents"]());
    },
    _disableDelayedDragEvents: function () {
      var _0x4c2144 = this["el"]["ownerDocument"];
      (_0x5ec097(_0x4c2144, "mouseup", this["_disableDelayedDrag"]),
        _0x5ec097(_0x4c2144, "touchend", this["_disableDelayedDrag"]),
        _0x5ec097(_0x4c2144, "touchcancel", this["_disableDelayedDrag"]),
        _0x5ec097(_0x4c2144, "mousemove", this["_delayedDragTouchMoveHandler"]),
        _0x5ec097(_0x4c2144, "touchmove", this["_delayedDragTouchMoveHandler"]),
        _0x5ec097(
          _0x4c2144,
          "pointermove",
          this["_delayedDragTouchMoveHandler"],
        ));
    },
    _triggerDragStart: function (_0x48457d, _0x47f49d) {
      ((_0x47f49d =
        _0x47f49d || ("touch" == _0x48457d["pointerType"] && _0x48457d)),
        !this["nativeDraggable"] || _0x47f49d
          ? this["options"]["supportPointer"]
            ? _0x25f753(document, "pointermove", this["_onTouchMove"])
            : _0x25f753(
                document,
                _0x47f49d ? "touchmove" : "mousemove",
                this["_onTouchMove"],
              )
          : (_0x25f753(_0x4c8404, "dragend", this),
            _0x25f753(_0x3a1157, "dragstart", this["_onDragStart"])));
      try {
        document["selection"]
          ? _0x158053(function () {
              document["selection"]["empty"]();
            })
          : window["getSelection"]()["removeAllRanges"]();
      } catch (_0x5e5fe7) {}
    },
    _dragStarted: function (_0x5a4f97, _0x4dd19f) {
      var _0x517ed3;
      ((_0x55ee58 = !0x1),
        _0x3a1157 && _0x4c8404
          ? (_0x338aab("dragStarted", this, { evt: _0x4dd19f }),
            this["nativeDraggable"] &&
              _0x25f753(document, "dragover", _0xea0740),
            (_0x517ed3 = this["options"]),
            _0x5a4f97 || _0x42f20d(_0x4c8404, _0x517ed3["dragClass"], !0x1),
            _0x42f20d(_0x4c8404, _0x517ed3["ghostClass"], !0x0),
            (_0x1d4300["active"] = this),
            _0x5a4f97 && this["_appendGhost"](),
            _0x1c8304({
              sortable: this,
              name: "start",
              originalEvent: _0x4dd19f,
            }))
          : this["_nulling"]());
    },
    _emulateDragOver: function () {
      if (_0x360dc8) {
        ((this["_lastX"] = _0x360dc8["clientX"]),
          (this["_lastY"] = _0x360dc8["clientY"]),
          _0x5d4fc1());
        for (
          var _0x3461d0 = document["elementFromPoint"](
              _0x360dc8["clientX"],
              _0x360dc8["clientY"],
            ),
            _0x2cc460 = _0x3461d0;
          _0x3461d0 &&
          _0x3461d0["shadowRoot"] &&
          (_0x3461d0 = _0x3461d0["shadowRoot"]["elementFromPoint"](
            _0x360dc8["clientX"],
            _0x360dc8["clientY"],
          )) !== _0x2cc460;

        )
          _0x2cc460 = _0x3461d0;
        if (
          (_0x4c8404["parentNode"][_0x2848d7]["_isOutsideThisEl"](_0x3461d0),
          _0x2cc460)
        )
          do {
            if (
              _0x2cc460[_0x2848d7] &&
              _0x2cc460[_0x2848d7]["_onDragOver"]({
                clientX: _0x360dc8["clientX"],
                clientY: _0x360dc8["clientY"],
                target: _0x3461d0,
                rootEl: _0x2cc460,
              }) &&
              !this["options"]["dragoverBubble"]
            )
              break;
          } while ((_0x2cc460 = (_0x3461d0 = _0x2cc460)["parentNode"]));
        _0x420b67();
      }
    },
    _onTouchMove: function (_0xca62d) {
      if (_0x1d3175) {
        var _0x4060f7 = (_0x5ad098 = this["options"])["fallbackTolerance"],
          _0x54af93 = _0x5ad098["fallbackOffset"],
          _0x5c52dd = _0xca62d["touches"] ? _0xca62d["touches"][0x0] : _0xca62d,
          _0x49deff = _0x52d46f && _0x9185c4(_0x52d46f, !0x0),
          _0x274b2e = _0x52d46f && _0x49deff && _0x49deff["a"],
          _0x574476 = _0x52d46f && _0x49deff && _0x49deff["d"],
          _0x5ad098 = _0x274a64 && _0x11e334 && _0x1e26ad(_0x11e334);
        ((_0x274b2e =
          (_0x5c52dd["clientX"] - _0x1d3175["clientX"] + _0x54af93["x"]) /
            (_0x274b2e || 0x1) +
          (_0x5ad098 ? _0x5ad098[0x0] - _0x1b4f9a[0x0] : 0x0) /
            (_0x274b2e || 0x1)),
          (_0x574476 =
            (_0x5c52dd["clientY"] - _0x1d3175["clientY"] + _0x54af93["y"]) /
              (_0x574476 || 0x1) +
            (_0x5ad098 ? _0x5ad098[0x1] - _0x1b4f9a[0x1] : 0x0) /
              (_0x574476 || 0x1)));
        if (!_0x1d4300["active"] && !_0x55ee58) {
          if (
            _0x4060f7 &&
            Math["max"](
              Math["abs"](_0x5c52dd["clientX"] - this["_lastX"]),
              Math["abs"](_0x5c52dd["clientY"] - this["_lastY"]),
            ) < _0x4060f7
          )
            return;
          this["_onDragStart"](_0xca62d, !0x0);
        }
        (_0x52d46f &&
          (_0x49deff
            ? ((_0x49deff["e"] += _0x274b2e - (_0x2686bf || 0x0)),
              (_0x49deff["f"] += _0x574476 - (_0x195f1e || 0x0)))
            : (_0x49deff = {
                a: 0x1,
                b: 0x0,
                c: 0x0,
                d: 0x1,
                e: _0x274b2e,
                f: _0x574476,
              }),
          (_0x49deff = "matrix("
            ["concat"](_0x49deff["a"], ",")
            ["concat"](_0x49deff["b"], ",")
            ["concat"](_0x49deff["c"], ",")
            ["concat"](_0x49deff["d"], ",")
            ["concat"](_0x49deff["e"], ",")
            ["concat"](_0x49deff["f"], ")")),
          _0x307908(_0x52d46f, "webkitTransform", _0x49deff),
          _0x307908(_0x52d46f, "mozTransform", _0x49deff),
          _0x307908(_0x52d46f, "msTransform", _0x49deff),
          _0x307908(_0x52d46f, "transform", _0x49deff),
          (_0x2686bf = _0x274b2e),
          (_0x195f1e = _0x574476),
          (_0x360dc8 = _0x5c52dd)),
          _0xca62d["cancelable"] && _0xca62d["preventDefault"]());
      }
    },
    _appendGhost: function () {
      if (!_0x52d46f) {
        var _0x29938f = this["options"]["fallbackOnBody"]
            ? document["body"]
            : _0x3a1157,
          _0x2e7686 = _0x156da0(_0x4c8404, !0x0, _0x274a64, !0x0, _0x29938f),
          _0x248e9e = this["options"];
        if (_0x274a64) {
          for (
            _0x11e334 = _0x29938f;
            "static" === _0x307908(_0x11e334, "position") &&
            "none" === _0x307908(_0x11e334, "transform") &&
            _0x11e334 !== document;

          )
            _0x11e334 = _0x11e334["parentNode"];
          (_0x11e334 !== document["body"] &&
          _0x11e334 !== document["documentElement"]
            ? (_0x11e334 === document && (_0x11e334 = _0x23897c()),
              (_0x2e7686["top"] += _0x11e334["scrollTop"]),
              (_0x2e7686["left"] += _0x11e334["scrollLeft"]))
            : (_0x11e334 = _0x23897c()),
            (_0x1b4f9a = _0x1e26ad(_0x11e334)));
        }
        (_0x42f20d(
          (_0x52d46f = _0x4c8404["cloneNode"](!0x0)),
          _0x248e9e["ghostClass"],
          !0x1,
        ),
          _0x42f20d(_0x52d46f, _0x248e9e["fallbackClass"], !0x0),
          _0x42f20d(_0x52d46f, _0x248e9e["dragClass"], !0x0),
          _0x307908(_0x52d46f, "transition", ""),
          _0x307908(_0x52d46f, "transform", ""),
          _0x307908(_0x52d46f, "box-sizing", "border-box"),
          _0x307908(_0x52d46f, "margin", 0x0),
          _0x307908(_0x52d46f, "top", _0x2e7686["top"]),
          _0x307908(_0x52d46f, "left", _0x2e7686["left"]),
          _0x307908(_0x52d46f, "width", _0x2e7686["width"]),
          _0x307908(_0x52d46f, "height", _0x2e7686["height"]),
          _0x307908(_0x52d46f, "opacity", "0.8"),
          _0x307908(_0x52d46f, "position", _0x274a64 ? "absolute" : "fixed"),
          _0x307908(_0x52d46f, "zIndex", "100000"),
          _0x307908(_0x52d46f, "pointerEvents", "none"),
          (_0x1d4300["ghost"] = _0x52d46f),
          _0x29938f["appendChild"](_0x52d46f),
          _0x307908(
            _0x52d46f,
            "transform-origin",
            (_0x572bcd / parseInt(_0x52d46f["style"]["width"])) * 0x64 +
              "%\x20" +
              (_0x125e6a / parseInt(_0x52d46f["style"]["height"])) * 0x64 +
              "%",
          ));
      }
    },
    _onDragStart: function (_0x1e8764, _0x3620c9) {
      var _0x40e22f = this,
        _0x354a57 = _0x1e8764["dataTransfer"],
        _0x4c821c = _0x40e22f["options"];
      (_0x338aab("dragStart", this, { evt: _0x1e8764 }),
        _0x1d4300["eventCanceled"]
          ? this["_onDrop"]()
          : (_0x338aab("setupClone", this),
            _0x1d4300["eventCanceled"] ||
              (((_0x32a4c0 = _0x3e007f(_0x4c8404))["draggable"] = !0x1),
              (_0x32a4c0["style"]["will-change"] = ""),
              this["_hideClone"](),
              _0x42f20d(_0x32a4c0, this["options"]["chosenClass"], !0x1),
              (_0x1d4300["clone"] = _0x32a4c0)),
            (_0x40e22f["cloneId"] = _0x158053(function () {
              (_0x338aab("clone", _0x40e22f),
                _0x1d4300["eventCanceled"] ||
                  (_0x40e22f["options"]["removeCloneOnHide"] ||
                    _0x3a1157["insertBefore"](_0x32a4c0, _0x4c8404),
                  _0x40e22f["_hideClone"](),
                  _0x1c8304({ sortable: _0x40e22f, name: "clone" })));
            })),
            _0x3620c9 || _0x42f20d(_0x4c8404, _0x4c821c["dragClass"], !0x0),
            _0x3620c9
              ? ((_0x138e44 = !0x0),
                (_0x40e22f["_loopId"] = setInterval(
                  _0x40e22f["_emulateDragOver"],
                  0x32,
                )))
              : (_0x5ec097(document, "mouseup", _0x40e22f["_onDrop"]),
                _0x5ec097(document, "touchend", _0x40e22f["_onDrop"]),
                _0x5ec097(document, "touchcancel", _0x40e22f["_onDrop"]),
                _0x354a57 &&
                  ((_0x354a57["effectAllowed"] = "move"),
                  _0x4c821c["setData"] &&
                    _0x4c821c["setData"]["call"](
                      _0x40e22f,
                      _0x354a57,
                      _0x4c8404,
                    )),
                _0x25f753(document, "drop", _0x40e22f),
                _0x307908(_0x4c8404, "transform", "translateZ(0)")),
            (_0x55ee58 = !0x0),
            (_0x40e22f["_dragStartId"] = _0x158053(
              _0x40e22f["_dragStarted"]["bind"](
                _0x40e22f,
                _0x3620c9,
                _0x1e8764,
              ),
            )),
            _0x25f753(document, "selectstart", _0x40e22f),
            (_0x19e098 = !0x0),
            _0x1e8f4e && _0x307908(document["body"], "user-select", "none")));
    },
    _onDragOver: function (_0x354211) {
      var _0x3d3b3e,
        _0x58c3d3,
        _0x5ae7c2,
        _0xa111c4,
        _0x1795fb = this["el"],
        _0x34d6ea = _0x354211["target"],
        _0x2e8090 = this["options"],
        _0x3f6d1b = _0x2e8090["group"],
        _0x50042d = _0x1d4300["active"],
        _0x348763 = _0x2a49d0 === _0x3f6d1b,
        _0x185071 = _0x2e8090["sort"],
        _0x537794 = _0x40fc4e || _0x50042d,
        _0x1aab6d = this,
        _0x47a4f9 = !0x1;
      if (!_0x5237f9) {
        if (
          (void 0x0 !== _0x354211["preventDefault"] &&
            _0x354211["cancelable"] &&
            _0x354211["preventDefault"](),
          (_0x34d6ea = _0x460dec(
            _0x34d6ea,
            _0x2e8090["draggable"],
            _0x1795fb,
            !0x0,
          )),
          _0x319c58("dragOver"),
          _0x1d4300["eventCanceled"])
        )
          return _0x47a4f9;
        if (
          _0x4c8404["contains"](_0x354211["target"]) ||
          (_0x34d6ea["animated"] &&
            _0x34d6ea["animatingX"] &&
            _0x34d6ea["animatingY"]) ||
          _0x1aab6d["_ignoreWhileAnimating"] === _0x34d6ea
        )
          return _0x4a936c(!0x1);
        if (
          ((_0x138e44 = !0x1),
          _0x50042d &&
            !_0x2e8090["disabled"] &&
            (_0x348763
              ? _0x185071 || (_0x58c3d3 = _0x150448 !== _0x3a1157)
              : _0x40fc4e === this ||
                ((this["lastPutMode"] = _0x2a49d0["checkPull"](
                  this,
                  _0x50042d,
                  _0x4c8404,
                  _0x354211,
                )) &&
                  _0x3f6d1b["checkPut"](
                    this,
                    _0x50042d,
                    _0x4c8404,
                    _0x354211,
                  ))))
        ) {
          if (
            ((_0x5ae7c2 =
              "vertical" === this["_getDirection"](_0x354211, _0x34d6ea)),
            (_0x3d3b3e = _0x156da0(_0x4c8404)),
            _0x319c58("dragOverValid"),
            _0x1d4300["eventCanceled"])
          )
            return _0x47a4f9;
          if (_0x58c3d3)
            return (
              (_0x150448 = _0x3a1157),
              _0x5dc972(),
              this["_hideClone"](),
              _0x319c58("revert"),
              _0x1d4300["eventCanceled"] ||
                (_0x3122f4
                  ? _0x3a1157["insertBefore"](_0x4c8404, _0x3122f4)
                  : _0x3a1157["appendChild"](_0x4c8404)),
              _0x4a936c(!0x0)
            );
          if (
            !(_0x4e03db = _0x58f526(_0x1795fb, _0x2e8090["draggable"])) ||
            ((function (_0x2fd14b, _0x2f28d3, _0x772d7b) {
              return (
                (_0x772d7b = _0x156da0(
                  _0x58f526(_0x772d7b["el"], _0x772d7b["options"]["draggable"]),
                )),
                _0x2f28d3
                  ? _0x2fd14b["clientX"] > _0x772d7b["right"] + 0xa ||
                    (_0x2fd14b["clientX"] <= _0x772d7b["right"] &&
                      _0x2fd14b["clientY"] > _0x772d7b["bottom"] &&
                      _0x2fd14b["clientX"] >= _0x772d7b["left"])
                  : (_0x2fd14b["clientX"] > _0x772d7b["right"] &&
                      _0x2fd14b["clientY"] > _0x772d7b["top"]) ||
                    (_0x2fd14b["clientX"] <= _0x772d7b["right"] &&
                      _0x2fd14b["clientY"] > _0x772d7b["bottom"] + 0xa)
              );
            })(_0x354211, _0x5ae7c2, this) &&
              !_0x4e03db["animated"])
          ) {
            if (_0x4e03db === _0x4c8404) return _0x4a936c(!0x1);
            if (
              ((_0x34d6ea =
                _0x4e03db && _0x1795fb === _0x354211["target"]
                  ? _0x4e03db
                  : _0x34d6ea) && (_0x399e1e = _0x156da0(_0x34d6ea)),
              !0x1 !==
                _0x3ffb7a(
                  _0x3a1157,
                  _0x1795fb,
                  _0x4c8404,
                  _0x3d3b3e,
                  _0x34d6ea,
                  _0x399e1e,
                  _0x354211,
                  !!_0x34d6ea,
                ))
            )
              return (
                _0x5dc972(),
                _0x1795fb["appendChild"](_0x4c8404),
                (_0x150448 = _0x1795fb),
                _0x478498(),
                _0x4a936c(!0x0)
              );
          } else {
            if (
              _0x4e03db &&
              (function (_0x5f67e8, _0x122651, _0x6da76c) {
                return (
                  (_0x6da76c = _0x156da0(
                    _0x350cbb(_0x6da76c["el"], 0x0, _0x6da76c["options"], !0x0),
                  )),
                  _0x122651
                    ? _0x5f67e8["clientX"] < _0x6da76c["left"] - 0xa ||
                      (_0x5f67e8["clientY"] < _0x6da76c["top"] &&
                        _0x5f67e8["clientX"] < _0x6da76c["right"])
                    : _0x5f67e8["clientY"] < _0x6da76c["top"] - 0xa ||
                      (_0x5f67e8["clientY"] < _0x6da76c["bottom"] &&
                        _0x5f67e8["clientX"] < _0x6da76c["left"])
                );
              })(_0x354211, _0x5ae7c2, this)
            ) {
              if (
                (_0x711db4 = _0x350cbb(_0x1795fb, 0x0, _0x2e8090, !0x0)) ===
                _0x4c8404
              )
                return _0x4a936c(!0x1);
              if (
                ((_0x399e1e = _0x156da0((_0x34d6ea = _0x711db4))),
                !0x1 !==
                  _0x3ffb7a(
                    _0x3a1157,
                    _0x1795fb,
                    _0x4c8404,
                    _0x3d3b3e,
                    _0x34d6ea,
                    _0x399e1e,
                    _0x354211,
                    !0x1,
                  ))
              )
                return (
                  _0x5dc972(),
                  _0x1795fb["insertBefore"](_0x4c8404, _0x711db4),
                  (_0x150448 = _0x1795fb),
                  _0x478498(),
                  _0x4a936c(!0x0)
                );
            } else {
              if (_0x34d6ea["parentNode"] === _0x1795fb) {
                var _0x4ea27f,
                  _0x39f1d7,
                  _0x2eb9a5,
                  _0x4e03db,
                  _0x399e1e = _0x156da0(_0x34d6ea),
                  _0x1ad57e = _0x4c8404["parentNode"] !== _0x1795fb,
                  _0x2dfc52 =
                    ((_0x2dfc52 =
                      (_0x4c8404["animated"] && _0x4c8404["toRect"]) ||
                      _0x3d3b3e),
                    (_0x5ef92b =
                      (_0x34d6ea["animated"] && _0x34d6ea["toRect"]) ||
                      _0x399e1e),
                    (_0x102175 = (_0xa111c4 = _0x5ae7c2)
                      ? _0x2dfc52["left"]
                      : _0x2dfc52["top"]),
                    (_0x3f6d1b = _0xa111c4
                      ? _0x2dfc52["right"]
                      : _0x2dfc52["bottom"]),
                    (_0x4e03db = _0xa111c4
                      ? _0x2dfc52["width"]
                      : _0x2dfc52["height"]),
                    (_0x711db4 = _0xa111c4
                      ? _0x5ef92b["left"]
                      : _0x5ef92b["top"]),
                    (_0x2dfc52 = _0xa111c4
                      ? _0x5ef92b["right"]
                      : _0x5ef92b["bottom"]),
                    (_0x5ef92b = _0xa111c4
                      ? _0x5ef92b["width"]
                      : _0x5ef92b["height"]),
                    !(
                      _0x102175 === _0x711db4 ||
                      _0x3f6d1b === _0x2dfc52 ||
                      _0x102175 + _0x4e03db / 0x2 ===
                        _0x711db4 + _0x5ef92b / 0x2
                    )),
                  _0x102175 = _0x5ae7c2 ? "top" : "left",
                  _0x711db4 = (_0x4e03db =
                    _0x1c4eb3(_0x34d6ea, "top", "top") ||
                    _0x1c4eb3(_0x4c8404, "top", "top"))
                    ? _0x4e03db["scrollTop"]
                    : void 0x0;
                if (
                  (_0x15d8bc !== _0x34d6ea &&
                    ((_0x39f1d7 = _0x399e1e[_0x102175]),
                    (_0x11aa71 = !0x1),
                    (_0x5597e6 =
                      (!_0x2dfc52 && _0x2e8090["invertSwap"]) || _0x1ad57e)),
                  0x0 !==
                    (_0x4ea27f = (function (
                      _0x501431,
                      _0x44532a,
                      _0x4dcadf,
                      _0x24448c,
                      _0x1a9680,
                      _0x2f1a1c,
                      _0x8f1df0,
                      _0x542297,
                    ) {
                      var _0x5c3f66 = _0x24448c
                          ? _0x501431["clientY"]
                          : _0x501431["clientX"],
                        _0x30b001 = _0x24448c
                          ? _0x4dcadf["height"]
                          : _0x4dcadf["width"];
                      ((_0x501431 = _0x24448c
                        ? _0x4dcadf["top"]
                        : _0x4dcadf["left"]),
                        (_0x24448c = _0x24448c
                          ? _0x4dcadf["bottom"]
                          : _0x4dcadf["right"]),
                        (_0x4dcadf = !0x1));
                      if (!_0x8f1df0) {
                        if (_0x542297 && _0x97e304 < _0x30b001 * _0x1a9680) {
                          if (
                            (_0x11aa71 =
                              (!_0x11aa71 &&
                                (0x1 === _0x28ce9e
                                  ? _0x501431 + (_0x30b001 * _0x2f1a1c) / 0x2 <
                                    _0x5c3f66
                                  : _0x5c3f66 <
                                    _0x24448c -
                                      (_0x30b001 * _0x2f1a1c) / 0x2)) ||
                              _0x11aa71)
                          )
                            _0x4dcadf = !0x0;
                          else {
                            if (
                              0x1 === _0x28ce9e
                                ? _0x5c3f66 < _0x501431 + _0x97e304
                                : _0x24448c - _0x97e304 < _0x5c3f66
                            )
                              return -_0x28ce9e;
                          }
                        } else {
                          if (
                            _0x501431 + (_0x30b001 * (0x1 - _0x1a9680)) / 0x2 <
                              _0x5c3f66 &&
                            _0x5c3f66 <
                              _0x24448c - (_0x30b001 * (0x1 - _0x1a9680)) / 0x2
                          )
                            return (function (_0x3b7ba3) {
                              return _0x5085eb(_0x4c8404) < _0x5085eb(_0x3b7ba3)
                                ? 0x1
                                : -0x1;
                            })(_0x44532a);
                        }
                      }
                      return (_0x4dcadf = _0x4dcadf || _0x8f1df0) &&
                        (_0x5c3f66 <
                          _0x501431 + (_0x30b001 * _0x2f1a1c) / 0x2 ||
                          _0x24448c - (_0x30b001 * _0x2f1a1c) / 0x2 < _0x5c3f66)
                        ? _0x501431 + _0x30b001 / 0x2 < _0x5c3f66
                          ? 0x1
                          : -0x1
                        : 0x0;
                    })(
                      _0x354211,
                      _0x34d6ea,
                      _0x399e1e,
                      _0x5ae7c2,
                      _0x2dfc52 ? 0x1 : _0x2e8090["swapThreshold"],
                      null == _0x2e8090["invertedSwapThreshold"]
                        ? _0x2e8090["swapThreshold"]
                        : _0x2e8090["invertedSwapThreshold"],
                      _0x5597e6,
                      _0x15d8bc === _0x34d6ea,
                    )))
                ) {
                  for (
                    var _0x501973 = _0x5085eb(_0x4c8404);
                    (_0x2eb9a5 =
                      _0x150448["children"][(_0x501973 -= _0x4ea27f)]) &&
                    ("none" === _0x307908(_0x2eb9a5, "display") ||
                      _0x2eb9a5 === _0x52d46f);

                  );
                }
                if (0x0 === _0x4ea27f || _0x2eb9a5 === _0x34d6ea)
                  return _0x4a936c(!0x1);
                _0x28ce9e = _0x4ea27f;
                var _0x5ef92b = (_0x15d8bc = _0x34d6ea)["nextElementSibling"];
                _0x1ad57e = !0x1;
                if (
                  !0x1 !==
                  (_0x2dfc52 = _0x3ffb7a(
                    _0x3a1157,
                    _0x1795fb,
                    _0x4c8404,
                    _0x3d3b3e,
                    _0x34d6ea,
                    _0x399e1e,
                    _0x354211,
                    (_0x1ad57e = 0x1 === _0x4ea27f),
                  ))
                )
                  return (
                    (0x1 !== _0x2dfc52 && -0x1 !== _0x2dfc52) ||
                      (_0x1ad57e = 0x1 === _0x2dfc52),
                    (_0x5237f9 = !0x0),
                    setTimeout(_0x4a57a2, 0x1e),
                    _0x5dc972(),
                    _0x1ad57e && !_0x5ef92b
                      ? _0x1795fb["appendChild"](_0x4c8404)
                      : _0x34d6ea["parentNode"]["insertBefore"](
                          _0x4c8404,
                          _0x1ad57e ? _0x5ef92b : _0x34d6ea,
                        ),
                    _0x4e03db &&
                      _0x2f90a0(
                        _0x4e03db,
                        0x0,
                        _0x711db4 - _0x4e03db["scrollTop"],
                      ),
                    (_0x150448 = _0x4c8404["parentNode"]),
                    void 0x0 === _0x39f1d7 ||
                      _0x5597e6 ||
                      (_0x97e304 = Math["abs"](
                        _0x39f1d7 - _0x156da0(_0x34d6ea)[_0x102175],
                      )),
                    _0x478498(),
                    _0x4a936c(!0x0)
                  );
              }
            }
          }
          if (_0x1795fb["contains"](_0x4c8404)) return _0x4a936c(!0x1);
        }
        return !0x1;
      }
      function _0x319c58(_0x47dff4, _0x436787) {
        _0x338aab(
          _0x47dff4,
          _0x1aab6d,
          _0x2826a5(
            {
              evt: _0x354211,
              isOwner: _0x348763,
              axis: _0x5ae7c2 ? "vertical" : "horizontal",
              revert: _0x58c3d3,
              dragRect: _0x3d3b3e,
              targetRect: _0x399e1e,
              canSort: _0x185071,
              fromSortable: _0x537794,
              target: _0x34d6ea,
              completed: _0x4a936c,
              onMove: function (_0x5662b2, _0x335096) {
                return _0x3ffb7a(
                  _0x3a1157,
                  _0x1795fb,
                  _0x4c8404,
                  _0x3d3b3e,
                  _0x5662b2,
                  _0x156da0(_0x5662b2),
                  _0x354211,
                  _0x335096,
                );
              },
              changed: _0x478498,
            },
            _0x436787,
          ),
        );
      }
      function _0x5dc972() {
        (_0x319c58("dragOverAnimationCapture"),
          _0x1aab6d["captureAnimationState"](),
          _0x1aab6d !== _0x537794 && _0x537794["captureAnimationState"]());
      }
      function _0x4a936c(_0x50183b) {
        return (
          _0x319c58("dragOverCompleted", { insertion: _0x50183b }),
          _0x50183b &&
            (_0x348763
              ? _0x50042d["_hideClone"]()
              : _0x50042d["_showClone"](_0x1aab6d),
            _0x1aab6d !== _0x537794 &&
              (_0x42f20d(
                _0x4c8404,
                (_0x40fc4e || _0x50042d)["options"]["ghostClass"],
                !0x1,
              ),
              _0x42f20d(_0x4c8404, _0x2e8090["ghostClass"], !0x0)),
            _0x40fc4e !== _0x1aab6d && _0x1aab6d !== _0x1d4300["active"]
              ? (_0x40fc4e = _0x1aab6d)
              : _0x1aab6d === _0x1d4300["active"] &&
                _0x40fc4e &&
                (_0x40fc4e = null),
            _0x537794 === _0x1aab6d &&
              (_0x1aab6d["_ignoreWhileAnimating"] = _0x34d6ea),
            _0x1aab6d["animateAll"](function () {
              (_0x319c58("dragOverAnimationComplete"),
                (_0x1aab6d["_ignoreWhileAnimating"] = null));
            }),
            _0x1aab6d !== _0x537794 &&
              (_0x537794["animateAll"](),
              (_0x537794["_ignoreWhileAnimating"] = null))),
          ((_0x34d6ea === _0x4c8404 && !_0x4c8404["animated"]) ||
            (_0x34d6ea === _0x1795fb && !_0x34d6ea["animated"])) &&
            (_0x15d8bc = null),
          _0x2e8090["dragoverBubble"] ||
            _0x354211["rootEl"] ||
            _0x34d6ea === document ||
            (_0x4c8404["parentNode"][_0x2848d7]["_isOutsideThisEl"](
              _0x354211["target"],
            ),
            _0x50183b || _0x562723(_0x354211)),
          !_0x2e8090["dragoverBubble"] &&
            _0x354211["stopPropagation"] &&
            _0x354211["stopPropagation"](),
          (_0x47a4f9 = !0x0)
        );
      }
      function _0x478498() {
        ((_0xf8d987 = _0x5085eb(_0x4c8404)),
          (_0xfc74fa = _0x5085eb(_0x4c8404, _0x2e8090["draggable"])),
          _0x1c8304({
            sortable: _0x1aab6d,
            name: "change",
            toEl: _0x1795fb,
            newIndex: _0xf8d987,
            newDraggableIndex: _0xfc74fa,
            originalEvent: _0x354211,
          }));
      }
    },
    _ignoreWhileAnimating: null,
    _offMoveEvents: function () {
      (_0x5ec097(document, "mousemove", this["_onTouchMove"]),
        _0x5ec097(document, "touchmove", this["_onTouchMove"]),
        _0x5ec097(document, "pointermove", this["_onTouchMove"]),
        _0x5ec097(document, "dragover", _0x562723),
        _0x5ec097(document, "mousemove", _0x562723),
        _0x5ec097(document, "touchmove", _0x562723));
    },
    _offUpEvents: function () {
      var _0x1fe3a5 = this["el"]["ownerDocument"];
      (_0x5ec097(_0x1fe3a5, "mouseup", this["_onDrop"]),
        _0x5ec097(_0x1fe3a5, "touchend", this["_onDrop"]),
        _0x5ec097(_0x1fe3a5, "pointerup", this["_onDrop"]),
        _0x5ec097(_0x1fe3a5, "touchcancel", this["_onDrop"]),
        _0x5ec097(document, "selectstart", this));
    },
    _onDrop: function (_0x3c49f0) {
      var _0x3a46d8 = this["el"],
        _0x4ce523 = this["options"];
      ((_0xf8d987 = _0x5085eb(_0x4c8404)),
        (_0xfc74fa = _0x5085eb(_0x4c8404, _0x4ce523["draggable"])),
        _0x338aab("drop", this, { evt: _0x3c49f0 }),
        (_0x150448 = _0x4c8404 && _0x4c8404["parentNode"]),
        (_0xf8d987 = _0x5085eb(_0x4c8404)),
        (_0xfc74fa = _0x5085eb(_0x4c8404, _0x4ce523["draggable"])),
        _0x1d4300["eventCanceled"] ||
          ((_0x11aa71 = _0x5597e6 = _0x55ee58 = !0x1),
          clearInterval(this["_loopId"]),
          clearTimeout(this["_dragStartTimer"]),
          _0x2c8d3e(this["cloneId"]),
          _0x2c8d3e(this["_dragStartId"]),
          this["nativeDraggable"] &&
            (_0x5ec097(document, "drop", this),
            _0x5ec097(_0x3a46d8, "dragstart", this["_onDragStart"])),
          this["_offMoveEvents"](),
          this["_offUpEvents"](),
          _0x1e8f4e && _0x307908(document["body"], "user-select", ""),
          _0x307908(_0x4c8404, "transform", ""),
          _0x3c49f0 &&
            (_0x19e098 &&
              (_0x3c49f0["cancelable"] && _0x3c49f0["preventDefault"](),
              _0x4ce523["dropBubble"] || _0x3c49f0["stopPropagation"]()),
            _0x52d46f &&
              _0x52d46f["parentNode"] &&
              _0x52d46f["parentNode"]["removeChild"](_0x52d46f),
            (_0x3a1157 === _0x150448 ||
              (_0x40fc4e && "clone" !== _0x40fc4e["lastPutMode"])) &&
              _0x32a4c0 &&
              _0x32a4c0["parentNode"] &&
              _0x32a4c0["parentNode"]["removeChild"](_0x32a4c0),
            _0x4c8404 &&
              (this["nativeDraggable"] && _0x5ec097(_0x4c8404, "dragend", this),
              _0x28f66e(_0x4c8404),
              (_0x4c8404["style"]["will-change"] = ""),
              _0x19e098 &&
                !_0x55ee58 &&
                _0x42f20d(
                  _0x4c8404,
                  (_0x40fc4e || this)["options"]["ghostClass"],
                  !0x1,
                ),
              _0x42f20d(_0x4c8404, this["options"]["chosenClass"], !0x1),
              _0x1c8304({
                sortable: this,
                name: "unchoose",
                toEl: _0x150448,
                newIndex: null,
                newDraggableIndex: null,
                originalEvent: _0x3c49f0,
              }),
              _0x3a1157 !== _0x150448
                ? (0x0 <= _0xf8d987 &&
                    (_0x1c8304({
                      rootEl: _0x150448,
                      name: "add",
                      toEl: _0x150448,
                      fromEl: _0x3a1157,
                      originalEvent: _0x3c49f0,
                    }),
                    _0x1c8304({
                      sortable: this,
                      name: "remove",
                      toEl: _0x150448,
                      originalEvent: _0x3c49f0,
                    }),
                    _0x1c8304({
                      rootEl: _0x150448,
                      name: "sort",
                      toEl: _0x150448,
                      fromEl: _0x3a1157,
                      originalEvent: _0x3c49f0,
                    }),
                    _0x1c8304({
                      sortable: this,
                      name: "sort",
                      toEl: _0x150448,
                      originalEvent: _0x3c49f0,
                    })),
                  _0x40fc4e && _0x40fc4e["save"]())
                : _0xf8d987 !== _0x369c7c &&
                  0x0 <= _0xf8d987 &&
                  (_0x1c8304({
                    sortable: this,
                    name: "update",
                    toEl: _0x150448,
                    originalEvent: _0x3c49f0,
                  }),
                  _0x1c8304({
                    sortable: this,
                    name: "sort",
                    toEl: _0x150448,
                    originalEvent: _0x3c49f0,
                  })),
              _0x1d4300["active"] &&
                ((null != _0xf8d987 && -0x1 !== _0xf8d987) ||
                  ((_0xf8d987 = _0x369c7c), (_0xfc74fa = _0x292c3c)),
                _0x1c8304({
                  sortable: this,
                  name: "end",
                  toEl: _0x150448,
                  originalEvent: _0x3c49f0,
                }),
                this["save"]())))),
        this["_nulling"]());
    },
    _nulling: function () {
      (_0x338aab("nulling", this),
        (_0x3a1157 =
          _0x4c8404 =
          _0x150448 =
          _0x52d46f =
          _0x3122f4 =
          _0x32a4c0 =
          _0x5b9424 =
          _0x46438b =
          _0x1d3175 =
          _0x360dc8 =
          _0x19e098 =
          _0xf8d987 =
          _0xfc74fa =
          _0x369c7c =
          _0x292c3c =
          _0x15d8bc =
          _0x28ce9e =
          _0x40fc4e =
          _0x2a49d0 =
          _0x1d4300["dragged"] =
          _0x1d4300["ghost"] =
          _0x1d4300["clone"] =
          _0x1d4300["active"] =
            null),
        _0x48c6c5["forEach"](function (_0x4531ca) {
          _0x4531ca["checked"] = !0x0;
        }),
        (_0x48c6c5["length"] = _0x2686bf = _0x195f1e = 0x0));
    },
    handleEvent: function (_0x3bd07d) {
      switch (_0x3bd07d["type"]) {
        case "drop":
        case "dragend":
          this["_onDrop"](_0x3bd07d);
          break;
        case "dragenter":
        case "dragover":
          _0x4c8404 &&
            (this["_onDragOver"](_0x3bd07d),
            (function (_0x38b795) {
              (_0x38b795["dataTransfer"] &&
                (_0x38b795["dataTransfer"]["dropEffect"] = "move"),
                _0x38b795["cancelable"] && _0x38b795["preventDefault"]());
            })(_0x3bd07d));
          break;
        case "selectstart":
          _0x3bd07d["preventDefault"]();
      }
    },
    toArray: function () {
      for (
        var _0x2a7473,
          _0x440062 = [],
          _0x802217 = this["el"]["children"],
          _0xc6712d = 0x0,
          _0x51ed0b = _0x802217["length"],
          _0x41b1b1 = this["options"];
        _0xc6712d < _0x51ed0b;
        _0xc6712d++
      )
        _0x460dec(
          (_0x2a7473 = _0x802217[_0xc6712d]),
          _0x41b1b1["draggable"],
          this["el"],
          !0x1,
        ) &&
          _0x440062["push"](
            _0x2a7473["getAttribute"](_0x41b1b1["dataIdAttr"]) ||
              (function (_0x34aaae) {
                var _0xfb8a4 =
                    _0x34aaae["tagName"] +
                    _0x34aaae["className"] +
                    _0x34aaae["src"] +
                    _0x34aaae["href"] +
                    _0x34aaae["textContent"],
                  _0x383c4c = _0xfb8a4["length"],
                  _0x4e1952 = 0x0;
                for (; _0x383c4c--; )
                  _0x4e1952 += _0xfb8a4["charCodeAt"](_0x383c4c);
                return _0x4e1952["toString"](0x24);
              })(_0x2a7473),
          );
      return _0x440062;
    },
    sort: function (_0x326602, _0x2e6b18) {
      var _0x539071 = {},
        _0x35489d = this["el"];
      (this["toArray"]()["forEach"](function (_0x280f07, _0x4f560d) {
        _0x460dec(
          (_0x4f560d = _0x35489d["children"][_0x4f560d]),
          this["options"]["draggable"],
          _0x35489d,
          !0x1,
        ) && (_0x539071[_0x280f07] = _0x4f560d);
      }, this),
        _0x2e6b18 && this["captureAnimationState"](),
        _0x326602["forEach"](function (_0xb00335) {
          _0x539071[_0xb00335] &&
            (_0x35489d["removeChild"](_0x539071[_0xb00335]),
            _0x35489d["appendChild"](_0x539071[_0xb00335]));
        }),
        _0x2e6b18 && this["animateAll"]());
    },
    save: function () {
      var _0x3c13f1 = this["options"]["store"];
      _0x3c13f1 && _0x3c13f1["set"] && _0x3c13f1["set"](this);
    },
    closest: function (_0x1b0274, _0x4d6702) {
      return _0x460dec(
        _0x1b0274,
        _0x4d6702 || this["options"]["draggable"],
        this["el"],
        !0x1,
      );
    },
    option: function (_0x34d6d9, _0xb81a19) {
      var _0x1e38fd = this["options"];
      if (void 0x0 === _0xb81a19) return _0x1e38fd[_0x34d6d9];
      var _0x26ffd4 = _0x249677["modifyOption"](this, _0x34d6d9, _0xb81a19);
      ((_0x1e38fd[_0x34d6d9] = void 0x0 !== _0x26ffd4 ? _0x26ffd4 : _0xb81a19),
        "group" === _0x34d6d9 && _0x396b8d(_0x1e38fd));
    },
    destroy: function () {
      _0x338aab("destroy", this);
      var _0x1f24e7 = this["el"];
      ((_0x1f24e7[_0x2848d7] = null),
        _0x5ec097(_0x1f24e7, "mousedown", this["_onTapStart"]),
        _0x5ec097(_0x1f24e7, "touchstart", this["_onTapStart"]),
        _0x5ec097(_0x1f24e7, "pointerdown", this["_onTapStart"]),
        this["nativeDraggable"] &&
          (_0x5ec097(_0x1f24e7, "dragover", this),
          _0x5ec097(_0x1f24e7, "dragenter", this)),
        Array["prototype"]["forEach"]["call"](
          _0x1f24e7["querySelectorAll"]("[draggable]"),
          function (_0x59bc20) {
            _0x59bc20["removeAttribute"]("draggable");
          },
        ),
        this["_onDrop"](),
        this["_disableDelayedDragEvents"](),
        _0xd20cce["splice"](_0xd20cce["indexOf"](this["el"]), 0x1),
        (this["el"] = _0x1f24e7 = null));
    },
    _hideClone: function () {
      _0x46438b ||
        (_0x338aab("hideClone", this),
        _0x1d4300["eventCanceled"] ||
          (_0x307908(_0x32a4c0, "display", "none"),
          this["options"]["removeCloneOnHide"] &&
            _0x32a4c0["parentNode"] &&
            _0x32a4c0["parentNode"]["removeChild"](_0x32a4c0),
          (_0x46438b = !0x0)));
    },
    _showClone: function (_0x2a7fce) {
      "clone" === _0x2a7fce["lastPutMode"]
        ? _0x46438b &&
          (_0x338aab("showClone", this),
          _0x1d4300["eventCanceled"] ||
            (_0x4c8404["parentNode"] != _0x3a1157 ||
            this["options"]["group"]["revertClone"]
              ? _0x3122f4
                ? _0x3a1157["insertBefore"](_0x32a4c0, _0x3122f4)
                : _0x3a1157["appendChild"](_0x32a4c0)
              : _0x3a1157["insertBefore"](_0x32a4c0, _0x4c8404),
            this["options"]["group"]["revertClone"] &&
              this["animate"](_0x4c8404, _0x32a4c0),
            _0x307908(_0x32a4c0, "display", ""),
            (_0x46438b = !0x1)))
        : this["_hideClone"]();
    },
  }),
    _0x4d9932 &&
      _0x25f753(document, "touchmove", function (_0x3a5599) {
        (_0x1d4300["active"] || _0x55ee58) &&
          _0x3a5599["cancelable"] &&
          _0x3a5599["preventDefault"]();
      }),
    (_0x1d4300["utils"] = {
      on: _0x25f753,
      off: _0x5ec097,
      css: _0x307908,
      find: _0x5145cb,
      is: function (_0x195051, _0x1630cd) {
        return !!_0x460dec(_0x195051, _0x1630cd, _0x195051, !0x1);
      },
      extend: function (_0x4f4903, _0x14ae86) {
        if (_0x4f4903 && _0x14ae86) {
          for (var _0x30696a in _0x14ae86)
            _0x14ae86["hasOwnProperty"](_0x30696a) &&
              (_0x4f4903[_0x30696a] = _0x14ae86[_0x30696a]);
        }
        return _0x4f4903;
      },
      throttle: _0x24aa9f,
      closest: _0x460dec,
      toggleClass: _0x42f20d,
      clone: _0x3e007f,
      index: _0x5085eb,
      nextTick: _0x158053,
      cancelNextTick: _0x2c8d3e,
      detectDirection: _0x4c1e8e,
      getChild: _0x350cbb,
    }),
    (_0x1d4300["get"] = function (_0x54799c) {
      return _0x54799c[_0x2848d7];
    }),
    (_0x1d4300["mount"] = function () {
      for (
        var _0x67059b = arguments["length"],
          _0x356bbb = new Array(_0x67059b),
          _0x14ae0c = 0x0;
        _0x14ae0c < _0x67059b;
        _0x14ae0c++
      )
        _0x356bbb[_0x14ae0c] = arguments[_0x14ae0c];
      (_0x356bbb =
        _0x356bbb[0x0]["constructor"] === Array ? _0x356bbb[0x0] : _0x356bbb)[
        "forEach"
      ](function (_0x3f1387) {
        if (!_0x3f1387["prototype"] || !_0x3f1387["prototype"]["constructor"])
          throw "Sortable:\x20Mounted\x20plugin\x20must\x20be\x20a\x20constructor\x20function,\x20not\x20"[
            "concat"
          ]({}["toString"]["call"](_0x3f1387));
        (_0x3f1387["utils"] &&
          (_0x1d4300["utils"] = _0x2826a5(
            _0x2826a5({}, _0x1d4300["utils"]),
            _0x3f1387["utils"],
          )),
          _0x249677["mount"](_0x3f1387));
      });
    }),
    (_0x1d4300["create"] = function (_0x41d7e6, _0x29e543) {
      return new _0x1d4300(_0x41d7e6, _0x29e543);
    }));
  var _0x1a2d62,
    _0x2ba3aa,
    _0x5949d3,
    _0x56863c,
    _0x2273ff,
    _0x3d6d2e,
    _0x3d8849 = [],
    _0x4c6b93 = !(_0x1d4300["version"] = "1.14.0");
  function _0xaf3482() {
    (_0x3d8849["forEach"](function (_0x11bb50) {
      clearInterval(_0x11bb50["pid"]);
    }),
      (_0x3d8849 = []));
  }
  function _0x1e5995() {
    clearInterval(_0x3d6d2e);
  }
  var _0xd2a8e1,
    _0x1af907 = _0x24aa9f(function (
      _0x18be81,
      _0x3b11d1,
      _0x56110f,
      _0x5cd1cf,
    ) {
      if (_0x3b11d1["scroll"]) {
        var _0x43d290,
          _0x5a7f70 = (
            _0x18be81["touches"] ? _0x18be81["touches"][0x0] : _0x18be81
          )["clientX"],
          _0x52217d = (
            _0x18be81["touches"] ? _0x18be81["touches"][0x0] : _0x18be81
          )["clientY"],
          _0x589fb0 = _0x3b11d1["scrollSensitivity"],
          _0x4c1091 = _0x3b11d1["scrollSpeed"],
          _0xd8640f = _0x23897c(),
          _0xca99d3 = !0x1;
        _0x2ba3aa !== _0x56110f &&
          ((_0x2ba3aa = _0x56110f),
          _0xaf3482(),
          (_0x1a2d62 = _0x3b11d1["scroll"]),
          (_0x43d290 = _0x3b11d1["scrollFn"]),
          !0x0 === _0x1a2d62 && (_0x1a2d62 = _0x1524ea(_0x56110f, !0x0)));
        var _0x569926 = 0x0,
          _0x36040f = _0x1a2d62;
        do {
          var _0x73f5d9 = _0x36040f,
            _0x4d67f1 = (_0x127d7b = _0x156da0(_0x73f5d9))["top"],
            _0xab66db = _0x127d7b["bottom"],
            _0x8a030a = _0x127d7b["left"],
            _0x674d86 = _0x127d7b["right"],
            _0x1bee9a = _0x127d7b["width"],
            _0x5229e6 = _0x127d7b["height"],
            _0x89c738 = void 0x0,
            _0x2b04a7 = _0x73f5d9["scrollWidth"],
            _0x344c50 = _0x73f5d9["scrollHeight"],
            _0x2bb730 = _0x307908(_0x73f5d9),
            _0x5bc67e = _0x73f5d9["scrollLeft"],
            _0x127d7b = _0x73f5d9["scrollTop"],
            _0x1eb8b4 =
              _0x73f5d9 === _0xd8640f
                ? ((_0x89c738 =
                    _0x1bee9a < _0x2b04a7 &&
                    ("auto" === _0x2bb730["overflowX"] ||
                      "scroll" === _0x2bb730["overflowX"] ||
                      "visible" === _0x2bb730["overflowX"])),
                  _0x5229e6 < _0x344c50 &&
                    ("auto" === _0x2bb730["overflowY"] ||
                      "scroll" === _0x2bb730["overflowY"] ||
                      "visible" === _0x2bb730["overflowY"]))
                : ((_0x89c738 =
                    _0x1bee9a < _0x2b04a7 &&
                    ("auto" === _0x2bb730["overflowX"] ||
                      "scroll" === _0x2bb730["overflowX"])),
                  _0x5229e6 < _0x344c50 &&
                    ("auto" === _0x2bb730["overflowY"] ||
                      "scroll" === _0x2bb730["overflowY"]));
          ((_0x5bc67e =
            _0x89c738 &&
            (Math["abs"](_0x674d86 - _0x5a7f70) <= _0x589fb0 &&
              _0x5bc67e + _0x1bee9a < _0x2b04a7) -
              (Math["abs"](_0x8a030a - _0x5a7f70) <= _0x589fb0 && !!_0x5bc67e)),
            (_0x127d7b =
              _0x1eb8b4 &&
              (Math["abs"](_0xab66db - _0x52217d) <= _0x589fb0 &&
                _0x127d7b + _0x5229e6 < _0x344c50) -
                (Math["abs"](_0x4d67f1 - _0x52217d) <= _0x589fb0 &&
                  !!_0x127d7b)));
          if (!_0x3d8849[_0x569926]) {
            for (var _0x282114 = 0x0; _0x282114 <= _0x569926; _0x282114++)
              _0x3d8849[_0x282114] || (_0x3d8849[_0x282114] = {});
          }
          ((_0x3d8849[_0x569926]["vx"] == _0x5bc67e &&
            _0x3d8849[_0x569926]["vy"] == _0x127d7b &&
            _0x3d8849[_0x569926]["el"] === _0x73f5d9) ||
            ((_0x3d8849[_0x569926]["el"] = _0x73f5d9),
            (_0x3d8849[_0x569926]["vx"] = _0x5bc67e),
            (_0x3d8849[_0x569926]["vy"] = _0x127d7b),
            clearInterval(_0x3d8849[_0x569926]["pid"]),
            (0x0 == _0x5bc67e && 0x0 == _0x127d7b) ||
              ((_0xca99d3 = !0x0),
              (_0x3d8849[_0x569926]["pid"] = setInterval(
                function () {
                  _0x5cd1cf &&
                    0x0 === this["layer"] &&
                    _0x1d4300["active"]["_onTouchMove"](_0x2273ff);
                  var _0x25ebaa = _0x3d8849[this["layer"]]["vy"]
                      ? _0x3d8849[this["layer"]]["vy"] * _0x4c1091
                      : 0x0,
                    _0x2a5c5e = _0x3d8849[this["layer"]]["vx"]
                      ? _0x3d8849[this["layer"]]["vx"] * _0x4c1091
                      : 0x0;
                  ("function" == typeof _0x43d290 &&
                    "continue" !==
                      _0x43d290["call"](
                        _0x1d4300["dragged"]["parentNode"][_0x2848d7],
                        _0x2a5c5e,
                        _0x25ebaa,
                        _0x18be81,
                        _0x2273ff,
                        _0x3d8849[this["layer"]]["el"],
                      )) ||
                    _0x2f90a0(
                      _0x3d8849[this["layer"]]["el"],
                      _0x2a5c5e,
                      _0x25ebaa,
                    );
                }["bind"]({ layer: _0x569926 }),
                0x18,
              )))),
            _0x569926++);
        } while (
          _0x3b11d1["bubbleScroll"] &&
          _0x36040f !== _0xd8640f &&
          (_0x36040f = _0x1524ea(_0x36040f, !0x1))
        );
        _0x4c6b93 = _0xca99d3;
      }
    }, 0x1e);
  _0x177758 = function (_0x29a820) {
    var _0x1df6c4 = _0x29a820["originalEvent"],
      _0x41bfe7 = _0x29a820["putSortable"],
      _0x321549 = _0x29a820["dragEl"],
      _0x117a4f = _0x29a820["activeSortable"],
      _0x42b45e = _0x29a820["dispatchSortableEvent"],
      _0x3e34e5 = _0x29a820["hideGhostForTarget"];
    ((_0x29a820 = _0x29a820["unhideGhostForTarget"]),
      _0x1df6c4 &&
        ((_0x117a4f = _0x41bfe7 || _0x117a4f),
        _0x3e34e5(),
        (_0x1df6c4 =
          _0x1df6c4["changedTouches"] && _0x1df6c4["changedTouches"]["length"]
            ? _0x1df6c4["changedTouches"][0x0]
            : _0x1df6c4),
        (_0x1df6c4 = document["elementFromPoint"](
          _0x1df6c4["clientX"],
          _0x1df6c4["clientY"],
        )),
        _0x29a820(),
        _0x117a4f &&
          !_0x117a4f["el"]["contains"](_0x1df6c4) &&
          (_0x42b45e("spill"),
          this["onSpill"]({ dragEl: _0x321549, putSortable: _0x41bfe7 }))));
  };
  function _0x2b620e() {}
  function _0xf57426() {}
  ((_0x2b620e["prototype"] = {
    startIndex: null,
    dragStart: function (_0x272cf2) {
      ((_0x272cf2 = _0x272cf2["oldDraggableIndex"]),
        (this["startIndex"] = _0x272cf2));
    },
    onSpill: function (_0x2ce023) {
      var _0x27a4f6 = _0x2ce023["dragEl"],
        _0x58d2e5 = _0x2ce023["putSortable"];
      (this["sortable"]["captureAnimationState"](),
        _0x58d2e5 && _0x58d2e5["captureAnimationState"](),
        ((_0x2ce023 = _0x350cbb(
          this["sortable"]["el"],
          this["startIndex"],
          this["options"],
        ))
          ? this["sortable"]["el"]["insertBefore"](_0x27a4f6, _0x2ce023)
          : this["sortable"]["el"]["appendChild"](_0x27a4f6),
        this["sortable"]["animateAll"](),
        _0x58d2e5 && _0x58d2e5["animateAll"]()));
    },
    drop: _0x177758,
  }),
    _0x35b1a3(_0x2b620e, { pluginName: "revertOnSpill" }),
    (_0xf57426["prototype"] = {
      onSpill: function (_0xc55563) {
        var _0x3e3e70 = _0xc55563["dragEl"];
        ((_0xc55563 = _0xc55563["putSortable"] || this["sortable"])[
          "captureAnimationState"
        ](),
          _0x3e3e70["parentNode"] &&
            _0x3e3e70["parentNode"]["removeChild"](_0x3e3e70),
          _0xc55563["animateAll"]());
      },
      drop: _0x177758,
    }),
    _0x35b1a3(_0xf57426, { pluginName: "removeOnSpill" }));
  var _0x3a5946,
    _0x452b2a,
    _0xd3f953,
    _0xdcb910,
    _0x5acb88,
    _0x396bd1 = [],
    _0x29b4df = [],
    _0x3dc22a = !0x1,
    _0x5ea62e = !0x1,
    _0x45f380 = !0x1;
  function _0x3a704a(_0x12c9c7, _0xf2b8ea) {
    _0x29b4df["forEach"](function (_0x48c6e3, _0x4fc73c) {
      (_0x4fc73c =
        _0xf2b8ea["children"][
          _0x48c6e3["sortableIndex"] + (_0x12c9c7 ? Number(_0x4fc73c) : 0x0)
        ])
        ? _0xf2b8ea["insertBefore"](_0x48c6e3, _0x4fc73c)
        : _0xf2b8ea["appendChild"](_0x48c6e3);
    });
  }
  function _0x3e87d6() {
    _0x396bd1["forEach"](function (_0x38c5d6) {
      _0x38c5d6 !== _0xd3f953 &&
        _0x38c5d6["parentNode"] &&
        _0x38c5d6["parentNode"]["removeChild"](_0x38c5d6);
    });
  }
  return (
    _0x1d4300["mount"](
      new (function () {
        function _0x48cce3() {
          for (var _0x3e95c in ((this["defaults"] = {
            scroll: !0x0,
            forceAutoScrollFallback: !0x1,
            scrollSensitivity: 0x1e,
            scrollSpeed: 0xa,
            bubbleScroll: !0x0,
          }),
          this))
            "_" === _0x3e95c["charAt"](0x0) &&
              "function" == typeof this[_0x3e95c] &&
              (this[_0x3e95c] = this[_0x3e95c]["bind"](this));
        }
        return (
          (_0x48cce3["prototype"] = {
            dragStarted: function (_0x54fc89) {
              ((_0x54fc89 = _0x54fc89["originalEvent"]),
                this["sortable"]["nativeDraggable"]
                  ? _0x25f753(document, "dragover", this["_handleAutoScroll"])
                  : this["options"]["supportPointer"]
                    ? _0x25f753(
                        document,
                        "pointermove",
                        this["_handleFallbackAutoScroll"],
                      )
                    : _0x54fc89["touches"]
                      ? _0x25f753(
                          document,
                          "touchmove",
                          this["_handleFallbackAutoScroll"],
                        )
                      : _0x25f753(
                          document,
                          "mousemove",
                          this["_handleFallbackAutoScroll"],
                        ));
            },
            dragOverCompleted: function (_0x4a1b03) {
              ((_0x4a1b03 = _0x4a1b03["originalEvent"]),
                this["options"]["dragOverBubble"] ||
                  _0x4a1b03["rootEl"] ||
                  this["_handleAutoScroll"](_0x4a1b03));
            },
            drop: function () {
              (this["sortable"]["nativeDraggable"]
                ? _0x5ec097(document, "dragover", this["_handleAutoScroll"])
                : (_0x5ec097(
                    document,
                    "pointermove",
                    this["_handleFallbackAutoScroll"],
                  ),
                  _0x5ec097(
                    document,
                    "touchmove",
                    this["_handleFallbackAutoScroll"],
                  ),
                  _0x5ec097(
                    document,
                    "mousemove",
                    this["_handleFallbackAutoScroll"],
                  )),
                _0x1e5995(),
                _0xaf3482(),
                clearTimeout(_0x4864bd),
                (_0x4864bd = void 0x0));
            },
            nulling: function () {
              ((_0x2273ff =
                _0x2ba3aa =
                _0x1a2d62 =
                _0x4c6b93 =
                _0x3d6d2e =
                _0x5949d3 =
                _0x56863c =
                  null),
                (_0x3d8849["length"] = 0x0));
            },
            _handleFallbackAutoScroll: function (_0x5d7a4d) {
              this["_handleAutoScroll"](_0x5d7a4d, !0x0);
            },
            _handleAutoScroll: function (_0x23f05c, _0x2ae096) {
              var _0x47e5fe,
                _0x5c5b45 = this,
                _0x3757bb = (
                  _0x23f05c["touches"] ? _0x23f05c["touches"][0x0] : _0x23f05c
                )["clientX"],
                _0x32c12e = (
                  _0x23f05c["touches"] ? _0x23f05c["touches"][0x0] : _0x23f05c
                )["clientY"],
                _0x2d2043 = document["elementFromPoint"](_0x3757bb, _0x32c12e);
              ((_0x2273ff = _0x23f05c),
                _0x2ae096 ||
                this["options"]["forceAutoScrollFallback"] ||
                _0x6f6279 ||
                _0x127cc2 ||
                _0x1e8f4e
                  ? (_0x1af907(
                      _0x23f05c,
                      this["options"],
                      _0x2d2043,
                      _0x2ae096,
                    ),
                    (_0x47e5fe = _0x1524ea(_0x2d2043, !0x0)),
                    !_0x4c6b93 ||
                      (_0x3d6d2e &&
                        _0x3757bb === _0x5949d3 &&
                        _0x32c12e === _0x56863c) ||
                      (_0x3d6d2e && _0x1e5995(),
                      (_0x3d6d2e = setInterval(function () {
                        var _0xdea088 = _0x1524ea(
                          document["elementFromPoint"](_0x3757bb, _0x32c12e),
                          !0x0,
                        );
                        (_0xdea088 !== _0x47e5fe &&
                          ((_0x47e5fe = _0xdea088), _0xaf3482()),
                          _0x1af907(
                            _0x23f05c,
                            _0x5c5b45["options"],
                            _0xdea088,
                            _0x2ae096,
                          ));
                      }, 0xa)),
                      (_0x5949d3 = _0x3757bb),
                      (_0x56863c = _0x32c12e)))
                  : this["options"]["bubbleScroll"] &&
                      _0x1524ea(_0x2d2043, !0x0) !== _0x23897c()
                    ? _0x1af907(
                        _0x23f05c,
                        this["options"],
                        _0x1524ea(_0x2d2043, !0x1),
                        !0x1,
                      )
                    : _0xaf3482());
            },
          }),
          _0x35b1a3(_0x48cce3, {
            pluginName: "scroll",
            initializeByDefault: !0x0,
          })
        );
      })(),
    ),
    _0x1d4300["mount"](_0xf57426, _0x2b620e),
    _0x1d4300["mount"](
      new (function () {
        function _0x4713bc() {
          this["defaults"] = { swapClass: "sortable-swap-highlight" };
        }
        return (
          (_0x4713bc["prototype"] = {
            dragStart: function (_0x4571d3) {
              ((_0x4571d3 = _0x4571d3["dragEl"]), (_0xd2a8e1 = _0x4571d3));
            },
            dragOverValid: function (_0x31c46b) {
              var _0x5e3c44 = _0x31c46b["completed"],
                _0x33e461 = _0x31c46b["target"],
                _0x44961b = _0x31c46b["onMove"],
                _0x13d142 = _0x31c46b["activeSortable"],
                _0x239b25 = _0x31c46b["changed"],
                _0x3c7203 = _0x31c46b["cancel"];
              _0x13d142["options"]["swap"] &&
                ((_0x31c46b = this["sortable"]["el"]),
                (_0x13d142 = this["options"]),
                _0x33e461 &&
                  _0x33e461 !== _0x31c46b &&
                  ((_0x31c46b = _0xd2a8e1),
                  (_0xd2a8e1 =
                    !0x1 !== _0x44961b(_0x33e461)
                      ? (_0x42f20d(_0x33e461, _0x13d142["swapClass"], !0x0),
                        _0x33e461)
                      : null),
                  _0x31c46b &&
                    _0x31c46b !== _0xd2a8e1 &&
                    _0x42f20d(_0x31c46b, _0x13d142["swapClass"], !0x1)),
                _0x239b25(),
                _0x5e3c44(!0x0),
                _0x3c7203());
            },
            drop: function (_0x5a57db) {
              var _0x58d3ee,
                _0x29e6d7,
                _0x2c259b = _0x5a57db["activeSortable"],
                _0x10a623 = _0x5a57db["putSortable"],
                _0x102789 = _0x5a57db["dragEl"],
                _0x56d895 = _0x10a623 || this["sortable"],
                _0x146a7c = this["options"];
              (_0xd2a8e1 && _0x42f20d(_0xd2a8e1, _0x146a7c["swapClass"], !0x1),
                _0xd2a8e1 &&
                  (_0x146a7c["swap"] ||
                    (_0x10a623 && _0x10a623["options"]["swap"])) &&
                  _0x102789 !== _0xd2a8e1 &&
                  (_0x56d895["captureAnimationState"](),
                  _0x56d895 !== _0x2c259b &&
                    _0x2c259b["captureAnimationState"](),
                  (_0x29e6d7 = _0xd2a8e1),
                  (_0x5a57db = (_0x58d3ee = _0x102789)["parentNode"]),
                  (_0x146a7c = _0x29e6d7["parentNode"]),
                  _0x5a57db &&
                    _0x146a7c &&
                    !_0x5a57db["isEqualNode"](_0x29e6d7) &&
                    !_0x146a7c["isEqualNode"](_0x58d3ee) &&
                    ((_0x10a623 = _0x5085eb(_0x58d3ee)),
                    (_0x102789 = _0x5085eb(_0x29e6d7)),
                    _0x5a57db["isEqualNode"](_0x146a7c) &&
                      _0x10a623 < _0x102789 &&
                      _0x102789++,
                    _0x5a57db["insertBefore"](
                      _0x29e6d7,
                      _0x5a57db["children"][_0x10a623],
                    ),
                    _0x146a7c["insertBefore"](
                      _0x58d3ee,
                      _0x146a7c["children"][_0x102789],
                    )),
                  _0x56d895["animateAll"](),
                  _0x56d895 !== _0x2c259b && _0x2c259b["animateAll"]()));
            },
            nulling: function () {
              _0xd2a8e1 = null;
            },
          }),
          _0x35b1a3(_0x4713bc, {
            pluginName: "swap",
            eventProperties: function () {
              return { swapItem: _0xd2a8e1 };
            },
          })
        );
      })(),
    ),
    _0x1d4300["mount"](
      new (function () {
        function _0x38e2c9(_0x4f3e27) {
          for (var _0x37bdd5 in this)
            "_" === _0x37bdd5["charAt"](0x0) &&
              "function" == typeof this[_0x37bdd5] &&
              (this[_0x37bdd5] = this[_0x37bdd5]["bind"](this));
          (_0x4f3e27["options"]["supportPointer"]
            ? _0x25f753(document, "pointerup", this["_deselectMultiDrag"])
            : (_0x25f753(document, "mouseup", this["_deselectMultiDrag"]),
              _0x25f753(document, "touchend", this["_deselectMultiDrag"])),
            _0x25f753(document, "keydown", this["_checkKeyDown"]),
            _0x25f753(document, "keyup", this["_checkKeyUp"]),
            (this["defaults"] = {
              selectedClass: "sortable-selected",
              multiDragKey: null,
              setData: function (_0x7d7b1e, _0x49890b) {
                var _0x69a065 = "";
                (_0x396bd1["length"] && _0x452b2a === _0x4f3e27
                  ? _0x396bd1["forEach"](function (_0x16ccba, _0xc719f2) {
                      _0x69a065 +=
                        (_0xc719f2 ? ",\x20" : "") + _0x16ccba["textContent"];
                    })
                  : (_0x69a065 = _0x49890b["textContent"]),
                  _0x7d7b1e["setData"]("Text", _0x69a065));
              },
            }));
        }
        return (
          (_0x38e2c9["prototype"] = {
            multiDragKeyDown: !0x1,
            isMultiDrag: !0x1,
            delayStartGlobal: function (_0x2b0637) {
              ((_0x2b0637 = _0x2b0637["dragEl"]), (_0xd3f953 = _0x2b0637));
            },
            delayEnded: function () {
              this["isMultiDrag"] = ~_0x396bd1["indexOf"](_0xd3f953);
            },
            setupClone: function (_0x1883be) {
              var _0x5b8bbc = _0x1883be["sortable"];
              _0x1883be = _0x1883be["cancel"];
              if (this["isMultiDrag"]) {
                for (
                  var _0x50d3fb = 0x0;
                  _0x50d3fb < _0x396bd1["length"];
                  _0x50d3fb++
                )
                  (_0x29b4df["push"](_0x3e007f(_0x396bd1[_0x50d3fb])),
                    (_0x29b4df[_0x50d3fb]["sortableIndex"] =
                      _0x396bd1[_0x50d3fb]["sortableIndex"]),
                    (_0x29b4df[_0x50d3fb]["draggable"] = !0x1),
                    (_0x29b4df[_0x50d3fb]["style"]["will-change"] = ""),
                    _0x42f20d(
                      _0x29b4df[_0x50d3fb],
                      this["options"]["selectedClass"],
                      !0x1,
                    ),
                    _0x396bd1[_0x50d3fb] === _0xd3f953 &&
                      _0x42f20d(
                        _0x29b4df[_0x50d3fb],
                        this["options"]["chosenClass"],
                        !0x1,
                      ));
                (_0x5b8bbc["_hideClone"](), _0x1883be());
              }
            },
            clone: function (_0x3aa092) {
              var _0x31904a = _0x3aa092["sortable"],
                _0x218fb2 = _0x3aa092["rootEl"],
                _0x194011 = _0x3aa092["dispatchSortableEvent"];
              ((_0x3aa092 = _0x3aa092["cancel"]),
                this["isMultiDrag"] &&
                  (this["options"]["removeCloneOnHide"] ||
                    (_0x396bd1["length"] &&
                      _0x452b2a === _0x31904a &&
                      (_0x3a704a(!0x0, _0x218fb2),
                      _0x194011("clone"),
                      _0x3aa092()))));
            },
            showClone: function (_0xb9068d) {
              var _0x28c4f1 = _0xb9068d["cloneNowShown"],
                _0x2c89a3 = _0xb9068d["rootEl"];
              ((_0xb9068d = _0xb9068d["cancel"]),
                this["isMultiDrag"] &&
                  (_0x3a704a(!0x1, _0x2c89a3),
                  _0x29b4df["forEach"](function (_0x417c59) {
                    _0x307908(_0x417c59, "display", "");
                  }),
                  _0x28c4f1(),
                  (_0x5acb88 = !0x1),
                  _0xb9068d()));
            },
            hideClone: function (_0x2aa2d6) {
              var _0x145010 = this,
                _0x43cb7a =
                  (_0x2aa2d6["sortable"], _0x2aa2d6["cloneNowHidden"]);
              ((_0x2aa2d6 = _0x2aa2d6["cancel"]),
                this["isMultiDrag"] &&
                  (_0x29b4df["forEach"](function (_0x5b9570) {
                    (_0x307908(_0x5b9570, "display", "none"),
                      _0x145010["options"]["removeCloneOnHide"] &&
                        _0x5b9570["parentNode"] &&
                        _0x5b9570["parentNode"]["removeChild"](_0x5b9570));
                  }),
                  _0x43cb7a(),
                  (_0x5acb88 = !0x0),
                  _0x2aa2d6()));
            },
            dragStartGlobal: function (_0x12b4d1) {
              (_0x12b4d1["sortable"],
                (!this["isMultiDrag"] &&
                  _0x452b2a &&
                  _0x452b2a["multiDrag"]["_deselectMultiDrag"](),
                _0x396bd1["forEach"](function (_0x1885a5) {
                  _0x1885a5["sortableIndex"] = _0x5085eb(_0x1885a5);
                }),
                (_0x396bd1 = _0x396bd1["sort"](function (_0x2b1057, _0x2be3ee) {
                  return (
                    _0x2b1057["sortableIndex"] - _0x2be3ee["sortableIndex"]
                  );
                })),
                (_0x45f380 = !0x0)));
            },
            dragStarted: function (_0x54bc57) {
              var _0x3d5832,
                _0x449fbd = this;
              ((_0x54bc57 = _0x54bc57["sortable"]),
                this["isMultiDrag"] &&
                  (this["options"]["sort"] &&
                    (_0x54bc57["captureAnimationState"](),
                    this["options"]["animation"] &&
                      (_0x396bd1["forEach"](function (_0x2d6300) {
                        _0x2d6300 !== _0xd3f953 &&
                          _0x307908(_0x2d6300, "position", "absolute");
                      }),
                      (_0x3d5832 = _0x156da0(_0xd3f953, !0x1, !0x0, !0x0)),
                      _0x396bd1["forEach"](function (_0x574017) {
                        _0x574017 !== _0xd3f953 &&
                          _0x16af76(_0x574017, _0x3d5832);
                      }),
                      (_0x3dc22a = _0x5ea62e = !0x0))),
                  _0x54bc57["animateAll"](function () {
                    ((_0x3dc22a = _0x5ea62e = !0x1),
                      _0x449fbd["options"]["animation"] &&
                        _0x396bd1["forEach"](function (_0x16ff45) {
                          _0x1a3dff(_0x16ff45);
                        }),
                      _0x449fbd["options"]["sort"] && _0x3e87d6());
                  })));
            },
            dragOver: function (_0x50bc0e) {
              var _0x5a62c3 = _0x50bc0e["target"],
                _0x20f787 = _0x50bc0e["completed"];
              ((_0x50bc0e = _0x50bc0e["cancel"]),
                _0x5ea62e &&
                  ~_0x396bd1["indexOf"](_0x5a62c3) &&
                  (_0x20f787(!0x1), _0x50bc0e()));
            },
            revert: function (_0x37e6f1) {
              var _0x3c83ab,
                _0x539fc4,
                _0x3f1a4c = _0x37e6f1["fromSortable"],
                _0x5797c6 = _0x37e6f1["rootEl"],
                _0x109178 = _0x37e6f1["sortable"],
                _0x564ff4 = _0x37e6f1["dragRect"];
              0x1 < _0x396bd1["length"] &&
                (_0x396bd1["forEach"](function (_0x44b26e) {
                  (_0x109178["addAnimationState"]({
                    target: _0x44b26e,
                    rect: _0x5ea62e ? _0x156da0(_0x44b26e) : _0x564ff4,
                  }),
                    _0x1a3dff(_0x44b26e),
                    (_0x44b26e["fromRect"] = _0x564ff4),
                    _0x3f1a4c["removeAnimationState"](_0x44b26e));
                }),
                (_0x5ea62e = !0x1),
                (_0x3c83ab = !this["options"]["removeCloneOnHide"]),
                (_0x539fc4 = _0x5797c6),
                _0x396bd1["forEach"](function (_0x15ce3a, _0x2e6869) {
                  (_0x2e6869 =
                    _0x539fc4["children"][
                      _0x15ce3a["sortableIndex"] +
                        (_0x3c83ab ? Number(_0x2e6869) : 0x0)
                    ])
                    ? _0x539fc4["insertBefore"](_0x15ce3a, _0x2e6869)
                    : _0x539fc4["appendChild"](_0x15ce3a);
                }));
            },
            dragOverCompleted: function (_0x5d88e9) {
              var _0x348aa6,
                _0x5b0d83 = _0x5d88e9["sortable"],
                _0x5375e9 = _0x5d88e9["isOwner"],
                _0x35d135 = _0x5d88e9["insertion"],
                _0x1712fb = _0x5d88e9["activeSortable"],
                _0x1296cd = _0x5d88e9["parentEl"],
                _0x27a480 = _0x5d88e9["putSortable"];
              ((_0x5d88e9 = this["options"]),
                _0x35d135 &&
                  (_0x5375e9 && _0x1712fb["_hideClone"](),
                  (_0x3dc22a = !0x1),
                  _0x5d88e9["animation"] &&
                    0x1 < _0x396bd1["length"] &&
                    (_0x5ea62e ||
                      (!_0x5375e9 &&
                        !_0x1712fb["options"]["sort"] &&
                        !_0x27a480)) &&
                    ((_0x348aa6 = _0x156da0(_0xd3f953, !0x1, !0x0, !0x0)),
                    _0x396bd1["forEach"](function (_0x153bb3) {
                      _0x153bb3 !== _0xd3f953 &&
                        (_0x16af76(_0x153bb3, _0x348aa6),
                        _0x1296cd["appendChild"](_0x153bb3));
                    }),
                    (_0x5ea62e = !0x0)),
                  _0x5375e9 ||
                    (_0x5ea62e || _0x3e87d6(),
                    0x1 < _0x396bd1["length"]
                      ? ((_0x5375e9 = _0x5acb88),
                        _0x1712fb["_showClone"](_0x5b0d83),
                        _0x1712fb["options"]["animation"] &&
                          !_0x5acb88 &&
                          _0x5375e9 &&
                          _0x29b4df["forEach"](function (_0xe6d3bc) {
                            (_0x1712fb["addAnimationState"]({
                              target: _0xe6d3bc,
                              rect: _0xdcb910,
                            }),
                              (_0xe6d3bc["fromRect"] = _0xdcb910),
                              (_0xe6d3bc["thisAnimationDuration"] = null));
                          }))
                      : _0x1712fb["_showClone"](_0x5b0d83))));
            },
            dragOverAnimationCapture: function (_0xa7b9e3) {
              var _0x4ff1d0 = _0xa7b9e3["dragRect"],
                _0x3d5fa2 = _0xa7b9e3["isOwner"];
              ((_0xa7b9e3 = _0xa7b9e3["activeSortable"]),
                (_0x396bd1["forEach"](function (_0x1f633f) {
                  _0x1f633f["thisAnimationDuration"] = null;
                }),
                _0xa7b9e3["options"]["animation"] &&
                  !_0x3d5fa2 &&
                  _0xa7b9e3["multiDrag"]["isMultiDrag"] &&
                  ((_0xdcb910 = _0x35b1a3({}, _0x4ff1d0)),
                  (_0x4ff1d0 = _0x9185c4(_0xd3f953, !0x0)),
                  (_0xdcb910["top"] -= _0x4ff1d0["f"]),
                  (_0xdcb910["left"] -= _0x4ff1d0["e"]))));
            },
            dragOverAnimationComplete: function () {
              _0x5ea62e && ((_0x5ea62e = !0x1), _0x3e87d6());
            },
            drop: function (_0x10adec) {
              var _0x5a892d = _0x10adec["originalEvent"],
                _0x501a10 = _0x10adec["rootEl"],
                _0x23c9db = _0x10adec["parentEl"],
                _0x1de39f = _0x10adec["sortable"],
                _0xef972e = _0x10adec["dispatchSortableEvent"],
                _0x4caa51 = _0x10adec["oldIndex"],
                _0x5f2575 = _0x10adec["putSortable"],
                _0x36bf2f = _0x5f2575 || this["sortable"];
              if (_0x5a892d) {
                var _0x1a6909,
                  _0x46fb56,
                  _0x525c1a,
                  _0x328b17 = this["options"],
                  _0x52af00 = _0x23c9db["children"];
                if (!_0x45f380) {
                  if (
                    (_0x328b17["multiDragKey"] &&
                      !this["multiDragKeyDown"] &&
                      this["_deselectMultiDrag"](),
                    _0x42f20d(
                      _0xd3f953,
                      _0x328b17["selectedClass"],
                      !~_0x396bd1["indexOf"](_0xd3f953),
                    ),
                    ~_0x396bd1["indexOf"](_0xd3f953))
                  )
                    (_0x396bd1["splice"](_0x396bd1["indexOf"](_0xd3f953), 0x1),
                      (_0x3a5946 = null),
                      _0x2ef43f({
                        sortable: _0x1de39f,
                        rootEl: _0x501a10,
                        name: "deselect",
                        targetEl: _0xd3f953,
                        originalEvt: _0x5a892d,
                      }));
                  else {
                    if (
                      (_0x396bd1["push"](_0xd3f953),
                      _0x2ef43f({
                        sortable: _0x1de39f,
                        rootEl: _0x501a10,
                        name: "select",
                        targetEl: _0xd3f953,
                        originalEvt: _0x5a892d,
                      }),
                      _0x5a892d["shiftKey"] &&
                        _0x3a5946 &&
                        _0x1de39f["el"]["contains"](_0x3a5946))
                    ) {
                      var _0x3c5d4c = _0x5085eb(_0x3a5946);
                      _0x10adec = _0x5085eb(_0xd3f953);
                      if (~_0x3c5d4c && ~_0x10adec && _0x3c5d4c !== _0x10adec) {
                        for (
                          var _0x1b2fce,
                            _0x2101ac =
                              _0x3c5d4c < _0x10adec
                                ? ((_0x1b2fce = _0x3c5d4c), _0x10adec)
                                : ((_0x1b2fce = _0x10adec), _0x3c5d4c + 0x1);
                          _0x1b2fce < _0x2101ac;
                          _0x1b2fce++
                        )
                          ~_0x396bd1["indexOf"](_0x52af00[_0x1b2fce]) ||
                            (_0x42f20d(
                              _0x52af00[_0x1b2fce],
                              _0x328b17["selectedClass"],
                              !0x0,
                            ),
                            _0x396bd1["push"](_0x52af00[_0x1b2fce]),
                            _0x2ef43f({
                              sortable: _0x1de39f,
                              rootEl: _0x501a10,
                              name: "select",
                              targetEl: _0x52af00[_0x1b2fce],
                              originalEvt: _0x5a892d,
                            }));
                      }
                    } else _0x3a5946 = _0xd3f953;
                    _0x452b2a = _0x36bf2f;
                  }
                }
                (_0x45f380 &&
                  this["isMultiDrag"] &&
                  ((_0x5ea62e = !0x1),
                  (_0x23c9db[_0x2848d7]["options"]["sort"] ||
                    _0x23c9db !== _0x501a10) &&
                    0x1 < _0x396bd1["length"] &&
                    ((_0x1a6909 = _0x156da0(_0xd3f953)),
                    (_0x46fb56 = _0x5085eb(
                      _0xd3f953,
                      ":not(." + this["options"]["selectedClass"] + ")",
                    )),
                    !_0x3dc22a &&
                      _0x328b17["animation"] &&
                      (_0xd3f953["thisAnimationDuration"] = null),
                    _0x36bf2f["captureAnimationState"](),
                    _0x3dc22a ||
                      (_0x328b17["animation"] &&
                        ((_0xd3f953["fromRect"] = _0x1a6909),
                        _0x396bd1["forEach"](function (_0x238ffe) {
                          var _0x367987;
                          ((_0x238ffe["thisAnimationDuration"] = null),
                            _0x238ffe !== _0xd3f953 &&
                              ((_0x367987 = _0x5ea62e
                                ? _0x156da0(_0x238ffe)
                                : _0x1a6909),
                              (_0x238ffe["fromRect"] = _0x367987),
                              _0x36bf2f["addAnimationState"]({
                                target: _0x238ffe,
                                rect: _0x367987,
                              })));
                        })),
                      _0x3e87d6(),
                      _0x396bd1["forEach"](function (_0x4346be) {
                        (_0x52af00[_0x46fb56]
                          ? _0x23c9db["insertBefore"](
                              _0x4346be,
                              _0x52af00[_0x46fb56],
                            )
                          : _0x23c9db["appendChild"](_0x4346be),
                          _0x46fb56++);
                      }),
                      _0x4caa51 === _0x5085eb(_0xd3f953) &&
                        ((_0x525c1a = !0x1),
                        _0x396bd1["forEach"](function (_0x2c9303) {
                          _0x2c9303["sortableIndex"] !== _0x5085eb(_0x2c9303) &&
                            (_0x525c1a = !0x0);
                        }),
                        _0x525c1a && _0xef972e("update"))),
                    _0x396bd1["forEach"](function (_0x49750a) {
                      _0x1a3dff(_0x49750a);
                    }),
                    _0x36bf2f["animateAll"]()),
                  (_0x452b2a = _0x36bf2f)),
                  (_0x501a10 === _0x23c9db ||
                    (_0x5f2575 && "clone" !== _0x5f2575["lastPutMode"])) &&
                    _0x29b4df["forEach"](function (_0x38e135) {
                      _0x38e135["parentNode"] &&
                        _0x38e135["parentNode"]["removeChild"](_0x38e135);
                    }));
              }
            },
            nullingGlobal: function () {
              ((this["isMultiDrag"] = _0x45f380 = !0x1),
                (_0x29b4df["length"] = 0x0));
            },
            destroyGlobal: function () {
              (this["_deselectMultiDrag"](),
                _0x5ec097(document, "pointerup", this["_deselectMultiDrag"]),
                _0x5ec097(document, "mouseup", this["_deselectMultiDrag"]),
                _0x5ec097(document, "touchend", this["_deselectMultiDrag"]),
                _0x5ec097(document, "keydown", this["_checkKeyDown"]),
                _0x5ec097(document, "keyup", this["_checkKeyUp"]));
            },
            _deselectMultiDrag: function (_0x238b76) {
              if (
                !(
                  (void 0x0 !== _0x45f380 && _0x45f380) ||
                  _0x452b2a !== this["sortable"] ||
                  (_0x238b76 &&
                    _0x460dec(
                      _0x238b76["target"],
                      this["options"]["draggable"],
                      this["sortable"]["el"],
                      !0x1,
                    )) ||
                  (_0x238b76 && 0x0 !== _0x238b76["button"])
                )
              )
                for (; _0x396bd1["length"]; ) {
                  var _0x3f759d = _0x396bd1[0x0];
                  (_0x42f20d(_0x3f759d, this["options"]["selectedClass"], !0x1),
                    _0x396bd1["shift"](),
                    _0x2ef43f({
                      sortable: this["sortable"],
                      rootEl: this["sortable"]["el"],
                      name: "deselect",
                      targetEl: _0x3f759d,
                      originalEvt: _0x238b76,
                    }));
                }
            },
            _checkKeyDown: function (_0xee3f71) {
              _0xee3f71["key"] === this["options"]["multiDragKey"] &&
                (this["multiDragKeyDown"] = !0x0);
            },
            _checkKeyUp: function (_0x10a530) {
              _0x10a530["key"] === this["options"]["multiDragKey"] &&
                (this["multiDragKeyDown"] = !0x1);
            },
          }),
          _0x35b1a3(_0x38e2c9, {
            pluginName: "multiDrag",
            utils: {
              select: function (_0x30ac8e) {
                var _0x41e556 = _0x30ac8e["parentNode"][_0x2848d7];
                _0x41e556 &&
                  _0x41e556["options"]["multiDrag"] &&
                  !~_0x396bd1["indexOf"](_0x30ac8e) &&
                  (_0x452b2a &&
                    _0x452b2a !== _0x41e556 &&
                    (_0x452b2a["multiDrag"]["_deselectMultiDrag"](),
                    (_0x452b2a = _0x41e556)),
                  _0x42f20d(
                    _0x30ac8e,
                    _0x41e556["options"]["selectedClass"],
                    !0x0,
                  ),
                  _0x396bd1["push"](_0x30ac8e));
              },
              deselect: function (_0x164398) {
                var _0xbfb768 = _0x164398["parentNode"][_0x2848d7],
                  _0x1c21a3 = _0x396bd1["indexOf"](_0x164398);
                _0xbfb768 &&
                  _0xbfb768["options"]["multiDrag"] &&
                  ~_0x1c21a3 &&
                  (_0x42f20d(
                    _0x164398,
                    _0xbfb768["options"]["selectedClass"],
                    !0x1,
                  ),
                  _0x396bd1["splice"](_0x1c21a3, 0x1));
              },
            },
            eventProperties: function () {
              var _0x24547d = this,
                _0x2207bf = [],
                _0xd3fb0f = [];
              return (
                _0x396bd1["forEach"](function (_0xaf8bb8) {
                  var _0x57186f;
                  (_0x2207bf["push"]({
                    multiDragElement: _0xaf8bb8,
                    index: _0xaf8bb8["sortableIndex"],
                  }),
                    (_0x57186f =
                      _0x5ea62e && _0xaf8bb8 !== _0xd3f953
                        ? -0x1
                        : _0x5ea62e
                          ? _0x5085eb(
                              _0xaf8bb8,
                              ":not(." +
                                _0x24547d["options"]["selectedClass"] +
                                ")",
                            )
                          : _0x5085eb(_0xaf8bb8)),
                    _0xd3fb0f["push"]({
                      multiDragElement: _0xaf8bb8,
                      index: _0x57186f,
                    }));
                }),
                {
                  items: _0x7067(_0x396bd1),
                  clones: []["concat"](_0x29b4df),
                  oldIndicies: _0x2207bf,
                  newIndicies: _0xd3fb0f,
                }
              );
            },
            optionListeners: {
              multiDragKey: function (_0x12a107) {
                return (
                  "ctrl" === (_0x12a107 = _0x12a107["toLowerCase"]())
                    ? (_0x12a107 = "Control")
                    : 0x1 < _0x12a107["length"] &&
                      (_0x12a107 =
                        _0x12a107["charAt"](0x0)["toUpperCase"]() +
                        _0x12a107["substr"](0x1)),
                  _0x12a107
                );
              },
            },
          })
        );
      })(),
    ),
    _0x1d4300
  );
});
var _0x374761 = async function (_0x2df771 = "sniper-mark") {
  var _0x6698f7 = document["createElement"]("img");
  return (
    (_0x6698f7["id"] = _0x2df771),
    _0x6698f7["classList"]["add"]("sniper-mark"),
    (_0x6698f7["src"] = await chrome["runtime"]["getURL"](
      "libraries/target-spin/target.png",
    )),
    _0x6698f7
  );
};
function _0x529f17() {
  var _0x4cae0b = document["querySelectorAll"](".sniper-mark");
  for (var _0x54316c = 0x0; _0x54316c < _0x4cae0b["length"]; _0x54316c++)
    _0x4cae0b[_0x54316c]["classList"]["add"]("spin");
}
function _0x4176c2() {
  var _0x1b313c = document["querySelectorAll"](".sniper-mark");
  for (var _0x36e629 = 0x0; _0x36e629 < _0x1b313c["length"]; _0x36e629++)
    _0x1b313c[_0x36e629]["classList"]["remove"]("spin");
}
function _0x48c406() {
  var _0x1952aa = document["querySelectorAll"](".sniper-mark");
  for (var _0x2ad84e = 0x0; _0x2ad84e < _0x1952aa["length"]; _0x2ad84e++)
    _0x1952aa[_0x2ad84e]["classList"]["add"]("flash");
}
function _0x1717d6() {
  var _0x5a3e81 = document["querySelectorAll"](".sniper-mark");
  for (var _0x3b84c1 = 0x0; _0x3b84c1 < _0x5a3e81["length"]; _0x3b84c1++)
    _0x5a3e81[_0x3b84c1]["classList"]["remove"]("flash");
}
function _0x22c43e(_0x18824f) {
  _0x18824f["classList"]["add"]("spin");
}
function _0x1aa8d8(_0x4ff2ce) {
  _0x4ff2ce["classList"]["remove"]("spin");
}
function _0x4f8550(_0x2c51f2) {
  _0x2c51f2["classList"]["add"]("flash");
}
function _0x7de440(_0x1404e3) {
  _0x1404e3["classList"]["remove"]("flash");
}
function _0x37d93c(_0x4bf1ad, _0x52172e) {
  console["log"]("flyInText:\x20started");
  const _0x12393a = _0x4bf1ad["split"]("");
  ((_0x52172e["innerHTML"] = ""),
    console["log"]("flyInText:\x20finished\x20clearing\x20element"));
  const _0x126d5c = document["createElement"]("style");
  ((_0x126d5c["innerHTML"] =
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20@keyframes\x20flyIn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20from\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateY(-100%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x200;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20to\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateY(0%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x201;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"),
    console["log"]("flyInText:\x20finished\x20creating\x20style"),
    document["head"]["appendChild"](_0x126d5c),
    console["log"](
      "flyInText:\x20finished\x20appending\x20style\x20to\x20head",
    ),
    _0x12393a["forEach"]((_0x334237, _0x58403c) => {
      const _0x4a00d3 = document["createElement"]("span");
      ((_0x4a00d3["innerHTML"] = _0x334237),
        (_0x4a00d3["style"]["opacity"] = "0"),
        (_0x4a00d3["style"]["animation"] =
          "flyIn\x200.1s\x20ease\x20forwards\x20" + _0x58403c / 0x23 + "s"),
        _0x52172e["appendChild"](_0x4a00d3));
    }),
    console["log"](
      "flyInText:\x20finished\x20appending\x20chars\x20to\x20element",
    ));
}
function _0x151be8(_0x19dfba, screenWidth, screenHeight, _0x53a03e) {
  const _0x5aa354 = document["createElement"]("div");
  return (
    (_0x5aa354["style"]["position"] = "absolute"),
    (_0x5aa354["style"]["fontSize"] = _0x19dfba + "px"),
    (_0x5aa354["style"]["zIndex"] = "9999999"),
    (_0x5aa354["speed"] = Math["random"]() * _0x53a03e + 0x1),
    Math["random"]() > 0.5 &&
      (_0x5aa354["style"]["color"] =
        "#" + Math["floor"](0xffffff * Math["random"]())["toString"](0x10)),
    _0x1757c6(_0x5aa354, screenWidth, screenHeight),
    document["body"]["appendChild"](_0x5aa354),
    _0x5aa354
  );
}
function _0x1757c6(_0x1e9a2f, screenWidth, screenHeight) {
  ((_0x1e9a2f["style"]["top"] = Math["random"]() * -screenHeight + "px"),
    (_0x1e9a2f["style"]["left"] =
      Math["floor"](Math["random"]() * screenWidth) + "px"),
    (_0x1e9a2f["style"]["opacity"] = 0x1));
}
function _0x2f5d2f(
  _0x1f6671,
  _0x56b96c,
  _0x4841db,
  _0x2ef84c,
  screenWidth,
  screenHeight,
  _0x2c7f3e,
) {
  const _0x5cfc54 = performance["now"]() - _0x2c7f3e;
  (_0x1f6671["forEach"]((_0x4e21c2) => {
    const _0x2fcca4 = parseFloat(_0x4e21c2["style"]["top"]),
      _0x3f032b = parseFloat(_0x4e21c2["style"]["left"]),
      _0x146725 = _0x4e21c2["speed"];
    if (_0x2fcca4 > screenHeight)
      _0x1757c6(_0x4e21c2, screenWidth, screenHeight);
    else
      ((_0x4e21c2["style"]["top"] =
        _0x2fcca4 + _0x146725 * (_0x5cfc54 / 0x3e8) + "px"),
        (_0x4e21c2["style"]["left"] =
          _0x3f032b + 0x2 * Math["random"]() - 0x1 + "px"),
        (_0x4e21c2["style"]["opacity"] = Math["max"](
          0x0,
          (_0x56b96c - _0x5cfc54) / _0x56b96c,
        )));
  }),
    _0x5cfc54 < _0x56b96c
      ? requestAnimationFrame(() =>
          _0x2f5d2f(
            _0x1f6671,
            _0x56b96c,
            _0x4841db,
            _0x2ef84c,
            screenWidth,
            screenHeight,
            _0x2c7f3e,
          ),
        )
      : _0x1f6671["forEach"]((_0x1779b6) => {
          document["body"]["removeChild"](_0x1779b6);
        }));
}
var _0x4dd8b7 = !0x1;
function _0x526aa4(_0x565abf, _0x6b67f1 = "image/x-icon") {
  var _0x19210f = "shortcut\x20icon";
  "image/gif" == _0x6b67f1 || "image/png" == _0x6b67f1
    ? (_0x19210f = "icon")
    : (_0x4dd8b7 = !0x1);
  var _0xab46e5 =
    document["querySelector"]("link[rel*=\x27icon\x27]") ||
    document["createElement"]("link");
  ((_0xab46e5["type"] = _0x6b67f1),
    (_0xab46e5["rel"] = _0x19210f),
    (_0xab46e5["href"] = _0x565abf),
    document["getElementsByTagName"]("head")[0x0]["appendChild"](_0xab46e5));
}
function _0x2271e7(_0x145b7f, _0x2789ae = "image/x-icon") {
  let _0x290376 =
      "image/gif" == _0x2789ae || "image/png" == _0x2789ae
        ? "icon"
        : "shortcut\x20icon",
    _0x53471f = document["querySelectorAll"]("link[rel*=\x27icon\x27]");
  if (0x0 === _0x53471f["length"]) {
    let _0x55ace4 = document["createElement"]("link");
    ((_0x55ace4["type"] = _0x2789ae),
      (_0x55ace4["rel"] = _0x290376),
      (_0x55ace4["href"] = _0x145b7f),
      document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x55ace4));
    return;
  }
  for (let _0x350894 of _0x53471f) {
    ((_0x350894["type"] = _0x2789ae),
      (_0x350894["rel"] = _0x290376),
      (_0x350894["href"] = _0x145b7f));
  }
}
function _0x2a3747() {
  _0x4dd8b7 = !0x0;
  var _0x4dfc9c = 0x0,
    _0x151915 = chrome["runtime"]["getURL"](
      "Favicons/Gifs/Gear/frame_" + _0x4dfc9c + "_delay-0.04s.gif",
    ),
    _0x40b18b = setInterval(function () {
      if (_0x4dd8b7 && _0x4dfc9c < 0x1c)
        (_0x526aa4(_0x151915, "image/gif"),
          _0x4dfc9c++,
          (_0x151915 = chrome["runtime"]["getURL"](
            "Favicons/Gifs/Gear/frame_" + _0x4dfc9c + "_delay-0.04s.gif",
          )));
      else {
        if (_0x4dd8b7 && _0x4dfc9c >= 0x1c)
          ((_0x4dfc9c = 0x0),
            (_0x151915 = chrome["runtime"]["getURL"](
              "Favicons/Gifs/Gear/frame_" + _0x4dfc9c + "_delay-0.04s.gif",
            )));
        else clearInterval(_0x40b18b);
      }
    }, 0x28);
}
function _0x16c7af() {
  _0x4dd8b7 = !0x0;
  var _0x54dcab = 0x0,
    _0x342f86 = chrome["runtime"]["getURL"](
      "Favicons/Task_Bar/" + _0x54dcab + ".png",
    ),
    _0x3f615f = setInterval(function () {
      if (_0x4dd8b7 && _0x54dcab < 0x1b)
        (_0x526aa4(_0x342f86, "image/gif"),
          _0x54dcab++,
          (_0x342f86 = chrome["runtime"]["getURL"](
            "Favicons/Task_Bar/" + _0x54dcab + ".png",
          )));
      else {
        if (_0x4dd8b7 && _0x54dcab >= 0x1b)
          ((_0x54dcab = 0x0),
            (_0x342f86 = chrome["runtime"]["getURL"](
              "Favicons/Task_Bar/" + _0x54dcab + ".png",
            )));
        else clearInterval(_0x3f615f);
      }
    }, 0x28);
}
function _0x47eb7a() {
  _0x4dd8b7 = !0x0;
  var _0x17217d = 0x0,
    _0x133c38 = [0x2, 0x8, 0xe, 0x14, 0x1a, 0x1b],
    _0x221d69 = 0x28,
    _0x5ac75b = "0.04s",
    _0x2d4038 = setInterval(function () {
      if (_0x4dd8b7) {
        _0x5ac75b = _0x133c38["includes"](_0x17217d) ? "0.05s" : "0.04s";
        var _0x252059 =
          "frame_" +
          _0x17217d["toString"]()["padStart"](0x2, "0") +
          "_delay-" +
          _0x5ac75b +
          ".gif";
        (_0x526aa4(
          chrome["runtime"]["getURL"]("Favicons/Sniper/" + _0x252059),
          "image/gif",
        ),
          ++_0x17217d >= 0x1b && (_0x17217d = 0x0),
          (_0x221d69 = "0.05s" === _0x5ac75b ? 0x32 : 0x28));
      } else clearInterval(_0x2d4038);
    }, _0x221d69);
}
async function _0x3abd25() {
  ((_0x4dd8b7 = !0x1),
    await new Promise((_0x2fea8b) => setTimeout(_0x2fea8b, 0x7d0)));
}
async function _0x34027e(_0x2c5fbd, _0x114f3b) {
  return new Promise((_0x4c64b1, _0x6b347e) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x2c5fbd, data: _0x114f3b },
      function (_0x1a6059) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x114f3b),
          console["log"]("fetchData\x20response", _0x1a6059),
          _0x4c64b1(_0x1a6059["data"]));
      },
    );
  });
}
async function _0x5191d0(_0x1534e5, _0x4dbbd6) {
  return new Promise((_0x10115d, _0x2ce090) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x1534e5, data: _0x4dbbd6 },
      function (_0x41137d) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x4dbbd6),
          console["log"]("fetchData\x20response", _0x41137d),
          _0x41137d["error"] && _0x2ce090(_0x41137d["error"]),
          _0x10115d(_0x41137d["data"]));
      },
    );
  });
}
async function fetchPrompt(_0x58de5) {
  var _0x31fa52 = chrome["runtime"]["getURL"](_0x58de5),
    _0x3e9068 = await fetch(_0x31fa52);
  return await _0x3e9068["text"]();
}
function _0x295736(_0x163565, _0x35f7f7 = 0.7, _0x2f1d7a = "text-davinci-003") {
  return new Promise((_0x3d23da, _0x596277) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "request-openAi",
        prompt: _0x163565,
        temperature: _0x35f7f7,
        model: _0x2f1d7a,
      },
      function (_0x36ac95) {
        _0x3d23da(_0x36ac95["response"]);
      },
    );
  });
}
function _0xf8b923(_0xd93f65) {
  if (!_0xd93f65["error"]) return _0xd93f65;
  alert(
    "OpenAI:\x20" +
      _0xd93f65["error"]["message"] +
      "\x0aENTER\x20IN\x20NEW\x20API\x20KEY",
  );
}
function _0x452cf5(_0x155651, _0x30188b) {
  return (
    console["log"]("test\x20save\x20to\x20local\x20storage"),
    console["log"]("key\x20" + _0x155651 + ",\x20value\x20" + _0x30188b),
    new Promise((_0x4c06f9, _0x38e2e4) => {
      chrome["storage"]["local"]["set"](
        { [_0x155651]: _0x30188b },
        function () {
          (console["log"]("my\x20key", _0x155651),
            chrome["storage"]["local"]["get"](_0x155651, function (_0x47a7f7) {
              (console["log"](
                "the\x20Value\x20currently\x20is\x20",
                _0x47a7f7[_0x155651],
              ),
                _0x4c06f9());
            }));
        },
      );
    })
  );
}
function _0x44fbe4(_0x2109c1) {
  return new Promise((_0x16aa35, _0x33f3d6) => {
    chrome["storage"]["local"]["get"](_0x2109c1, function (_0x4cc9ca) {
      (console["log"]("Value\x20currently\x20is\x20", _0x4cc9ca[_0x2109c1]),
        _0x16aa35(_0x4cc9ca[_0x2109c1]));
    });
  });
}
function _0x39af0a() {
  var _0x56b409 = document["createElement"]("table");
  return (
    _0x56b409["setAttribute"]("id", "listing-data-table"),
    _0x56b409["setAttribute"]("class", "styled-table"),
    _0x56b409["createTHead"]()["insertRow"](0x0),
    _0x56b409["createTBody"](),
    _0x56b409
  );
}
function _0x1c2793(_0x4d9090, _0x27e633) {
  var _0x2814cc = _0x27e633["headerName"],
    _0x1dd9cd = _0x2814cc["toLowerCase"]()["replace"](/ /g, "-"),
    _0x4ebc60 =
      _0x4d9090["querySelector"]("thead")["getElementsByTagName"]("tr")[0x0],
    _0x2a8c15 = document["createElement"]("th");
  ((_0x2a8c15["innerHTML"] = _0x2814cc),
    _0x2a8c15["setAttribute"]("class", _0x1dd9cd + "-header"),
    _0x4ebc60["appendChild"](_0x2a8c15));
}
function _0xf87b2e(_0x347bd6) {
  var _0x509133 = _0x347bd6["toLowerCase"]()["replace"](/ /g, "-");
  return document["querySelector"]("." + _0x509133 + "-header")["cellIndex"];
}
function _0x23a1c2(_0x5820a9) {
  var _0x554923 = _0x5820a9["querySelector"]("thead")
      ["getElementsByTagName"]("tr")[0x0]
      ["getElementsByTagName"]("th"),
    _0x134b03 =
      _0x5820a9["querySelector"]("tbody")["getElementsByTagName"]("tr"),
    _0x533a3f = _0x5820a9["querySelector"]("tbody")["insertRow"](
      _0x134b03["length"],
    );
  for (var _0x15c99d = 0x0; _0x15c99d < _0x554923["length"]; _0x15c99d++)
    _0x533a3f["insertCell"](_0x15c99d)["setAttribute"](
      "class",
      _0x554923[_0x15c99d]["innerHTML"]["toLowerCase"]()["replace"](/ /g, "-") +
        "-cell",
    );
  return _0x134b03["length"];
}
function _0x3380da(_0x4c1da3, _0xc6805) {
  var _0x121d0c = _0xc6805["rowNumber"],
    _0x298ef5 = _0xc6805["headerName"],
    _0x27a346 = _0xc6805["cellValue"],
    _0x1b7e1d = _0x298ef5["toLowerCase"]()["replace"](/ /g, "-");
  _0x4c1da3["querySelector"](
    "tbody\x20tr:nth-child(" + _0x121d0c + ")\x20td." + _0x1b7e1d + "-cell",
  )["innerHTML"] = _0x27a346;
}
function _0x100344(_0x37ca4e, _0x13eacf) {
  var _0xeba7b1 = _0x13eacf["button"],
    _0xcfcd80 = _0x13eacf["rowNumber"],
    _0x5455ed = _0x13eacf["headerName"]["toLowerCase"]()["replace"](/ /g, "-");
  _0x37ca4e["querySelector"](
    "tbody\x20tr:nth-child(" + _0xcfcd80 + ")\x20td." + _0x5455ed + "-cell",
  )["appendChild"](_0xeba7b1);
}
function _0x5afc20(_0x5a56ca, _0x501b27) {
  var _0x5791ad, _0x2fe0a2, _0x11b730, _0x13588c, _0x5c99cc, _0x50080c;
  ((_0x5a56ca = document["getElementById"](_0x5a56ca)), (_0x2fe0a2 = !0x0));
  for (; _0x2fe0a2; ) {
    ((_0x2fe0a2 = !0x1),
      (_0x5791ad = _0x5a56ca["getElementsByTagName"]("tr")),
      console["log"]("sortTable\x20rows", _0x5791ad));
    for (_0x11b730 = 0x1; _0x11b730 < _0x5791ad["length"] - 0x1; _0x11b730++) {
      _0x50080c = !0x1;
      var _0x443a10 = _0x5791ad[_0x11b730];
      (console["log"]("xRow", _0x443a10),
        (_0x13588c =
          _0x5791ad[_0x11b730]["getElementsByTagName"]("td")[
            _0xf87b2e(_0x501b27)
          ]),
        (_0x5c99cc =
          _0x5791ad[_0x11b730 + 0x1]["getElementsByTagName"]("td")[
            _0xf87b2e(_0x501b27)
          ]),
        console["log"]("sortTable\x20x", _0x13588c),
        console["log"]("sortTable\x20y", _0x5c99cc));
      if (
        _0x13588c["innerHTML"]["toLowerCase"]() >
        _0x5c99cc["innerHTML"]["toLowerCase"]()
      ) {
        _0x50080c = !0x0;
        break;
      }
    }
    _0x50080c &&
      (_0x5791ad[_0x11b730]["parentNode"]["insertBefore"](
        _0x5791ad[_0x11b730 + 0x1],
        _0x5791ad[_0x11b730],
      ),
      (_0x2fe0a2 = !0x0));
  }
}
function _0x5c457f(_0x5b5bf7) {
  var _0xcfef32 = _0x5b5bf7["buttonInnerText"],
    _0x107e0c = _0x5b5bf7["textAreaSelector"],
    _0x17c88e = _0x5b5bf7["valueToSet"],
    _0x580d09 = _0x5b5bf7["callback"],
    _0x5f5d0d = document["createElement"]("button");
  return (
    (_0x5f5d0d["innerText"] = _0xcfef32),
    (_0x5f5d0d["onclick"] = function () {
      ((document["querySelector"](_0x107e0c)["value"] = _0x17c88e),
        _0x580d09 && _0x580d09());
    }),
    _0x5f5d0d
  );
}
console["log"]("Sanitizer\x20loading");
var _0x498e3c = new (function () {
  var _0x2cc0d3 = {
      A: !0x0,
      ABBR: !0x0,
      B: !0x0,
      BLOCKQUOTE: !0x0,
      BODY: !0x0,
      BR: !0x0,
      CENTER: !0x0,
      CODE: !0x0,
      DIV: !0x0,
      EM: !0x0,
      FONT: !0x0,
      H1: !0x0,
      H2: !0x0,
      H3: !0x0,
      H4: !0x0,
      H5: !0x0,
      H6: !0x0,
      HR: !0x0,
      I: !0x0,
      LABEL: !0x0,
      LI: !0x0,
      OL: !0x0,
      P: !0x0,
      PRE: !0x0,
      SMALL: !0x0,
      SOURCE: !0x0,
      SPAN: !0x0,
      STRONG: !0x0,
      TABLE: !0x0,
      TBODY: !0x0,
      TR: !0x0,
      TD: !0x0,
      TH: !0x0,
      THEAD: !0x0,
      UL: !0x0,
      U: !0x0,
      VIDEO: !0x0,
    },
    _0x4c06f8 = { FORM: !0x0 },
    _0x19620f = {
      align: !0x0,
      color: !0x0,
      controls: !0x0,
      height: !0x0,
      src: !0x0,
      style: !0x0,
      target: !0x0,
      title: !0x0,
      type: !0x0,
      width: !0x0,
    },
    _0x2d5267 = {
      color: !0x0,
      "background-color": !0x0,
      "font-size": !0x0,
      "text-align": !0x0,
      "text-decoration": !0x0,
      "font-weight": !0x0,
    },
    _0x1cf20e = [""],
    _0x1d609c = { href: !0x0, action: !0x0 };
  this["SanitizeHtml"] = function (_0x823b82) {
    if ("" == (_0x823b82 = _0x823b82["trim"]())) return "";
    if ("<br>" == _0x823b82) return "";
    var _0x17fcb2 = document["createElement"]("iframe");
    if (void 0x0 === _0x17fcb2["sandbox"])
      return (
        alert(
          "Your\x20browser\x20does\x20not\x20support\x20sandboxed\x20iframes.\x20Please\x20upgrade\x20to\x20a\x20modern\x20browser.",
        ),
        ""
      );
    ((_0x17fcb2["sandbox"] = "allow-same-origin"),
      (_0x17fcb2["style"]["display"] = "none"),
      document["body"]["appendChild"](_0x17fcb2));
    var _0x427458 =
      _0x17fcb2["contentDocument"] || _0x17fcb2["contentWindow"]["document"];
    (null == _0x427458["body"] && _0x427458["write"]("<body></body>"),
      (_0x427458["body"]["innerHTML"] = _0x823b82));
    var _0x45e894 = (function _0x2f43a9(_0x2c52ad) {
      if (_0x2c52ad["nodeType"] == Node["TEXT_NODE"])
        var _0x451844 = _0x2c52ad["cloneNode"](!0x0);
      else {
        if (
          _0x2c52ad["nodeType"] == Node["ELEMENT_NODE"] &&
          (_0x2cc0d3[_0x2c52ad["tagName"]] || _0x4c06f8[_0x2c52ad["tagName"]])
        ) {
          if (
            ("SPAN" == _0x2c52ad["tagName"] ||
              "B" == _0x2c52ad["tagName"] ||
              "I" == _0x2c52ad["tagName"] ||
              "U" == _0x2c52ad["tagName"]) &&
            "" == _0x2c52ad["innerHTML"]["trim"]()
          )
            return document["createDocumentFragment"]();
          _0x451844 = _0x4c06f8[_0x2c52ad["tagName"]]
            ? _0x427458["createElement"]("DIV")
            : _0x427458["createElement"](_0x2c52ad["tagName"]);
          for (
            var _0x43a60f = 0x0;
            _0x43a60f < _0x2c52ad["attributes"]["length"];
            _0x43a60f++
          ) {
            var _0x474fd9 = _0x2c52ad["attributes"][_0x43a60f];
            if (_0x19620f[_0x474fd9["name"]]) {
              if ("style" == _0x474fd9["name"])
                for (s = 0x0; s < _0x2c52ad["style"]["length"]; s++) {
                  var _0x586239 = _0x2c52ad["style"][s];
                  _0x2d5267[_0x586239] &&
                    _0x451844["style"]["setProperty"](
                      _0x586239,
                      _0x2c52ad["style"]["getPropertyValue"](_0x586239),
                    );
                }
              else {
                if (
                  _0x1d609c[_0x474fd9["name"]] &&
                  _0x474fd9["value"]["indexOf"](":") > -0x1 &&
                  !_0x5cb279(_0x474fd9["value"], _0x1cf20e)
                )
                  continue;
                _0x451844["setAttribute"](
                  _0x474fd9["name"],
                  _0x474fd9["value"],
                );
              }
            }
          }
          for (
            _0x43a60f = 0x0;
            _0x43a60f < _0x2c52ad["childNodes"]["length"];
            _0x43a60f++
          ) {
            var _0x13a721 = _0x2f43a9(_0x2c52ad["childNodes"][_0x43a60f]);
            _0x451844["appendChild"](_0x13a721, !0x1);
          }
        } else _0x451844 = document["createDocumentFragment"]();
      }
      return _0x451844;
    })(_0x427458["body"]);
    return (
      document["body"]["removeChild"](_0x17fcb2),
      _0x45e894["innerHTML"]
        ["replace"](/<br[^>]*>(\S)/g, "<br>\x0a$1")
        ["replace"](/div><div/g, "div>\x0a<div")
    );
  };
  function _0x5cb279(_0x22710d, _0x4cf854) {
    for (var _0x5c04d7 = 0x0; _0x5c04d7 < _0x4cf854["length"]; _0x5c04d7++)
      if (0x0 == _0x22710d["indexOf"](_0x4cf854[_0x5c04d7])) return !0x0;
    return !0x1;
  }
  ((this["AllowedTags"] = _0x2cc0d3),
    (this["AllowedAttributes"] = _0x19620f),
    (this["AllowedCssStyles"] = _0x2d5267),
    (this["AllowedSchemas"] = _0x1cf20e));
})();
function _0x26858f(_0x137798, find, _0x3db9d8) {
  try {
    var _0x35aa05,
      _0x39fbed = "",
      _0x4e507 = _0x137798,
      _0x4d49a6 = find["toLowerCase"]();
    for (
      ;
      -0x1 !== (_0x35aa05 = _0x4e507["toLowerCase"]()["indexOf"](_0x4d49a6));

    ) {
      ((_0x39fbed += _0x4e507["substr"](0x0, _0x35aa05) + _0x3db9d8),
        (_0x4e507 = _0x4e507["substr"](_0x35aa05 + find["length"])));
    }
    return _0x39fbed + _0x4e507;
  } catch (_0x9c4a0) {
    return _0x137798;
  }
}
function _0x3b2373(_0x14d72b) {
  return _0x14d72b["charAt"](0x0)["toUpperCase"]() + _0x14d72b["slice"](0x1);
}
var _0x2c715f = (_0x428788, _0x361df7) => {
    console["log"]("test\x20waitUntilElementExists");
    var _0x11f442 = document["querySelector"](_0x428788);
    console["log"]("Checking");
    if (_0x11f442) return (console["log"]("Found"), _0x361df7(_0x11f442));
    setTimeout(() => _0x2c715f(_0x428788, _0x361df7), 0x1f4);
  },
  _0x12f4e0 = (_0x13e191, _0x57dd12) => {
    console["log"]("test");
    var _0x58ae04 = document["querySelectorAll"](_0x13e191)[0x0];
    console["log"]("Checking");
    if (_0x58ae04) return (console["log"]("Found"), _0x57dd12(_0x58ae04));
    setTimeout(() => _0x12f4e0(_0x13e191, _0x57dd12), 0x1f4);
  };
_0x2c715f = (_0x5b6d43, _0x2bb6f3) => {
  var _0x3e8420 = document["querySelector"](_0x5b6d43);
  console["log"]("Checking");
  if (_0x3e8420) return (console["log"]("Found"), _0x2bb6f3(_0x3e8420));
  setTimeout(() => _0x2c715f(_0x5b6d43, _0x2bb6f3), 0x1f4);
};
function _0x53b14c(_0x1ac6c8, _0x479a9f = 0x32, _0x33749a = 0x64) {
  const _0x567d30 = document["querySelector"](_0x1ac6c8);
  !window["__" + _0x1ac6c8] &&
    ((window["__" + _0x1ac6c8] = 0x0),
    (window["__" + _0x1ac6c8 + "__delay"] = _0x479a9f),
    (window["__" + _0x1ac6c8 + "__tries"] = _0x33749a));
  if (null === _0x567d30) {
    if (window["__" + _0x1ac6c8] >= window["__" + _0x1ac6c8 + "__tries"])
      return ((window["__" + _0x1ac6c8] = 0x0), Promise["resolve"](null));
    return new Promise((_0x50e65f) => {
      (window["__" + _0x1ac6c8]++,
        setTimeout(_0x50e65f, window["__" + _0x1ac6c8 + "__delay"]));
    })["then"](() => _0x53b14c(_0x1ac6c8));
  }
  return Promise["resolve"](_0x567d30);
}
function _0x11a5c9(
  _0x433f1b = document,
  _0x500565,
  _0x2b802c = 0x32,
  _0x201c6c = 0x64,
) {
  const _0x5c4bc9 = _0x433f1b["querySelector"](_0x500565);
  !window["__" + _0x500565] &&
    ((window["__" + _0x500565] = 0x0),
    (window["__" + _0x500565 + "__delay"] = _0x2b802c),
    (window["__" + _0x500565 + "__tries"] = _0x201c6c));
  if (null === _0x5c4bc9) {
    if (window["__" + _0x500565] >= window["__" + _0x500565 + "__tries"])
      return ((window["__" + _0x500565] = 0x0), Promise["resolve"](null));
    return new Promise((_0x8a71ae) => {
      (window["__" + _0x500565]++,
        setTimeout(_0x8a71ae, window["__" + _0x500565 + "__delay"]));
    })["then"](() => _0x53b14c(_0x500565));
  }
  return Promise["resolve"](_0x5c4bc9);
}
const _0x3e102a = { URL: "URL", BASE_64: "BASE_64" };
console["log"]("image_utils.js");
async function _0x5e1fad(_0xa339dc) {
  if (!_0xa339dc) throw new Error("Image\x20URL\x20is\x20required");
  var _0x320f25 = (_0x320f25 = await _0x269891(_0xa339dc))["b64Image"];
  return await _0x5d8657(_0x320f25);
}
function _0x269891(_0x3b7b66) {
  return new Promise((_0x4bac67, _0x2d0f0f) => {
    chrome["runtime"]["sendMessage"](
      { type: "url-to-b64", url: _0x3b7b66 },
      (_0x19e92a) => {
        _0x19e92a && _0x19e92a["error"]
          ? _0x2d0f0f(new Error(_0x19e92a["error"]))
          : _0x4bac67(_0x19e92a);
      },
    );
  });
}
const _0x30d976 = (_0x321bd4, _0x4ff0ad) => {
    ((trimmedString = _0x321bd4),
      _0x321bd4["startsWith"]("data") &&
        (trimmedString = _0x321bd4["split"](",")[0x1]));
    const _0x31a8a6 = atob(trimmedString),
      _0x5bc91a = new ArrayBuffer(_0x31a8a6["length"]),
      _0x458593 = new Uint8Array(_0x5bc91a);
    for (let _0x3a3fa0 = 0x0; _0x3a3fa0 < _0x31a8a6["length"]; _0x3a3fa0++)
      _0x458593[_0x3a3fa0] = _0x31a8a6["charCodeAt"](_0x3a3fa0);
    const _0x1b20d3 = new Blob([_0x5bc91a], { type: "image/jpeg" });
    return new File([_0x1b20d3], _0x4ff0ad, {
      lastModified: new Date()["getTime"](),
      type: "image/jpeg",
    });
  },
  _0x19ea09 = (_0x36a988, _0x218b3f) => {
    const _0x1553be = new DataTransfer();
    (_0x1553be["items"]["add"](_0x36a988),
      (_0x218b3f["files"] = _0x1553be["files"]));
    const _0x4bb702 = new Event("change", { bubbles: !0x0 });
    _0x218b3f["dispatchEvent"](_0x4bb702);
  };
var _0x1d99db = async (_0x351ac8, _0x27c4a1, _0x1da098, _0x4e6fef) => {
  let _0x228eb0;
  if (_0x4e6fef == _0x3e102a["URL"]) {
    const { b64Image: _0x1a8795 } = await _0x269891(_0x351ac8);
    _0x228eb0 = _0x30d976(_0x1a8795, _0x1da098);
  }
  _0x4e6fef == _0x3e102a["BASE_64"] &&
    (_0x228eb0 = _0x30d976(_0x351ac8, _0x1da098));
  var _0x486094 = document["querySelector"](_0x27c4a1);
  _0x19ea09(_0x228eb0, _0x486094);
};
async function _0x9886a5(
  _0x27d094,
  _0x53dd45,
  _0x12873d,
  _0x3e2bea,
  _0x231c25,
  _0x5dc49c,
  _0x26f6c5,
  _0x54c0a5,
) {
  var _0x61164f = await _0x5e1fad(_0x27d094);
  _0x61164f = await _0xd2e129(_0x61164f, _0x231c25, _0x5dc49c);
  var _0x51db78 = await _0x5e1fad(_0x12873d);
  ((_0x51db78 = await _0xd2e129(_0x51db78, 0.45 * _0x5dc49c, 0.45 * _0x231c25)),
    (_0x61164f = await _0xe783a9(_0x61164f, _0x51db78, 0.75)));
  var _0x5c6327 = await _0x5e1fad(_0x53dd45);
  return (
    (_0x5c6327 = await _0xd2e129(
      _0x5c6327,
      0.45 * _0x5dc49c,
      0.45 * _0x231c25,
    )),
    await _0x8bd0f3(_0x61164f, _0x5c6327, 0.95)
  );
}
async function _0x13ab3d(
  _0x365343,
  _0x399a3d,
  _0x4ef9bd,
  _0x9af5f9,
  _0x231021,
  _0x5942e6,
  _0xa2dc0f,
) {
  var _0x3f36c1 = await _0x5e1fad(_0x365343);
  _0x3f36c1 = await _0x30f1af(_0x3f36c1, _0x9af5f9, _0x231021);
  var _0x4213a3 = await _0x5e1fad(_0x399a3d);
  return (
    (_0x4213a3 = await _0x30f1af(
      _0x4213a3,
      0.45 * _0x231021,
      0.45 * _0x9af5f9,
    )),
    (_0x3f36c1 = await _0x37cbef(_0x3f36c1, _0x4213a3, "right")),
    (_0x4213a3 = await _0x30f1af(_0x4213a3, 0.4 * _0x231021, 0.4 * _0x9af5f9)),
    await _0x18801f(_0x3f36c1, _0x4213a3, 0.7, _0x399a3d)
  );
}
async function _0x1ccced(_0x38d0db) {
  var _0x5f29b7 = _0x38d0db["imageSource"],
    _0xfb357f = _0x38d0db["waterMarkUrl"],
    _0x36f3ca = await _0x5e1fad(_0x5f29b7);
  ((_0x36f3ca = await _0x504d23(_0x36f3ca)),
    (_0x36f3ca = await _0x146919(_0x36f3ca)));
  var _0x306591 = await _0x5e1fad(_0xfb357f);
  return (
    (_0x306591 = await _0x30f1af(
      _0x306591,
      0.2 * _0x36f3ca["height"],
      0.2 * _0x36f3ca["width"],
    )),
    (_0x306591 = await _0x504d23(_0x306591)),
    (_0x306591 = await _0x146919(_0x306591)),
    (_0x36f3ca = await _0x37cbef(_0x36f3ca, _0x306591, "right")),
    (_0x36f3ca = await _0x18801f(_0x36f3ca, _0x306591, 0.7))["width"] >
    _0x36f3ca["height"]
      ? (_0x36f3ca = await _0x53e2b3({
          imageObject: _0x36f3ca,
          padding: _0x36f3ca["width"] - _0x36f3ca["height"],
          paddingDirection: "height",
        }))
      : (_0x36f3ca["width"] < _0x36f3ca["height"] ||
          _0x36f3ca["width"] == _0x36f3ca["height"]) &&
        (_0x36f3ca = await _0x53e2b3({
          imageObject: _0x36f3ca,
          padding: _0x36f3ca["height"] - _0x36f3ca["width"],
          paddingDirection: "width",
        })),
    _0x36f3ca
  );
}
async function _0x4b41c4(_0x42b6fc, _0x5e235e = "Look", _0x35380e = "Inside") {
  var _0x50bffc = _0x42b6fc["imageSource"],
    _0x333b57 = _0x42b6fc["waterMarkUrl"],
    _0x58548e = await _0x5e1fad(_0x50bffc);
  ((_0x58548e = await _0x504d23(_0x58548e)),
    (_0x58548e = await _0x146919(_0x58548e)));
  var _0x12942a = await _0x5e1fad(_0x333b57);
  ((_0x12942a = await _0x30f1af(
    _0x12942a,
    0.2 * _0x58548e["height"],
    0.2 * _0x58548e["width"],
  )),
    (_0x12942a = await _0x504d23(_0x12942a)),
    (_0x12942a = await _0x146919(_0x12942a)));
  var _0x357dc9 = getProductDescriptionAndFeatures(),
    _0x2c4a2e = getFilteredTitle() + "\x0a\x0a" + _0x357dc9,
    _0x190c6f = await _0x34027e(
      "http://1.1.1.66:1102/api/ItemSpecifics/GetBuyerIntent",
      { request_type: "get_buyer_intent", productDescription: _0x2c4a2e },
    );
  console["log"]("twoWordBuyerIntent", _0x190c6f);
  var _0x55543a = _0x190c6f["split"]("\x20");
  _0x5e235e = _0x55543a[0x0];
  for (var _0x52f055 = 0x1; _0x52f055 < _0x55543a["length"]; _0x52f055++)
    _0x35380e += "\x20" + _0x55543a[_0x52f055];
  return (
    (_0x35380e = _0x35380e["trim"]()),
    (_0x5e235e = _0x5e235e["trim"]()),
    (_0x58548e = await _0x187fcb(_0x58548e, _0x5e235e, _0x35380e)),
    (_0x58548e = await _0x37cbef(_0x58548e, _0x12942a, "right")),
    (_0x58548e = await _0x3b0395(_0x58548e)),
    await _0x18801f(_0x58548e, _0x12942a, 0.7)
  );
}
async function _0x408d89(_0x114a22) {
  var _0x1e66a7 = _0x114a22["imageSource"],
    _0x4f6467 = _0x114a22["waterMarkUrl"],
    _0x1e8a81 = await _0x5e1fad(_0x1e66a7);
  ((_0x1e8a81 = await _0x504d23(_0x1e8a81)),
    (_0x1e8a81 = await _0x146919(_0x1e8a81)));
  var _0x237215 = await _0x5e1fad(_0x4f6467);
  return (
    (_0x237215 = await _0x30f1af(
      _0x237215,
      0.2 * _0x1e8a81["height"],
      0.2 * _0x1e8a81["width"],
    )),
    (_0x237215 = await _0x504d23(_0x237215)),
    (_0x237215 = await _0x146919(_0x237215)),
    (_0x1e8a81 = await _0x37cbef(_0x1e8a81, _0x237215, "right")),
    (_0x1e8a81 = await _0x3b0395(_0x1e8a81)),
    (_0x1e8a81 = await _0x18801f(_0x1e8a81, _0x237215, 0.7)),
    await _0x2e34ae(_0x1e8a81, 0x1f4, 0x1f4)
  );
}
function _0x3238e0(_0x396075) {
  ((imgWidth = _0x396075["width"]), (imgHeight = _0x396075["height"]));
  var _0x3a7d55 = document["createElement"]("canvas");
  (_0x3a7d55["setAttribute"]("width", imgWidth),
    _0x3a7d55["setAttribute"]("height", imgHeight));
  var _0x1700dd = _0x3a7d55["getContext"]("2d");
  _0x1700dd["drawImage"](_0x396075, 0x0, 0x0);
  var _0x5eb189 = _0x1700dd["getImageData"](0x0, 0x0, imgWidth, imgHeight)[
      "data"
    ],
    _0x232732 = function (_0x23dffd, _0x25adfd) {
      var _0x582a2c = imgWidth * _0x25adfd + _0x23dffd;
      return {
        red: _0x5eb189[0x4 * _0x582a2c],
        green: _0x5eb189[0x4 * _0x582a2c + 0x1],
        blue: _0x5eb189[0x4 * _0x582a2c + 0x2],
        opacity: _0x5eb189[0x4 * _0x582a2c + 0x3],
      };
    },
    _0x44984f = function (_0x42ee1e) {
      return (
        _0x42ee1e["red"] > 0xc8 &&
        _0x42ee1e["green"] > 0xc8 &&
        _0x42ee1e["blue"] > 0xc8
      );
    },
    _0x40be97 = function (_0x11fada) {
      var _0x59883f = _0x11fada ? 0x1 : -0x1;
      for (
        var _0x542a83 = _0x11fada ? 0x0 : imgHeight - 0x1;
        _0x11fada ? _0x542a83 < imgHeight : _0x542a83 > -0x1;
        _0x542a83 += _0x59883f
      )
        for (var _0x45a663 = 0x0; _0x45a663 < imgWidth; _0x45a663++) {
          var _0x26e433 = _0x232732(_0x45a663, _0x542a83);
          if (!_0x44984f(_0x26e433))
            return _0x11fada
              ? _0x542a83
              : Math["min"](_0x542a83 + 0x1, imgHeight);
        }
      return null;
    },
    _0x362773 = function (_0x2567db) {
      var _0x5c4dfd = _0x2567db ? 0x1 : -0x1;
      for (
        var _0xac74d5 = _0x2567db ? 0x0 : imgWidth - 0x1;
        _0x2567db ? _0xac74d5 < imgWidth : _0xac74d5 > -0x1;
        _0xac74d5 += _0x5c4dfd
      )
        for (var _0x3ddd37 = 0x0; _0x3ddd37 < imgHeight; _0x3ddd37++) {
          var _0x1cb9b2 = _0x232732(_0xac74d5, _0x3ddd37);
          if (!_0x44984f(_0x1cb9b2))
            return _0x2567db
              ? _0xac74d5
              : Math["min"](_0xac74d5 + 0x1, imgWidth);
        }
      return null;
    },
    _0x16b159 = _0x40be97(!0x0),
    _0x517177 = _0x40be97(!0x1),
    _0x398c8d = _0x362773(!0x0),
    _0x3ff830 = _0x362773(!0x1) - _0x398c8d,
    _0x1a3258 = _0x517177 - _0x16b159;
  return (
    _0x3a7d55["setAttribute"]("width", _0x3ff830),
    _0x3a7d55["setAttribute"]("height", _0x1a3258),
    _0x3a7d55["getContext"]("2d")["drawImage"](
      _0x396075,
      _0x398c8d,
      _0x16b159,
      _0x3ff830,
      _0x1a3258,
      0x0,
      0x0,
      _0x3ff830,
      _0x1a3258,
    ),
    _0x3a7d55["toDataURL"]()
  );
}
async function _0x238bd0(_0x233d23) {
  var _0x36b41e = _0x233d23["imageSource"],
    _0x3b5d6e = await _0x5e1fad(_0x36b41e);
  ((_0x3b5d6e = await _0x53e2b3({
    imageObject: _0x3b5d6e,
    padding: _0x3b5d6e["width"] - _0x3b5d6e["height"],
    paddingDirection: "height",
  })),
    (_0x3b5d6e = await _0x527a41(_0x3b5d6e, "black", "30px")),
    document["body"]["prepend"](_0x3b5d6e));
}
function _0x53e2b3(_0x2a0d24) {
  return new Promise((_0x1c6775, _0x441593) => {
    var _0x434e28 = _0x2a0d24["imageObject"],
      _0x3e2fd6 = _0x2a0d24["padding"],
      _0x9932dd = _0x2a0d24["paddingDirection"] || "all",
      _0x25bf43 = document["createElement"]("canvas");
    _0x25bf43["id"] = "myCanvas";
    var _0x19a7f5 = _0x25bf43["getContext"]("2d");
    "all" == _0x9932dd &&
      ((_0x25bf43["width"] = _0x434e28["width"] + _0x3e2fd6),
      (_0x25bf43["height"] = _0x434e28["height"] + _0x3e2fd6),
      (_0x19a7f5["fillStyle"] = "white"),
      _0x19a7f5["fillRect"](0x0, 0x0, _0x25bf43["width"], _0x25bf43["height"]),
      _0x19a7f5["drawImage"](_0x434e28, _0x3e2fd6 / 0x2, _0x3e2fd6 / 0x2));
    "height" == _0x9932dd &&
      ((_0x25bf43["width"] = _0x434e28["width"]),
      (_0x25bf43["height"] = _0x434e28["height"] + _0x3e2fd6),
      (_0x19a7f5["fillStyle"] = "white"),
      _0x19a7f5["fillRect"](0x0, 0x0, _0x25bf43["width"], _0x25bf43["height"]),
      _0x19a7f5["drawImage"](_0x434e28, 0x0, _0x3e2fd6 / 0x2));
    "width" == _0x9932dd &&
      ((_0x25bf43["width"] = _0x434e28["width"] + _0x3e2fd6),
      (_0x25bf43["height"] = _0x434e28["height"]),
      (_0x19a7f5["fillStyle"] = "white"),
      _0x19a7f5["fillRect"](0x0, 0x0, _0x25bf43["width"], _0x25bf43["height"]),
      _0x19a7f5["drawImage"](_0x434e28, _0x3e2fd6 / 0x2, 0x0));
    var _0x13f9fa = new Image();
    ((_0x13f9fa["onload"] = function () {
      _0x1c6775(_0x13f9fa);
    }),
      (_0x13f9fa["src"] = _0x25bf43["toDataURL"]()));
  });
}
async function _0x1febf2(
  _0x475426,
  _0x3989ce,
  _0x394f2a,
  _0x2edb31,
  _0x2ecf97,
  _0x22f205,
  _0x37eddc,
  _0x23d19b,
) {
  var _0x5c5816 = await _0x5e1fad(_0x475426);
  ((_0x5c5816 = await _0x30f1af(_0x5c5816, _0x2ecf97, _0x22f205)),
    (_0x5c5816 = await _0x504d23(_0x5c5816)));
  var _0x990d1b = await _0x5e1fad(_0x394f2a);
  ((_0x990d1b = await _0x504d23(_0x990d1b)),
    (_0x990d1b = await _0x30f1af(
      _0x990d1b,
      0.45 * _0x22f205,
      0.45 * _0x2ecf97,
    )));
  var _0x311fb6 = await _0x5e1fad(_0x3989ce);
  return (
    (_0x311fb6 = await _0x30f1af(
      _0x311fb6,
      0.45 * _0x22f205,
      0.45 * _0x2ecf97,
    )),
    (_0x5c5816 = await _0x37cbef(_0x5c5816, _0x311fb6, "right")),
    (_0x311fb6 = await _0x30f1af(_0x311fb6, 0.4 * _0x2ecf97, 0.4 * _0x22f205)),
    (_0x5c5816 = await _0x3e35c0(_0x5c5816, _0x311fb6, 0x1, 0xc)),
    (_0x990d1b = await _0x3a6238(
      _0x990d1b,
      0.65 * _0x311fb6["width"],
      0.65 * _0x311fb6["height"],
    )),
    (_0x990d1b = await _0x146919(_0x990d1b)),
    (_0x5c5816 = await _0x18801f(_0x5c5816, _0x990d1b, 0.7)),
    (_0x5c5816 = await _0x3b0395(_0x5c5816)),
    await _0x2e34ae(_0x5c5816, 0x1f4, 0x1f4)
  );
}
async function _0x161cfb(
  _0x302c73,
  _0x6b00c4,
  _0x31ff57,
  _0x4a0923,
  _0x29cc67,
  _0xc72426,
  _0x5b4e04,
  _0x12232d,
) {
  var _0x538676 = await _0x5e1fad(_0x302c73);
  ((_0x538676 = await _0x30f1af(_0x538676, _0x29cc67, _0xc72426)),
    (_0x538676 = await _0x504d23(_0x538676)));
  var _0x783806 = await _0x5e1fad(_0x31ff57);
  ((_0x783806 = await _0x30f1af(_0x783806, 0.45 * _0xc72426, 0.45 * _0x29cc67)),
    (waterMarkImg = await _0x504d23(_0x783806)),
    (waterMarkImg = await _0x146919(_0x783806)));
  var _0x293073 = await _0x5e1fad(_0x6b00c4);
  return (
    (_0x293073 = await _0x30f1af(
      _0x293073,
      0.45 * _0xc72426,
      0.45 * _0x29cc67,
    )),
    (_0x538676 = await _0x37cbef(_0x538676, _0x293073, "right")),
    (_0x783806 = await _0x3a6238(
      _0x783806,
      0.65 * _0x293073["width"],
      0.65 * _0x293073["height"],
    )),
    (_0x783806 = await _0x146919(_0x783806)),
    (_0x538676 = await _0x18801f(_0x538676, _0x783806, 0.7)),
    (_0x538676 = await _0x3b0395(_0x538676)),
    (_0x293073 = await _0x30f1af(_0x293073, 0.4 * _0x29cc67, 0.4 * _0xc72426)),
    (_0x538676 = await _0x3e35c0(_0x538676, _0x293073, 0x1, 0xc)),
    await _0x2e34ae(_0x538676, 0x1f4, 0x1f4)
  );
}
async function _0x5250e0(
  _0x2b4052,
  _0x2ef411,
  _0x5ec182,
  _0x297f2c,
  _0x388296,
  _0x39441f,
  _0x35903a,
  _0xe5e33f,
) {
  var _0x531823 = await _0x5e1fad(_0x2b4052);
  ((_0x531823 = await _0x30f1af(_0x531823, _0x388296, _0x39441f)),
    (_0x531823 = await _0x504d23(_0x531823)));
  var _0x4908d8 = await _0x5e1fad(_0x5ec182);
  ((_0x4908d8 = await _0x30f1af(_0x4908d8, 0.45 * _0x39441f, 0.45 * _0x388296)),
    (waterMarkImg = await _0x504d23(_0x4908d8)),
    (waterMarkImg = await _0x146919(_0x4908d8)));
  var _0x4eefc4 = await _0x5e1fad(_0x2ef411);
  return (
    (_0x4eefc4 = await _0x30f1af(
      _0x4eefc4,
      0.45 * _0x39441f,
      0.45 * _0x388296,
    )),
    (_0x531823 = await _0x37cbef(_0x531823, _0x4eefc4, "right")),
    (_0x531823 = await _0x3b0395(_0x531823)),
    (_0x4908d8 = await _0x3a6238(
      _0x4908d8,
      0.65 * _0x4eefc4["width"],
      0.65 * _0x4eefc4["height"],
    )),
    (_0x4908d8 = await _0x146919(_0x4908d8)),
    (_0x531823 = await _0x18801f(_0x531823, _0x4908d8, 0.7)),
    (_0x4eefc4 = await _0x30f1af(_0x4eefc4, 0.4 * _0x388296, 0.4 * _0x39441f)),
    (_0x531823 = await _0x3e35c0(_0x531823, _0x4eefc4, 0x1, 0xc)),
    (_0x531823 = await _0x262057(_0x531823)),
    (_0x531823 = await _0x5432b0(_0x531823)),
    await _0x2e34ae(_0x531823, 0x1f4, 0x1f4)
  );
}
function _0x323e81(_0x9fd88e, _0x2f2a67, _0x35a9ad) {
  return new Promise(async (_0x2b2f40, _0x207969) => {
    let _0x134602 = document["createElement"]("canvas");
    ((_0x134602["width"] = _0x9fd88e["width"]),
      (_0x134602["height"] = _0x9fd88e["height"]));
    let _0x519b8f = _0x134602["getContext"]("2d");
    ((_0x519b8f["fillStyle"] = _0x35a9ad),
      _0x519b8f["fillRect"](0x0, 0x0, _0x134602["width"], _0x134602["height"]),
      _0x519b8f["drawImage"](
        _0x9fd88e,
        0x0,
        0x0,
        _0x9fd88e["width"],
        _0x9fd88e["height"],
      ));
    var _0x3ac213 = new Image();
    ((_0x3ac213["onload"] = function () {
      _0x2b2f40(_0x3ac213);
    }),
      (_0x3ac213["src"] = _0x134602["toDataURL"]()));
  });
}
async function _0x23dfca(
  _0x35a4c9,
  _0x2cfd70,
  _0x2b97e3,
  _0x535e75,
  _0x120b31,
  _0x4d4fd3,
  _0x286568,
  _0x37f528,
) {
  var _0x14299c = await _0x5e1fad(_0x35a4c9);
  ((_0x14299c = await _0x30f1af(_0x14299c, _0x120b31, _0x4d4fd3)),
    (_0x14299c = await _0x504d23(_0x14299c)));
  var _0x53b088 = await _0x5e1fad(_0x2b97e3);
  _0x53b088 = await _0x30f1af(_0x53b088, 0.45 * _0x4d4fd3, 0.45 * _0x120b31);
  var _0x9c9d6a = await _0x5e1fad(_0x2cfd70);
  return (
    (_0x9c9d6a = await _0x30f1af(
      _0x9c9d6a,
      0.45 * _0x4d4fd3,
      0.45 * _0x120b31,
    )),
    (_0x9c9d6a = await _0x146919(_0x9c9d6a)),
    (_0x9c9d6a = await _0x323e81(_0x9c9d6a, _0x2cfd70, "beige")),
    (_0x14299c = await _0x37cbef(_0x14299c, _0x9c9d6a, "right")),
    (_0x9c9d6a = await _0x30f1af(_0x9c9d6a, 0.4 * _0x120b31, 0.4 * _0x4d4fd3)),
    (_0x14299c = await _0x3e35c0(_0x14299c, _0x9c9d6a, 0x1, 0xc)),
    (_0x53b088 = await _0x504d23(_0x53b088)),
    (_0x53b088 = await _0x3a6238(
      _0x53b088,
      _0x9c9d6a["width"],
      _0x9c9d6a["height"],
    )),
    (_0x53b088 = await _0x146919(_0x53b088)),
    (_0x14299c = await _0x18801f(_0x14299c, _0x53b088, 0.7, _0x2b97e3)),
    (_0x14299c = await _0x3b0395(_0x14299c)),
    (_0x14299c = await _0x262057(_0x14299c)),
    (_0x14299c = await _0x5432b0(_0x14299c)),
    await _0x2e34ae(_0x14299c, 0x1f4, 0x1f4)
  );
}
async function _0xd99ff6(
  _0x2eedaf,
  _0x3b9ddd,
  _0x334013,
  _0x1f62c4,
  _0x1dc1a2,
  _0x498317,
  _0x1c7ed7,
  _0x24f4c9,
  _0x31d531,
  _0x40024d,
) {
  var _0x87d82f = await _0x5e1fad(_0x2eedaf);
  _0x87d82f = await _0xd2e129(_0x87d82f, _0x1c7ed7, _0x24f4c9);
  var _0x571876 = await _0x5e1fad(_0x334013);
  _0x571876 = await _0x30f1af(_0x571876, 0.45 * _0x24f4c9, 0.45 * _0x1c7ed7);
  var _0x231f1f = await _0x5e1fad(_0x3b9ddd);
  ((_0x231f1f = await _0x30f1af(_0x231f1f, 0.45 * _0x24f4c9, 0.45 * _0x1c7ed7)),
    (_0x87d82f = await _0x37cbef(_0x87d82f, _0x231f1f, "right")),
    (_0x231f1f = await _0x30f1af(_0x231f1f, 0.4 * _0x24f4c9, 0.4 * _0x1c7ed7)),
    (_0x571876 = await _0x30f1af(_0x571876, 0.4 * _0x24f4c9, 0.4 * _0x1c7ed7)),
    (_0x87d82f = await _0x3e35c0(_0x87d82f, _0x231f1f, 0x1, 0xc)),
    (_0x571876 = await _0x146919(_0x571876)),
    (_0x87d82f = await _0x18801f(_0x87d82f, _0x571876, 0.7)));
  var _0x5aa9a9 = await _0x5e1fad(_0x1f62c4);
  ((_0x5aa9a9 = await _0x22254f(_0x5aa9a9)),
    (_0x5aa9a9 = await _0x30f1af(
      _0x5aa9a9,
      0.45 * _0x24f4c9,
      0.45 * _0x1c7ed7,
    )));
  var _0x3f36cb = await _0x5e1fad(_0x1dc1a2);
  _0x3f36cb = await _0x22254f(_0x3f36cb);
  if (
    (_0x3f36cb = await _0x30f1af(
      _0x3f36cb,
      0.45 * _0x24f4c9,
      0.45 * _0x1c7ed7,
    ))["width"] >= _0x5aa9a9["width"]
  )
    ((_0x87d82f = await _0x37cbef(_0x87d82f, _0x3f36cb, "left")),
      (_0x3f36cb = await _0x30f1af(
        _0x3f36cb,
        0.4 * _0x24f4c9,
        0.4 * _0x1c7ed7,
      )),
      (_0x5aa9a9 = await _0x30f1af(
        _0x5aa9a9,
        0.4 * _0x24f4c9,
        0.4 * _0x1c7ed7,
      )),
      (_0x87d82f = await _0x45f103(_0x87d82f, _0x3f36cb, 0x1, 0xc)),
      (_0x87d82f = await _0x4712d9(_0x87d82f, _0x5aa9a9, 0x1)));
  else
    _0x5aa9a9["width"] > _0x3f36cb["width"] &&
      ((_0x87d82f = await _0x37cbef(_0x87d82f, _0x5aa9a9, "left")),
      (_0x3f36cb = await _0x30f1af(
        _0x3f36cb,
        0.4 * _0x24f4c9,
        0.4 * _0x1c7ed7,
      )),
      (_0x5aa9a9 = await _0x30f1af(
        _0x5aa9a9,
        0.4 * _0x24f4c9,
        0.4 * _0x1c7ed7,
      )),
      (_0x87d82f = await _0x4712d9(_0x87d82f, _0x5aa9a9, 0x1)),
      (_0x87d82f = await _0x45f103(_0x87d82f, _0x3f36cb, 0x1, 0xc)));
  return await _0x2e34ae(_0x87d82f, 0x1f4, 0x1f4);
}
function _0x527a41(_0x347f12, _0x11f58a, _0x28eaad) {
  return new Promise((_0x245a47, _0xb8088a) => {
    var _0x101302 = document["createElement"]("canvas");
    ((_0x101302["width"] = _0x347f12["width"]),
      (_0x101302["height"] = _0x347f12["height"]));
    var _0x320d48 = _0x101302["getContext"]("2d");
    (_0x320d48["drawImage"](_0x347f12, 0x0, 0x0),
      (_0x320d48["strokeStyle"] = _0x11f58a),
      (_0x320d48["lineWidth"] = _0x28eaad),
      _0x320d48["strokeRect"](
        0x0,
        0x0,
        _0x101302["width"],
        _0x101302["height"],
      ));
    var _0x435d22 = new Image();
    ((_0x435d22["onload"] = function () {
      _0x245a47(_0x435d22);
    }),
      (_0x435d22["src"] = _0x101302["toDataURL"]()));
  });
}
async function _0x54839f(
  _0x89c3a1,
  _0xb7bcfe,
  _0x3ebddb,
  _0x5c8517,
  _0x5094c7,
  _0x4ae083,
  _0x5a7975,
) {
  var _0x149843 = await _0x5e1fad(_0x89c3a1);
  _0x149843 = await _0xd2e129(_0x149843, _0x5c8517, _0x5094c7);
  var _0x38b1de = await _0x5e1fad(
    "https://centreforinquiry.ca/wp-content/uploads/2020/05/68353859-canadian-map-with-canada-flag.jpg",
  );
  ((_0x38b1de = await _0xd2e129(_0x38b1de, 0.45 * _0x5094c7, 0.45 * _0x5c8517)),
    (_0x149843 = await _0xe783a9(_0x149843, _0x38b1de, 0.75)));
  var _0x4c29a1 = await _0x5e1fad(_0xb7bcfe);
  return (
    (_0x4c29a1 = await _0x22254f(_0x4c29a1)),
    (_0x4c29a1 = await _0x1af62f(_0x4c29a1)),
    (_0x4c29a1 = await _0x4f86c3(_0x4c29a1, 0xa)),
    (_0x4c29a1 = await _0xd2e129(
      _0x4c29a1,
      0.45 * _0x5094c7,
      0.45 * _0x5c8517,
    )),
    (_0x149843 = await _0x8bd0f3(_0x149843, _0x4c29a1, 0.95)),
    (_0x149843 = await _0x2c1db7(_0x149843, _0x3ebddb, _0x4ae083, _0x5a7975)),
    await _0x22254f(_0x149843)
  );
}
function _0x22254f(_0x49b4dd) {
  return new Promise(function (_0x11205d, _0x269f2f) {
    let _0x79e29a = document["createElement"]("canvas");
    ((_0x79e29a["width"] = _0x49b4dd["width"]),
      (_0x79e29a["height"] = _0x49b4dd["height"]));
    let _0xc3b647 = _0x79e29a["getContext"]("2d");
    ((_0xc3b647["fillStyle"] = "white"),
      _0xc3b647["fillRect"](0x0, 0x0, _0x79e29a["width"], _0x79e29a["height"]),
      _0xc3b647["drawImage"](
        _0x49b4dd,
        0x0,
        0x0,
        _0x79e29a["width"],
        _0x79e29a["height"],
      ),
      (_0xc3b647["strokeStyle"] = "black"),
      (_0xc3b647["lineWidth"] = 0x1e),
      _0xc3b647["strokeRect"](
        0x0,
        0x0,
        _0x79e29a["width"],
        _0x79e29a["height"],
      ));
    var _0x4965bd = new Image();
    ((_0x4965bd["onload"] = function () {
      _0x11205d(_0x4965bd);
    }),
      (_0x4965bd["src"] = _0x79e29a["toDataURL"]()));
  });
}
function _0x8bd0f3(_0x5bd222, _0x8976b1, _0xfd408b) {
  return new Promise(function (_0x5c405b, _0x3188ab) {
    let _0x2c8ca2 = document["createElement"]("canvas");
    ((_0x2c8ca2["width"] = _0x5bd222["width"]),
      (_0x2c8ca2["height"] = _0x5bd222["height"]));
    let _0x347e46 = _0x2c8ca2["getContext"]("2d");
    ((_0x347e46["fillStyle"] = "white"),
      _0x347e46["fillRect"](0x0, 0x0, _0x2c8ca2["width"], _0x2c8ca2["height"]),
      _0x347e46["drawImage"](_0x5bd222, 0x0, 0x0),
      (_0x347e46["globalAlpha"] = _0xfd408b));
    var _0x382568 =
        _0x2c8ca2["width"] - _0x8976b1["width"] - _0x2c8ca2["width"] / 0x32,
      _0xdfc2ef =
        _0x2c8ca2["height"] - _0x8976b1["height"] - _0x2c8ca2["height"] / 0xc;
    _0x347e46["drawImage"](_0x8976b1, _0x382568, _0xdfc2ef);
    var _0x1f85e5 = new Image();
    ((_0x1f85e5["onload"] = function () {
      _0x5c405b(_0x1f85e5);
    }),
      (_0x1f85e5["src"] = _0x2c8ca2["toDataURL"]()));
  });
}
async function _0xa494fb(
  _0x5b4dea,
  _0x3dc25a,
  _0x3f9790,
  _0x21eb3d,
  _0x599ab2,
) {
  var _0x1394d8 = localStorage["getItem"]("waterMarkUrl"),
    _0x95ac1b = await _0x5e1fad(_0x5b4dea);
  _0x95ac1b = await _0xd2e129(_0x95ac1b, _0x21eb3d, _0x599ab2);
  var _0x4ed9ce = await _0x5e1fad(_0x1394d8);
  ((_0x4ed9ce = await _0xd2e129(_0x4ed9ce, 0.4 * _0x599ab2, 0.4 * _0x21eb3d)),
    (_0x95ac1b = await _0xe783a9(_0x95ac1b, _0x4ed9ce, 0.75)),
    (_0x95ac1b = await _0x2c1db7(_0x95ac1b, _0x3dc25a)),
    upload(_0x95ac1b["src"], _0x3dc25a, _0x3f9790));
}
async function _0x335cad(
  _0x38e734,
  _0xd13fb8,
  _0x471fca,
  _0x1cff51,
  _0x2a0e4d,
) {
  localStorage["getItem"]("waterMarkUrl");
  var _0x117985 = await _0x5e1fad(_0x38e734);
  ((_0x117985 = await _0x4f86c3(_0x117985, 0x0)),
    (_0x117985 = await _0xd2e129(_0x117985, _0x1cff51, _0x2a0e4d)),
    upload(_0x117985["src"], _0xd13fb8, _0x471fca));
}
function _0x37e08a(_0x31463b) {
  var _0x5156ab = document["createElement"]("img");
  ((_0x5156ab["src"] = _0x31463b),
    document["getElementsByTagName"]("html")[0x0]["appendChild"](_0x5156ab));
}
function _0x37ed33(_0xd2266f) {
  return new Promise(function (_0x4cdbb0, _0x39bd4d) {
    var _0x20382a = new Image();
    ((_0x20382a["src"] = _0xd2266f),
      (_0x20382a["crossOrigin"] = "anonymous"),
      (_0x20382a["onload"] = function () {
        _0x4cdbb0(_0x20382a);
      }));
  });
}
async function _0x2c1db7(_0x54e4e7, _0x2eeca9, _0x236851, _0x4aca60) {
  var _0x4169db = await _0x41ef78(_0x54e4e7, _0x2eeca9, _0x236851, _0x4aca60);
  return await _0x446290(_0x54e4e7, _0x2eeca9, _0x4169db, _0x236851, _0x4aca60);
}
function _0x446290(_0x38133d, _0x1d9c72, _0x283145, _0x161b8b, _0x123da6) {
  return new Promise(function (_0x192ad4, _0x2c6d71) {
    var _0x1e6444 = document["createElement"]("canvas");
    _0x1e6444["id"] = "myCanvas";
    var _0xfd78c4 = (_0x38133d["height"] / 0xa) * 0.45,
      _0x43dad1 = _0xfd78c4 + _0xfd78c4 / 0x2,
      _0x125ce7 = _0xfd78c4;
    ((_0x1e6444["width"] = _0x38133d["width"]),
      (_0x1e6444["height"] = _0x38133d["height"] + _0x43dad1 * _0x283145));
    var _0x279056 = _0x1e6444["getContext"]("2d");
    ((_0x279056["fillStyle"] = "white"),
      _0x279056["fillRect"](0x0, 0x0, _0x1e6444["width"], _0x1e6444["height"]));
    var _0x29c1a6 = _0x1e6444["width"],
      _0x4bc0c4 = _0x1e6444["height"] * (0x46 / 0x5dc);
    ((_0x279056["fillStyle"] = _0x161b8b),
      (_0x279056["font"] = _0xfd78c4 + "px\x20" + _0x123da6),
      _0x359b56(_0x279056, _0x1d9c72, 0x0, _0x125ce7, _0x29c1a6, _0x4bc0c4),
      _0x279056["drawImage"](_0x38133d, 0x0, _0x43dad1 * _0x283145));
    let _0x2eef3e = new Image();
    ((_0x2eef3e["crossOrigin"] = "anonymous"),
      (_0x2eef3e["src"] = _0x1e6444["toDataURL"]()),
      (_0x2eef3e["onload"] = function () {
        _0x192ad4(_0x2eef3e);
      }));
  });
}
function _0x6f9525(_0x28c5af) {
  var _0x43f399 = (_0x28c5af["height"] / 0xa) * 1.5,
    _0x22c7eb = _0x43f399 + _0x43f399 / 0x2,
    _0xab6b00 = _0x43f399;
  return new Promise(function (_0x519d75, _0x20046a) {
    var _0x1c54b4 = document["createElement"]("canvas");
    ((_0x1c54b4["id"] = "myCanvas"),
      (_0x1c54b4["width"] = _0x28c5af["width"]),
      (_0x1c54b4["height"] = _0x28c5af["height"] + 0x1 * _0x22c7eb));
    var _0x1f60d4 = _0x1c54b4["getContext"]("2d");
    ((_0x1f60d4["fillStyle"] = "white"),
      _0x1f60d4["fillRect"](0x0, 0x0, _0x1c54b4["width"], _0x1c54b4["height"]),
      _0x1c54b4["width"],
      (_0x1f60d4["fillStyle"] = "#F79148"),
      (_0x1f60d4["font"] = "bold\x20" + _0x43f399 + "px\x20Arial"),
      _0x1f60d4["fillText"]("Look\x20", 0x0, _0xab6b00));
    var _0x216155 = _0x1f60d4["measureText"]("Look\x20")["width"];
    ((_0x1f60d4["fillStyle"] = "#34B8FF"),
      (_0x1f60d4["font"] = "bold\x20" + _0x43f399 + "px\x20Arial"),
      _0x1f60d4["fillText"]("Inside\x20⤸", 0x0 + _0x216155, _0xab6b00),
      _0x1f60d4["drawImage"](_0x28c5af, 0x0, 0x1 * _0x22c7eb));
    var _0x282230 = new Image();
    ((_0x282230["crossOrigin"] = "anonymous"),
      (_0x282230["src"] = _0x1c54b4["toDataURL"]()),
      (_0x282230["onload"] = function () {
        _0x519d75(_0x282230);
      }));
  });
}
function _0x187fcb(_0x2c90a0, _0x57d58a, _0x1ef148) {
  _0x1ef148 += "\x20⤸";
  var _0x2ac39f = _0x2c90a0["width"],
    _0x28d0a4 = _0x2c90a0["width"] / 0xa,
    _0x4de230 = _0x28d0a4 + _0x28d0a4 / 0x2,
    _0x4a126b = _0x28d0a4;
  return new Promise(function (_0x1e385c, _0x4a34ca) {
    var _0x9d8a78 = document["createElement"]("canvas");
    ((_0x9d8a78["id"] = "myCanvas"),
      (_0x9d8a78["width"] = _0x2c90a0["width"]),
      (_0x9d8a78["height"] = _0x2c90a0["height"] + 0x1 * _0x4de230));
    var _0x47f22f = _0x9d8a78["getContext"]("2d");
    ((_0x47f22f["fillStyle"] = "white"),
      _0x47f22f["fillRect"](0x0, 0x0, _0x9d8a78["width"], _0x9d8a78["height"]),
      (_0x47f22f["fillStyle"] = "#34B8FF"),
      (_0x47f22f["font"] = "bold\x20" + _0x28d0a4 + "px\x20Arial"),
      _0x47f22f["fillText"](_0x57d58a, 0x0, _0x4a126b));
    var _0x576ecb = _0x47f22f["measureText"](_0x57d58a)["width"],
      _0x1193d4 = ((_0x2ac39f - _0x576ecb) / _0x1ef148["length"]) * 0x2;
    ((_0x47f22f["fillStyle"] = "#F79148"),
      (_0x47f22f["font"] = "bold\x20" + _0x1193d4 + "px\x20Arial"),
      _0x47f22f["fillText"](_0x1ef148, 0x0 + _0x576ecb, _0x4a126b),
      _0x47f22f["drawImage"](_0x2c90a0, 0x0, 0x1 * _0x4de230));
    var _0x2c13d5 = new Image();
    ((_0x2c13d5["crossOrigin"] = "anonymous"),
      (_0x2c13d5["src"] = _0x9d8a78["toDataURL"]()),
      (_0x2c13d5["onload"] = function () {
        _0x1e385c(_0x2c13d5);
      }));
  });
}
function _0x41ef78(_0x509221, _0x5326ae, _0x297a36, _0x20e0d5) {
  return new Promise((_0x20d51a) => {
    var _0x330178 = document["createElement"]("canvas");
    _0x330178["id"] = "myCanvas";
    var _0x4bc6ec = (_0x509221["height"] / 0xa) * 0.45,
      _0x5141c1 = _0x4bc6ec;
    ((_0x330178["width"] = _0x509221["width"]),
      (_0x330178["height"] = _0x509221["height"]));
    var _0x1decb3 = _0x330178["getContext"]("2d");
    ((_0x1decb3["fillStyle"] = "white"),
      _0x1decb3["fillRect"](0x0, 0x0, _0x330178["width"], _0x330178["height"]));
    var _0x4a8ff4 = _0x330178["width"],
      _0x5cbd82 = _0x330178["height"] * (0x46 / 0x5dc);
    ((_0x1decb3["fillStyle"] = _0x297a36),
      (_0x1decb3["font"] = _0x4bc6ec + "px\x20" + _0x20e0d5));
    var _0x2b4fea = 0x1,
      _0x4fadbf = _0x5326ae["split"]("\x20"),
      _0x8c7274 = "";
    for (var _0x971c0f = 0x0; _0x971c0f < _0x4fadbf["length"]; _0x971c0f++) {
      var _0x5876a6 = _0x8c7274 + _0x4fadbf[_0x971c0f] + "\x20";
      if (
        _0x1decb3["measureText"](_0x5876a6)["width"] > _0x4a8ff4 &&
        _0x971c0f > 0x0
      )
        (_0x2b4fea++,
          _0x1decb3["fillText"](_0x8c7274, 0x0, _0x5141c1),
          (_0x8c7274 = _0x4fadbf[_0x971c0f] + "\x20"),
          (_0x5141c1 += _0x5cbd82));
      else _0x8c7274 = _0x5876a6;
    }
    _0x20d51a(_0x2b4fea);
  });
}
function _0x359b56(
  _0x478d1,
  _0x3f1937,
  _0x547b0,
  _0x20eaf0,
  _0x56fd86,
  _0x22867d,
) {
  var _0x353329 = _0x3f1937["split"]("\x20"),
    _0x3a370f = "";
  for (var _0x3ea1c2 = 0x0; _0x3ea1c2 < _0x353329["length"]; _0x3ea1c2++) {
    var _0x4c16e5 = _0x3a370f + _0x353329[_0x3ea1c2] + "\x20";
    if (
      _0x478d1["measureText"](_0x4c16e5)["width"] > _0x56fd86 &&
      _0x3ea1c2 > 0x0
    )
      (_0x478d1["fillText"](_0x3a370f, _0x547b0, _0x20eaf0),
        (_0x3a370f = _0x353329[_0x3ea1c2] + "\x20"),
        (_0x20eaf0 += _0x22867d));
    else _0x3a370f = _0x4c16e5;
  }
  _0x478d1["fillText"](_0x3a370f, _0x547b0, _0x20eaf0);
}
function _0x1af62f(_0x1e5c31) {
  return new Promise(function (_0x342bb5, _0x29ae8f) {
    var _0x4b7bd3 = document["createElement"]("canvas");
    ((_0x4b7bd3["id"] = "myCanvas"),
      (_0x4b7bd3["width"] = _0x1e5c31["width"]),
      (_0x4b7bd3["height"] = _0x1e5c31["height"]));
    var _0x2170fe = _0x4b7bd3["getContext"]("2d");
    ((_0x2170fe["fillStyle"] = "white"),
      _0x2170fe["fillRect"](0x0, 0x0, _0x4b7bd3["width"], _0x4b7bd3["height"]),
      _0x2170fe["translate"](_0x4b7bd3["width"], 0x0),
      _0x2170fe["scale"](-0x1, 0x1),
      _0x2170fe["drawImage"](_0x1e5c31, 0x0, 0x0));
    let _0x332318 = new Image();
    ((_0x332318["crossOrigin"] = "anonymous"),
      (_0x332318["src"] = _0x4b7bd3["toDataURL"]()),
      (_0x332318["onload"] = function () {
        _0x342bb5(_0x332318);
      }));
  });
}
function _0xd2e129(_0x2acc8b, _0x4b1f9d, _0x7566f) {
  return new Promise(function (_0x896dc1, _0x3ded35) {
    var _0x4b2a53 = document["createElement"]("canvas");
    ((_0x4b2a53["id"] = "myCanvas"),
      (_0x4b2a53["width"] = _0x4b1f9d),
      (_0x4b2a53["height"] = _0x7566f));
    var _0x582008 = _0x4b2a53["getContext"]("2d");
    ((_0x582008["fillStyle"] = "white"),
      _0x582008["fillRect"](0x0, 0x0, _0x4b2a53["width"], _0x4b2a53["height"]));
    var _0x4872d4 = _0x4b1f9d / 0x2,
      _0x18e0c2 = _0x7566f / 0x2,
      _0x2464ba = 0x1;
    (_0x2acc8b["width"] > _0x2acc8b["height"] &&
      (_0x2464ba = _0x4b1f9d / _0x2acc8b["width"]),
      _0x2acc8b["width"] < _0x2acc8b["height"] &&
        (_0x2464ba = _0x4b1f9d / _0x2acc8b["height"]),
      _0x2acc8b["width"] === _0x2acc8b["height"] &&
        (_0x2464ba = _0x4b1f9d / _0x2acc8b["height"]));
    var _0x1b77f2 = _0x2acc8b["width"] * _0x2464ba,
      _0x4d26a9 = _0x2acc8b["height"] * _0x2464ba;
    ((_0x582008["globalAlpha"] = 0x1),
      _0x582008["drawImage"](
        _0x2acc8b,
        _0x4872d4 - _0x1b77f2 / 0x2,
        _0x18e0c2 - _0x4d26a9 / 0x2,
        _0x1b77f2,
        _0x4d26a9,
      ));
    let _0x5b8193 = new Image();
    ((_0x5b8193["crossOrigin"] = "anonymous"),
      (_0x5b8193["src"] = _0x4b2a53["toDataURL"]()),
      (_0x5b8193["onload"] = function () {
        _0x896dc1(_0x5b8193);
      }));
  });
}
function _0x30f1af(_0x427f59, _0x4dd3c3, _0x2595a2) {
  return new Promise(function (_0x47fcef, _0xea14df) {
    var _0x213ed2 = 0x1;
    (_0x427f59["width"] > _0x427f59["height"] &&
      (_0x213ed2 = _0x4dd3c3 / _0x427f59["width"]),
      _0x427f59["width"] < _0x427f59["height"] &&
        (_0x213ed2 = _0x4dd3c3 / _0x427f59["height"]),
      _0x427f59["width"] === _0x427f59["height"] &&
        (_0x213ed2 = _0x4dd3c3 / _0x427f59["height"]));
    var _0x15c148 = _0x427f59["width"] * _0x213ed2,
      _0x400096 = _0x427f59["height"] * _0x213ed2,
      _0x54d148 = document["createElement"]("canvas");
    ((_0x54d148["id"] = "myCanvas"),
      (_0x54d148["width"] = _0x15c148),
      (_0x54d148["height"] = _0x400096),
      (_0x54d148["style"] = "border:2px\x20solid\x20black;"));
    var _0x11debe = _0x54d148["getContext"]("2d");
    ((_0x11debe["fillStyle"] = "white"),
      _0x11debe["fillRect"](0x0, 0x0, _0x54d148["width"], _0x54d148["height"]),
      (_0x11debe["globalAlpha"] = 0x1),
      _0x11debe["drawImage"](_0x427f59, 0x0, 0x0, _0x15c148, _0x400096));
    let _0x482e8e = new Image();
    ((_0x482e8e["crossOrigin"] = "anonymous"),
      (_0x482e8e["src"] = _0x54d148["toDataURL"]()),
      (_0x482e8e["onload"] = function () {
        _0x47fcef(_0x482e8e);
      }));
  });
}
function _0x46c8ca(_0x2ded15) {
  return new Promise(function (_0x34a68d, _0x45cb00) {
    const _0x7b3608 = Math["max"](_0x2ded15["width"], _0x2ded15["height"]),
      _0x27ea16 = document["createElement"]("canvas");
    ((_0x27ea16["width"] = _0x7b3608), (_0x27ea16["height"] = _0x7b3608));
    const _0x27d3c7 = _0x27ea16["getContext"]("2d");
    ((_0x27d3c7["fillStyle"] = "white"),
      _0x27d3c7["fillRect"](0x0, 0x0, _0x27ea16["width"], _0x27ea16["height"]));
    const _0x46cdb0 = (_0x7b3608 - _0x2ded15["width"]) / 0x2,
      _0x541e44 = (_0x7b3608 - _0x2ded15["height"]) / 0x2;
    _0x27d3c7["drawImage"](
      _0x2ded15,
      _0x46cdb0,
      _0x541e44,
      _0x2ded15["width"],
      _0x2ded15["height"],
    );
    const _0x5c0db2 = new Image();
    ((_0x5c0db2["onload"] = function () {
      _0x34a68d(_0x5c0db2);
    }),
      (_0x5c0db2["src"] = _0x27ea16["toDataURL"]()));
  });
}
function _0x2e34ae(_0x734892, _0x4d5291, _0x50388f) {
  return new Promise(function (_0x5a25cc, _0x501391) {
    var _0x372437 = _0x734892["width"],
      _0x5d1dca = _0x734892["height"];
    if (_0x372437 < _0x4d5291 || _0x5d1dca < _0x50388f) {
      var _0x15c605 = document["createElement"]("canvas"),
        _0x49b2e0 = _0x15c605["getContext"]("2d"),
        _0x418836 = Math["max"](_0x4d5291 / _0x372437, _0x50388f / _0x5d1dca);
      ((_0x372437 *= _0x418836),
        (_0x5d1dca *= _0x418836),
        (_0x15c605["width"] = _0x372437),
        (_0x15c605["height"] = _0x5d1dca),
        _0x49b2e0["drawImage"](_0x734892, 0x0, 0x0, _0x372437, _0x5d1dca));
      var _0x5db55f = new Image();
      ((_0x5db55f["src"] = _0x15c605["toDataURL"]()),
        (_0x5db55f["onload"] = function () {
          _0x5a25cc(_0x5db55f);
        }));
    } else _0x5a25cc(_0x734892);
  });
}
function _0x3a6238(_0x400e7e, _0x18f725, _0x2c8861) {
  return new Promise(function (_0x39cc04, _0xe659a6) {
    var _0x2bbea8 = 0x1;
    (_0x400e7e["width"] > _0x400e7e["height"] &&
      (_0x2bbea8 = _0x18f725 / _0x400e7e["width"]),
      _0x400e7e["width"] < _0x400e7e["height"] &&
        (_0x2bbea8 = _0x18f725 / _0x400e7e["height"]),
      _0x400e7e["width"] === _0x400e7e["height"] &&
        (_0x2bbea8 = _0x18f725 / _0x400e7e["height"]));
    var _0x46da08 = _0x400e7e["width"] * _0x2bbea8,
      _0x1bc6d6 = _0x400e7e["height"] * _0x2bbea8,
      _0x2e55d1 = 0x1;
    for (; _0x46da08 > _0x18f725; ) {
      ((_0x46da08 = _0x400e7e["width"] * _0x2e55d1),
        (_0x1bc6d6 = _0x400e7e["height"] * _0x2e55d1),
        (_0x2e55d1 -= 0.01));
    }
    var _0x1f26aa = document["createElement"]("canvas");
    ((_0x1f26aa["id"] = "myCanvas"),
      (_0x1f26aa["width"] = _0x46da08),
      (_0x1f26aa["height"] = _0x1bc6d6),
      (_0x1f26aa["style"] = "border:2px\x20solid\x20black;"));
    var _0x1597d1 = _0x1f26aa["getContext"]("2d");
    ((_0x1597d1["fillStyle"] = "white"),
      _0x1597d1["fillRect"](0x0, 0x0, _0x1f26aa["width"], _0x1f26aa["height"]),
      (_0x1597d1["globalAlpha"] = 0x1),
      _0x1597d1["drawImage"](_0x400e7e, 0x0, 0x0, _0x46da08, _0x1bc6d6));
    let _0x2219a2 = new Image();
    ((_0x2219a2["crossOrigin"] = "anonymous"),
      (_0x2219a2["src"] = _0x1f26aa["toDataURL"]()),
      (_0x2219a2["onload"] = function () {
        _0x39cc04(_0x2219a2);
      }));
  });
}
function _0x5d8657(_0x4bcfbb) {
  return new Promise((_0x41bad9, _0x4c4a20) => {
    var _0x39b4d8 = document["createElement"]("canvas")["getContext"]("2d"),
      _0x3e5af4 = new Image();
    ((_0x3e5af4["onload"] = function () {
      (_0x39b4d8["drawImage"](_0x3e5af4, 0x0, 0x0), _0x41bad9(_0x3e5af4));
    }),
      (_0x3e5af4["src"] = _0x4bcfbb));
  });
}
function _0xe783a9(_0x481bde, _0x5b0c59, _0x2ff015) {
  return new Promise(function (_0x485c74, _0x5245c4) {
    let _0x2e8b6a = document["createElement"]("canvas");
    ((_0x2e8b6a["width"] = _0x481bde["width"] + _0x5b0c59["width"]),
      (_0x2e8b6a["height"] = _0x481bde["height"]));
    let _0x202d50 = _0x2e8b6a["getContext"]("2d");
    ((_0x202d50["fillStyle"] = "white"),
      _0x202d50["fillRect"](0x0, 0x0, _0x2e8b6a["width"], _0x2e8b6a["height"]),
      _0x202d50["drawImage"](_0x481bde, 0x0, 0x0),
      (_0x202d50["globalAlpha"] = _0x2ff015));
    var _0x608e42 = 0.9 * _0x5b0c59["width"],
      _0x5f021d = 0.9 * _0x5b0c59["height"];
    _0x202d50["drawImage"](
      _0x5b0c59,
      _0x2e8b6a["width"] - _0x608e42,
      0x0,
      _0x608e42,
      _0x5f021d,
    );
    var _0x5a820b = new Image();
    ((_0x5a820b["onload"] = function () {
      _0x485c74(_0x5a820b);
    }),
      (_0x5a820b["src"] = _0x2e8b6a["toDataURL"]()));
  });
}
function _0x4f86c3(_0x5ddcb6, _0xe7f087) {
  return new Promise(function (_0x240ff3, _0x27d560) {
    var _0x381fa1 = document["createElement"]("canvas"),
      _0x4053f7 = _0x381fa1["getContext"]("2d");
    ((_0x4053f7["fillStyle"] = "white"),
      _0x4053f7["fillRect"](0x0, 0x0, _0x381fa1["width"], _0x381fa1["height"]));
    var _0x3cab26 = (_0xe7f087 * Math["PI"]) / 0xb4,
      _0x18d474 = Math["cos"](_0x3cab26),
      _0x244a5c = Math["sin"](_0x3cab26);
    (_0x244a5c < 0x0 && (_0x244a5c = -_0x244a5c),
      _0x18d474 < 0x0 && (_0x18d474 = -_0x18d474),
      (_0x381fa1["width"] =
        _0x5ddcb6["height"] * _0x244a5c + _0x5ddcb6["width"] * _0x18d474),
      (_0x381fa1["height"] =
        _0x5ddcb6["height"] * _0x18d474 + _0x5ddcb6["width"] * _0x244a5c));
    var _0x15f6ee = _0x5ddcb6["width"],
      _0x3f7de8 = _0x5ddcb6["height"],
      _0x535ee5 = _0x381fa1["width"] / 0x2,
      _0x46c9d6 = _0x381fa1["height"] / 0x2,
      _0x3abd7f = Math["PI"] / 0xb4;
    (_0x4053f7["translate"](_0x535ee5, _0x46c9d6),
      _0x4053f7["rotate"](_0xe7f087 * _0x3abd7f),
      _0x4053f7["drawImage"](
        _0x5ddcb6,
        -_0x15f6ee / 0x2,
        -_0x3f7de8 / 0x2,
        _0x15f6ee,
        _0x3f7de8,
      ));
    var _0x1869ea = new Image();
    ((_0x1869ea["onload"] = function () {
      _0x240ff3(_0x1869ea);
    }),
      (_0x1869ea["src"] = _0x381fa1["toDataURL"]()));
  });
}
function _0x37cbef(_0x1cd51d, _0x43e1f5, _0x5b68fa) {
  return new Promise(function (_0x5d2772, _0x6b1b21) {
    let _0x380607 = document["createElement"]("canvas");
    ((_0x380607["width"] = _0x1cd51d["width"] + _0x43e1f5["width"]),
      (_0x380607["height"] = _0x1cd51d["height"]));
    let _0x42a291 = _0x380607["getContext"]("2d");
    ((_0x42a291["fillStyle"] = "white"),
      _0x42a291["fillRect"](0x0, 0x0, _0x380607["width"], _0x380607["height"]));
    var _0x469dac = _0x43e1f5["width"];
    (_0x43e1f5["height"],
      "left" === _0x5b68fa
        ? _0x42a291["drawImage"](_0x1cd51d, _0x469dac, 0x0)
        : "right" === _0x5b68fa && _0x42a291["drawImage"](_0x1cd51d, 0x0, 0x0));
    var _0x4fef97 = new Image();
    ((_0x4fef97["onload"] = function () {
      _0x5d2772(_0x4fef97);
    }),
      (_0x4fef97["src"] = _0x380607["toDataURL"]()));
  });
}
function _0x5da1c9(_0x44b313, _0x5f2ab7, _0x58a336) {
  return new Promise(function (_0x4f26ad, _0x2be180) {
    let _0x1a2880 = document["createElement"]("canvas");
    ((_0x1a2880["width"] = _0x44b313["width"] + _0x5f2ab7),
      (_0x1a2880["height"] = _0x44b313["height"]));
    let _0x28e86e = _0x1a2880["getContext"]("2d");
    ((_0x28e86e["fillStyle"] = "white"),
      _0x28e86e["fillRect"](0x0, 0x0, _0x1a2880["width"], _0x1a2880["height"]));
    var _0x1f9da5 = _0x5f2ab7;
    "top" === _0x58a336
      ? _0x28e86e["drawImage"](_0x44b313, 0x0, _0x1f9da5)
      : "botttom" === _0x58a336 && _0x28e86e["drawImage"](_0x44b313, 0x0, 0x0);
    var _0x3fa7e8 = new Image();
    ((_0x3fa7e8["onload"] = function () {
      _0x4f26ad(_0x3fa7e8);
    }),
      (_0x3fa7e8["src"] = _0x1a2880["toDataURL"]()));
  });
}
function _0x3b0395(_0x3289df) {
  return new Promise(function (_0x59c346, _0x57c589) {
    let _0x3da537 = document["createElement"]("canvas");
    console["log"]("Making\x20image\x20aspect\x20same");
    if (_0x3289df["width"] > _0x3289df["height"])
      ((_0x3da537["width"] = _0x3289df["width"]),
        (_0x3da537["height"] =
          _0x3289df["height"] + (_0x3289df["width"] - _0x3289df["height"])));
    else
      _0x3289df["width"] < _0x3289df["height"]
        ? ((_0x3da537["height"] = _0x3289df["height"]),
          (_0x3da537["width"] =
            _0x3289df["width"] + (_0x3289df["height"] - _0x3289df["width"])))
        : (console["log"]("Image\x20is\x20already\x20a\x20square"),
          _0x59c346(_0x3289df));
    console["log"]("Done\x20making\x20image\x20aspect\x20same");
    let _0x37c5d1 = _0x3da537["getContext"]("2d");
    ((_0x37c5d1["fillStyle"] = "white"),
      _0x37c5d1["fillRect"](0x0, 0x0, _0x3da537["width"], _0x3da537["height"]),
      _0x37c5d1["drawImage"](
        _0x3289df,
        (_0x3da537["width"] - _0x3289df["width"]) / 0x2,
        (_0x3da537["height"] - _0x3289df["height"]) / 0x2,
      ));
    var _0x456da6 = new Image();
    ((_0x456da6["onload"] = function () {
      _0x59c346(_0x456da6);
    }),
      (_0x456da6["src"] = _0x3da537["toDataURL"]()));
  });
}
function _0x4712d9(_0x5aee86, _0x33ceec, _0x3d9b04) {
  return new Promise(function (_0x48384b, _0x2fc8ff) {
    let _0x31f661 = document["createElement"]("canvas");
    ((_0x31f661["width"] = _0x5aee86["width"]),
      (_0x31f661["height"] = _0x5aee86["height"]));
    let _0xe88ad7 = _0x31f661["getContext"]("2d");
    ((_0xe88ad7["fillStyle"] = "white"),
      _0xe88ad7["fillRect"](0x0, 0x0, _0x31f661["width"], _0x31f661["height"]));
    var _0x5121e5 = _0x33ceec["width"],
      _0x557561 = _0x33ceec["height"];
    (_0xe88ad7["drawImage"](_0x5aee86, 0x0, 0x0),
      (_0xe88ad7["globalAlpha"] = _0x3d9b04));
    var _0x4fea29 = 0x0 + _0x31f661["width"] / 0x32;
    _0xe88ad7["drawImage"](_0x33ceec, _0x4fea29, 0x0, _0x5121e5, _0x557561);
    var _0x26f2d6 = new Image();
    ((_0x26f2d6["onload"] = function () {
      _0x48384b(_0x26f2d6);
    }),
      (_0x26f2d6["src"] = _0x31f661["toDataURL"]()));
  });
}
function _0x18801f(_0x4dbca9, _0x2622ab, _0x49dcc8) {
  return new Promise(async function (_0x3b5f2d, _0x43ea95) {
    let _0x2e3580 = document["createElement"]("canvas");
    ((_0x2e3580["width"] = _0x4dbca9["width"]),
      (_0x2e3580["height"] = _0x4dbca9["height"]));
    let _0xfa3839 = _0x2e3580["getContext"]("2d");
    ((_0xfa3839["fillStyle"] = "white"),
      _0xfa3839["fillRect"](0x0, 0x0, _0x2e3580["width"], _0x2e3580["height"]),
      _0xfa3839["drawImage"](_0x4dbca9, 0x0, 0x0),
      (_0xfa3839["globalAlpha"] = _0x49dcc8),
      _0xfa3839["drawImage"](
        _0x2622ab,
        _0x2e3580["width"] - _0x2622ab["width"],
        0x0,
        _0x2622ab["width"],
        _0x2622ab["height"],
      ));
    var _0xfc5acb = new Image();
    ((_0xfc5acb["onload"] = function () {
      _0x3b5f2d(_0xfc5acb);
    }),
      (_0xfc5acb["src"] = _0x2e3580["toDataURL"]()));
  });
}
function _0xd3a214(_0x7e5e0c, _0x10a6ef, _0x17efec) {
  return new Promise(function (_0x2e9538, _0x2aae15) {
    let _0xf4d8ba = document["createElement"]("canvas");
    ((_0xf4d8ba["width"] = _0x7e5e0c["width"]),
      (_0xf4d8ba["height"] = _0x7e5e0c["height"]));
    let _0x28d3be = _0xf4d8ba["getContext"]("2d");
    ((_0x28d3be["fillStyle"] = "white"),
      _0x28d3be["fillRect"](0x0, 0x0, _0xf4d8ba["width"], _0xf4d8ba["height"]),
      _0x28d3be["drawImage"](_0x7e5e0c, 0x0, 0x0),
      (_0x28d3be["globalAlpha"] = _0x17efec));
    var _0x4c902f = _0x10a6ef["width"],
      _0x54881d = _0x10a6ef["height"];
    _0x28d3be["drawImage"](
      _0x10a6ef,
      _0xf4d8ba["width"] - _0x4c902f,
      0x0,
      _0x4c902f,
      _0x54881d,
    );
    var _0x129bbe = new Image();
    ((_0x129bbe["onload"] = function () {
      _0x2e9538(_0x129bbe);
    }),
      (_0x129bbe["src"] = _0xf4d8ba["toDataURL"]()));
  });
}
function _0x437223(
  _0x5f4f5d,
  _0x20f6f6,
  _0x48d5ff,
  _0x37409b,
  _0x4ac62f,
  _0x576b5e,
) {
  (_0x5f4f5d["beginPath"](),
    _0x5f4f5d["moveTo"](_0x20f6f6 + _0x576b5e, _0x48d5ff),
    _0x5f4f5d["lineTo"](_0x20f6f6 + _0x37409b - _0x576b5e, _0x48d5ff),
    _0x5f4f5d["quadraticCurveTo"](
      _0x20f6f6 + _0x37409b,
      _0x48d5ff,
      _0x20f6f6 + _0x37409b,
      _0x48d5ff + _0x576b5e,
    ),
    _0x5f4f5d["lineTo"](
      _0x20f6f6 + _0x37409b,
      _0x48d5ff + _0x4ac62f - _0x576b5e,
    ),
    _0x5f4f5d["quadraticCurveTo"](
      _0x20f6f6 + _0x37409b,
      _0x48d5ff + _0x4ac62f,
      _0x20f6f6 + _0x37409b - _0x576b5e,
      _0x48d5ff + _0x4ac62f,
    ),
    _0x5f4f5d["lineTo"](_0x20f6f6 + _0x576b5e, _0x48d5ff + _0x4ac62f),
    _0x5f4f5d["quadraticCurveTo"](
      _0x20f6f6,
      _0x48d5ff + _0x4ac62f,
      _0x20f6f6,
      _0x48d5ff + _0x4ac62f - _0x576b5e,
    ),
    _0x5f4f5d["lineTo"](_0x20f6f6, _0x48d5ff + _0x576b5e),
    _0x5f4f5d["quadraticCurveTo"](
      _0x20f6f6,
      _0x48d5ff,
      _0x20f6f6 + _0x576b5e,
      _0x48d5ff,
    ),
    _0x5f4f5d["closePath"]());
}
function _0x3e35c0(_0x4d57e5, _0x316731, _0x4bbbb6, _0x1a3db9) {
  return new Promise(function (_0x53f2ab, _0x33f503) {
    let _0x5b0f0b = document["createElement"]("canvas");
    ((_0x5b0f0b["width"] = _0x4d57e5["width"]),
      (_0x5b0f0b["height"] = _0x4d57e5["height"]));
    let _0x459e85 = _0x5b0f0b["getContext"]("2d");
    ((_0x459e85["fillStyle"] = "white"),
      _0x459e85["fillRect"](0x0, 0x0, _0x5b0f0b["width"], _0x5b0f0b["height"]),
      _0x459e85["drawImage"](_0x4d57e5, 0x0, 0x0),
      (_0x459e85["globalAlpha"] = _0x4bbbb6));
    var _0x40d4b =
        _0x5b0f0b["width"] - _0x316731["width"] - _0x5b0f0b["width"] / 0x32,
      _0x99101f =
        _0x5b0f0b["height"] -
        _0x316731["height"] -
        _0x5b0f0b["height"] / _0x1a3db9;
    (_0x437223(
      _0x459e85,
      _0x40d4b,
      _0x99101f,
      _0x316731["width"],
      _0x316731["height"],
      0xa,
    ),
      _0x459e85["clip"](),
      _0x459e85["drawImage"](_0x316731, _0x40d4b, _0x99101f));
    var _0x58ccd5 = new Image();
    ((_0x58ccd5["onload"] = function () {
      _0x53f2ab(_0x58ccd5);
    }),
      (_0x58ccd5["src"] = _0x5b0f0b["toDataURL"]()));
  });
}
function _0x45f103(_0x23351e, _0xebdd9f, _0x120e6b, _0x51ed81) {
  return new Promise(function (_0x18dd1a, _0x6acf34) {
    let _0x4d2f17 = document["createElement"]("canvas");
    ((_0x4d2f17["width"] = _0x23351e["width"]),
      (_0x4d2f17["height"] = _0x23351e["height"]));
    let _0x4423b9 = _0x4d2f17["getContext"]("2d");
    ((_0x4423b9["fillStyle"] = "white"),
      _0x4423b9["fillRect"](0x0, 0x0, _0x4d2f17["width"], _0x4d2f17["height"]),
      _0x4423b9["drawImage"](_0x23351e, 0x0, 0x0),
      (_0x4423b9["globalAlpha"] = _0x120e6b));
    var _0x1cbbf9 = 0x0 + _0x4d2f17["width"] / 0x32,
      _0x4822bb =
        _0x4d2f17["height"] -
        _0xebdd9f["height"] -
        _0x4d2f17["height"] / _0x51ed81;
    _0x4423b9["drawImage"](_0xebdd9f, _0x1cbbf9, _0x4822bb);
    var _0x2b6f44 = new Image();
    ((_0x2b6f44["onload"] = function () {
      _0x18dd1a(_0x2b6f44);
    }),
      (_0x2b6f44["src"] = _0x4d2f17["toDataURL"]()));
  });
}
function _0xf0b222(_0x3af6bb, _0x58ce9f, _0x3ab5e5) {
  return new Promise(function (_0x33aed4, _0x143ab1) {
    let _0xc506cf = document["createElement"]("canvas");
    ((_0xc506cf["width"] = _0x3af6bb["width"]),
      (_0xc506cf["height"] = _0x3af6bb["height"]));
    let _0x101fe8 = _0xc506cf["getContext"]("2d");
    ((_0x101fe8["fillStyle"] = "white"),
      _0x101fe8["fillRect"](0x0, 0x0, _0xc506cf["width"], _0xc506cf["height"]),
      _0x101fe8["drawImage"](_0x3af6bb, 0x0, 0x0),
      _0x101fe8["drawImage"](
        _0x58ce9f,
        _0x3ab5e5,
        _0xc506cf["height"] - _0x58ce9f["height"],
      ));
    var _0x130764 = new Image();
    ((_0x130764["onload"] = function () {
      _0x33aed4(_0x130764);
    }),
      (_0x130764["src"] = _0xc506cf["toDataURL"]()));
  });
}
function _0x2df14b(_0x4d62f8, _0x2abba0) {
  return new Promise(function (_0x31c7a3, _0xc3a07c) {
    let _0x2441a5 = document["createElement"]("canvas");
    ((_0x2441a5["width"] = _0x4d62f8["width"]),
      (_0x2441a5["height"] = _0x4d62f8["height"]));
    let _0x3542c1 = _0x2441a5["getContext"]("2d");
    ((_0x3542c1["fillStyle"] = "white"),
      _0x3542c1["fillRect"](0x0, 0x0, _0x2441a5["width"], _0x2441a5["height"]),
      (_0x3542c1["globalAlpha"] = _0x2abba0),
      _0x3542c1["drawImage"](_0x4d62f8, 0x0, 0x0));
    var _0x27ceea = new Image();
    ((_0x27ceea["onload"] = function () {
      _0x31c7a3(_0x27ceea);
    }),
      (_0x27ceea["src"] = _0x2441a5["toDataURL"]()));
  });
}
function _0x1473f6(_0x3cee47, _0x3b3378) {
  return new Promise(function (_0x33f038, _0x2607cf) {
    let _0x57a7b5 = document["createElement"]("canvas");
    ((_0x57a7b5["width"] = _0x3cee47["width"] + imgWatermark["width"]),
      (_0x57a7b5["height"] = _0x3cee47["height"]));
    let _0x2e0197 = _0x57a7b5["getContext"]("2d");
    ((_0x2e0197["fillStyle"] = "white"),
      _0x2e0197["fillRect"](0x0, 0x0, _0x57a7b5["width"], _0x57a7b5["height"]),
      (_0x2e0197["globalAlpha"] = _0x3b3378),
      _0x2e0197["drawImage"](_0x3cee47, 0x0, 0x0));
    var _0xfa476f = 0.9 * imgWatermark["width"],
      _0x32c4b9 = 0.9 * imgWatermark["height"];
    _0x2e0197["drawImage"](
      imgWatermark,
      _0x57a7b5["width"] - _0xfa476f,
      0x0,
      _0xfa476f,
      _0x32c4b9,
    );
    var _0x5058b9 = new Image();
    ((_0x5058b9["onload"] = function () {
      _0x33f038(_0x5058b9);
    }),
      (_0x5058b9["src"] = _0x57a7b5["toDataURL"]()));
  });
}
function _0x317f39(_0x472e17) {
  return new Promise((_0x126545, _0x208cdb) => {
    var _0x106f97 = document["createElement"]("canvas"),
      _0x28922f = _0x106f97["getContext"]("2d");
    ((_0x106f97["width"] = _0x472e17["width"]),
      (_0x106f97["height"] = _0x472e17["height"]));
    var _0x43524c = new Image();
    ((_0x43524c["onload"] = function () {
      (_0x28922f["drawImage"](_0x472e17, 0x0, 0x0), _0x126545(_0x106f97));
    }),
      (_0x43524c["src"] = _0x472e17["src"]));
  });
}
function _0x3fd33b(_0x4d17c5) {
  return new Promise((_0x3a4c0f, _0x9c70eb) => {
    var _0x566e07 = new Image();
    ((_0x566e07["onload"] = function () {
      _0x3a4c0f(_0x566e07);
    }),
      (_0x566e07["src"] = _0x4d17c5["toDataURL"]()));
  });
}
function _0x504d23(_0xdc1b7f) {
  return new Promise((_0x397f61, _0x5399fd) => {
    var _0x2ebb7f = new Image(),
      _0x179372 = document["createElement"]("canvas"),
      _0x4b7710 = _0x179372["getContext"]("2d"),
      _0x4e0623 = {};
    ((_0x2ebb7f["onload"] = function () {
      ((_0x179372["width"] = _0x2ebb7f["width"]),
        (_0x179372["height"] = _0x2ebb7f["height"]),
        _0x4b7710["drawImage"](
          _0x2ebb7f,
          0x0,
          0x0,
          _0x2ebb7f["width"],
          _0x2ebb7f["height"],
        ),
        (_0x4e0623 = _0x4b7710["getImageData"](
          0x0,
          0x0,
          _0x2ebb7f["width"],
          _0x2ebb7f["height"],
        )["data"]));
      var _0x4f2ad4 = _0xc83cd2(!0x0, _0x2ebb7f, _0x4e0623),
        _0x327e23 = _0xc83cd2(!0x1, _0x2ebb7f, _0x4e0623),
        _0xd7b972 = _0x1e80ee(!0x0, _0x2ebb7f, _0x4e0623),
        _0x1a141f = _0x1e80ee(!0x1, _0x2ebb7f, _0x4e0623) - _0xd7b972,
        _0xd1575c = _0x327e23 - _0x4f2ad4;
      ((_0x179372["width"] = _0x1a141f),
        (_0x179372["height"] = _0xd1575c),
        _0x4b7710["drawImage"](
          _0x2ebb7f,
          _0xd7b972,
          _0x4f2ad4,
          _0x1a141f,
          _0xd1575c,
          0x0,
          0x0,
          _0x1a141f,
          _0xd1575c,
        ));
      let _0x5c03d0 = new Image();
      ((_0x5c03d0["crossOrigin"] = "anonymous"),
        (_0x5c03d0["onload"] = function () {
          _0x397f61(_0x5c03d0);
        }),
        (_0x5c03d0["src"] = _0x179372["toDataURL"]()));
    }),
      (_0x2ebb7f["src"] = _0xdc1b7f["src"]));
  });
}
function _0x1e80ee(_0x5dccc4, _0x239bac, _0x5015d9) {
  var _0x58fc1 = _0x5dccc4 ? 0x1 : -0x1;
  for (
    var _0x38d8c6 = _0x5dccc4 ? 0x0 : _0x239bac["width"] - 0x1;
    _0x5dccc4 ? _0x38d8c6 < _0x239bac["width"] : _0x38d8c6 > -0x1;
    _0x38d8c6 += _0x58fc1
  )
    for (var _0x54dced = 0x0; _0x54dced < _0x239bac["height"]; _0x54dced++)
      if (!_0x47bc56(_0x513b21(_0x38d8c6, _0x54dced, _0x5015d9, _0x239bac)))
        return _0x38d8c6;
  return null;
}
function _0xc83cd2(_0x29c38e, _0x1faf48, _0x1865b8) {
  var _0x3cf2a6 = _0x29c38e ? 0x1 : -0x1;
  for (
    var _0x4cd2bd = _0x29c38e ? 0x0 : _0x1faf48["height"] - 0x1;
    _0x29c38e ? _0x4cd2bd < _0x1faf48["height"] : _0x4cd2bd > -0x1;
    _0x4cd2bd += _0x3cf2a6
  )
    for (var _0x3d13c0 = 0x0; _0x3d13c0 < _0x1faf48["width"]; _0x3d13c0++)
      if (!_0x47bc56(_0x513b21(_0x3d13c0, _0x4cd2bd, _0x1865b8, _0x1faf48)))
        return _0x4cd2bd;
  return null;
}
function _0x47bc56(_0x28a520) {
  return (
    0xff == _0x28a520["red"] &&
    0xff == _0x28a520["green"] &&
    0xff == _0x28a520["blue"]
  );
}
function _0x513b21(_0x3e1e8d, _0x1f1953, _0x139054, _0xf0db9a) {
  return {
    red: _0x139054[0x4 * (_0xf0db9a["width"] * _0x1f1953 + _0x3e1e8d)],
    green: _0x139054[0x4 * (_0xf0db9a["width"] * _0x1f1953 + _0x3e1e8d) + 0x1],
    blue: _0x139054[0x4 * (_0xf0db9a["width"] * _0x1f1953 + _0x3e1e8d) + 0x2],
  };
}
function _0x146919(_0x3d6a44) {
  return new Promise((_0x5d86ee, _0x3bd938) => {
    var _0x3a823d = document["createElement"]("canvas"),
      _0x245cf5 = _0x3a823d["getContext"]("2d");
    ((_0x3a823d["width"] = _0x3d6a44["width"]),
      (_0x3a823d["height"] = _0x3d6a44["height"]),
      _0x245cf5["drawImage"](
        _0x3d6a44,
        0x0,
        0x0,
        _0x3d6a44["width"],
        _0x3d6a44["height"],
      ));
    let _0x417a4d = _0x245cf5["getImageData"](
      0x0,
      0x0,
      _0x3d6a44["width"],
      _0x3d6a44["height"],
    );
    var _0x20a3e8 = _0x417a4d["data"];
    for (let _0x29d19c = 0x0; _0x29d19c < _0x20a3e8["length"]; _0x29d19c += 0x4)
      [
        _0x20a3e8[_0x29d19c],
        _0x20a3e8[_0x29d19c + 0x1],
        _0x20a3e8[_0x29d19c + 0x2],
      ]["every"]((_0x2c3f6b) => _0x2c3f6b < 0x100 && _0x2c3f6b > 0xf5) &&
        (_0x20a3e8[_0x29d19c + 0x3] = 0x0);
    _0x245cf5["putImageData"](_0x417a4d, 0x0, 0x0);
    var _0x5661ed = new Image();
    ((_0x5661ed["onload"] = function () {
      _0x5d86ee(_0x5661ed);
    }),
      (_0x5661ed["src"] = _0x3a823d["toDataURL"]()));
  });
}
async function _0x262057(
  _0x5a8171,
  _0x4cc857 = "/Image_Badges/Best_Seller.png",
) {
  var _0x1aaff3 = chrome["runtime"]["getURL"](_0x4cc857),
    _0x32c744 = await _0x5e1fad(_0x1aaff3),
    _0x45bd68 = document["createElement"]("canvas"),
    _0x29c356 = _0x45bd68["getContext"]("2d");
  ((_0x45bd68["width"] = _0x5a8171["width"]),
    (_0x45bd68["height"] = _0x5a8171["height"] + _0x32c744["height"]),
    (_0x29c356["fillStyle"] = "white"),
    _0x29c356["fillRect"](0x0, 0x0, _0x45bd68["width"], _0x45bd68["height"]),
    _0x29c356["drawImage"](_0x5a8171, 0x0, _0x32c744["height"]),
    _0x29c356["drawImage"](
      _0x32c744,
      0x0,
      0x0,
      _0x32c744["width"],
      _0x32c744["height"],
    ));
  var _0x858cc7 = new Image();
  return ((_0x858cc7["src"] = _0x45bd68["toDataURL"]()), _0x858cc7);
}
async function _0x5432b0(
  _0xaa27b5,
  _0x1601f7 = "/Image_Badges/Limited-Time-Deal-Badge.jpg",
) {
  var _0xb60b51 = chrome["runtime"]["getURL"](_0x1601f7),
    _0x3c6876 = await _0x5e1fad(_0xb60b51),
    _0x1286e7 = document["createElement"]("canvas"),
    _0x4cb67d = _0x1286e7["getContext"]("2d");
  ((_0x1286e7["width"] = _0xaa27b5["width"]),
    (_0x1286e7["height"] = _0xaa27b5["height"]),
    (_0x4cb67d["fillStyle"] = "white"),
    _0x4cb67d["fillRect"](0x0, 0x0, _0x1286e7["width"], _0x1286e7["height"]),
    _0x4cb67d["drawImage"](_0xaa27b5, 0x0, 0x0));
  var _0x2bbf23 = _0xaa27b5["width"] / 2.5,
    _0x1daf9f = _0x3c6876["height"] * (_0x2bbf23 / _0x3c6876["width"]);
  _0x4cb67d["drawImage"](
    _0x3c6876,
    _0xaa27b5["width"] - _0x2bbf23,
    _0xaa27b5["height"] - _0x1daf9f,
    _0x2bbf23,
    _0x1daf9f,
  );
  var _0xb82ead = new Image();
  return ((_0xb82ead["src"] = _0x1286e7["toDataURL"]()), _0xb82ead);
}
async function _0x548248(
  _0x21e3ec,
  _0x302406,
  _0x4694e4,
  _0x2e2ef6,
  _0x56b4e1,
  _0x3a1fd4,
  _0x54a8c2,
  _0x27df1a,
  _0x211b88,
  _0x580700,
  _0x3cca88 = !0x1,
) {
  (console["log"]("Creating\x20multi\x20image\x20V2"),
    console["log"]("imageSource", _0x21e3ec));
  var _0xf68e7e = await _0x5e1fad(_0x21e3ec);
  ((_0xf68e7e = await _0x30f1af(_0xf68e7e, _0x54a8c2, _0x27df1a)),
    (_0xf68e7e = await _0x504d23(_0xf68e7e)));
  var _0x33bd12 = await _0x5e1fad(_0x302406),
    _0x5c4fe8 = await _0x5e1fad(_0x2e2ef6),
    _0x2cc72f = await _0x5e1fad(_0x56b4e1);
  ((_0x33bd12 = await _0x30f1af(_0x33bd12, 0.45 * _0x54a8c2, 0.45 * _0x27df1a)),
    (_0x5c4fe8 = await _0x30f1af(
      _0x5c4fe8,
      0.45 * _0x54a8c2,
      0.45 * _0x27df1a,
    )),
    (_0x2cc72f = await _0x30f1af(
      _0x2cc72f,
      0.45 * _0x54a8c2,
      0.45 * _0x27df1a,
    )));
  var _0x134fe9 = Math["max"](
    _0x33bd12["width"],
    _0x5c4fe8["width"],
    _0x2cc72f["width"],
  );
  ((_0xf68e7e = await _0x2b85f4(_0xf68e7e, _0x134fe9, "right")),
    (_0xf68e7e = await _0x3b0395(_0xf68e7e)),
    (_0x33bd12 = await _0x30f1af(_0x33bd12, 0.4 * _0x54a8c2, 0.4 * _0x27df1a)),
    (_0x5c4fe8 = await _0x30f1af(_0x5c4fe8, 0.4 * _0x54a8c2, 0.4 * _0x27df1a)),
    (_0x2cc72f = await _0x30f1af(_0x2cc72f, 0.4 * _0x54a8c2, 0.4 * _0x27df1a)));
  var _0x298fbf = 0x0;
  ((_0xf68e7e = await _0x40f114(_0xf68e7e, _0x33bd12, _0x298fbf)),
    (_0x298fbf += _0x33bd12["height"] + _0xf68e7e["height"] / 0x19),
    (_0xf68e7e = await _0x40f114(_0xf68e7e, _0x5c4fe8, _0x298fbf)),
    (_0x298fbf += _0x5c4fe8["height"] + _0xf68e7e["height"] / 0x19),
    (_0xf68e7e = await _0x40f114(_0xf68e7e, _0x2cc72f, _0x298fbf)));
  var _0x21111d = await _0x5e1fad(_0x4694e4);
  _0x21111d = await _0x30f1af(
    _0x21111d,
    0.2 * _0xf68e7e["height"],
    0.2 * _0xf68e7e["width"],
  );
  var _0xe621f5 = _0xf68e7e["height"],
    _0x450d01 = chrome["runtime"]["getURL"]("/Image_Badges/Best_Seller.png"),
    _0x38b9c5 = await _0x5e1fad(_0x450d01),
    _0x576238 = _0xf68e7e["height"] / 0x5,
    _0x4986ac = _0x38b9c5["width"] * (_0x576238 / _0x38b9c5["height"]);
  _0x38b9c5 = await _0x30f1af(_0x38b9c5, _0x4986ac, _0x576238);
  if (_0x3cca88) {
    _0xf68e7e = await _0x262057(_0xf68e7e);
    var _0x5acbf5 =
      (_0xf68e7e = await _0x5432b0(_0xf68e7e))["height"] - _0xe621f5;
    ((_0x21111d = await _0x30f1af(
      _0x21111d,
      _0x5acbf5,
      0.2 * _0xf68e7e["width"],
    )),
      (_0xf68e7e = await _0x53b478(_0xf68e7e, _0x21111d, 0.7)));
  }
  return await _0x2e34ae(_0xf68e7e, 0x1f4, 0x1f4);
}
function _0x5c62d0(_0x455555, _0x195c33, _0x4a204c, _0x5abdd7 = 0x1) {
  return new Promise(function (_0x38fe99, _0x74dc1b) {
    let _0xefd9a9 = document["createElement"]("canvas");
    ((_0xefd9a9["width"] = _0x455555["width"]),
      (_0xefd9a9["height"] = _0x455555["height"]));
    let _0x2c8481 = _0xefd9a9["getContext"]("2d");
    ((_0x2c8481["fillStyle"] = "white"),
      _0x2c8481["fillRect"](0x0, 0x0, _0xefd9a9["width"], _0xefd9a9["height"]),
      _0x2c8481["drawImage"](_0x455555, 0x0, 0x0));
    var _0x20ee50 = _0x4a204c;
    (_0x437223(
      _0x2c8481,
      0x0,
      _0x20ee50,
      _0x195c33["width"],
      _0x195c33["height"],
      0xa,
    ),
      (_0x2c8481["globalAlpha"] = _0x5abdd7),
      _0x2c8481["drawImage"](_0x195c33, 0x0, _0x20ee50));
    let _0xc0e2c2 = new Image();
    ((_0xc0e2c2["src"] = _0xefd9a9["toDataURL"]()), _0x38fe99(_0xc0e2c2));
  });
}
function _0x40f114(_0xf7eee5, _0x104489, _0x1e7a9a) {
  return new Promise(function (_0x50715d, _0x248f0b) {
    let _0x35f586 = document["createElement"]("canvas");
    ((_0x35f586["width"] = _0xf7eee5["width"]),
      (_0x35f586["height"] = _0xf7eee5["height"]));
    let _0x2e0ab6 = _0x35f586["getContext"]("2d");
    ((_0x2e0ab6["fillStyle"] = "white"),
      _0x2e0ab6["fillRect"](0x0, 0x0, _0x35f586["width"], _0x35f586["height"]),
      _0x2e0ab6["drawImage"](_0xf7eee5, 0x0, 0x0),
      (_0x2e0ab6["globalAlpha"] = 0.9));
    var _0x2b685c =
        _0x35f586["width"] - _0x104489["width"] - _0x35f586["width"] / 0x32,
      _0x5ed706 = _0x1e7a9a;
    (_0x437223(
      _0x2e0ab6,
      _0x2b685c,
      _0x5ed706,
      _0x104489["width"],
      _0x104489["height"],
      0xa,
    ),
      _0x2e0ab6["clip"](),
      _0x2e0ab6["drawImage"](_0x104489, _0x2b685c, _0x5ed706));
    var _0x34b457 = new Image();
    ((_0x34b457["onload"] = function () {
      _0x50715d(_0x34b457);
    }),
      (_0x34b457["src"] = _0x35f586["toDataURL"]()));
  });
}
function _0x2b85f4(_0x3f7846, _0xf3d5f, _0x135a8d) {
  return new Promise(function (_0x94668, _0x94b897) {
    let _0x472d6c = document["createElement"]("canvas");
    ((_0x472d6c["width"] = _0x3f7846["width"] + _0xf3d5f),
      (_0x472d6c["height"] = _0x3f7846["height"]));
    let _0x3e0220 = _0x472d6c["getContext"]("2d");
    ((_0x3e0220["fillStyle"] = "white"),
      _0x3e0220["fillRect"](0x0, 0x0, _0x472d6c["width"], _0x472d6c["height"]));
    var _0x4fb2e0 = _0xf3d5f;
    "left" === _0x135a8d
      ? _0x3e0220["drawImage"](_0x3f7846, _0x4fb2e0, 0x0)
      : "right" === _0x135a8d && _0x3e0220["drawImage"](_0x3f7846, 0x0, 0x0);
    var _0x3ed4c8 = new Image();
    ((_0x3ed4c8["onload"] = function () {
      _0x94668(_0x3ed4c8);
    }),
      (_0x3ed4c8["src"] = _0x472d6c["toDataURL"]()));
  });
}
function _0x1b1e90(_0x449213, _0x8ad0df, _0x547389) {
  return new Promise(function (_0x16a12f, _0x2776da) {
    let _0x29ddca = document["createElement"]("canvas");
    ((_0x29ddca["width"] = _0x449213["width"]),
      (_0x29ddca["height"] = _0x449213["height"] + _0x8ad0df));
    let _0x554fcd = _0x29ddca["getContext"]("2d");
    ((_0x554fcd["fillStyle"] = "white"),
      _0x554fcd["fillRect"](0x0, 0x0, _0x29ddca["width"], _0x29ddca["height"]));
    var _0x16dca3 = _0x8ad0df;
    "top" === _0x547389
      ? _0x554fcd["drawImage"](_0x449213, 0x0, _0x16dca3)
      : "bottom" === _0x547389 && _0x554fcd["drawImage"](_0x449213, 0x0, 0x0);
    var _0x1d1db6 = new Image();
    ((_0x1d1db6["onload"] = function () {
      _0x16a12f(_0x1d1db6);
    }),
      (_0x1d1db6["src"] = _0x29ddca["toDataURL"]()));
  });
}
function _0x53b478(_0x3e9bd9, _0x19a7f1, _0x5bf6da) {
  return new Promise(async function (_0x2c33f5, _0x5f15d6) {
    let _0x3e5d20 = document["createElement"]("canvas");
    ((_0x3e5d20["width"] = _0x3e9bd9["width"]),
      (_0x3e5d20["height"] = _0x3e9bd9["height"]));
    let _0x4e28d2 = _0x3e5d20["getContext"]("2d");
    ((_0x4e28d2["fillStyle"] = "white"),
      _0x4e28d2["fillRect"](0x0, 0x0, _0x3e5d20["width"], _0x3e5d20["height"]),
      _0x4e28d2["drawImage"](_0x3e9bd9, 0x0, 0x0),
      (_0x4e28d2["globalAlpha"] = _0x5bf6da),
      _0x4e28d2["drawImage"](
        _0x19a7f1,
        _0x3e5d20["width"] - _0x19a7f1["width"],
        0x0,
        _0x19a7f1["width"],
        _0x19a7f1["height"],
      ));
    var _0x2210c6 = new Image();
    ((_0x2210c6["onload"] = function () {
      _0x2c33f5(_0x2210c6);
    }),
      (_0x2210c6["src"] = _0x3e5d20["toDataURL"]()));
  });
}
function _0x2b9e0f(_0x3e72c0) {
  return new Promise(function (_0x5b6aa7, _0x274c63) {
    let _0x279989 = document["createElement"]("canvas");
    (_0x3e72c0["width"], _0x3e72c0["height"]);
    if (_0x3e72c0["width"] > _0x3e72c0["height"])
      ((_0x279989["width"] = _0x3e72c0["width"]),
        (_0x279989["height"] =
          _0x3e72c0["height"] + (_0x3e72c0["width"] - _0x3e72c0["height"])));
    else {
      if (!(_0x3e72c0["width"] < _0x3e72c0["height"])) return _0x3e72c0;
      ((_0x279989["height"] = _0x3e72c0["height"]),
        (_0x279989["width"] =
          _0x3e72c0["width"] + (_0x3e72c0["height"] - _0x3e72c0["width"])));
    }
    let _0x24b35b = _0x279989["getContext"]("2d");
    ((_0x24b35b["fillStyle"] = "white"),
      _0x24b35b["fillRect"](0x0, 0x0, _0x279989["width"], _0x279989["height"]),
      _0x24b35b["drawImage"](
        _0x3e72c0,
        _0x279989["width"] - _0x3e72c0["width"],
        _0x279989["height"] - _0x3e72c0["height"],
      ));
    var _0x2aed1 = new Image();
    ((_0x2aed1["onload"] = function () {
      _0x5b6aa7(_0x2aed1);
    }),
      (_0x2aed1["src"] = _0x279989["toDataURL"]()));
  });
}
async function _0xbba02e(_0x7e4972, _0x4b9f90) {
  var _0x3020ef = await _0x5e1fad(_0x7e4972);
  _0x3020ef = await _0x30f1af(_0x3020ef, 0x5dc, 0x5dc);
  var _0x491331 = [];
  for (var _0xd54a2c = 0x0; _0xd54a2c < _0x4b9f90["length"]; _0xd54a2c++) {
    var _0x48a012 = await _0x5e1fad(_0x4b9f90[_0xd54a2c]);
    ((_0x48a012 = await _0x30f1af(
      _0x48a012,
      _0x3020ef["width"] / _0x4b9f90["length"],
      _0x3020ef["height"] / _0x4b9f90["length"],
    )),
      _0x491331["push"](_0x48a012));
  }
  var _0x29c4c5 = _0x491331[0x0];
  for (_0xd54a2c = 0x0; _0xd54a2c < _0x491331["length"]; _0xd54a2c++)
    _0x491331[_0xd54a2c]["width"] > _0x29c4c5["width"] &&
      (_0x29c4c5 = _0x491331[_0xd54a2c]);
  _0x3020ef = await _0x1b1e90(_0x3020ef, _0x29c4c5["height"], "bottom");
  for (_0xd54a2c = 0x0; _0xd54a2c < _0x491331["length"]; _0xd54a2c++)
    _0x3020ef = await _0xf0b222(
      _0x3020ef,
      _0x491331[_0xd54a2c],
      _0xd54a2c * (_0x3020ef["width"] / _0x491331["length"]),
    );
  return _0x3020ef;
}
async function _0x4c38c7(_0x223d99, _0x5d4ccf, _0x2fe297) {
  ((_0x223d99 = await _0x30f1af(_0x223d99, 0x5dc, 0x5dc)),
    (_0x223d99 = await _0x504d23(_0x223d99)));
  var _0x385057 = await _0x5e1fad(_0x2fe297);
  ((_0x385057 = await _0x504d23(_0x385057)),
    (_0x385057 = await _0x30f1af(_0x385057, 0x2a3, 0x2a3)));
  var _0x3ee315 = await _0x5e1fad(_0x5d4ccf);
  return (
    (_0x3ee315 = await _0x30f1af(_0x3ee315, 0x2a3, 0x2a3)),
    (_0x223d99 = await _0x37cbef(_0x223d99, _0x3ee315, "right")),
    (_0x3ee315 = await _0x30f1af(_0x3ee315, 0x258, 0x258)),
    (_0x223d99 = await _0x3e35c0(_0x223d99, _0x3ee315, 0x1, 0xc)),
    (_0x385057 = await _0x3a6238(
      _0x385057,
      0.65 * _0x3ee315["width"],
      0.65 * _0x3ee315["height"],
    )),
    (_0x385057 = await _0x146919(_0x385057)),
    (_0x223d99 = await _0x18801f(_0x223d99, _0x385057, 0.7)),
    (_0x223d99 = await _0x3b0395(_0x223d99)),
    await _0x2e34ae(_0x223d99, 0x1f4, 0x1f4)
  );
}
function _0x301a3c(_0x5c0cf1, _0x33ccc9) {
  return new Promise((_0x30d3e6, _0x1d3e37) => {
    const _0x4851b5 = _0x5c0cf1,
      _0x2aa9ab = document["createElement"]("canvas");
    ((_0x2aa9ab["width"] = _0x4851b5["width"]),
      (_0x2aa9ab["height"] = _0x4851b5["height"]));
    const _0x519c1e = _0x2aa9ab["getContext"]("2d");
    (_0x519c1e["clearRect"](0x0, 0x0, _0x2aa9ab["width"], _0x2aa9ab["height"]),
      _0x519c1e["save"](),
      _0x519c1e["beginPath"](),
      _0x519c1e["moveTo"](_0x33ccc9, 0x0),
      _0x519c1e["lineTo"](_0x2aa9ab["width"] - _0x33ccc9, 0x0),
      _0x519c1e["quadraticCurveTo"](
        _0x2aa9ab["width"],
        0x0,
        _0x2aa9ab["width"],
        _0x33ccc9,
      ),
      _0x519c1e["lineTo"](_0x2aa9ab["width"], _0x2aa9ab["height"] - _0x33ccc9),
      _0x519c1e["quadraticCurveTo"](
        _0x2aa9ab["width"],
        _0x2aa9ab["height"],
        _0x2aa9ab["width"] - _0x33ccc9,
        _0x2aa9ab["height"],
      ),
      _0x519c1e["lineTo"](_0x33ccc9, _0x2aa9ab["height"]),
      _0x519c1e["quadraticCurveTo"](
        0x0,
        _0x2aa9ab["height"],
        0x0,
        _0x2aa9ab["height"] - _0x33ccc9,
      ),
      _0x519c1e["lineTo"](0x0, _0x33ccc9),
      _0x519c1e["quadraticCurveTo"](0x0, 0x0, _0x33ccc9, 0x0),
      _0x519c1e["clip"](),
      _0x519c1e["drawImage"](
        _0x4851b5,
        0x0,
        0x0,
        _0x2aa9ab["width"],
        _0x2aa9ab["height"],
      ),
      _0x519c1e["restore"]());
    const _0x214872 = new Image();
    ((_0x214872["onload"] = () => {
      _0x30d3e6(_0x214872);
    }),
      (_0x214872["src"] = _0x2aa9ab["toDataURL"]()));
  });
}
async function _0x53e3b5(_0x122b91, _0xc234be) {
  var _0x3b9213 = document["createElement"]("canvas");
  ((_0x3b9213["width"] = 0x1f4), (_0x3b9213["height"] = 0x1f4));
  var _0x523bd9 = _0x3b9213["getContext"]("2d");
  ((_0x523bd9["fillStyle"] = "#E53238"),
    _0x523bd9["fillRect"](0x0, 0x0, _0x3b9213["width"], 0x14),
    (_0x523bd9["fillStyle"] = "#0074E8"),
    _0x523bd9["fillRect"](
      _0x3b9213["width"] - 0x14,
      0x0,
      0x14,
      _0x3b9213["height"],
    ),
    (_0x523bd9["fillStyle"] = "#F5AF02"),
    _0x523bd9["fillRect"](
      0x0,
      _0x3b9213["height"] - 0x14,
      _0x3b9213["width"],
      0x14,
    ),
    (_0x523bd9["fillStyle"] = "#86B817"),
    _0x523bd9["fillRect"](0x0, 0x0, 0x14, _0x3b9213["height"]));
  var innerWidth = _0x3b9213["width"] - 0x28,
    innerHeight = _0x3b9213["height"] - 0x28;
  ((_0x523bd9["fillStyle"] = "#ffffff"),
    _0x523bd9["fillRect"](0x14, 0x14, innerWidth, innerHeight));
  var _0x10deee = "Informationen\x20zur\x20Produktsicherheit";
  ((_0x523bd9["font"] = "bold\x2024px\x20Arial"),
    (_0x523bd9["fillStyle"] = "#000"));
  var _0x1e6b6 =
    0x14 + (innerWidth - _0x523bd9["measureText"](_0x10deee)["width"]) / 0x2;
  (_0x523bd9["fillText"](_0x10deee, _0x1e6b6, 0x28),
    (_0x523bd9["strokeStyle"] = "#cccccc"),
    (_0x523bd9["lineWidth"] = 0x1),
    _0x523bd9["beginPath"](),
    _0x523bd9["moveTo"](0x1e, 0x4b),
    _0x523bd9["lineTo"](0x14 + innerWidth - 0xa, 0x4b),
    _0x523bd9["stroke"]());
  var _0x19a7ca = 0x14 + innerHeight - 0xa;
  function _0x224e0d(
    _0x59258c,
    _0x31c307,
    _0x1b896b,
    _0x20b17b,
    _0x540714,
    _0x564b60,
    _0x1f4591,
  ) {
    ((_0x59258c["fillStyle"] = "#000"),
      (_0x59258c["font"] = "bold\x2016px\x20Arial"),
      (_0x59258c["textBaseline"] = "top"),
      _0x59258c["fillText"](_0x540714, _0x31c307 + 0x8, _0x1b896b),
      (_0x1b896b += 0x14),
      (_0x59258c["font"] = "14px\x20Arial"));
    var _0x42d63f = (function (_0xbef347, _0x243a79, _0x4dd51a) {
      var _0x4e7260 = _0x243a79["split"]("\x0a"),
        _0x1e1ff7 = [];
      for (var _0x365a08 = 0x0; _0x365a08 < _0x4e7260["length"]; _0x365a08++) {
        var _0x10d4e0 = _0x4e7260[_0x365a08]["split"]("\x20"),
          _0x57e360 = "";
        for (
          var _0x32d1e0 = 0x0;
          _0x32d1e0 < _0x10d4e0["length"];
          _0x32d1e0++
        ) {
          var _0x139326 = _0x57e360 + _0x10d4e0[_0x32d1e0] + "\x20";
          if (
            _0xbef347["measureText"](_0x139326)["width"] > _0x4dd51a &&
            _0x32d1e0 > 0x0
          )
            (_0x1e1ff7["push"](_0x57e360["trim"]()),
              (_0x57e360 = _0x10d4e0[_0x32d1e0] + "\x20"));
          else _0x57e360 = _0x139326;
        }
        _0x1e1ff7["push"](_0x57e360["trim"]());
      }
      return _0x1e1ff7;
    })(_0x59258c, _0x564b60, _0x20b17b - 0x10);
    for (
      var _0x4399a7 = 0x0;
      _0x4399a7 < _0x42d63f["length"] && !(_0x1b896b + 0x10 > _0x1f4591);
      _0x4399a7++
    ) {
      (_0x59258c["fillText"](_0x42d63f[_0x4399a7], _0x31c307 + 0x8, _0x1b896b),
        (_0x1b896b += 0x10));
    }
    return _0x1b896b;
  }
  var _0x558633 = _0x224e0d(
    _0x523bd9,
    0x14,
    0x55,
    innerWidth,
    "Hersteller:",
    _0x122b91,
    0x55 + (0x14 + innerHeight - 0x55 - 0xa) / 0x2,
  );
  return (
    _0x224e0d(
      _0x523bd9,
      0x14,
      (_0x558633 += 0xa),
      innerWidth,
      "EU\x20Verantwortliche\u00a0Person:",
      _0xc234be,
      _0x19a7ca,
    ),
    (_0x523bd9["strokeStyle"] = "#eeeeee"),
    (_0x523bd9["lineWidth"] = 0x2),
    _0x523bd9["strokeRect"](0x14, 0x14, innerWidth, innerHeight),
    new Promise(function (_0x4bdafb) {
      var _0x47944c = new Image();
      ((_0x47944c["src"] = _0x3b9213["toDataURL"]("image/png")),
        (_0x47944c["onload"] = function () {
          _0x4bdafb(_0x47944c);
        }));
    })
  );
}
function _0x1a2f03() {
  return new Promise((_0x142e3d) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x142e3d();
      });
    });
  });
}
function _0x20a235() {
  return new Promise((_0x576e08) => {
    requestIdleCallback(() => {
      _0x576e08();
    });
  });
}
function _0x37a54a(_0x1a58c9 = 0x3e8) {
  return new Promise((_0x54aa95, _0x1a3b5e) => {
    let _0x389059,
      _0x17fb23 = Date["now"](),
      _0x23c0c9 = !0x1;
    function _0x35dbd3() {
      if (Date["now"]() - _0x17fb23 > _0x1a58c9)
        (_0x23c0c9 && _0x389059["disconnect"](), _0x54aa95());
      else setTimeout(_0x35dbd3, _0x1a58c9);
    }
    const _0x3ce657 = () => {
        _0x17fb23 = Date["now"]();
      },
      _0x47dd66 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x389059 = new MutationObserver(_0x3ce657)),
        _0x389059["observe"](document["body"], _0x47dd66),
        (_0x23c0c9 = !0x0),
        setTimeout(_0x35dbd3, _0x1a58c9));
    else
      window["onload"] = () => {
        ((_0x389059 = new MutationObserver(_0x3ce657)),
          _0x389059["observe"](document["body"], _0x47dd66),
          (_0x23c0c9 = !0x0),
          setTimeout(_0x35dbd3, _0x1a58c9));
      };
  });
}
async function _0x494bf1() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x37a54a(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
console["log"]("pre_list_display.js\x20loaded");
function _0x270c99(_0x18d1e6) {
  var _0x2c92a2 = document["createElement"]("h2");
  return (
    (_0x2c92a2["id"] = "title_ecom_sniper"),
    (_0x2c92a2["textContent"] = _0x18d1e6),
    _0x2c92a2
  );
}
function _0x3150f1(_0x71a3d3) {
  var _0x120474 = document["createElement"]("div");
  _0x120474["id"] = "listTitleContainer";
  var _0x4e60ed = document["createElement"]("textarea");
  ((_0x4e60ed["id"] = "listTitle"),
    (_0x4e60ed["rows"] = "1"),
    (_0x4e60ed["cols"] = "50"),
    (_0x4e60ed["placeholder"] = "Input\x20new\x20title\x20here..."),
    (_0x4e60ed["textContent"] = _0x71a3d3));
  var _0x206beb = document["createElement"]("div");
  return (
    (_0x206beb["id"] = "charCount"),
    (_0x206beb["textContent"] =
      "Characters:\x20" + _0x4e60ed["value"]["length"] + "/80"),
    _0x4e60ed["addEventListener"]("input", function () {
      _0x206beb["textContent"] =
        "Characters:\x20" + _0x4e60ed["value"]["length"] + "/80";
    }),
    _0x120474["appendChild"](_0x4e60ed),
    _0x120474["appendChild"](_0x206beb),
    _0x120474
  );
}
function _0x1836a4(_0x40e0a5) {
  var _0x31dfd1 = document["createElement"]("div");
  _0x31dfd1["id"] = "listDescriptionContainer";
  var _0x2b2f4a = document["createElement"]("h2");
  ((_0x2b2f4a["textContent"] = "Scraped\x20Description"),
    _0x31dfd1["appendChild"](_0x2b2f4a));
  var _0x52ad2d = document["createElement"]("p");
  return (
    (_0x52ad2d["id"] = "listDescription"),
    (_0x52ad2d["contentEditable"] = "true"),
    (_0x52ad2d["innerHTML"] = _0x40e0a5),
    _0x31dfd1["appendChild"](_0x52ad2d),
    _0x31dfd1
  );
}
function _0x279d57(_0x241963) {
  var _0x28e745 = document["createDocumentFragment"]();
  for (var _0x10e75a = 0x0; _0x10e75a < _0x241963["length"]; _0x10e75a++) {
    var _0x2061d0 = document["createElement"]("div");
    _0x2061d0["classList"]["add"]("imageContainer");
    var _0xe2f061 = document["createElement"]("img");
    ((_0xe2f061["src"] = _0x241963[_0x10e75a]),
      (_0xe2f061["width"] = "100"),
      (_0xe2f061["height"] = "100"));
    var _0x54dbad = document["createElement"]("span");
    ((_0x54dbad["textContent"] = "x"),
      _0x54dbad["classList"]["add"]("deleteButton"),
      _0x54dbad["addEventListener"]("click", function (_0x9e2c6e) {
        (_0x9e2c6e["stopPropagation"](), this["parentNode"]["remove"]());
      }),
      _0xe2f061["addEventListener"]("click", function () {
        var _0x195bab = document["querySelectorAll"](".highlight");
        for (var _0x5d66bd = 0x0; _0x5d66bd < _0x195bab["length"]; _0x5d66bd++)
          _0x195bab[_0x5d66bd]["classList"]["remove"]("highlight");
        this["classList"]["add"]("highlight");
      }),
      _0xe2f061["addEventListener"]("dblclick", _0x5a6832),
      _0x2061d0["appendChild"](_0xe2f061),
      _0x2061d0["appendChild"](_0x54dbad),
      _0x28e745["appendChild"](_0x2061d0));
  }
  return _0x28e745;
}
async function _0x1ada9d(_0xaa0779, _0x3a7a07) {
  console["log"]("mainImage:\x20" + _0xaa0779);
  var _0x25b604 = await _0xbba02e(_0xaa0779, _0x3a7a07),
    _0x51a8a0 = document["createElement"]("div");
  _0x51a8a0["classList"]["add"]("imageContainer");
  var _0x3681f9 = document["createElement"]("img");
  ((_0x3681f9["src"] = _0x25b604["src"]),
    (_0x3681f9["width"] = "100"),
    (_0x3681f9["height"] = "100"));
  var _0x5791e4 = document["createElement"]("span");
  return (
    (_0x5791e4["textContent"] = "x"),
    _0x5791e4["classList"]["add"]("deleteButton"),
    _0x5791e4["addEventListener"]("click", function (_0x34e7c7) {
      (_0x34e7c7["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x3681f9["addEventListener"]("click", function () {
      var _0x43e3fd = document["querySelectorAll"](".highlight");
      for (var _0x10bd0d = 0x0; _0x10bd0d < _0x43e3fd["length"]; _0x10bd0d++)
        _0x43e3fd[_0x10bd0d]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x3681f9["addEventListener"]("dblclick", _0x5a6832),
    _0x51a8a0["appendChild"](_0x3681f9),
    _0x51a8a0["appendChild"](_0x5791e4),
    _0x51a8a0
  );
}
async function _0x3335b0(_0x10e858, _0x115f2a, _0x44837d) {
  console["log"]("mainImage:\x20" + _0x10e858);
  var _0x321b11 = await _0xbba02e(_0x10e858, _0x44837d),
    _0x34de70 = await _0x4c38c7(
      _0x321b11,
      _0x115f2a,
      "https://i.imgur.com/DMwAoOA.png",
    ),
    _0x5bc996 = document["createElement"]("div");
  _0x5bc996["classList"]["add"]("imageContainer");
  var _0x17c5c0 = document["createElement"]("img");
  ((_0x17c5c0["src"] = _0x34de70["src"]),
    (_0x17c5c0["width"] = "100"),
    (_0x17c5c0["height"] = "100"));
  var _0x8f37aa = document["createElement"]("span");
  return (
    (_0x8f37aa["textContent"] = "x"),
    _0x8f37aa["classList"]["add"]("deleteButton"),
    _0x8f37aa["addEventListener"]("click", function (_0x42ec85) {
      (_0x42ec85["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x17c5c0["addEventListener"]("click", function () {
      var _0x55d9ad = document["querySelectorAll"](".highlight");
      for (var _0x346716 = 0x0; _0x346716 < _0x55d9ad["length"]; _0x346716++)
        _0x55d9ad[_0x346716]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x17c5c0["addEventListener"]("dblclick", _0x5a6832),
    _0x17c5c0["classList"]["add"]("highlight"),
    _0x5bc996["appendChild"](_0x17c5c0),
    _0x5bc996["appendChild"](_0x8f37aa),
    _0x5bc996
  );
}
async function _0x3aed0c(_0x42dd3a, _0x939ef, _0xf2eecd, _0x507862) {
  var { watermark_url: _0x1fdcc5 } =
      await chrome["storage"]["local"]["get"]("watermark_url"),
    _0x44b2a4 = await _0x548248(
      _0x42dd3a,
      _0x939ef,
      _0x1fdcc5,
      _0xf2eecd,
      _0x507862,
      "imageTitle",
      0x5dc,
      0x5dc,
      "black",
      "arial",
      !0x0,
    ),
    _0x38ca98 = document["createElement"]("div");
  _0x38ca98["classList"]["add"]("imageContainer");
  var _0x592d6b = document["createElement"]("img");
  _0x592d6b["src"] = _0x44b2a4["src"];
  var _0x14270e = document["createElement"]("span");
  return (
    (_0x14270e["textContent"] = "x"),
    _0x14270e["classList"]["add"]("deleteButton"),
    _0x14270e["addEventListener"]("click", function (_0x8199cb) {
      (_0x8199cb["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x592d6b["addEventListener"]("click", function () {
      var _0x3a035c = document["querySelectorAll"](".highlight");
      for (var _0x4f74ab = 0x0; _0x4f74ab < _0x3a035c["length"]; _0x4f74ab++)
        _0x3a035c[_0x4f74ab]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x592d6b["addEventListener"]("dblclick", _0x5a6832),
    _0x592d6b["classList"]["add"]("highlight"),
    _0x38ca98["appendChild"](_0x592d6b),
    _0x38ca98["appendChild"](_0x14270e),
    _0x38ca98
  );
}
function _0x5a6832(_0x13fb7c) {
  var _0x2eb81b = document["getElementById"]("myModal"),
    _0x5981de = document["getElementById"]("img01");
  ((_0x2eb81b["style"]["display"] = "block"), (_0x5981de["src"] = this["src"]));
}
function _0x4fc45f() {
  document["getElementById"]("myModal")["style"]["display"] = "none";
}
function _0x52aa25(_0x3b0f7c) {
  var _0x48e71a = document["getElementById"]("myModal");
  _0x3b0f7c["target"] == _0x48e71a && _0x4fc45f();
}
function _0x29d0f8(_0x3db10d) {
  var _0x3398bc = document["createElement"]("h3");
  return (
    (_0x3398bc["textContent"] = "Scraped\x20Price:\x20$" + _0x3db10d),
    _0x3398bc
  );
}
function _0x3ba7b2(_0x5c30a9) {
  var _0x5332f6 = document["createElement"]("h3");
  return (
    (_0x5332f6["id"] = "listSku"),
    (_0x5332f6["textContent"] = _0x5c30a9),
    _0x5332f6
  );
}
function _0x5254e8(_0x4b514e) {
  var _0x149557 = document["createElement"]("div");
  _0x149557["id"] = "listPriceContainer";
  var _0x44ca78 = document["createElement"]("label");
  ((_0x44ca78["htmlFor"] = "newPrice"),
    (_0x44ca78["textContent"] = "Price\x20to\x20be\x20listed\x20on\x20eBay:"));
  var _0x43af9d = document["createElement"]("input");
  return (
    (_0x43af9d["id"] = "listPrice"),
    (_0x43af9d["type"] = "number"),
    (_0x43af9d["placeholder"] = "Input\x20new\x20price\x20here..."),
    (_0x43af9d["value"] = _0x4b514e),
    _0x149557["appendChild"](_0x44ca78),
    _0x149557["appendChild"](_0x43af9d),
    _0x149557
  );
}
function _0x838147() {
  var _0x3e0754 = document["createElement"]("button");
  return (
    (_0x3e0754["id"] = "listOnEbayButton"),
    (_0x3e0754["textContent"] = "List\x20on\x20eBay"),
    _0x3e0754["addEventListener"]("click", function () {
      _0x87d21b();
    }),
    _0x3e0754
  );
}
function _0x30473f() {
  const _0x1b9f08 = document["createElement"]("button");
  return (
    (_0x1b9f08["innerHTML"] = "<b>Snipe\x20Title</b>"),
    (_0x1b9f08["id"] = "create-title-v4"),
    _0x1b9f08["classList"]["add"]("create-title-v4"),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x7f39fd) {
        console["log"]("createSnipeTitleButton\x20response:\x20", _0x7f39fd);
        if (_0x7f39fd["creditsAvailable"])
          _0x1b9f08["onclick"] = function () {
            (console["log"]("clicked\x20button"),
              chrome["runtime"]["sendMessage"](
                { type: "checkCredits" },
                async function (_0x4c2f44) {
                  console["log"]("response:\x20", _0x4c2f44);
                  if (_0x4c2f44["creditsAvailable"]) {
                    chrome["runtime"]["sendMessage"]({
                      type: "deductCredits",
                      amount: 0,
                    });
                    var _0x32f5cd =
                        document["querySelector"]("#listTitle")["textContent"],
                      _0x374d09 = document["querySelector"](
                        "#listDescriptionContainer\x20p",
                      )["innerText"];
                    await _0x561702(_0x32f5cd, _0x374d09);
                  } else
                    alert(
                      "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits.",
                    );
                },
              ));
          };
        else
          ((_0x1b9f08["disabled"] = !0x0),
            (_0x1b9f08["innerHTML"] =
              "<b>Snipe\x20Title</b>\x20(No\x20Credits)"),
            (_0x1b9f08["style"]["backgroundColor"] = "grey"));
      },
    ),
    _0x1b9f08
  );
}
async function _0x343068() {
  var _0x40fd7f = document["querySelector"]("#create-title-v4");
  ((_0x40fd7f["disabled"] = !0x0),
    (_0x40fd7f["style"]["backgroundColor"] = "grey"),
    (_0x40fd7f["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    _0x3abd25(),
    _0x529f17(),
    (document["title"] = "Creating\x20The\x20Perfect\x20Title\x20-\x20"),
    _0x47eb7a());
  var _0x2236d4 =
      document["querySelector"]("#listTitle")["textContent"] +
      "\x0a" +
      document["querySelector"]("#listDescriptionContainer\x20p")["innerText"],
    _0x7c5fd8 = await _0x34027e(
      "https://ebaysnipertitlebuilder.ngrok.io/api/TitleBuilder/BuildTitle",
      { request_type: "build_title", product_description: _0x2236d4 },
    );
  console["log"]("getAiTitleFromApi\x20data:\x20", _0x7c5fd8);
  var _0xc388c1 = _0x7c5fd8["title"];
  (console["log"](
    "\x20createTitleV4AndAppendToTable\x20ai_title:\x20",
    _0xc388c1,
  ),
    _0x526aa4(chrome["runtime"]["getURL"]("Favicons/Completed/received.png")),
    await new Promise((_0x4d4feb) => setTimeout(_0x4d4feb, 0x3e8)),
    console["log"]("finished\x20waiting\x201\x20second"),
    (document["title"] = "Received\x20Title:\x20\x22" + _0xc388c1 + "\x22"),
    _0x2790a9(_0xc388c1, "Perfect\x20Title"),
    console["log"]("finished\x20createCellWithTitle"));
  var _0x3b53fb = document["getElementById"]("listing-data-table"),
    _0x3544e9 =
      _0x3b53fb["rows"][_0x3b53fb["rows"]["length"] - 0x1]["querySelector"](
        ".title-cell",
      );
  (console["log"]("finished\x20tableRow.querySelector(.title-cell);"),
    _0xc388c1 || (_0xc388c1 = "undefined"),
    _0x37d93c(_0xc388c1, _0x3544e9),
    console["log"]("finished\x20flyInText"));
  var _0x2dd419 = document["querySelector"]("#listTitle");
  return (
    (_0x2dd419["value"] = _0xc388c1),
    _0x2dd419["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    console["log"]("finished\x20textArea.value\x20=\x20ai_title;"),
    _0x4176c2(),
    _0x48c406(),
    await new Promise((_0x2bf093) => setTimeout(_0x2bf093, 0x7d0)),
    _0x1717d6(),
    (_0x40fd7f["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x40fd7f["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x40fd7f["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x40fd7f["disabled"] = !0x1));
    }, 0x7d0),
    _0xc388c1
  );
}
async function _0x561702(_0x305122, _0x1183d8) {
  var _0x575efe = document["querySelector"]("#create-title-v4");
  ((_0x575efe["disabled"] = !0x0),
    (_0x575efe["style"]["backgroundColor"] = "grey"),
    (_0x575efe["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    _0x3abd25(),
    _0x529f17(),
    console["log"]("create10TitlesV3AndAppendToTable"),
    _0x305122 || (_0x305122 = getFilteredTitle()),
    _0x1183d8 || (_0x1183d8 = getProductDescriptionAndFeatures()));
  var _0x3e17ef = await _0x34027e(
    "https://suggest-optimized-titles-2-djybcnnsgq-uc.a.run.app",
    {
      request_type: "generate_10_titles",
      product_description: _0x1183d8,
      product_title: _0x305122,
    },
  );
  console["log"]("create10TitlesV3AndAppendToTable\x20data:\x20", _0x3e17ef);
  var _0x2b567e = _0x3e17ef;
  if (!_0x2b567e)
    return (
      _0x2790a9("Error\x20-\x20Try\x20Again", "Perfect\x20Title"),
      _0x4176c2(),
      _0x48c406(),
      await new Promise((_0x11fe47) => setTimeout(_0x11fe47, 0x7d0)),
      _0x1717d6(),
      (_0x575efe["innerHTML"] = "<b>Sniped\x20Title!</b>"),
      (_0x575efe["style"]["backgroundColor"] = "#3a86ff"),
      setTimeout(function () {
        ((_0x575efe["innerHTML"] = "<b>Snipe\x20Title</b>"),
          (_0x575efe["disabled"] = !0x1));
      }, 0x7d0),
      null
    );
  (Array["isArray"](_0x2b567e) || (_0x2b567e = [_0x2b567e]),
    (_0x2b567e = _0x2b567e["filter"](function (_0x317d70) {
      return _0x317d70["trim"]()["length"] > 0x0;
    })["map"](function (_0x3e7c7f) {
      return _0x3e7c7f["trim"]();
    })));
  var _0x466670 = "";
  for (var _0xd15fc4 = 0x0; _0xd15fc4 < _0x2b567e["length"]; _0xd15fc4++)
    (_0x305122 = _0x2b567e[_0xd15fc4])["length"] > _0x466670["length"] &&
      _0x305122["length"] <= 0x50 &&
      (_0x466670 = _0x305122);
  0x0 == _0x466670["length"] && (_0x466670 = _0x2b567e[0x0]);
  for (_0xd15fc4 = 0x0; _0xd15fc4 < _0x2b567e["length"]; _0xd15fc4++) {
    ((_0x305122 = _0x2b567e[_0xd15fc4]),
      console["log"]("title:\x20", _0x305122));
    if (!(_0x305122["length"] > 0x5a)) {
      _0x2790a9(
        _0x305122,
        _0x466670 == _0x305122 ? "Perfect\x20Title" : "Great\x20Title",
      );
      var _0x4ed5c2 = document["getElementById"]("listing-data-table");
      (_0x37d93c(
        _0x305122,
        _0x4ed5c2["rows"][_0x4ed5c2["rows"]["length"] - 0x1]["querySelector"](
          ".title-cell",
        ),
      ),
        _0x48c406(),
        await new Promise((_0x549b33) => setTimeout(_0x549b33, 0x12c)),
        _0x1717d6());
    }
  }
  var _0x56f3b0 = document["querySelector"]("#the-textarea");
  (_0x56f3b0 || (_0x56f3b0 = document["querySelector"]("#listTitle")),
    (_0x56f3b0["value"] = _0x466670));
  try {
    updateTheCharacterCountOnTextArea();
  } catch (_0x4c4a5a) {}
  return (
    _0x4176c2(),
    _0x48c406(),
    await new Promise((_0x3a8d80) => setTimeout(_0x3a8d80, 0x7d0)),
    _0x1717d6(),
    (_0x575efe["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x575efe["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x575efe["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x575efe["disabled"] = !0x1));
    }, 0x7d0),
    _0x466670
  );
}
async function _0x2790a9(_0x36c0e6, _0x2a323a) {
  var _0x123ad3 = document["getElementById"]("listing-data-table"),
    _0x53a48d = _0x23a1c2(_0x123ad3);
  (_0x3380da(_0x123ad3, {
    rowNumber: _0x53a48d,
    cellValue: _0x53a48d,
    headerName: "Rank",
  }),
    _0x3380da(_0x123ad3, {
      rowNumber: _0x53a48d,
      cellValue: _0x36c0e6,
      headerName: "Title",
    }),
    _0x3380da(_0x123ad3, {
      rowNumber: _0x53a48d,
      cellValue: _0x2a323a,
      headerName: "Type",
    }),
    _0x3380da(_0x123ad3, {
      rowNumber: _0x53a48d,
      cellValue: _0x36c0e6["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x540583 = document["createElement"]("button");
  ((_0x540583["innerHTML"] = "Change"),
    (_0x540583["onclick"] = function () {
      var _0x16bccd = document["querySelector"]("#listTitle");
      ((_0x16bccd["value"] = _0x36c0e6),
        _0x16bccd["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
    }),
    _0x100344(_0x123ad3, {
      button: _0x540583,
      rowNumber: _0x53a48d,
      headerName: "Action",
    }));
}
async function _0x104531() {
  _0x529f17();
  var _0x19d6d6 = document["querySelectorAll"](".imageContainer\x20img"),
    _0x1818d7 = [];
  for (var _0x45e11a = 0x0; _0x45e11a < _0x19d6d6["length"]; _0x45e11a++)
    _0x1818d7["push"](_0x19d6d6[_0x45e11a]["src"]);
  if (_0x1818d7["length"] < 0x4)
    (alert(
      "You\x20need\x204\x20images\x20to\x20generate\x20a\x20quad\x20image",
    ),
      _0x4176c2());
  else {
    var _0x1a20e2 = await _0x3aed0c(
      _0x1818d7[0x0],
      _0x1818d7[0x1],
      _0x1818d7[0x2],
      _0x1818d7[0x3],
    );
    (document["querySelector"]("#imagesContainer")["appendChild"](_0x1a20e2),
      _0x4176c2(),
      _0x48c406(),
      await new Promise((_0x4b032e) => setTimeout(_0x4b032e, 0x7d0)),
      _0x1717d6());
  }
}
async function _0x4e8319() {
  _0x529f17();
  var _0x154e4e = document["querySelectorAll"](".imageContainer\x20img"),
    _0x48c258 = [];
  for (var _0x3a821a = 0x0; _0x3a821a < _0x154e4e["length"]; _0x3a821a++)
    _0x48c258["push"](_0x154e4e[_0x3a821a]["src"]);
  var _0xe19ba0 = await _0x1ada9d(_0x48c258[0x0], _0x48c258);
  (document["querySelector"]("#imagesContainer")["appendChild"](_0xe19ba0),
    _0x4176c2(),
    _0x48c406(),
    await new Promise((_0x268596) => setTimeout(_0x268596, 0x7d0)),
    _0x1717d6());
}
async function _0x3fff72(_0x5bf6fd) {
  var _0x4c159f = _0x5bf6fd["images"],
    _0x45e1be = _0x5bf6fd["title"],
    _0x588784 = _0x5bf6fd["price"],
    _0x487a91 = _0x5bf6fd["description"];
  _0x588784 = _0x5bf6fd["price"];
  var _0x5bba76 = _0x5bf6fd["sku"];
  _0x5bf6fd["attributeImages"];
  var _0x4cee02 = _0x30473f(),
    _0x35514e = _0x374761();
  _0x3c0c6f();
  var _0x5d3de3 = document["createElement"]("div");
  _0x5d3de3["id"] = "data-box";
  var _0x385f28 = document["createElement"]("div");
  _0x385f28["id"] = "imagesContainer";
  var _0x5f31b6 = _0x279d57(_0x4c159f);
  (_0x385f28["appendChild"](_0x5f31b6), _0x5d3de3["appendChild"](_0x385f28));
  var _0xce5edb = document["createElement"]("div");
  _0xce5edb["id"] = "buttonContainer";
  var _0xfc64dd = document["createElement"]("button");
  ((_0xfc64dd["innerHTML"] = "Generate\x20Quad\x20Image"),
    (_0xfc64dd["id"] = "generateQuadImageButton"),
    (_0xfc64dd["onclick"] = async function (_0x484c82) {
      (_0x484c82["preventDefault"](),
        (_0xfc64dd["disabled"] = !0x0),
        (_0xfc64dd["style"]["backgroundColor"] = "grey"),
        await _0x104531(),
        (_0xfc64dd["disabled"] = !0x1),
        (_0xfc64dd["style"]["backgroundColor"] = "#4CAF50"));
    }));
  var _0xa4f62e = document["createElement"]("button");
  ((_0xa4f62e["innerHTML"] = "Create\x20Multi\x20Image"),
    (_0xa4f62e["id"] = "createMultiImageButton"),
    (_0xa4f62e["onclick"] = async function (_0x3dcb60) {
      (_0x3dcb60["preventDefault"](),
        (_0xa4f62e["disabled"] = !0x0),
        (_0xa4f62e["style"]["backgroundColor"] = "grey"),
        await _0x4e8319(),
        (_0xa4f62e["disabled"] = !0x1),
        (_0xa4f62e["style"]["backgroundColor"] = "#4CAF50"));
    }));
  var _0x1074a8 = _0x35514e["cloneNode"](!0x0);
  (_0xce5edb["appendChild"](_0x1074a8),
    _0xce5edb["appendChild"](_0xfc64dd),
    _0xce5edb["appendChild"](_0xa4f62e),
    _0x5d3de3["appendChild"](_0xce5edb),
    _0x5d3de3["appendChild"](_0x270c99(_0x45e1be)),
    _0x5d3de3["appendChild"](_0x3150f1(_0x45e1be)),
    _0x5d3de3["appendChild"](_0x5254e8(_0x588784)),
    _0x5d3de3["appendChild"](_0x35514e),
    _0x5d3de3["appendChild"](_0x4cee02),
    _0x5d3de3["appendChild"](_0x838147()));
  var _0x5a0bb2 = _0x39af0a();
  (_0x5d3de3["appendChild"](_0x5a0bb2),
    _0x1c2793(_0x5a0bb2, { headerName: "Rank" }),
    _0x1c2793(_0x5a0bb2, { headerName: "Type" }),
    _0x1c2793(_0x5a0bb2, { headerName: "Title" }),
    _0x1c2793(_0x5a0bb2, { headerName: "Total\x20Characters" }),
    _0x1c2793(_0x5a0bb2, { headerName: "Action" }));
  var _0x43422c = _0x23a1c2(_0x5a0bb2);
  (_0x3380da(_0x5a0bb2, {
    rowNumber: _0x43422c,
    cellValue: _0x43422c,
    headerName: "Rank",
  }),
    _0x3380da(_0x5a0bb2, {
      rowNumber: _0x43422c,
      cellValue: _0x45e1be,
      headerName: "Title",
    }),
    _0x3380da(_0x5a0bb2, {
      rowNumber: _0x43422c,
      cellValue: "Filtered",
      headerName: "Type",
    }),
    _0x3380da(_0x5a0bb2, {
      rowNumber: _0x43422c,
      cellValue: _0x45e1be["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x5dce65 = document["createElement"]("button");
  ((_0x5dce65["innerHTML"] = "Change"),
    (_0x5dce65["onclick"] = function () {
      var _0x4d0786 = document["querySelector"]("#listTitle");
      ((_0x4d0786["value"] = _0x45e1be),
        _0x4d0786["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
    }),
    _0x100344(_0x5a0bb2, {
      button: _0x5dce65,
      rowNumber: _0x43422c,
      headerName: "Action",
    }),
    _0x5d3de3["appendChild"](_0x1836a4(_0x487a91)),
    _0x5d3de3["appendChild"](_0x29d0f8(_0x588784)),
    _0x5d3de3["appendChild"](_0x3ba7b2(_0x5bba76)));
  var _0x382417 = document["createElement"]("span");
  ((_0x382417["innerHTML"] = "&times;"),
    _0x382417["classList"]["add"]("close-button"),
    (_0x382417["onclick"] = function () {
      _0x5d3de3["remove"]();
    }),
    _0x5d3de3["appendChild"](_0x382417),
    document["body"]["insertBefore"](_0x5d3de3, document["body"]["firstChild"]),
    document["querySelector"](".imageContainer")
      ["querySelector"]("img")
      ["click"](),
    _0x451b99());
}
function _0x451b99() {
  var _0x114782 = document["getElementById"]("imagesContainer");
  new Sortable(_0x114782, {
    animation: 0x96,
    chosenClass: "sortable-chosen",
    dragClass: "sortable-drag",
  });
}
function _0x87d21b() {
  (_0x526aa4(chrome["runtime"]["getURL"]("Favicons/Completed/right_arrow.png")),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      async function (_0x1767d8) {
        console["log"]("response:\x20", _0x1767d8);
        if (_0x1767d8["creditsAvailable"]) {
          chrome["runtime"]["sendMessage"]({
            type: "deductCredits",
            amount: 0,
          });
          var _0x2f2c4f = document["querySelectorAll"](
              ".imageContainer\x20img",
            ),
            _0x3facff = [];
          for (
            var _0x3ec851 = 0x0;
            _0x3ec851 < _0x2f2c4f["length"];
            _0x3ec851++
          )
            _0x3facff["push"](_0x2f2c4f[_0x3ec851]["src"]);
          var _0x4635c2 = document["querySelector"](
              ".imageContainer\x20img.highlight",
            )["src"],
            _0x1759ae = await _0x5e1fad(_0x4635c2),
            _0x1239a7 = {
              title:
                document["querySelector"]("#title_ecom_sniper")["innerText"],
              custom_title: document["querySelector"]("#listTitle")["value"],
              custom_price: document["querySelector"]("#listPrice")["value"],
              descriptionHTML:
                document["querySelector"]("#listDescription")["innerHTML"],
              descriptionText:
                document["querySelector"]("#listDescription")["innerText"],
              main_hd_images: _0x3facff,
              main_sd_images: [],
              selected_image: _0x1759ae["src"],
              listingType: "paid2",
              sku: document["querySelector"]("#listSku")["innerText"],
            };
          chrome["runtime"]["sendMessage"](
            { type: "list_to_ebay", product_data: _0x1239a7 },
            function (_0x4f2255) {
              console["log"](_0x4f2255["farewell"]);
            },
          );
        } else
          alert(
            "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits\x20to\x20continue\x20listing.",
          );
      },
    ));
}
function _0x3c0c6f() {
  const _0x2b0edb = document["createElement"]("div");
  ((_0x2b0edb["id"] = "myModal"), _0x2b0edb["classList"]["add"]("modal"));
  const _0x4f23de = document["createElement"]("span");
  (_0x4f23de["classList"]["add"]("close"),
    (_0x4f23de["innerHTML"] = "&times;"),
    _0x2b0edb["appendChild"](_0x4f23de));
  const _0x3de495 = document["createElement"]("img");
  (_0x3de495["classList"]["add"]("modal-content"),
    (_0x3de495["id"] = "img01"),
    _0x2b0edb["appendChild"](_0x3de495),
    document["body"]["appendChild"](_0x2b0edb),
    document["getElementsByClassName"]("close")[0x0]["addEventListener"](
      "click",
      _0x4fc45f,
    ),
    window["addEventListener"]("click", _0x52aa25));
}
async function _0x683ce1(_0x3320b0) {
  var { markupPrice: _0x4cbb51 } =
    await chrome["storage"]["local"]["get"]("markupPrice");
  let _0x20c70e = _0x3320b0 * (0x1 + _0x4cbb51 / 0x64);
  _0x20c70e = Math["ceil"](_0x20c70e);
  var { end_price: _0x2101e1 } =
      await chrome["storage"]["local"]["get"]("end_price"),
    _0x1172e5 = 0x1 - (_0x2101e1 = parseFloat(_0x2101e1));
  return (
    0x1 == _0x1172e5 && (_0x1172e5 = 0x0),
    (_0x20c70e -= _0x1172e5),
    _0x20c70e
  );
}
console["log"]("functions.js\x20loaded");
function _0x190693() {
  return document["querySelector"]("#main-title")["innerText"];
}
function _0x2d5036() {
  var _0x2a482d = document["querySelector"]("span[itemprop=\x27price\x27]")[
    "innerText"
  ];
  return (
    (_0x2a482d = _0x2a482d["match"](/\d+\.\d+/)[0x0]),
    parseFloat(_0x2a482d)
  );
}
function _0x387b5f() {
  return document["querySelector"](
    "div[data-testid=\x27product-description-content\x27]",
  )["textContent"];
}
function _0x1de7a3() {
  var _0x223489 = document["querySelectorAll"](
      "div[data-testid=\x27vertical-carousel-container\x27]\x20img",
    ),
    _0x1aee90 = [];
  for (var _0x3002df = 0x0; _0x3002df < _0x223489["length"]; _0x3002df++) {
    var _0x48fd52 = _0x223489[_0x3002df]["src"];
    (_0x48fd52["includes"]("http://") || _0x48fd52["includes"]("https://")) &&
      ((_0x48fd52 = _0x48fd52["match"](
        /(https?:\/\/.*\.(?:png|jpg|jpeg|webp|gif|bmp))/,
      )[0x0]),
      _0x1aee90["push"](_0x48fd52));
  }
  return _0x1aee90;
}
function _0x3b3548(_0x5e0ae5) {
  return _0x5e0ae5["usItemId"];
}
function _0x46e160() {
  var _0x216715 = document["querySelector"]("script#__NEXT_DATA__");
  if (_0x216715)
    return JSON["parse"](_0x216715["textContent"])["props"]["pageProps"][
      "initialData"
    ]["data"]["product"];
}
function _0x1f5228(_0x53fc99) {
  return _0x53fc99["brand"];
}
console["log"]("content.js\x20loaded");
async function _0x406d3f() {
  await _0x37a54a();
  var _0x5c7337 = _0x46e160(),
    _0x5a8a69 = _0x190693();
  console["log"]("title", _0x5a8a69);
  var _0x5a7c11 = _0x2d5036();
  console["log"]("price", _0x5a7c11);
  var _0xa698cd = _0x387b5f();
  (console["log"]("description", _0xa698cd),
    (_0xa698cd = filterTitle(_0xa698cd, _0x5c7337["brand"])),
    (_0xa698cd = filterTitle(_0xa698cd, _0x5c7337["sellerDisplayName"])),
    (_0xa698cd = filterTitle(_0xa698cd, _0x5c7337["sellerName"])));
  var _0x5e2bfa = _0x1de7a3();
  console["log"]("images", _0x5e2bfa);
  var _0x26810b = _0x3b3548(_0x5c7337);
  console["log"]("sku", _0x26810b);
  var filteredTitle = filterTitle(_0x5a8a69, _0x5c7337["brand"]);
  ((filteredTitle = filterTitle(filteredTitle, _0x5c7337["model"])),
    (filteredTitle = filterTitle(
      filteredTitle,
      _0x5c7337["sellerDisplayName"],
    )),
    (filteredTitle = filterTitle(filteredTitle, _0x5c7337["sellerName"])));
  var _0x1e16d8 = {
    title: (filteredTitle = filterTitle(
      filteredTitle,
      _0x5c7337["manufacturerProductId"],
    )),
    description: _0xa698cd,
    images: _0x5e2bfa,
    price: await _0x683ce1(_0x5a7c11),
    sku: _0x26810b,
  };
  (console["log"]("options", _0x1e16d8), _0x3fff72(_0x1e16d8));
}
function filterTitle(_0x1f604b, _0x158e3c) {
  if (!_0x158e3c || "string" != typeof _0x158e3c) return _0x1f604b;
  var _0x1b0c15 = new RegExp(_0x158e3c, "gi");
  return _0x1f604b["replace"](_0x1b0c15, "");
}
document["addEventListener"]("DOMContentLoaded", async function () {
  _0x406d3f();
});
