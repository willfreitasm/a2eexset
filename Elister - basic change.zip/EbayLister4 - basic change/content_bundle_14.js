class _0x3472e1 {
  constructor({
    target: target = null,
    menuItems: menuItems = [],
    mode: mode = "dark",
  }) {
    ((this["target"] = target),
      (this["menuItems"] = menuItems),
      (this["mode"] = mode),
      (this["targetNode"] = this["getTargetNode"]()),
      (this["menuItemsNode"] = this["getMenuItemsNode"]()),
      (this["isOpened"] = !0x1),
      (this["menuContainer"] = null));
  }
  ["getTargetNode"]() {
    const _0x169f21 = document["querySelectorAll"](this["target"]);
    if (_0x169f21 && 0x0 !== _0x169f21["length"]) return _0x169f21;
    return (
      console["error"](
        "getTargetNode\x20::\x20\x22" +
          this["target"] +
          "\x22\x20target\x20not\x20found",
      ),
      []
    );
  }
  ["getMenuItemsNode"]() {
    const _0x456343 = [];
    if (!this["menuItems"])
      return (
        console["error"](
          "getMenuItemsNode\x20::\x20Please\x20enter\x20menu\x20items",
        ),
        []
      );
    return (
      console["log"]("this.menuItems", this["menuItems"]),
      this["menuItems"]["forEach"]((_0xb7252f, _0x3b5332) => {
        const _0x5a0f7d = this["createItemMarkup"](_0xb7252f);
        (_0x5a0f7d["firstChild"]["setAttribute"](
          "style",
          "animation-delay:\x20" + 0.08 * _0x3b5332 + "s",
        ),
          _0x456343["push"](_0x5a0f7d));
      }),
      _0x456343
    );
  }
  ["createItemMarkup"](_0x228e49) {
    const _0x18fb2f = document["createElement"]("BUTTON"),
      _0x3b1aea = document["createElement"]("LI");
    return (
      (_0x18fb2f["innerHTML"] = _0x228e49["content"]),
      _0x18fb2f["classList"]["add"]("contextMenu-button"),
      _0x228e49["selected"] && _0x18fb2f["classList"]["add"]("selected"),
      _0x3b1aea["classList"]["add"]("contextMenu-item"),
      _0x228e49["divider"] &&
        _0x3b1aea["setAttribute"]("data-divider", _0x228e49["divider"]),
      _0x3b1aea["appendChild"](_0x18fb2f),
      _0x228e49["events"] &&
        0x0 !== _0x228e49["events"]["length"] &&
        Object["entries"](_0x228e49["events"])["forEach"]((_0xdd7fd1) => {
          const [_0x3f08ac, _0x3c16dc] = _0xdd7fd1;
          _0x18fb2f["addEventListener"](_0x3f08ac, _0x3c16dc);
        }),
      _0x3b1aea
    );
  }
  ["renderMenu"]() {
    (console["log"]("rendering\x20menu", this["menuItemsNode"]),
      (this["menuItemsNode"] = this["getMenuItemsNode"]()));
    const _0xcde304 = document["createElement"]("UL");
    return (
      _0xcde304["classList"]["add"]("contextMenu"),
      _0xcde304["setAttribute"]("data-theme", this["mode"]),
      this["menuItemsNode"]["forEach"]((_0x40d2d3) =>
        _0xcde304["appendChild"](_0x40d2d3),
      ),
      _0xcde304
    );
  }
  ["closeMenu"](_0x38bf2a) {
    this["isOpened"] && ((this["isOpened"] = !0x1), _0x38bf2a["remove"]());
  }
  ["init"]() {
    (document["addEventListener"]("click", () =>
      this["closeMenu"](this["menuContainer"]),
    ),
      window["addEventListener"]("blur", () =>
        this["closeMenu"](this["menuContainer"]),
      ),
      this["targetNode"]["forEach"]((_0xdf399b) => {
        _0xdf399b["addEventListener"]("contextmenu", (_0x4ecde5) => {
          (console["log"]("this.menuContainer", this["menuContainer"]),
            (this["menuContainer"] = this["renderMenu"]()),
            _0x4ecde5["preventDefault"](),
            console["log"]("this.menuContainer", this["menuContainer"]),
            (this["isOpened"] = !0x0));
          const { clientX: _0x3e3d50, clientY: _0x2d643a } = _0x4ecde5;
          document["body"]["appendChild"](this["menuContainer"]);
          const _0x376f7e =
              _0x2d643a + this["menuContainer"]["scrollHeight"] >=
              window["innerHeight"]
                ? window["innerHeight"] -
                  this["menuContainer"]["scrollHeight"] -
                  0x14
                : _0x2d643a,
            _0x3f99ee =
              _0x3e3d50 + this["menuContainer"]["scrollWidth"] >=
              window["innerWidth"]
                ? window["innerWidth"] -
                  this["menuContainer"]["scrollWidth"] -
                  0x14
                : _0x3e3d50;
          this["menuContainer"]["setAttribute"](
            "style",
            "--width:\x20" +
              this["menuContainer"]["scrollWidth"] +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--height:\x20" +
              this["menuContainer"]["scrollHeight"] +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--top:\x20" +
              _0x376f7e +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--left:\x20" +
              _0x3f99ee +
              "px;",
          );
        });
      }));
  }
}
function _0x390d28(_0x240918, _0x5603f9, _0x42e5f5) {
  (_0x240918["forEach"]((_0x589957) => {
    _0x589957["id"] === _0x5603f9 && (_0x589957["selected"] = !0x1);
  }),
    _0x240918["forEach"]((_0x2d5be1) => {
      _0x2d5be1["id"] === _0x5603f9 &&
        _0x2d5be1["value"] === _0x42e5f5 &&
        (_0x2d5be1["selected"] = !0x0);
    }),
    console["log"]("updateContextMenu", _0x240918));
}
function _0x2b0dbc(_0x36db41) {
  var _0x8535a5 = document["createElement"]("div");
  ((_0x8535a5["id"] = _0x36db41),
    (_0x8535a5["className"] = "custom-context-menu"));
  var _0x22e187 = [];
  function _0x56eaa4() {
    (_0x8535a5 &&
      ((_0x8535a5["style"]["display"] = "none"), _0x8535a5["remove"]()),
      document["removeEventListener"]("click", _0x56eaa4));
  }
  return {
    addMenuItem: function (_0x1fd19a, _0x49c90d) {
      var _0x5eb9ab = document["createElement"]("div");
      ((_0x5eb9ab["className"] = "context-menu-item"),
        (_0x5eb9ab["textContent"] = _0x1fd19a),
        _0x5eb9ab["addEventListener"]("click", function (_0xacab7f) {
          (_0x49c90d(_0xacab7f), _0x56eaa4());
        }),
        _0x8535a5["appendChild"](_0x5eb9ab),
        _0x22e187["push"](_0x5eb9ab));
    },
    showMenu: function (_0x518710) {
      _0x518710["preventDefault"]();
      var _0x255bb7 = document["getElementById"](_0x36db41);
      (_0x255bb7 && _0x255bb7["remove"](),
        document["body"]["appendChild"](_0x8535a5),
        (_0x8535a5["style"]["left"] = _0x518710["pageX"] + "px"),
        (_0x8535a5["style"]["top"] = _0x518710["pageY"] + "px"),
        (_0x8535a5["style"]["display"] = "block"),
        _0x8535a5["addEventListener"]("click", function (_0x39107e) {
          _0x39107e["stopPropagation"]();
        }),
        document["addEventListener"]("click", _0x56eaa4));
    },
    hideMenu: _0x56eaa4,
    id: _0x36db41,
    element: _0x8535a5,
  };
}
function _0x32b65a() {
  return new Promise((_0x5550db) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x5550db();
      });
    });
  });
}
function _0x737ffd() {
  return new Promise((_0x2ec177) => {
    requestIdleCallback(() => {
      _0x2ec177();
    });
  });
}
function _0x9eafd3(_0x1d904a = 0x3e8) {
  return new Promise((_0x3132b1, _0x5e63b8) => {
    let _0x5e6574,
      _0x5bfb4a = Date["now"](),
      _0x572c9e = !0x1;
    function _0x4bcd18() {
      if (Date["now"]() - _0x5bfb4a > _0x1d904a)
        (_0x572c9e && _0x5e6574["disconnect"](), _0x3132b1());
      else setTimeout(_0x4bcd18, _0x1d904a);
    }
    const _0x16b7c5 = () => {
        _0x5bfb4a = Date["now"]();
      },
      _0x3ae33c = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x5e6574 = new MutationObserver(_0x16b7c5)),
        _0x5e6574["observe"](document["body"], _0x3ae33c),
        (_0x572c9e = !0x0),
        setTimeout(_0x4bcd18, _0x1d904a));
    else
      window["onload"] = () => {
        ((_0x5e6574 = new MutationObserver(_0x16b7c5)),
          _0x5e6574["observe"](document["body"], _0x3ae33c),
          (_0x572c9e = !0x0),
          setTimeout(_0x4bcd18, _0x1d904a));
      };
  });
}
async function _0x39d03b() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x9eafd3(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0xb152c6(
  _0x58f63f = null,
  _0x238bce = null,
  _0x41363a = null,
  _0x16aa2e = null,
) {
  var _0x569e37 = document["createElement"]("a");
  (_0x569e37["setAttribute"]("class", "a-link-text"),
    _0x569e37["classList"]["add"]("icon"),
    _0x569e37["classList"]["add"]("amazonSearchLink"),
    _0x569e37["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x3adcef = document["createElement"]("img");
  return (
    _0x3adcef["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x3adcef["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x569e37["appendChild"](_0x3adcef),
    _0x569e37["addEventListener"]("click", async function (_0x3e1624) {
      (_0x3e1624["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x58f63f) {
        var _0x685e67 = _0x2056f5(_0x3e1624);
        if (!_0x685e67) return;
        var _0x3c34c6 = extractItemData(_0x685e67);
        ((_0x58f63f = _0x3c34c6["title"])["endsWith"]("...") &&
          (_0x58f63f = _0x58f63f["substring"](
            0x0,
            _0x58f63f["lastIndexOf"]("\x20"),
          )),
          _0x58f63f["length"] > 0x4b &&
            (_0x58f63f = _0x58f63f["substring"](
              0x0,
              _0x58f63f["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0xd93286 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0xd93286),
        _0xd93286 || (_0xd93286 = "reviews"),
        console["log"]("amazonSortType", _0xd93286),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x585348 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x58f63f["length"] > 0x50; )
        _0x58f63f = _0x58f63f["substring"](
          0x0,
          _0x58f63f["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0xaa11a3 } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x13fbfb = _0x58f63f;
      "keywords" == _0xaa11a3 && (_0x13fbfb = await _0x372945(_0x58f63f));
      try {
        _0x3c34c6 = extractItemData(_0x685e67);
      } catch (_0x99aff0) {
        console["log"]("error", _0x99aff0);
      }
      (_0x3c34c6 ||
        (_0x3c34c6 = {
          title: _0x58f63f,
          price: _0x238bce,
          itemNumber: _0x41363a,
          image: _0x16aa2e,
        }),
        console["log"]("itemData", _0x3c34c6),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x13fbfb,
          options: { isTabActive: !0x0, sort: _0xd93286 },
          itemData: _0x3c34c6,
        }));
    }),
    _0x569e37
  );
}
function _0x2d8715(_0x3063d6) {
  var _0x13cc42 = document["createElement"]("a");
  (_0x13cc42["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x13cc42["setAttribute"]("class", "a-link-text"),
    _0x13cc42["classList"]["add"]("icon"),
    _0x13cc42["classList"]["add"]("amazonSearchLink"),
    _0x13cc42["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x4b6a8c = document["createElement"]("img");
  return (
    _0x4b6a8c["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4b6a8c["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x13cc42["appendChild"](_0x4b6a8c),
    _0x13cc42["addEventListener"]("click", async function (_0x40a93e) {
      (_0x40a93e["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x3063d6),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x3063d6,
        }));
    }),
    _0x13cc42
  );
}
function _0x37257a(_0x15410e) {
  var _0x398d0f = document["createElement"]("a");
  (_0x398d0f["setAttribute"]("id", "amazonLink"),
    _0x398d0f["setAttribute"]("class", "a-link-text"),
    _0x398d0f["classList"]["add"]("icon"),
    _0x398d0f["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x1c24d7 = document["createElement"]("img");
  return (
    _0x1c24d7["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x1c24d7["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x398d0f["appendChild"](_0x1c24d7),
    _0x398d0f["addEventListener"]("click", async function (_0x17042a) {
      (_0x17042a["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x30702f } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x62c8e4 =
          "https://www.amazon." +
          _0x30702f +
          "/dp/" +
          _0x15410e +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x62c8e4 });
    }),
    _0x398d0f
  );
}
function _0x308223(_0x52ecf1) {
  var _0x423831 = document["createElement"]("a");
  (_0x423831["setAttribute"]("id", "amazonLink"),
    _0x423831["setAttribute"]("class", "a-link-text"),
    _0x423831["classList"]["add"]("icon"),
    _0x423831["classList"]["add"]("amazonLink"),
    _0x423831["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x37c3ea = document["createElement"]("img");
  return (
    _0x37c3ea["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x37c3ea["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x423831["appendChild"](_0x37c3ea),
    _0x423831["addEventListener"]("click", async function (_0xdbb628) {
      (_0xdbb628["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x52ecf1(_0xdbb628);
      } catch (_0x407615) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x407615);
      }
    }),
    _0x423831
  );
}
function _0x1e27d4(
  _0x58a1cd = null,
  _0x273dc6,
  _0x57213f = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x58a1cd, _0x273dc6);
  var _0xa0cd67 = document["createElement"]("a");
  (_0xa0cd67["setAttribute"]("id", "ebayLink"),
    _0xa0cd67["setAttribute"]("class", "a-link-text"),
    _0xa0cd67["classList"]["add"]("icon"),
    _0x273dc6 && _0x273dc6["soldItems"]
      ? _0xa0cd67["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0xa0cd67["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0xf011c5 = document["createElement"]("img");
  return (
    _0xf011c5["setAttribute"]("src", chrome["runtime"]["getURL"](_0x57213f)),
    _0xf011c5["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xa0cd67["appendChild"](_0xf011c5),
    _0xa0cd67["addEventListener"]("click", async function (_0x3b2b8b) {
      (_0x3b2b8b["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x58a1cd) console["log"]("title\x20found", _0x58a1cd);
      else {
        console["log"]("title\x20not\x20found");
        var _0x3f6a70 = _0x2056f5(_0x3b2b8b);
        if (!_0x3f6a70) return;
        var _0x13ec15 = extractItemData(_0x3f6a70);
        _0x58a1cd = _0x13ec15["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x149c75 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x58a1cd["length"] > 0x50; )
        _0x58a1cd = _0x58a1cd["substring"](
          0x0,
          _0x58a1cd["lastIndexOf"]("\x20"),
        );
      var _0x4b2e77 =
        "https://www.ebay." +
        _0x149c75 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x58a1cd) +
        "&_odkw=" +
        encodeURIComponent(_0x58a1cd);
      (_0x273dc6 && _0x273dc6["soldItems"] && (_0x4b2e77 += "&LH_Sold=1"),
        _0x273dc6 && _0x273dc6["sortLowToHigh"] && (_0x4b2e77 += "&_sop=15"),
        _0x273dc6 && _0x273dc6["endedRecently"] && (_0x4b2e77 += "&_sop=13"),
        (_0x4b2e77 += "&LH_ItemCondition=1000"),
        (_0x4b2e77 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x4b2e77,
        }));
    }),
    _0xa0cd67
  );
}
function _0x57d22a(_0x316e0e = null) {
  var _0x2540ed = document["createElement"]("a");
  (_0x2540ed["setAttribute"]("id", "googleLink"),
    _0x2540ed["setAttribute"]("class", "a-link-text"),
    _0x2540ed["classList"]["add"]("icon"),
    _0x2540ed["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x4d1658 = document["createElement"]("img");
  return (
    _0x4d1658["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x4d1658["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2540ed["appendChild"](_0x4d1658),
    _0x2540ed["addEventListener"]("click", async function (_0x53c14e) {
      (_0x53c14e["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x316e0e) {
        var _0x28493d = _0x2056f5(_0x53c14e);
        if (!_0x28493d) return;
        var _0x508f36 = extractItemData(_0x28493d);
        _0x316e0e = _0x508f36["image"];
      }
      var { domain: _0x486a14 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0xef6c7b(_0x486a14),
        encodeURIComponent(_0x316e0e),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x316e0e,
        }));
    }),
    _0x2540ed
  );
}
function _0x2ac9c3(_0x10393e = null) {
  var _0x14d6b0 = document["createElement"]("a");
  (_0x14d6b0["setAttribute"]("id", "googleLink"),
    _0x14d6b0["setAttribute"]("class", "a-link-text"),
    _0x14d6b0["classList"]["add"]("icon"),
    _0x14d6b0["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x309374 = document["createElement"]("img");
  return (
    _0x309374["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x309374["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x14d6b0["appendChild"](_0x309374),
    _0x14d6b0["addEventListener"]("click", async function (_0x173e10) {
      (_0x173e10["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x10393e) {
        var _0x2783a7 = _0x2056f5(_0x173e10);
        if (!_0x2783a7) return;
        var _0x33ab57 = extractItemData(_0x2783a7);
        _0x10393e = _0x33ab57["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x10393e,
      });
    }),
    _0x14d6b0
  );
}
function _0x494fbb(_0x54b40a) {
  var _0x353b6a = document["createElement"]("a");
  (_0x353b6a["setAttribute"]("id", "lookUpSkuLink"),
    _0x353b6a["setAttribute"]("class", "a-link-text"),
    _0x353b6a["classList"]["add"]("icon"),
    _0x353b6a["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x12a76c = document["createElement"]("img");
  return (
    _0x12a76c["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x12a76c["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x353b6a["appendChild"](_0x12a76c),
    _0x353b6a["addEventListener"]("click", async function (_0x45bc1f) {
      (_0x45bc1f["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x989c4f } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x1cce33 =
          "https://www.amazon." +
          _0x989c4f +
          "/dp/" +
          _0x54b40a +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x1cce33,
        options: { active: !0x0 },
      });
    }),
    _0x353b6a
  );
}
function _0x4957c8(_0x1123c2 = null) {
  var _0x3161fb = document["createElement"]("a");
  (_0x3161fb["setAttribute"]("id", "productHunterLink"),
    _0x3161fb["setAttribute"]("class", "a-link-text"),
    _0x3161fb["classList"]["add"]("icon"),
    _0x3161fb["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x57550b = document["createElement"]("img");
  return (
    _0x57550b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x57550b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3161fb["appendChild"](_0x57550b),
    _0x3161fb["addEventListener"]("click", async function (_0x30ebf0) {
      (_0x30ebf0["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x1123c2) {
        var _0x18b4ec = _0x2056f5(_0x30ebf0);
        if (!_0x18b4ec) return;
        var _0x98846e = extractItemData(_0x18b4ec);
        _0x1123c2 = _0x98846e["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x1123c2),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x1123c2,
        }));
    }),
    _0x3161fb
  );
}
function _0xef6c7b(_0x222905) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x222905] || "en-US";
}
function _0x3d8543(_0x1e9a6a = null) {
  console["log"]("createSearchTerapeakButton", _0x1e9a6a);
  var _0x131530 = document["createElement"]("a");
  (_0x131530["setAttribute"]("class", "a-link-text"),
    _0x131530["classList"]["add"]("terapeakLink"),
    _0x131530["classList"]["add"]("icon"),
    _0x131530["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x1e9a6a && _0x131530["setAttribute"]("item_title", _0x1e9a6a));
  var _0x3e625d = document["createElement"]("img");
  return (
    _0x3e625d["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x3e625d["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x131530["appendChild"](_0x3e625d),
    _0x131530["addEventListener"]("click", async function (_0x2577e7) {
      (_0x2577e7["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x4666df = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x4666df),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x4666df) {
        var _0xec5a39 = _0x2056f5(_0x2577e7);
        if (!_0xec5a39) return;
        _0x4666df = extractItemData(_0xec5a39)["title"];
      }
      console["log"]("title", _0x4666df);
      var { convertToKeywords: _0x1147f8 } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x1147f8) var _0x4666df = await _0x372945(_0x4666df);
      var { domain: _0x1bef9d } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x2f03ec = _0x1d2b30(_0x4666df, _0x1bef9d);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x2f03ec });
    }),
    _0x131530
  );
}
async function _0x372945(_0x30c973) {
  var _0x345ba1 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x3189f6) => _0x3189f6["json"]());
  ((_0x345ba1["user_input"] = _0x30c973),
    console["log"]("jsonPrompt", _0x345ba1));
  var _0x2d9d87 = await new Promise((_0x54860b, _0x4f7058) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x345ba1,
      },
      function (_0x1ece93) {
        _0x54860b(_0x1ece93["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x2d9d87),
    (_0x2d9d87 = JSON["parse"](_0x2d9d87))["output"]
  );
}
function _0x1d2b30(
  _0x260065,
  _0x2633ed = "ca",
  _0x16771c = 0x1e,
  _0x2edbab = 0x0,
  _0x3ca0ef = 0x0,
  _0x1ef3a1 = 0x32,
  _0x130aec = "-itemssold",
  _0x8b53e9 = "SOLD",
  _0x351108 = "EBAY-CA",
  _0x537b2c = "America/Toronto",
  _0xfd4da3 = "BuyerLocation:::CA",
  _0x801b46 = 0x0,
) {
  _0x351108 = "";
  switch (_0x2633ed) {
    case "ca":
    default:
      _0x351108 = "EBAY-CA";
      break;
    case "com":
      _0x351108 = "EBAY-US";
      break;
    case "co.uk":
      _0x351108 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x2633ed +
    "/sh/research?" +
    [
      "keywords=" + _0x260065,
      "dayRange=" + _0x16771c,
      "categoryId=" + _0x2edbab,
      "offset=" + _0x3ca0ef,
      "limit=" + _0x1ef3a1,
      "sorting=" + _0x130aec,
      "tabName=" + _0x8b53e9,
      "marketplace=" + _0x351108,
      "tz=" + encodeURIComponent(_0x537b2c),
      "minPrice=" + _0x801b46,
    ]["join"]("&")
  );
}
async function _0x35b7f9(_0x4be6db) {
  var { domain: _0x1be6d8 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x5b60a6 =
      "https://www.ebay." +
      _0x1be6d8 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x4be6db +
      "&store_name=" +
      _0x4be6db +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x5b60a6 });
}
async function _0x4595a0(_0x1db107) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x1db107,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x1db107));
}
async function _0x16c075(_0x5d0df0) {
  var { response: _0x24a37c } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x5d0df0,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x24a37c), _0x24a37c);
}
function _0x414857(_0x2f98fc = null) {
  console["log"]("createOpenSellerItemsButton", _0x2f98fc);
  var _0x3cffa0 = document["createElement"]("a");
  (_0x3cffa0["setAttribute"]("id", "sellerItemsLink"),
    _0x3cffa0["setAttribute"]("class", "a-link-text"),
    _0x3cffa0["classList"]["add"]("icon"),
    _0x3cffa0["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x590565 = document["createElement"]("img");
  return (
    _0x590565["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x590565["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3cffa0["appendChild"](_0x590565),
    _0x3cffa0["addEventListener"]("click", async function (_0x47e0fa) {
      (_0x47e0fa["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x2f98fc),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x2f98fc));
      var _0x7f1890;
      if (!_0x2f98fc) {
        console["log"]("username\x20not\x20found");
        var _0x5f4d71 = _0x2056f5(_0x47e0fa);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x5f4d71,
        );
        if (!_0x5f4d71) return;
        var _0x35b6a9 = extractItemData(_0x5f4d71);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x35b6a9,
        ),
          (_0x2f98fc = _0x35b6a9["username"]),
          (_0x7f1890 = _0x35b6a9["itemNumber"]));
      }
      if (
        _0x2f98fc["includes"]("\x20") ||
        _0x2f98fc !== _0x2f98fc["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x2f98fc,
        );
        if (!_0x7f1890) {
          if (!(_0x5f4d71 = _0x2056f5(_0x47e0fa))) return;
          _0x7f1890 = (_0x35b6a9 = extractItemData(_0x5f4d71))["itemNumber"];
        }
        _0x4595a0(_0x7f1890);
      } else
        ((_0x2f98fc = _0x2f98fc["toLowerCase"]()),
          console["log"]("username", _0x2f98fc),
          _0x35b7f9(_0x2f98fc));
    }),
    _0x3cffa0
  );
}
function _0x13f6a0(_0x13ea81) {
  for (
    ;
    _0x13ea81 &&
    !_0x13ea81["classList"]["contains"]("s-item") &&
    !_0x13ea81["classList"]["contains"]("su-card-container");

  )
    _0x13ea81 = _0x13ea81["parentElement"];
  return _0x13ea81;
}
function _0xd05f05(_0x4d0883 = null) {
  var _0x491eaa = document["createElement"]("a");
  (_0x491eaa["setAttribute"]("id", "purchaseHistoryLink"),
    _0x491eaa["setAttribute"]("class", "a-link-text"),
    _0x491eaa["classList"]["add"]("icon"),
    _0x491eaa["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x262ac6 = document["createElement"]("img");
  return (
    _0x262ac6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x262ac6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x491eaa["appendChild"](_0x262ac6),
    _0x491eaa["addEventListener"]("click", async function (_0x25eb68) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x4d0883),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x25eb68["preventDefault"]());
      var _0x263b68 = _0x2056f5(_0x25eb68);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x263b68,
      );
      if (_0x263b68) {
        var { selectedFilter: _0x2f0f16 } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x2f0f16 &&
          ((_0x2f0f16 = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x2f0f16,
          }));
        var _0x435624 = _0x2f0f16,
          _0x3c0382 = await checkPurchaseHistoryAndAddToItem(
            _0x263b68,
            _0x435624,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x3c0382);
      } else
        try {
          var _0x211a80 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x4d0883,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x211a80),
            (_0x3c0382 = _0x211a80["totalSold"]));
        } catch (_0x5b19ed) {
          (console["log"]("error", _0x5b19ed), (_0x3c0382 = -0x3e7));
        }
    }),
    _0x491eaa
  );
}
function _0x2056f5(_0x2ae0ea) {
  var _0x48b65c = _0x2ae0ea["target"];
  return (
    (_0x48b65c = _0x13f6a0(_0x48b65c)),
    console["log"]("found\x20s-item", _0x48b65c),
    _0x48b65c
  );
}
function _0x28064c(_0x401a00 = null, _0xc637d = null, _0x197b9f = null) {
  var _0x12e4f3 = document["createElement"]("a");
  (_0x12e4f3["setAttribute"]("id", "copyDataLink"),
    _0x12e4f3["setAttribute"]("class", "a-link-text"),
    _0x12e4f3["classList"]["add"]("icon"),
    _0x12e4f3["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x1433a0 = document["createElement"]("img");
  return (
    _0x1433a0["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x1433a0["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x12e4f3["appendChild"](_0x1433a0),
    _0x12e4f3["addEventListener"]("click", async function (_0x303446) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x401a00,
        _0xc637d,
        _0x197b9f,
      ),
        _0x303446["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x401a00 && _0xc637d && _0x197b9f)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x401a00,
          _0xc637d,
          _0x197b9f,
        ),
          isNaN(_0xc637d) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0xc637d),
            (_0xc637d = _0xc637d["replace"](/[^0-9.]/g, ""))),
          _0x372392(
            JSON["stringify"]({
              title: _0x401a00,
              price: _0xc637d,
              itemNumber: _0x197b9f,
            }),
          ));
      else {
        if (!_0x401a00 || !_0xc637d || !_0x197b9f) {
          var _0x41cea9 = _0x2056f5(_0x303446);
          if (!_0x41cea9) return;
        }
        var _0x5b9f13 = extractItemData(_0x41cea9);
        (console["log"]("itemData", _0x5b9f13),
          _0x372392(JSON["stringify"](_0x5b9f13)));
      }
    }),
    _0x12e4f3
  );
}
function _0x372392(_0xb7d47) {
  var _0x2e1658 = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x2e1658),
    (_0x2e1658["value"] = _0xb7d47),
    _0x2e1658["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x2e1658));
}
async function _0xed03a1(_0x4298ef = null) {
  console["log"]("price", _0x4298ef);
  if (_0x4298ef) {
    try {
      _0x4298ef = _0x4298ef["replace"](/[^0-9.]/g, "");
    } catch (_0x31ca1c) {}
    _0x4298ef = parseFloat(_0x4298ef);
  }
  var _0x50c06a = await _0x454566(_0x4298ef),
    _0x2d547a = document["createElement"]("div");
  return (
    _0x2d547a["setAttribute"]("id", "breakEvenPrice"),
    _0x2d547a["setAttribute"]("class", "break-even-price"),
    (_0x2d547a["textContent"] =
      "Break-even\x20price:\x20$" + _0x50c06a["toFixed"](0x2)),
    _0x2d547a
  );
}
async function _0x5a4173(_0xa8f6a9) {
  var _0x586223 = !0x1,
    _0x2bbadf = !0x1,
    { includeCurrencyConversion: _0x2bbadf } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x586223 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x5f383 =
    0.1325 * _0xa8f6a9 +
    0.021 * _0xa8f6a9 +
    _0xa8f6a9 * (_0x586223 ? 0.004 : 0x0) +
    0.4;
  return (_0x2bbadf && (_0x5f383 += 0.035 * _0xa8f6a9), _0xa8f6a9 - _0x5f383);
}
async function _0x454566(_0x212ed2) {
  var { isInternational: _0x7a0be2 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x1f83b6 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x7a0be2 || (_0x7a0be2 = !0x1), _0x1f83b6 || (_0x1f83b6 = !0x0));
  var _0x2e4ab8 = 13.25;
  _0x1f83b6 && (_0x2e4ab8 = 12.35);
  var _0x3ba8dc = _0x212ed2 + 0.0725 * _0x212ed2,
    _0x49ae55 =
      _0x3ba8dc * (_0x2e4ab8 / 0x64) +
      0.4 +
      (_0x7a0be2 ? 0.004 * _0x3ba8dc : 0x0),
    _0x252c44 =
      _0x212ed2 -
      (_0x49ae55 + (_0x7a0be2 ? 0.05 * _0x49ae55 : 0x0)) -
      (_0x7a0be2 ? 0.035 * _0x3ba8dc : 0x0),
    { isUserTaxExempt: _0x2e117c } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x2e117c || (_0x2e117c = !0x1),
    _0x2e117c || (_0x252c44 /= 1.0725),
    _0x7a0be2 && (_0x252c44 -= (3.5 * _0x252c44) / 0x64),
    _0x252c44
  );
}
function _0x394a29(_0xa280ca = null) {
  console["log"]("createButtonToSaveSeller", _0xa280ca);
  var _0x10b375 = document["createElement"]("a");
  (_0x10b375["setAttribute"]("id", "saveSellerLink"),
    _0x10b375["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x10b375["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x16ed6e = document["createElement"]("img");
  return (
    _0x16ed6e["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x16ed6e["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x10b375["appendChild"](_0x16ed6e),
    _0x10b375["addEventListener"]("click", async function (_0x28032f) {
      (_0x28032f["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0xa280ca));
      var _0x55d460;
      if (!_0xa280ca) {
        var _0xb34c8 = _0x2056f5(_0x28032f);
        if (!_0xb34c8) return;
        var _0x277135 = extractItemData(_0xb34c8);
        ((_0xa280ca = _0x277135["username"]),
          (_0x55d460 = _0x277135["itemNumber"]));
      }
      if (
        _0xa280ca["includes"]("\x20") ||
        _0xa280ca !== _0xa280ca["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0xa280ca,
        ),
          (_0xa280ca = await _0x16c075(_0x55d460)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0xa280ca,
          ));
      else _0xa280ca = _0xa280ca["toLowerCase"]();
      _0x10b375["setAttribute"]("data-seller-name", _0xa280ca);
      var { ebayCompetitors: _0x4c1e1e } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x3448e7 = (_0x4c1e1e = _0x4c1e1e || [])["indexOf"](_0xa280ca);
      console["log"]("ebayCompetitors", _0x4c1e1e);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x3448e7
            ? (console["log"]("save-seller\x20clicked\x20username", _0xa280ca),
              _0x4c1e1e["push"](_0xa280ca),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x16ed6e["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0xa280ca,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x16ed6e["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x3448e7)
            (console["log"]("remove-seller\x20clicked\x20username", _0xa280ca),
              _0x4c1e1e["splice"](_0x3448e7, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x16ed6e["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0xa280ca,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x4c1e1e });
    }),
    _0x10b375
  );
}
async function _0x37492e(_0x5d9ed2, _0x367f0e) {
  var { ebayCompetitors: _0x356e1a } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x524cf0 = (_0x356e1a = _0x356e1a || [])["indexOf"](_0x367f0e),
    _0x40f3d9 = _0x5d9ed2["querySelector"]("img");
  -0x1 !== _0x524cf0
    ? (_0x5d9ed2["classList"]["replace"]("save-seller", "remove-seller"),
      _0x40f3d9["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x5d9ed2["classList"]["replace"]("remove-seller", "save-seller"),
      _0x40f3d9["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x996b48(
  _0x4da2b1 = null,
  _0x214cc1 = null,
  _0x5ed664 = null,
  _0xbed318 = !0x0,
  _0x285538 = null,
  _0x540cc1 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x4da2b1));
  var _0x2ba3de = _0x394a29(_0x214cc1),
    _0x28a86e = _0x3d8543(_0x4da2b1),
    _0x488d35 = _0xd05f05(_0x285538),
    _0x36d232 = _0x1e27d4(_0x4da2b1),
    _0x5dd7ca = _0xb152c6(_0x4da2b1, _0x540cc1, _0x285538, _0x5ed664),
    _0xc67c79 = _0x1e27d4(
      _0x4da2b1,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x4a4f04 = _0x57d22a(_0x5ed664),
    _0x4b0048 = _0x2ac9c3(_0x285538),
    _0x4389bc = _0x414857(_0x214cc1),
    _0x477c6b = document["createElement"]("div");
  _0x477c6b["setAttribute"]("id", "search-div");
  var _0x35831d = document["createElement"]("label");
  ((_0x35831d["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x477c6b["appendChild"](_0x35831d),
    _0x477c6b["appendChild"](_0x5dd7ca),
    _0x477c6b["appendChild"](_0x36d232),
    _0x477c6b["appendChild"](_0x28a86e),
    _0x477c6b["appendChild"](_0x4a4f04),
    _0x477c6b["appendChild"](_0x4b0048),
    _0x477c6b["appendChild"](_0xc67c79),
    console["log"]("CopyDataButton", _0x4da2b1, _0x540cc1, _0x285538));
  var _0x2bb21f = _0x28064c(_0x4da2b1, _0x540cc1, _0x285538),
    _0x58575d = document["createElement"]("div");
  _0x58575d["setAttribute"]("id", "item-buttons-div");
  var _0x4cb997 = document["createElement"]("div");
  (_0x4cb997["setAttribute"]("id", "main-buttons-div"),
    _0x4cb997["appendChild"](_0x4389bc),
    _0x4cb997["appendChild"](_0x488d35),
    _0x4cb997["appendChild"](_0x2bb21f),
    _0x4cb997["appendChild"](_0x2ba3de),
    _0x58575d["appendChild"](_0x4cb997));
  if (_0xbed318) {
    var _0x194c46 = createButtonListToEbay();
    _0x58575d["appendChild"](_0x194c46);
  }
  return (_0x58575d["appendChild"](_0x477c6b), _0x58575d);
}
var _0x1c2c08 = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x395d72) => {
        (console["log"](
          _0x395d72,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          _0x390d28(_0x1c2c08, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x1f866f) => {
        (console["log"](
          _0x1f866f,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          _0x390d28(_0x1c2c08, "search-type", "keywords"));
      },
    },
  },
];
async function _0x40bc07() {
  var { convertToKeywords: _0x56a416 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x56a416 &&
    ((_0x56a416 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    _0x390d28(_0x1c2c08, "search-type", _0x56a416 ? "keywords" : "title"),
    new _0x3472e1({ target: ".terapeakLink", menuItems: _0x1c2c08 })["init"]());
}
var _0x2bbb66 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x48988e) => {
        (console["log"](_0x48988e, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          _0x390d28(_0x2bbb66, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x3984ce) => {
        (console["log"](_0x3984ce, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          _0x390d28(_0x2bbb66, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x445d3d) => {
        (console["log"](
          _0x445d3d,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          _0x390d28(_0x2bbb66, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x340526) => {
        (console["log"](
          _0x340526,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          _0x390d28(_0x2bbb66, "search-type", "keywords"));
      },
    },
  },
];
async function _0x821f51() {
  var { amazonSortType: _0x48cc7f } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x386cde } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x386cde &&
    ((_0x386cde = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x48cc7f &&
      ((_0x48cc7f = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    _0x390d28(_0x2bbb66, "sort-type", _0x48cc7f),
    _0x390d28(_0x2bbb66, "search-type", _0x386cde),
    new _0x3472e1({ target: ".amazonSearchLink", menuItems: _0x2bbb66 })[
      "init"
    ]());
}
_0x2bbb66 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x3d4abd) => {
        (console["log"](_0x3d4abd, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          _0x390d28(_0x2bbb66, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x110f21) => {
        (console["log"](_0x110f21, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          _0x390d28(_0x2bbb66, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x2ef3cf = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x435c15) => {
        (console["log"](_0x435c15, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          _0x390d28(_0x2ef3cf, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5debea) => {
        (console["log"](_0x5debea, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          _0x390d28(_0x2ef3cf, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5afe5f) => {
        (console["log"](_0x5afe5f, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          _0x390d28(_0x2ef3cf, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5842e4) => {
        (console["log"](_0x5842e4, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          _0x390d28(_0x2ef3cf, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x5bfc08) => {
        (console["log"](_0x5bfc08, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          _0x390d28(_0x2ef3cf, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x123539) => {
        (console["log"](_0x123539, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          _0x390d28(_0x2ef3cf, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0xb1ea6a) => {
        (console["log"](_0xb1ea6a, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          _0x390d28(_0x2ef3cf, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x4215a7) => {
        (console["log"](_0x4215a7, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          _0x390d28(_0x2ef3cf, "filter-type", "90"));
      },
    },
  },
];
async function _0x563720() {
  var { selectedFilter: _0x63557d } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x63557d &&
    ((_0x63557d = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    _0x390d28(_0x2ef3cf, "filter-type", _0x63557d),
    new _0x3472e1({ target: ".filter-date-context", menuItems: _0x2ef3cf })[
      "init"
    ]());
}
function _0x28291b() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x5601c6() {
  const _0x12ad58 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x24a574 = 0x0;
  const _0x237cfa = () =>
    new Promise((_0x952874, _0x38042e) => {
      const _0x54c367 = new MutationObserver((_0x4d3903, _0x325287) => {
        const _0x4e9bc6 = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x4e9bc6 &&
          (console["log"]("Details\x20form\x20found!"),
          _0x325287["disconnect"](),
          _0x952874(_0x4e9bc6));
      });
      (_0x54c367["observe"](_0x12ad58, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x54c367["disconnect"]();
          if (_0x24a574 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x24a574 + 0x1) +
                "/3)",
            ),
              _0x24a574++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x952874(_0x237cfa()), 0x1388));
          else
            _0x38042e(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x9670 = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x9670) {
    (_0x9670["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x237cfa(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x5718f1) {
      console["error"](_0x5718f1["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x4e7427(_0x443507 = null, _0x4882c5 = null, _0x7326e7 = null) {
  var _0x532b08 = document["createElement"]("a");
  (_0x532b08["setAttribute"]("id", "copyDataLink"),
    _0x532b08["setAttribute"]("class", "a-link-text"),
    _0x532b08["classList"]["add"]("icon"),
    _0x532b08["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x2ad3e6 = document["createElement"]("img");
  return (
    _0x2ad3e6["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x2ad3e6["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x532b08["appendChild"](_0x2ad3e6),
    _0x532b08["addEventListener"]("click", async function (_0x1fcdb0) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x443507,
        _0x4882c5,
        _0x7326e7,
      ),
        _0x1fcdb0["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x443507 && _0x4882c5 && _0x7326e7) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x443507,
          _0x4882c5,
          _0x7326e7,
        );
        isNaN(_0x4882c5) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x4882c5),
          (_0x4882c5 = _0x4882c5["replace"](/[^0-9.]/g, "")));
        var _0x1c6c37 = JSON["stringify"]({
          title: _0x443507,
          price: _0x4882c5,
          itemNumber: _0x7326e7,
        });
        (_0x26c0c0(
          (_0x528dca = await findSimiliarProducts(_0x1c6c37))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x528dca),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x443507 || !_0x4882c5 || !_0x7326e7) {
          var _0x2ebb9b = _0x2056f5(_0x1fcdb0);
          if (!_0x2ebb9b) return;
        }
        var _0x132cdb = extractItemData(_0x2ebb9b);
        (console["log"]("itemData", _0x132cdb),
          (_0x1c6c37 = JSON["stringify"](_0x132cdb)));
        var _0x528dca;
        (_0x26c0c0(
          (_0x528dca = await findSimiliarProducts(_0x1c6c37))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x528dca),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x532b08
  );
}
async function findSimiliarProducts(_0x5b42a4) {
  console["log"]("findSimiliarProducts", _0x5b42a4);
  var _0x20d932 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x5b42a4,
  });
  return (console["log"]("response", _0x20d932), _0x20d932["productLinks"]);
}
function _0x26c0c0(_0x168aee) {
  const _0x4fbc98 = document["getElementById"]("productLinksModalOverlay");
  _0x4fbc98 && _0x4fbc98["remove"]();
  const _0x13156a = document["createElement"]("div");
  ((_0x13156a["id"] = "productLinksModalOverlay"),
    _0x13156a["classList"]["add"]("product-links-modal-overlay"));
  const _0xf180c4 = document["createElement"]("div");
  _0xf180c4["classList"]["add"]("product-links-modal");
  const _0x22c79f = document["createElement"]("div");
  _0x22c79f["classList"]["add"]("modal-button-container");
  const _0x3dfe85 = document["createElement"]("button");
  (_0x3dfe85["classList"]["add"]("close-button"),
    (_0x3dfe85["innerText"] = "Close"),
    _0x3dfe85["addEventListener"]("click", () => {
      _0x13156a["remove"]();
    }));
  const _0x231ad4 = document["createElement"]("button");
  (_0x231ad4["classList"]["add"]("copy-button"),
    (_0x231ad4["innerText"] = "Copy"),
    _0x231ad4["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x168aee),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x2200bd) {
        console["error"]("Failed\x20to\x20copy:", _0x2200bd);
      }
    }));
  const _0x1ccf68 = document["createElement"]("h2");
  _0x1ccf68["innerText"] = "Similar\x20Product\x20Links";
  const _0x11ef05 = document["createElement"]("textarea");
  ((_0x11ef05["value"] = _0x168aee),
    _0x11ef05["setAttribute"]("readonly", !0x0),
    (_0x11ef05["style"]["width"] = "100%"),
    (_0x11ef05["style"]["height"] = "300px"),
    _0x22c79f["appendChild"](_0x231ad4),
    _0x22c79f["appendChild"](_0x3dfe85),
    _0xf180c4["appendChild"](_0x22c79f),
    _0xf180c4["appendChild"](_0x1ccf68),
    _0xf180c4["appendChild"](_0x11ef05),
    _0x13156a["appendChild"](_0xf180c4),
    document["body"]["appendChild"](_0x13156a));
}
async function _0x4d6a16() {
  console["log"]("addQuickActionButtons");
  var _0x1697bc = document["getElementsByClassName"]("research-table-row");
  for (var _0x2d0436 = 0x0; _0x2d0436 < _0x1697bc["length"]; _0x2d0436++) {
    var _0x5a220c = _0x1697bc[_0x2d0436],
      _0x3ba383 = _0x5a220c["querySelector"](".research-table-row__actions"),
      _0x15325a = _0x5b3ba5(_0x5a220c),
      _0x235b24 = _0x12d320(_0x5a220c),
      _0x2026ef = _0x3efde2(_0x5a220c);
    (console["log"]("title", _0x15325a),
      console["log"]("price", _0x235b24),
      console["log"]("itemNumber", _0x2026ef));
    var _0x1535a8 = _0xd05f05(_0x2026ef),
      _0x4c8ada = _0x1e27d4(_0x15325a),
      _0x4aadf1 = _0xb152c6(_0x15325a),
      _0x4a9d25 = _0x28064c(_0x15325a, _0x235b24, _0x2026ef),
      _0x18e550 = document["createElement"]("div");
    _0x18e550["setAttribute"]("id", "search-div");
    var _0x3b574d = document["createElement"]("label");
    ((_0x3b574d["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
      _0x18e550["appendChild"](_0x3b574d),
      _0x18e550["appendChild"](_0x4aadf1),
      _0x18e550["appendChild"](_0x4c8ada),
      _0x18e550["appendChild"](_0x1535a8),
      _0x18e550["appendChild"](_0x4a9d25),
      _0x3ba383["appendChild"](_0x18e550));
  }
}
function _0x5b3ba5(_0x3291f0) {
  return _0x3291f0["querySelector"](".research-table-row__product-info-name")[
    "innerText"
  ];
}
function _0x12d320(_0x45b23e) {
  return _0x45b23e["querySelector"](".research-table-row__avgSoldPrice")[
    "innerText"
  ]["match"](/\d+\.\d+/)[0x0];
}
function _0x3efde2(_0x29c9b2) {
  return _0x29c9b2["querySelector"](".research-table-row__link-row-anchor")[
    "href"
  ]["match"](/\/itm\/(\d+)/)[0x1];
}
console["log"]("Terapeak\x20script\x20loaded");
async function _0x4134e7() {
  (await _0x32b65a(),
    console["log"]("terapeak\x20page\x20loaded"),
    (await _0x3c0d78(0x2710)) && (await _0x821f51()));
}
_0x4134e7();
async function _0x3c0d78(_0x37b8d4) {
  return new Promise((_0x40932e) => {
    const _0x17d62f = (_0x4ce3b4) => {
      (console["log"]("Window.addEvent", _0x4ce3b4),
        document["querySelector"]("#search-div") || _0x4d6a16(),
        document["querySelector"]("#search-div") &&
          (window["removeEventListener"]("message", _0x17d62f),
          _0x40932e(!0x0)));
    };
    (window["addEventListener"]("message", _0x17d62f, !0x1),
      setTimeout(() => {
        (window["removeEventListener"]("message", _0x17d62f), _0x40932e(!0x1));
      }, _0x37b8d4));
  });
}
