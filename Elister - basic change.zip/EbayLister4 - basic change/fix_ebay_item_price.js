// Fix price extraction on eBay item pages
// This script corrects the price value to avoid grabbing the seller feedback score

(function () {
  "use strict";

  console.log("[Price Fix] Script loaded on eBay item page");

  // Function to extract the correct price from eBay item page
  function extractCorrectPrice() {
    console.log("[Price Fix] Starting price extraction...");

    // First, try to find the original "Was" price (before sale)
    // This appears when an item is on sale
    const originalPriceSelectors = [
      ".x-price-section__main-panel .ux-textspans--STRIKETHROUGH", // Strikethrough original price
      ".x-price-section .ux-textspans[aria-hidden='true']", // Hidden text with original price
      ".x-price-primary ~ .ux-textspans--STRIKETHROUGH", // Strikethrough near primary price
    ];

    // Try to find elements containing "Was" or other language equivalents
    const allTextElements = document.querySelectorAll(
      ".x-price-section .ux-textspans",
    );
    for (const element of allTextElements) {
      const text = element.textContent || "";
      // Check for "Was", "Era" (Portuguese/Spanish), "Était" (French), "War" (German), etc.
      if (
        /^(Was|Era|Était|War|原价|Było|Fue)\s+/i.test(text) ||
        element.classList.contains("ux-textspans--STRIKETHROUGH")
      ) {
        let priceText = text;
        console.log(
          "[Price Fix] Found potential original price text:",
          priceText,
        );

        // Extract numeric value
        priceText = priceText.replace(/[^0-9.,]/g, "");

        // Handle different decimal/thousand separators
        const lastComma = priceText.lastIndexOf(",");
        const lastDot = priceText.lastIndexOf(".");

        if (lastComma > lastDot) {
          // European format: 1.234,56
          priceText = priceText.replace(/\./g, "").replace(",", ".");
        } else {
          // US format: 1,234.56
          priceText = priceText.replace(/,/g, "");
        }

        const price = parseFloat(priceText);
        if (!isNaN(price) && price > 0) {
          console.log("[Price Fix] Extracted original (Was) price:", price);
          return price.toFixed(2);
        }
      }
    }

    // If no "Was" price found, look for strikethrough elements
    for (const selector of originalPriceSelectors) {
      const priceElement = document.querySelector(selector);
      if (priceElement) {
        let priceText = priceElement.textContent || priceElement.innerText;
        console.log(
          "[Price Fix] Found strikethrough price with selector:",
          selector,
          "Text:",
          priceText,
        );

        // Extract numeric value
        priceText = priceText.replace(/[^0-9.,]/g, "");

        // Handle different decimal/thousand separators
        const lastComma = priceText.lastIndexOf(",");
        const lastDot = priceText.lastIndexOf(".");

        if (lastComma > lastDot) {
          // European format: 1.234,56
          priceText = priceText.replace(/\./g, "").replace(",", ".");
        } else {
          // US format: 1,234.56
          priceText = priceText.replace(/,/g, "");
        }

        const price = parseFloat(priceText);
        if (!isNaN(price) && price > 0) {
          console.log("[Price Fix] Extracted original price:", price);
          return price.toFixed(2);
        }
      }
    }

    // Fallback: Try to get the percentage and calculate original price
    const discountElement = document.querySelector(
      ".x-price-section .ux-textspans:not(.ux-textspans--STRIKETHROUGH)",
    );
    const percentageMatch =
      discountElement?.textContent?.match(/\((\d+)%.*?\)/);
    if (percentageMatch) {
      const discountPercent = parseInt(percentageMatch[1]);
      console.log("[Price Fix] Found discount percentage:", discountPercent);

      // Get current sale price
      const salePriceSelectors = [
        ".x-price-primary span.ux-textspans:not(.ux-textspans--STRIKETHROUGH)",
        ".x-price-primary .ux-textspans--BOLD",
      ];

      for (const selector of salePriceSelectors) {
        const priceElement = document.querySelector(selector);
        if (priceElement) {
          let priceText = priceElement.textContent || priceElement.innerText;
          priceText = priceText.replace(/[^0-9.,]/g, "");

          const lastComma = priceText.lastIndexOf(",");
          const lastDot = priceText.lastIndexOf(".");

          if (lastComma > lastDot) {
            priceText = priceText.replace(/\./g, "").replace(",", ".");
          } else {
            priceText = priceText.replace(/,/g, "");
          }

          const salePrice = parseFloat(priceText);
          if (!isNaN(salePrice) && salePrice > 0) {
            // Calculate original price from sale price and discount percentage
            const originalPrice = salePrice / (1 - discountPercent / 100);
            console.log(
              "[Price Fix] Calculated original price from sale price and percentage:",
              originalPrice,
            );
            return originalPrice.toFixed(2);
          }
        }
      }
    }

    // Final fallback: Get current price (sale or regular)
    const priceSelectors = [
      ".x-price-primary span.ux-textspans", // New eBay layout
      ".x-price-primary .ux-textspans--BOLD",
      '[itemprop="price"]',
      ".x-price-approx__price",
      ".vi-VR-cvipPrice",
      "#prcIsum",
      "#mm-saleDscPrc",
      ".notranslate.vi-VR-cvipPrice",
    ];

    for (const selector of priceSelectors) {
      const priceElement = document.querySelector(selector);
      if (priceElement) {
        let priceText = priceElement.textContent || priceElement.innerText;
        console.log(
          "[Price Fix] Found fallback price with selector:",
          selector,
          "Text:",
          priceText,
        );

        // Extract numeric value
        priceText = priceText.replace(/[^0-9.,]/g, "");

        // Handle different decimal/thousand separators
        const lastComma = priceText.lastIndexOf(",");
        const lastDot = priceText.lastIndexOf(".");

        if (lastComma > lastDot) {
          // European format: 1.234,56
          priceText = priceText.replace(/\./g, "").replace(",", ".");
        } else {
          // US format: 1,234.56
          priceText = priceText.replace(/,/g, "");
        }

        const price = parseFloat(priceText);
        if (!isNaN(price) && price > 0) {
          console.log("[Price Fix] Extracted fallback price:", price);
          return price.toFixed(2);
        }
      }
    }

    console.log("[Price Fix] Could not find price, returning null");
    return null;
  }

  // Override the Copy Data button creation to use correct price
  function patchCopyDataButton() {
    // Wait for the button to be created
    const observer = new MutationObserver((mutations) => {
      const copyButton = document.querySelector("#copyDataLink");
      if (copyButton && !copyButton.dataset.pricePatched) {
        console.log("[Price Fix] Found Copy Data button, patching...");
        copyButton.dataset.pricePatched = "true";

        // Get the correct price
        const correctPrice = extractCorrectPrice();
        if (correctPrice) {
          console.log(
            "[Price Fix] Patching button with correct price:",
            correctPrice,
          );

          // Re-attach click handler with correct price
          const oldHandler = copyButton.onclick;
          copyButton.onclick = null;

          copyButton.addEventListener("click", async function (e) {
            e.preventDefault();
            this.classList.add("clicked");
            setTimeout(() => {
              this.classList.remove("clicked");
            }, 800);

            // Get title and item number from the page
            const title =
              document.querySelector("h1.x-item-title__mainTitle span")
                ?.textContent ||
              document.querySelector(".it-ttl")?.textContent ||
              document.title.split("|")[0].trim();

            const itemNumber =
              window.location.pathname.match(/\/itm\/(\d+)/)?.[1] ||
              document.querySelector("[data-itemid]")?.dataset.itemid;

            const data = {
              title: title,
              price: correctPrice,
              itemNumber: itemNumber,
            };

            // Copy to clipboard
            const jsonString = JSON.stringify(data);
            const textarea = document.createElement("textarea");
            document.body.appendChild(textarea);
            textarea.value = jsonString;
            textarea.select();
            document.execCommand("copy");
            document.body.removeChild(textarea);

            console.log("[Price Fix] Copied to clipboard:", jsonString);
          });
        }
      }
    });

    // Observe for button creation
    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    // Stop observing after 10 seconds
    setTimeout(() => observer.disconnect(), 10000);
  }

  // Run when page loads
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", patchCopyDataButton);
  } else {
    patchCopyDataButton();
  }
})();
