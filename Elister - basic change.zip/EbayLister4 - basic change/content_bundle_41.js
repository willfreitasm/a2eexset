function _0x45d2e0() {
  return new Promise((_0x3100d0) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x3100d0();
      });
    });
  });
}
function _0x57f921() {
  return new Promise((_0x22bd63) => {
    requestIdleCallback(() => {
      _0x22bd63();
    });
  });
}
function _0x57b893(_0x4ca91d = 0x3e8) {
  return new Promise((_0x232188, _0x2e2591) => {
    let _0x939c30,
      _0x34cf4f = Date["now"](),
      _0x4a09fe = !0x1;
    function _0x5121d3() {
      if (Date["now"]() - _0x34cf4f > _0x4ca91d)
        (_0x4a09fe && _0x939c30["disconnect"](), _0x232188());
      else setTimeout(_0x5121d3, _0x4ca91d);
    }
    const _0x33b5a8 = () => {
        _0x34cf4f = Date["now"]();
      },
      _0x356272 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x939c30 = new MutationObserver(_0x33b5a8)),
        _0x939c30["observe"](document["body"], _0x356272),
        (_0x4a09fe = !0x0),
        setTimeout(_0x5121d3, _0x4ca91d));
    else
      window["onload"] = () => {
        ((_0x939c30 = new MutationObserver(_0x33b5a8)),
          _0x939c30["observe"](document["body"], _0x356272),
          (_0x4a09fe = !0x0),
          setTimeout(_0x5121d3, _0x4ca91d));
      };
  });
}
async function _0x11d202() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x57b893(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x27e6ef() {
  return await new Promise(function (_0x19c5bf, _0x5030f0) {
    chrome["runtime"]["sendMessage"](
      { type: "checkMembership" },
      function (_0x39f084) {
        (console["log"]("result:\x20", _0x39f084["membership"]),
          _0x19c5bf(_0x39f084["membership"]));
      },
    );
  });
}
async function _0x3106b2() {
  return await new Promise(function (_0x6b01c9, _0x2c1862) {
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x259887) {
        (console["log"]("result:\x20", _0x259887["creditsAvailable"]),
          _0x6b01c9(_0x259887["creditsAvailable"]));
      },
    );
  });
}
async function _0x2f0ce9(_0x597ce7) {
  if ("ultimate" != (await _0x27e6ef()))
    return {
      success: !0x1,
      message:
        "You\x20must\x20be\x20an\x20Ultimate\x20member\x20to\x20use\x20this\x20feature.",
    };
  if (0x0 == (await _0x3106b2()))
    return {
      success: !0x1,
      message: "You\x20have\x20no\x20credits\x20available.",
    };
  return (
    chrome["runtime"]["sendMessage"]({ type: "deductCredits", amount: 0 }),
    { success: !0x0, message: "Credits\x20deducted." }
  );
}
function _0x2749e8(
  _0x4487bc = null,
  _0x463e36 = null,
  _0x3840d5 = null,
  _0x4d4b6a = null,
) {
  var _0x33cf0d = document["createElement"]("a");
  (_0x33cf0d["setAttribute"]("class", "a-link-text"),
    _0x33cf0d["classList"]["add"]("icon"),
    _0x33cf0d["classList"]["add"]("amazonSearchLink"),
    _0x33cf0d["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x26411a = document["createElement"]("img");
  return (
    _0x26411a["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x26411a["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x33cf0d["appendChild"](_0x26411a),
    _0x33cf0d["addEventListener"]("click", async function (_0xb518b4) {
      (_0xb518b4["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x4487bc) {
        var _0x13b79a = _0x27cb18(_0xb518b4);
        if (!_0x13b79a) return;
        var _0x13b8eb = extractItemData(_0x13b79a);
        ((_0x4487bc = _0x13b8eb["title"])["endsWith"]("...") &&
          (_0x4487bc = _0x4487bc["substring"](
            0x0,
            _0x4487bc["lastIndexOf"]("\x20"),
          )),
          _0x4487bc["length"] > 0x4b &&
            (_0x4487bc = _0x4487bc["substring"](
              0x0,
              _0x4487bc["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x1819de } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x1819de),
        _0x1819de || (_0x1819de = "reviews"),
        console["log"]("amazonSortType", _0x1819de),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x225196 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x4487bc["length"] > 0x50; )
        _0x4487bc = _0x4487bc["substring"](
          0x0,
          _0x4487bc["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x298256 } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x3ac2d0 = _0x4487bc;
      "keywords" == _0x298256 && (_0x3ac2d0 = await _0x415dc7(_0x4487bc));
      try {
        _0x13b8eb = extractItemData(_0x13b79a);
      } catch (_0x4c860a) {
        console["log"]("error", _0x4c860a);
      }
      (_0x13b8eb ||
        (_0x13b8eb = {
          title: _0x4487bc,
          price: _0x463e36,
          itemNumber: _0x3840d5,
          image: _0x4d4b6a,
        }),
        console["log"]("itemData", _0x13b8eb),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x3ac2d0,
          options: { isTabActive: !0x0, sort: _0x1819de },
          itemData: _0x13b8eb,
        }));
    }),
    _0x33cf0d
  );
}
function _0x32aec5(_0x4622b5) {
  var _0xf3b451 = document["createElement"]("a");
  (_0xf3b451["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0xf3b451["setAttribute"]("class", "a-link-text"),
    _0xf3b451["classList"]["add"]("icon"),
    _0xf3b451["classList"]["add"]("amazonSearchLink"),
    _0xf3b451["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x16c6f1 = document["createElement"]("img");
  return (
    _0x16c6f1["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x16c6f1["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xf3b451["appendChild"](_0x16c6f1),
    _0xf3b451["addEventListener"]("click", async function (_0x4c79bd) {
      (_0x4c79bd["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x4622b5),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x4622b5,
        }));
    }),
    _0xf3b451
  );
}
function _0x53f245(_0x4a3530) {
  var _0x248ee5 = document["createElement"]("a");
  (_0x248ee5["setAttribute"]("id", "amazonLink"),
    _0x248ee5["setAttribute"]("class", "a-link-text"),
    _0x248ee5["classList"]["add"]("icon"),
    _0x248ee5["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x4a2978 = document["createElement"]("img");
  return (
    _0x4a2978["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x4a2978["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x248ee5["appendChild"](_0x4a2978),
    _0x248ee5["addEventListener"]("click", async function (_0x5288b6) {
      (_0x5288b6["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x50104d } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x1d3c06 =
          "https://www.amazon." +
          _0x50104d +
          "/dp/" +
          _0x4a3530 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x1d3c06 });
    }),
    _0x248ee5
  );
}
function _0x56921a(_0x559591) {
  var _0x18f0f3 = document["createElement"]("a");
  (_0x18f0f3["setAttribute"]("id", "amazonLink"),
    _0x18f0f3["setAttribute"]("class", "a-link-text"),
    _0x18f0f3["classList"]["add"]("icon"),
    _0x18f0f3["classList"]["add"]("amazonLink"),
    _0x18f0f3["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x58f2bd = document["createElement"]("img");
  return (
    _0x58f2bd["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x58f2bd["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x18f0f3["appendChild"](_0x58f2bd),
    _0x18f0f3["addEventListener"]("click", async function (_0x29d039) {
      (_0x29d039["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x559591(_0x29d039);
      } catch (_0x90edaf) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x90edaf);
      }
    }),
    _0x18f0f3
  );
}
function _0x37c4aa(
  _0x53f538 = null,
  _0x31528f,
  _0x3fdc5b = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x53f538, _0x31528f);
  var _0x12740f = document["createElement"]("a");
  (_0x12740f["setAttribute"]("id", "ebayLink"),
    _0x12740f["setAttribute"]("class", "a-link-text"),
    _0x12740f["classList"]["add"]("icon"),
    _0x31528f && _0x31528f["soldItems"]
      ? _0x12740f["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x12740f["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x552f13 = document["createElement"]("img");
  return (
    _0x552f13["setAttribute"]("src", chrome["runtime"]["getURL"](_0x3fdc5b)),
    _0x552f13["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x12740f["appendChild"](_0x552f13),
    _0x12740f["addEventListener"]("click", async function (_0x5a423e) {
      (_0x5a423e["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x53f538) console["log"]("title\x20found", _0x53f538);
      else {
        console["log"]("title\x20not\x20found");
        var _0x2dc032 = _0x27cb18(_0x5a423e);
        if (!_0x2dc032) return;
        var _0x2a2609 = extractItemData(_0x2dc032);
        _0x53f538 = _0x2a2609["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x1857c9 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x53f538["length"] > 0x50; )
        _0x53f538 = _0x53f538["substring"](
          0x0,
          _0x53f538["lastIndexOf"]("\x20"),
        );
      var _0x2ad1f8 =
        "https://www.ebay." +
        _0x1857c9 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x53f538) +
        "&_odkw=" +
        encodeURIComponent(_0x53f538);
      (_0x31528f && _0x31528f["soldItems"] && (_0x2ad1f8 += "&LH_Sold=1"),
        _0x31528f && _0x31528f["sortLowToHigh"] && (_0x2ad1f8 += "&_sop=15"),
        _0x31528f && _0x31528f["endedRecently"] && (_0x2ad1f8 += "&_sop=13"),
        (_0x2ad1f8 += "&LH_ItemCondition=1000"),
        (_0x2ad1f8 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x2ad1f8,
        }));
    }),
    _0x12740f
  );
}
function _0x177d9d(_0x273414 = null) {
  var _0x272b22 = document["createElement"]("a");
  (_0x272b22["setAttribute"]("id", "googleLink"),
    _0x272b22["setAttribute"]("class", "a-link-text"),
    _0x272b22["classList"]["add"]("icon"),
    _0x272b22["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x35bcf9 = document["createElement"]("img");
  return (
    _0x35bcf9["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x35bcf9["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x272b22["appendChild"](_0x35bcf9),
    _0x272b22["addEventListener"]("click", async function (_0x1240aa) {
      (_0x1240aa["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x273414) {
        var _0x5257c4 = _0x27cb18(_0x1240aa);
        if (!_0x5257c4) return;
        var _0x262a57 = extractItemData(_0x5257c4);
        _0x273414 = _0x262a57["image"];
      }
      var { domain: _0x3b0a18 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x71d5fb(_0x3b0a18),
        encodeURIComponent(_0x273414),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x273414,
        }));
    }),
    _0x272b22
  );
}
function _0x186900(_0x1fa8a2 = null) {
  var _0x33d6ec = document["createElement"]("a");
  (_0x33d6ec["setAttribute"]("id", "googleLink"),
    _0x33d6ec["setAttribute"]("class", "a-link-text"),
    _0x33d6ec["classList"]["add"]("icon"),
    _0x33d6ec["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x42e7c4 = document["createElement"]("img");
  return (
    _0x42e7c4["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x42e7c4["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x33d6ec["appendChild"](_0x42e7c4),
    _0x33d6ec["addEventListener"]("click", async function (_0x4fb6b7) {
      (_0x4fb6b7["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x1fa8a2) {
        var _0x442f6a = _0x27cb18(_0x4fb6b7);
        if (!_0x442f6a) return;
        var _0x1c04fa = extractItemData(_0x442f6a);
        _0x1fa8a2 = _0x1c04fa["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x1fa8a2,
      });
    }),
    _0x33d6ec
  );
}
function _0x17676a(_0x95eda1) {
  var _0x1c62c2 = document["createElement"]("a");
  (_0x1c62c2["setAttribute"]("id", "lookUpSkuLink"),
    _0x1c62c2["setAttribute"]("class", "a-link-text"),
    _0x1c62c2["classList"]["add"]("icon"),
    _0x1c62c2["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0xc711f7 = document["createElement"]("img");
  return (
    _0xc711f7["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0xc711f7["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1c62c2["appendChild"](_0xc711f7),
    _0x1c62c2["addEventListener"]("click", async function (_0x404a16) {
      (_0x404a16["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x2c10cd } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x26cb09 =
          "https://www.amazon." +
          _0x2c10cd +
          "/dp/" +
          _0x95eda1 +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x26cb09,
        options: { active: !0x0 },
      });
    }),
    _0x1c62c2
  );
}
function _0x5e9a41(_0x4ee495 = null) {
  var _0x4416a2 = document["createElement"]("a");
  (_0x4416a2["setAttribute"]("id", "productHunterLink"),
    _0x4416a2["setAttribute"]("class", "a-link-text"),
    _0x4416a2["classList"]["add"]("icon"),
    _0x4416a2["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0xa5d0a0 = document["createElement"]("img");
  return (
    _0xa5d0a0["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0xa5d0a0["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4416a2["appendChild"](_0xa5d0a0),
    _0x4416a2["addEventListener"]("click", async function (_0x5a8902) {
      (_0x5a8902["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x4ee495) {
        var _0xc2e049 = _0x27cb18(_0x5a8902);
        if (!_0xc2e049) return;
        var _0x452c0b = extractItemData(_0xc2e049);
        _0x4ee495 = _0x452c0b["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x4ee495),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x4ee495,
        }));
    }),
    _0x4416a2
  );
}
function _0x71d5fb(_0x3ec69a) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x3ec69a] || "en-US";
}
function _0x2f538e(_0x383ed0 = null) {
  console["log"]("createSearchTerapeakButton", _0x383ed0);
  var _0x2cba66 = document["createElement"]("a");
  (_0x2cba66["setAttribute"]("class", "a-link-text"),
    _0x2cba66["classList"]["add"]("terapeakLink"),
    _0x2cba66["classList"]["add"]("icon"),
    _0x2cba66["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x383ed0 && _0x2cba66["setAttribute"]("item_title", _0x383ed0));
  var _0x1b9486 = document["createElement"]("img");
  return (
    _0x1b9486["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x1b9486["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2cba66["appendChild"](_0x1b9486),
    _0x2cba66["addEventListener"]("click", async function (_0x7dbab9) {
      (_0x7dbab9["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x34bf94 = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x34bf94),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x34bf94) {
        var _0x445acb = _0x27cb18(_0x7dbab9);
        if (!_0x445acb) return;
        _0x34bf94 = extractItemData(_0x445acb)["title"];
      }
      console["log"]("title", _0x34bf94);
      var { convertToKeywords: _0x2769ac } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x2769ac) var _0x34bf94 = await _0x415dc7(_0x34bf94);
      var { domain: _0x24c13e } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x11998d = _0x5839cb(_0x34bf94, _0x24c13e);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x11998d });
    }),
    _0x2cba66
  );
}
async function _0x415dc7(_0x1f990f) {
  var _0x4d8736 = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x587069) => _0x587069["json"]());
  ((_0x4d8736["user_input"] = _0x1f990f),
    console["log"]("jsonPrompt", _0x4d8736));
  var _0x49cab1 = await new Promise((_0x4fc0e4, _0x538f07) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x4d8736,
      },
      function (_0x45212b) {
        _0x4fc0e4(_0x45212b["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x49cab1),
    (_0x49cab1 = JSON["parse"](_0x49cab1))["output"]
  );
}
function _0x5839cb(
  _0x3183ce,
  _0x22af05 = "ca",
  _0x10d8ce = 0x1e,
  _0x4387a3 = 0x0,
  _0xcbd02e = 0x0,
  _0xf1b3d9 = 0x32,
  _0x11a724 = "-itemssold",
  _0x54bf13 = "SOLD",
  _0x89955c = "EBAY-CA",
  _0x56542b = "America/Toronto",
  _0x346e92 = "BuyerLocation:::CA",
  _0x1a33c9 = 0x0,
) {
  _0x89955c = "";
  switch (_0x22af05) {
    case "ca":
    default:
      _0x89955c = "EBAY-CA";
      break;
    case "com":
      _0x89955c = "EBAY-US";
      break;
    case "co.uk":
      _0x89955c = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x22af05 +
    "/sh/research?" +
    [
      "keywords=" + _0x3183ce,
      "dayRange=" + _0x10d8ce,
      "categoryId=" + _0x4387a3,
      "offset=" + _0xcbd02e,
      "limit=" + _0xf1b3d9,
      "sorting=" + _0x11a724,
      "tabName=" + _0x54bf13,
      "marketplace=" + _0x89955c,
      "tz=" + encodeURIComponent(_0x56542b),
      "minPrice=" + _0x1a33c9,
    ]["join"]("&")
  );
}
async function _0xe8b96(_0x4fed70) {
  var { domain: _0x30cd1b } = await chrome["storage"]["local"]["get"]("domain"),
    _0x1dc2db =
      "https://www.ebay." +
      _0x30cd1b +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x4fed70 +
      "&store_name=" +
      _0x4fed70 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x1dc2db });
}
async function _0x1ffd32(_0x17e46a) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x17e46a,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x17e46a));
}
async function _0x4463c5(_0x3c1677) {
  var { response: _0x37334a } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x3c1677,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x37334a), _0x37334a);
}
function _0x23225a(_0xe7bedd = null) {
  console["log"]("createOpenSellerItemsButton", _0xe7bedd);
  var _0xb5834a = document["createElement"]("a");
  (_0xb5834a["setAttribute"]("id", "sellerItemsLink"),
    _0xb5834a["setAttribute"]("class", "a-link-text"),
    _0xb5834a["classList"]["add"]("icon"),
    _0xb5834a["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x1f8ccf = document["createElement"]("img");
  return (
    _0x1f8ccf["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x1f8ccf["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xb5834a["appendChild"](_0x1f8ccf),
    _0xb5834a["addEventListener"]("click", async function (_0x5c0ceb) {
      (_0x5c0ceb["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0xe7bedd),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0xe7bedd));
      var _0x58207e;
      if (!_0xe7bedd) {
        console["log"]("username\x20not\x20found");
        var _0x4faabe = _0x27cb18(_0x5c0ceb);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x4faabe,
        );
        if (!_0x4faabe) return;
        var _0x190e89 = extractItemData(_0x4faabe);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x190e89,
        ),
          (_0xe7bedd = _0x190e89["username"]),
          (_0x58207e = _0x190e89["itemNumber"]));
      }
      if (
        _0xe7bedd["includes"]("\x20") ||
        _0xe7bedd !== _0xe7bedd["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0xe7bedd,
        );
        if (!_0x58207e) {
          if (!(_0x4faabe = _0x27cb18(_0x5c0ceb))) return;
          _0x58207e = (_0x190e89 = extractItemData(_0x4faabe))["itemNumber"];
        }
        _0x1ffd32(_0x58207e);
      } else
        ((_0xe7bedd = _0xe7bedd["toLowerCase"]()),
          console["log"]("username", _0xe7bedd),
          _0xe8b96(_0xe7bedd));
    }),
    _0xb5834a
  );
}
function _0x121194(_0x3a61b3) {
  for (
    ;
    _0x3a61b3 &&
    !_0x3a61b3["classList"]["contains"]("s-item") &&
    !_0x3a61b3["classList"]["contains"]("su-card-container");

  )
    _0x3a61b3 = _0x3a61b3["parentElement"];
  return _0x3a61b3;
}
function _0x9ce70c(_0xaa913d = null) {
  var _0x331308 = document["createElement"]("a");
  (_0x331308["setAttribute"]("id", "purchaseHistoryLink"),
    _0x331308["setAttribute"]("class", "a-link-text"),
    _0x331308["classList"]["add"]("icon"),
    _0x331308["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x1baa80 = document["createElement"]("img");
  return (
    _0x1baa80["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x1baa80["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x331308["appendChild"](_0x1baa80),
    _0x331308["addEventListener"]("click", async function (_0x50d732) {
      (console["log"]("createCheckPurchaseHistoryButton", _0xaa913d),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x50d732["preventDefault"]());
      var _0x3b7d98 = _0x27cb18(_0x50d732);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x3b7d98,
      );
      if (_0x3b7d98) {
        var { selectedFilter: _0x30b9b8 } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x30b9b8 &&
          ((_0x30b9b8 = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x30b9b8,
          }));
        var _0x100a8d = _0x30b9b8,
          _0x54ede0 = await checkPurchaseHistoryAndAddToItem(
            _0x3b7d98,
            _0x100a8d,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x54ede0);
      } else
        try {
          var _0x383fb7 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0xaa913d,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x383fb7),
            (_0x54ede0 = _0x383fb7["totalSold"]));
        } catch (_0xb20dd5) {
          (console["log"]("error", _0xb20dd5), (_0x54ede0 = -0x3e7));
        }
    }),
    _0x331308
  );
}
function _0x27cb18(_0x1ec751) {
  var _0x3a1a94 = _0x1ec751["target"];
  return (
    (_0x3a1a94 = _0x121194(_0x3a1a94)),
    console["log"]("found\x20s-item", _0x3a1a94),
    _0x3a1a94
  );
}
function _0x3a7a65(_0x554df9 = null, _0x1624fb = null, _0x1c4a16 = null) {
  var _0x586eb9 = document["createElement"]("a");
  (_0x586eb9["setAttribute"]("id", "copyDataLink"),
    _0x586eb9["setAttribute"]("class", "a-link-text"),
    _0x586eb9["classList"]["add"]("icon"),
    _0x586eb9["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x431bd8 = document["createElement"]("img");
  return (
    _0x431bd8["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x431bd8["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x586eb9["appendChild"](_0x431bd8),
    _0x586eb9["addEventListener"]("click", async function (_0x2fdd17) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x554df9,
        _0x1624fb,
        _0x1c4a16,
      ),
        _0x2fdd17["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x554df9 && _0x1624fb && _0x1c4a16)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x554df9,
          _0x1624fb,
          _0x1c4a16,
        ),
          isNaN(_0x1624fb) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x1624fb),
            (_0x1624fb = _0x1624fb["replace"](/[^0-9.]/g, ""))),
          _0xa06463(
            JSON["stringify"]({
              title: _0x554df9,
              price: _0x1624fb,
              itemNumber: _0x1c4a16,
            }),
          ));
      else {
        if (!_0x554df9 || !_0x1624fb || !_0x1c4a16) {
          var _0x5e30f7 = _0x27cb18(_0x2fdd17);
          if (!_0x5e30f7) return;
        }
        var _0x24e6ef = extractItemData(_0x5e30f7);
        (console["log"]("itemData", _0x24e6ef),
          _0xa06463(JSON["stringify"](_0x24e6ef)));
      }
    }),
    _0x586eb9
  );
}
function _0xa06463(_0x5d8675) {
  var _0x2fb63d = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x2fb63d),
    (_0x2fb63d["value"] = _0x5d8675),
    _0x2fb63d["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x2fb63d));
}
async function _0x4f2b4e(_0x2a7900 = null) {
  console["log"]("price", _0x2a7900);
  if (_0x2a7900) {
    try {
      _0x2a7900 = _0x2a7900["replace"](/[^0-9.]/g, "");
    } catch (_0xe2b7f3) {}
    _0x2a7900 = parseFloat(_0x2a7900);
  }
  var _0x46868f = await _0x3f07f0(_0x2a7900),
    _0x5f4578 = document["createElement"]("div");
  return (
    _0x5f4578["setAttribute"]("id", "breakEvenPrice"),
    _0x5f4578["setAttribute"]("class", "break-even-price"),
    (_0x5f4578["textContent"] =
      "Break-even\x20price:\x20$" + _0x46868f["toFixed"](0x2)),
    _0x5f4578
  );
}
async function _0xf25cda(_0x258158) {
  var _0x4393fa = !0x1,
    _0x4eb41b = !0x1,
    { includeCurrencyConversion: _0x4eb41b } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x4393fa } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x5d202f =
    0.1325 * _0x258158 +
    0.021 * _0x258158 +
    _0x258158 * (_0x4393fa ? 0.004 : 0x0) +
    0.4;
  return (_0x4eb41b && (_0x5d202f += 0.035 * _0x258158), _0x258158 - _0x5d202f);
}
async function _0x3f07f0(_0x3859c7) {
  var { isInternational: _0xce68c5 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x201bfd } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0xce68c5 || (_0xce68c5 = !0x1), _0x201bfd || (_0x201bfd = !0x0));
  var _0x55417d = 13.25;
  _0x201bfd && (_0x55417d = 12.35);
  var _0x5aca71 = _0x3859c7 + 0.0725 * _0x3859c7,
    _0x1d6b0b =
      _0x5aca71 * (_0x55417d / 0x64) +
      0.4 +
      (_0xce68c5 ? 0.004 * _0x5aca71 : 0x0),
    _0x1943be =
      _0x3859c7 -
      (_0x1d6b0b + (_0xce68c5 ? 0.05 * _0x1d6b0b : 0x0)) -
      (_0xce68c5 ? 0.035 * _0x5aca71 : 0x0),
    { isUserTaxExempt: _0x283736 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x283736 || (_0x283736 = !0x1),
    _0x283736 || (_0x1943be /= 1.0725),
    _0xce68c5 && (_0x1943be -= (3.5 * _0x1943be) / 0x64),
    _0x1943be
  );
}
function _0x31ed41(_0x540c84 = null) {
  console["log"]("createButtonToSaveSeller", _0x540c84);
  var _0x1b7779 = document["createElement"]("a");
  (_0x1b7779["setAttribute"]("id", "saveSellerLink"),
    _0x1b7779["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x1b7779["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x11861b = document["createElement"]("img");
  return (
    _0x11861b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x11861b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1b7779["appendChild"](_0x11861b),
    _0x1b7779["addEventListener"]("click", async function (_0x5984bd) {
      (_0x5984bd["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x540c84));
      var _0x43afa0;
      if (!_0x540c84) {
        var _0x13d3ec = _0x27cb18(_0x5984bd);
        if (!_0x13d3ec) return;
        var _0x1a4efd = extractItemData(_0x13d3ec);
        ((_0x540c84 = _0x1a4efd["username"]),
          (_0x43afa0 = _0x1a4efd["itemNumber"]));
      }
      if (
        _0x540c84["includes"]("\x20") ||
        _0x540c84 !== _0x540c84["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x540c84,
        ),
          (_0x540c84 = await _0x4463c5(_0x43afa0)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x540c84,
          ));
      else _0x540c84 = _0x540c84["toLowerCase"]();
      _0x1b7779["setAttribute"]("data-seller-name", _0x540c84);
      var { ebayCompetitors: _0x5eb2b0 } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x53cb32 = (_0x5eb2b0 = _0x5eb2b0 || [])["indexOf"](_0x540c84);
      console["log"]("ebayCompetitors", _0x5eb2b0);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x53cb32
            ? (console["log"]("save-seller\x20clicked\x20username", _0x540c84),
              _0x5eb2b0["push"](_0x540c84),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x11861b["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x540c84,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x11861b["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x53cb32)
            (console["log"]("remove-seller\x20clicked\x20username", _0x540c84),
              _0x5eb2b0["splice"](_0x53cb32, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x11861b["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x540c84,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x5eb2b0 });
    }),
    _0x1b7779
  );
}
async function _0x3e7674(_0x59566d, _0x371ad7) {
  var { ebayCompetitors: _0x163b63 } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x38d95a = (_0x163b63 = _0x163b63 || [])["indexOf"](_0x371ad7),
    _0x93635d = _0x59566d["querySelector"]("img");
  -0x1 !== _0x38d95a
    ? (_0x59566d["classList"]["replace"]("save-seller", "remove-seller"),
      _0x93635d["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x59566d["classList"]["replace"]("remove-seller", "save-seller"),
      _0x93635d["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0xb20eb5(
  _0x192ccd = null,
  _0x4e5205 = null,
  _0x26e49d = null,
  _0x596ac5 = !0x0,
  _0x58cd40 = null,
  _0x5776a4 = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x192ccd));
  var _0xdc7f6 = _0x31ed41(_0x4e5205),
    _0x3ba367 = _0x2f538e(_0x192ccd),
    _0x3faca8 = _0x9ce70c(_0x58cd40),
    _0x3f1a49 = _0x37c4aa(_0x192ccd),
    _0x2c8118 = _0x2749e8(_0x192ccd, _0x5776a4, _0x58cd40, _0x26e49d),
    _0x32ce63 = _0x37c4aa(
      _0x192ccd,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x5874e7 = _0x177d9d(_0x26e49d),
    _0x47cadb = _0x186900(_0x58cd40),
    _0x33af49 = _0x23225a(_0x4e5205),
    _0x38db60 = document["createElement"]("div");
  _0x38db60["setAttribute"]("id", "search-div");
  var _0x32ea5a = document["createElement"]("label");
  ((_0x32ea5a["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x38db60["appendChild"](_0x32ea5a),
    _0x38db60["appendChild"](_0x2c8118),
    _0x38db60["appendChild"](_0x3f1a49),
    _0x38db60["appendChild"](_0x3ba367),
    _0x38db60["appendChild"](_0x5874e7),
    _0x38db60["appendChild"](_0x47cadb),
    _0x38db60["appendChild"](_0x32ce63),
    console["log"]("CopyDataButton", _0x192ccd, _0x5776a4, _0x58cd40));
  var _0x2e7909 = _0x3a7a65(_0x192ccd, _0x5776a4, _0x58cd40),
    _0x251803 = document["createElement"]("div");
  _0x251803["setAttribute"]("id", "item-buttons-div");
  var _0x475bb6 = document["createElement"]("div");
  (_0x475bb6["setAttribute"]("id", "main-buttons-div"),
    _0x475bb6["appendChild"](_0x33af49),
    _0x475bb6["appendChild"](_0x3faca8),
    _0x475bb6["appendChild"](_0x2e7909),
    _0x475bb6["appendChild"](_0xdc7f6),
    _0x251803["appendChild"](_0x475bb6));
  if (_0x596ac5) {
    var _0x40d08b = createButtonListToEbay();
    _0x251803["appendChild"](_0x40d08b);
  }
  return (_0x251803["appendChild"](_0x38db60), _0x251803);
}
var _0x5bad8a = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x11f182) => {
        (console["log"](
          _0x11f182,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x5bad8a, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x1bec5f) => {
        (console["log"](
          _0x1bec5f,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x5bad8a, "search-type", "keywords"));
      },
    },
  },
];
async function _0x236fe9() {
  var { convertToKeywords: _0x432bff } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x432bff &&
    ((_0x432bff = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x5bad8a,
      "search-type",
      _0x432bff ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x5bad8a })[
      "init"
    ]());
}
var _0x121e7a = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x4c3a4b) => {
        (console["log"](_0x4c3a4b, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x121e7a, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x4b1272) => {
        (console["log"](_0x4b1272, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x121e7a, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x31e86d) => {
        (console["log"](
          _0x31e86d,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x121e7a, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x4a675f) => {
        (console["log"](
          _0x4a675f,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x121e7a, "search-type", "keywords"));
      },
    },
  },
];
async function _0x1f48c1() {
  var { amazonSortType: _0x337987 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x20927c } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x20927c &&
    ((_0x20927c = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x337987 &&
      ((_0x337987 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x121e7a, "sort-type", _0x337987),
    updateContextMenu(_0x121e7a, "search-type", _0x20927c),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x121e7a })[
      "init"
    ]());
}
_0x121e7a = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x43e76b) => {
        (console["log"](_0x43e76b, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x121e7a, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x1f24f2) => {
        (console["log"](_0x1f24f2, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x121e7a, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x4b2c55 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x45a41d) => {
        (console["log"](_0x45a41d, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0x4b2c55, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x4bd357) => {
        (console["log"](_0x4bd357, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0x4b2c55, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2e5dff) => {
        (console["log"](_0x2e5dff, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0x4b2c55, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x335121) => {
        (console["log"](_0x335121, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0x4b2c55, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x4759f9) => {
        (console["log"](_0x4759f9, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0x4b2c55, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0xbc2724) => {
        (console["log"](_0xbc2724, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0x4b2c55, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x14c528) => {
        (console["log"](_0x14c528, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0x4b2c55, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3c5665) => {
        (console["log"](_0x3c5665, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0x4b2c55, "filter-type", "90"));
      },
    },
  },
];
async function _0x4ce20c() {
  var { selectedFilter: _0x5f0dce } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x5f0dce &&
    ((_0x5f0dce = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0x4b2c55, "filter-type", _0x5f0dce),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0x4b2c55 })[
      "init"
    ]());
}
function _0x5cd3a8() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x306b61() {
  const _0xce6672 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x4eb825 = 0x0;
  const _0x25e90f = () =>
    new Promise((_0x1b67bc, _0x5730df) => {
      const _0x4eab96 = new MutationObserver((_0x4d59ed, _0x2afdc0) => {
        const _0x4774fb = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x4774fb &&
          (console["log"]("Details\x20form\x20found!"),
          _0x2afdc0["disconnect"](),
          _0x1b67bc(_0x4774fb));
      });
      (_0x4eab96["observe"](_0xce6672, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x4eab96["disconnect"]();
          if (_0x4eb825 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x4eb825 + 0x1) +
                "/3)",
            ),
              _0x4eb825++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x1b67bc(_0x25e90f()), 0x1388));
          else
            _0x5730df(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0xfd319b = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0xfd319b) {
    (_0xfd319b["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x25e90f(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0xb953b9) {
      console["error"](_0xb953b9["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x398686(_0x4037cf = null, _0x1660d6 = null, _0x28f0bf = null) {
  var _0x5a6ffc = document["createElement"]("a");
  (_0x5a6ffc["setAttribute"]("id", "copyDataLink"),
    _0x5a6ffc["setAttribute"]("class", "a-link-text"),
    _0x5a6ffc["classList"]["add"]("icon"),
    _0x5a6ffc["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x55844b = document["createElement"]("img");
  return (
    _0x55844b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x55844b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5a6ffc["appendChild"](_0x55844b),
    _0x5a6ffc["addEventListener"]("click", async function (_0x2ba40b) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x4037cf,
        _0x1660d6,
        _0x28f0bf,
      ),
        _0x2ba40b["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x4037cf && _0x1660d6 && _0x28f0bf) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x4037cf,
          _0x1660d6,
          _0x28f0bf,
        );
        isNaN(_0x1660d6) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x1660d6),
          (_0x1660d6 = _0x1660d6["replace"](/[^0-9.]/g, "")));
        var _0x57ec65 = JSON["stringify"]({
          title: _0x4037cf,
          price: _0x1660d6,
          itemNumber: _0x28f0bf,
        });
        (_0x32a8ce(
          (_0x1f8d86 = await findSimiliarProducts(_0x57ec65))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x1f8d86),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x4037cf || !_0x1660d6 || !_0x28f0bf) {
          var _0x229bb0 = _0x27cb18(_0x2ba40b);
          if (!_0x229bb0) return;
        }
        var _0x12d530 = extractItemData(_0x229bb0);
        (console["log"]("itemData", _0x12d530),
          (_0x57ec65 = JSON["stringify"](_0x12d530)));
        var _0x1f8d86;
        (_0x32a8ce(
          (_0x1f8d86 = await findSimiliarProducts(_0x57ec65))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x1f8d86),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x5a6ffc
  );
}
async function findSimiliarProducts(_0x440bc5) {
  console["log"]("findSimiliarProducts", _0x440bc5);
  var _0x4436b3 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x440bc5,
  });
  return (console["log"]("response", _0x4436b3), _0x4436b3["productLinks"]);
}
function _0x32a8ce(_0x2cbb2e) {
  const _0x5c589b = document["getElementById"]("productLinksModalOverlay");
  _0x5c589b && _0x5c589b["remove"]();
  const _0x3b0263 = document["createElement"]("div");
  ((_0x3b0263["id"] = "productLinksModalOverlay"),
    _0x3b0263["classList"]["add"]("product-links-modal-overlay"));
  const _0x5cfc07 = document["createElement"]("div");
  _0x5cfc07["classList"]["add"]("product-links-modal");
  const _0x4516d9 = document["createElement"]("div");
  _0x4516d9["classList"]["add"]("modal-button-container");
  const _0x3d9af9 = document["createElement"]("button");
  (_0x3d9af9["classList"]["add"]("close-button"),
    (_0x3d9af9["innerText"] = "Close"),
    _0x3d9af9["addEventListener"]("click", () => {
      _0x3b0263["remove"]();
    }));
  const _0x812a7a = document["createElement"]("button");
  (_0x812a7a["classList"]["add"]("copy-button"),
    (_0x812a7a["innerText"] = "Copy"),
    _0x812a7a["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x2cbb2e),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x2bd882) {
        console["error"]("Failed\x20to\x20copy:", _0x2bd882);
      }
    }));
  const _0x48ac37 = document["createElement"]("h2");
  _0x48ac37["innerText"] = "Similar\x20Product\x20Links";
  const _0x2e084e = document["createElement"]("textarea");
  ((_0x2e084e["value"] = _0x2cbb2e),
    _0x2e084e["setAttribute"]("readonly", !0x0),
    (_0x2e084e["style"]["width"] = "100%"),
    (_0x2e084e["style"]["height"] = "300px"),
    _0x4516d9["appendChild"](_0x812a7a),
    _0x4516d9["appendChild"](_0x3d9af9),
    _0x5cfc07["appendChild"](_0x4516d9),
    _0x5cfc07["appendChild"](_0x48ac37),
    _0x5cfc07["appendChild"](_0x2e084e),
    _0x3b0263["appendChild"](_0x5cfc07),
    document["body"]["appendChild"](_0x3b0263));
}
console["log"]("ebay_tracking_functions.js\x20loaded");
function scrollToIndex(_0x568519) {
  (_0x568519["classList"]["add"]("highlighted"),
    Array["prototype"]["filter"]
      ["call"](_0x568519["parentNode"]["children"], function (_0x56ed9d) {
        return _0x56ed9d !== _0x568519;
      })
      ["forEach"](function (_0xee7d39) {
        _0xee7d39["classList"]["remove"]("highlighted");
      }),
    _0x568519["scrollIntoView"]({ block: "center" }));
}
function _0x3ffbe0(_0x1c2e5a) {
  var _0x367639 = !0x1;
  return (
    _0x1c2e5a["querySelectorAll"](".inline-notice__header")["length"] > 0x0 &&
      (_0x367639 = !0x0),
    _0x367639
  );
}
async function _0x38c34f(_0x3867af) {
  _0x3867af["style"]["backgroundColor"] = "#fc95ab";
  var _0x2e4fd1 = fetchEbayData(_0x3867af),
    _0x1f9c8c = await new Promise((_0x2072ae) => {
      chrome["runtime"]["sendMessage"](
        { type: "endItem", ebayData: _0x2e4fd1 },
        function (_0x311fc8) {
          (console["log"](_0x311fc8), _0x2072ae(_0x311fc8));
        },
      );
    });
  return (console["log"]("Response\x20received", _0x1f9c8c), _0x1f9c8c);
}
async function _0x5b9b6d(_0x91b617) {
  return "amazon";
}
async function fetchAmazonData(_0x3df71f) {
  var { domain: _0xab6d6b } = await chrome["storage"]["local"]["get"]("domain"),
    _0x40b84a =
      "https://www.amazon." + _0xab6d6b + "/dp/" + _0x3df71f + "/?th=1&psc=1",
    { amazonData: _0x49e906 } = await new Promise((_0x528791) => {
      chrome["runtime"]["sendMessage"](
        { type: "fetch_amazon_data", url: _0x40b84a },
        function (_0x43dba6) {
          _0x528791(_0x43dba6);
        },
      );
    });
  return (console["log"]("amazonData", _0x49e906), _0x49e906);
}
async function _0x1bc471(_0x344e18, _0x101cee) {
  var _0x116fdf;
  if ("amazon" === _0x101cee)
    try {
      _0x116fdf = atob(_0x344e18);
    } catch (_0x476059) {
      return (console["error"](_0x476059), null);
    }
  return _0x116fdf;
}
async function fetchSupplierItemData(_0x37d3f8, _0x2b956c) {
  if ("amazon" === _0x2b956c) return await fetchAmazonData(_0x37d3f8);
}
async function _0x1670c2() {
  const {
    priceVariation: _0x38a99e,
    desiredPriceEnding: _0x268162,
    markupPrice: _0x57c653,
  } = await chrome["storage"]["local"]["get"]([
    "priceVariation",
    "desiredPriceEnding",
    "markupPrice",
  ]);
  return {
    priceVariation: Number(_0x38a99e),
    desiredPriceEnding: Number(_0x268162),
    markupPercentage: Number(_0x57c653),
  };
}
function _0x34fda6(_0x1f2131, _0x27905a) {
  return parseFloat((_0x1f2131 * (0x1 + _0x27905a / 0x64))["toFixed"](0x2));
}
async function _0x358d00(_0x2a70e7, _0xdead96) {
  var _0x1593ea = document["createElement"]("li");
  if ("amazonItemUrl" === _0x2a70e7)
    _0x1593ea["innerHTML"] =
      _0x2a70e7 +
      ":\x20<a\x20href=\x22" +
      _0xdead96[_0x2a70e7] +
      "\x22\x20target=\x22_blank\x22>" +
      _0xdead96[_0x2a70e7] +
      "</a>";
  else {
    if ("isItemAvailable" === _0x2a70e7 || "isEligibleForPrime" === _0x2a70e7)
      ((_0x1593ea["innerHTML"] = _0x2a70e7 + ":\x20" + _0xdead96[_0x2a70e7]),
        (_0x1593ea["style"]["color"] = _0xdead96[_0x2a70e7] ? "green" : "red"));
    else {
      if ("price" === _0x2a70e7) {
        const _0x16d25d = await _0x1670c2();
        var _0x30038b = parseFloat(_0xdead96[_0x2a70e7]);
        console["log"]("\x20generateListItem\x20azmazonPrice", _0x30038b);
        var _0x570131 = _0x34fda6(_0x30038b, _0x16d25d["markupPercentage"]);
        _0x1593ea["innerHTML"] =
          _0x2a70e7 +
          ":\x20" +
          _0xdead96[_0x2a70e7] +
          "\x20<br>\x20Markup\x20Percentage:\x20" +
          _0x16d25d["markupPercentage"] +
          "\x20<br>\x20Markup\x20Price:\x20" +
          _0x570131;
      } else
        _0x1593ea["innerHTML"] = _0x2a70e7 + ":\x20" + _0xdead96[_0x2a70e7];
    }
  }
  return _0x1593ea;
}
async function _0x26a18a(_0x51532b, _0x419d41) {
  var _0x322032 = _0x51532b["firstElementChild"]["querySelector"](
      "td[class*=\x22title\x22]",
    ),
    _0x20ee12 = document["createElement"]("div");
  _0x20ee12["classList"]["add"]("amazon-item-box");
  var _0x1b427f = document["createElement"]("h3");
  ((_0x1b427f["innerHTML"] = "Amazon\x20Item"),
    _0x20ee12["appendChild"](_0x1b427f));
  var _0x42fff5 = document["createElement"]("ul");
  for (var _0x2f1730 in _0x419d41)
    if (
      !["deliveryTimeMessage", "isItemDeliveryExtended", "isItemCorrectUrl"][
        "includes"
      ](_0x2f1730)
    ) {
      var _0x5cc137 = await _0x358d00(_0x2f1730, _0x419d41);
      _0x42fff5["appendChild"](_0x5cc137);
    }
  (_0x20ee12["appendChild"](_0x42fff5), _0x322032["appendChild"](_0x20ee12));
}
async function _0x17a54e(_0x4b58bc) {
  if (_0x4b58bc) {
    (_0x4b58bc["querySelector"](".grid-row")["getAttribute"]("data-id"),
      console["log"]("itemNode", _0x4b58bc),
      (_0x4b58bc["style"]["backgroundColor"] = "#FFE15175"),
      scrollToIndex(_0x4b58bc));
    var _0x2a6230 = fetchEbayData(_0x4b58bc);
    console["log"]("ebayItemData", _0x2a6230);
    var { enable_set_gspr: _0x481c38 } =
      await chrome["storage"]["local"]["get"]("enable_set_gspr");
    if (_0x481c38 && _0x481c38["checkbox"]) {
      var { failedGsprItems: _0x2767e4 } =
        await chrome["storage"]["local"]["get"]("failedGsprItems");
      _0x2767e4 || (_0x2767e4 = []);
      if (!_0x2a6230["customLabel"]) {
        (console["log"]("custom\x20label\x20not\x20found"),
          await _0x552131(_0x2a6230, "Custom\x20label\x20not\x20found"),
          _0x2767e4["push"](_0x2a6230["itemNumber"]),
          await chrome["storage"]["local"]["set"]({
            failedGsprItems: _0x2767e4,
          }));
        return;
      }
      if (_0x3ffbe0(_0x4b58bc)) {
        (console["log"]("Policy\x20violation\x20exists"),
          await _0x552131(_0x2a6230, "Policy\x20violation\x20exists"),
          _0x2767e4["push"](_0x2a6230["itemNumber"]),
          await chrome["storage"]["local"]["set"]({
            failedGsprItems: _0x2767e4,
          }));
        return;
      }
      if (!(_0x251745 = await _0x1bc471(_0x2a6230["customLabel"], "amazon"))) {
        (console["log"]("SKU\x20not\x20decoded"),
          await _0x552131(_0x2a6230, "SKU\x20not\x20decoded"),
          _0x2767e4["push"](_0x2a6230["itemNumber"]),
          await chrome["storage"]["local"]["set"]({
            failedGsprItems: _0x2767e4,
          }));
        return;
      }
      if (!_0x251745["toUpperCase"]()["startsWith"]("B")) {
        (console["log"]("SKU\x20does\x20not\x20start\x20with\x20B"),
          await _0x552131(
            _0x2a6230,
            "SKU\x20does\x20not\x20start\x20with\x20B",
          ),
          _0x2767e4["push"](_0x2a6230["itemNumber"]),
          await chrome["storage"]["local"]["set"]({
            failedGsprItems: _0x2767e4,
          }));
        return;
      }
      var { domain: _0x370315 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x35b59f =
          "https://www.amazon." +
          _0x370315 +
          "/dp/" +
          _0x251745 +
          "/?th=1&psc=1";
      if (
        !(
          (_0x55a3c5 = await new Promise((_0x1e2350) => {
            chrome["runtime"]["sendMessage"](
              { type: "get_gspr", url: _0x35b59f },
              function (_0x2452b0) {
                (console["log"]("gspr", _0x2452b0), _0x1e2350(_0x2452b0));
              },
            );
          })) &&
          _0x55a3c5["gspr"] &&
          _0x55a3c5["gspr"]["manufacturerInfo"] &&
          _0x55a3c5["gspr"]["manufacturerInfo"]["country"]
        )
      ) {
        (await _0x552131(_0x2a6230, "GSPR\x20not\x20found"),
          _0x2767e4["push"](_0x2a6230["itemNumber"]),
          await chrome["storage"]["local"]["set"]({
            failedGsprItems: _0x2767e4,
          }));
        return;
      }
      var { gspr: _0x5d1c0c } = _0x55a3c5,
        _0x16a22 = await new Promise((_0x33cc37) => {
          chrome["runtime"]["sendMessage"](
            {
              type: "update_gspr_on_listing",
              gspr: _0x5d1c0c,
              itemNumber: _0x2a6230["itemNumber"],
            },
            function (_0x577550) {
              (console["log"](_0x577550), _0x33cc37(_0x577550));
            },
          );
        });
      (console["log"]("gsprSetResponse", _0x16a22),
        (!_0x16a22 || !_0x16a22["gsprSet"]) &&
          (_0x2767e4["push"](_0x2a6230["itemNumber"]),
          await chrome["storage"]["local"]["set"]({
            failedGsprItems: _0x2767e4,
          }),
          await _0x552131(_0x2a6230, "GSPR\x20set\x20failed")));
    } else {
      var { enable_set_skus_to_items: _0x3f4989 } = await chrome["storage"][
        "local"
      ]["get"]("enable_set_skus_to_items");
      if (_0x3f4989 && _0x3f4989["checkbox"]) {
        if (_0x2a6230["customLabel"]) {
          console["log"]("custom\x20label\x20found,\x20sku\x20already\x20set");
          return;
        }
        console["log"]("ebay\x20Item\x20Number", _0x2a6230["itemNumber"]);
        var _0x55a3c5 = await new Promise((_0x2dab4b) => {
            chrome["runtime"]["sendMessage"](
              {
                type: "get_sku_from_description",
                itemNumber: _0x2a6230["itemNumber"],
              },
              function (_0x225a1f) {
                _0x2dab4b(_0x225a1f);
              },
            );
          }),
          _0x3bb427 = _0x55a3c5?.["sku"];
        console["log"]("sku", _0x3bb427);
        if (_0x3bb427) {
          console["log"]("sku\x20found", _0x3bb427);
          var _0x3897d9 = await setRowCellValue(
            _0x4b58bc,
            "listingSKU",
            _0x3bb427,
          );
          console["log"]("succssfullyUpdated", _0x3897d9);
        }
      } else {
        var { enable_scan_for_restricted_words: _0x543ecb } = await chrome[
          "storage"
        ]["local"]["get"]("enable_scan_for_restricted_words");
        if (_0x543ecb && _0x543ecb["checkbox"])
          (console["log"]("Scanning\x20for\x20restricted\x20words"),
            (_0x55a3c5 = await new Promise((_0x419af0) => {
              chrome["runtime"]["sendMessage"](
                {
                  type: "check_if_item_is_restricted",
                  itemNumber: _0x2a6230["itemNumber"],
                },
                function (_0x3238d3) {
                  _0x419af0(_0x3238d3);
                },
              );
            })));
        else {
          if (_0x3ffbe0(_0x4b58bc)) {
            var { enable_delete_policy_violation_items: _0x3e1bf7 } =
              await chrome["storage"]["local"]["get"](
                "enable_delete_policy_violation_items",
              );
            if (_0x3e1bf7 && _0x3e1bf7["checkbox"]) {
              ((_0x55a3c5 = await _0x38c34f(_0x4b58bc)),
                console["log"]("response", _0x55a3c5),
                console["log"]("item\x20deleted"),
                await _0x552131(
                  _0x2a6230,
                  "Policy\x20violation\x20exists,\x20item\x20deleted",
                ));
              return;
            }
            await _0x552131(_0x2a6230, "Policy\x20violation\x20exists");
          } else {
            var { enable_delete_items_with_no_sku: _0x477bb3 } = await chrome[
              "storage"
            ]["local"]["get"]("enable_delete_items_with_no_sku");
            if (_0x477bb3 && _0x477bb3["checkbox"] && !_0x2a6230["customLabel"])
              (console["log"](
                "custom\x20label\x20not\x20found,\x20deleting\x20item",
              ),
                "delete" === (_0x1a865b = _0x477bb3["action"]) &&
                  ((_0x55a3c5 = await _0x38c34f(_0x4b58bc)),
                  console["log"]("response", _0x55a3c5),
                  console["log"]("item\x20deleted"),
                  await _0x552131(
                    _0x2a6230,
                    "Custom\x20label\x20not\x20found,\x20item\x20deleted",
                  )),
                "out_of_stock" === _0x1a865b &&
                  _0x2a6230["availableQty"] > 0x0 &&
                  ((_0x3897d9 = await setRowCellValue(
                    _0x4b58bc,
                    "availableQuantity",
                    0x0,
                  ))
                    ? await _0x552131(
                        _0x2a6230,
                        "Custom\x20label\x20not\x20found,\x20quantity\x20set\x20to\x200",
                      )
                    : await _0x552131(
                        _0x2a6230,
                        "Update\x20failed,\x20Custom\x20label\x20not\x20found,\x20quantity\x20not\x20updated",
                      )));
            else {
              if (_0x2a6230["customLabel"]) {
                var _0x312eed = await _0x5b9b6d(_0x2a6230["customLabel"]),
                  _0x251745 = await _0x1bc471(
                    _0x2a6230["customLabel"],
                    _0x312eed,
                  ),
                  { enable_delete_items_with_broken_sku: _0x57cb1b } =
                    await chrome["storage"]["local"]["get"](
                      "enable_delete_items_with_broken_sku",
                    );
                if (_0x251745) {
                  var _0x1b494f = await fetchSupplierItemData(
                    _0x251745,
                    _0x312eed,
                  );
                  await _0x26a18a(_0x4b58bc, _0x1b494f);
                  if (_0x1b494f["hasNetworkError"])
                    (await _0x552131(
                      _0x2a6230,
                      "Network\x20error,\x20item\x20not\x20found\x20on\x20supplier\x20site",
                    ),
                      (_0x4b58bc["style"]["backgroundColor"] = "#fc95ab"));
                  else {
                    var {
                      enable_delete_items_by_non_chinese_sellers: _0xc3fa61,
                    } = await chrome["storage"]["local"]["get"](
                      "enable_delete_items_by_non_chinese_sellers",
                    );
                    if (_0xc3fa61 && _0xc3fa61["checkbox"])
                      try {
                        var { isChineseSeller: _0x1e2d42 } = await new Promise(
                          (_0x40b3b1) => {
                            chrome["runtime"]["sendMessage"](
                              { type: "check_amazon_tab_if_chinese_seller" },
                              function (_0x4ec608) {
                                _0x40b3b1(_0x4ec608);
                              },
                            );
                          },
                        );
                        console["log"]("isChineseSeller", _0x1e2d42);
                        if (!0x1 === _0x1e2d42) {
                          console["log"](
                            "Non\x20chinese\x20seller,\x20deleting\x20item",
                          );
                          if ("save_item_id" === _0xc3fa61["action"]) {
                            _0x552131(
                              _0x2a6230,
                              "Non\x20chinese\x20seller,\x20item\x20not\x20deleted,\x20item\x20id\x20saved",
                            );
                            var { nonChineseSellerItemIds: _0x4710a1 } =
                              await chrome["storage"]["local"]["get"](
                                "nonChineseSellerItemIds",
                              );
                            (_0x4710a1 || (_0x4710a1 = []),
                              _0x4710a1["push"](_0x2a6230["itemNumber"]),
                              await chrome["storage"]["local"]["set"]({
                                nonChineseSellerItemIds: _0x4710a1,
                              }));
                          }
                          return;
                        }
                        (console["log"](
                          "Chinese\x20seller,\x20item\x20not\x20deleted",
                        ),
                          _0x552131(_0x2a6230, "Chinese\x20seller\x20[✅]"));
                      } catch (_0xf0ffd2) {
                        (console["error"](_0xf0ffd2),
                          await _0x552131(
                            _0x2a6230,
                            "Error\x20checking\x20seller\x20location",
                          ));
                        return;
                      }
                    var { enable_delete_items_not_found_on_amazon: _0x5cf2f1 } =
                      await chrome["storage"]["local"]["get"](
                        "enable_delete_items_not_found_on_amazon",
                      );
                    if (
                      !_0x5cf2f1 ||
                      !_0x5cf2f1["checkbox"] ||
                      _0x1b494f["hasNetworkError"] ||
                      _0x1b494f["isPageCorrectlyOpened"]
                    ) {
                      var {
                        enable_delete_items_sku_changed_on_amazon: _0x37b66c,
                      } = await chrome["storage"]["local"]["get"](
                        "enable_delete_items_sku_changed_on_amazon",
                      );
                      if (
                        _0x37b66c &&
                        _0x37b66c["checkbox"] &&
                        _0x1b494f["sku"] !== _0x251745
                      ) {
                        console["log"](
                          "SKU\x20changed\x20on\x20supplier\x20site,\x20deleting\x20item",
                        );
                        if ("delete" === (_0x1a865b = _0x37b66c["action"])) {
                          ((_0x55a3c5 = await _0x38c34f(_0x4b58bc)),
                            console["log"]("response", _0x55a3c5),
                            console["log"]("item\x20deleted"));
                          var _0x9c3647 =
                            "\x0a\x20\x20\x20\x20\x20\x20\x20\x20<span\x20style=\x22color:\x20red;\x22>SKU\x20changed\x20on\x20supplier\x20site,\x20item\x20deleted</span>,\x0a\x20\x20\x20\x20\x20\x20\x20\x20<span\x20style=\x22color:\x20blue;\x22>decodedSku:\x20[" +
                            _0x251745 +
                            "]</span>,\x0a\x20\x20\x20\x20\x20\x20\x20\x20<span\x20style=\x22color:\x20green;\x22>supplierSku:\x20[" +
                            _0x1b494f["sku"] +
                            "]</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20";
                          await _0x552131(_0x2a6230, _0x9c3647);
                        }
                        "out_of_stock" === _0x1a865b &&
                          (_0x2a6230["availableQty"] > 0x0 &&
                            ((_0x3897d9 = await setRowCellValue(
                              _0x4b58bc,
                              "availableQuantity",
                              0x0,
                            )) ||
                              (await _0x552131(
                                _0x2a6230,
                                "Update\x20failed,\x20SKU\x20changed\x20on\x20supplier\x20site,\x20quantity\x20not\x20updated",
                              ))),
                          (_0x9c3647 =
                            "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20style=\x22color:\x20red;\x22>SKU\x20changed\x20on\x20supplier\x20site,\x20quantity\x20set\x20to\x200</span>,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20style=\x22color:\x20blue;\x22>decodedSku:\x20[" +
                            _0x251745 +
                            "]</span>,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20style=\x22color:\x20green;\x22>supplierSku:\x20[" +
                            _0x1b494f["sku"] +
                            "]</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"),
                          await _0x552131(_0x2a6230, _0x9c3647));
                      } else {
                        if (_0x1b494f) {
                          var { enable_stock_monitor: _0x9ddf39 } =
                            await chrome["storage"]["local"]["get"](
                              "enable_stock_monitor",
                            );
                          console["log"]("enable_stock_monitor", _0x9ddf39);
                          var _0x3698c1 = await _0x4c0288(_0x1b494f);
                          if (_0x9ddf39 && _0x9ddf39["checkbox"]) {
                            var _0x137f1f = _0x9ddf39["restock_quantity"];
                            console["log"]("isInStock:\x20" + _0x3698c1);
                            if (_0x3698c1) {
                              (console["log"]("item\x20is\x20in\x20stock"),
                                (_0x4b58bc["style"]["backgroundColor"] =
                                  "#d1f2b8"));
                              var {
                                force_restock_quantity_setting: _0x47a914,
                              } = await chrome["storage"]["local"]["get"](
                                "force_restock_quantity_setting",
                              );
                              if (_0x47a914 && _0x47a914["checkbox"])
                                ((_0x137f1f = _0x47a914["restock_quantity"]),
                                  console["log"](
                                    "force\x20restock\x20quantity:\x20" +
                                      _0x137f1f,
                                  ),
                                  _0x2a6230["availableQty"] !== _0x137f1f &&
                                    ((_0x3897d9 = await setRowCellValue(
                                      _0x4b58bc,
                                      "availableQuantity",
                                      _0x137f1f,
                                    )) ||
                                      (await _0x552131(
                                        _0x2a6230,
                                        "Update\x20failed,\x20Item\x20is\x20in\x20stock,\x20quantity\x20not\x20updated",
                                      ))));
                              else
                                _0x2a6230["availableQty"] < 0x1 &&
                                  ((_0x3897d9 = await setRowCellValue(
                                    _0x4b58bc,
                                    "availableQuantity",
                                    _0x137f1f,
                                  )) ||
                                    (await _0x552131(
                                      _0x2a6230,
                                      "Update\x20failed,\x20Item\x20is\x20in\x20stock,\x20quantity\x20not\x20updated",
                                    )));
                            } else {
                              console["log"](
                                "item\x20is\x20not\x20in\x20stock",
                              );
                              var _0x42d71b = await _0x2e3998(_0x1b494f),
                                _0x39416c = _0x1b494f["availabilityMessage"];
                              ((_0x9c3647 =
                                "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22tracking-message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p\x20class=\x22status-error\x22><strong>Item\x20is\x20not\x20in\x20stock</strong></p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p\x20class=\x22status-reasons\x22><em>Reasons:</em>\x20" +
                                _0x42d71b["join"](",\x20") +
                                "</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<p\x20class=\x22status-availability\x22><em>Availability\x20Message:</em>\x20" +
                                _0x39416c +
                                "</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"),
                                (_0x4b58bc["style"]["backgroundColor"] =
                                  "#fc95ab"),
                                await _0x552131(_0x2a6230, _0x9c3647),
                                _0x2a6230["availableQty"] > 0x0 &&
                                  ((_0x3897d9 = await setRowCellValue(
                                    _0x4b58bc,
                                    "availableQuantity",
                                    0x0,
                                  )) ||
                                    (await _0x552131(
                                      _0x2a6230,
                                      "Update\x20failed,\x20Item\x20is\x20not\x20in\x20stock,\x20quantity\x20not\x20updated",
                                    ))));
                            }
                          }
                          var {
                              enable_price_ending_filter:
                                enable_price_ending_filter,
                            } = await chrome["storage"]["local"]["get"](
                              "enable_price_ending_filter",
                            ),
                            { enable_price_monitor: _0x3d622c } = await chrome[
                              "storage"
                            ]["local"]["get"]("enable_price_monitor");
                          if (
                            _0x3d622c &&
                            _0x3d622c["checkbox"] &&
                            enable_price_ending_filter &&
                            enable_price_ending_filter["checkbox"]
                          ) {
                            var _0x57eae4 = _0x2a6230["price"];
                            console["log"]("ebayPrice:\x20" + _0x57eae4);
                            var _0x433248 =
                              enable_price_ending_filter["price_endings"];
                            (console["log"](
                              "(pre)\x20allowedPriceEndings:\x20" + _0x433248,
                            ),
                              (_0x433248 = (_0x433248 =
                                _0x433248["split"](","))["map"]((_0xcc6dba) =>
                                parseFloat(_0xcc6dba["trim"]()),
                              )),
                              console["log"](
                                "allowedPriceEndings:\x20" + _0x433248,
                              ));
                            var _0x44befe =
                              _0x57eae4["toString"]()["split"](".")[0x1] ||
                              _0x57eae4["toString"]()["split"](",")[0x1] ||
                              _0x57eae4["toString"]()["split"]("€")[0x1];
                            ((_0x44befe = parseFloat(_0x44befe)),
                              console["log"](
                                "ebayPriceEnding:\x20" + _0x44befe,
                              ));
                            if (!_0x433248["includes"](_0x44befe)) {
                              await _0x552131(
                                _0x2a6230,
                                "eBay\x20price\x20ending\x20is\x20not\x20allowed.\x20Please\x20change\x20the\x20price\x20ending\x20to\x20one\x20of\x20the\x20allowed\x20price\x20endings",
                              );
                              return;
                            }
                          }
                          if (
                            _0x1b494f["isIpBlocked"] ||
                            !0x1 === _0x1b494f["isPageCorrectlyOpened"]
                          )
                            await _0x552131(
                              _0x2a6230,
                              "IP\x20is\x20blocked\x20or\x20page\x20is\x20not\x20correctly\x20opened",
                            );
                          else {
                            if (
                              _0x3d622c &&
                              _0x3d622c["checkbox"] &&
                              _0x3698c1 &&
                              "markup_pricing" === _0x3d622c["pricing_option"]
                            ) {
                              var { markupPrice: _0x756769 } =
                                await chrome["storage"]["local"]["get"](
                                  "markupPrice",
                                );
                              console["log"]("markupPrice", _0x756769);
                              var _0x5b9277 = _0x756769,
                                _0x8503e8 = parseFloat(
                                  _0x3d622c["price_trigger_threshold"],
                                );
                              _0x57eae4 = parseFloat(_0x2a6230["price"]);
                              var _0x541d90 = parseFloat(_0x1b494f["price"]),
                                _0x17e04a = (_0x5b9277 / 0x64) * _0x541d90,
                                _0x8916f1 = _0x541d90 + _0x17e04a;
                              ((_0x8916f1 = parseFloat(
                                _0x8916f1["toFixed"](0x2),
                              )),
                                console["log"](
                                  "markedUpSupplierPrice:\x20" + _0x8916f1,
                                ),
                                console["log"](
                                  "supplierPrice:\x20" + _0x541d90,
                                ),
                                console["log"](
                                  "markup_percentage:\x20" + _0x5b9277,
                                ),
                                console["log"]("markupAmount:\x20" + _0x17e04a),
                                console["log"](
                                  "price_trigger_threshold:\x20" + _0x8503e8,
                                ));
                              if (
                                _0x57eae4 < _0x8916f1 - _0x8503e8 ||
                                _0x57eae4 > _0x8916f1 + _0x8503e8
                              ) {
                                var { end_price: _0x5c00b2 } =
                                  await chrome["storage"]["local"]["get"](
                                    "end_price",
                                  );
                                _0x5c00b2 = parseFloat(_0x5c00b2);
                                if (isNaN(_0x5c00b2))
                                  throw new Error(
                                    "Invalid\x20end_price\x20value\x20from\x20storage",
                                  );
                                var _0x4962db = _0x239200(_0x8916f1, _0x5c00b2),
                                  { domain: _0x370315 } =
                                    await chrome["storage"]["local"]["get"](
                                      "domain",
                                    );
                                (("de" !== _0x370315 &&
                                  "fr" !== _0x370315 &&
                                  "it" !== _0x370315 &&
                                  "es" !== _0x370315) ||
                                  (_0x4962db = _0x4962db["toString"]()[
                                    "replace"
                                  ](".", ",")),
                                  console["log"](
                                    "adjusting\x20the\x20price\x20to:\x20" +
                                      _0x4962db,
                                  ),
                                  (_0x3897d9 = await setRowCellValue(
                                    _0x4b58bc,
                                    "price",
                                    _0x4962db,
                                  )) ||
                                    (await _0x552131(
                                      _0x2a6230,
                                      "Update\x20failed,\x20Price\x20mismatch\x20detected,\x20price\x20not\x20updated",
                                    )));
                              }
                            }
                          }
                        } else
                          await _0x552131(
                            _0x2a6230,
                            "Supplier\x20item\x20info\x20not\x20found",
                          );
                      }
                    } else
                      (console["log"](
                        "Item\x20not\x20found\x20on\x20supplier\x20site,\x20deleting\x20item",
                      ),
                        "delete" === (_0x1a865b = _0x5cf2f1["action"]) &&
                          ((_0x55a3c5 = await _0x38c34f(_0x4b58bc)),
                          console["log"]("response", _0x55a3c5),
                          console["log"]("item\x20deleted"),
                          await _0x552131(
                            _0x2a6230,
                            "<span\x20style=\x27color:\x20red;\x27>Item\x20not\x20found\x20on\x20supplier\x20site,\x20item\x20deleted</span>",
                          )),
                        "out_of_stock" === _0x1a865b &&
                          (_0x2a6230["availableQty"] > 0x0 &&
                            ((_0x3897d9 = await setRowCellValue(
                              _0x4b58bc,
                              "availableQuantity",
                              0x0,
                            )) ||
                              (await _0x552131(
                                _0x2a6230,
                                "Update\x20failed,\x20Item\x20not\x20found\x20on\x20supplier\x20site,\x20quantity\x20not\x20updated",
                              ))),
                          await _0x552131(
                            _0x2a6230,
                            "<span\x20style=\x27color:\x20red;\x27>Item\x20not\x20found\x20on\x20supplier\x20site,\x20quantity\x20set\x20to\x200</span>",
                          )));
                  }
                } else {
                  if (_0x57cb1b && _0x57cb1b["checkbox"]) {
                    console["log"](
                      "SKU\x20is\x20not\x20decoded,\x20deleting\x20item",
                    );
                    var _0x1a865b;
                    ("delete" === (_0x1a865b = _0x57cb1b["action"]) &&
                      ((_0x55a3c5 = await _0x38c34f(_0x4b58bc)),
                      console["log"]("response", _0x55a3c5),
                      console["log"]("item\x20deleted"),
                      await _0x552131(
                        _0x2a6230,
                        "SKU\x20not\x20decoded,\x20item\x20deleted",
                      )),
                      "out_of_stock" === _0x1a865b &&
                        _0x2a6230["availableQty"] > 0x0 &&
                        ((_0x3897d9 = await setRowCellValue(
                          _0x4b58bc,
                          "availableQuantity",
                          0x0,
                        ))
                          ? await _0x552131(
                              _0x2a6230,
                              "SKU\x20not\x20decoded,\x20quantity\x20set\x20to\x200",
                            )
                          : await _0x552131(
                              _0x2a6230,
                              "Update\x20failed,\x20SKU\x20not\x20decoded,\x20quantity\x20not\x20updated",
                            )));
                  }
                }
              } else console["log"]("custom\x20label\x20not\x20found");
            }
          }
        }
      }
    }
  }
}
function _0x239200(_0xe35fd7, _0x1a0a01) {
  if ((_0x1a0a01 = parseFloat(_0x1a0a01)) >= 0x1 && _0x1a0a01 < 0x64)
    _0x1a0a01 /= 0x64;
  else {
    if (_0x1a0a01 >= 0x64 || _0x1a0a01 < 0x0)
      throw new Error("Invalid\x20end_price\x20value");
  }
  var _0x4febe0 = Math["floor"](_0xe35fd7),
    _0x415174 = Math["ceil"](_0xe35fd7),
    _0xe83527 = [];
  for (
    var _0x82f3f5 = _0x4febe0 - 0x1;
    _0x82f3f5 <= _0x415174 + 0x1;
    _0x82f3f5++
  ) {
    var _0x4b5a7e = _0x82f3f5 + _0x1a0a01;
    _0x4b5a7e >= 0x0 && _0xe83527["push"](_0x4b5a7e);
  }
  var _0x2da020 = _0xe83527["reduce"](function (_0x37e745, _0x1d4b62) {
    return Math["abs"](_0x1d4b62 - _0xe35fd7) <
      Math["abs"](_0x37e745 - _0xe35fd7)
      ? _0x1d4b62
      : _0x37e745;
  });
  return parseFloat(_0x2da020["toFixed"](0x2));
}
async function _0x4c0288(_0x1f9ed6) {
  if (!_0x1f9ed6["hasFreeShipping"]) return !0x1;
  if (!_0x1f9ed6["isItemAvailable"]) return !0x1;
  if (!_0x1f9ed6["isPageCorrectlyOpened"]) return !0x1;
  if (_0x1f9ed6["isItemDeliveryExtended"]) return !0x1;
  if (
    _0x1f9ed6["itemCondition"] &&
    "used" == _0x1f9ed6["itemCondition"]["toLowerCase"]()
  )
    return !0x1;
  var { enable_stock_monitor: _0x14383d } = await chrome["storage"]["local"][
    "get"
  ]("enable_stock_monitor");
  return !(
    "prime_only" === _0x14383d["prime_option"] &&
    !_0x1f9ed6["isEligibleForPrime"]
  );
}
async function _0x2e3998(_0x39d894) {
  var _0xc29793 = [];
  (_0x39d894["hasFreeShipping"] ||
    _0xc29793["push"]("Item\x20does\x20not\x20have\x20free\x20shipping"),
    _0x39d894["isItemAvailable"] ||
      _0xc29793["push"]("Item\x20is\x20not\x20available"),
    _0x39d894["isPageCorrectlyOpened"] ||
      _0xc29793["push"]("Page\x20did\x20not\x20open\x20correctly"),
    _0x39d894["isItemDeliveryExtended"] &&
      _0xc29793["push"]("Item\x20delivery\x20is\x20extended"),
    _0x39d894["itemCondition"] &&
      "used" == _0x39d894["itemCondition"]["toLowerCase"]() &&
      _0xc29793["push"]("Item\x20is\x20used"));
  var { enable_stock_monitor: _0x94922b } = await chrome["storage"]["local"][
    "get"
  ]("enable_stock_monitor");
  return (
    "prime_only" === _0x94922b["prime_option"] &&
      (_0x39d894["isEligibleForPrime"] ||
        _0xc29793["push"]("Item\x20is\x20not\x20eligible\x20for\x20Prime")),
    _0xc29793
  );
}
async function _0x552131(_0x480bc3, _0x52ab8a) {
  var { should_track_log: _0xc957c3 } =
    await chrome["storage"]["local"]["get"]("should_track_log");
  if (_0xc957c3) {
    var { tracking_log: _0x5e5fb4 } =
      await chrome["storage"]["local"]["get"]("tracking_log");
    _0x5e5fb4 || (_0x5e5fb4 = []);
    var _0x29e401 = {
      entry_time: new Date()["toLocaleString"](),
      ebayItemData: _0x480bc3,
      statusMessage: _0x52ab8a,
    };
    (_0x5e5fb4["push"](_0x29e401),
      await chrome["storage"]["local"]["set"]({ tracking_log: _0x5e5fb4 }));
  }
}
async function _0x516586(_0xc97c53) {
  var { domain: _0x53a616 } = await chrome["storage"]["local"]["get"]("domain");
  try {
    const _0x3e186a = await fetch(
        "https://poshmark." + _0x53a616 + "/edit-listing/" + _0xc97c53,
        { credentials: "include" },
      ),
      _0xcbe643 = (await _0x3e186a["text"]())["match"](/"sku":\s*"([^"]+)"/);
    if (!_0xcbe643) {
      console["error"]("SKU\x20not\x20found\x20in\x20response");
      return;
    }
    return _0xcbe643[0x1];
  } catch (_0x203e5c) {
    console["error"]("Error\x20fetching\x20SKU:", _0x203e5c);
  }
}
async function _0x4c8e29(_0x3312a1, _0x4cdf2e = {}) {
  const {
      available: _0x163ca0,
      price: _0x4867e6,
      originalPrice: _0x39cc8d,
      region: region = "us",
    } = _0x4cdf2e,
    _0x14e311 = "ca" === region ? "poshmark.ca" : "poshmark.com",
    _0x1ac629 = "ca" === region ? "CAD" : "USD",
    _0x106a5e =
      "https://" +
      _0x14e311 +
      "/vm-rest/posts/" +
      _0x3312a1 +
      "?pm_version=2025.37.1";
  var _0xa7c9b1 = { post: {} };
  _0x4cdf2e["hasOwnProperty"]("available") &&
    (_0xa7c9b1["post"]["inventory"] = {
      status: _0x163ca0 ? "available" : "not_for_sale",
    });
  "number" == typeof _0x4867e6 &&
    ((_0xa7c9b1["post"]["price_amount"] = {
      val: _0x4867e6["toFixed"](0x2),
      currency_code: _0x1ac629,
    }),
    _0x4cdf2e["hasOwnProperty"]("originalPrice") ||
      (_0xa7c9b1["post"]["original_price_amount"] = {
        val: (1.5 * _0x4867e6)["toFixed"](0x2),
        currency_code: _0x1ac629,
      }));
  ("number" == typeof _0x39cc8d &&
    (_0xa7c9b1["post"]["original_price_amount"] = {
      val: _0x39cc8d["toFixed"](0x2),
      currency_code: _0x1ac629,
    }),
    _0x4cdf2e["hasOwnProperty"]("set_offers") &&
      (_0xa7c9b1["post"]["offer_auto_actions_v2_enabled"] =
        !!_0x4cdf2e["set_offers"]),
    _0x4cdf2e["hasOwnProperty"]("min_offer") &&
      (_0xa7c9b1["post"]["offer_auto_actions_min_price_amount"] = {
        val: _0x4cdf2e["min_offer"],
        currency_code: _0x1ac629,
      }),
    console["log"](
      "Updating\x20listing\x20[" + _0x3312a1 + "@" + _0x14e311 + "]\x20with:",
      _0xa7c9b1,
    ));
  if (0x0 === Object["keys"](_0xa7c9b1["post"])["length"])
    return (
      console["warn"](
        "[" +
          _0x3312a1 +
          "]\x20No\x20update\x20options\x20specified—skipping\x20request.",
      ),
      Promise["resolve"]()
    );
  return (
    console["log"]("postData:", _0xa7c9b1),
    fetch(_0x106a5e, {
      method: "POST",
      credentials: "include",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON["stringify"](_0xa7c9b1),
    })
      ["then"]((_0x3b32e7) => {
        if (!_0x3b32e7["ok"]) throw new Error("HTTP\x20" + _0x3b32e7["status"]);
        return _0x3b32e7["json"]();
      })
      ["then"]((_0x1a9549) => {
        return (
          console["log"](
            "✅\x20[" + _0x3312a1 + "@" + _0x14e311 + "]\x20updated:",
            _0xa7c9b1["post"],
            _0x1a9549,
          ),
          _0x1a9549
        );
      })
      ["catch"]((_0x44e7da) => {
        console["error"](
          "❌\x20[" + _0x3312a1 + "@" + _0x14e311 + "]\x20update\x20failed:",
          _0x44e7da,
        );
        throw _0x44e7da;
      })
  );
}
function fetchProductData(
  _0x5a3464,
  _0x6bc149 = "https://www.amazon.com/dp/" + atob(_0x5a3464) + "?th=1&psc=1",
) {
  return (
    console["log"](
      "fetchProductData\x20called\x20with\x20cl:",
      _0x5a3464,
      "and\x20url:",
      _0x6bc149,
    ),
    new Promise((_0x565653, _0x49f51b) => {
      chrome["runtime"]["sendMessage"](
        {
          type: "fetch_product_data",
          supplier: "amazon",
          customLabel: _0x5a3464,
          itemUrl: _0x6bc149,
        },
        (_0x4909da) => {
          if (chrome["runtime"]["lastError"])
            return _0x49f51b(chrome["runtime"]["lastError"]);
          if (!_0x4909da || _0x4909da["error"])
            return _0x49f51b(
              new Error(_0x4909da?.["error"] || "Unknown\x20error"),
            );
          _0x565653(_0x4909da["productData"] || {});
        },
      );
    })
  );
}
async function _0x143f9a(_0x29fb6f, _0x55c254 = {}) {
  const {
    minPrice: _0x2730f5,
    currency: currency = "USD",
    region: region = "us",
    userId: _0x4404c7,
    pmVersion: pmVersion = "2025.37.1",
  } = _0x55c254;
  if (!_0x4404c7)
    throw new Error("previewOfferEarnings\x20requires\x20opts.userId");
  if (null == _0x2730f5)
    throw new Error("previewOfferEarnings\x20requires\x20opts.minPrice");
  const _0xd6134 =
    "https://" +
    ("ca" === region ? "poshmark.ca" : "poshmark.com") +
    "/vm-rest/users/" +
    _0x4404c7 +
    "/seller_earnings/post?" +
    new URLSearchParams({
      price_amount: JSON["stringify"]({
        val: String(_0x2730f5),
        currency_code: currency,
      }),
      object_id: _0x29fb6f,
      pm_version: pmVersion,
    })["toString"]();
  console["log"]("Fetching\x20earnings\x20preview\x20from:", _0xd6134);
  const _0x175c95 = await fetch(_0xd6134, {
    method: "GET",
    credentials: "include",
    headers: {
      Accept: "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!_0x175c95["ok"])
    throw new Error(
      "previewOfferEarnings\x20failed:\x20HTTP\x20" + _0x175c95["status"],
    );
  const _0x36fecc = await _0x175c95["json"]();
  return (
    console["log"](
      "💡\x20Earnings\x20preview\x20for\x20post\x20" + _0x29fb6f + ":",
      _0x36fecc,
    ),
    _0x36fecc
  );
}
function _0x3cd668() {
  const _0x394d41 = document["querySelectorAll"]("a[href^=\x22/listing/\x22]");
  for (let _0x4bcdf2 of _0x394d41) {
    const _0x330ea0 = _0x4bcdf2["getAttribute"]("href")["match"](/-(\w{24})$/);
    if (_0x330ea0) {
      const _0x5e7065 = _0x330ea0[0x1];
      return (console["log"]("Listing\x20ID:", _0x5e7065), _0x5e7065);
    }
  }
  return (console["warn"]("No\x20listing\x20ID\x20found."), null);
}
function _0x4a444f() {
  const _0x4f3209 = window["location"]["pathname"]["match"](
    /\/listing\/.*-(\w{24})$/,
  );
  if (_0x4f3209) {
    const _0x236e24 = _0x4f3209[0x1];
    return (
      console["log"]("Listing\x20ID\x20from\x20URL:", _0x236e24),
      _0x236e24
    );
  }
  return (console["warn"]("No\x20listing\x20ID\x20found\x20in\x20URL."), null);
}
function _0x5ab863() {
  var _0x434c04 = _0x3cd668();
  return (_0x434c04 || (_0x434c04 = _0x4a444f()), _0x434c04);
}
async function _0x4527e4() {
  var _0x2e0c22 = _0x5ab863(),
    _0x203b21 = await _0x516586(_0x2e0c22);
  return atob(_0x203b21);
}
async function _0x3d971c() {
  var _0x2ad677 = await _0x4527e4();
  if (!_0x2ad677) throw new Error("ASIN\x20not\x20found");
  const { domain: _0x1c447f } =
      await chrome["storage"]["local"]["get"]("domain"),
    _0x30c3db =
      "https://www.amazon." + _0x1c447f + "/dp/" + _0x2ad677 + "?th=1&psc=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x30c3db });
}
let _0xeac1b0 = !0x1,
  _0x274c71 = !0x1,
  _0x86ef0c = document["title"],
  _0x103bf5 = new Audio(chrome["runtime"]["getURL"]("bell.mp3"));
function _0x367d0f() {
  ((document["querySelector"]("#captcha-popup") &&
    "block" ===
      document["querySelector"]("#captcha-popup")["style"]["display"]) ||
    document["querySelector"](".g-recaptcha-con")) &&
    !_0xeac1b0 &&
    ((_0xeac1b0 = !0x0),
    void 0x0 !== _0x103bf5 && _0x103bf5["play"](),
    (_0x274c71 = !0x0),
    (_0x86ef0c = document["title"]),
    (document["title"] =
      "Captcha\x20detected!\x20Please\x20solve\x20it\x20to\x20continue."),
    setTimeout(
      () =>
        alert(
          "Captcha\x20detected!\x20Please\x20solve\x20it\x20to\x20continue.",
        ),
      0x3e8,
    ),
    _0x157cd());
}
function _0x157cd() {
  let _0x39e748 = setInterval(() => {
    !(
      (document["querySelector"]("#captcha-popup") &&
        "block" ===
          document["querySelector"]("#captcha-popup")["style"]["display"]) ||
      document["querySelector"](".g-recaptcha-con")
    ) &&
      ((_0xeac1b0 = !0x1),
      (_0x274c71 = !0x1),
      (document["title"] = _0x86ef0c || "Poshmark"),
      clearInterval(_0x39e748),
      console["log"]("Captcha\x20solved,\x20resuming\x20script."));
  }, 0x7d0);
}
function _0xdc21d9() {
  return new Promise((_0x2d2d50) => {
    let _0x294bd4 = setInterval(() => {
      !_0x274c71 && (clearInterval(_0x294bd4), _0x2d2d50());
    }, 0x3e8);
  });
}
function _0x15684f(_0x67f4b) {
  return new Promise((_0x10f976) => setTimeout(_0x10f976, _0x67f4b));
}
async function _0x15d994(_0x4f2c3c = 0x1d4c0) {
  const _0x1507e7 = Date["now"](),
    _0x12a752 = document["body"]["scrollHeight"];
  window["scrollTo"](0x0, document["body"]["scrollHeight"]);
  for (; Date["now"]() - _0x1507e7 < _0x4f2c3c; ) {
    await _0x15684f(0x3e8);
    if (document["body"]["scrollHeight"] > _0x12a752)
      return (console["log"]("New\x20items\x20loaded."), !0x0);
    console["log"]("Waiting\x20for\x20new\x20items\x20to\x20load...");
  }
  return (console["log"]("No\x20more\x20items\x20to\x20load."), !0x1);
}
function _0x467b52() {
  const _0x48d35a = [];
  return (
    document["querySelectorAll"](".tile,\x20.card")["forEach"]((_0x6ada25) => {
      const _0x311dfc = _0xd85c58(_0x6ada25);
      if (!_0x311dfc) return;
      const {
        itemName: _0x2bdbd4,
        shareButton: _0xa5858f,
        itemId: _0xe5fd3,
        price: _0x383e37,
        availability: _0x40c183,
      } = _0x311dfc;
      _0x2bdbd4 &&
        _0xa5858f &&
        _0x48d35a["push"]({
          itemName: _0x2bdbd4,
          shareButton: _0xa5858f,
          element: _0x6ada25,
          itemId: _0xe5fd3,
          price: _0x383e37,
          availability: _0x40c183,
        });
    }),
    console["log"]("Collected\x20" + _0x48d35a["length"] + "\x20items."),
    _0x48d35a
  );
}
function _0xd85c58(_0x318044) {
  let _0x141c4 = null,
    _0x3005eb = null;
  const _0xdc8a90 = _0x318044["querySelector"](
    ".tile__title,\x20a.tile__title.tc--b,\x20.title",
  );
  _0xdc8a90 && (_0x141c4 = _0xdc8a90["innerText"]);
  const _0x11d90d = _0x318044["querySelector"](
    ".social-action-bar__share,\x20.share",
  );
  _0x11d90d && (_0x3005eb = _0x11d90d);
  if (_0x141c4 && _0x141c4["includes"]("Meet\x20your")) return;
  let _0x5eaa13;
  const _0x634d56 = _0x318044["querySelector"]("a")?.["getAttribute"]("href");
  _0x634d56 && (_0x5eaa13 = _0x634d56["split"]("-")["pop"]()["trim"]());
  let _0x4f5c04;
  const _0x57f986 = _0x318044["querySelector"](
    ".title__condition__container",
  )?.["nextElementSibling"]?.["firstChild"]?.["firstChild"];
  _0x57f986 &&
    (_0x4f5c04 = parseFloat(_0x57f986["innerText"]["replace"](/[^0-9.]/g, "")));
  let _0x334ee8 = !_0x318044["querySelector"](".not-for-sale-tag");
  return {
    itemName: _0x141c4,
    shareButton: _0x3005eb,
    element: _0x318044,
    itemId: _0x5eaa13,
    price: _0x4f5c04,
    availability: _0x334ee8,
  };
}
function _0x45724c(_0x8eb738 = "track") {
  let _0x531650 = document["createElement"]("div");
  ((_0x531650["id"] = "share-progress-modal"),
    (_0x531650["innerHTML"] =
      "\x0a\x20\x20\x20\x20<div\x20class=\x22modal-content\x22>\x0a\x20\x20\x20\x20\x20\x20<h2\x20id=\x22modal-title\x22>Starting\x20" +
      _0x8eb738 +
      "\x20process...</h2>\x0a\x20\x20\x20\x20\x20\x20<div\x20id=\x22loader\x22></div>\x0a\x20\x20\x20\x20\x20\x20<div\x20id=\x22progress-bar-container\x22><div\x20id=\x22progress-bar\x22></div></div>\x0a\x20\x20\x20\x20\x20\x20<p\x20id=\x22progress-text\x22>0\x20items\x20processed</p>\x0a\x20\x20\x20\x20\x20\x20<button\x20id=\x22stop-button\x22\x20style=\x22margin-top:\x2010px;\x22>Stop</button>\x0a\x20\x20\x20\x20</div>\x0a\x20\x20"),
    document["body"]["appendChild"](_0x531650),
    document["getElementById"]("stop-button")["addEventListener"](
      "click",
      () => {
        ((_0x274c71 = !0x0),
          (document["title"] = _0x86ef0c || "Poshmark"),
          _0x528e67(),
          alert("Process\x20stopped."));
      },
    ));
}
function _0x5e1284(_0x4fc0e7, _0x46e2aa) {
  ((document["getElementById"]("modal-title")["textContent"] =
    "Loading\x20items\x20for\x20" + _0x46e2aa + "..."),
    (document["getElementById"]("progress-text")["textContent"] =
      _0x4fc0e7 + "\x20items\x20loaded"),
    (document["getElementById"]("loader")["style"]["display"] = "block"));
}
function _0x23cfce(_0xe3792a, _0x37c63e, _0x456143) {
  const _0x39b034 = document["getElementById"]("modal-title"),
    _0x53f145 = document["getElementById"]("progress-bar"),
    _0x28bf68 = document["getElementById"]("progress-text"),
    _0x2dfa88 = document["getElementById"]("loader");
  ("track" === _0x456143 &&
    (_0x39b034["textContent"] = "Tracking\x20Your\x20Items..."),
    "offers_on" === _0x456143 &&
      (_0x39b034["textContent"] = "Turning\x20Offers\x20ON..."),
    "offers_off" === _0x456143 &&
      (_0x39b034["textContent"] = "Turning\x20Offers\x20OFF..."),
    (_0x2dfa88["style"]["display"] = "none"));
  let _0x1fea0f = (_0xe3792a / _0x37c63e) * 0x64;
  ((_0x53f145["style"]["width"] = _0x1fea0f + "%"),
    (_0x28bf68["textContent"] =
      _0xe3792a + "\x20/\x20" + _0x37c63e + "\x20items\x20processed"));
}
function _0x528e67() {
  document["getElementById"]("share-progress-modal")?.["remove"]();
}
function _0x8159cc(_0x2d6fd7, _0x23b7a4, _0x24706c = "gray") {
  let _0x25aecc = _0x2d6fd7["element"]["querySelector"](".sync-note");
  (!_0x25aecc &&
    ((_0x25aecc = document["createElement"]("div")),
    (_0x25aecc["className"] = "sync-note"),
    Object["assign"](_0x25aecc["style"], {
      fontSize: "12px",
      marginTop: "4px",
      padding: "2px\x204px",
      borderRadius: "4px",
      background: "#f0f0f0",
      color: "#333",
    }),
    _0x2d6fd7["element"]["appendChild"](_0x25aecc)),
    (_0x25aecc["textContent"] = _0x23b7a4),
    (_0x2d6fd7["element"]["style"]["border"] = "2px\x20solid\x20" + _0x24706c));
}
async function _0x3131a4(_0x5f24f1 = "track") {
  var { domain: _0xf64b6e } = await chrome["storage"]["local"]["get"]("domain"),
    _0x1f7581 = "ca" === _0xf64b6e ? "ca" : "us";
  ((_0x274c71 = !0x1),
    console["log"]("🔄\x20Starting\x20mode:\x20" + _0x5f24f1),
    _0x45724c(_0x5f24f1));
  const _0x428b21 = new Set();
  let _0x5aea0f = 0x0,
    _0x3cb575 = 0x0;
  for (; !_0x274c71; ) {
    _0x5e1284(_0x3cb575, _0x5f24f1);
    const _0x50f161 = _0x467b52()["filter"](
      (_0x328d3b) => !_0x428b21["has"](_0x328d3b["itemName"]),
    );
    if (0x0 !== _0x50f161["length"]) {
      ((_0x3cb575 += _0x50f161["length"]),
        _0x23cfce(_0x5aea0f, _0x3cb575, _0x5f24f1));
      for (const _0x566b98 of _0x50f161) {
        (_0x566b98["element"]["classList"]["add"]("highlight-item"),
          _0x566b98["element"]["scrollIntoView"]({
            behavior: "smooth",
            block: "center",
          }));
        try {
          "track" === _0x5f24f1
            ? await _0x62b222(_0x566b98, _0x1f7581)
            : "offers_on" === _0x5f24f1
              ? await _0x240f07(_0x566b98, _0x1f7581)
              : "offers_off" === _0x5f24f1 &&
                (await _0x59bdc2(_0x566b98, _0x1f7581));
        } catch (_0x258499) {
          console["error"](
            "❌\x20Failed\x20for\x20" + _0x566b98["itemId"],
            _0x258499,
          );
        }
        (_0x566b98["element"]["classList"]["remove"]("highlight-item"),
          _0x428b21["add"](_0x566b98["itemName"]),
          _0x5aea0f++,
          _0x23cfce(_0x5aea0f, _0x3cb575, _0x5f24f1),
          await _0x15684f(0x12c));
      }
      if (!(await _0x15d994())) break;
    } else {
      if (!(await _0x15d994())) break;
    }
  }
  (_0x528e67(),
    alert(
      "✅\x20" +
        _0x5f24f1 +
        "\x20finished:\x20" +
        _0x5aea0f +
        "/" +
        _0x3cb575 +
        "\x20items\x20done.",
    ));
}
async function _0x62b222(_0x314def, _0x337245) {
  const _0x28b1aa = await _0x516586(_0x314def["itemId"]);
  if (!_0x28b1aa) return;
  let _0x5b3c32;
  try {
    ((_0x5b3c32 = await fetchProductData(_0x28b1aa)),
      console["log"]("Fetched\x20supplier\x20data:", _0x5b3c32));
  } catch {
    _0x5b3c32 = { quantity: 0x0, price: -0x1 };
  }
  const _0x17ac6b = await chrome["storage"]["local"]["get"]([
      "enable_stock_monitor",
      "enable_price_monitor",
      "markupPrice",
      "price_trigger_threshold",
    ]),
    _0x1ad42d = { region: _0x337245 };
  _0x17ac6b["enable_stock_monitor"]?.["checkbox"] &&
    (_0x314def["availability"] &&
      _0x5b3c32["quantity"] < 0x1 &&
      (_0x1ad42d["available"] = !0x1),
    !_0x314def["availability"] &&
      _0x5b3c32["quantity"] > 0x0 &&
      (_0x1ad42d["available"] = !0x0));
  if (
    _0x17ac6b["enable_price_monitor"]?.["checkbox"] &&
    _0x5b3c32["price"] > 0x0
  ) {
    const _0x18889b = _0x17ac6b["markupPrice"] || 0x1,
      _0x3c5eb2 = parseFloat(_0x17ac6b["price_trigger_threshold"]) || 0x0,
      _0x3b21b0 = _0x34fda6(_0x5b3c32["price"], _0x18889b);
    (Math["abs"](_0x314def["price"] - _0x3b21b0) > _0x3c5eb2 &&
      (_0x1ad42d["price"] = Math["round"](_0x3b21b0)),
      console["log"](
        "Item\x20price:\x20" +
          _0x314def["price"] +
          ",\x20Supplier\x20price:\x20" +
          _0x5b3c32["price"] +
          ",\x20Marked\x20up:\x20" +
          _0x3b21b0 +
          ",\x20Post\x20price:\x20" +
          _0x1ad42d["price"] +
          ",\x20markup:\x20" +
          _0x18889b +
          ",\x20threshold:\x20" +
          _0x3c5eb2,
      ));
  }
  if (0x1 === Object["keys"](_0x1ad42d)["length"]) {
    _0x8159cc(
      _0x314def,
      "No\x20changes",
      _0x314def["availability"] ? "green" : "red",
    );
    return;
  }
  await _0x4c8e29(_0x314def["itemId"], _0x1ad42d);
  let _0x1b3486 = [];
  (void 0x0 !== _0x1ad42d["available"] &&
    _0x1b3486["push"](
      "Stock:\x20" +
        (_0x314def["availability"] ? "in" : "out") +
        "\x20→\x20" +
        (_0x1ad42d["available"] ? "in" : "out"),
    ),
    void 0x0 !== _0x1ad42d["price"] &&
      _0x1b3486["push"](
        "Price:\x20" + _0x314def["price"] + "\x20→\x20" + _0x1ad42d["price"],
      ),
    _0x8159cc(
      _0x314def,
      _0x1b3486["join"](";\x20"),
      _0x1ad42d["available"] ? "green" : "red",
    ));
}
async function _0x240f07(_0x54b511, _0x2673a4) {
  const { poshmark_min_offer_percentage: _0x4f6e15 } = await chrome["storage"][
      "local"
    ]["get"]("poshmark_min_offer_percentage"),
    _0x1f2df5 = parseFloat(_0x4f6e15) || 0.8,
    _0x2a9bac = Math["round"](_0x54b511["price"] * _0x1f2df5),
    _0x2f0031 = {
      region: _0x2673a4,
      set_offers: !0x0,
      min_offer: _0x2a9bac,
      price: _0x54b511["price"],
    };
  (await _0x4c8e29(_0x54b511["itemId"], _0x2f0031),
    _0x8159cc(
      _0x54b511,
      "Offers\x20ON\x20→\x20Floor\x20$" + _0x2a9bac,
      "purple",
    ));
}
async function _0x59bdc2(_0x434c54, _0x532172) {
  const _0xabbfa3 = { region: _0x532172, set_offers: !0x1 };
  (await _0x4c8e29(_0x434c54["itemId"], _0xabbfa3),
    _0x8159cc(_0x434c54, "Offers\x20OFF", "gray"));
}
function _0x2c001e() {
  const _0x5207be =
    document["querySelector"]("#your-listings-container") || document["body"];
  (_0x4b5616(_0x5207be),
    new MutationObserver((_0x14fb30) => {
      for (const _0x336cc0 of _0x14fb30)
        for (const _0x2d3e47 of _0x336cc0["addedNodes"])
          _0x2d3e47 instanceof HTMLElement &&
            (_0x2d3e47["matches"](".tile,\x20.card")
              ? _0x4a7ca4(_0x2d3e47)
              : _0x4b5616(_0x2d3e47));
    })["observe"](_0x5207be, { childList: !0x0, subtree: !0x0 }));
}
function _0x4a7ca4(_0x4ec1b6) {
  const _0x249b33 = _0x56921a(_0x3d971c);
  _0x4ec1b6["querySelector"]("[data-et-name=\x22seller\x22]")?.["appendChild"](
    _0x249b33,
  );
}
function _0x4b5616(_0x20f56a = document) {
  _0x20f56a["querySelectorAll"](".tile,\x20.card")["forEach"]((_0x2c4cb1) => {
    _0x2c4cb1["querySelector"](".your-sku-button-class") ||
      _0x4a7ca4(_0x2c4cb1);
  });
}
async function _0x3d971c(_0x48308b) {
  _0x48308b["preventDefault"]();
  let _0xf5fc64 = _0x48308b["target"];
  for (; _0xf5fc64 && !_0xf5fc64["matches"](".tile,\x20.card"); )
    _0xf5fc64 = _0xf5fc64["parentElement"];
  if (!_0xf5fc64) {
    console["error"](
      "No\x20card\x20or\x20tile\x20found\x20in\x20the\x20event\x20target\x20hierarchy.",
    );
    return;
  }
  console["log"]("Target\x20card\x20or\x20tile:", _0xf5fc64);
  var _0x466a7c = _0xd85c58(_0xf5fc64);
  if (!_0x466a7c) {
    console["error"]("No\x20card\x20details\x20found.");
    return;
  }
  var { domain: _0x633ba3 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x454565 = await _0x516586(_0x466a7c["itemId"], _0x633ba3);
  if (!_0x454565) {
    console["warn"](
      "Poshmark\x20SKU\x20not\x20found\x20for\x20" +
        _0x466a7c["itemId"] +
        ".\x20Skipping.",
    );
    return;
  }
  const _0x2e79a9 =
    "https://www.amazon." +
    _0x633ba3 +
    "/dp/" +
    atob(_0x454565) +
    "?th=1&psc=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x2e79a9 });
}
function _0x115461() {
  const _0x3d8fa9 = document["createElement"]("div");
  _0x3d8fa9["className"] = "control-bar";
  const _0x463317 = _0x567c73(
      "Track\x20Items",
      "btn\x20btn-primary",
      "Check\x20all\x20items\x20and\x20update\x20stock/price\x20from\x20supplier",
      async () => {
        await _0x3131a4("track");
      },
    ),
    _0x3fdcd8 = _0x567c73(
      "Offers\x20ON",
      "btn",
      "Turn\x20Smart\x20Sell\x20offers\x20ON\x20for\x20every\x20item\x20(minimum\x20price\x20from\x20Settings)",
      async () => {
        await _0x3131a4("offers_on");
      },
    ),
    _0x20e39b = _0x567c73(
      "Offers\x20OFF",
      "btn",
      "Turn\x20Smart\x20Sell\x20offers\x20OFF\x20for\x20every\x20item",
      async () => {
        await _0x3131a4("offers_off");
      },
    ),
    _0x5cd743 = _0x567c73(
      "⚙️\x20Settings",
      "btn",
      "Open\x20Settings:\x20set\x20min\x20offer\x20%,\x20enable\x20stock/price\x20monitor,\x20etc.",
      async () => {
        await _0x488167();
      },
    ),
    _0x3632a3 = document["createElement"]("div");
  ((_0x3632a3["className"] = "control-helper"),
    (_0x3632a3["textContent"] =
      "Tip:\x20Use\x20these\x20buttons\x20to\x20manage\x20all\x20your\x20listings\x20at\x20once."),
    _0x3d8fa9["append"](_0x463317, _0x3fdcd8, _0x20e39b, _0x5cd743));
  const _0x30856e = document["createElement"]("div");
  return (
    (_0x30856e["className"] = "es-control-bar-wrap"),
    _0x30856e["append"](_0x3d8fa9, _0x3632a3),
    _0x30856e
  );
}
function _0x567c73(_0x5f3322, _0x1060a, _0x4c959a, _0x32da49) {
  const _0x636e6b = document["createElement"]("button");
  return (
    (_0x636e6b["className"] = _0x1060a),
    (_0x636e6b["textContent"] = _0x5f3322),
    (_0x636e6b["title"] = _0x4c959a),
    _0x636e6b["addEventListener"]("click", async () => {
      try {
        await _0x32da49();
      } catch (_0xe991b7) {
        (console["error"](_0xe991b7),
          _0x3807a2("Something\x20went\x20wrong.", "error"));
      }
    }),
    _0x636e6b
  );
}
function _0x1b8a06() {
  return location["hostname"]["includes"]("poshmark.ca") ? "ca" : "us";
}
async function _0x488167() {
  const _0x4fcf33 = await chrome["storage"]["local"]["get"]([
      "poshmark_min_offer_percentage",
      "enable_stock_monitor",
      "enable_price_monitor",
      "markupPrice",
      "price_trigger_threshold",
    ]),
    _0xeab478 = _0x444d1c(_0x4fcf33["poshmark_min_offer_percentage"])
      ? _0x4fcf33["poshmark_min_offer_percentage"]
      : 0.8;
  var _0x4b24e9 = _0x4fcf33["markupPrice"];
  _0x444d1c(_0x4b24e9) || (_0x4b24e9 = parseInt(_0x4b24e9, 0xa));
  const _0x5d902f = _0x444d1c(_0x4b24e9) ? _0x4b24e9 : 0x64,
    _0x5ba2b6 = !!_0x4fcf33["enable_stock_monitor"]?.["checkbox"],
    _0x1feac8 = !!_0x4fcf33["enable_price_monitor"]?.["checkbox"],
    _0x3b5cb7 = _0x444d1c(_0x4fcf33["price_trigger_threshold"])
      ? _0x4fcf33["price_trigger_threshold"]
      : 0x0,
    _0x2437ca = document["createElement"]("div");
  _0x2437ca["className"] = "pmset-wrap\x20open";
  const _0x231e78 = document["createElement"]("div");
  ((_0x231e78["className"] = "pmset-dim"),
    (_0x231e78["onclick"] = () => _0x2437ca["remove"]()),
    _0x2437ca["appendChild"](_0x231e78));
  const _0x2bad49 = document["createElement"]("div");
  ((_0x2bad49["className"] = "pmset-panel"),
    _0x2437ca["appendChild"](_0x2bad49));
  const _0x3ea1c9 = document["createElement"]("div");
  _0x3ea1c9["className"] = "pmset-title-row";
  const _0x1ce64e = document["createElement"]("h2");
  ((_0x1ce64e["className"] = "pmset-title"),
    (_0x1ce64e["textContent"] = "Settings"));
  const _0x5672e7 = document["createElement"]("button");
  ((_0x5672e7["className"] = "pmset-close"),
    (_0x5672e7["textContent"] = "×"),
    (_0x5672e7["onclick"] = () => _0x2437ca["remove"]()),
    _0x3ea1c9["append"](_0x1ce64e, _0x5672e7),
    _0x2bad49["appendChild"](_0x3ea1c9));
  const _0x21a563 = _0x41cd61(
    "Minimum\x20Offer\x20%\x20of\x20Price",
    "poshmark_min_offer_percentage",
    "0.8",
    "Example:\x200.8\x20=\x2080%.\x20If\x20item\x20is\x20$100,\x20lowest\x20offer\x20auto-accept\x20=\x20$80.",
    { step: "0.01", min: "0", max: "1" },
  );
  _0x21a563["querySelector"](".pmset-input")["value"] = String(_0xeab478);
  const _0x3b81fb = _0x4f6324(
    "Enable\x20Stock\x20Monitor",
    "enable_stock_monitor",
    "Turn\x20ON\x20to\x20hide\x20items\x20when\x20supplier\x20is\x20out\x20of\x20stock",
  );
  _0x3b81fb["querySelector"](".pm-switch__input")["checked"] = _0x5ba2b6;
  const _0x9320dd = _0x4f6324(
    "Enable\x20Price\x20Monitor",
    "enable_price_monitor",
    "Turn\x20ON\x20to\x20update\x20item\x20price\x20if\x20supplier\x20changes",
  );
  _0x9320dd["querySelector"](".pm-switch__input")["checked"] = _0x1feac8;
  const _0x3dc358 = _0x41cd61(
    "Markup\x20Percent\x20(%)",
    "markupPrice",
    "100",
    "Type\x20a\x20whole\x20number.\x20100%\x20makes\x20$100\x20→\x20$200.\x2070%\x20makes\x20$100\x20→\x20$170.\x20Negative\x20is\x20allowed.",
    { type: "text", pattern: "-?\x5cd+" },
  );
  _0x3dc358["querySelector"](".pmset-input")["value"] = String(_0x5d902f);
  const _0x88cc02 = _0x41cd61(
    "Price\x20Trigger\x20Threshold",
    "price_trigger_threshold",
    "0",
    "Only\x20update\x20price\x20if\x20the\x20difference\x20is\x20bigger\x20than\x20this\x20number.",
    { step: "1" },
  );
  ((_0x88cc02["querySelector"](".pmset-input")["value"] = String(_0x3b5cb7)),
    _0x2bad49["append"](_0x21a563, _0x3b81fb, _0x9320dd, _0x3dc358, _0x88cc02));
  const _0x2c04f4 = document["createElement"]("div");
  _0x2c04f4["className"] = "pmset-actions";
  const _0x42e070 = document["createElement"]("button");
  ((_0x42e070["className"] = "pm-btn"),
    (_0x42e070["textContent"] = "Cancel"),
    (_0x42e070["onclick"] = () => _0x2437ca["remove"]()));
  const _0x14fc98 = document["createElement"]("button");
  ((_0x14fc98["className"] = "pm-btn\x20pm-btn-primary"),
    (_0x14fc98["textContent"] = "Save"),
    (_0x14fc98["onclick"] = async () => {
      const _0x28ea79 = _0x2437ca["querySelectorAll"]("[data-key]"),
        _0x5945e7 = {};
      for (const _0xf5c4b8 of _0x28ea79) {
        const _0x203bb6 = _0xf5c4b8["dataset"]["key"];
        if ("checkbox" === _0xf5c4b8["type"]) {
          _0x5945e7[_0x203bb6] = { checkbox: _0xf5c4b8["checked"] };
          continue;
        }
        if ("markupPrice" === _0x203bb6) {
          const _0x450fc0 = (_0xf5c4b8["value"] || "")["trim"]();
          if (!/^-?\d+$/["test"](_0x450fc0)) {
            alert(
              "Markup\x20Percent\x20must\x20be\x20a\x20whole\x20number\x20(e.g.,\x20-100,\x200,\x2070,\x20400).",
            );
            return;
          }
          _0x5945e7[_0x203bb6] = parseInt(_0x450fc0, 0xa);
          continue;
        }
        if ("poshmark_min_offer_percentage" === _0x203bb6) {
          let _0x33e9b2 = parseFloat(_0xf5c4b8["value"]);
          (Number["isFinite"](_0x33e9b2) || (_0x33e9b2 = 0.8),
            (_0x5945e7[_0x203bb6] = Math["min"](
              0x1,
              Math["max"](0x0, _0x33e9b2),
            )));
          continue;
        }
        let _0x169b43 = parseFloat(_0xf5c4b8["value"]);
        _0x5945e7[_0x203bb6] = Number["isFinite"](_0x169b43) ? _0x169b43 : 0x0;
      }
      (await chrome["storage"]["local"]["set"](_0x5945e7),
        _0x2437ca["remove"](),
        _0x3807a2("Settings\x20saved", "ok"));
    }),
    _0x2c04f4["append"](_0x42e070, _0x14fc98),
    _0x2bad49["appendChild"](_0x2c04f4),
    document["body"]["appendChild"](_0x2437ca));
}
function _0x41cd61(_0x338f65, _0x16a5a4, _0x415fcb, _0x336d4e, _0x86f779 = {}) {
  const _0x373435 = document["createElement"]("div");
  _0x373435["className"] = "pmset-field";
  const _0x36025f = document["createElement"]("label");
  ((_0x36025f["className"] = "pmset-label"),
    (_0x36025f["textContent"] = _0x338f65));
  const _0x19cd57 = document["createElement"]("input");
  ((_0x19cd57["className"] = "pmset-input"),
    (_0x19cd57["dataset"]["key"] = _0x16a5a4),
    (_0x19cd57["placeholder"] = _0x415fcb),
    Object["assign"](_0x19cd57, _0x86f779));
  const _0x245d88 = document["createElement"]("p");
  return (
    (_0x245d88["className"] = "pmset-help"),
    (_0x245d88["textContent"] = _0x336d4e),
    _0x373435["append"](_0x36025f, _0x19cd57, _0x245d88),
    _0x373435
  );
}
function _0x4f6324(_0x39c526, _0x309b64, _0x436d5c) {
  const _0x379b97 = document["createElement"]("div");
  _0x379b97["className"] = "pmset-field";
  const _0x4264c8 = document["createElement"]("div");
  _0x4264c8["className"] = "pmset-toggle-row";
  const _0x4f68b6 = document["createElement"]("div");
  _0x4f68b6["className"] = "pm-switch";
  const _0x1bfee8 = document["createElement"]("input");
  ((_0x1bfee8["className"] = "pm-switch__input"),
    (_0x1bfee8["type"] = "checkbox"),
    (_0x1bfee8["dataset"]["key"] = _0x309b64));
  const _0x31262b = document["createElement"]("div");
  _0x31262b["className"] = "pm-switch__track";
  const _0x2a307a = document["createElement"]("div");
  ((_0x2a307a["className"] = "pm-switch__knob"),
    _0x31262b["appendChild"](_0x2a307a),
    _0x4f68b6["append"](_0x1bfee8, _0x31262b));
  const _0x20b6e4 = document["createElement"]("label");
  ((_0x20b6e4["className"] = "pmset-label\x20pmset-label--inline"),
    (_0x20b6e4["textContent"] = _0x39c526),
    _0x4264c8["append"](_0x4f68b6, _0x20b6e4));
  const _0x5a7e55 = document["createElement"]("p");
  return (
    (_0x5a7e55["className"] = "pmset-help"),
    (_0x5a7e55["textContent"] = _0x436d5c),
    _0x379b97["append"](_0x4264c8, _0x5a7e55),
    _0x379b97
  );
}
function _0x3807a2(_0x2e20e5, _0x90b24c = "ok") {
  const _0x44b756 = document["createElement"]("div");
  ((_0x44b756["className"] = "small-note\x20" + _0x90b24c),
    (_0x44b756["textContent"] = _0x2e20e5),
    document["body"]["appendChild"](_0x44b756),
    setTimeout(() => _0x44b756["classList"]["add"]("show"), 0xa),
    setTimeout(() => {
      (_0x44b756["classList"]["remove"]("show"),
        setTimeout(() => _0x44b756["remove"](), 0x12c));
    }, 0x7d0));
}
function _0x444d1c(_0x475b8f) {
  return "number" == typeof _0x475b8f && Number["isFinite"](_0x475b8f);
}
(chrome["runtime"]["onMessage"]["addListener"](
  (_0x548c0e, _0x23b560, _0x37fe08) => {
    ("share_all_items" === _0x548c0e["type"] && _0x3131a4(),
      "turn_offers_on" === _0x548c0e["type"] && _0x3131a4("offers_on"),
      "turn_offers_off" === _0x548c0e["type"] && _0x3131a4("offers_off"));
  },
),
  document["addEventListener"]("DOMContentLoaded", async () => {
    (await _0x57b893(), _0x2c001e(), _0x3a5873());
  }));
function _0x3a6b55() {
  if (document["getElementById"]("es-control-bar")) return;
  const _0x5112e1 = _0x115461();
  _0x5112e1["querySelector"](".control-bar")["id"] = "es-control-bar";
  const _0x543c3a = document["querySelector"](
    ".closet__header__info__user-details__actions",
  );
  if (_0x543c3a) {
    const _0x1f9fcd = document["createElement"]("div");
    ((_0x1f9fcd["className"] = "es-control-bar-wrap"),
      _0x1f9fcd["appendChild"](_0x5112e1),
      _0x543c3a["prepend"](_0x1f9fcd));
    return;
  }
  const _0x4cc0b2 = document["querySelector"](
    ".closet__header__info__user-details__container",
  );
  if (_0x4cc0b2 && _0x4cc0b2["parentElement"]) {
    const _0x1ba920 = document["createElement"]("div");
    ((_0x1ba920["className"] = "es-control-bar-under-tabs"),
      _0x1ba920["appendChild"](_0x5112e1),
      _0x4cc0b2["parentElement"]["insertBefore"](
        _0x1ba920,
        _0x4cc0b2["nextSibling"],
      ));
    return;
  }
  const _0xf546c8 =
    document["getElementById"]("grid-page__ss-au-ph-right-sticky") ||
    document["getElementById"]("grid-page__wss-au-ph-right-sticky");
  if (_0xf546c8) {
    const _0x2f3c75 = document["createElement"]("div");
    ((_0x2f3c75["className"] = "es-control-bar-right"),
      _0x2f3c75["appendChild"](_0x5112e1),
      _0xf546c8["classList"]["remove"]("hide"),
      _0xf546c8["appendChild"](_0x2f3c75));
    return;
  }
  document["body"]["prepend"](_0x5112e1);
}
function _0x56bf57() {
  (_0x3a6b55(),
    new MutationObserver(() => {
      document["getElementById"]("es-control-bar") || _0x3a6b55();
    })["observe"](document["documentElement"], {
      childList: !0x0,
      subtree: !0x0,
    }));
}
function _0x1fb9b9() {
  let _0x5e01f8 = location["href"];
  const _0x186434 = () => {
      _0x5e01f8 !== location["href"] &&
        ((_0x5e01f8 = location["href"]),
        document["getElementById"]("es-control-bar")
          ?.["closest"](".es-control-bar-wrap")
          ?.["remove"](),
        document["getElementById"]("es-control-bar")?.["remove"](),
        setTimeout(_0x3a6b55, 0x190));
    },
    push = history["pushState"];
  history["pushState"] = function () {
    (push["apply"](this, arguments), _0x186434());
  };
  const _0x4b9656 = history["replaceState"];
  ((history["replaceState"] = function () {
    (_0x4b9656["apply"](this, arguments), _0x186434());
  }),
    window["addEventListener"]("popstate", _0x186434));
}
function _0x3a5873() {
  if ("loading" === document["readyState"])
    document["addEventListener"]("DOMContentLoaded", () => {
      (_0x56bf57(), _0x1fb9b9());
    });
  else (_0x56bf57(), _0x1fb9b9());
}
