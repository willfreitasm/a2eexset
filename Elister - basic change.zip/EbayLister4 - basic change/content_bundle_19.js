(console["log"]("Iframe\x20content\x20script\x20is\x20running"),
  window["addEventListener"]("message", (_0x29120d) => {
    if (_0x29120d["data"] && "getDescription" === _0x29120d["data"]["action"]) {
      console["log"]("getDescription\x20from\x20iframeContentScript.js");
      var _0x230d00 = document["querySelector"]("body");
      _0x230d00["querySelectorAll"]("script")["forEach"]((_0x3d8a42) => {
        _0x3d8a42["remove"]();
      });
      var _0xb0186e = _0x230d00["querySelector"]("#closeHtml");
      _0xb0186e && _0xb0186e["remove"]();
      var _0x43467e = _0x230d00["innerHTML"];
      window["parent"]["postMessage"](
        { action: "sendDescription", descriptionHTML: _0x43467e },
        "*",
      );
    }
  }));
