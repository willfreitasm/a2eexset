class _0x28d081 {
  constructor({
    target: target = null,
    menuItems: menuItems = [],
    mode: mode = "dark",
  }) {
    ((this["target"] = target),
      (this["menuItems"] = menuItems),
      (this["mode"] = mode),
      (this["targetNode"] = this["getTargetNode"]()),
      (this["menuItemsNode"] = this["getMenuItemsNode"]()),
      (this["isOpened"] = !0x1),
      (this["menuContainer"] = null));
  }
  ["getTargetNode"]() {
    const _0x5b7c18 = document["querySelectorAll"](this["target"]);
    if (_0x5b7c18 && 0x0 !== _0x5b7c18["length"]) return _0x5b7c18;
    return (
      console["error"](
        "getTargetNode\x20::\x20\x22" +
          this["target"] +
          "\x22\x20target\x20not\x20found",
      ),
      []
    );
  }
  ["getMenuItemsNode"]() {
    const _0xce981e = [];
    if (!this["menuItems"])
      return (
        console["error"](
          "getMenuItemsNode\x20::\x20Please\x20enter\x20menu\x20items",
        ),
        []
      );
    return (
      console["log"]("this.menuItems", this["menuItems"]),
      this["menuItems"]["forEach"]((_0x251a84, _0x8c6b91) => {
        const _0x5443b6 = this["createItemMarkup"](_0x251a84);
        (_0x5443b6["firstChild"]["setAttribute"](
          "style",
          "animation-delay:\x20" + 0.08 * _0x8c6b91 + "s",
        ),
          _0xce981e["push"](_0x5443b6));
      }),
      _0xce981e
    );
  }
  ["createItemMarkup"](_0x841b12) {
    const _0x43fc72 = document["createElement"]("BUTTON"),
      _0x2a2097 = document["createElement"]("LI");
    return (
      (_0x43fc72["innerHTML"] = _0x841b12["content"]),
      _0x43fc72["classList"]["add"]("contextMenu-button"),
      _0x841b12["selected"] && _0x43fc72["classList"]["add"]("selected"),
      _0x2a2097["classList"]["add"]("contextMenu-item"),
      _0x841b12["divider"] &&
        _0x2a2097["setAttribute"]("data-divider", _0x841b12["divider"]),
      _0x2a2097["appendChild"](_0x43fc72),
      _0x841b12["events"] &&
        0x0 !== _0x841b12["events"]["length"] &&
        Object["entries"](_0x841b12["events"])["forEach"]((_0x233d38) => {
          const [_0x329549, _0x809483] = _0x233d38;
          _0x43fc72["addEventListener"](_0x329549, _0x809483);
        }),
      _0x2a2097
    );
  }
  ["renderMenu"]() {
    (console["log"]("rendering\x20menu", this["menuItemsNode"]),
      (this["menuItemsNode"] = this["getMenuItemsNode"]()));
    const _0x466dad = document["createElement"]("UL");
    return (
      _0x466dad["classList"]["add"]("contextMenu"),
      _0x466dad["setAttribute"]("data-theme", this["mode"]),
      this["menuItemsNode"]["forEach"]((_0xae038a) =>
        _0x466dad["appendChild"](_0xae038a),
      ),
      _0x466dad
    );
  }
  ["closeMenu"](_0x1b4b8f) {
    this["isOpened"] && ((this["isOpened"] = !0x1), _0x1b4b8f["remove"]());
  }
  ["init"]() {
    (document["addEventListener"]("click", () =>
      this["closeMenu"](this["menuContainer"]),
    ),
      window["addEventListener"]("blur", () =>
        this["closeMenu"](this["menuContainer"]),
      ),
      this["targetNode"]["forEach"]((_0x185a0a) => {
        _0x185a0a["addEventListener"]("contextmenu", (_0x47eb04) => {
          (console["log"]("this.menuContainer", this["menuContainer"]),
            (this["menuContainer"] = this["renderMenu"]()),
            _0x47eb04["preventDefault"](),
            console["log"]("this.menuContainer", this["menuContainer"]),
            (this["isOpened"] = !0x0));
          const { clientX: _0x8ed5dd, clientY: _0x82608a } = _0x47eb04;
          document["body"]["appendChild"](this["menuContainer"]);
          const _0x533603 =
              _0x82608a + this["menuContainer"]["scrollHeight"] >=
              window["innerHeight"]
                ? window["innerHeight"] -
                  this["menuContainer"]["scrollHeight"] -
                  0x14
                : _0x82608a,
            _0xcb635a =
              _0x8ed5dd + this["menuContainer"]["scrollWidth"] >=
              window["innerWidth"]
                ? window["innerWidth"] -
                  this["menuContainer"]["scrollWidth"] -
                  0x14
                : _0x8ed5dd;
          this["menuContainer"]["setAttribute"](
            "style",
            "--width:\x20" +
              this["menuContainer"]["scrollWidth"] +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--height:\x20" +
              this["menuContainer"]["scrollHeight"] +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--top:\x20" +
              _0x533603 +
              "px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--left:\x20" +
              _0xcb635a +
              "px;",
          );
        });
      }));
  }
}
function _0xb326a3(_0x3b30eb, _0x131972, _0x5d84b4) {
  (_0x3b30eb["forEach"]((_0x13c69e) => {
    _0x13c69e["id"] === _0x131972 && (_0x13c69e["selected"] = !0x1);
  }),
    _0x3b30eb["forEach"]((_0x220d6b) => {
      _0x220d6b["id"] === _0x131972 &&
        _0x220d6b["value"] === _0x5d84b4 &&
        (_0x220d6b["selected"] = !0x0);
    }),
    console["log"]("updateContextMenu", _0x3b30eb));
}
function _0x2993cf(_0x34711e) {
  var _0x130be0 = document["createElement"]("div");
  ((_0x130be0["id"] = _0x34711e),
    (_0x130be0["className"] = "custom-context-menu"));
  var _0xcdfc46 = [];
  function _0x2931a1() {
    (_0x130be0 &&
      ((_0x130be0["style"]["display"] = "none"), _0x130be0["remove"]()),
      document["removeEventListener"]("click", _0x2931a1));
  }
  return {
    addMenuItem: function (_0x1d0986, _0x1a505d) {
      var _0x4ec98b = document["createElement"]("div");
      ((_0x4ec98b["className"] = "context-menu-item"),
        (_0x4ec98b["textContent"] = _0x1d0986),
        _0x4ec98b["addEventListener"]("click", function (_0x74c6f5) {
          (_0x1a505d(_0x74c6f5), _0x2931a1());
        }),
        _0x130be0["appendChild"](_0x4ec98b),
        _0xcdfc46["push"](_0x4ec98b));
    },
    showMenu: function (_0x3495e9) {
      _0x3495e9["preventDefault"]();
      var _0x253533 = document["getElementById"](_0x34711e);
      (_0x253533 && _0x253533["remove"](),
        document["body"]["appendChild"](_0x130be0),
        (_0x130be0["style"]["left"] = _0x3495e9["pageX"] + "px"),
        (_0x130be0["style"]["top"] = _0x3495e9["pageY"] + "px"),
        (_0x130be0["style"]["display"] = "block"),
        _0x130be0["addEventListener"]("click", function (_0x55d542) {
          _0x55d542["stopPropagation"]();
        }),
        document["addEventListener"]("click", _0x2931a1));
    },
    hideMenu: _0x2931a1,
    id: _0x34711e,
    element: _0x130be0,
  };
}
async function _0x57faf8(_0x13d4fa) {
  if (_0x3a53c6(_0x13d4fa))
    return (
      console["log"]("Custom\x20view\x20settings\x20are\x20not\x20applied"),
      !0x0
    );
  await _0x4cbbb7();
  for (const _0x2435ff of _0x13d4fa) {
    (await _0x2289aa(_0x2435ff, !0x0),
      console["log"](
        "Toggled\x20" + _0x2435ff + "\x20on,\x20waiting\x204\x20seconds",
      ),
      await new Promise((_0x21828d) => setTimeout(_0x21828d, 0xfa0)));
  }
  return (
    console["log"](
      "Waiting\x2010\x20seconds\x20for\x20the\x20page\x20to\x20update",
    ),
    await new Promise((_0x2a68b6) => setTimeout(_0x2a68b6, 0x1388)),
    _0x23f253(),
    console["log"]("Custom\x20view\x20settings\x20are\x20applied"),
    !0x0
  );
}
async function _0x4cbbb7() {
  const _0x2ca512 = document["querySelector"]("button.customize-link");
  if (!_0x2ca512) {
    console["error"]("Customize\x20button\x20not\x20found");
    throw new Error("Customize\x20button\x20not\x20found");
  }
  _0x2ca512["click"]();
  let _0x31cf81 = null;
  for (; !_0x31cf81; ) {
    (await new Promise((_0x9d5b1a) => setTimeout(_0x9d5b1a, 0xbb8)),
      (_0x31cf81 = document["querySelector"]("#listings-customization-dialog")),
      _0x31cf81 ||
        console["log"](
          "Could\x20not\x20find\x20customizationDialog,\x20trying\x20again\x20in\x203\x20seconds",
        ));
  }
  return (console["log"]("customizationDialog", _0x31cf81), _0x31cf81);
}
async function _0x2289aa(_0x4c3e22 = "Item\x20number", _0xc9ea71 = !0x0) {
  const _0x737d4a = document["querySelectorAll"](
    "input[name=\x22customize-check\x22]",
  );
  let _0x8aa626 = null;
  for (const _0x157748 of _0x737d4a) {
    const _0x34cc55 = _0x157748["getAttribute"]("data-text");
    if (
      Array["isArray"](_0x4c3e22)
        ? _0x4c3e22["includes"](_0x34cc55)
        : _0x34cc55 === _0x4c3e22
    ) {
      _0x8aa626 = _0x157748;
      break;
    }
  }
  if (!_0x8aa626) return !0x1;
  if (_0x8aa626["checked"] === _0xc9ea71) return !0x0;
  return (_0x8aa626["focus"](), _0x8aa626["click"](), !0x0);
}
function _0x23f253() {
  console["log"]("Saving\x20custom\x20view\x20settings");
  var _0x57e7a0 = document["querySelector"]("#customize-save");
  if (!_0x57e7a0)
    return (console["error"]("Save\x20button\x20not\x20found"), !0x1);
  return (_0x57e7a0["click"](), !0x0);
}
function _0x3a53c6(_0x4699c0) {
  var _0x9032cc = document["querySelector"](".header-row");
  if (!_0x9032cc)
    return (console["error"]("Header\x20row\x20not\x20found"), !0x1);
  var _0x25d926 = _0x9032cc["querySelectorAll"]("th"),
    _0xc67c6d = new Set();
  for (var _0x2be147 of _0x25d926) {
    var _0x313024 = _0x2be147["querySelectorAll"](".th-title-content");
    if (0x0 !== _0x313024["length"]) {
      var _0x51f7e9 =
        _0x313024[_0x313024["length"] - 0x1]["textContent"]["trim"]();
      _0xc67c6d["add"](_0x51f7e9);
    }
  }
  console["log"]("displayedHeaders:", Array["from"](_0xc67c6d));
  const _0xfb326f = [];
  for (const _0x2bcaae of _0x4699c0)
    Array["isArray"](_0x2bcaae)
      ? _0x2bcaae["some"]((_0x458ab6) => _0xc67c6d["has"](_0x458ab6)) ||
        _0xfb326f["push"](_0x2bcaae)
      : _0xc67c6d["has"](_0x2bcaae) || _0xfb326f["push"](_0x2bcaae);
  if (_0xfb326f["length"] > 0x0)
    return (console["log"]("Missing\x20options:", _0xfb326f), !0x1);
  return !0x0;
}
async function _0xacfb0d(_0x2f1e43) {
  if (_0x5c9661(_0x2f1e43))
    return (
      console["log"](
        "All\x20desired\x20fields\x20are\x20already\x20checked—no\x20action\x20needed.",
      ),
      !0x0
    );
  await _0x4c2ac2();
  for (const _0x1fe4ba of _0x2f1e43) {
    (await _0x3cb867(_0x1fe4ba["nameAttr"], _0x1fe4ba["valueAttr"], !0x0),
      await new Promise((_0x360b0c) => setTimeout(_0x360b0c, 0x1f4)));
  }
  return (
    console["log"](
      "Waiting\x202\x20seconds\x20before\x20applying\x20changes...",
    ),
    await new Promise((_0x24b395) => setTimeout(_0x24b395, 0x7d0)),
    _0x77f1b3(),
    console["log"](
      "Search\x20page\x20custom\x20view\x20settings\x20applied\x20successfully.",
    ),
    !0x0
  );
}
function _0x5c9661(_0x4d2fce) {
  for (const { nameAttr: _0x56a28d, valueAttr: _0x59e863 } of _0x4d2fce) {
    const _0x483d0e = document["querySelector"](
      "input[type=\x22checkbox\x22][name=\x22" +
        _0x56a28d +
        "\x22][value=\x22" +
        _0x59e863 +
        "\x22]",
    );
    if (!_0x483d0e || !_0x483d0e["checked"]) return !0x1;
  }
  return !0x0;
}
async function _0x4c2ac2() {
  const _0x49f0ad = document["querySelector"](".srp-view-options__customize");
  if (!_0x49f0ad)
    throw new Error(
      "Customize\x20button\x20not\x20found\x20on\x20the\x20search\x20page.",
    );
  (_0x49f0ad["click"](),
    console["log"](
      "Clicked\x20Customize\x20button,\x20waiting\x20for\x20form\x20to\x20appear...",
    ));
  let _0x44eacf = null,
    _0x4d97d8 = 0x0;
  for (; !_0x44eacf && _0x4d97d8 < 0x5; ) {
    (await new Promise((_0x49d644) => setTimeout(_0x49d644, 0x7d0)),
      (_0x44eacf = document["querySelector"](".s-customize-form__details")),
      !_0x44eacf &&
        (_0x4d97d8++,
        console["log"](
          "Could\x20not\x20find\x20details\x20form\x20yet.\x20Attempt\x20" +
            _0x4d97d8 +
            "/5...",
        )));
  }
  if (!_0x44eacf)
    throw new Error(
      "Customize\x20form\x20did\x20not\x20appear\x20after\x20several\x20attempts.",
    );
  return (
    console["log"]("Found\x20the\x20customize\x20form:", _0x44eacf),
    _0x44eacf
  );
}
async function _0x3cb867(_0x3e2bf7, _0x2a75bb, _0x3f3304 = !0x0) {
  const _0x347210 =
      "input[type=\x22checkbox\x22][name=\x22" +
      _0x3e2bf7 +
      "\x22][value=\x22" +
      _0x2a75bb +
      "\x22]",
    _0x18ae82 = document["querySelector"](_0x347210);
  if (!_0x18ae82)
    return (
      console["error"](
        "Checkbox\x20with\x20name=\x22" +
          _0x3e2bf7 +
          "\x22\x20value=\x22" +
          _0x2a75bb +
          "\x22\x20not\x20found.",
      ),
      !0x1
    );
  if (_0x18ae82["checked"] === _0x3f3304)
    return (
      console["log"](
        "Checkbox\x20(name=" +
          _0x3e2bf7 +
          ",\x20value=" +
          _0x2a75bb +
          ")\x20is\x20already\x20in\x20desired\x20state.",
      ),
      !0x0
    );
  return (
    _0x18ae82["focus"](),
    _0x18ae82["click"](),
    console["log"](
      "Toggled\x20checkbox\x20(name=" +
        _0x3e2bf7 +
        ",\x20value=" +
        _0x2a75bb +
        ")\x20to\x20" +
        _0x3f3304 +
        ".",
    ),
    !0x0
  );
}
function _0x77f1b3() {
  const _0x3dbdab = document["querySelector"](
    ".s-customize-form__actions\x20.btn--primary",
  );
  if (!_0x3dbdab)
    return (
      console["error"](
        "Apply\x20changes\x20button\x20not\x20found\x20in\x20customize\x20form!",
      ),
      !0x1
    );
  return (
    _0x3dbdab["click"](),
    console["log"](
      "Clicked\x20\x27Apply\x20changes\x27\x20to\x20save\x20the\x20search\x20page\x20customizations.",
    ),
    !0x0
  );
}
async function _0x5ac301() {
  await _0xacfb0d([
    { nameAttr: "_fcse", valueAttr: "1" },
    { nameAttr: "_fcie", valueAttr: "1" },
  ]);
}
function _0x32ffde(
  _0x30abd7 = null,
  _0x4fbc36 = null,
  _0x1927c4 = null,
  _0x28861e = null,
) {
  var _0x5a86e4 = document["createElement"]("a");
  (_0x5a86e4["setAttribute"]("class", "a-link-text"),
    _0x5a86e4["classList"]["add"]("icon"),
    _0x5a86e4["classList"]["add"]("amazonSearchLink"),
    _0x5a86e4["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x1a0214 = document["createElement"]("img");
  return (
    _0x1a0214["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x1a0214["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5a86e4["appendChild"](_0x1a0214),
    _0x5a86e4["addEventListener"]("click", async function (_0x46880a) {
      (_0x46880a["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x30abd7) {
        var _0x5d28c3 = _0x3367f2(_0x46880a);
        if (!_0x5d28c3) return;
        var _0x391671 = _0x120abc(_0x5d28c3);
        ((_0x30abd7 = _0x391671["title"])["endsWith"]("...") &&
          (_0x30abd7 = _0x30abd7["substring"](
            0x0,
            _0x30abd7["lastIndexOf"]("\x20"),
          )),
          _0x30abd7["length"] > 0x4b &&
            (_0x30abd7 = _0x30abd7["substring"](
              0x0,
              _0x30abd7["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x3ac348 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x3ac348),
        _0x3ac348 || (_0x3ac348 = "reviews"),
        console["log"]("amazonSortType", _0x3ac348),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x3fc6e1 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x30abd7["length"] > 0x50; )
        _0x30abd7 = _0x30abd7["substring"](
          0x0,
          _0x30abd7["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x48bd9a } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x4c1697 = _0x30abd7;
      "keywords" == _0x48bd9a && (_0x4c1697 = await _0x541d06(_0x30abd7));
      try {
        _0x391671 = _0x120abc(_0x5d28c3);
      } catch (_0x16f631) {
        console["log"]("error", _0x16f631);
      }
      (_0x391671 ||
        (_0x391671 = {
          title: _0x30abd7,
          price: _0x4fbc36,
          itemNumber: _0x1927c4,
          image: _0x28861e,
        }),
        console["log"]("itemData", _0x391671),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x4c1697,
          options: { isTabActive: !0x0, sort: _0x3ac348 },
          itemData: _0x391671,
        }));
    }),
    _0x5a86e4
  );
}
function _0x4ebc63(_0x261dc8) {
  var _0x3fc2c8 = document["createElement"]("a");
  (_0x3fc2c8["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x3fc2c8["setAttribute"]("class", "a-link-text"),
    _0x3fc2c8["classList"]["add"]("icon"),
    _0x3fc2c8["classList"]["add"]("amazonSearchLink"),
    _0x3fc2c8["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x2d47ae = document["createElement"]("img");
  return (
    _0x2d47ae["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x2d47ae["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3fc2c8["appendChild"](_0x2d47ae),
    _0x3fc2c8["addEventListener"]("click", async function (_0x234ace) {
      (_0x234ace["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x261dc8),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x261dc8,
        }));
    }),
    _0x3fc2c8
  );
}
function _0x3e0ca8(_0x47d581) {
  var _0x4c66e9 = document["createElement"]("a");
  (_0x4c66e9["setAttribute"]("id", "amazonLink"),
    _0x4c66e9["setAttribute"]("class", "a-link-text"),
    _0x4c66e9["classList"]["add"]("icon"),
    _0x4c66e9["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x477ba1 = document["createElement"]("img");
  return (
    _0x477ba1["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x477ba1["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4c66e9["appendChild"](_0x477ba1),
    _0x4c66e9["addEventListener"]("click", async function (_0x1ddb85) {
      (_0x1ddb85["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x58d2a2 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x23f2e9 =
          "https://www.amazon." +
          _0x58d2a2 +
          "/dp/" +
          _0x47d581 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x23f2e9 });
    }),
    _0x4c66e9
  );
}
function _0x32bbca(_0x3473a8) {
  var _0x142ab0 = document["createElement"]("a");
  (_0x142ab0["setAttribute"]("id", "amazonLink"),
    _0x142ab0["setAttribute"]("class", "a-link-text"),
    _0x142ab0["classList"]["add"]("icon"),
    _0x142ab0["classList"]["add"]("amazonLink"),
    _0x142ab0["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0xa80389 = document["createElement"]("img");
  return (
    _0xa80389["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0xa80389["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x142ab0["appendChild"](_0xa80389),
    _0x142ab0["addEventListener"]("click", async function (_0x25dfd8) {
      (_0x25dfd8["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0x3473a8(_0x25dfd8);
      } catch (_0x149411) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0x149411);
      }
    }),
    _0x142ab0
  );
}
function _0x29233b(
  _0x51ef96 = null,
  _0x536db4,
  _0x483de1 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x51ef96, _0x536db4);
  var _0x3fc69e = document["createElement"]("a");
  (_0x3fc69e["setAttribute"]("id", "ebayLink"),
    _0x3fc69e["setAttribute"]("class", "a-link-text"),
    _0x3fc69e["classList"]["add"]("icon"),
    _0x536db4 && _0x536db4["soldItems"]
      ? _0x3fc69e["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x3fc69e["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x4e45d3 = document["createElement"]("img");
  return (
    _0x4e45d3["setAttribute"]("src", chrome["runtime"]["getURL"](_0x483de1)),
    _0x4e45d3["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3fc69e["appendChild"](_0x4e45d3),
    _0x3fc69e["addEventListener"]("click", async function (_0x238815) {
      (_0x238815["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x51ef96) console["log"]("title\x20found", _0x51ef96);
      else {
        console["log"]("title\x20not\x20found");
        var _0x284d4c = _0x3367f2(_0x238815);
        if (!_0x284d4c) return;
        var _0x1f0cd0 = _0x120abc(_0x284d4c);
        _0x51ef96 = _0x1f0cd0["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x336a7f } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x51ef96["length"] > 0x50; )
        _0x51ef96 = _0x51ef96["substring"](
          0x0,
          _0x51ef96["lastIndexOf"]("\x20"),
        );
      var _0x8f3dda =
        "https://www.ebay." +
        _0x336a7f +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x51ef96) +
        "&_odkw=" +
        encodeURIComponent(_0x51ef96);
      (_0x536db4 && _0x536db4["soldItems"] && (_0x8f3dda += "&LH_Sold=1"),
        _0x536db4 && _0x536db4["sortLowToHigh"] && (_0x8f3dda += "&_sop=15"),
        _0x536db4 && _0x536db4["endedRecently"] && (_0x8f3dda += "&_sop=13"),
        (_0x8f3dda += "&LH_ItemCondition=1000"),
        (_0x8f3dda += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x8f3dda,
        }));
    }),
    _0x3fc69e
  );
}
function _0x3806a7(_0x48c0a6 = null) {
  var _0x34cd3f = document["createElement"]("a");
  (_0x34cd3f["setAttribute"]("id", "googleLink"),
    _0x34cd3f["setAttribute"]("class", "a-link-text"),
    _0x34cd3f["classList"]["add"]("icon"),
    _0x34cd3f["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x191390 = document["createElement"]("img");
  return (
    _0x191390["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x191390["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x34cd3f["appendChild"](_0x191390),
    _0x34cd3f["addEventListener"]("click", async function (_0x2c347e) {
      (_0x2c347e["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x48c0a6) {
        var _0x45ba0e = _0x3367f2(_0x2c347e);
        if (!_0x45ba0e) return;
        var _0x24ffd4 = _0x120abc(_0x45ba0e);
        _0x48c0a6 = _0x24ffd4["image"];
      }
      var { domain: _0x5bac15 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x512972(_0x5bac15),
        encodeURIComponent(_0x48c0a6),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x48c0a6,
        }));
    }),
    _0x34cd3f
  );
}
function _0x23681f(_0x3edb84 = null) {
  var _0x5edbfb = document["createElement"]("a");
  (_0x5edbfb["setAttribute"]("id", "googleLink"),
    _0x5edbfb["setAttribute"]("class", "a-link-text"),
    _0x5edbfb["classList"]["add"]("icon"),
    _0x5edbfb["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x4b669b = document["createElement"]("img");
  return (
    _0x4b669b["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x4b669b["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5edbfb["appendChild"](_0x4b669b),
    _0x5edbfb["addEventListener"]("click", async function (_0x51c1c4) {
      (_0x51c1c4["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x3edb84) {
        var _0x3f6f2d = _0x3367f2(_0x51c1c4);
        if (!_0x3f6f2d) return;
        var _0x1cfd90 = _0x120abc(_0x3f6f2d);
        _0x3edb84 = _0x1cfd90["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x3edb84,
      });
    }),
    _0x5edbfb
  );
}
function _0x5e04db(_0x502ac7) {
  var _0xeb6cdc = document["createElement"]("a");
  (_0xeb6cdc["setAttribute"]("id", "lookUpSkuLink"),
    _0xeb6cdc["setAttribute"]("class", "a-link-text"),
    _0xeb6cdc["classList"]["add"]("icon"),
    _0xeb6cdc["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x1f2ba9 = document["createElement"]("img");
  return (
    _0x1f2ba9["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x1f2ba9["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xeb6cdc["appendChild"](_0x1f2ba9),
    _0xeb6cdc["addEventListener"]("click", async function (_0x26da49) {
      (_0x26da49["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x11b894 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x4daca6 =
          "https://www.amazon." +
          _0x11b894 +
          "/dp/" +
          _0x502ac7 +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x4daca6,
        options: { active: !0x0 },
      });
    }),
    _0xeb6cdc
  );
}
function _0x4124e1(_0x4e1ba6 = null) {
  var _0x455311 = document["createElement"]("a");
  (_0x455311["setAttribute"]("id", "productHunterLink"),
    _0x455311["setAttribute"]("class", "a-link-text"),
    _0x455311["classList"]["add"]("icon"),
    _0x455311["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x4c2030 = document["createElement"]("img");
  return (
    _0x4c2030["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x4c2030["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x455311["appendChild"](_0x4c2030),
    _0x455311["addEventListener"]("click", async function (_0xe2d502) {
      (_0xe2d502["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x4e1ba6) {
        var _0x49556a = _0x3367f2(_0xe2d502);
        if (!_0x49556a) return;
        var _0x1a928f = _0x120abc(_0x49556a);
        _0x4e1ba6 = _0x1a928f["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x4e1ba6),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x4e1ba6,
        }));
    }),
    _0x455311
  );
}
function _0x512972(_0x5a5b96) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x5a5b96] || "en-US";
}
function _0x53b7e2(_0x47e540 = null) {
  console["log"]("createSearchTerapeakButton", _0x47e540);
  var _0x5c53c6 = document["createElement"]("a");
  (_0x5c53c6["setAttribute"]("class", "a-link-text"),
    _0x5c53c6["classList"]["add"]("terapeakLink"),
    _0x5c53c6["classList"]["add"]("icon"),
    _0x5c53c6["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x47e540 && _0x5c53c6["setAttribute"]("item_title", _0x47e540));
  var _0x17e066 = document["createElement"]("img");
  return (
    _0x17e066["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x17e066["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5c53c6["appendChild"](_0x17e066),
    _0x5c53c6["addEventListener"]("click", async function (_0x591259) {
      (_0x591259["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x3e57bb = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x3e57bb),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x3e57bb) {
        var _0x321739 = _0x3367f2(_0x591259);
        if (!_0x321739) return;
        _0x3e57bb = _0x120abc(_0x321739)["title"];
      }
      console["log"]("title", _0x3e57bb);
      var { convertToKeywords: _0x2309ab } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x2309ab) var _0x3e57bb = await _0x541d06(_0x3e57bb);
      var { domain: _0x29e2ca } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x59f4ad = _0xb836f0(_0x3e57bb, _0x29e2ca);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x59f4ad });
    }),
    _0x5c53c6
  );
}
async function _0x541d06(_0x41f5dc) {
  var _0x30f90d = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x1f44f5) => _0x1f44f5["json"]());
  ((_0x30f90d["user_input"] = _0x41f5dc),
    console["log"]("jsonPrompt", _0x30f90d));
  var _0x17f883 = await new Promise((_0xd5355f, _0x12c20d) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x30f90d,
      },
      function (_0x4d679b) {
        _0xd5355f(_0x4d679b["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x17f883),
    (_0x17f883 = JSON["parse"](_0x17f883))["output"]
  );
}
function _0xb836f0(
  _0x3f0146,
  _0x1d4157 = "ca",
  _0x14626b = 0x1e,
  _0x5cbed0 = 0x0,
  _0x46eadf = 0x0,
  _0x3ad313 = 0x32,
  _0x48b6fb = "-itemssold",
  _0x48a16e = "SOLD",
  _0x4de75c = "EBAY-CA",
  _0x531c65 = "America/Toronto",
  _0x1528e5 = "BuyerLocation:::CA",
  _0x1e87ee = 0x0,
) {
  _0x4de75c = "";
  switch (_0x1d4157) {
    case "ca":
    default:
      _0x4de75c = "EBAY-CA";
      break;
    case "com":
      _0x4de75c = "EBAY-US";
      break;
    case "co.uk":
      _0x4de75c = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x1d4157 +
    "/sh/research?" +
    [
      "keywords=" + _0x3f0146,
      "dayRange=" + _0x14626b,
      "categoryId=" + _0x5cbed0,
      "offset=" + _0x46eadf,
      "limit=" + _0x3ad313,
      "sorting=" + _0x48b6fb,
      "tabName=" + _0x48a16e,
      "marketplace=" + _0x4de75c,
      "tz=" + encodeURIComponent(_0x531c65),
      "minPrice=" + _0x1e87ee,
    ]["join"]("&")
  );
}
async function _0x16ee80(_0xfec91a) {
  var { domain: _0x221a0a } = await chrome["storage"]["local"]["get"]("domain"),
    _0x308f4a =
      "https://www.ebay." +
      _0x221a0a +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0xfec91a +
      "&store_name=" +
      _0xfec91a +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x308f4a });
}
async function _0x1cfac0(_0x57f3cb) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x57f3cb,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x57f3cb));
}
async function _0x36a9f2(_0x5beff1) {
  var { response: _0x5ab295 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x5beff1,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x5ab295), _0x5ab295);
}
function _0x2901fc(_0x289b7e = null) {
  console["log"]("createOpenSellerItemsButton", _0x289b7e);
  var _0x54ae38 = document["createElement"]("a");
  (_0x54ae38["setAttribute"]("id", "sellerItemsLink"),
    _0x54ae38["setAttribute"]("class", "a-link-text"),
    _0x54ae38["classList"]["add"]("icon"),
    _0x54ae38["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x3b2f79 = document["createElement"]("img");
  return (
    _0x3b2f79["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x3b2f79["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x54ae38["appendChild"](_0x3b2f79),
    _0x54ae38["addEventListener"]("click", async function (_0x1c9c80) {
      (_0x1c9c80["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x289b7e),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x289b7e));
      var _0x5bc6b3;
      if (!_0x289b7e) {
        console["log"]("username\x20not\x20found");
        var _0x40391c = _0x3367f2(_0x1c9c80);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x40391c,
        );
        if (!_0x40391c) return;
        var _0x7986b8 = _0x120abc(_0x40391c);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x7986b8,
        ),
          (_0x289b7e = _0x7986b8["username"]),
          (_0x5bc6b3 = _0x7986b8["itemNumber"]));
      }
      if (
        _0x289b7e["includes"]("\x20") ||
        _0x289b7e !== _0x289b7e["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x289b7e,
        );
        if (!_0x5bc6b3) {
          if (!(_0x40391c = _0x3367f2(_0x1c9c80))) return;
          _0x5bc6b3 = (_0x7986b8 = _0x120abc(_0x40391c))["itemNumber"];
        }
        _0x1cfac0(_0x5bc6b3);
      } else
        ((_0x289b7e = _0x289b7e["toLowerCase"]()),
          console["log"]("username", _0x289b7e),
          _0x16ee80(_0x289b7e));
    }),
    _0x54ae38
  );
}
function _0x4479e9(_0x90b808) {
  for (
    ;
    _0x90b808 &&
    !_0x90b808["classList"]["contains"]("s-item") &&
    !_0x90b808["classList"]["contains"]("su-card-container");

  )
    _0x90b808 = _0x90b808["parentElement"];
  return _0x90b808;
}
function _0x3d3a7a(_0x1da56d = null) {
  var _0xf9fe67 = document["createElement"]("a");
  (_0xf9fe67["setAttribute"]("id", "purchaseHistoryLink"),
    _0xf9fe67["setAttribute"]("class", "a-link-text"),
    _0xf9fe67["classList"]["add"]("icon"),
    _0xf9fe67["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x111fae = document["createElement"]("img");
  return (
    _0x111fae["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x111fae["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xf9fe67["appendChild"](_0x111fae),
    _0xf9fe67["addEventListener"]("click", async function (_0x45ed6f) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x1da56d),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x45ed6f["preventDefault"]());
      var _0x2fb73e = _0x3367f2(_0x45ed6f);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x2fb73e,
      );
      if (_0x2fb73e) {
        var { selectedFilter: _0x3b7f20 } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x3b7f20 &&
          ((_0x3b7f20 = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x3b7f20,
          }));
        var _0x31285c = _0x3b7f20,
          _0xfa7125 = await _0x487cd7(_0x2fb73e, _0x31285c, !0x1, !0x0);
        console["log"]("totalSold", _0xfa7125);
      } else
        try {
          var _0x975a94 = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x1da56d,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x975a94),
            (_0xfa7125 = _0x975a94["totalSold"]));
        } catch (_0x755ef9) {
          (console["log"]("error", _0x755ef9), (_0xfa7125 = -0x3e7));
        }
    }),
    _0xf9fe67
  );
}
function _0x3367f2(_0x2eab8e) {
  var _0x3a4111 = _0x2eab8e["target"];
  return (
    (_0x3a4111 = _0x4479e9(_0x3a4111)),
    console["log"]("found\x20s-item", _0x3a4111),
    _0x3a4111
  );
}
function _0x1f732e(_0x3aa327 = null, _0x26308a = null, _0x3026e5 = null) {
  var _0xe5702d = document["createElement"]("a");
  (_0xe5702d["setAttribute"]("id", "copyDataLink"),
    _0xe5702d["setAttribute"]("class", "a-link-text"),
    _0xe5702d["classList"]["add"]("icon"),
    _0xe5702d["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x31552d = document["createElement"]("img");
  return (
    _0x31552d["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x31552d["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xe5702d["appendChild"](_0x31552d),
    _0xe5702d["addEventListener"]("click", async function (_0x301750) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x3aa327,
        _0x26308a,
        _0x3026e5,
      ),
        _0x301750["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x3aa327 && _0x26308a && _0x3026e5)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x3aa327,
          _0x26308a,
          _0x3026e5,
        ),
          isNaN(_0x26308a) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x26308a),
            (_0x26308a = _0x26308a["replace"](/[^0-9.]/g, ""))),
          _0x33e147(
            JSON["stringify"]({
              title: _0x3aa327,
              price: _0x26308a,
              itemNumber: _0x3026e5,
            }),
          ));
      else {
        if (!_0x3aa327 || !_0x26308a || !_0x3026e5) {
          var _0xb3079b = _0x3367f2(_0x301750);
          if (!_0xb3079b) return;
        }
        var _0x362392 = _0x120abc(_0xb3079b);
        (console["log"]("itemData", _0x362392),
          _0x33e147(JSON["stringify"](_0x362392)));
      }
    }),
    _0xe5702d
  );
}
function _0x33e147(_0x29a747) {
  var _0x57050c = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x57050c),
    (_0x57050c["value"] = _0x29a747),
    _0x57050c["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x57050c));
}
async function _0x256d7f(_0x28f7b8 = null) {
  console["log"]("price", _0x28f7b8);
  if (_0x28f7b8) {
    try {
      _0x28f7b8 = _0x28f7b8["replace"](/[^0-9.]/g, "");
    } catch (_0x239cc6) {}
    _0x28f7b8 = parseFloat(_0x28f7b8);
  }
  var _0x5b9171 = await _0x492b76(_0x28f7b8),
    _0x209749 = document["createElement"]("div");
  return (
    _0x209749["setAttribute"]("id", "breakEvenPrice"),
    _0x209749["setAttribute"]("class", "break-even-price"),
    (_0x209749["textContent"] =
      "Break-even\x20price:\x20$" + _0x5b9171["toFixed"](0x2)),
    _0x209749
  );
}
async function _0x5d9773(_0x268922) {
  var _0x735082 = !0x1,
    _0x591673 = !0x1,
    { includeCurrencyConversion: _0x591673 } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x735082 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x105222 =
    0.1325 * _0x268922 +
    0.021 * _0x268922 +
    _0x268922 * (_0x735082 ? 0.004 : 0x0) +
    0.4;
  return (_0x591673 && (_0x105222 += 0.035 * _0x268922), _0x268922 - _0x105222);
}
async function _0x492b76(_0x4050ca) {
  var { isInternational: _0x31ce34 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x595ed6 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x31ce34 || (_0x31ce34 = !0x1), _0x595ed6 || (_0x595ed6 = !0x0));
  var _0x343674 = 13.25;
  _0x595ed6 && (_0x343674 = 12.35);
  var _0xdd704d = _0x4050ca + 0.0725 * _0x4050ca,
    _0x1cf53d =
      _0xdd704d * (_0x343674 / 0x64) +
      0.4 +
      (_0x31ce34 ? 0.004 * _0xdd704d : 0x0),
    _0x166c77 =
      _0x4050ca -
      (_0x1cf53d + (_0x31ce34 ? 0.05 * _0x1cf53d : 0x0)) -
      (_0x31ce34 ? 0.035 * _0xdd704d : 0x0),
    { isUserTaxExempt: _0xb48693 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0xb48693 || (_0xb48693 = !0x1),
    _0xb48693 || (_0x166c77 /= 1.0725),
    _0x31ce34 && (_0x166c77 -= (3.5 * _0x166c77) / 0x64),
    _0x166c77
  );
}
function _0x432bb6(_0x2e2cf5 = null) {
  console["log"]("createButtonToSaveSeller", _0x2e2cf5);
  var _0x4d166b = document["createElement"]("a");
  (_0x4d166b["setAttribute"]("id", "saveSellerLink"),
    _0x4d166b["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x4d166b["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x53cb6c = document["createElement"]("img");
  return (
    _0x53cb6c["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x53cb6c["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4d166b["appendChild"](_0x53cb6c),
    _0x4d166b["addEventListener"]("click", async function (_0x5bc45c) {
      (_0x5bc45c["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0x2e2cf5));
      var _0x19f03b;
      if (!_0x2e2cf5) {
        var _0x6b4a24 = _0x3367f2(_0x5bc45c);
        if (!_0x6b4a24) return;
        var _0x281335 = _0x120abc(_0x6b4a24);
        ((_0x2e2cf5 = _0x281335["username"]),
          (_0x19f03b = _0x281335["itemNumber"]));
      }
      if (
        _0x2e2cf5["includes"]("\x20") ||
        _0x2e2cf5 !== _0x2e2cf5["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x2e2cf5,
        ),
          (_0x2e2cf5 = await _0x36a9f2(_0x19f03b)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0x2e2cf5,
          ));
      else _0x2e2cf5 = _0x2e2cf5["toLowerCase"]();
      _0x4d166b["setAttribute"]("data-seller-name", _0x2e2cf5);
      var { ebayCompetitors: _0x86d6c6 } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x51ee58 = (_0x86d6c6 = _0x86d6c6 || [])["indexOf"](_0x2e2cf5);
      console["log"]("ebayCompetitors", _0x86d6c6);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x51ee58
            ? (console["log"]("save-seller\x20clicked\x20username", _0x2e2cf5),
              _0x86d6c6["push"](_0x2e2cf5),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x53cb6c["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0x2e2cf5,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x53cb6c["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x51ee58)
            (console["log"]("remove-seller\x20clicked\x20username", _0x2e2cf5),
              _0x86d6c6["splice"](_0x51ee58, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x53cb6c["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0x2e2cf5,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x86d6c6 });
    }),
    _0x4d166b
  );
}
async function _0x46082e(_0x5ec43c, _0x5c1b2d) {
  var { ebayCompetitors: _0x161a8a } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x4bf0cb = (_0x161a8a = _0x161a8a || [])["indexOf"](_0x5c1b2d),
    _0x48a9f9 = _0x5ec43c["querySelector"]("img");
  -0x1 !== _0x4bf0cb
    ? (_0x5ec43c["classList"]["replace"]("save-seller", "remove-seller"),
      _0x48a9f9["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x5ec43c["classList"]["replace"]("remove-seller", "save-seller"),
      _0x48a9f9["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x23223e(
  _0x12e79f = null,
  _0x767289 = null,
  _0x30fe6f = null,
  _0x230b78 = !0x0,
  _0x285f4a = null,
  _0x5c014d = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x12e79f));
  var _0x3c8ca2 = _0x432bb6(_0x767289),
    _0x4de2d8 = _0x53b7e2(_0x12e79f),
    _0x4a8b26 = _0x3d3a7a(_0x285f4a),
    _0x46df87 = _0x29233b(_0x12e79f),
    _0x4abbd6 = _0x32ffde(_0x12e79f, _0x5c014d, _0x285f4a, _0x30fe6f),
    _0x53180b = _0x29233b(
      _0x12e79f,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x5b24ff = _0x3806a7(_0x30fe6f),
    _0x4d1159 = _0x23681f(_0x285f4a),
    _0x10e620 = _0x2901fc(_0x767289),
    _0xa008bf = document["createElement"]("div");
  _0xa008bf["setAttribute"]("id", "search-div");
  var _0x279dfb = document["createElement"]("label");
  ((_0x279dfb["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0xa008bf["appendChild"](_0x279dfb),
    _0xa008bf["appendChild"](_0x4abbd6),
    _0xa008bf["appendChild"](_0x46df87),
    _0xa008bf["appendChild"](_0x4de2d8),
    _0xa008bf["appendChild"](_0x5b24ff),
    _0xa008bf["appendChild"](_0x4d1159),
    _0xa008bf["appendChild"](_0x53180b),
    console["log"]("CopyDataButton", _0x12e79f, _0x5c014d, _0x285f4a));
  var _0x39267d = _0x1f732e(_0x12e79f, _0x5c014d, _0x285f4a),
    _0x2afa1d = document["createElement"]("div");
  _0x2afa1d["setAttribute"]("id", "item-buttons-div");
  var _0x23ebd7 = document["createElement"]("div");
  (_0x23ebd7["setAttribute"]("id", "main-buttons-div"),
    _0x23ebd7["appendChild"](_0x10e620),
    _0x23ebd7["appendChild"](_0x4a8b26),
    _0x23ebd7["appendChild"](_0x39267d),
    _0x23ebd7["appendChild"](_0x3c8ca2),
    _0x2afa1d["appendChild"](_0x23ebd7));
  if (_0x230b78) {
    var _0x1b768a = _0x5affb9();
    _0x2afa1d["appendChild"](_0x1b768a);
  }
  return (_0x2afa1d["appendChild"](_0xa008bf), _0x2afa1d);
}
var _0x9aaa72 = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0x2c6067) => {
        (console["log"](
          _0x2c6067,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          _0xb326a3(_0x9aaa72, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x1d45c0) => {
        (console["log"](
          _0x1d45c0,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          _0xb326a3(_0x9aaa72, "search-type", "keywords"));
      },
    },
  },
];
async function _0x54296e() {
  var { convertToKeywords: _0x343b13 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x343b13 &&
    ((_0x343b13 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    _0xb326a3(_0x9aaa72, "search-type", _0x343b13 ? "keywords" : "title"),
    new _0x28d081({ target: ".terapeakLink", menuItems: _0x9aaa72 })["init"]());
}
var _0x213d8b = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0xed008d) => {
        (console["log"](_0xed008d, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          _0xb326a3(_0x213d8b, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x46153d) => {
        (console["log"](_0x46153d, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          _0xb326a3(_0x213d8b, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x3e9d65) => {
        (console["log"](
          _0x3e9d65,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          _0xb326a3(_0x213d8b, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x262ab5) => {
        (console["log"](
          _0x262ab5,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          _0xb326a3(_0x213d8b, "search-type", "keywords"));
      },
    },
  },
];
async function _0x25dde7() {
  var { amazonSortType: _0x9a529b } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x41a846 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x41a846 &&
    ((_0x41a846 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x9a529b &&
      ((_0x9a529b = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    _0xb326a3(_0x213d8b, "sort-type", _0x9a529b),
    _0xb326a3(_0x213d8b, "search-type", _0x41a846),
    new _0x28d081({ target: ".amazonSearchLink", menuItems: _0x213d8b })[
      "init"
    ]());
}
_0x213d8b = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x10e7a5) => {
        (console["log"](_0x10e7a5, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          _0xb326a3(_0x213d8b, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x366406) => {
        (console["log"](_0x366406, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          _0xb326a3(_0x213d8b, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x35b372 = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x4930d9) => {
        (console["log"](_0x4930d9, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          _0xb326a3(_0x35b372, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3df2e2) => {
        (console["log"](_0x3df2e2, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          _0xb326a3(_0x35b372, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x531de4) => {
        (console["log"](_0x531de4, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          _0xb326a3(_0x35b372, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x1e3c30) => {
        (console["log"](_0x1e3c30, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          _0xb326a3(_0x35b372, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x48aa28) => {
        (console["log"](_0x48aa28, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          _0xb326a3(_0x35b372, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2232be) => {
        (console["log"](_0x2232be, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          _0xb326a3(_0x35b372, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x437450) => {
        (console["log"](_0x437450, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          _0xb326a3(_0x35b372, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x105800) => {
        (console["log"](_0x105800, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          _0xb326a3(_0x35b372, "filter-type", "90"));
      },
    },
  },
];
async function _0x3626e3() {
  var { selectedFilter: _0x3d090b } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x3d090b &&
    ((_0x3d090b = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    _0xb326a3(_0x35b372, "filter-type", _0x3d090b),
    new _0x28d081({ target: ".filter-date-context", menuItems: _0x35b372 })[
      "init"
    ]());
}
function _0x30748a() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x143638() {
  const _0x36cba3 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x9cc721 = 0x0;
  const _0x549e20 = () =>
    new Promise((_0x3b9f95, _0x125927) => {
      const _0x5093ea = new MutationObserver((_0x50ba43, _0x1f890b) => {
        const _0x48c281 = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x48c281 &&
          (console["log"]("Details\x20form\x20found!"),
          _0x1f890b["disconnect"](),
          _0x3b9f95(_0x48c281));
      });
      (_0x5093ea["observe"](_0x36cba3, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x5093ea["disconnect"]();
          if (_0x9cc721 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x9cc721 + 0x1) +
                "/3)",
            ),
              _0x9cc721++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x3b9f95(_0x549e20()), 0x1388));
          else
            _0x125927(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x23df5e = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x23df5e) {
    (_0x23df5e["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x549e20(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x486a01) {
      console["error"](_0x486a01["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x1220db(_0x14b46f = null, _0x4959ba = null, _0x17e005 = null) {
  var _0x4e2d4d = document["createElement"]("a");
  (_0x4e2d4d["setAttribute"]("id", "copyDataLink"),
    _0x4e2d4d["setAttribute"]("class", "a-link-text"),
    _0x4e2d4d["classList"]["add"]("icon"),
    _0x4e2d4d["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x41f833 = document["createElement"]("img");
  return (
    _0x41f833["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x41f833["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4e2d4d["appendChild"](_0x41f833),
    _0x4e2d4d["addEventListener"]("click", async function (_0x4d0f32) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x14b46f,
        _0x4959ba,
        _0x17e005,
      ),
        _0x4d0f32["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x14b46f && _0x4959ba && _0x17e005) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x14b46f,
          _0x4959ba,
          _0x17e005,
        );
        isNaN(_0x4959ba) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x4959ba),
          (_0x4959ba = _0x4959ba["replace"](/[^0-9.]/g, "")));
        var _0x216e5f = JSON["stringify"]({
          title: _0x14b46f,
          price: _0x4959ba,
          itemNumber: _0x17e005,
        });
        (_0x3dc9ca(
          (_0x589d5d = await findSimiliarProducts(_0x216e5f))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x589d5d),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x14b46f || !_0x4959ba || !_0x17e005) {
          var _0x506f75 = _0x3367f2(_0x4d0f32);
          if (!_0x506f75) return;
        }
        var _0x3e6925 = _0x120abc(_0x506f75);
        (console["log"]("itemData", _0x3e6925),
          (_0x216e5f = JSON["stringify"](_0x3e6925)));
        var _0x589d5d;
        (_0x3dc9ca(
          (_0x589d5d = await findSimiliarProducts(_0x216e5f))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x589d5d),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x4e2d4d
  );
}
async function findSimiliarProducts(_0x25b385) {
  console["log"]("findSimiliarProducts", _0x25b385);
  var _0x4c637a = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x25b385,
  });
  return (console["log"]("response", _0x4c637a), _0x4c637a["productLinks"]);
}
function _0x3dc9ca(_0x4a03cf) {
  const _0x70ffc6 = document["getElementById"]("productLinksModalOverlay");
  _0x70ffc6 && _0x70ffc6["remove"]();
  const _0x541eff = document["createElement"]("div");
  ((_0x541eff["id"] = "productLinksModalOverlay"),
    _0x541eff["classList"]["add"]("product-links-modal-overlay"));
  const _0xe710b9 = document["createElement"]("div");
  _0xe710b9["classList"]["add"]("product-links-modal");
  const _0x4f6891 = document["createElement"]("div");
  _0x4f6891["classList"]["add"]("modal-button-container");
  const _0x1bd4dc = document["createElement"]("button");
  (_0x1bd4dc["classList"]["add"]("close-button"),
    (_0x1bd4dc["innerText"] = "Close"),
    _0x1bd4dc["addEventListener"]("click", () => {
      _0x541eff["remove"]();
    }));
  const _0x213f4d = document["createElement"]("button");
  (_0x213f4d["classList"]["add"]("copy-button"),
    (_0x213f4d["innerText"] = "Copy"),
    _0x213f4d["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x4a03cf),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x493959) {
        console["error"]("Failed\x20to\x20copy:", _0x493959);
      }
    }));
  const _0x4b35d3 = document["createElement"]("h2");
  _0x4b35d3["innerText"] = "Similar\x20Product\x20Links";
  const _0x5f37b9 = document["createElement"]("textarea");
  ((_0x5f37b9["value"] = _0x4a03cf),
    _0x5f37b9["setAttribute"]("readonly", !0x0),
    (_0x5f37b9["style"]["width"] = "100%"),
    (_0x5f37b9["style"]["height"] = "300px"),
    _0x4f6891["appendChild"](_0x213f4d),
    _0x4f6891["appendChild"](_0x1bd4dc),
    _0xe710b9["appendChild"](_0x4f6891),
    _0xe710b9["appendChild"](_0x4b35d3),
    _0xe710b9["appendChild"](_0x5f37b9),
    _0x541eff["appendChild"](_0xe710b9),
    document["body"]["appendChild"](_0x541eff));
}
function _0x2fc65e(_0x346460) {
  try {
    try {
      var _0x4e77d4 = new Date(_0x346460);
      if (!isNaN(_0x4e77d4)) return _0x4e77d4;
    } catch (_0x59d34f) {}
    var _0x5c083d = _0x346460["split"](",")[0x0]
      ["trim"]()
      ["match"](/(\d+)\.? ?(\w+)[.]? ?(\d+)/);
    if (!_0x5c083d)
      return (
        console["error"]("Date\x20string\x20not\x20recognized:", _0x346460),
        null
      );
    console["log"]("match:\x20", _0x5c083d);
    const _0x496a62 = _0x5c083d[0x1],
      _0x56ef45 = _0x5c083d[0x2]["toLowerCase"](),
      _0x2cf28e = _0x5c083d[0x3],
      _0x3b9ac9 = _0x576400[_0x56ef45];
    if (!_0x3b9ac9)
      return (console["error"]("Month\x20not\x20recognized:", _0x56ef45), null);
    const _0x2e0ac9 = _0x2cf28e + "-" + _0x3b9ac9 + "-" + _0x496a62,
      _0x491aaf = new Date(_0x2e0ac9);
    if (isNaN(_0x491aaf))
      return (console["error"]("Invalid\x20date\x20parsed:", _0x2e0ac9), null);
    return _0x491aaf;
  } catch (_0x158adf) {
    return (
      console["error"]("Error\x20parsing\x20date:", _0x346460, _0x158adf),
      null
    );
  }
}
const _0x576400 = {
  gen: "01",
  genn: "01",
  feb: "02",
  febb: "02",
  mar: "03",
  apr: "04",
  mag: "05",
  magg: "05",
  giu: "06",
  lug: "07",
  ago: "08",
  set: "09",
  sett: "09",
  ott: "10",
  nov: "11",
  dic: "12",
  ene: "01",
  feb: "02",
  mar: "03",
  abr: "04",
  may: "05",
  jun: "06",
  jul: "07",
  ago: "08",
  sep: "09",
  oct: "10",
  nov: "11",
  dic: "12",
  janv: "01",
  févr: "02",
  mars: "03",
  avr: "04",
  mai: "05",
  juin: "06",
  juil: "07",
  août: "08",
  sept: "09",
  oct: "10",
  nov: "11",
  déc: "12",
  jan: "01",
  feb: "02",
  märz: "03",
  mrz: "03",
  apr: "04",
  mai: "05",
  juni: "06",
  juli: "07",
  aug: "08",
  sept: "09",
  okt: "10",
  nov: "11",
  dez: "12",
  jan: "01",
  feb: "02",
  mar: "03",
  apr: "04",
  may: "05",
  jun: "06",
  jul: "07",
  aug: "08",
  sep: "09",
  oct: "10",
  nov: "11",
  dec: "12",
};
var _0x20180c = _0x2fc65e("Aug\x2030\x202024");
console["log"](_0x20180c);
function _0x6b5361(_0x543a6b) {
  const _0x47a264 = (_0x543a6b = _0x543a6b["replace"](/[^0-9.,]/g, ""))[
      "lastIndexOf"
    ](","),
    _0x32ac3c = _0x543a6b["lastIndexOf"](".");
  return (
    (_0x543a6b =
      _0x47a264 > _0x32ac3c
        ? (_0x543a6b = _0x543a6b["replace"](/\./g, ""))["replace"](",", ".")
        : _0x543a6b["replace"](/,/g, "")),
    parseFloat(_0x543a6b)
  );
}
console["log"]("ebay/store_search/functions.js\x20loaded");
var _0x478d34 = !0x1,
  _0x49787f = 0x1f4;
function _0x108781() {
  var _0x1e4d86 = document["createElement"]("button");
  return (
    _0x1e4d86["setAttribute"]("class", "btn-extract-all"),
    (_0x1e4d86["id"] = "btn-extract-all"),
    (_0x1e4d86["innerHTML"] = "Extract\x20All\x20Titles"),
    _0x1e4d86["addEventListener"]("click", async function (_0x393b6d) {
      _0x393b6d["preventDefault"]();
      var { run_status_extract_titles: _0x823800 } = await chrome["storage"][
        "local"
      ]["get"]("run_status_extract_titles");
      if (null == _0x823800 || 0x0 == _0x823800)
        ((_0x823800 = !0x0),
          _0x1e4d86["classList"]["remove"]("btn-extract-all"),
          _0x1e4d86["classList"]["add"]("btn-stop-extract-all"),
          (_0x1e4d86["innerHTML"] = "Stop\x20Extracting\x20Titles"));
      else
        0x1 == _0x823800 &&
          (_0x1e4d86["classList"]["remove"]("btn-stop-extract-all"),
          _0x1e4d86["classList"]["add"]("btn-extract-all"),
          (_0x1e4d86["innerHTML"] = "Extract\x20All\x20Titles"),
          (_0x823800 = !0x1));
      (chrome["storage"]["local"]["set"]({
        run_status_extract_titles: _0x823800,
      }),
        console["log"]("run_status_extract_titles", _0x823800),
        _0x41fc20());
    }),
    _0x1e4d86
  );
}
async function fetchSoldDataBasedOnSelection() {
  try {
    var { selectedFetchMethod: _0x4fa8fc } = await chrome["storage"]["local"][
      "get"
    ]("selectedFetchMethod");
    ("none" == _0x4fa8fc &&
      console["log"]("No\x20fetch\x20method\x20selected."),
      "sequential" == _0x4fa8fc &&
        (console["log"]("Fetching\x20data\x20sequentially."),
        await fetchSoldDataSequentially()),
      "concurrent" == _0x4fa8fc &&
        (console["log"]("Fetching\x20data\x20concurrently."),
        await fetchSoldDataConcurrently()),
      "sequential-purchase-history" == _0x4fa8fc &&
        (console["log"](
          "Fetching\x20data\x20sequentially\x20via\x20purchase\x20history.",
        ),
        await fetchSoldDataSequentiallyViaPurchaseHistory()),
      "concurrent-purchase-history" == _0x4fa8fc &&
        (console["log"](
          "Fetching\x20data\x20concurrently\x20via\x20purchase\x20history.",
        ),
        await fetchSoldDataConcurrentlyViaPurchaseHistory()));
  } catch (_0x5b63a6) {
    console["error"](
      "An\x20error\x20occurred\x20while\x20fetching\x20sold\x20data:\x20",
      _0x5b63a6,
    );
  }
}
function _0x87b1c4() {
  var _0x181e68 = document["createElement"]("button");
  return (
    _0x181e68["setAttribute"]("class", "btn-clear-all-titles"),
    (_0x181e68["innerHTML"] = "Clear\x20Titles"),
    chrome["storage"]["local"]["get"](
      "savedEbaySearchItems",
      function (_0x25d101) {
        _0x181e68["innerHTML"] =
          "Clear\x20Titles\x20(" +
          _0x25d101["savedEbaySearchItems"]["length"] +
          ")";
      },
    ),
    _0x181e68["addEventListener"]("click", function (_0x2fcaa4) {
      (chrome["storage"]["local"]["set"]({ savedEbaySearchItems: [] }),
        (_0x181e68["innerHTML"] = "Titles\x20Cleared\x20✔️"),
        setTimeout(function () {
          _0x181e68["innerHTML"] = "Clear\x20Titles";
        }, 0xbb8));
    }),
    _0x181e68
  );
}
async function _0x41fc20() {
  console["log"]("extractAllTitles()");
  var _0x63dd3 = !0x0;
  (console["log"]("run_status_extract_titles", _0x63dd3),
    (document["title"] = "🔥\x20Extracting\x20Titles\x20🔥"));
  try {
    await fetchSoldDataBasedOnSelection();
  } catch (_0x1cf50e) {
    console["log"]("error", _0x1cf50e);
  }
  try {
    _0x5c371c();
  } catch (_0x98fdcd) {
    console["log"]("error", _0x98fdcd);
  }
  var _0x415199 = _0xeb99c9();
  console["log"]("ebaySearchItems", _0x415199);
  var { savedEbaySearchItems: _0x1049ed } = await chrome["storage"]["local"][
    "get"
  ]("savedEbaySearchItems");
  (null == _0x1049ed && (_0x1049ed = []),
    (_0x1049ed = (_0x1049ed = _0x1049ed["concat"](_0x415199))["filter"](
      (_0x11f813, _0x3ba617, _0x1c6380) =>
        _0x1c6380["findIndex"](
          (_0x32ccc9) => _0x32ccc9["title"] === _0x11f813["title"],
        ) === _0x3ba617,
    )),
    chrome["storage"]["local"]["set"]({ savedEbaySearchItems: _0x1049ed }));
  var _0x380ce8 = await _0x4c7314();
  await new Promise((_0xa95ada) => setTimeout(_0xa95ada, 0xbb8));
  var { run_status_extract_titles: _0x63dd3 } = await chrome["storage"][
    "local"
  ]["get"]("run_status_extract_titles");
  console["log"]("doesNextPageExist", _0x380ce8);
  var { scrapeAllPages: _0x1809c4 } =
    await chrome["storage"]["local"]["get"]("scrapeAllPages");
  if (0x1 == _0x380ce8 && 0x1 == _0x63dd3 && 0x1 == _0x1809c4)
    (console["log"]("doesNextPageExist\x20==\x20true"),
      document["getElementsByClassName"]("pagination__next")[0x0]["click"]());
  else {
    if (0x0 == _0x380ce8 || 0x0 == _0x1809c4) {
      console["log"]("doesNextPageExist\x20==\x20false");
      var _0x3661d8 = document["getElementById"]("btn-extract-all");
      (_0x3661d8["classList"]["remove"]("btn-stop-extract-all"),
        _0x3661d8["classList"]["add"]("btn-extract-all"),
        (_0x3661d8["innerHTML"] = "Complete!"),
        (document["getElementsByClassName"]("btn-clear-all-titles")[0x0][
          "innerHTML"
        ] = "Clear\x20Titles\x20(" + _0x1049ed["length"] + ")"),
        (document["title"] = "Completed\x20Extraction!\x20✔️"),
        (_0x63dd3 = !0x1),
        chrome["storage"]["local"]["set"]({
          run_status_extract_titles: _0x63dd3,
        }),
        await new Promise((_0x2d20e7) => setTimeout(_0x2d20e7, 0xbb8)),
        (_0x3661d8["innerHTML"] = "Extract\x20All\x20Titles"));
    }
  }
}
function filterEbaySearchItemsByDate(_0x41fe0c, _0x536626) {
  if ("default" == _0x536626) return _0x41fe0c;
  var _0x2b9260 = new Date(),
    _0x16dddd = new Date();
  return (
    _0x16dddd["setDate"](_0x16dddd["getDate"]() - _0x536626),
    _0x41fe0c["filter"](function (_0x555856) {
      var _0x5924a4 = new Date(_0x555856["dateSold"]);
      return _0x5924a4 >= _0x16dddd && _0x5924a4 <= _0x2b9260;
    })
  );
}
function _0x4c7314() {
  return new Promise((_0x4ff924, _0x53a786) => {
    var _0x5906de = document["getElementsByClassName"]("pagination__next")[0x0];
    (null == _0x5906de && _0x4ff924(!0x1),
      _0x4ff924("true" != _0x5906de["getAttribute"]("aria-disabled")));
  });
}
function _0x9ceda4() {
  var _0x479f06 = document["createElement"]("button");
  return (
    _0x479f06["setAttribute"]("class", "btn-show-all-titles"),
    (_0x479f06["innerHTML"] = "Filter\x20Titles"),
    _0x479f06["addEventListener"]("click", function (_0x3f1377) {
      chrome["runtime"]["sendMessage"]({ type: "openSortEbayItems" });
    }),
    _0x479f06
  );
}
async function _0x1101b1() {
  var { savedEbaySearchItems: _0x5e20d9 } = await chrome["storage"]["local"][
      "get"
    ]("savedEbaySearchItems"),
    _0x348a9b = [];
  for (var _0x15348e = 0x0; _0x15348e < _0x5e20d9["length"]; _0x15348e++)
    _0x348a9b["push"](_0x5e20d9[_0x15348e]["title"]);
  (console["log"](_0x348a9b),
    _0x58856f((_0x348a9b = _0x348a9b["join"]("\x0a"))),
    _0x245fec(),
    _0x35af47(_0x348a9b));
}
function _0x3351ee(_0x2890c7, _0x5f3909, _0x249249 = "") {
  const _0x5337aa = document["createElement"](_0x2890c7);
  return (
    (_0x5337aa["id"] = _0x5f3909),
    (_0x5337aa["innerHTML"] = _0x249249),
    _0x5337aa
  );
}
function _0x41907f(_0x2f92c9, _0x1ca91c) {
  _0x1ca91c["forEach"]((_0x179475) => _0x2f92c9["appendChild"](_0x179475));
}
function _0x58856f(_0x480d97) {
  const _0x59cffb = _0x3351ee("div", "keyword_modal"),
    _0x128531 = _0x3351ee("div", "keyword_modal_content"),
    _0x4f543e = _0x3351ee("div", "keyword_modal_header"),
    _0x1af8f3 = _0x3351ee("div", "keyword_modal_body"),
    _0x187613 = _0x3351ee("div", "keyword_modal_footer"),
    _0x5ba8be = _0x3351ee("span", "keyword_modal_close", "&times;");
  _0x4f543e["appendChild"](_0x5ba8be);
  const _0x1217a3 = _0x3351ee(
    "p",
    "keyword_info",
    "Loaded\x20" + _0x480d97["split"]("\x0a")["length"] + "\x20keywords",
  );
  _0x1af8f3["appendChild"](_0x1217a3);
  const _0x4a4158 = _0x3351ee("textarea", "keyword_textarea");
  ((_0x4a4158["value"] = _0x480d97),
    (_0x4a4158["style"]["width"] = "100%"),
    _0x1af8f3["appendChild"](_0x4a4158));
  const _0x45921a = _0x3351ee(
    "button",
    "copy_keywords_button",
    "Copy\x20All\x20Keywords",
  );
  ((_0x45921a["style"]["display"] = "block"),
    (_0x45921a["style"]["margin"] = "auto"),
    _0x187613["appendChild"](_0x45921a),
    _0x41907f(_0x128531, [_0x4f543e, _0x1af8f3, _0x187613]),
    _0x59cffb["appendChild"](_0x128531),
    document["body"]["appendChild"](_0x59cffb),
    (_0x59cffb["style"]["display"] = "block"));
}
function _0x245fec() {
  document["getElementById"]("keyword_modal_close")["addEventListener"](
    "click",
    function () {
      document["getElementById"]("keyword_modal")["remove"]();
    },
  );
}
function _0x35af47(_0x4b9482) {
  const _0x1c20dd = document["getElementById"]("copy_keywords_button");
  _0x1c20dd["addEventListener"]("click", function () {
    (navigator["clipboard"]["writeText"](_0x4b9482),
      (_0x1c20dd["innerHTML"] = "Copied!"));
  });
}
async function _0x23c460() {
  var _0x242d4b = document["createElement"]("select");
  ((_0x242d4b["id"] = "filter-dropdown"),
    _0x242d4b["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "Select\x20Filter", value: "default" },
      { text: "Last\x201\x20Day", value: "1" },
      { text: "Last\x203\x20Days", value: "3" },
      { text: "Last\x207\x20Days", value: "7" },
      { text: "Last\x2014\x20Days", value: "14" },
      { text: "Last\x2021\x20Days", value: "21" },
      { text: "Last\x2030\x20Days", value: "30" },
      { text: "Last\x2060\x20Days", value: "60" },
      { text: "Last\x2090\x20Days", value: "90" },
    ]["forEach"]((_0x35f312) => {
      var _0x590370 = document["createElement"]("option");
      ((_0x590370["value"] = _0x35f312["value"]),
        (_0x590370["innerText"] = _0x35f312["text"]),
        _0x242d4b["appendChild"](_0x590370));
    }));
  let { selectedFilter: _0x268fad } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  !_0x268fad &&
    ((_0x268fad = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: _0x268fad }));
  ((_0x242d4b["value"] = _0x268fad),
    _0x242d4b["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        selectedFilter: this["value"],
      }),
        console["log"]("Filter\x20saved:\x20" + this["value"]));
    }));
  var _0x440cb0 = document["createElement"]("label");
  _0x440cb0["innerText"] =
    "Only\x20Scan\x20Items\x20That\x20Sold\x20within:\x20";
  var _0x3e4168 = document["createElement"]("div");
  return (
    _0x3e4168["setAttribute"]("class", "filter-dropdown-div"),
    (_0x3e4168["id"] = "filter-dropdown-container"),
    _0x3e4168["appendChild"](_0x440cb0),
    _0x3e4168["appendChild"](_0x242d4b),
    _0x3e4168
  );
}
function _0x3c8534() {
  var _0x2a4d9a = document["createElement"]("button");
  return (
    _0x2a4d9a["setAttribute"]("class", "btn-terapeak-search"),
    (_0x2a4d9a["innerHTML"] = "Find\x20Total\x20Sold\x20&\x20Competitors"),
    (_0x2a4d9a["style"]["display"] = "none"),
    _0x2a4d9a["addEventListener"]("click", async function (_0x219f8f) {
      _0x219f8f["preventDefault"]();
      let _0x4520d0 = _0x219f8f["target"];
      for (; _0x4520d0 && !_0x4520d0["classList"]["contains"]("s-item"); )
        _0x4520d0 = _0x4520d0["parentElement"];
      _0x4520d0 &&
        (console["log"]("item", _0x4520d0),
        await _0x201bfa(_0x4520d0),
        _0x5e7528());
    }),
    _0x2a4d9a
  );
}
async function _0x60a1cf() {
  document["querySelector"](".s-item__wrapper");
}
async function _0x375654(_0x35652c, _0x162835) {
  var _0x29aab0 = _0x35652c["querySelector"](".s-item__itemID")["textContent"];
  ((_0x29aab0 = (_0x29aab0 = _0x29aab0["split"]("Item:\x20")[0x1])["replace"](
    /\s/g,
    "",
  )),
    console["log"]("itemNumber", _0x29aab0));
  var _0x46667b = await chrome["runtime"]["sendMessage"]({
    type: "checkPurchaseHistory",
    itemNumber: _0x29aab0,
    lastXDays: _0x162835,
  });
  return (console["log"]("response", _0x46667b), _0x46667b["totalSold"]);
}
async function _0x487cd7(
  _0x429d9e,
  _0x5001e8,
  _0x57eeed = !0x0,
  _0x7ac2f6 = !0x1,
) {
  console["log"]("item", _0x429d9e);
  var _0x305805;
  try {
    var _0x3e2bd8 = _0x429d9e["querySelector"](".s-item__itemID");
    (_0x3e2bd8 ||
      (_0x3e2bd8 = (_0x3e2bd8 = (_0x3e2bd8 = _0x429d9e["querySelector"](
        ".su-card-container__attributes__secondary",
      ))["querySelectorAll"](".s-card__attribute-row"))[
        _0x3e2bd8["length"] - 0x1
      ]),
      (_0x305805 = _0x3e2bd8["textContent"]));
  } catch (_0x3db2ea) {
    console["log"]("error", _0x3db2ea);
    return;
  }
  (console["log"]("itemNumber", _0x305805),
    (_0x305805 = _0x305805["split"](":")[0x1]),
    console["log"]("itemNumber", _0x305805),
    (_0x305805 = _0x305805["replace"](/\s/g, "")));
  var _0xabfb71 = _0x3300d5(_0x429d9e);
  console["log"]("soldDateElement", _0xabfb71);
  var _0x24720e;
  if (null !== _0xabfb71)
    ((_0x24720e = _0xabfb71["textContent"]),
      console["log"]("soldDate", _0x24720e),
      (_0x24720e = (_0x24720e = _0x24720e["split"]("\x20")
        ["slice"](0x1)
        ["join"]("\x20"))["trim"]()));
  else _0x24720e = null;
  (console["log"]("soldDate\x20before\x20parse", _0x24720e),
    (_0x24720e = _0x2fc65e(_0x24720e)),
    console["log"]("soldDate\x20after\x20parse", _0x24720e));
  var _0x41632e = new Date(_0x24720e);
  console["log"]("dateSold", _0x41632e);
  var _0x21bcd8 = (new Date() - _0x41632e) / 0x5265c00;
  console["log"]("daysDifference", _0x21bcd8);
  var _0x13025b = 0x0;
  if (_0x21bcd8 > _0x5001e8 && !_0x7ac2f6)
    console["log"]("daysDifference\x20>\x20lastXDays");
  else
    try {
      var _0x46e695 = await chrome["runtime"]["sendMessage"]({
        type: "checkPurchaseHistory",
        itemNumber: _0x305805,
        lastXDays: _0x5001e8,
        closeTabAfterSearch: _0x57eeed,
      });
      (console["log"]("response", _0x46e695),
        (_0x13025b = _0x46e695["totalSold"]));
    } catch (_0x33d377) {
      (console["log"]("error", _0x33d377), (_0x13025b = -0x3e7));
    }
  var _0x5a1f2c = {
    0x1: _0x13025b["totalSoldIn1"],
    0x3: _0x13025b["totalSoldIn3"],
    0x7: _0x13025b["totalSoldIn7"],
    0xe: _0x13025b["totalSoldIn14"],
    0x1e: _0x13025b["totalSoldIn30"],
    0x3c: _0x13025b["totalSoldIn60"],
    0x5a: _0x13025b["totalSoldIn90"],
  };
  const _0xdceb5b = [0x1, 0x3, 0x7, 0xe, 0x1e, 0x3c, 0x5a];
  let _0x1fd415 = !0x0;
  for (let _0x45c368 of _0xdceb5b)
    if (
      void 0x0 !== _0x5a1f2c[_0x45c368] &&
      "undefined" !== _0x5a1f2c[_0x45c368]
    ) {
      _0x1fd415 = !0x1;
      break;
    }
  _0x13025b = document["createElement"]("p");
  if (_0x1fd415)
    ((_0x13025b["innerHTML"] =
      "<strong>Total\x20Sold:</strong>\x20Not\x20Available"),
      _0x429d9e["appendChild"](_0x13025b));
  else {
    var _0x48bd4b = document["createElement"]("table");
    _0x48bd4b["className"] = "total-sold-table";
    var _0xdca6cc = document["createElement"]("tr");
    ((_0xdca6cc["innerHTML"] =
      "<th>Last\x20X\x20Days</th><th>Total\x20Sold</th>"),
      _0x48bd4b["appendChild"](_0xdca6cc),
      _0xdceb5b["forEach"]((_0x14b3d1) => {
        var _0x4abc37 = document["createElement"]("tr");
        (_0x4abc37["setAttribute"]("class", "total-sold-element"),
          _0x4abc37["setAttribute"]("data-last-x-days", _0x14b3d1),
          _0x4abc37["setAttribute"](
            "data-total-sold",
            "undefined" !== _0x5a1f2c[_0x14b3d1]
              ? _0x5a1f2c[_0x14b3d1]
              : "Not\x20Available",
          ),
          (_0x4abc37["innerHTML"] =
            "<td\x20>" +
            _0x14b3d1 +
            "</td><td><b\x20style=\x22color:red;\x22>" +
            ("undefined" !== _0x5a1f2c[_0x14b3d1]
              ? _0x5a1f2c[_0x14b3d1]
              : "Not\x20Available") +
            "</b></td>"),
          _0x48bd4b["appendChild"](_0x4abc37));
      }),
      _0x429d9e["appendChild"](_0x48bd4b));
  }
  setTimeout(() => {
    try {
      _0x48bd4b["classList"]["add"]("show-element");
    } catch (_0x34cd6d) {
      console["log"]("error", _0x34cd6d);
    }
    try {
      _0x48bd4b["querySelectorAll"]("tr")["forEach"](function (_0x574ac0) {
        _0x574ac0["classList"]["add"]("show-element");
      });
    } catch (_0x54c45c) {
      console["log"]("error", _0x54c45c);
    }
    try {
      _0x13025b["classList"]["add"]("show-element");
    } catch (_0x2afcf3) {
      console["log"]("error", _0x2afcf3);
    }
  }, 0x0);
}
function _0x55da58(_0x29b43b, _0x5a2bc7) {
  var _0x9f83b = document["createElement"]("div");
  return (
    _0x9f83b["setAttribute"]("class", "total-sold-element"),
    _0x9f83b["setAttribute"]("data-total-sold", _0x29b43b),
    _0x9f83b["setAttribute"]("data-last-x-days", _0x5a2bc7),
    (_0x9f83b["innerHTML"] =
      -0x3e7 == _0x29b43b
        ? "Total\x20Sold:\x20<b\x20style=\x22color:red;\x22>\x20Error\x20Occurred\x20</b>"
        : "Total\x20Sold:\x20<b\x20style=\x22color:red;\x22>\x20" +
          _0x29b43b +
          "\x20</b>\x20(Last\x20<b>\x20" +
          _0x5a2bc7 +
          "\x20</b>\x20Days)"),
    _0x9f83b
  );
}
async function _0x201bfa(_0x29f95a) {
  var _0x154fd5 = _0x29f95a["querySelector"](".s-item__title")["textContent"];
  if (
    "" != _0x154fd5 &&
    null != _0x154fd5 &&
    null != _0x154fd5 &&
    "Shop\x20on\x20eBay" != _0x154fd5
  ) {
    console["log"]("title:", _0x154fd5);
    var _0x469e50 = await _0x3a6ba2(_0x154fd5),
      _0x1935fd = _0x469e50["totalSold"],
      _0x59791d = _0x469e50["totalCompetitors"],
      _0x496795 = document["createElement"]("div");
    (_0x496795["setAttribute"]("class", "total-sold-element"),
      _0x496795["setAttribute"]("data-total-sold", _0x1935fd),
      (_0x496795["innerHTML"] = "Total\x20Sold:\x20" + _0x1935fd),
      _0x29f95a["appendChild"](_0x496795));
    var _0x52ed9d = document["createElement"]("div");
    (_0x52ed9d["setAttribute"]("class", "total-competitors-element"),
      _0x52ed9d["setAttribute"]("data-total-competitors", _0x59791d),
      (_0x52ed9d["innerHTML"] = "Total\x20Competitors:\x20" + _0x59791d),
      _0x29f95a["appendChild"](_0x52ed9d),
      setTimeout(() => {
        (_0x496795["classList"]["add"]("show-element"),
          _0x52ed9d["classList"]["add"]("show-element"));
      }, 0x0));
  }
}
async function _0x3a6ba2(_0x4552f1) {
  if (!0x0 === _0x478d34)
    return (
      _0xa9f4ff(),
      (_0x49787f = 0x32),
      { totalSold: "Rate\x20Limited", totalCompetitors: "Rate\x20Limited" }
    );
  var _0x59bef1 = await chrome["runtime"]["sendMessage"]({
    type: "searchTitleOnTeraPeak",
    title: _0x4552f1,
  });
  console["log"]("response", _0x59bef1);
  try {
    var _0x1e9d28 = _0x59bef1["response"]["soldData"];
    (console["log"]("soldData", _0x1e9d28), _0x5e7528());
  } catch (_0x734519) {
    return (
      console["log"]("error", _0x734519),
      (_0x478d34 = !0x0),
      _0xa9f4ff(),
      (_0x49787f = 0x32),
      { totalSold: "Rate\x20Limited", totalCompetitors: "Rate\x20Limited" }
    );
  }
  return _0x1e9d28;
}
function _0xa9f4ff() {
  if (document["querySelector"](".overlay")) return;
  const _0x3309ab = document["createElement"]("div");
  _0x3309ab["classList"]["add"]("overlay");
  const _0x3db794 = document["createElement"]("div");
  (_0x3db794["classList"]["add"]("text"),
    (_0x3db794["textContent"] =
      "Rate\x20Limit\x20Reached,\x20I\x20know\x20it\x20sucks\x20😭,\x20Try\x20again\x20in\x20a\x20bit!"),
    _0x3309ab["appendChild"](_0x3db794));
  var _0x1dfdd2 = document["createElement"]("button");
  (_0x1dfdd2["setAttribute"]("class", "btn-stop-extract-all"),
    (_0x1dfdd2["innerHTML"] = "Stop\x20Extracting\x20Titles"),
    _0x1dfdd2["addEventListener"]("click", function (_0x245607) {
      _0x245607["preventDefault"]();
      var _0x4674f9 = document["getElementById"]("btn-extract-all");
      (_0x4674f9["classList"]["remove"]("btn-stop-extract-all"),
        _0x4674f9["classList"]["add"]("btn-extract-all"),
        (_0x4674f9["innerHTML"] = "Extract\x20All\x20Titles"),
        (run_status_extract_titles = !0x1),
        chrome["storage"]["local"]["set"]({
          run_status_extract_titles: run_status_extract_titles,
        }),
        (_0x1dfdd2["innerHTML"] = "Please\x20Wait..."));
    }),
    _0x3309ab["appendChild"](_0x1dfdd2),
    document["body"]["appendChild"](_0x3309ab),
    setTimeout(() => {
      _0x3309ab["style"]["display"] = "flex";
    }, 0x0));
}
function _0x5e7528() {
  const _0xbab674 = document["querySelector"](".overlay");
  _0xbab674 &&
    ((_0xbab674["style"]["animation"] = "fadeOut\x200.5s\x20ease\x20forwards"),
    setTimeout(() => {
      _0xbab674["remove"]();
    }, 0x1f4));
}
async function _0x296ffa() {
  var _0xa50c0e = document["createElement"]("label");
  _0xa50c0e["setAttribute"]("class", "filter-label");
  var _0xd00aad = document["createElement"]("span");
  ((_0xd00aad["innerHTML"] = "Total\x20Sold\x20Filter:\x20"),
    _0xa50c0e["appendChild"](_0xd00aad));
  var _0x1ca22e = document["createElement"]("input");
  ((_0x1ca22e["type"] = "number"),
    (_0x1ca22e["id"] = "total-sold-input"),
    (_0x1ca22e["min"] = "0"),
    _0x1ca22e["setAttribute"]("class", "filter-input"));
  let { totalSoldFilter: _0x3aba62 } =
    await chrome["storage"]["local"]["get"]("totalSoldFilter");
  return (
    !_0x3aba62 &&
      ((_0x3aba62 = 0x0),
      await chrome["storage"]["local"]["set"]({ totalSoldFilter: _0x3aba62 })),
    (_0x1ca22e["value"] = _0x3aba62),
    _0x1ca22e["addEventListener"]("input", async function () {
      this["value"] >= 0x0 &&
        (await chrome["storage"]["local"]["set"]({
          totalSoldFilter: this["value"],
        }),
        console["log"](
          "Total\x20Sold\x20Filter\x20saved:\x20" + this["value"],
        ));
    }),
    _0xa50c0e["appendChild"](_0x1ca22e),
    _0xa50c0e
  );
}
async function _0x594589() {
  var _0x224d45 = document["createElement"]("label");
  _0x224d45["setAttribute"]("class", "filter-label");
  var _0x3a60bc = document["createElement"]("span");
  ((_0x3a60bc["innerHTML"] = "Total\x20Competitors\x20Filter:\x20"),
    _0x224d45["appendChild"](_0x3a60bc));
  var _0x8e7010 = document["createElement"]("input");
  ((_0x8e7010["type"] = "number"),
    (_0x8e7010["id"] = "total-competitors-input"),
    (_0x8e7010["min"] = "0"),
    _0x8e7010["setAttribute"]("class", "filter-input"));
  let { totalCompetitorsFilter: _0x114c11 } = await chrome["storage"]["local"][
    "get"
  ]("totalCompetitorsFilter");
  return (
    !_0x114c11 &&
      ((_0x114c11 = 0x0),
      await chrome["storage"]["local"]["set"]({
        totalCompetitorsFilter: _0x114c11,
      })),
    (_0x8e7010["value"] = _0x114c11),
    _0x8e7010["addEventListener"]("input", async function () {
      this["value"] >= 0x0 &&
        (await chrome["storage"]["local"]["set"]({
          totalCompetitorsFilter: this["value"],
        }),
        console["log"](
          "Total\x20Competitors\x20Filter\x20saved:\x20" + this["value"],
        ));
    }),
    _0x224d45["appendChild"](_0x8e7010),
    _0x224d45
  );
}
async function fetchSoldDataConcurrently() {
  var { concurrencyLimit: _0x5ce3f8 } =
      await chrome["storage"]["local"]["get"]("concurrencyLimit"),
    _0x2c3a11 = _0x5ce3f8;
  console["log"]("fetchSoldDataConcurrently");
  var _0x2737dd = document["querySelectorAll"](".s-item__wrapper"),
    _0x29013c = Array["from"](_0x2737dd);
  const _0x552b8d = [];
  for (
    let _0x30fd1e = 0x0;
    _0x30fd1e < Math["min"](_0x2c3a11, _0x29013c["length"]);
    _0x30fd1e++
  )
    _0x552b8d["push"](_0x3d0473(_0x29013c));
  await Promise["all"](_0x552b8d);
}
async function _0x3d0473(_0x58c2a2) {
  for (; _0x58c2a2["length"] > 0x0; ) {
    const _0x211c33 = _0x58c2a2["pop"]();
    (_0x211c33["classList"]["add"]("highlight"),
      await _0x201bfa(_0x211c33),
      _0x211c33["classList"]["remove"]("highlight"));
  }
}
async function fetchSoldDataConcurrentlyViaPurchaseHistory() {
  var { concurrencyLimit: _0x37f865 } =
      await chrome["storage"]["local"]["get"]("concurrencyLimit"),
    _0x4f6e66 = _0x37f865,
    _0x33ff11 = _0xe76416(),
    _0x21890c = Array["from"](_0x33ff11),
    { selectedFilter: _0x3bb9a7 } =
      await chrome["storage"]["local"]["get"]("selectedFilter");
  !_0x3bb9a7 &&
    ((_0x3bb9a7 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: _0x3bb9a7 }));
  var _0x308af8 = _0x3bb9a7;
  const _0x3bb197 = [];
  console["log"]("CONCURRENCY_LIMIT", _0x4f6e66);
  for (
    let _0xcbd6b3 = 0x0;
    _0xcbd6b3 < Math["min"](_0x4f6e66, _0x21890c["length"]);
    _0xcbd6b3++
  )
    _0x3bb197["push"](_0x397ef4(_0x21890c, _0x308af8));
  await Promise["all"](_0x3bb197);
}
async function _0x397ef4(_0x3cdd13, _0x4c0fd2) {
  for (; _0x3cdd13["length"] > 0x0; ) {
    var _0x1f7e36 = _0x3cdd13["pop"]();
    _0x1f7e36["classList"]["add"]("highlight");
    try {
      await _0x487cd7(_0x1f7e36, _0x4c0fd2);
    } catch (_0x6e944f) {
      console["log"]("error", _0x6e944f);
    }
    _0x1f7e36["classList"]["remove"]("highlight");
  }
}
async function fetchSoldDataSequentially() {
  const _0x46c832 = document["querySelectorAll"](".s-item__wrapper");
  for (const _0x20f5cf of _0x46c832) {
    (_0x20f5cf["scrollIntoView"]({ block: "center", inline: "nearest" }),
      _0x20f5cf["classList"]["add"]("highlight"),
      await _0x201bfa(_0x20f5cf),
      await new Promise((_0x180dc2) => setTimeout(_0x180dc2, _0x49787f)),
      _0x20f5cf["classList"]["remove"]("highlight"));
  }
  (await new Promise((_0x3988ba) => setTimeout(_0x3988ba, 0x7d0)), _0x5e7528());
}
async function fetchSoldDataSequentiallyViaPurchaseHistory() {
  var _0x4cb0d9 = document["querySelectorAll"](
    ".s-item__wrapper:not(.highlight)",
  );
  console["log"](
    "fetchSoldDataSequentiallyViaPurchaseHistory\x20items",
    _0x4cb0d9,
  );
  for (var _0x3e6455 of _0x4cb0d9) {
    try {
      _0x3e6455["querySelector"](".s-item__itemID")["textContent"];
    } catch (_0x142fe5) {
      console["log"]("itemNumber\x20not\x20found");
      continue;
    }
    (console["log"](
      "fetchSoldDataSequentiallyViaPurchaseHistory\x20item",
      _0x3e6455,
    ),
      _0x3e6455["scrollIntoView"]({ block: "center", inline: "nearest" }),
      _0x3e6455["classList"]["add"]("highlight"));
    var { selectedFilter: _0x54dac3 } =
      await chrome["storage"]["local"]["get"]("selectedFilter");
    !_0x54dac3 &&
      ((_0x54dac3 = "90"),
      await chrome["storage"]["local"]["set"]({ selectedFilter: _0x54dac3 }));
    var _0x55411a = _0x54dac3;
    (await _0x487cd7(_0x3e6455, _0x55411a),
      (_0x49787f = 0x96),
      await new Promise((_0xe57f47) => setTimeout(_0xe57f47, _0x49787f)),
      _0x3e6455["classList"]["remove"]("highlight"));
  }
  (await new Promise((_0x4d67b6) => setTimeout(_0x4d67b6, 0x7d0)), _0x5e7528());
}
function _0x46ab51() {
  var fetchSoldDataButton = document["createElement"]("button");
  return (
    fetchSoldDataButton["setAttribute"]("class", "btn-fetch-sold-data"),
    (fetchSoldDataButton["innerHTML"] = "Fetch\x20Sold\x20Data"),
    fetchSoldDataButton["addEventListener"](
      "click",
      async function (_0x3617e5) {
        (_0x3617e5["preventDefault"](), await fetchSoldDataSequentially());
      },
    ),
    fetchSoldDataButton
  );
}
async function _0x47551b() {
  var _0x1f9d6f = document["createElement"]("select");
  (_0x1f9d6f["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "Off", value: "none" },
      { text: "On", value: "concurrent-purchase-history" },
    ]["forEach"]((_0x5d885f) => {
      var _0x3d7fe5 = document["createElement"]("option");
      ((_0x3d7fe5["value"] = _0x5d885f["value"]),
        (_0x3d7fe5["innerText"] = _0x5d885f["text"]),
        _0x1f9d6f["appendChild"](_0x3d7fe5));
    }));
  let { selectedFetchMethod: _0x55a713 } = await chrome["storage"]["local"][
    "get"
  ]("selectedFetchMethod");
  !_0x55a713 &&
    ((_0x55a713 = "none"),
    await chrome["storage"]["local"]["set"]({
      selectedFetchMethod: _0x55a713,
    }));
  ((_0x1f9d6f["value"] = _0x55a713),
    _0x1f9d6f["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        selectedFetchMethod: this["value"],
      }),
        console["log"]("Fetch\x20Method\x20saved:\x20" + this["value"]),
        "concurrent-purchase-history" == this["value"]
          ? ((document["getElementById"](
              "concurrency-limit-dropdown-container",
            )["style"]["display"] = "block"),
            (document["getElementById"]("filter-dropdown-container")["style"][
              "display"
            ] = "block"))
          : ((document["getElementById"](
              "concurrency-limit-dropdown-container",
            )["style"]["display"] = "none"),
            (document["getElementById"]("filter-dropdown-container")["style"][
              "display"
            ] = "none")));
    }));
  var _0x16fa31 = document["createElement"]("label");
  ((_0x16fa31["innerText"] = "Get\x20Total\x20Sold\x20History:"),
    _0x16fa31["setAttribute"]("for", "terapeak-fetch-mode"));
  var _0x559946 = document["createElement"]("div");
  return (
    _0x559946["appendChild"](_0x16fa31),
    _0x559946["appendChild"](_0x1f9d6f),
    _0x559946
  );
}
async function _0x2f0daf() {
  var _0x37d183 = document["createElement"]("input");
  ((_0x37d183["type"] = "checkbox"),
    (_0x37d183["id"] = "scrape-all-pages-checkbox"));
  var { scrapeAllPages: _0x436d64 } =
    await chrome["storage"]["local"]["get"]("scrapeAllPages");
  !_0x436d64 &&
    ((_0x436d64 = !0x1),
    await chrome["storage"]["local"]["set"]({ scrapeAllPages: _0x436d64 }));
  ((_0x37d183["checked"] = _0x436d64),
    _0x37d183["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        scrapeAllPages: this["checked"],
      }),
        console["log"](
          "Scrape\x20All\x20Pages\x20saved:\x20" + this["checked"],
        ));
    }));
  var _0x573f27 = document["createElement"]("label");
  ((_0x573f27["innerText"] = "Scrape\x20All\x20Pages"),
    _0x573f27["setAttribute"]("for", "scrape-all-pages-checkbox"));
  var _0x2d98c0 = document["createElement"]("div");
  return (
    _0x2d98c0["appendChild"](_0x37d183),
    _0x2d98c0["appendChild"](_0x573f27),
    _0x2d98c0
  );
}
async function _0x57b75b() {
  var _0x3a61b4 = document["createElement"]("select");
  ((_0x3a61b4["id"] = "concurrency-limit-dropdown"),
    _0x3a61b4["setAttribute"]("class", "filter-dropdown-class"),
    [
      { text: "1", value: 0x1 },
      { text: "3", value: 0x3 },
      { text: "5", value: 0x5 },
      { text: "10", value: 0xa },
      { text: "15", value: 0xf },
      { text: "20", value: 0x14 },
      { text: "25", value: 0x19 },
      { text: "30", value: 0x1e },
      { text: "40", value: 0x28 },
      { text: "50", value: 0x32 },
    ]["forEach"]((_0x4489eb) => {
      var _0x72bb17 = document["createElement"]("option");
      ((_0x72bb17["value"] = _0x4489eb["value"]),
        (_0x72bb17["innerText"] = _0x4489eb["text"]),
        _0x3a61b4["appendChild"](_0x72bb17));
    }));
  var { concurrencyLimit: _0x20f276 } =
    await chrome["storage"]["local"]["get"]("concurrencyLimit");
  console["log"]("concurrencyLimit", _0x20f276);
  !_0x20f276 &&
    ((_0x20f276 = 0x5),
    chrome["storage"]["local"]["set"]({ concurrencyLimit: _0x20f276 }));
  ((_0x3a61b4["value"] = _0x20f276),
    _0x3a61b4["addEventListener"]("change", async function () {
      (await chrome["storage"]["local"]["set"]({
        concurrencyLimit: this["value"],
      }),
        console["log"]("Concurrency\x20Limit\x20saved:\x20" + this["value"]));
    }));
  var _0x14e569 = document["createElement"]("label");
  ((_0x14e569["innerText"] = "Scanning\x20Speed:\x20"),
    _0x14e569["setAttribute"]("for", "concurrency-limit-dropdown"));
  var _0x59778a = document["createElement"]("div");
  return (
    (_0x59778a["id"] = "concurrency-limit-dropdown-container"),
    _0x59778a["appendChild"](_0x14e569),
    _0x59778a["appendChild"](_0x3a61b4),
    _0x59778a
  );
}
function _0x5c371c() {
  var _0x2a8512 = document["querySelectorAll"]("li"),
    _0xf0e67e = Array["from"](_0x2a8512);
  ((_0xf0e67e = (_0xf0e67e = _0xf0e67e["filter"]((_0x2cc2d7) =>
    _0x2cc2d7["querySelector"](_0x30748a()),
  ))["filter"]((_0x3b8e55) =>
    _0x3b8e55["querySelector"](".total-sold-element"),
  ))["sort"]((_0x57950b, _0x30e922) => {
    (console["log"]("a", _0x57950b), console["log"]("b", _0x30e922));
    var _0x186439 = _0x57950b["querySelector"](".total-sold-element")[
        "getAttribute"
      ]("data-total-sold"),
      _0x5a8ffd = _0x30e922["querySelector"](".total-sold-element")[
        "getAttribute"
      ]("data-total-sold");
    return "Rate\x20Limited" == _0x186439 || "Rate\x20Limited" == _0x5a8ffd
      ? 0x0
      : _0x5a8ffd - _0x186439;
  }),
    _0xf0e67e["reverse"]());
  var _0xf7e6b6 = _0xf0e67e[0x0]["parentNode"];
  _0xf0e67e["forEach"]((_0x5a5cee) =>
    _0xf7e6b6["insertBefore"](
      _0x5a5cee,
      _0xf7e6b6["firstChild"]["nextSibling"],
    ),
  );
}
function _0x5c7983() {
  var _0x4b6231 = document["createElement"]("button");
  return (
    _0x4b6231["setAttribute"]("class", "btn-check-all-purchase-history"),
    _0x4b6231["classList"]["add"]("filter-date-context"),
    (_0x4b6231["id"] = "btn-check-all-purchase-history"),
    (_0x4b6231["innerHTML"] = "Check\x20All\x20Purchase\x20History"),
    _0x4b6231["addEventListener"]("click", async function (_0x3199a1) {
      try {
        await fetchSoldDataBasedOnSelection();
      } catch (_0x564274) {
        console["log"]("error", _0x564274);
      }
    }),
    _0x4b6231
  );
}
function _0x21954f(
  _0x51cd6d = null,
  _0x49100a = null,
  _0x51145e = null,
  _0x19a03c = !0x0,
) {
  console["log"]("createEcommerceSearchButtonsPanel", _0x51cd6d);
  var _0x3d2667 = _0x432bb6(_0x49100a),
    _0x2aa8fa = _0x53b7e2(_0x51cd6d),
    _0x110e52 = _0x3d3a7a(),
    _0xe319a6 = _0x29233b(_0x51cd6d),
    _0x5154f1 = _0x32ffde(_0x51cd6d),
    _0x25a471 = _0x29233b(
      _0x51cd6d,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x2e9c16 = _0x3806a7(_0x51145e),
    _0x1e9393 = _0x2901fc(_0x49100a),
    _0x2e39b0 = document["createElement"]("div");
  _0x2e39b0["setAttribute"]("id", "search-div");
  var _0xa7a811 = document["createElement"]("label");
  ((_0xa7a811["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x2e39b0["appendChild"](_0xa7a811),
    _0x2e39b0["appendChild"](_0x5154f1),
    _0x2e39b0["appendChild"](_0xe319a6),
    _0x2e39b0["appendChild"](_0x2aa8fa),
    _0x2e39b0["appendChild"](_0x2e9c16),
    _0x2e39b0["appendChild"](_0x25a471));
  var _0x2e1b00 = _0x1f732e(),
    _0x1c3a31 = _0x5affb9(),
    _0x190143 = document["createElement"]("div");
  _0x190143["setAttribute"]("id", "item-buttons-div");
  var _0x2058d4 = document["createElement"]("div");
  return (
    _0x2058d4["setAttribute"]("id", "main-buttons-div"),
    _0x2058d4["appendChild"](_0x1e9393),
    _0x2058d4["appendChild"](_0x110e52),
    _0x2058d4["appendChild"](_0x2e1b00),
    _0x2058d4["appendChild"](_0x3d2667),
    _0x190143["appendChild"](_0x2058d4),
    _0x19a03c && _0x190143["appendChild"](_0x1c3a31),
    _0x190143["appendChild"](_0x2e39b0),
    _0x190143
  );
}
console["log"]("public_search\x20functions.js\x20loaded");
function _0x5affb9() {
  var _0xd32433 = document["createElement"]("div"),
    _0x316bd0 = document["createElement"]("a");
  ((_0x316bd0["className"] =
    "vim\x20fake-btn\x20fake-btn--primary\x20ux-call-to-action"),
    (_0x316bd0["href"] = "#"),
    _0x316bd0["classList"]["add"]("custom-button"));
  var _0x53f8f2 = document["createElement"]("span");
  return (
    (_0x53f8f2["className"] = "ux-call-to-action__cell"),
    (_0x53f8f2["innerHTML"] =
      "<span\x20class=\x22ux-call-to-action__text\x22>List\x20To\x20Ebay</span>"),
    _0x316bd0["appendChild"](_0x53f8f2),
    _0xd32433["appendChild"](_0x316bd0),
    (_0xd32433["className"] = "button-list\x20vim"),
    _0x316bd0["addEventListener"]("click", async function (_0xd0ea0f) {
      _0xd0ea0f["preventDefault"]();
      if (!_0x316bd0["classList"]["contains"]("disabled")) {
        (console["log"]("buttonList\x20clicked"),
          _0x316bd0["classList"]["add"]("disabled"),
          (_0x53f8f2["querySelector"](".ux-call-to-action__text")["innerText"] =
            "Listing..."));
        var _0x5ea5ef = _0xd0ea0f["target"];
        console["log"]("item", _0x5ea5ef);
        for (; _0x5ea5ef && !_0x5ea5ef["classList"]["contains"]("s-item"); )
          _0x5ea5ef = _0x5ea5ef["parentElement"];
        console["log"]("item", _0x5ea5ef);
        if (_0x5ea5ef) {
          console["log"]("item", _0x5ea5ef);
          var _0x40f9c4 = _0x120abc(_0x5ea5ef, 0x0);
          console["log"]("itemData", _0x40f9c4);
          var _0x52bcdf = await new Promise((_0x291f38) => {
            chrome["runtime"]["sendMessage"](
              { type: "OpenEbayItemAndlistEbayItem", itemData: _0x40f9c4 },
              function (_0x1eb60b) {
                _0x291f38(_0x1eb60b["response"]);
              },
            );
          });
          console["log"]("response", _0x52bcdf);
          var _0x1f0c9e = _0x422faa(_0x52bcdf["response"]["message"]);
          (_0xd32433["appendChild"](_0x1f0c9e),
            (_0x53f8f2["querySelector"](".ux-call-to-action__text")[
              "innerText"
            ] =
              "itemListed" == _0x52bcdf["response"]["message"]["type"]
                ? "Listed!"
                : "Failed!"));
        }
      }
    }),
    _0xd32433
  );
}
function _0x422faa(_0x1700e5) {
  console["log"]("createDisplayElement\x20message", _0x1700e5);
  var _0x140b1a = document["createElement"]("div");
  _0x140b1a["className"] = "info-box";
  var _0x1fa3c9 = "itemListed" == _0x1700e5["type"] ? "success" : "error",
    _0x1923b7 = _0x1700e5["ebayItemLink"]
      ? "<a\x20href=\x22" +
        _0x1700e5["ebayItemLink"] +
        "\x22\x20target=\x22_blank\x22>View\x20Item</a>"
      : "Not\x20Available";
  return (
    (_0x140b1a["innerHTML"] =
      "\x0a\x20\x20\x20\x20\x20\x20<p>Status:\x20" +
      _0x1fa3c9 +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>Message:\x20" +
      _0x1700e5["message"] +
      "</p>\x0a\x20\x20\x20\x20\x20\x20<p>" +
      _0x1923b7 +
      "</p>"),
    _0x140b1a
  );
}
function _0x1a7481() {
  document["querySelectorAll"](".s-item")["forEach"]((_0xa50ccb, _0x2c6d00) => {
    const _0x4ba3aa = document["createElement"]("div");
    ((_0x4ba3aa["style"]["position"] = "absolute"),
      (_0x4ba3aa["style"]["top"] = "5px"),
      (_0x4ba3aa["style"]["left"] = "5px"),
      (_0x4ba3aa["style"]["backgroundColor"] = "white"),
      (_0x4ba3aa["style"]["padding"] = "5px"),
      (_0x4ba3aa["style"]["border"] = "1px\x20solid\x20black"),
      (_0x4ba3aa["style"]["borderRadius"] = "5px"),
      (_0x4ba3aa["style"]["zIndex"] = "1000"),
      (_0x4ba3aa["innerText"] = "Rank:\x20" + (_0x2c6d00 + 0x1)),
      (_0xa50ccb["style"]["position"] = "relative"),
      _0xa50ccb["appendChild"](_0x4ba3aa));
  });
}
function _0xe76416() {
  console["log"]("Selecting\x20all\x20items...");
  var _0x1ecc70 = document["querySelectorAll"]("#srp-river-results\x20.s-item");
  return (
    console["log"](_0x1ecc70),
    [
      ..._0x1ecc70,
      ...document["querySelectorAll"](".srp-results\x20.su-card-container"),
    ]
  );
}
function _0x3300d5(_0x4319cf) {
  var _0x438a6c = _0x4319cf["querySelector"](
    ".s-item__title--tag\x20.POSITIVE",
  );
  return (
    _0x438a6c ||
      (_0x438a6c = _0x4319cf["querySelector"](
        ".s-item__caption--signal.POSITIVE",
      )),
    _0x438a6c ||
      (_0x438a6c = _0x4319cf["querySelector"](".s-card__caption\x20.positive")),
    _0x438a6c
  );
}
function _0x120abc(_0x1f34ba, _0x598da8 = 0x0) {
  console["log"]("Extracting\x20item\x20data...", _0x1f34ba);
  var _0x26ec1 =
      _0x1f34ba["querySelector"](".s-item__title") ||
      _0x1f34ba["querySelector"](".s-card__title"),
    _0x43afa4 = _0x26ec1 ? _0x26ec1["querySelector"](".clipped") : null;
  _0x43afa4 && (_0x43afa4["textContent"] = "");
  var _0x9f8160 = _0x26ec1 ? _0x26ec1["textContent"] : null;
  const _0x5e232e = _0x598da8 + 0x1,
    _0x1a1f12 = null !== _0x1f34ba["querySelector"](".s-item__etrs-text");
  var _0x51b9ba = _0x3300d5(_0x1f34ba),
    _0x2f555a;
  _0x2f555a =
    null !== _0x51b9ba
      ? (_0x2f555a = (_0x2f555a = _0x51b9ba["textContent"])["replace"](
          "Sold",
          "",
        ))["trim"]()
      : null;
  var _0x2f4641 = {},
    _0x3206cf = "N/A";
  try {
    var _0x31037b = _0x1f34ba["querySelectorAll"](".total-sold-element");
    for (_0x598da8 = 0x0; _0x598da8 < _0x31037b["length"]; _0x598da8++) {
      var _0x2a1a8f = _0x31037b[_0x598da8],
        _0x272b6c = _0x2a1a8f["getAttribute"]("data-total-sold");
      _0x2f4641[_0x2a1a8f["getAttribute"]("data-last-x-days")] = _0x272b6c;
    }
    isNaN(_0x3206cf) && (_0x3206cf = "N/A");
  } catch (_0x5658c7) {
    console["log"](
      "Error\x20getting\x20total\x20sold\x20or\x20total\x20competitors",
      _0x5658c7,
    );
  }
  var _0x1060f5 =
    _0x1f34ba["querySelector"](".s-item__image-wrapper\x20img") ||
    _0x1f34ba["querySelector"](".image-treatment\x20img");
  _0x1060f5 = _0x1060f5["getAttribute"]("src");
  var _0x3ee760 = _0x1f34ba["querySelector"]("a")
    ["getAttribute"]("href")
    ["split"]("?")[0x0]
    ["split"]("/")
    ["pop"]();
  console["log"]("itemNumber", _0x3ee760);
  var _0xb14a74 = _0x1904f6(_0x1f34ba);
  return {
    title: _0x9f8160,
    price: _0x4b9c63(_0x1f34ba),
    listRanking: _0x5e232e,
    sponsored: _0x1a1f12,
    itemNumber: _0x3ee760,
    dateSold: _0x2f555a,
    totalSold: _0x2f4641,
    totalCompetitors: _0x3206cf,
    image: _0x1060f5,
    username: _0xb14a74,
    sellerFeedback: _0x47daf4(_0x1f34ba),
    sellerFeedbackPercent: _0x28aed4(_0x1f34ba),
  };
}
function _0x4b9c63(_0x55ebdb) {
  var _0x1e3a34 = _0x55ebdb["querySelector"](".s-item__price");
  _0x1e3a34 || (_0x1e3a34 = _0x55ebdb["querySelector"](".s-card__price"));
  var _0x5ea0c0 = _0x1e3a34["textContent"];
  return _0x6b5361(_0x5ea0c0);
}
function _0x5ac7b7() {
  var _0x116c74 = document["querySelectorAll"](
    ".su-card-container__attributes__secondary",
  );
  return (
    (_0x116c74 && 0x0 != _0x116c74["length"]) ||
      (_0x116c74 = document["querySelectorAll"](
        ".srp-results\x20.s-item__details-section--secondary",
      )),
    _0x116c74
  );
}
function _0x1b161a(_0x339a13) {
  var _0x105fdf = _0x339a13["querySelectorAll"](
    ".su-card-container__attributes__secondary\x20.s-card__attribute-row",
  );
  return 0x3 == _0x105fdf["length"]
    ? _0x105fdf[0x1]
    : 0x2 == _0x105fdf["length"] || 0x1 == _0x105fdf["length"]
      ? _0x105fdf[0x0]
      : _0x339a13["querySelector"](".s-item__seller-info-text") ||
        _0x339a13["querySelector"](".s-item__etrs-text") ||
        document["querySelector"](".s-item__etrs-text") ||
        _0x339a13["querySelector"](
          ".su-card-container__attributes__secondary\x20.secondary",
        );
}
function _0x1904f6(_0x22989a) {
  var _0xbeb72c = _0x1b161a(_0x22989a),
    _0x187003 = _0xbeb72c ? _0xbeb72c["innerText"] : null;
  return (
    (_0x187003 = (_0x187003 = _0x187003["split"]("(")[0x0])["trim"]())[
      "includes"
    ]("%") && (_0x187003 = _0x187003["replace"](/[\d.,]+%.*$/, "")["trim"]()),
    _0x187003
  );
}
function _0xeb99c9() {
  const _0x9508a7 = _0xe76416(),
    _0x25fe34 = [];
  for (let _0x38d097 = 0x0; _0x38d097 < _0x9508a7["length"]; _0x38d097++) {
    const _0x5a5df6 = _0x9508a7[_0x38d097];
    var _0x13a571;
    try {
      _0x13a571 = _0x120abc(_0x5a5df6, _0x38d097);
    } catch (_0x5e7d59) {
      console["error"]("Error\x20extracting\x20item\x20data:", _0x5e7d59);
      continue;
    }
    _0x25fe34["push"](_0x13a571);
  }
  return _0x25fe34;
}
function _0x1856e5(_0x252b45, _0x144b7b) {
  console["log"]("Received\x20itemNumber:", _0x252b45);
  let _0x17f86c = parseInt(_0x252b45);
  console["log"](
    "Item\x20number\x20after\x20conversion\x20to\x20integer:",
    _0x17f86c,
  );
  for (let _0x801d78 = 0x0; _0x801d78 < _0x144b7b["length"]; _0x801d78++) {
    const _0x1411a0 = _0x144b7b[_0x801d78];
    (console["log"]("Item\x20" + (_0x801d78 + 0x1) + ":", _0x1411a0),
      console["log"](
        "Item\x27s\x20number\x20in\x20data\x20before\x20conversion\x20to\x20integer:",
        _0x1411a0["itemNumber"],
      ));
    let _0x32f66b = parseInt(_0x1411a0["itemNumber"]);
    console["log"](
      "Item\x27s\x20number\x20in\x20data\x20after\x20conversion\x20to\x20integer:",
      _0x32f66b,
    );
    if (Number["isNaN"](_0x17f86c) || Number["isNaN"](_0x32f66b)) {
      console["log"](
        "Integer\x20conversion\x20failed.\x20Falling\x20back\x20to\x20string\x20comparison.",
      );
      let _0x1160be = String(_0x252b45)["trim"]();
      console["log"]("Trimmed\x20input\x20item\x20number:", _0x1160be);
      let _0x54c23f = String(_0x1411a0["itemNumber"])["trim"]();
      console["log"]("Trimmed\x20item\x20number\x20from\x20data:", _0x54c23f);
      if (_0x54c23f === _0x1160be)
        return (
          console["log"]("Item\x20found\x20using\x20string\x20comparison."),
          _0x1411a0
        );
    } else {
      console["log"]("Comparing\x20integers:", _0x32f66b, _0x17f86c);
      if (_0x32f66b === _0x17f86c)
        return (
          console["log"]("Item\x20found\x20using\x20integer\x20comparison."),
          _0x1411a0
        );
    }
  }
  return (console["log"]("No\x20matching\x20item\x20found."), null);
}
function _0x355dd9() {
  var _0x359794 = document["createElement"]("button");
  return (
    _0x359794["setAttribute"]("class", "btn-sort-by-total-sold"),
    _0x359794["classList"]["add"]("filter-date-context"),
    (_0x359794["id"] = "btn-sort-by-total-sold"),
    (_0x359794["innerHTML"] = "Total\x20Sold"),
    _0x359794["addEventListener"]("click", function (_0x128e57) {
      _0x5c371c();
    }),
    _0x359794
  );
}
async function _0x5c371c() {
  var _0x5c030c = document["querySelectorAll"]("li");
  console["log"]("items", _0x5c030c);
  var _0x5564f9 = Array["from"](_0x5c030c);
  (console["log"]("itemsArray", _0x5564f9),
    (_0x5564f9 = _0x5564f9["filter"]((_0x31445a) =>
      _0x31445a["querySelector"](_0x30748a()),
    )),
    console["log"](
      "removed\x20any\x20element\x20that\x20doesnt\x20have\x20s-item__caption-section",
      _0x5564f9,
    ),
    (_0x5564f9 = _0x5564f9["filter"]((_0x49fc5a) =>
      _0x49fc5a["querySelector"](".total-sold-element"),
    )),
    console["log"](
      "removed\x20any\x20item\x20that\x20doesnt\x20have\x20data-total-sold\x20attribute",
      _0x5564f9,
    ));
  var { selectedFilter: _0x19b4d7 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (_0x5564f9["sort"]((_0x27b827, _0x1297b7) => {
    (console["log"]("a", _0x27b827), console["log"]("b", _0x1297b7));
    var _0x55e8dc = _0x27b827["querySelector"](
        ".total-sold-element[data-last-x-days=\x22" + _0x19b4d7 + "\x22]",
      )["getAttribute"]("data-total-sold"),
      _0x54cf59 = _0x1297b7["querySelector"](
        ".total-sold-element[data-last-x-days=\x22" + _0x19b4d7 + "\x22]",
      )["getAttribute"]("data-total-sold");
    return "Rate\x20Limited" == _0x55e8dc || "Rate\x20Limited" == _0x54cf59
      ? 0x0
      : _0x54cf59 - _0x55e8dc;
  }),
    console["log"]("itemsArray", _0x5564f9),
    _0x5564f9["reverse"]());
  var _0x9937e4 = _0x5564f9[0x0]["parentNode"];
  _0x5564f9["forEach"]((_0x567812) =>
    _0x9937e4["insertBefore"](
      _0x567812,
      _0x9937e4["firstChild"]["nextSibling"],
    ),
  );
}
function _0x441e89() {
  var _0x326cbd = document["createElement"]("button");
  return (
    _0x326cbd["setAttribute"]("class", "btn-sort-by-sold-date"),
    (_0x326cbd["id"] = "btn-sort-by-sold-date"),
    (_0x326cbd["innerHTML"] = "Sold\x20Date"),
    _0x326cbd["addEventListener"]("click", function (_0x346321) {
      _0x8025a3();
    }),
    _0x326cbd
  );
}
function _0x8025a3() {
  var _0x1e7e9c = document["querySelectorAll"]("li"),
    _0x34511e = Array["from"](_0x1e7e9c);
  ((_0x34511e = _0x34511e["filter"]((_0x550047) =>
    _0x550047["querySelector"](_0x30748a()),
  )),
    console["log"]("itemsArray", _0x34511e),
    _0x34511e["sort"]((_0x4819a5, _0x342625) => {
      (console["log"]("a", _0x4819a5), console["log"]("b", _0x342625));
      var _0x4f007 = _0x48c8b8(_0x4819a5),
        _0x40229f = _0x48c8b8(_0x342625);
      (console["log"]("aDateSold", _0x4f007),
        console["log"]("bDateSold", _0x40229f));
      if (null == _0x4f007 || null == _0x40229f) return 0x0;
      var _0x573dd6 = new Date(_0x4f007);
      return new Date(_0x40229f) - _0x573dd6;
    }),
    _0x34511e["reverse"]());
  var _0x1fba23 = _0x34511e[0x0]["parentNode"];
  (_0x34511e["forEach"]((_0x4cd5b8) =>
    _0x1fba23["insertBefore"](
      _0x4cd5b8,
      _0x1fba23["firstChild"]["nextSibling"],
    ),
  ),
    console["log"]("itemsArray", _0x34511e));
}
function _0x48c8b8(_0xa759a8) {
  var _0x6d103e = _0xa759a8["querySelector"](
    ".s-item__title--tag\x20.POSITIVE",
  );
  null === _0x6d103e &&
    (_0x6d103e = _0xa759a8["querySelector"](
      ".s-item__caption--signal.POSITIVE",
    ));
  var _0x4a8125;
  _0x4a8125 =
    null !== _0x6d103e
      ? (_0x4a8125 = (_0x4a8125 = _0x6d103e["textContent"])["replace"](
          "Sold",
          "",
        ))["trim"]()
      : null;
  var _0x405871 = new Date(_0x4a8125),
    _0x4f75c2 = (new Date() - _0x405871) / 0x5265c00;
  return (console["log"]("daysDifference", _0x4f75c2), _0x4a8125);
}
function _0x1205ed() {
  var _0x35e4d2 = document["querySelectorAll"]("li"),
    _0x586931 = Array["from"](_0x35e4d2);
  ((_0x586931 = (_0x586931 = _0x586931["filter"]((_0x19be8b) =>
    _0x19be8b["querySelector"](".s-item__price"),
  ))["filter"]((_0x19c53d) => _0x19c53d["id"]["startsWith"]("item")))["sort"](
    (_0x53ba0d, _0xc40226) => {
      (console["log"]("a", _0x53ba0d), console["log"]("b", _0xc40226));
      var _0x4c00cd =
          _0x53ba0d["querySelector"](".s-item__price")["textContent"],
        _0x1ba62d = _0xc40226["querySelector"](".s-item__price")["textContent"];
      return (
        (_0x4c00cd = _0x4c00cd["replace"]("$", "")),
        (_0x1ba62d = _0x1ba62d["replace"]("$", "")),
        (_0x4c00cd = _0x4c00cd["replace"](/[^0-9.]/g, "")),
        (_0x1ba62d = _0x1ba62d["replace"](/[^0-9.]/g, "")),
        (_0x4c00cd = parseFloat(_0x4c00cd)) - parseFloat(_0x1ba62d)
      );
    },
  ),
    _0x586931["reverse"]());
  var _0x365576 = _0x586931[0x0]["parentNode"];
  _0x586931["forEach"]((_0x1b8d0c) =>
    _0x365576["insertBefore"](
      _0x1b8d0c,
      _0x365576["firstChild"]["nextSibling"],
    ),
  );
}
function _0x105221() {
  var _0x1cf174 = document["querySelectorAll"]("li"),
    _0x576bf9 = Array["from"](_0x1cf174);
  ((_0x576bf9 = (_0x576bf9 = _0x576bf9["filter"]((_0x1ba461) =>
    _0x1ba461["querySelector"](".s-item__price"),
  ))["filter"]((_0x1b3374) => _0x1b3374["id"]["startsWith"]("item")))["sort"](
    (_0x70a598, _0x25ada8) => {
      (console["log"]("a", _0x70a598), console["log"]("b", _0x25ada8));
      var _0x4ad44a =
          _0x70a598["querySelector"](".s-item__price")["textContent"],
        _0xef2286 = _0x25ada8["querySelector"](".s-item__price")["textContent"];
      return (
        (_0x4ad44a = _0x4ad44a["replace"]("$", "")),
        (_0xef2286 = _0xef2286["replace"]("$", "")),
        (_0x4ad44a = _0x4ad44a["replace"](/[^0-9.]/g, "")),
        (_0xef2286 = _0xef2286["replace"](/[^0-9.]/g, "")),
        (_0x4ad44a = parseFloat(_0x4ad44a)),
        (_0xef2286 = parseFloat(_0xef2286)) - _0x4ad44a
      );
    },
  ),
    _0x576bf9["reverse"]());
  var _0xf80ec = _0x576bf9[0x0]["parentNode"];
  _0x576bf9["forEach"]((_0x5b6979) =>
    _0xf80ec["insertBefore"](_0x5b6979, _0xf80ec["firstChild"]["nextSibling"]),
  );
}
function _0x1f638e() {
  var _0x2e012a = document["createElement"]("button");
  return (
    _0x2e012a["setAttribute"]("class", "btn-sort-by-lowest-price"),
    (_0x2e012a["id"] = "btn-sort-by-lowest-price"),
    (_0x2e012a["innerHTML"] = "Lowest\x20Price"),
    _0x2e012a["setAttribute"]("data-sort", "lowest-price"),
    _0x2e012a["addEventListener"]("click", function (_0x25b446) {
      "lowest-price" == _0x2e012a["getAttribute"]("data-sort")
        ? (_0x1205ed(),
          _0x2e012a["setAttribute"]("data-sort", "highest-price"),
          (_0x2e012a["innerHTML"] = "Highest\x20Price"))
        : (_0x105221(),
          _0x2e012a["setAttribute"]("data-sort", "lowest-price"),
          (_0x2e012a["innerHTML"] = "Lowest\x20Price"));
    }),
    _0x2e012a
  );
}
function _0x47daf4(_0xf40605) {
  var _0x3b6dae = _0x1b161a(_0xf40605);
  const _0x29b8e0 = _0x3b6dae?.["textContent"]["match"](/\(([^)]+)\)/),
    _0x53bb0b = _0x29b8e0?.[0x1]?.["trim"]() || null;
  if (_0x53bb0b && _0x53bb0b["toLowerCase"]()["includes"]("k")) {
    const _0x1f13eb = _0x53bb0b["match"](/[\d,]+/);
    if (_0x1f13eb)
      return 0x3e8 * parseInt(_0x1f13eb[0x0]["replace"](/,/g, ""), 0xa);
  }
  if (!_0x53bb0b) return null;
  const _0xa9647e = _0x53bb0b["replace"](/[.,](?=\d{3}\b)/g, "")["replace"](
      /[,\.]\d+$/,
      "",
    ),
    _0x3e646a = parseInt(_0xa9647e, 0xa);
  return isNaN(_0x3e646a) ? null : _0x3e646a;
}
function _0x28aed4(_0x33a141) {
  var _0x146aec = _0x1b161a(_0x33a141),
    _0x3088ef = _0x146aec?.["textContent"]["match"](
      /(\d{1,3}(?:[.,]\d{1,3})?)\s*%/,
    ),
    _0x5c450b = null;
  return (
    _0x3088ef
      ? (_0x5c450b = _0x3088ef[0x1]["replace"](",", "."))
      : console["warn"](
          "No\x20feedback\x20percent\x20found\x20in\x20username\x20element:",
          _0x146aec,
        ),
    _0x5c450b
  );
}
function _0x138038() {
  const _0x3990b0 = document["getElementById"](
    "seller-settings-modal-container",
  );
  _0x3990b0 && _0x3990b0["remove"]();
  const _0x1e6a60 = document["createElement"]("div");
  ((_0x1e6a60["id"] = "seller-settings-modal-container"),
    (_0x1e6a60["innerHTML"] =
      "\x0a\x20\x20\x20\x20<div\x20class=\x22seller-settings-modal-overlay\x22></div>\x0a\x20\x20\x20\x20<div\x20class=\x22seller-settings-modal\x22>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22seller-settings-modal-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22seller-settings-modal-title\x22>Seller\x20Scraper\x20Settings</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22close-seller-settings-btn\x22\x20class=\x22seller-settings-close-btn\x22>&times;</button>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22seller-settings-modal-body\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<label\x20for=\x22min-feedback-input\x22>Minimum\x20Feedback\x20Count:</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22number\x22\x20id=\x22min-feedback-input\x22\x20class=\x22seller-settings-input\x22\x20min=\x220\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<label\x20for=\x22min-percentage-input\x22>Minimum\x20Positive\x20%:</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22number\x22\x20id=\x22min-percentage-input\x22\x20class=\x22seller-settings-input\x22\x20min=\x220\x22\x20max=\x22100\x22>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22save-seller-settings-btn\x22\x20class=\x22seller-settings-save-btn\x22>Save\x20Settings</button>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20</div>\x0a\x20\x20"),
    document["body"]["appendChild"](_0x1e6a60),
    chrome["storage"]["local"]["get"](
      ["minSellerFeedback", "minSellerPercent"],
      (_0x5f2868) => {
        ((document["getElementById"]("min-feedback-input")["value"] =
          _0x5f2868["minSellerFeedback"] ?? 0x0),
          (document["getElementById"]("min-percentage-input")["value"] =
            _0x5f2868["minSellerPercent"] ?? 0x5a));
      },
    ),
    (document["getElementById"]("close-seller-settings-btn")["onclick"] =
      () => {
        _0x1e6a60["remove"]();
      }),
    (document["getElementById"]("save-seller-settings-btn")["onclick"] = () => {
      const _0x1b9ee4 =
          parseInt(document["getElementById"]("min-feedback-input")["value"]) ||
          0x0,
        _0x25de63 =
          parseInt(
            document["getElementById"]("min-percentage-input")["value"],
          ) || 0x5a;
      chrome["storage"]["local"]["set"](
        { minSellerFeedback: _0x1b9ee4, minSellerPercent: _0x25de63 },
        () => {
          (alert("Settings\x20saved."), _0x1e6a60["remove"]());
        },
      );
    }));
}
async function _0x695f55() {
  const _0x2482ae = document["createElement"]("div");
  _0x2482ae["className"] = "seller-actions-bar-wrapper";
  const { ebayCompetitors: ebayCompetitors = [] } =
    await chrome["storage"]["local"]["get"]("ebayCompetitors");
  return (
    (_0x2482ae["innerHTML"] =
      "\x0a\x20\x20\x20\x20<div\x20class=\x22seller-extract-btn-group\x22>\x0a\x20\x20\x20\x20\x20\x20<button\x20class=\x22seller-extract-btn\x22\x20id=\x22seller-extract-btn\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20Extract\x20Sellers\x20(0\x20new,\x20" +
      ebayCompetitors["length"] +
      "\x20total)\x0a\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20<button\x20class=\x22seller-clear-btn\x22\x20id=\x22seller-clear-btn\x22\x20title=\x22Clear\x20all\x20saved\x20sellers\x22>✖</button>\x0a\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20<button\x20class=\x22seller-research-btn\x22\x20id=\x22seller-research-btn\x22\x20title=\x22Open\x20Competitor\x20Research\x20Tool\x22>📊</button>\x0a\x20\x20\x20\x20<button\x20class=\x22seller-settings-icon-btn\x22\x20id=\x22seller-settings-btn\x22\x20title=\x22Settings\x22>⚙️</button>\x0a\x20\x20"),
    (_0x2482ae["querySelector"]("#seller-extract-btn")["onclick"] =
      async () => {
        const _0x46c48a = await _0x28aee1(),
          { ebayCompetitors: ebayCompetitors = [] } =
            await chrome["storage"]["local"]["get"]("ebayCompetitors");
        document["getElementById"]("seller-extract-btn")["innerText"] =
          "Extract\x20Sellers\x20(+" +
          _0x46c48a["length"] +
          "\x20new,\x20" +
          ebayCompetitors["length"] +
          "\x20total)";
      }),
    (_0x2482ae["querySelector"]("#seller-clear-btn")["onclick"] = async () => {
      confirm("Clear\x20all\x20saved\x20sellers?") &&
        (await chrome["storage"]["local"]["set"]({ ebayCompetitors: [] }),
        (document["getElementById"]("seller-extract-btn")["innerText"] =
          "Extract\x20Sellers\x20(0\x20new,\x200\x20total)"),
        console["log"]("✅\x20Seller\x20list\x20cleared."));
    }),
    (_0x2482ae["querySelector"]("#seller-settings-btn")["onclick"] = () => {
      _0x138038();
    }),
    (_0x2482ae["querySelector"]("#seller-research-btn")["onclick"] = () => {
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        options: { active: !0x0 },
        url: "chrome-extension://eohieelgcgopcnjjjanjgfjdaifolokm/Competitor_Research/index.html",
      });
    }),
    _0x2482ae
  );
}
async function _0x28aee1() {
  const _0x3d37d0 = _0xeb99c9(),
    { minSellerFeedback: _0x276aa5 = 0x0, minSellerPercent: _0x40522b = 0x0 } =
      await chrome["storage"]["local"]["get"]([
        "minSellerFeedback",
        "minSellerPercent",
      ]),
    _0x515612 = [];
  console["groupCollapsed"](
    "🔍\x20Extracting\x20sellers\x20(Min\x20Feedback:\x20" +
      _0x276aa5 +
      ",\x20Min\x20%:\x20" +
      _0x40522b +
      ")",
  );
  for (const _0x2ae0c5 of _0x3d37d0) {
    const _0x514cba = _0x2ae0c5["username"] || "N/A",
      _0x2dfa4d = _0x2ae0c5["sellerFeedback"] ?? 0x0,
      _0x1f07aa = _0x2ae0c5["sellerFeedbackPercent"] ?? 0x0,
      _0x17c3fa = _0x2dfa4d >= _0x276aa5 && _0x1f07aa >= _0x40522b;
    (console["group"](
      (_0x17c3fa ? "✅" : "❌") + "\x20Seller:\x20" + _0x514cba,
    ),
      console["log"]("📦\x20Feedback\x20Count:", _0x2dfa4d),
      console["log"]("📊\x20Feedback\x20Percent:", _0x1f07aa + "%"),
      console["log"](
        "🔒\x20Meets\x20Min\x20Feedback?",
        _0x2dfa4d + "\x20>=\x20" + _0x276aa5,
      ),
      console["log"](
        "🔒\x20Meets\x20Min\x20%?",
        _0x1f07aa + "\x20>=\x20" + _0x40522b,
      ));
    if (_0x17c3fa)
      (_0x515612["push"](_0x514cba),
        console["log"]("✅\x20Added\x20to\x20list."));
    else console["warn"]("⛔\x20Excluded\x20from\x20list.");
    console["groupEnd"]();
  }
  (console["groupEnd"](),
    console["log"]("🎯\x20Final\x20Seller\x20List:", _0x515612));
  var _0x146a3c = [...new Set(_0x515612)],
    { ebayCompetitors: _0x5a7947 } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors");
  return (
    (_0x5a7947 = _0x5a7947 || []),
    (_0x146a3c = _0x146a3c["filter"](
      (_0x5f0f7b) => !_0x5a7947["includes"](_0x5f0f7b),
    )),
    _0x5a7947["push"](..._0x146a3c),
    (_0x5a7947 = [...new Set(_0x5a7947)]),
    chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x5a7947 }),
    (document["getElementById"]("seller-extract-btn")["innerText"] =
      "Extract\x20Sellers\x20(+" +
      _0x146a3c["length"] +
      "\x20new,\x20" +
      _0x5a7947["length"] +
      "\x20total)"),
    _0x146a3c
  );
}
(console["log"]("public_search\x20content.js\x20loaded"),
  chrome["runtime"]["onMessage"]["addListener"](
    function (_0x2c0e1a, _0xb09708, _0x41ec89) {
      console["log"]("Message\x20received\x20from\x20popup.js:", _0x2c0e1a);
      if ("research_seo" === _0x2c0e1a["message"]) {
        console["log"]("clicked_browser_action\x20message\x20received");
        var _0x322f5c = _0xeb99c9();
        (console["log"]("ebaySearchItems", _0x322f5c),
          chrome["storage"]["local"]["set"](
            { ebaySearchItems: _0x322f5c },
            function () {
              console["log"]("Value\x20is\x20set\x20to\x20" + _0x322f5c);
              var _0x23e9c2 = chrome["runtime"]["getURL"](
                "research_seo/index.html",
              );
              chrome["runtime"]["sendMessage"](
                { type: "openNewTab", url: _0x23e9c2 },
                function (_0x56800c) {
                  console["log"]("Message\x20sent\x20to\x20background.js");
                },
              );
            },
          ));
      }
      if ("retrieve_competitors" === _0x2c0e1a["type"])
        return (
          _0x41ec89({ ebaySearchItems: (_0x322f5c = _0xeb99c9()) }),
          !0x0
        );
      return (
        "save_sellers_list" === _0x2c0e1a["type"] &&
          (console["log"]("Saving\x20sellers\x20list..."), _0x138038()),
        !0x0
      );
    },
  ));
async function _0x2286e2() {
  var _0x47ca39 = _0x5c7983(),
    _0x26da57 = _0x355dd9(),
    _0x3691db = _0x441e89(),
    _0x2af916 = _0x1f638e(),
    _0x5762ce = document["querySelector"](".s-answer-region-center-top"),
    _0x275c55 = await _0x695f55();
  (_0x5762ce["appendChild"](_0x275c55), _0x5762ce["appendChild"](_0x47ca39));
  var _0x588c12 = document["createElement"]("div");
  _0x588c12["setAttribute"]("id", "sort-div");
  var _0x1f2c42 = document["createElement"]("label");
  (_0x1f2c42["setAttribute"]("id", "sort-label"),
    (_0x1f2c42["innerHTML"] = "<b>Sort\x20by:\x20\x20\x20</b>"),
    _0x588c12["appendChild"](_0x1f2c42),
    _0x588c12["appendChild"](_0x26da57),
    _0x588c12["appendChild"](_0x3691db),
    _0x588c12["appendChild"](_0x2af916),
    _0x5762ce["appendChild"](_0x588c12));
  var _0x34c539 = _0x5ac7b7();
  console["log"]("sellerInfoElements", _0x34c539);
  for (i = 0x0; i < _0x34c539["length"]; i++) {
    var _0x5294e8 = _0x34c539[i],
      _0x1d05bd;
    try {
      _0x1d05bd = _0x1904f6(_0x5294e8);
    } catch (_0x14dd81) {
      console["log"](
        "Error\x20getting\x20seller\x20name\x20from\x20node",
        _0x14dd81,
      );
      continue;
    }
    var _0x34b100 = _0x23223e();
    _0x5294e8["appendChild"](_0x34b100);
    var _0x1f4b8d = _0x4b9c63(_0x4479e9(_0x5294e8)),
      _0x5f4805 = await _0x256d7f(_0x1f4b8d);
    (_0x5294e8["appendChild"](_0x5f4805),
      await _0x46082e(
        _0x5294e8["querySelector"]("#saveSellerLink"),
        _0x1d05bd,
      ));
  }
  (_0x54296e(), _0x25dde7(), _0x3626e3());
  try {
    _0x1a7481();
  } catch (_0x1acb7e) {}
  try {
    document["querySelectorAll"](".saveSellerLink")["forEach"](
      function (_0x53e160) {
        _0x53e160["addEventListener"]("click", async function (_0x180a8f) {
          var _0x288d10 = _0x4479e9(_0x53e160);
          (console["log"]("itemContainer", _0x288d10),
            await _0x53fea5(_0x288d10));
        });
      },
    );
  } catch (_0x31298f) {}
}
_0x2286e2();
async function _0x53fea5(_0x37eec8) {
  await new Promise((_0x1e3468) => setTimeout(_0x1e3468, 0x12c));
  var _0x5d3bf3 = _0x1904f6(_0x37eec8);
  console["log"]("clickedUserName", _0x5d3bf3);
  var _0xf1eb8e = _0x5ac7b7();
  for (i = 0x0; i < _0xf1eb8e["length"]; i++)
    if (_0xf1eb8e[i] !== _0x37eec8) {
      var _0x3a9331 = _0xf1eb8e[i];
      try {
        var _0x1121ea = _0x1904f6(_0x3a9331);
        await _0x46082e(
          _0x3a9331["querySelector"]("#saveSellerLink"),
          _0x1121ea,
        );
      } catch (_0xedf484) {
        console["log"](
          "Error\x20getting\x20seller\x20name\x20from\x20node",
          _0xedf484,
        );
        continue;
      }
    } else
      console["log"]("found\x20clicked\x20item\x20container,\x20skipping...");
}
