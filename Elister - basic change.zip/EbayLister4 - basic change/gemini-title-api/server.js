const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || 'YOUR_API_KEY_HERE');

// Function to build the prompt based on language
function buildPrompt(productTitle, productDescription, language) {
  const languageInstructions = {
    english: 'Generate titles in English',
    spanish: 'Generate titles in Spanish (Español)',
    french: 'Generate titles in French (Français)',
    german: 'Generate titles in German (Deutsch)',
    italian: 'Generate titles in Italian (Italiano)'
  };

  const languageInstruction = languageInstructions[language] || languageInstructions.english;

  return `### eBay Title Optimization Task

**Instructions**: Create 5 compelling eBay titles that highlight unique features and elevate perceived value. ${languageInstruction}.

**Requirements**:
1. **SEO Optimization**: Include relevant keywords for searchability
2. **Product Type First**: Mention the product type within the first 4 words
3. **Character Limit**: Each title must be between 60-80 characters (eBay optimized)
4. **High-Value Language**: Use adjectives that suggest quality and value
5. **Key Features**: Incorporate important specifications from the description
6. **Format**: Return ONLY 5 titles, one per line, no numbering, no extra text

---

**Product Information**:
- **Original Title**: ${productTitle}
- **Description**: ${productDescription}

---

**Output Format** (exactly 5 titles, one per line):`;
}

// Main endpoint
app.post('/', async (req, res) => {
  try {
    const { product_title, product_description, language = 'english', request_type } = req.body;

    // Validate request
    if (request_type !== 'generate_10_titles') {
      return res.status(400).json({ error: 'Invalid request_type' });
    }

    if (!product_title || !product_description) {
      return res.status(400).json({ error: 'Missing required fields: product_title, product_description' });
    }

    console.log(`[${new Date().toISOString()}] Processing request for: ${product_title.substring(0, 50)}...`);

    // Build prompt
    const prompt = buildPrompt(product_title, product_description, language);

    // Call Gemini API - Using Gemini 2.5 Flash-Lite (cost-optimized, thinking disabled)
    const model = genAI.getGenerativeModel({
      model: 'gemini-2.5-flash-lite',
      generationConfig: {
        temperature: 0.7,
        topP: 0.95,
        topK: 40,
        maxOutputTokens: 200, // Limit output for 5 titles only
      }
    });

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    // Log token usage for monitoring
    const usageMetadata = response.usageMetadata;
    if (usageMetadata) {
      console.log(`[TOKEN USAGE] Model: gemini-2.5-flash-lite | Input: ${usageMetadata.promptTokenCount} | Output: ${usageMetadata.candidatesTokenCount} | Total: ${usageMetadata.totalTokenCount}`);
    }

    // Parse response - split by newlines and clean up
    const titles = text
      .trim()
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0 && !line.match(/^[\d\.\-\*]+/)) // Remove numbered/bulleted lines
      .filter(line => line.length >= 40) // Only keep substantial titles
      .slice(0, 5); // Take only first 5

    // Ensure we have exactly 5 titles
    if (titles.length < 5) {
      console.warn(`Only generated ${titles.length} titles, expected 5`);
    }

    console.log(`[${new Date().toISOString()}] Generated ${titles.length} titles successfully`);

    // Return in same format as original API (array of strings)
    res.json(titles);

  } catch (error) {
    console.error('Error generating titles:', error);
    res.status(500).json({
      error: 'Failed to generate titles',
      details: error.message
    });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'Gemini Title Generator' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Gemini Title API running on port ${PORT}`);
  console.log(`📝 Endpoint: POST http://localhost:${PORT}/`);
  console.log(`❤️  Health check: GET http://localhost:${PORT}/health`);
});
