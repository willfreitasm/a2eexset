function _0x49fc08() {
  return new Promise((_0x189ce7) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x189ce7();
      });
    });
  });
}
function _0x51150a() {
  return new Promise((_0x10c10d) => {
    requestIdleCallback(() => {
      _0x10c10d();
    });
  });
}
function _0x1967e0(_0x37d3f1 = 0x3e8) {
  return new Promise((_0x15c6f6, _0xa423db) => {
    let _0x56ad85,
      _0x279227 = Date["now"](),
      _0x44d6c1 = !0x1;
    function _0x2c6a3a() {
      if (Date["now"]() - _0x279227 > _0x37d3f1)
        (_0x44d6c1 && _0x56ad85["disconnect"](), _0x15c6f6());
      else setTimeout(_0x2c6a3a, _0x37d3f1);
    }
    const _0xb62bd5 = () => {
        _0x279227 = Date["now"]();
      },
      _0xc6ca30 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x56ad85 = new MutationObserver(_0xb62bd5)),
        _0x56ad85["observe"](document["body"], _0xc6ca30),
        (_0x44d6c1 = !0x0),
        setTimeout(_0x2c6a3a, _0x37d3f1));
    else
      window["onload"] = () => {
        ((_0x56ad85 = new MutationObserver(_0xb62bd5)),
          _0x56ad85["observe"](document["body"], _0xc6ca30),
          (_0x44d6c1 = !0x0),
          setTimeout(_0x2c6a3a, _0x37d3f1));
      };
  });
}
async function _0x2d2d44() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x1967e0(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
function _0x231ef2(
  _0x3e6795 = null,
  _0x5f4c1d = null,
  _0x10c05f = null,
  _0x4a5088 = null,
) {
  var _0x5d078e = document["createElement"]("a");
  (_0x5d078e["setAttribute"]("class", "a-link-text"),
    _0x5d078e["classList"]["add"]("icon"),
    _0x5d078e["classList"]["add"]("amazonSearchLink"),
    _0x5d078e["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x33f0c2 = document["createElement"]("img");
  return (
    _0x33f0c2["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x33f0c2["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5d078e["appendChild"](_0x33f0c2),
    _0x5d078e["addEventListener"]("click", async function (_0xb01a2b) {
      (_0xb01a2b["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x3e6795) {
        var _0x497fc6 = _0x4d7269(_0xb01a2b);
        if (!_0x497fc6) return;
        var _0xe2703d = extractItemData(_0x497fc6);
        ((_0x3e6795 = _0xe2703d["title"])["endsWith"]("...") &&
          (_0x3e6795 = _0x3e6795["substring"](
            0x0,
            _0x3e6795["lastIndexOf"]("\x20"),
          )),
          _0x3e6795["length"] > 0x4b &&
            (_0x3e6795 = _0x3e6795["substring"](
              0x0,
              _0x3e6795["lastIndexOf"]("\x20"),
            )));
      }
      var { amazonSortType: _0x2dfac9 } =
        await chrome["storage"]["local"]["get"]("amazonSortType");
      (console["log"]("amazonSortType", _0x2dfac9),
        _0x2dfac9 || (_0x2dfac9 = "reviews"),
        console["log"]("amazonSortType", _0x2dfac9),
        console["log"]("ebayButton\x20clicked"));
      var { domain: _0x342596 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x3e6795["length"] > 0x50; )
        _0x3e6795 = _0x3e6795["substring"](
          0x0,
          _0x3e6795["lastIndexOf"]("\x20"),
        );
      var { amazonSearchType: _0x25cc73 } =
          await chrome["storage"]["local"]["get"]("amazonSearchType"),
        _0x279263 = _0x3e6795;
      "keywords" == _0x25cc73 && (_0x279263 = await _0x2a90e4(_0x3e6795));
      try {
        _0xe2703d = extractItemData(_0x497fc6);
      } catch (_0x56195a) {
        console["log"]("error", _0x56195a);
      }
      (_0xe2703d ||
        (_0xe2703d = {
          title: _0x3e6795,
          price: _0x5f4c1d,
          itemNumber: _0x10c05f,
          image: _0x4a5088,
        }),
        console["log"]("itemData", _0xe2703d),
        chrome["runtime"]["sendMessage"]({
          type: "search-on-amazon",
          searchQuery: _0x279263,
          options: { isTabActive: !0x0, sort: _0x2dfac9 },
          itemData: _0xe2703d,
        }));
    }),
    _0x5d078e
  );
}
function _0x2ff286(_0x12529b) {
  var _0x4a8f52 = document["createElement"]("a");
  (_0x4a8f52["setAttribute"]("id", "amazonLinkFromItemNumber"),
    _0x4a8f52["setAttribute"]("class", "a-link-text"),
    _0x4a8f52["classList"]["add"]("icon"),
    _0x4a8f52["classList"]["add"]("amazonSearchLink"),
    _0x4a8f52["setAttribute"](
      "title",
      "Search\x20Amazon\x20for\x20this\x20item",
    ));
  var _0x24d4b4 = document["createElement"]("img");
  return (
    _0x24d4b4["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x24d4b4["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4a8f52["appendChild"](_0x24d4b4),
    _0x4a8f52["addEventListener"]("click", async function (_0x1ab214) {
      (_0x1ab214["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("amazonLinkFromItemNumber\x20clicked", _0x12529b),
        chrome["runtime"]["sendMessage"]({
          type: "grab_sku_from_ebay_item_and_open_product",
          itemNumber: _0x12529b,
        }));
    }),
    _0x4a8f52
  );
}
function _0x4e4a74(_0x241f12) {
  var _0x596b1a = document["createElement"]("a");
  (_0x596b1a["setAttribute"]("id", "amazonLink"),
    _0x596b1a["setAttribute"]("class", "a-link-text"),
    _0x596b1a["classList"]["add"]("icon"),
    _0x596b1a["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0xa4f991 = document["createElement"]("img");
  return (
    _0xa4f991["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0xa4f991["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x596b1a["appendChild"](_0xa4f991),
    _0x596b1a["addEventListener"]("click", async function (_0x5a85ff) {
      (_0x5a85ff["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x53af32 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x2c03ba =
          "https://www.amazon." +
          _0x53af32 +
          "/dp/" +
          _0x241f12 +
          "?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x2c03ba });
    }),
    _0x596b1a
  );
}
function _0x2043c4(_0xf8ce7c) {
  var _0x550296 = document["createElement"]("a");
  (_0x550296["setAttribute"]("id", "amazonLink"),
    _0x550296["setAttribute"]("class", "a-link-text"),
    _0x550296["classList"]["add"]("icon"),
    _0x550296["classList"]["add"]("amazonLink"),
    _0x550296["setAttribute"](
      "title",
      "Open\x20Amazon\x20Listing\x20for\x20this\x20SKU",
    ));
  var _0x150b76 = document["createElement"]("img");
  return (
    _0x150b76["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/amazon-icon.png"),
    ),
    _0x150b76["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x550296["appendChild"](_0x150b76),
    _0x550296["addEventListener"]("click", async function (_0x564185) {
      (_0x564185["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      try {
        _0xf8ce7c(_0x564185);
      } catch (_0xb3f79c) {
        console["error"]("Failed\x20to\x20open\x20Amazon\x20tab:", _0xb3f79c);
      }
    }),
    _0x550296
  );
}
function _0x5351d0(
  _0x536663 = null,
  _0x197b06,
  _0x592957 = "icons/ebay-bag.png",
) {
  console["log"]("createEbaySearchButton", _0x536663, _0x197b06);
  var _0x3fb0ed = document["createElement"]("a");
  (_0x3fb0ed["setAttribute"]("id", "ebayLink"),
    _0x3fb0ed["setAttribute"]("class", "a-link-text"),
    _0x3fb0ed["classList"]["add"]("icon"),
    _0x197b06 && _0x197b06["soldItems"]
      ? _0x3fb0ed["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20sold\x20items",
        )
      : _0x3fb0ed["setAttribute"](
          "title",
          "Search\x20eBay\x20for\x20this\x20item",
        ));
  var _0x231010 = document["createElement"]("img");
  return (
    _0x231010["setAttribute"]("src", chrome["runtime"]["getURL"](_0x592957)),
    _0x231010["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3fb0ed["appendChild"](_0x231010),
    _0x3fb0ed["addEventListener"]("click", async function (_0x3ec985) {
      (_0x3ec985["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x536663) console["log"]("title\x20found", _0x536663);
      else {
        console["log"]("title\x20not\x20found");
        var _0x246f43 = _0x4d7269(_0x3ec985);
        if (!_0x246f43) return;
        var _0x555486 = extractItemData(_0x246f43);
        _0x536663 = _0x555486["title"];
      }
      console["log"]("ebayButton\x20clicked");
      var { domain: _0x2bc288 } =
        await chrome["storage"]["local"]["get"]("domain");
      for (; _0x536663["length"] > 0x50; )
        _0x536663 = _0x536663["substring"](
          0x0,
          _0x536663["lastIndexOf"]("\x20"),
        );
      var _0x4befb5 =
        "https://www.ebay." +
        _0x2bc288 +
        "/sch/i.html?_nkw=" +
        encodeURIComponent(_0x536663) +
        "&_odkw=" +
        encodeURIComponent(_0x536663);
      (_0x197b06 && _0x197b06["soldItems"] && (_0x4befb5 += "&LH_Sold=1"),
        _0x197b06 && _0x197b06["sortLowToHigh"] && (_0x4befb5 += "&_sop=15"),
        _0x197b06 && _0x197b06["endedRecently"] && (_0x4befb5 += "&_sop=13"),
        (_0x4befb5 += "&LH_ItemCondition=1000"),
        (_0x4befb5 += "&LH_FS=1"),
        chrome["runtime"]["sendMessage"]({
          type: "openNewTab",
          url: _0x4befb5,
        }));
    }),
    _0x3fb0ed
  );
}
function _0x2cd9ae(_0x499e7a = null) {
  var _0xe2ef50 = document["createElement"]("a");
  (_0xe2ef50["setAttribute"]("id", "googleLink"),
    _0xe2ef50["setAttribute"]("class", "a-link-text"),
    _0xe2ef50["classList"]["add"]("icon"),
    _0xe2ef50["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20image",
    ));
  var _0x2a5436 = document["createElement"]("img");
  return (
    _0x2a5436["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-icon.png"),
    ),
    _0x2a5436["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xe2ef50["appendChild"](_0x2a5436),
    _0xe2ef50["addEventListener"]("click", async function (_0x70169c) {
      (_0x70169c["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x499e7a) {
        var _0x218a89 = _0x4d7269(_0x70169c);
        if (!_0x218a89) return;
        var _0x507453 = extractItemData(_0x218a89);
        _0x499e7a = _0x507453["image"];
      }
      var { domain: _0xa1dce6 } =
        await chrome["storage"]["local"]["get"]("domain");
      (_0x976341(_0xa1dce6),
        encodeURIComponent(_0x499e7a),
        chrome["runtime"]["sendMessage"]({
          type: "search_image_on_google",
          imageUrl: _0x499e7a,
        }));
    }),
    _0xe2ef50
  );
}
function _0x27572e(_0x5946b9 = null) {
  var _0x2bc54d = document["createElement"]("a");
  (_0x2bc54d["setAttribute"]("id", "googleLink"),
    _0x2bc54d["setAttribute"]("class", "a-link-text"),
    _0x2bc54d["classList"]["add"]("icon"),
    _0x2bc54d["setAttribute"](
      "title",
      "Search\x20Google\x20for\x20this\x20description",
    ));
  var _0x2791b1 = document["createElement"]("img");
  return (
    _0x2791b1["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/google-search-icon.png"),
    ),
    _0x2791b1["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x2bc54d["appendChild"](_0x2791b1),
    _0x2bc54d["addEventListener"]("click", async function (_0x4db918) {
      (_0x4db918["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x5946b9) {
        var _0x445170 = _0x4d7269(_0x4db918);
        if (!_0x445170) return;
        var _0x5598e4 = extractItemData(_0x445170);
        _0x5946b9 = _0x5598e4["itemNumber"];
      }
      chrome["runtime"]["sendMessage"]({
        type: "search_ebay_item_description_on_google",
        itemNumber: _0x5946b9,
      });
    }),
    _0x2bc54d
  );
}
function _0x22b73f(_0x410977) {
  var _0x1ef112 = document["createElement"]("a");
  (_0x1ef112["setAttribute"]("id", "lookUpSkuLink"),
    _0x1ef112["setAttribute"]("class", "a-link-text"),
    _0x1ef112["classList"]["add"]("icon"),
    _0x1ef112["setAttribute"]("title", "Look\x20up\x20this\x20SKU"));
  var _0x419a02 = document["createElement"]("img");
  return (
    _0x419a02["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/search.png"),
    ),
    _0x419a02["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x1ef112["appendChild"](_0x419a02),
    _0x1ef112["addEventListener"]("click", async function (_0x576e42) {
      (_0x576e42["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      var { domain: _0x5cc7f9 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x4d760d =
          "https://www.amazon." +
          _0x5cc7f9 +
          "/dp/" +
          _0x410977 +
          "/?th=1&psc=1";
      chrome["runtime"]["sendMessage"]({
        type: "openNewTab",
        url: _0x4d760d,
        options: { active: !0x0 },
      });
    }),
    _0x1ef112
  );
}
function _0x5ebd86(_0x57526f = null) {
  var _0x5de5db = document["createElement"]("a");
  (_0x5de5db["setAttribute"]("id", "productHunterLink"),
    _0x5de5db["setAttribute"]("class", "a-link-text"),
    _0x5de5db["classList"]["add"]("icon"),
    _0x5de5db["setAttribute"](
      "title",
      "Search\x20Product\x20Hunter\x20for\x20this\x20item",
    ));
  var _0x1ff983 = document["createElement"]("img");
  return (
    _0x1ff983["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/add-product.png"),
    ),
    _0x1ff983["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x5de5db["appendChild"](_0x1ff983),
    _0x5de5db["addEventListener"]("click", async function (_0x476fe0) {
      (_0x476fe0["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x57526f) {
        var _0x196176 = _0x4d7269(_0x476fe0);
        if (!_0x196176) return;
        var _0x46a2e2 = extractItemData(_0x196176);
        _0x57526f = _0x46a2e2["title"];
      }
      (console["log"]("productHunterLink\x20clicked", _0x57526f),
        chrome["runtime"]["sendMessage"]({
          type: "search_product_hunter",
          searchQuery: _0x57526f,
        }));
    }),
    _0x5de5db
  );
}
function _0x976341(_0x5a7a48) {
  return { com: "en-US", ca: "en-CA", "co.uk": "en-GB" }[_0x5a7a48] || "en-US";
}
function _0x17682f(_0x56f3d9 = null) {
  console["log"]("createSearchTerapeakButton", _0x56f3d9);
  var _0x4e217d = document["createElement"]("a");
  (_0x4e217d["setAttribute"]("class", "a-link-text"),
    _0x4e217d["classList"]["add"]("terapeakLink"),
    _0x4e217d["classList"]["add"]("icon"),
    _0x4e217d["setAttribute"](
      "title",
      "Search\x20Terapeak\x20for\x20this\x20item",
    ),
    _0x56f3d9 && _0x4e217d["setAttribute"]("item_title", _0x56f3d9));
  var _0x5f5546 = document["createElement"]("img");
  return (
    _0x5f5546["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/terapeak.png"),
    ),
    _0x5f5546["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4e217d["appendChild"](_0x5f5546),
    _0x4e217d["addEventListener"]("click", async function (_0x2f3959) {
      (_0x2f3959["preventDefault"](),
        this["getAttribute"]("item_title") &&
          (_0x462c8d = this["getAttribute"]("item_title")),
        console["log"]("terapeakLink\x20clicked", _0x462c8d),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (!_0x462c8d) {
        var _0x186db7 = _0x4d7269(_0x2f3959);
        if (!_0x186db7) return;
        _0x462c8d = extractItemData(_0x186db7)["title"];
      }
      console["log"]("title", _0x462c8d);
      var { convertToKeywords: _0x584c1a } =
        await chrome["storage"]["local"]["get"]("convertToKeywords");
      if (_0x584c1a) var _0x462c8d = await _0x2a90e4(_0x462c8d);
      var { domain: _0x529884 } =
          await chrome["storage"]["local"]["get"]("domain"),
        _0x51ca1d = _0x5a9dfe(_0x462c8d, _0x529884);
      chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x51ca1d });
    }),
    _0x4e217d
  );
}
async function _0x2a90e4(_0xa7b18e) {
  var _0x2a27ee = await fetch(
    chrome["runtime"]["getURL"]("prompts_json/3_word_descriptor.json"),
  )["then"]((_0x397c0b) => _0x397c0b["json"]());
  ((_0x2a27ee["user_input"] = _0xa7b18e),
    console["log"]("jsonPrompt", _0x2a27ee));
  var _0x15d319 = await new Promise((_0xcddcf, _0x29fbdf) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "fetchData",
        url: "https://openai-function-call-djybcnnsgq-uc.a.run.app",
        data: _0x2a27ee,
      },
      function (_0x12728e) {
        _0xcddcf(_0x12728e["data"]);
      },
    );
  });
  return (
    console["log"]("data", _0x15d319),
    (_0x15d319 = JSON["parse"](_0x15d319))["output"]
  );
}
function _0x5a9dfe(
  _0x40764f,
  _0x3f8ef0 = "ca",
  _0x33f6a7 = 0x1e,
  _0xe92491 = 0x0,
  _0x308271 = 0x0,
  _0x54dfe4 = 0x32,
  _0x48ef9e = "-itemssold",
  _0x4208bd = "SOLD",
  _0x404908 = "EBAY-CA",
  _0x8de41a = "America/Toronto",
  _0x15761f = "BuyerLocation:::CA",
  _0x5606ff = 0x0,
) {
  _0x404908 = "";
  switch (_0x3f8ef0) {
    case "ca":
    default:
      _0x404908 = "EBAY-CA";
      break;
    case "com":
      _0x404908 = "EBAY-US";
      break;
    case "co.uk":
      _0x404908 = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x3f8ef0 +
    "/sh/research?" +
    [
      "keywords=" + _0x40764f,
      "dayRange=" + _0x33f6a7,
      "categoryId=" + _0xe92491,
      "offset=" + _0x308271,
      "limit=" + _0x54dfe4,
      "sorting=" + _0x48ef9e,
      "tabName=" + _0x4208bd,
      "marketplace=" + _0x404908,
      "tz=" + encodeURIComponent(_0x8de41a),
      "minPrice=" + _0x5606ff,
    ]["join"]("&")
  );
}
async function _0x5d2818(_0x4a3b27) {
  var { domain: _0x4cb4a4 } = await chrome["storage"]["local"]["get"]("domain"),
    _0x1eebc5 =
      "https://www.ebay." +
      _0x4cb4a4 +
      "/sch/i.html?_dkr=1&_fsrp=1&iconV2Request=true&_blrs=recall_filtering&_ssn=" +
      _0x4a3b27 +
      "&store_name=" +
      _0x4a3b27 +
      "&_ipg=240&_oac=1&LH_Sold=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x1eebc5 });
}
async function _0x1719c1(_0x57b3f1) {
  (chrome["runtime"]["sendMessage"]({
    type: "open_seller_page_from_item_number",
    itemNumber: _0x57b3f1,
  }),
    console["log"]("openItemPageThenSellerItemsPage", _0x57b3f1));
}
async function _0x3b2a8c(_0x5df565) {
  var { response: _0x4d3f82 } = await chrome["runtime"]["sendMessage"]({
    type: "open_item_page_then_get_seller",
    itemNumber: _0x5df565,
  });
  return (console["log"]("openItemPageThenGetSeller", _0x4d3f82), _0x4d3f82);
}
function _0x39ec8d(_0x2f03b0 = null) {
  console["log"]("createOpenSellerItemsButton", _0x2f03b0);
  var _0xb030ca = document["createElement"]("a");
  (_0xb030ca["setAttribute"]("id", "sellerItemsLink"),
    _0xb030ca["setAttribute"]("class", "a-link-text"),
    _0xb030ca["classList"]["add"]("icon"),
    _0xb030ca["setAttribute"](
      "title",
      "Opens\x20the\x20eBay\x20seller\x27s\x20sold\x20items",
    ));
  var _0x4ec4db = document["createElement"]("img");
  return (
    _0x4ec4db["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/people.jpg"),
    ),
    _0x4ec4db["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0xb030ca["appendChild"](_0x4ec4db),
    _0xb030ca["addEventListener"]("click", async function (_0x74fe43) {
      (_0x74fe43["preventDefault"](),
        console["log"]("sellerItemsLink\x20clicked\x201", _0x2f03b0),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("sellerItemsLink\x20clicked\x202", _0x2f03b0));
      var _0x5ed654;
      if (!_0x2f03b0) {
        console["log"]("username\x20not\x20found");
        var _0x3db724 = _0x4d7269(_0x74fe43);
        console["log"](
          "item\x20from\x20createOpenSellerItemsButton",
          _0x3db724,
        );
        if (!_0x3db724) return;
        var _0x329418 = extractItemData(_0x3db724);
        (console["log"](
          "itemData\x20from\x20createOpenSellerItemsButton",
          _0x329418,
        ),
          (_0x2f03b0 = _0x329418["username"]),
          (_0x5ed654 = _0x329418["itemNumber"]));
      }
      if (
        _0x2f03b0["includes"]("\x20") ||
        _0x2f03b0 !== _0x2f03b0["toLowerCase"]()
      ) {
        console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0x2f03b0,
        );
        if (!_0x5ed654) {
          if (!(_0x3db724 = _0x4d7269(_0x74fe43))) return;
          _0x5ed654 = (_0x329418 = extractItemData(_0x3db724))["itemNumber"];
        }
        _0x1719c1(_0x5ed654);
      } else
        ((_0x2f03b0 = _0x2f03b0["toLowerCase"]()),
          console["log"]("username", _0x2f03b0),
          _0x5d2818(_0x2f03b0));
    }),
    _0xb030ca
  );
}
function _0x1c41a9(_0x46b011) {
  for (
    ;
    _0x46b011 &&
    !_0x46b011["classList"]["contains"]("s-item") &&
    !_0x46b011["classList"]["contains"]("su-card-container");

  )
    _0x46b011 = _0x46b011["parentElement"];
  return _0x46b011;
}
function _0x2c1afd(_0x292154 = null) {
  var _0x4fa54d = document["createElement"]("a");
  (_0x4fa54d["setAttribute"]("id", "purchaseHistoryLink"),
    _0x4fa54d["setAttribute"]("class", "a-link-text"),
    _0x4fa54d["classList"]["add"]("icon"),
    _0x4fa54d["setAttribute"]("title", "Check\x20How\x20Many\x20Sold"));
  var _0x59eb50 = document["createElement"]("img");
  return (
    _0x59eb50["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/graph.png"),
    ),
    _0x59eb50["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x4fa54d["appendChild"](_0x59eb50),
    _0x4fa54d["addEventListener"]("click", async function (_0x51cbbe) {
      (console["log"]("createCheckPurchaseHistoryButton", _0x292154),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        _0x51cbbe["preventDefault"]());
      var _0x10a8d9 = _0x4d7269(_0x51cbbe);
      console["log"](
        "item\x20from\x20createCheckPurchaseHistoryButton",
        _0x10a8d9,
      );
      if (_0x10a8d9) {
        var { selectedFilter: _0x3459dd } =
          await chrome["storage"]["local"]["get"]("selectedFilter");
        !_0x3459dd &&
          ((_0x3459dd = "90"),
          await chrome["storage"]["local"]["set"]({
            selectedFilter: _0x3459dd,
          }));
        var _0x260786 = _0x3459dd,
          _0x43ce85 = await checkPurchaseHistoryAndAddToItem(
            _0x10a8d9,
            _0x260786,
            !0x1,
            !0x0,
          );
        console["log"]("totalSold", _0x43ce85);
      } else
        try {
          var _0x52583b = await chrome["runtime"]["sendMessage"]({
            type: "checkPurchaseHistory",
            itemNumber: _0x292154,
            lastXDays: 0x1e,
            closeTabAfterSearch: !0x1,
          });
          (console["log"]("response", _0x52583b),
            (_0x43ce85 = _0x52583b["totalSold"]));
        } catch (_0x58cf14) {
          (console["log"]("error", _0x58cf14), (_0x43ce85 = -0x3e7));
        }
    }),
    _0x4fa54d
  );
}
function _0x4d7269(_0x36bdb4) {
  var _0x522913 = _0x36bdb4["target"];
  return (
    (_0x522913 = _0x1c41a9(_0x522913)),
    console["log"]("found\x20s-item", _0x522913),
    _0x522913
  );
}
function _0x53d1b7(_0x501337 = null, _0x296ff1 = null, _0x385db7 = null) {
  var _0x3ff538 = document["createElement"]("a");
  (_0x3ff538["setAttribute"]("id", "copyDataLink"),
    _0x3ff538["setAttribute"]("class", "a-link-text"),
    _0x3ff538["classList"]["add"]("icon"),
    _0x3ff538["setAttribute"](
      "title",
      "Snipe\x20the\x20Title\x20And\x20Price,\x20Saves\x20this\x20to\x20Clipboard",
    ));
  var _0x28cd51 = document["createElement"]("img");
  return (
    _0x28cd51["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/copy.png"),
    ),
    _0x28cd51["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x3ff538["appendChild"](_0x28cd51),
    _0x3ff538["addEventListener"]("click", async function (_0x41c946) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x501337,
        _0x296ff1,
        _0x385db7,
      ),
        _0x41c946["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320));
      if (_0x501337 && _0x296ff1 && _0x385db7)
        (console["log"](
          "title,\x20price,\x20itemNumber",
          _0x501337,
          _0x296ff1,
          _0x385db7,
        ),
          isNaN(_0x296ff1) &&
            (console["log"]("price\x20is\x20not\x20a\x20number", _0x296ff1),
            (_0x296ff1 = _0x296ff1["replace"](/[^0-9.]/g, ""))),
          _0x39ed09(
            JSON["stringify"]({
              title: _0x501337,
              price: _0x296ff1,
              itemNumber: _0x385db7,
            }),
          ));
      else {
        if (!_0x501337 || !_0x296ff1 || !_0x385db7) {
          var _0x27baa3 = _0x4d7269(_0x41c946);
          if (!_0x27baa3) return;
        }
        var _0x4761af = extractItemData(_0x27baa3);
        (console["log"]("itemData", _0x4761af),
          _0x39ed09(JSON["stringify"](_0x4761af)));
      }
    }),
    _0x3ff538
  );
}
function _0x39ed09(_0x2fd048) {
  var _0x420e8b = document["createElement"]("textarea");
  (document["body"]["appendChild"](_0x420e8b),
    (_0x420e8b["value"] = _0x2fd048),
    _0x420e8b["select"](),
    document["execCommand"]("copy"),
    document["body"]["removeChild"](_0x420e8b));
}
async function _0x19ba1e(_0x501af6 = null) {
  console["log"]("price", _0x501af6);
  if (_0x501af6) {
    try {
      _0x501af6 = _0x501af6["replace"](/[^0-9.]/g, "");
    } catch (_0x356c83) {}
    _0x501af6 = parseFloat(_0x501af6);
  }
  var _0x1390f3 = await _0x4f9ec4(_0x501af6),
    _0x49eae0 = document["createElement"]("div");
  return (
    _0x49eae0["setAttribute"]("id", "breakEvenPrice"),
    _0x49eae0["setAttribute"]("class", "break-even-price"),
    (_0x49eae0["textContent"] =
      "Break-even\x20price:\x20$" + _0x1390f3["toFixed"](0x2)),
    _0x49eae0
  );
}
async function _0x27455c(_0x1cea20) {
  var _0x126948 = !0x1,
    _0x26ebe0 = !0x1,
    { includeCurrencyConversion: _0x26ebe0 } = await chrome["storage"]["local"][
      "get"
    ]("includeCurrencyConversion"),
    { includeInternationalFee: _0x126948 } = await chrome["storage"]["local"][
      "get"
    ]("includeInternationalFee");
  let _0x999c02 =
    0.1325 * _0x1cea20 +
    0.021 * _0x1cea20 +
    _0x1cea20 * (_0x126948 ? 0.004 : 0x0) +
    0.4;
  return (_0x26ebe0 && (_0x999c02 += 0.035 * _0x1cea20), _0x1cea20 - _0x999c02);
}
async function _0x4f9ec4(_0x6949ba) {
  var { isInternational: _0x27ffb4 } =
      await chrome["storage"]["local"]["get"]("isInternational"),
    { doesUserHaveEbaySubscription: _0x5ac803 } = await chrome["storage"][
      "local"
    ]["get"]("doesUserHaveEbaySubscription");
  (_0x27ffb4 || (_0x27ffb4 = !0x1), _0x5ac803 || (_0x5ac803 = !0x0));
  var _0x66058 = 13.25;
  _0x5ac803 && (_0x66058 = 12.35);
  var _0x2f8cc2 = _0x6949ba + 0.0725 * _0x6949ba,
    _0x51379e =
      _0x2f8cc2 * (_0x66058 / 0x64) +
      0.4 +
      (_0x27ffb4 ? 0.004 * _0x2f8cc2 : 0x0),
    _0x2ff5c7 =
      _0x6949ba -
      (_0x51379e + (_0x27ffb4 ? 0.05 * _0x51379e : 0x0)) -
      (_0x27ffb4 ? 0.035 * _0x2f8cc2 : 0x0),
    { isUserTaxExempt: _0x560152 } =
      await chrome["storage"]["local"]["get"]("isUserTaxExempt");
  return (
    _0x560152 || (_0x560152 = !0x1),
    _0x560152 || (_0x2ff5c7 /= 1.0725),
    _0x27ffb4 && (_0x2ff5c7 -= (3.5 * _0x2ff5c7) / 0x64),
    _0x2ff5c7
  );
}
function _0x320b80(_0xe1edfc = null) {
  console["log"]("createButtonToSaveSeller", _0xe1edfc);
  var _0x520c88 = document["createElement"]("a");
  (_0x520c88["setAttribute"]("id", "saveSellerLink"),
    _0x520c88["setAttribute"](
      "class",
      "a-link-text\x20save-seller\x20icon\x20saveSellerLink",
    ),
    _0x520c88["setAttribute"]("title", "Save\x20eBay\x20Seller"));
  var _0x4b9865 = document["createElement"]("img");
  return (
    _0x4b9865["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
    ),
    _0x4b9865["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x520c88["appendChild"](_0x4b9865),
    _0x520c88["addEventListener"]("click", async function (_0x202876) {
      (_0x202876["preventDefault"](),
        this["classList"]["add"]("clicked"),
        setTimeout(() => {
          this["classList"]["remove"]("clicked");
        }, 0x320),
        console["log"]("saveSellerLink\x20clicked\x201", _0xe1edfc));
      var _0x1fb17a;
      if (!_0xe1edfc) {
        var _0x310cad = _0x4d7269(_0x202876);
        if (!_0x310cad) return;
        var _0xf1a2b = extractItemData(_0x310cad);
        ((_0xe1edfc = _0xf1a2b["username"]),
          (_0x1fb17a = _0xf1a2b["itemNumber"]));
      }
      if (
        _0xe1edfc["includes"]("\x20") ||
        _0xe1edfc !== _0xe1edfc["toLowerCase"]()
      )
        (console["log"](
          "username\x20has\x20spaces\x20or\x20any\x20capital\x20letters,\x20therefor\x20its\x20a\x20store\x20name",
          _0xe1edfc,
        ),
          (_0xe1edfc = await _0x3b2a8c(_0x1fb17a)),
          console["log"](
            "username\x20from\x20openItemPageThenGetSeller",
            _0xe1edfc,
          ));
      else _0xe1edfc = _0xe1edfc["toLowerCase"]();
      _0x520c88["setAttribute"]("data-seller-name", _0xe1edfc);
      var { ebayCompetitors: _0x317ae0 } =
          await chrome["storage"]["local"]["get"]("ebayCompetitors"),
        _0x29b65a = (_0x317ae0 = _0x317ae0 || [])["indexOf"](_0xe1edfc);
      console["log"]("ebayCompetitors", _0x317ae0);
      if (this["classList"]["contains"]("save-seller"))
        (console["log"]("save-seller\x20clicked"),
          -0x1 === _0x29b65a
            ? (console["log"]("save-seller\x20clicked\x20username", _0xe1edfc),
              _0x317ae0["push"](_0xe1edfc),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x4b9865["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              ))
            : (console["log"](
                "save-seller\x20clicked\x20username\x20already\x20exists",
                _0xe1edfc,
              ),
              this["classList"]["replace"]("save-seller", "remove-seller"),
              _0x4b9865["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/save.png"),
              )));
      else {
        if (this["classList"]["contains"]("remove-seller")) {
          if (-0x1 !== _0x29b65a)
            (console["log"]("remove-seller\x20clicked\x20username", _0xe1edfc),
              _0x317ae0["splice"](_0x29b65a, 0x1),
              this["classList"]["replace"]("remove-seller", "save-seller"),
              _0x4b9865["setAttribute"](
                "src",
                chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
              ));
          else
            console["log"](
              "remove-seller\x20clicked\x20username\x20not\x20found",
              _0xe1edfc,
            );
        }
      }
      await chrome["storage"]["local"]["set"]({ ebayCompetitors: _0x317ae0 });
    }),
    _0x520c88
  );
}
async function _0xfe2892(_0x28e85e, _0x31c1cd) {
  var { ebayCompetitors: _0xf9f80 } =
      await chrome["storage"]["local"]["get"]("ebayCompetitors"),
    _0x479dcb = (_0xf9f80 = _0xf9f80 || [])["indexOf"](_0x31c1cd),
    _0x4f8c45 = _0x28e85e["querySelector"]("img");
  -0x1 !== _0x479dcb
    ? (_0x28e85e["classList"]["replace"]("save-seller", "remove-seller"),
      _0x4f8c45["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/save.png"),
      ))
    : (_0x28e85e["classList"]["replace"]("remove-seller", "save-seller"),
      _0x4f8c45["setAttribute"](
        "src",
        chrome["runtime"]["getURL"]("icons/floppy-disk.png"),
      ));
}
function _0x2a2efa(
  _0x54cd1b = null,
  _0x12066c = null,
  _0x254ee0 = null,
  _0x3917ba = !0x0,
  _0x3b9db0 = null,
  _0x37b15a = null,
) {
  (console["log"]("createEcommerceSearchButtonsPanel2"),
    console["log"]("title", _0x54cd1b));
  var _0x351cc1 = _0x320b80(_0x12066c),
    _0x16c537 = _0x17682f(_0x54cd1b),
    _0x3f3a84 = _0x2c1afd(_0x3b9db0),
    _0x433589 = _0x5351d0(_0x54cd1b),
    _0x496706 = _0x231ef2(_0x54cd1b, _0x37b15a, _0x3b9db0, _0x254ee0),
    _0x41d322 = _0x5351d0(
      _0x54cd1b,
      { soldItems: !0x0, endedRecently: !0x0 },
      "icons/sold.png",
    ),
    _0x427f57 = _0x2cd9ae(_0x254ee0),
    _0x17dbb1 = _0x27572e(_0x3b9db0),
    _0x5e0ece = _0x39ec8d(_0x12066c),
    _0x150cf3 = document["createElement"]("div");
  _0x150cf3["setAttribute"]("id", "search-div");
  var _0x6dcf98 = document["createElement"]("label");
  ((_0x6dcf98["innerHTML"] = "<b>\x20Search\x20on:\x20\x20</b>"),
    _0x150cf3["appendChild"](_0x6dcf98),
    _0x150cf3["appendChild"](_0x496706),
    _0x150cf3["appendChild"](_0x433589),
    _0x150cf3["appendChild"](_0x16c537),
    _0x150cf3["appendChild"](_0x427f57),
    _0x150cf3["appendChild"](_0x17dbb1),
    _0x150cf3["appendChild"](_0x41d322),
    console["log"]("CopyDataButton", _0x54cd1b, _0x37b15a, _0x3b9db0));
  var _0x246bf5 = _0x53d1b7(_0x54cd1b, _0x37b15a, _0x3b9db0),
    _0x16631f = document["createElement"]("div");
  _0x16631f["setAttribute"]("id", "item-buttons-div");
  var _0x483984 = document["createElement"]("div");
  (_0x483984["setAttribute"]("id", "main-buttons-div"),
    _0x483984["appendChild"](_0x5e0ece),
    _0x483984["appendChild"](_0x3f3a84),
    _0x483984["appendChild"](_0x246bf5),
    _0x483984["appendChild"](_0x351cc1),
    _0x16631f["appendChild"](_0x483984));
  if (_0x3917ba) {
    var _0x2bab56 = createButtonListToEbay();
    _0x16631f["appendChild"](_0x2bab56);
  }
  return (_0x16631f["appendChild"](_0x150cf3), _0x16631f);
}
var _0x5ab550 = [
  {
    content: "Search\x20with\x20Title",
    selected: !0x1,
    id: "search-type",
    value: "title",
    events: {
      click: (_0xefa050) => {
        (console["log"](
          _0xefa050,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 }),
          updateContextMenu(_0x5ab550, "search-type", "title"));
      },
    },
  },
  {
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    id: "search-type",
    value: "keywords",
    events: {
      click: (_0x2b9246) => {
        (console["log"](
          _0x2b9246,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ convertToKeywords: !0x0 }),
          updateContextMenu(_0x5ab550, "search-type", "keywords"));
      },
    },
  },
];
async function _0xad5481() {
  var { convertToKeywords: _0x2bafe8 } =
    await chrome["storage"]["local"]["get"]("convertToKeywords");
  (!_0x2bafe8 &&
    ((_0x2bafe8 = !0x1),
    await chrome["storage"]["local"]["set"]({ convertToKeywords: !0x1 })),
    updateContextMenu(
      _0x5ab550,
      "search-type",
      _0x2bafe8 ? "keywords" : "title",
    ),
    new ContextMenu({ target: ".terapeakLink", menuItems: _0x5ab550 })[
      "init"
    ]());
}
var _0x1befa0 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x327f63) => {
        (console["log"](_0x327f63, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x1befa0, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x37d9d4) => {
        (console["log"](_0x37d9d4, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x1befa0, "sort-type", "lowest-price"));
      },
    },
  },
  {
    divider: "top",
    id: "search-type",
    value: "title",
    content: "Search\x20with\x20Title",
    selected: !0x1,
    events: {
      click: (_0x17eac8) => {
        (console["log"](
          _0x17eac8,
          "Search\x20with\x20Title\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "title" }),
          updateContextMenu(_0x1befa0, "search-type", "title"));
      },
    },
  },
  {
    id: "search-type",
    value: "keywords",
    content: "Search\x20with\x20Keywords",
    selected: !0x1,
    events: {
      click: (_0x272fdb) => {
        (console["log"](
          _0x272fdb,
          "Search\x20with\x20Keywords\x20Button\x20Click",
        ),
          chrome["storage"]["local"]["set"]({ amazonSearchType: "keywords" }),
          updateContextMenu(_0x1befa0, "search-type", "keywords"));
      },
    },
  },
];
async function _0x93e842() {
  var { amazonSortType: _0x295b59 } =
      await chrome["storage"]["local"]["get"]("amazonSortType"),
    { amazonSearchType: _0x2eec94 } =
      await chrome["storage"]["local"]["get"]("amazonSearchType");
  (!_0x2eec94 &&
    ((_0x2eec94 = "title"),
    await chrome["storage"]["local"]["set"]({ amazonSearchType: "title" })),
    !_0x295b59 &&
      ((_0x295b59 = "reviews"),
      await chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" })),
    updateContextMenu(_0x1befa0, "sort-type", _0x295b59),
    updateContextMenu(_0x1befa0, "search-type", _0x2eec94),
    new ContextMenu({ target: ".amazonSearchLink", menuItems: _0x1befa0 })[
      "init"
    ]());
}
_0x1befa0 = [
  {
    id: "sort-type",
    value: "reviews",
    content: "Sort\x20by\x20Highest\x20Reviews",
    selected: !0x1,
    events: {
      click: (_0x11bd4f) => {
        (console["log"](_0x11bd4f, "Sort\x20by\x20Reviews\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "reviews" }),
          updateContextMenu(_0x1befa0, "sort-type", "reviews"));
      },
    },
  },
  {
    id: "sort-type",
    value: "lowest-price",
    content: "Sort\x20By\x20Lowest\x20Price",
    selected: !0x1,
    events: {
      click: (_0x34fef4) => {
        (console["log"](_0x34fef4, "Sort\x20by\x20Price\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ amazonSortType: "lowest-price" }),
          updateContextMenu(_0x1befa0, "sort-type", "lowest-price"));
      },
    },
  },
];
var _0x1b4e0a = [
  {
    id: "filter-type",
    value: "1",
    content: "1\x20Day",
    selected: !0x1,
    events: {
      click: (_0x4fa4b3) => {
        (console["log"](_0x4fa4b3, "1\x20Day\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "1" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "1"));
      },
    },
  },
  {
    id: "filter-type",
    value: "3",
    content: "3\x20Days",
    selected: !0x1,
    events: {
      click: (_0x57b4d6) => {
        (console["log"](_0x57b4d6, "3\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "3" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "3"));
      },
    },
  },
  {
    id: "filter-type",
    value: "7",
    content: "7\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3f58d2) => {
        (console["log"](_0x3f58d2, "7\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "7" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "7"));
      },
    },
  },
  {
    id: "filter-type",
    value: "14",
    content: "14\x20Days",
    selected: !0x1,
    events: {
      click: (_0x2d5108) => {
        (console["log"](_0x2d5108, "14\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "14" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "14"));
      },
    },
  },
  {
    id: "filter-type",
    value: "21",
    content: "21\x20Days",
    selected: !0x1,
    events: {
      click: (_0x34205e) => {
        (console["log"](_0x34205e, "21\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "21" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "21"));
      },
    },
  },
  {
    id: "filter-type",
    value: "30",
    content: "30\x20Days",
    selected: !0x1,
    events: {
      click: (_0x541af6) => {
        (console["log"](_0x541af6, "30\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "30" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "30"));
      },
    },
  },
  {
    id: "filter-type",
    value: "60",
    content: "60\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3fd01c) => {
        (console["log"](_0x3fd01c, "60\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "60" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "60"));
      },
    },
  },
  {
    id: "filter-type",
    value: "90",
    content: "90\x20Days",
    selected: !0x1,
    events: {
      click: (_0x3c6cf0) => {
        (console["log"](_0x3c6cf0, "90\x20Days\x20Button\x20Click"),
          chrome["storage"]["local"]["set"]({ selectedFilter: "90" }),
          updateContextMenu(_0x1b4e0a, "filter-type", "90"));
      },
    },
  },
];
async function _0x345273() {
  var { selectedFilter: _0x201fb0 } =
    await chrome["storage"]["local"]["get"]("selectedFilter");
  (!_0x201fb0 &&
    ((_0x201fb0 = "90"),
    await chrome["storage"]["local"]["set"]({ selectedFilter: "90" })),
    updateContextMenu(_0x1b4e0a, "filter-type", _0x201fb0),
    new ContextMenu({ target: ".filter-date-context", menuItems: _0x1b4e0a })[
      "init"
    ]());
}
function _0x48864f() {
  return ".s-item__caption-section,\x20.s-item__caption--signal.POSITIVE";
}
async function _0x381cf9() {
  const _0x3b4f73 = document["querySelector"](
    ".s-customize-v2\x20.lightbox-dialog__main",
  );
  let _0x438da2 = 0x0;
  const _0x40bf41 = () =>
    new Promise((_0x4d24fb, _0xfebc8a) => {
      const _0x5b5524 = new MutationObserver((_0x434c81, _0x352b4b) => {
        const _0x5e08e2 = document["querySelector"](
          ".s-customize-form__details",
        );
        _0x5e08e2 &&
          (console["log"]("Details\x20form\x20found!"),
          _0x352b4b["disconnect"](),
          _0x4d24fb(_0x5e08e2));
      });
      (_0x5b5524["observe"](_0x3b4f73, {
        childList: !0x0,
        subtree: !0x0,
        attributes: !0x1,
      }),
        setTimeout(() => {
          _0x5b5524["disconnect"]();
          if (_0x438da2 < 0x3)
            (console["log"](
              "Details\x20form\x20not\x20found,\x20retrying...\x20(" +
                (_0x438da2 + 0x1) +
                "/3)",
            ),
              _0x438da2++,
              document["querySelector"](
                ".srp-view-options\x20li:nth-child(2)\x20button",
              )?.["click"](),
              setTimeout(() => _0x4d24fb(_0x40bf41()), 0x1388));
          else
            _0xfebc8a(
              new Error(
                "Details\x20form\x20did\x20not\x20appear\x20after\x20maximum\x20retries.",
              ),
            );
        }, 0x4e20));
    });
  var _0x4b5a82 = document["querySelector"](
    ".srp-view-options\x20li:nth-child(2)\x20button",
  );
  if (_0x4b5a82) {
    (_0x4b5a82["click"](),
      console["log"](
        "Clicked\x20the\x20customize\x20button,\x20waiting\x20for\x20form...",
      ));
    try {
      (await _0x40bf41(),
        console["log"](
          "You\x20can\x20now\x20perform\x20operations\x20on\x20the\x20form.",
        ));
    } catch (_0x396f56) {
      console["error"](_0x396f56["message"]);
    }
  } else console["error"]("Customize\x20button\x20not\x20found.");
}
function _0x2881de(_0x23608d = null, _0x5ced00 = null, _0x387761 = null) {
  var _0x151393 = document["createElement"]("a");
  (_0x151393["setAttribute"]("id", "copyDataLink"),
    _0x151393["setAttribute"]("class", "a-link-text"),
    _0x151393["classList"]["add"]("icon"),
    _0x151393["setAttribute"]("title", "Get\x20similiar\x20product\x20links"));
  var _0x489d85 = document["createElement"]("img");
  return (
    _0x489d85["setAttribute"](
      "src",
      chrome["runtime"]["getURL"]("icons/ecomsniper.png"),
    ),
    _0x489d85["setAttribute"](
      "style",
      "width:\x2020px;\x20height:\x2020px;\x20vertical-align:\x20middle;\x20margin-right:\x205px;",
    ),
    _0x151393["appendChild"](_0x489d85),
    _0x151393["addEventListener"]("click", async function (_0x1e0f12) {
      (console["log"](
        "copyDataLink\x20clicked",
        _0x23608d,
        _0x5ced00,
        _0x387761,
      ),
        _0x1e0f12["preventDefault"](),
        this["classList"]["add"]("spinner"));
      if (_0x23608d && _0x5ced00 && _0x387761) {
        console["log"](
          "title,\x20price,\x20itemNumber",
          _0x23608d,
          _0x5ced00,
          _0x387761,
        );
        isNaN(_0x5ced00) &&
          (console["log"]("price\x20is\x20not\x20a\x20number", _0x5ced00),
          (_0x5ced00 = _0x5ced00["replace"](/[^0-9.]/g, "")));
        var _0x192c45 = JSON["stringify"]({
          title: _0x23608d,
          price: _0x5ced00,
          itemNumber: _0x387761,
        });
        (_0xd61f03(
          (_0x5383c7 = await findSimiliarProducts(_0x192c45))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x5383c7),
          this["classList"]["remove"]("spinner"));
      } else {
        if (!_0x23608d || !_0x5ced00 || !_0x387761) {
          var _0x1767be = _0x4d7269(_0x1e0f12);
          if (!_0x1767be) return;
        }
        var _0x555fc9 = extractItemData(_0x1767be);
        (console["log"]("itemData", _0x555fc9),
          (_0x192c45 = JSON["stringify"](_0x555fc9)));
        var _0x5383c7;
        (_0xd61f03(
          (_0x5383c7 = await findSimiliarProducts(_0x192c45))["join"]("\x0a"),
        ),
          console["log"]("productLinks", _0x5383c7),
          this["classList"]["remove"]("spinner"));
      }
    }),
    _0x151393
  );
}
async function findSimiliarProducts(_0x9d3358) {
  console["log"]("findSimiliarProducts", _0x9d3358);
  var _0x4895c2 = await chrome["runtime"]["sendMessage"]({
    type: "find_similiar_products",
    jsonString: _0x9d3358,
  });
  return (console["log"]("response", _0x4895c2), _0x4895c2["productLinks"]);
}
function _0xd61f03(_0x5e319d) {
  const _0x44f987 = document["getElementById"]("productLinksModalOverlay");
  _0x44f987 && _0x44f987["remove"]();
  const _0x165253 = document["createElement"]("div");
  ((_0x165253["id"] = "productLinksModalOverlay"),
    _0x165253["classList"]["add"]("product-links-modal-overlay"));
  const _0x51cd35 = document["createElement"]("div");
  _0x51cd35["classList"]["add"]("product-links-modal");
  const _0x16a30c = document["createElement"]("div");
  _0x16a30c["classList"]["add"]("modal-button-container");
  const _0x3c40aa = document["createElement"]("button");
  (_0x3c40aa["classList"]["add"]("close-button"),
    (_0x3c40aa["innerText"] = "Close"),
    _0x3c40aa["addEventListener"]("click", () => {
      _0x165253["remove"]();
    }));
  const _0x49eaa0 = document["createElement"]("button");
  (_0x49eaa0["classList"]["add"]("copy-button"),
    (_0x49eaa0["innerText"] = "Copy"),
    _0x49eaa0["addEventListener"]("click", async () => {
      try {
        (await navigator["clipboard"]["writeText"](_0x5e319d),
          alert("Copied\x20to\x20clipboard!"));
      } catch (_0x2eb908) {
        console["error"]("Failed\x20to\x20copy:", _0x2eb908);
      }
    }));
  const _0x9acb77 = document["createElement"]("h2");
  _0x9acb77["innerText"] = "Similar\x20Product\x20Links";
  const _0xd78085 = document["createElement"]("textarea");
  ((_0xd78085["value"] = _0x5e319d),
    _0xd78085["setAttribute"]("readonly", !0x0),
    (_0xd78085["style"]["width"] = "100%"),
    (_0xd78085["style"]["height"] = "300px"),
    _0x16a30c["appendChild"](_0x49eaa0),
    _0x16a30c["appendChild"](_0x3c40aa),
    _0x51cd35["appendChild"](_0x16a30c),
    _0x51cd35["appendChild"](_0x9acb77),
    _0x51cd35["appendChild"](_0xd78085),
    _0x165253["appendChild"](_0x51cd35),
    document["body"]["appendChild"](_0x165253));
}
async function _0xbe91cb(_0x32b852) {
  var { domain: _0x493618 } = await chrome["storage"]["local"]["get"]("domain");
  try {
    const _0x20c84d = await fetch(
        "https://poshmark." + _0x493618 + "/edit-listing/" + _0x32b852,
        { credentials: "include" },
      ),
      _0x328ae7 = (await _0x20c84d["text"]())["match"](/"sku":\s*"([^"]+)"/);
    if (!_0x328ae7) {
      console["error"]("SKU\x20not\x20found\x20in\x20response");
      return;
    }
    return _0x328ae7[0x1];
  } catch (_0x3438a1) {
    console["error"]("Error\x20fetching\x20SKU:", _0x3438a1);
  }
}
async function _0x2a55ae(_0x4897ec, _0x11e173 = {}) {
  const {
      available: _0x21e876,
      price: _0x350b83,
      originalPrice: _0x336448,
      region: region = "us",
    } = _0x11e173,
    _0x26be94 = "ca" === region ? "poshmark.ca" : "poshmark.com",
    _0x4a7291 = "ca" === region ? "CAD" : "USD",
    _0x19dbac =
      "https://" +
      _0x26be94 +
      "/vm-rest/posts/" +
      _0x4897ec +
      "?pm_version=2025.37.1";
  var _0x484f52 = { post: {} };
  _0x11e173["hasOwnProperty"]("available") &&
    (_0x484f52["post"]["inventory"] = {
      status: _0x21e876 ? "available" : "not_for_sale",
    });
  "number" == typeof _0x350b83 &&
    ((_0x484f52["post"]["price_amount"] = {
      val: _0x350b83["toFixed"](0x2),
      currency_code: _0x4a7291,
    }),
    _0x11e173["hasOwnProperty"]("originalPrice") ||
      (_0x484f52["post"]["original_price_amount"] = {
        val: (1.5 * _0x350b83)["toFixed"](0x2),
        currency_code: _0x4a7291,
      }));
  ("number" == typeof _0x336448 &&
    (_0x484f52["post"]["original_price_amount"] = {
      val: _0x336448["toFixed"](0x2),
      currency_code: _0x4a7291,
    }),
    _0x11e173["hasOwnProperty"]("set_offers") &&
      (_0x484f52["post"]["offer_auto_actions_v2_enabled"] =
        !!_0x11e173["set_offers"]),
    _0x11e173["hasOwnProperty"]("min_offer") &&
      (_0x484f52["post"]["offer_auto_actions_min_price_amount"] = {
        val: _0x11e173["min_offer"],
        currency_code: _0x4a7291,
      }),
    console["log"](
      "Updating\x20listing\x20[" + _0x4897ec + "@" + _0x26be94 + "]\x20with:",
      _0x484f52,
    ));
  if (0x0 === Object["keys"](_0x484f52["post"])["length"])
    return (
      console["warn"](
        "[" +
          _0x4897ec +
          "]\x20No\x20update\x20options\x20specified—skipping\x20request.",
      ),
      Promise["resolve"]()
    );
  return (
    console["log"]("postData:", _0x484f52),
    fetch(_0x19dbac, {
      method: "POST",
      credentials: "include",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON["stringify"](_0x484f52),
    })
      ["then"]((_0x49035f) => {
        if (!_0x49035f["ok"]) throw new Error("HTTP\x20" + _0x49035f["status"]);
        return _0x49035f["json"]();
      })
      ["then"]((_0x2117e3) => {
        return (
          console["log"](
            "✅\x20[" + _0x4897ec + "@" + _0x26be94 + "]\x20updated:",
            _0x484f52["post"],
            _0x2117e3,
          ),
          _0x2117e3
        );
      })
      ["catch"]((_0x4fbfbb) => {
        console["error"](
          "❌\x20[" + _0x4897ec + "@" + _0x26be94 + "]\x20update\x20failed:",
          _0x4fbfbb,
        );
        throw _0x4fbfbb;
      })
  );
}
function fetchProductData(
  _0x5deabf,
  _0x2f8a2b = "https://www.amazon.com/dp/" + atob(_0x5deabf) + "?th=1&psc=1",
) {
  return (
    console["log"](
      "fetchProductData\x20called\x20with\x20cl:",
      _0x5deabf,
      "and\x20url:",
      _0x2f8a2b,
    ),
    new Promise((_0x4d3ec5, _0x25a4f6) => {
      chrome["runtime"]["sendMessage"](
        {
          type: "fetch_product_data",
          supplier: "amazon",
          customLabel: _0x5deabf,
          itemUrl: _0x2f8a2b,
        },
        (_0x209d88) => {
          if (chrome["runtime"]["lastError"])
            return _0x25a4f6(chrome["runtime"]["lastError"]);
          if (!_0x209d88 || _0x209d88["error"])
            return _0x25a4f6(
              new Error(_0x209d88?.["error"] || "Unknown\x20error"),
            );
          _0x4d3ec5(_0x209d88["productData"] || {});
        },
      );
    })
  );
}
async function _0xaa6705(_0x18819c, _0x1164ea = {}) {
  const {
    minPrice: _0x1c7445,
    currency: currency = "USD",
    region: region = "us",
    userId: _0x280dd0,
    pmVersion: pmVersion = "2025.37.1",
  } = _0x1164ea;
  if (!_0x280dd0)
    throw new Error("previewOfferEarnings\x20requires\x20opts.userId");
  if (null == _0x1c7445)
    throw new Error("previewOfferEarnings\x20requires\x20opts.minPrice");
  const _0xeafda3 =
    "https://" +
    ("ca" === region ? "poshmark.ca" : "poshmark.com") +
    "/vm-rest/users/" +
    _0x280dd0 +
    "/seller_earnings/post?" +
    new URLSearchParams({
      price_amount: JSON["stringify"]({
        val: String(_0x1c7445),
        currency_code: currency,
      }),
      object_id: _0x18819c,
      pm_version: pmVersion,
    })["toString"]();
  console["log"]("Fetching\x20earnings\x20preview\x20from:", _0xeafda3);
  const _0x128937 = await fetch(_0xeafda3, {
    method: "GET",
    credentials: "include",
    headers: {
      Accept: "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!_0x128937["ok"])
    throw new Error(
      "previewOfferEarnings\x20failed:\x20HTTP\x20" + _0x128937["status"],
    );
  const _0x21c837 = await _0x128937["json"]();
  return (
    console["log"](
      "💡\x20Earnings\x20preview\x20for\x20post\x20" + _0x18819c + ":",
      _0x21c837,
    ),
    _0x21c837
  );
}
function _0x235972() {
  const _0x5e5d04 = document["querySelectorAll"]("a[href^=\x22/listing/\x22]");
  for (let _0x418b9f of _0x5e5d04) {
    const _0x39e3fd = _0x418b9f["getAttribute"]("href")["match"](/-(\w{24})$/);
    if (_0x39e3fd) {
      const _0x41fbb2 = _0x39e3fd[0x1];
      return (console["log"]("Listing\x20ID:", _0x41fbb2), _0x41fbb2);
    }
  }
  return (console["warn"]("No\x20listing\x20ID\x20found."), null);
}
function _0x18da54() {
  const _0x2fef1f = window["location"]["pathname"]["match"](
    /\/listing\/.*-(\w{24})$/,
  );
  if (_0x2fef1f) {
    const _0x14b721 = _0x2fef1f[0x1];
    return (
      console["log"]("Listing\x20ID\x20from\x20URL:", _0x14b721),
      _0x14b721
    );
  }
  return (console["warn"]("No\x20listing\x20ID\x20found\x20in\x20URL."), null);
}
function _0x1923ba() {
  var _0x644e61 = _0x235972();
  return (_0x644e61 || (_0x644e61 = _0x18da54()), _0x644e61);
}
async function _0x3639ad() {
  var _0xc55bb0 = _0x1923ba(),
    _0x3ca59c = await _0xbe91cb(_0xc55bb0);
  return atob(_0x3ca59c);
}
async function _0x51ffe1() {
  var _0x14a636 = await _0x3639ad();
  if (!_0x14a636) throw new Error("ASIN\x20not\x20found");
  const { domain: _0x1f5559 } =
      await chrome["storage"]["local"]["get"]("domain"),
    _0x2a4897 =
      "https://www.amazon." + _0x1f5559 + "/dp/" + _0x14a636 + "?th=1&psc=1";
  chrome["runtime"]["sendMessage"]({ type: "openNewTab", url: _0x2a4897 });
}
(console["log"]("content/poshmark/product_page/content.js\x20loaded"),
  _0x5cc783());
async function _0x5cc783() {
  await _0x1967e0();
  var _0x4918bb = _0x2043c4(_0x51ffe1),
    _0x3393ba = document["querySelector"](".listing__title");
  (console["log"](_0x3393ba),
    _0x3393ba["parentElement"]["insertBefore"](_0x4918bb, _0x3393ba));
}
