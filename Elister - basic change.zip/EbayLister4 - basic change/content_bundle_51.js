function _0x2076b6() {
  return new Promise((_0x48feef) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0x48feef();
      });
    });
  });
}
function _0x2220d2() {
  return new Promise((_0x454758) => {
    requestIdleCallback(() => {
      _0x454758();
    });
  });
}
function _0x38a5fe(_0x5d588b = 0x3e8) {
  return new Promise((_0x4b3e7d, _0x1c5bbc) => {
    let _0x262a6d,
      _0x1e1003 = Date["now"](),
      _0x47e720 = !0x1;
    function _0x2428dd() {
      if (Date["now"]() - _0x1e1003 > _0x5d588b)
        (_0x47e720 && _0x262a6d["disconnect"](), _0x4b3e7d());
      else setTimeout(_0x2428dd, _0x5d588b);
    }
    const _0xbbb57b = () => {
        _0x1e1003 = Date["now"]();
      },
      _0x1a08dc = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x262a6d = new MutationObserver(_0xbbb57b)),
        _0x262a6d["observe"](document["body"], _0x1a08dc),
        (_0x47e720 = !0x0),
        setTimeout(_0x2428dd, _0x5d588b));
    else
      window["onload"] = () => {
        ((_0x262a6d = new MutationObserver(_0xbbb57b)),
          _0x262a6d["observe"](document["body"], _0x1a08dc),
          (_0x47e720 = !0x0),
          setTimeout(_0x2428dd, _0x5d588b));
      };
  });
}
async function _0x26e666() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x38a5fe(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
async function _0x3bb447() {
  function _0x3b39c8() {
    return document["querySelectorAll"]("tr");
  }
  function _0x14efe0(_0x43214f, _0x26758d) {
    const _0x4074fe = _0x43214f["querySelectorAll"]("span"),
      _0x37a39c = [];
    for (const _0x21c752 of _0x4074fe)
      _0x21c752["innerText"] === _0x26758d && _0x37a39c["push"](_0x21c752);
    return _0x37a39c[0x1]
      ? _0x37a39c[0x1]["parentElement"]["querySelector"](".ellipsis")[
          "innerText"
        ]
      : null;
  }
  function _0x366510(_0x514ffe) {
    return _0x14efe0(_0x514ffe, "SELL");
  }
  function _0x3cab59(_0x28e446) {
    return _0x14efe0(_0x28e446, "BUY");
  }
  function pushItems() {
    const _0x18074c = _0x3b39c8();
    for (const _0x571469 of _0x18074c)
      try {
        const _0xa8bc41 = {
          itemNumber: _0x366510(_0x571469),
          sku: _0x3cab59(_0x571469),
        };
        _0xa8bc41["itemNumber"] &&
          _0xa8bc41["sku"] &&
          "" !== _0xa8bc41["itemNumber"]["trim"]() &&
          "" !== _0xa8bc41["sku"]["trim"]() &&
          _0x34406f["push"](_0xa8bc41);
      } catch (_0x36a668) {}
    console["log"](
      "Total\x20Items\x20Collected\x20(so\x20far):\x20" + _0x34406f["length"],
    );
  }
  function _0x59b0b4() {
    const _0x41f3e4 = document["querySelectorAll"](
      ".ant5-pagination-item-link",
    );
    if (!_0x41f3e4["length"]) return !0x1;
    const _0x255516 = _0x41f3e4[_0x41f3e4["length"] - 0x1];
    return !(
      !_0x255516 ||
      _0x255516["classList"]["contains"]("ant5-pagination-disabled") ||
      "true" === _0x255516["getAttribute"]("aria-disabled") ||
      _0x255516["disabled"]
    );
  }
  function _0x1e45f7() {
    const _0x3ccadb = document["querySelectorAll"](
      ".ant5-pagination-item-link",
    );
    _0x3ccadb[_0x3ccadb["length"] - 0x1]["click"]();
  }
  async function scrollToBottom(_0x26027b = 0x1388, _0xb1dee3 = 0x1f4) {
    document["title"] =
      "Scrolling\x20to\x20bottom\x20on\x20page\x20" + _0x37a599;
    let _0x101ddb = document["body"]["scrollHeight"],
      _0xa7d9fd = 0x0;
    for (; _0xa7d9fd < _0x26027b; ) {
      (window["scrollTo"](0x0, document["body"]["scrollHeight"]),
        await new Promise((_0x48ac0a) => setTimeout(_0x48ac0a, _0xb1dee3)));
      let _0x2df27d = document["body"]["scrollHeight"];
      if (_0x2df27d === _0x101ddb) break;
      ((_0x101ddb = _0x2df27d), (_0xa7d9fd += _0xb1dee3));
    }
    document["title"] =
      "Scrolled\x20to\x20bottom\x20on\x20page\x20" + _0x37a599;
  }
  async function _0x8f88c7(_0x1e74af = 0x2710, _0xe7c9dc = 0xfa) {
    document["title"] =
      "Waiting\x20for\x20items\x20to\x20load\x20on\x20page\x20" + _0x37a599;
    let _0x33c340 = 0x0;
    for (; _0x33c340 < _0x1e74af; ) {
      const _0x5dd3a8 = _0x3b39c8();
      let _0x3ea62e = !0x1;
      for (const _0x491971 of _0x5dd3a8)
        try {
          const _0x34a761 = _0x366510(_0x491971),
            _0x5cd28a = _0x3cab59(_0x491971);
          if (
            _0x34a761 &&
            _0x5cd28a &&
            "" !== _0x34a761["trim"]() &&
            "" !== _0x5cd28a["trim"]()
          ) {
            _0x3ea62e = !0x0;
            break;
          }
        } catch (_0x7c2653) {}
      if (_0x3ea62e) {
        document["title"] = "Items\x20loaded\x20on\x20page\x20" + _0x37a599;
        return;
      }
      (await new Promise((_0x3b63bc) => setTimeout(_0x3b63bc, _0xe7c9dc)),
        (_0x33c340 += _0xe7c9dc));
    }
    document["title"] =
      "Timeout\x20waiting\x20for\x20items\x20on\x20page\x20" + _0x37a599;
  }
  let _0x37a599 = 0x1,
    _0x34406f = [];
  (await scrollToBottom(), await _0x8f88c7(), pushItems());
  for (; _0x59b0b4(); ) {
    ((document["title"] = "Navigating\x20to\x20page\x20" + (_0x37a599 + 0x1)),
      console["log"]("Navigating\x20to\x20page\x20" + (_0x37a599 + 0x1)),
      _0x1e45f7(),
      _0x37a599++,
      await scrollToBottom(),
      await _0x8f88c7(),
      pushItems());
  }
  (console["log"]("No\x20next\x20page\x20found.\x20Finishing\x20up..."),
    (document["title"] =
      "Scraping\x20complete.\x20Saving\x20items\x20total:\x20" +
      _0x34406f["length"]),
    !(function (_0x256c01) {
      const _0x47396e = JSON["stringify"](_0x256c01, null, 0x2),
        _0x61a4aa = document["createElement"]("a");
      ((_0x61a4aa["href"] =
        "data:text/plain;charset=utf-8," + encodeURIComponent(_0x47396e)),
        (_0x61a4aa["target"] = "_blank"),
        (_0x61a4aa["download"] = "items.txt"),
        _0x61a4aa["click"]());
    })(_0x34406f),
    !(function (_0x1ac868) {
      const _0x5165af = document["createElement"]("a");
      ((_0x5165af["href"] =
        "data:text/csv;charset=utf-8," + encodeURIComponent(_0x1ac868)),
        (_0x5165af["target"] = "_blank"),
        (_0x5165af["download"] = "ebayFileExchange.csv"),
        _0x5165af["click"]());
    })(
      (function (_0x199107) {
        let _0x38fea0 = "Action,ItemID,CustomLabel\x0a";
        for (const _0x4fe209 of _0x199107) {
          const _0x38879a = btoa(_0x4fe209["sku"]);
          _0x38fea0 +=
            "Revise," + _0x4fe209["itemNumber"] + "," + _0x38879a + "\x0a";
        }
        return _0x38fea0;
      })(_0x34406f),
    ));
}
chrome["runtime"]["onMessage"]["addListener"](
  function (_0xf9c090, _0x24d1f2, _0x3b6a73) {
    "autods_download_skus" === _0xf9c090["type"] &&
      (console["log"]("Autods\x20SKU\x20download\x20initiated."), _0x3bb447());
  },
);
