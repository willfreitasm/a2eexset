function _0x553a99() {
  return new Promise((_0xcfb849) => {
    window["addEventListener"]("load", () => {
      requestIdleCallback(() => {
        _0xcfb849();
      });
    });
  });
}
function _0x30da68() {
  return new Promise((_0x2c9046) => {
    requestIdleCallback(() => {
      _0x2c9046();
    });
  });
}
function _0x475d10(_0x1a35a3 = 0x3e8) {
  return new Promise((_0x134f08, _0x68f531) => {
    let _0x2a894f,
      _0x22718c = Date["now"](),
      _0x594aaf = !0x1;
    function _0x51de1b() {
      if (Date["now"]() - _0x22718c > _0x1a35a3)
        (_0x594aaf && _0x2a894f["disconnect"](), _0x134f08());
      else setTimeout(_0x51de1b, _0x1a35a3);
    }
    const _0x512191 = () => {
        _0x22718c = Date["now"]();
      },
      _0x209335 = { attributes: !0x0, childList: !0x0, subtree: !0x0 };
    if ("complete" === document["readyState"])
      ((_0x2a894f = new MutationObserver(_0x512191)),
        _0x2a894f["observe"](document["body"], _0x209335),
        (_0x594aaf = !0x0),
        setTimeout(_0x51de1b, _0x1a35a3));
    else
      window["onload"] = () => {
        ((_0x2a894f = new MutationObserver(_0x512191)),
          _0x2a894f["observe"](document["body"], _0x209335),
          (_0x594aaf = !0x0),
          setTimeout(_0x51de1b, _0x1a35a3));
      };
  });
}
async function _0x58593b() {
  (console["log"](
    "waiting\x20for\x20page\x20to\x20load\x20and\x20become\x20stable",
  ),
    await _0x475d10(),
    console["log"](
      "page\x20loaded\x20and\x20stable,\x20notifying\x20background",
    ),
    chrome["runtime"]["sendMessage"]({ type: "page-loaded-and-stable" }));
}
console["log"]("Functions\x20script\x20loaded");
function _0x153a74(_0x53aaaa) {
  var _0x52077b = document["querySelector"](
    "label[aria-label=\x22Title\x22]\x20input",
  );
  if (_0x52077b) {
    let _0x345c27 = _0x52077b["value"];
    _0x52077b["value"] = _0x53aaaa;
    let _0x200402 = new Event("input", { bubbles: !0x0 });
    _0x200402["simulated"] = !0x0;
    let _0x1e7963 = _0x52077b["_valueTracker"];
    (_0x1e7963 && _0x1e7963["setValue"](_0x345c27),
      _0x52077b["dispatchEvent"](_0x200402));
  }
}
function _0x42cead(_0x540135) {
  var _0x13bed3 = document["querySelector"](
    "label[aria-label=\x22Price\x22]\x20input",
  );
  if (_0x13bed3) {
    let _0x59ac79 = _0x13bed3["value"];
    _0x13bed3["value"] = _0x540135;
    let _0x282ca4 = new Event("input", { bubbles: !0x0 });
    _0x282ca4["simulated"] = !0x0;
    let _0x3eb7ba = _0x13bed3["_valueTracker"];
    (_0x3eb7ba && _0x3eb7ba["setValue"](_0x59ac79),
      _0x13bed3["dispatchEvent"](_0x282ca4));
  }
}
function _0x39025e(_0x242d7e) {
  var _0x5c013c = document["querySelector"](
    "label[aria-label=\x22Description\x22]\x20textarea",
  );
  if (_0x5c013c) {
    let _0x47de71 = _0x5c013c["value"];
    _0x5c013c["value"] = _0x242d7e;
    let _0x55e453 = new Event("input", { bubbles: !0x0 });
    _0x55e453["simulated"] = !0x0;
    let _0x45566b = _0x5c013c["_valueTracker"];
    (_0x45566b && _0x45566b["setValue"](_0x47de71),
      _0x5c013c["dispatchEvent"](_0x55e453));
  }
}
async function _0x5c1f69(_0x5a7498) {
  var _0x1f4d36 = document["querySelector"](
    "label[aria-label=\x22Condition\x22]",
  );
  ((_0x1f4d36 = _0x1f4d36["children"][0x0]["children"][0x1])["click"](),
    console["log"]("Condition:\x20", _0x5a7498));
  var _0xbb138d = document["body"]["getElementsByTagName"]("*"),
    _0x2eca8e = null;
  for (var _0x5a01ec = 0x0; _0x5a01ec < _0xbb138d["length"]; _0x5a01ec++)
    if (_0xbb138d[_0x5a01ec]["textContent"] == _0x5a7498) {
      ((_0x2eca8e = _0xbb138d[_0x5a01ec]),
        console["log"]("Element\x20found:\x20", _0x2eca8e),
        _0xbb138d[_0x5a01ec]["click"]());
      return;
    }
  (await new Promise((_0x5c8052) => setTimeout(_0x5c8052, 0x3e8)),
    _0x5c1f69(_0x5a7498));
}
async function _0x49285d(_0x37b3da) {
  var _0x12b49b = document["querySelector"](
    "label[aria-label=\x22Category\x22]",
  );
  (_0x12b49b = _0x12b49b["children"][0x0]["children"][0x1])["click"]();
  var _0x1bcd6f = document["body"]["getElementsByTagName"]("*"),
    _0x426741 = null;
  for (var _0x2bd3e6 = 0x0; _0x2bd3e6 < _0x1bcd6f["length"]; _0x2bd3e6++)
    if (_0x1bcd6f[_0x2bd3e6]["textContent"] == _0x37b3da) {
      ((_0x426741 = _0x1bcd6f[_0x2bd3e6]),
        console["log"]("Element\x20found:\x20", _0x426741),
        _0x1bcd6f[_0x2bd3e6]["lastChild"]["click"]());
      return;
    }
  (await new Promise((_0x1cc1fb) => setTimeout(_0x1cc1fb, 0x3e8)),
    _0x49285d(_0x37b3da));
}
async function _0x155621(_0x5cf3b7) {
  var _0x1f80c7 = document["querySelector"](
    "label[aria-label=\x22SKU\x22]\x20input",
  );
  if (_0x1f80c7) {
    let _0x2cdf7d = _0x1f80c7["value"];
    _0x1f80c7["value"] = _0x5cf3b7;
    let _0x13cb06 = new Event("input", { bubbles: !0x0 });
    _0x13cb06["simulated"] = !0x0;
    let _0x3d1826 = _0x1f80c7["_valueTracker"];
    (_0x3d1826 && _0x3d1826["setValue"](_0x2cdf7d),
      _0x1f80c7["dispatchEvent"](_0x13cb06));
  }
}
var _0x40affc = "New\x20MacBook\x20Pro\x202021";
(_0x153a74(_0x40affc),
  _0x42cead("2000"),
  _0x39025e(
    "This\x20is\x20a\x20brand\x20new\x20MacBook\x20Pro\x202021.\x20It\x20is\x20the\x20best\x20laptop\x20in\x20the\x20world.\x20Buy\x20it\x20now!",
  ),
  _0x5c1f69("Used\x20-\x20Like\x20New"),
  _0x49285d("Tools"),
  _0x155621("1234567890"),
  console["log"]("Content\x20script\x20loaded"));
async function _0x31e380() {
  (await _0x475d10(), console["log"]("Content\x20script\x20loaded"));
}
_0x31e380();
