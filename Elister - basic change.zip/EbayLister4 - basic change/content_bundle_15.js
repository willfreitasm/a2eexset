async function _0x446713(_0x4dedeb, _0x310b0b) {
  return new Promise((_0x593e1e, _0x176381) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x4dedeb, data: _0x310b0b },
      function (_0x2108bc) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x310b0b),
          console["log"]("fetchData\x20response", _0x2108bc),
          _0x593e1e(_0x2108bc["data"]));
      },
    );
  });
}
async function _0x30c002(_0x6b4e4c, _0x34ea78) {
  return new Promise((_0x3e55a2, _0x4e18a8) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x6b4e4c, data: _0x34ea78 },
      function (_0x26f331) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x34ea78),
          console["log"]("fetchData\x20response", _0x26f331),
          _0x26f331["error"] && _0x4e18a8(_0x26f331["error"]),
          _0x3e55a2(_0x26f331["data"]));
      },
    );
  });
}
function _0x3c105f(
  _0x160c6d,
  {
    primeEligible: primeEligible = !0x0,
    maxPrice: maxPrice = null,
    minPrice: minPrice = null,
    pageNumber: pageNumber = 0x1,
    sort: sort = "reviews",
    freeShipping: freeShipping = !0x0,
    domain: domain = "com",
    isSellerAmazon: isSellerAmazon = !0x1,
  } = {},
) {
  (console["log"]("buildAmazonSearchUrl"),
    console["log"](_0x160c6d),
    console["log"]("maxPrice:\x20" + maxPrice),
    console["log"]("minPrice:\x20" + minPrice));
  let _0x4290bd =
    "https://www.amazon." + domain + "/s?k=" + encodeURIComponent(_0x160c6d);
  return (
    null != minPrice &&
      null == maxPrice &&
      (_0x4290bd += "&rh=p_36%3A" + 0x64 * minPrice + "-"),
    null == minPrice &&
      null != maxPrice &&
      (_0x4290bd += "&rh=p_36%3A-" + 0x64 * maxPrice),
    null != minPrice &&
      null != maxPrice &&
      (_0x4290bd += "&rh=p_36%3A" + 0x64 * minPrice + "-" + 0x64 * maxPrice),
    null == minPrice && null == maxPrice && (_0x4290bd += "&rh=p_36%3A-"),
    "com" == domain
      ? (_0x4290bd += "%2Cp_85%3A2470955011")
      : "ca" == domain && (_0x4290bd += "%2Cp_85%3A5690392011"),
    freeShipping &&
      ("com" == domain &&
        ((_0x4290bd += "%2C"), (_0x4290bd += "p_76%3A1249155011")),
      "ca" == domain &&
        ((_0x4290bd += "%2C"), (_0x4290bd += "p_76%3A3276484011"))),
    isSellerAmazon &&
      ("com" == domain &&
        ((_0x4290bd += "%2C"),
        (_0x4290bd += "p_n_feature_forty-seven_browse-bin%3A24677333011")),
      "ca" == domain &&
        ((_0x4290bd += "%2C"), (_0x4290bd += "p_6%3AA3DWYIK6Y9EEQB"))),
    primeEligible && (_0x4290bd += "&rhf=gp%3Aa"),
    "lowest-price" == sort && (_0x4290bd += "&s=price-asc-rank"),
    "reviews" == sort && (_0x4290bd += "&s=review-count-rank"),
    _0x4290bd
  );
}
function _0x4bc175(
  _0x267d1b,
  _0x114d11 = "ca",
  _0x3f719a = 0x1e,
  _0x20d550 = 0x0,
  _0x5081bf = 0x0,
  _0x4efc16 = 0x32,
  _0x186901 = "-itemssold",
  _0x28786f = "SOLD",
  _0x5e2ade = "EBAY-CA",
  _0x2758be = "America/Toronto",
  _0xa50290 = "BuyerLocation:::CA",
  _0x44f745 = 0x1e,
) {
  _0x5e2ade = "";
  switch (_0x114d11) {
    case "ca":
    default:
      _0x5e2ade = "EBAY-CA";
      break;
    case "com":
      _0x5e2ade = "EBAY-US";
      break;
    case "co.uk":
      _0x5e2ade = "EBAY-UK";
  }
  return (
    "https://www.ebay." +
    _0x114d11 +
    "/sh/research?" +
    [
      "keywords=" + _0x267d1b,
      "dayRange=" + _0x3f719a,
      "categoryId=" + _0x20d550,
      "offset=" + _0x5081bf,
      "limit=" + _0x4efc16,
      "sorting=" + _0x186901,
      "tabName=" + _0x28786f,
      "marketplace=" + _0x5e2ade,
      "tz=" + encodeURIComponent(_0x2758be),
      "minPrice=" + _0x44f745,
    ]["join"]("&")
  );
}
function _0x3869d1(_0x45bb5c) {
  return (
    "https://www.ebay.ca/sh/research?marketplace=EBAY-CA&keywords=" +
    encodeURIComponent(_0x45bb5c) +
    "&dayRange=30&endDate=1679082379576&startDate=1676493979576&categoryId=0&offset=0&limit=50&tabName=ACTIVE&tz=America%2FToronto"
  );
}
console["log"]("functions.js\x20loaded");
function _0x1cdf16() {
  let _0x15ed9f = document["createElement"]("button");
  return (
    (_0x15ed9f["className"] = "search-amazon-button"),
    (_0x15ed9f["textContent"] = "Search\x20Amazon"),
    _0x15ed9f["addEventListener"]("click", _0x2fc4e1),
    _0x15ed9f
  );
}
function _0x2fc4e1() {
  var _0x417e20 = this;
  for (; "TR" !== _0x417e20["tagName"]; ) _0x417e20 = _0x417e20["parentNode"];
  var _0x3ef169 = _0x587dcf(_0x417e20);
  chrome["runtime"]["sendMessage"]({
    type: "search-on-amazon",
    searchQuery: _0x3ef169,
  });
}
function _0x587dcf(_0x3ad16c) {
  return _0x3ad16c["getElementsByClassName"]("productTitle")[0x0]["innerText"];
}
function _0x446b81(_0x4647be) {
  var _0x20551c =
    _0x4647be["getElementsByClassName"]("sorting_1")[0x4]["innerText"];
  return (
    console["log"](_0x20551c),
    (_0x20551c = (_0x20551c = (_0x20551c = _0x20551c["replace"]("$", ""))[
      "replace"
    ](",", ""))["trim"]()),
    parseFloat(_0x20551c)
  );
}
function _0x2f91d8() {
  let _0x2ff6d8 = document["createElement"]("button");
  return (
    (_0x2ff6d8["className"] = "search-seller-from-clipboard-button"),
    (_0x2ff6d8["style"]["width"] = "fit-content"),
    (_0x2ff6d8["style"]["fontSize"] = "0.7em"),
    navigator["clipboard"]["readText"]()["then"]((_0x57b6b5) => {
      _0x2ff6d8["textContent"] = "Search\x20" + _0x57b6b5;
    }),
    _0x2ff6d8["addEventListener"]("click", _0xb6320),
    _0x2ff6d8
  );
}
function _0xb6320() {
  navigator["clipboard"]["readText"]()["then"]((_0x415a29) => {
    ((document["getElementById"]("tbSearch")["value"] = _0x415a29),
      document["getElementById"]("tbSearchBtn")["click"]());
  });
}
async function fetchProductTitles() {
  const _0x3bb1e2 = [],
    _0x3b5d2d = document["getElementsByClassName"]("productTitle");
  for (let _0x18c586 = 0x0; _0x18c586 < _0x3b5d2d["length"]; _0x18c586++)
    _0x3bb1e2["push"](_0x3b5d2d[_0x18c586]["innerText"]);
  return _0x3bb1e2;
}
function _0x3bedcc() {
  const _0x19d535 = document["createElement"]("button");
  ((_0x19d535["textContent"] = "Save\x20Titles"),
    _0x19d535["addEventListener"]("click", async (_0x9245d8) => {
      _0x9245d8["preventDefault"]();
      const _0x20ab0f = await fetchProductTitles();
      console["log"](_0x20ab0f);
      var { amazonSearchQuerys: _0x4a6e48 } =
        await chrome["storage"]["local"]["get"]("amazonSearchQuerys");
      (console["log"]("amazonSearchQuerys", _0x4a6e48),
        (_0x4a6e48 = _0x4a6e48["concat"](_0x20ab0f)),
        console["log"]("amazonSearchQuerys", _0x4a6e48),
        (_0x4a6e48 = [...new Set(_0x4a6e48)]),
        chrome["storage"]["local"]["set"](
          { amazonSearchQuerys: _0x4a6e48 },
          function () {
            console["log"]("amazonSearchQuerys\x20saved");
          },
        ));
    }),
    document["getElementById"]("searchBtn")["parentElement"]["appendChild"](
      _0x19d535,
    ));
}
function _0x35bf9f() {
  console["log"]("observeSearchBtn");
  const _0xcb4ca8 = new MutationObserver((_0x575481) => {
    _0x575481["forEach"]((_0x1ef003) => {
      "childList" === _0x1ef003["type"] &&
        document["getElementById"]("searchBtn") &&
        (console["log"]("searchBtn\x20found"),
        _0x3bedcc(),
        _0xcb4ca8["disconnect"]());
    });
  });
  _0xcb4ca8["observe"](document["body"], { childList: !0x0, subtree: !0x0 });
}
console["log"]("content.js\x20loaded");
try {
  var _0xc1385e = _0x2f91d8(),
    _0x1394ad = document["querySelector"](
      ".compSearchWrap\x20.scWrap\x20.csSearchWrap",
    );
  _0x1394ad["insertBefore"](_0xc1385e, _0x1394ad["children"][0x1]);
} catch (_0x181fb7) {
  console["log"](_0x181fb7);
}
function _0x53d27a() {
  var _0x305c78 = document["querySelector"]("#datatable-responsive\x20tbody")[
    "querySelectorAll"
  ]("tr");
  for (var _0x3b5d19 = 0x0; _0x3b5d19 < _0x305c78["length"]; _0x3b5d19++) {
    var _0x9c0ec9 = _0x305c78[_0x3b5d19];
    if (!_0x9c0ec9["querySelector"](".search-amazon-button")) {
      var _0x122fb8 = _0x1cdf16(),
        _0x4cfe67 = _0x9c0ec9["querySelector"]("td");
      _0x4cfe67 && _0x4cfe67["appendChild"](_0x122fb8);
    }
  }
}
function _0x5b3bd0() {
  var _0x39cdfd = document["querySelector"]("#datatable-responsive\x20tbody")[
    "querySelectorAll"
  ]("tr");
  for (var _0x22a9fe = 0x0; _0x22a9fe < _0x39cdfd["length"]; _0x22a9fe++) {
    var _0xa0e348 = _0x39cdfd[_0x22a9fe]["querySelector"](
      ".search-amazon-button",
    );
    _0xa0e348 && _0xa0e348["remove"]();
  }
}
async function _0x1eb41f() {
  return new Promise((_0x1f2613, _0x50ee37) => {
    const _0x15073b = document["querySelector"]("#datatable-responsive"),
      _0x5a92af = new MutationObserver((_0x17aef6) => {
        for (let _0x52f4c5 of _0x17aef6)
          if ("childList" === _0x52f4c5["type"]) {
            const _0x4d69e6 = _0x15073b["querySelector"]("tbody");
            _0x4d69e6 && (_0x5a92af["disconnect"](), _0x1f2613(_0x4d69e6));
          }
      });
    _0x5a92af["observe"](_0x15073b, {
      attributes: !0x1,
      childList: !0x0,
      subtree: !0x0,
    });
  });
}
function _0x226fab(_0x3bd854) {
  new MutationObserver((_0x2bbc86) => {
    for (let _0x18c4aa of _0x2bbc86)
      "childList" === _0x18c4aa["type"] &&
        (clearTimeout(window["changeTimeout"]),
        (window["changeTimeout"] = setTimeout(() => {
          _0x47d06c();
        }, 0x1f4)));
  })["observe"](_0x3bd854, {
    attributes: !0x1,
    childList: !0x0,
    subtree: !0x1,
  });
}
function _0x47d06c() {
  (console["log"]("Changes\x20stopped"), _0x53d27a());
}
(_0x1eb41f()["then"]((_0x4a55a8) => _0x226fab(_0x4a55a8)), _0x35bf9f());
