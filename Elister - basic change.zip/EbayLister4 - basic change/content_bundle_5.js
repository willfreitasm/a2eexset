!(function (_0x5e4c1d, _0x2e2e0a) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module["exports"] = _0x2e2e0a())
    : "function" == typeof define && define["amd"]
      ? define(_0x2e2e0a)
      : ((_0x5e4c1d = _0x5e4c1d || self)["Sortable"] = _0x2e2e0a());
})(this, function () {
  "use strict";
  function _0x196cd7(_0x337765, _0x106ec6) {
    var _0x2e0233,
      _0x4c3c85 = Object["keys"](_0x337765);
    return (
      Object["getOwnPropertySymbols"] &&
        ((_0x2e0233 = Object["getOwnPropertySymbols"](_0x337765)),
        _0x106ec6 &&
          (_0x2e0233 = _0x2e0233["filter"](function (_0x1c9131) {
            return Object["getOwnPropertyDescriptor"](_0x337765, _0x1c9131)[
              "enumerable"
            ];
          })),
        _0x4c3c85["push"]["apply"](_0x4c3c85, _0x2e0233)),
      _0x4c3c85
    );
  }
  function _0x2c4f52(_0x4494d1) {
    for (var _0x12746c = 0x1; _0x12746c < arguments["length"]; _0x12746c++) {
      var _0x17d3c3 = null != arguments[_0x12746c] ? arguments[_0x12746c] : {};
      _0x12746c % 0x2
        ? _0x196cd7(Object(_0x17d3c3), !0x0)["forEach"](function (_0x5f0640) {
            var _0x1b19af, _0x415165;
            ((_0x1b19af = _0x4494d1),
              (_0x5f0640 = _0x17d3c3[(_0x415165 = _0x5f0640)]),
              _0x415165 in _0x1b19af
                ? Object["defineProperty"](_0x1b19af, _0x415165, {
                    value: _0x5f0640,
                    enumerable: !0x0,
                    configurable: !0x0,
                    writable: !0x0,
                  })
                : (_0x1b19af[_0x415165] = _0x5f0640));
          })
        : Object["getOwnPropertyDescriptors"]
          ? Object["defineProperties"](
              _0x4494d1,
              Object["getOwnPropertyDescriptors"](_0x17d3c3),
            )
          : _0x196cd7(Object(_0x17d3c3))["forEach"](function (_0x32d1ef) {
              Object["defineProperty"](
                _0x4494d1,
                _0x32d1ef,
                Object["getOwnPropertyDescriptor"](_0x17d3c3, _0x32d1ef),
              );
            });
    }
    return _0x4494d1;
  }
  function _0x4953d2(_0x42538b) {
    return (_0x4953d2 =
      "function" == typeof Symbol && "symbol" == typeof Symbol["iterator"]
        ? function (_0x2ea207) {
            return typeof _0x2ea207;
          }
        : function (_0xda6eeb) {
            return _0xda6eeb &&
              "function" == typeof Symbol &&
              _0xda6eeb["constructor"] === Symbol &&
              _0xda6eeb !== Symbol["prototype"]
              ? "symbol"
              : typeof _0xda6eeb;
          })(_0x42538b);
  }
  function _0x355909() {
    return (_0x355909 =
      Object["assign"] ||
      function (_0x3f1de1) {
        for (
          var _0x491756 = 0x1;
          _0x491756 < arguments["length"];
          _0x491756++
        ) {
          var _0x471b36,
            _0xe57a71 = arguments[_0x491756];
          for (_0x471b36 in _0xe57a71)
            Object["prototype"]["hasOwnProperty"]["call"](
              _0xe57a71,
              _0x471b36,
            ) && (_0x3f1de1[_0x471b36] = _0xe57a71[_0x471b36]);
        }
        return _0x3f1de1;
      })["apply"](this, arguments);
  }
  function _0x4a6337(_0x2ec77d) {
    return (
      (function (_0x5660ed) {
        if (Array["isArray"](_0x5660ed)) return _0x545095(_0x5660ed);
      })(_0x2ec77d) ||
      (function (_0x32eb46) {
        if (
          ("undefined" != typeof Symbol &&
            null != _0x32eb46[Symbol["iterator"]]) ||
          null != _0x32eb46["@@iterator"]
        )
          return Array["from"](_0x32eb46);
      })(_0x2ec77d) ||
      (function (_0x3c6ab4, _0x381335) {
        if (_0x3c6ab4) {
          if ("string" == typeof _0x3c6ab4)
            return _0x545095(_0x3c6ab4, _0x381335);
          var _0x3c702d = Object["prototype"]["toString"]
            ["call"](_0x3c6ab4)
            ["slice"](0x8, -0x1);
          return "Map" ===
            (_0x3c702d =
              "Object" === _0x3c702d && _0x3c6ab4["constructor"]
                ? _0x3c6ab4["constructor"]["name"]
                : _0x3c702d) || "Set" === _0x3c702d
            ? Array["from"](_0x3c6ab4)
            : "Arguments" === _0x3c702d ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/["test"](_0x3c702d)
              ? _0x545095(_0x3c6ab4, _0x381335)
              : void 0x0;
        }
      })(_0x2ec77d) ||
      (function () {
        throw new TypeError(
          "Invalid\x20attempt\x20to\x20spread\x20non-iterable\x20instance.\x0aIn\x20order\x20to\x20be\x20iterable,\x20non-array\x20objects\x20must\x20have\x20a\x20[Symbol.iterator]()\x20method.",
        );
      })()
    );
  }
  function _0x545095(_0x3b51be, _0x34e1a1) {
    (null == _0x34e1a1 || _0x34e1a1 > _0x3b51be["length"]) &&
      (_0x34e1a1 = _0x3b51be["length"]);
    for (
      var _0x33d123 = 0x0, _0x19b46c = new Array(_0x34e1a1);
      _0x33d123 < _0x34e1a1;
      _0x33d123++
    )
      _0x19b46c[_0x33d123] = _0x3b51be[_0x33d123];
    return _0x19b46c;
  }
  function _0x18323d(_0x13c58b) {
    if ("undefined" != typeof window && window["navigator"])
      return !!navigator["userAgent"]["match"](_0x13c58b);
  }
  var _0x241510 = _0x18323d(
      /(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i,
    ),
    _0x4523c3 = _0x18323d(/Edge/i),
    _0x1c6d59 = _0x18323d(/firefox/i),
    _0x3fd77c =
      _0x18323d(/safari/i) && !_0x18323d(/chrome/i) && !_0x18323d(/android/i),
    _0x2808c4 = _0x18323d(/iP(ad|od|hone)/i),
    _0x295c46 = _0x18323d(/chrome/i) && _0x18323d(/android/i),
    _0x4f1ae2 = { capture: !0x1, passive: !0x1 };
  function _0x15866f(_0x5f5507, _0x1f6d60, _0x43d20a) {
    _0x5f5507["addEventListener"](
      _0x1f6d60,
      _0x43d20a,
      !_0x241510 && _0x4f1ae2,
    );
  }
  function _0x47ae28(_0x3cc50e, _0x37f75a, _0x56e2c6) {
    _0x3cc50e["removeEventListener"](
      _0x37f75a,
      _0x56e2c6,
      !_0x241510 && _0x4f1ae2,
    );
  }
  function _0x4578bf(_0x30330b, _0x1d03e5) {
    if (
      _0x1d03e5 &&
      (">" === _0x1d03e5[0x0] && (_0x1d03e5 = _0x1d03e5["substring"](0x1)),
      _0x30330b)
    )
      try {
        if (_0x30330b["matches"]) return _0x30330b["matches"](_0x1d03e5);
        if (_0x30330b["msMatchesSelector"])
          return _0x30330b["msMatchesSelector"](_0x1d03e5);
        if (_0x30330b["webkitMatchesSelector"])
          return _0x30330b["webkitMatchesSelector"](_0x1d03e5);
      } catch (_0x440363) {
        return;
      }
  }
  function _0x1b7759(_0x561cb5, _0x66e50a, _0x305300, _0x271e9a) {
    if (_0x561cb5) {
      _0x305300 = _0x305300 || document;
      do {
        if (
          (null != _0x66e50a &&
            (">" !== _0x66e50a[0x0] || _0x561cb5["parentNode"] === _0x305300) &&
            _0x4578bf(_0x561cb5, _0x66e50a)) ||
          (_0x271e9a && _0x561cb5 === _0x305300)
        )
          return _0x561cb5;
      } while (
        _0x561cb5 !== _0x305300 &&
        (_0x561cb5 =
          (_0x2cb558 = _0x561cb5)["host"] &&
          _0x2cb558 !== document &&
          _0x2cb558["host"]["nodeType"]
            ? _0x2cb558["host"]
            : _0x2cb558["parentNode"])
      );
    }
    var _0x2cb558;
    return null;
  }
  var _0x5230c4,
    _0xcabd38 = /\s+/g;
  function _0x27586c(_0x37d18d, _0xfd5d05, _0x4338f1) {
    var _0x20f26f;
    _0x37d18d &&
      _0xfd5d05 &&
      (_0x37d18d["classList"]
        ? _0x37d18d["classList"][_0x4338f1 ? "add" : "remove"](_0xfd5d05)
        : ((_0x20f26f = ("\x20" + _0x37d18d["className"] + "\x20")
            ["replace"](_0xcabd38, "\x20")
            ["replace"]("\x20" + _0xfd5d05 + "\x20", "\x20")),
          (_0x37d18d["className"] = (_0x20f26f +
            (_0x4338f1 ? "\x20" + _0xfd5d05 : ""))["replace"](
            _0xcabd38,
            "\x20",
          ))));
  }
  function _0x5df889(_0x46c26b, _0x4733a7, _0x43f1df) {
    var _0x186202 = _0x46c26b && _0x46c26b["style"];
    if (_0x186202) {
      if (void 0x0 === _0x43f1df)
        return (
          document["defaultView"] && document["defaultView"]["getComputedStyle"]
            ? (_0x43f1df = document["defaultView"]["getComputedStyle"](
                _0x46c26b,
                "",
              ))
            : _0x46c26b["currentStyle"] &&
              (_0x43f1df = _0x46c26b["currentStyle"]),
          void 0x0 === _0x4733a7 ? _0x43f1df : _0x43f1df[_0x4733a7]
        );
      _0x186202[
        (_0x4733a7 =
          _0x4733a7 in _0x186202 || -0x1 !== _0x4733a7["indexOf"]("webkit")
            ? _0x4733a7
            : "-webkit-" + _0x4733a7)
      ] = _0x43f1df + ("string" == typeof _0x43f1df ? "" : "px");
    }
  }
  function _0x9e6c8a(_0x1365ec, _0x28ab09) {
    var _0x4513eb = "";
    if ("string" == typeof _0x1365ec) _0x4513eb = _0x1365ec;
    else
      do {
        var _0x48fe78 = _0x5df889(_0x1365ec, "transform");
      } while (
        (_0x48fe78 &&
          "none" !== _0x48fe78 &&
          (_0x4513eb = _0x48fe78 + "\x20" + _0x4513eb),
        !_0x28ab09 && (_0x1365ec = _0x1365ec["parentNode"]))
      );
    var _0x3bfe7e =
      window["DOMMatrix"] ||
      window["WebKitCSSMatrix"] ||
      window["CSSMatrix"] ||
      window["MSCSSMatrix"];
    return _0x3bfe7e && new _0x3bfe7e(_0x4513eb);
  }
  function _0x90411(_0x53783f, _0x2f7f34, _0x110b6c) {
    if (_0x53783f) {
      var _0x3bc1e9 = _0x53783f["getElementsByTagName"](_0x2f7f34),
        _0x57b614 = 0x0,
        _0x37c694 = _0x3bc1e9["length"];
      if (_0x110b6c) {
        for (; _0x57b614 < _0x37c694; _0x57b614++)
          _0x110b6c(_0x3bc1e9[_0x57b614], _0x57b614);
      }
      return _0x3bc1e9;
    }
    return [];
  }
  function _0x2f148a() {
    return document["scrollingElement"] || document["documentElement"];
  }
  function _0x1250df(_0x2bddde, _0x309a48, _0x393b33, _0x5e5024, _0x38c955) {
    if (_0x2bddde["getBoundingClientRect"] || _0x2bddde === window) {
      var _0x5e11d3,
        _0x5bff8f,
        _0x2525d8,
        _0x503a42,
        _0x5eaf0d,
        _0x38a650,
        _0x677471 =
          _0x2bddde !== window &&
          _0x2bddde["parentNode"] &&
          _0x2bddde !== _0x2f148a()
            ? ((_0x5bff8f = (_0x5e11d3 = _0x2bddde["getBoundingClientRect"]())[
                "top"
              ]),
              (_0x2525d8 = _0x5e11d3["left"]),
              (_0x503a42 = _0x5e11d3["bottom"]),
              (_0x5eaf0d = _0x5e11d3["right"]),
              (_0x38a650 = _0x5e11d3["height"]),
              _0x5e11d3["width"])
            : ((_0x2525d8 = _0x5bff8f = 0x0),
              (_0x503a42 = window["innerHeight"]),
              (_0x5eaf0d = window["innerWidth"]),
              (_0x38a650 = window["innerHeight"]),
              window["innerWidth"]);
      if (
        (_0x309a48 || _0x393b33) &&
        _0x2bddde !== window &&
        ((_0x38c955 = _0x38c955 || _0x2bddde["parentNode"]), !_0x241510)
      )
        do {
          if (
            _0x38c955 &&
            _0x38c955["getBoundingClientRect"] &&
            ("none" !== _0x5df889(_0x38c955, "transform") ||
              (_0x393b33 && "static" !== _0x5df889(_0x38c955, "position")))
          ) {
            var _0x5f1eac = _0x38c955["getBoundingClientRect"]();
            ((_0x5bff8f -=
              _0x5f1eac["top"] +
              parseInt(_0x5df889(_0x38c955, "border-top-width"))),
              (_0x2525d8 -=
                _0x5f1eac["left"] +
                parseInt(_0x5df889(_0x38c955, "border-left-width"))),
              (_0x503a42 = _0x5bff8f + _0x5e11d3["height"]),
              (_0x5eaf0d = _0x2525d8 + _0x5e11d3["width"]));
            break;
          }
        } while ((_0x38c955 = _0x38c955["parentNode"]));
      return (
        _0x5e5024 &&
          _0x2bddde !== window &&
          ((_0x5e5024 =
            (_0x309a48 = _0x9e6c8a(_0x38c955 || _0x2bddde)) && _0x309a48["a"]),
          (_0x2bddde = _0x309a48 && _0x309a48["d"]),
          _0x309a48 &&
            ((_0x503a42 = (_0x5bff8f /= _0x2bddde) + (_0x38a650 /= _0x2bddde)),
            (_0x5eaf0d = (_0x2525d8 /= _0x5e5024) + (_0x677471 /= _0x5e5024)))),
        {
          top: _0x5bff8f,
          left: _0x2525d8,
          bottom: _0x503a42,
          right: _0x5eaf0d,
          width: _0x677471,
          height: _0x38a650,
        }
      );
    }
  }
  function _0x38db3b(_0x3b3460, _0x376ee0, _0x21c500) {
    for (
      var _0x183d40 = _0x1fb3c0(_0x3b3460, !0x0),
        _0x17b28d = _0x1250df(_0x3b3460)[_0x376ee0];
      _0x183d40;

    ) {
      var _0x989a7b = _0x1250df(_0x183d40)[_0x21c500];
      if (
        !("top" === _0x21c500 || "left" === _0x21c500
          ? _0x989a7b <= _0x17b28d
          : _0x17b28d <= _0x989a7b)
      )
        return _0x183d40;
      if (_0x183d40 === _0x2f148a()) break;
      _0x183d40 = _0x1fb3c0(_0x183d40, !0x1);
    }
    return !0x1;
  }
  function _0x193fa3(_0x3625d7, _0x497e9f, _0x46a79f, _0x4a5007) {
    for (
      var _0x25af65 = 0x0, _0x3a23e5 = 0x0, _0x20c324 = _0x3625d7["children"];
      _0x3a23e5 < _0x20c324["length"];

    ) {
      if (
        "none" !== _0x20c324[_0x3a23e5]["style"]["display"] &&
        _0x20c324[_0x3a23e5] !== _0x31214e["ghost"] &&
        (_0x4a5007 || _0x20c324[_0x3a23e5] !== _0x31214e["dragged"]) &&
        _0x1b7759(_0x20c324[_0x3a23e5], _0x46a79f["draggable"], _0x3625d7, !0x1)
      ) {
        if (_0x25af65 === _0x497e9f) return _0x20c324[_0x3a23e5];
        _0x25af65++;
      }
      _0x3a23e5++;
    }
    return null;
  }
  function _0x545036(_0x307d2c, _0x187271) {
    for (
      var _0x57761a = _0x307d2c["lastElementChild"];
      _0x57761a &&
      (_0x57761a === _0x31214e["ghost"] ||
        "none" === _0x5df889(_0x57761a, "display") ||
        (_0x187271 && !_0x4578bf(_0x57761a, _0x187271)));

    )
      _0x57761a = _0x57761a["previousElementSibling"];
    return _0x57761a || null;
  }
  function _0x493816(_0xa2d533, _0x30af99) {
    var _0x379933 = 0x0;
    if (!_0xa2d533 || !_0xa2d533["parentNode"]) return -0x1;
    for (; (_0xa2d533 = _0xa2d533["previousElementSibling"]); )
      "TEMPLATE" === _0xa2d533["nodeName"]["toUpperCase"]() ||
        _0xa2d533 === _0x31214e["clone"] ||
        (_0x30af99 && !_0x4578bf(_0xa2d533, _0x30af99)) ||
        _0x379933++;
    return _0x379933;
  }
  function _0x2e0c24(_0x274494) {
    var _0x35bcb0 = 0x0,
      _0x1ad9db = 0x0,
      _0x1f9a19 = _0x2f148a();
    if (_0x274494)
      do {
        var _0xa3f2ca = (_0x983b1e = _0x9e6c8a(_0x274494))["a"],
          _0x983b1e = _0x983b1e["d"];
      } while (
        ((_0x35bcb0 += _0x274494["scrollLeft"] * _0xa3f2ca),
        (_0x1ad9db += _0x274494["scrollTop"] * _0x983b1e),
        _0x274494 !== _0x1f9a19 && (_0x274494 = _0x274494["parentNode"]))
      );
    return [_0x35bcb0, _0x1ad9db];
  }
  function _0x1fb3c0(_0x4006c4, _0x65d816) {
    if (!_0x4006c4 || !_0x4006c4["getBoundingClientRect"]) return _0x2f148a();
    var _0x1a75f5 = _0x4006c4,
      _0x342c08 = !0x1;
    do {
      if (
        _0x1a75f5["clientWidth"] < _0x1a75f5["scrollWidth"] ||
        _0x1a75f5["clientHeight"] < _0x1a75f5["scrollHeight"]
      ) {
        var _0x4bc66e = _0x5df889(_0x1a75f5);
        if (
          (_0x1a75f5["clientWidth"] < _0x1a75f5["scrollWidth"] &&
            ("auto" == _0x4bc66e["overflowX"] ||
              "scroll" == _0x4bc66e["overflowX"])) ||
          (_0x1a75f5["clientHeight"] < _0x1a75f5["scrollHeight"] &&
            ("auto" == _0x4bc66e["overflowY"] ||
              "scroll" == _0x4bc66e["overflowY"]))
        ) {
          if (
            !_0x1a75f5["getBoundingClientRect"] ||
            _0x1a75f5 === document["body"]
          )
            return _0x2f148a();
          if (_0x342c08 || _0x65d816) return _0x1a75f5;
          _0x342c08 = !0x0;
        }
      }
    } while ((_0x1a75f5 = _0x1a75f5["parentNode"]));
    return _0x2f148a();
  }
  function _0x23d408(_0x35a392, _0x446454) {
    return (
      Math["round"](_0x35a392["top"]) === Math["round"](_0x446454["top"]) &&
      Math["round"](_0x35a392["left"]) === Math["round"](_0x446454["left"]) &&
      Math["round"](_0x35a392["height"]) ===
        Math["round"](_0x446454["height"]) &&
      Math["round"](_0x35a392["width"]) === Math["round"](_0x446454["width"])
    );
  }
  function _0x5cd183(_0x45bbac, _0x2b51db) {
    return function () {
      var _0x5092c9;
      _0x5230c4 ||
        (0x1 === (_0x5092c9 = arguments)["length"]
          ? _0x45bbac["call"](this, _0x5092c9[0x0])
          : _0x45bbac["apply"](this, _0x5092c9),
        (_0x5230c4 = setTimeout(function () {
          _0x5230c4 = void 0x0;
        }, _0x2b51db)));
    };
  }
  function _0x536a9b(_0x56f3fe, _0x3e9a72, _0x47d19a) {
    ((_0x56f3fe["scrollLeft"] += _0x3e9a72),
      (_0x56f3fe["scrollTop"] += _0x47d19a));
  }
  function _0x43ea8e(_0xc09ed2) {
    var _0x44d03e = window["Polymer"],
      _0x2fb52c = window["jQuery"] || window["Zepto"];
    return _0x44d03e && _0x44d03e["dom"]
      ? _0x44d03e["dom"](_0xc09ed2)["cloneNode"](!0x0)
      : _0x2fb52c
        ? _0x2fb52c(_0xc09ed2)["clone"](!0x0)[0x0]
        : _0xc09ed2["cloneNode"](!0x0);
  }
  function _0x398747(_0x285ba6, _0x56eb4a) {
    (_0x5df889(_0x285ba6, "position", "absolute"),
      _0x5df889(_0x285ba6, "top", _0x56eb4a["top"]),
      _0x5df889(_0x285ba6, "left", _0x56eb4a["left"]),
      _0x5df889(_0x285ba6, "width", _0x56eb4a["width"]),
      _0x5df889(_0x285ba6, "height", _0x56eb4a["height"]));
  }
  function _0x42e02d(_0x188841) {
    (_0x5df889(_0x188841, "position", ""),
      _0x5df889(_0x188841, "top", ""),
      _0x5df889(_0x188841, "left", ""),
      _0x5df889(_0x188841, "width", ""),
      _0x5df889(_0x188841, "height", ""));
  }
  var _0x4459c5 = "Sortable" + new Date()["getTime"](),
    _0x584cea = [],
    _0x7e28af = { initializeByDefault: !0x0 },
    _0x504264 = {
      mount: function (_0x207fcd) {
        for (var _0x11975c in _0x7e28af)
          !_0x7e28af["hasOwnProperty"](_0x11975c) ||
            _0x11975c in _0x207fcd ||
            (_0x207fcd[_0x11975c] = _0x7e28af[_0x11975c]);
        (_0x584cea["forEach"](function (_0x282c75) {
          if (_0x282c75["pluginName"] === _0x207fcd["pluginName"])
            throw "Sortable:\x20Cannot\x20mount\x20plugin\x20"["concat"](
              _0x207fcd["pluginName"],
              "\x20more\x20than\x20once",
            );
        }),
          _0x584cea["push"](_0x207fcd));
      },
      pluginEvent: function (_0x3c7b03, _0x212575, _0x3bc3bc) {
        var _0x4eab8f = this;
        ((this["eventCanceled"] = !0x1),
          (_0x3bc3bc["cancel"] = function () {
            _0x4eab8f["eventCanceled"] = !0x0;
          }));
        var _0x4e1a60 = _0x3c7b03 + "Global";
        _0x584cea["forEach"](function (_0x1a1567) {
          _0x212575[_0x1a1567["pluginName"]] &&
            (_0x212575[_0x1a1567["pluginName"]][_0x4e1a60] &&
              _0x212575[_0x1a1567["pluginName"]][_0x4e1a60](
                _0x2c4f52({ sortable: _0x212575 }, _0x3bc3bc),
              ),
            _0x212575["options"][_0x1a1567["pluginName"]] &&
              _0x212575[_0x1a1567["pluginName"]][_0x3c7b03] &&
              _0x212575[_0x1a1567["pluginName"]][_0x3c7b03](
                _0x2c4f52({ sortable: _0x212575 }, _0x3bc3bc),
              ));
        });
      },
      initializePlugins: function (_0x16fa73, _0x28057f, _0x2a874a, _0x5d8f73) {
        for (var _0x520c3b in (_0x584cea["forEach"](function (_0x3dc764) {
          var _0x5840f2 = _0x3dc764["pluginName"];
          (_0x16fa73["options"][_0x5840f2] ||
            _0x3dc764["initializeByDefault"]) &&
            (((_0x3dc764 = new _0x3dc764(
              _0x16fa73,
              _0x28057f,
              _0x16fa73["options"],
            ))["sortable"] = _0x16fa73),
            (_0x3dc764["options"] = _0x16fa73["options"]),
            (_0x16fa73[_0x5840f2] = _0x3dc764),
            _0x355909(_0x2a874a, _0x3dc764["defaults"]));
        }),
        _0x16fa73["options"])) {
          var _0x44d292;
          _0x16fa73["options"]["hasOwnProperty"](_0x520c3b) &&
            void 0x0 !==
              (_0x44d292 = this["modifyOption"](
                _0x16fa73,
                _0x520c3b,
                _0x16fa73["options"][_0x520c3b],
              )) &&
            (_0x16fa73["options"][_0x520c3b] = _0x44d292);
        }
      },
      getEventProperties: function (_0xe99df1, _0x52d740) {
        var _0x344009 = {};
        return (
          _0x584cea["forEach"](function (_0x465b92) {
            "function" == typeof _0x465b92["eventProperties"] &&
              _0x355909(
                _0x344009,
                _0x465b92["eventProperties"]["call"](
                  _0x52d740[_0x465b92["pluginName"]],
                  _0xe99df1,
                ),
              );
          }),
          _0x344009
        );
      },
      modifyOption: function (_0x4738f1, _0x3eb196, _0x3cc341) {
        var _0x213f0a;
        return (
          _0x584cea["forEach"](function (_0x34ff04) {
            _0x4738f1[_0x34ff04["pluginName"]] &&
              _0x34ff04["optionListeners"] &&
              "function" == typeof _0x34ff04["optionListeners"][_0x3eb196] &&
              (_0x213f0a = _0x34ff04["optionListeners"][_0x3eb196]["call"](
                _0x4738f1[_0x34ff04["pluginName"]],
                _0x3cc341,
              ));
          }),
          _0x213f0a
        );
      },
    };
  function _0x45e685(_0x9b07e8) {
    var _0x452b88 = _0x9b07e8["sortable"],
      _0x19100e = _0x9b07e8["rootEl"],
      _0x24b07a = _0x9b07e8["name"],
      _0x57abea = _0x9b07e8["targetEl"],
      _0x5d74df = _0x9b07e8["cloneEl"],
      _0x1f5e9c = _0x9b07e8["toEl"],
      _0xa52bf2 = _0x9b07e8["fromEl"],
      _0x4f8791 = _0x9b07e8["oldIndex"],
      _0x164693 = _0x9b07e8["newIndex"],
      _0x1b7f21 = _0x9b07e8["oldDraggableIndex"],
      _0x2d83f2 = _0x9b07e8["newDraggableIndex"],
      _0x238d3a = _0x9b07e8["originalEvent"],
      _0x268d76 = _0x9b07e8["putSortable"],
      _0x53c5f3 = _0x9b07e8["extraEventProperties"];
    if ((_0x452b88 = _0x452b88 || (_0x19100e && _0x19100e[_0x4459c5]))) {
      var _0x14a7df,
        _0x417181 = _0x452b88["options"];
      ((_0x9b07e8 =
        "on" +
        _0x24b07a["charAt"](0x0)["toUpperCase"]() +
        _0x24b07a["substr"](0x1)),
        (!window["CustomEvent"] || _0x241510 || _0x4523c3
          ? (_0x14a7df = document["createEvent"]("Event"))["initEvent"](
              _0x24b07a,
              !0x0,
              !0x0,
            )
          : (_0x14a7df = new CustomEvent(_0x24b07a, {
              bubbles: !0x0,
              cancelable: !0x0,
            })),
        (_0x14a7df["to"] = _0x1f5e9c || _0x19100e),
        (_0x14a7df["from"] = _0xa52bf2 || _0x19100e),
        (_0x14a7df["item"] = _0x57abea || _0x19100e),
        (_0x14a7df["clone"] = _0x5d74df),
        (_0x14a7df["oldIndex"] = _0x4f8791),
        (_0x14a7df["newIndex"] = _0x164693),
        (_0x14a7df["oldDraggableIndex"] = _0x1b7f21),
        (_0x14a7df["newDraggableIndex"] = _0x2d83f2),
        (_0x14a7df["originalEvent"] = _0x238d3a),
        (_0x14a7df["pullMode"] = _0x268d76
          ? _0x268d76["lastPutMode"]
          : void 0x0)));
      var _0x37d08a,
        _0x4e057f = _0x2c4f52(
          _0x2c4f52({}, _0x53c5f3),
          _0x504264["getEventProperties"](_0x24b07a, _0x452b88),
        );
      for (_0x37d08a in _0x4e057f) _0x14a7df[_0x37d08a] = _0x4e057f[_0x37d08a];
      (_0x19100e && _0x19100e["dispatchEvent"](_0x14a7df),
        _0x417181[_0x9b07e8] &&
          _0x417181[_0x9b07e8]["call"](_0x452b88, _0x14a7df));
    }
  }
  function _0x65a5d2(_0x1a9a88, _0x116826) {
    var _0x3ca484 = (_0x26415b =
        0x2 < arguments["length"] && void 0x0 !== arguments[0x2]
          ? arguments[0x2]
          : {})["evt"],
      _0x26415b = (function (_0x1bbbf8, _0x44a66c) {
        if (null == _0x1bbbf8) return {};
        var _0x3952c6,
          _0x56433c = (function (_0x1bd7c1, _0x18505a) {
            if (null == _0x1bd7c1) return {};
            for (
              var _0x4c44c2,
                _0x13e76f = {},
                _0x522d62 = Object["keys"](_0x1bd7c1),
                _0x39a099 = 0x0;
              _0x39a099 < _0x522d62["length"];
              _0x39a099++
            )
              ((_0x4c44c2 = _0x522d62[_0x39a099]),
                0x0 <= _0x18505a["indexOf"](_0x4c44c2) ||
                  (_0x13e76f[_0x4c44c2] = _0x1bd7c1[_0x4c44c2]));
            return _0x13e76f;
          })(_0x1bbbf8, _0x44a66c);
        if (Object["getOwnPropertySymbols"]) {
          for (
            var _0x3be5b5 = Object["getOwnPropertySymbols"](_0x1bbbf8),
              _0xeb4989 = 0x0;
            _0xeb4989 < _0x3be5b5["length"];
            _0xeb4989++
          )
            ((_0x3952c6 = _0x3be5b5[_0xeb4989]),
              0x0 <= _0x44a66c["indexOf"](_0x3952c6) ||
                (Object["prototype"]["propertyIsEnumerable"]["call"](
                  _0x1bbbf8,
                  _0x3952c6,
                ) &&
                  (_0x56433c[_0x3952c6] = _0x1bbbf8[_0x3952c6])));
        }
        return _0x56433c;
      })(_0x26415b, _0x382a4c);
    _0x504264["pluginEvent"]["bind"](_0x31214e)(
      _0x1a9a88,
      _0x116826,
      _0x2c4f52(
        {
          dragEl: _0x331fac,
          parentEl: _0x55267f,
          ghostEl: _0x1f0cdc,
          rootEl: _0x653a7c,
          nextEl: _0x4af5bc,
          lastDownEl: _0x5ba633,
          cloneEl: _0x525d7a,
          cloneHidden: _0x5687a1,
          dragStarted: _0xf7577,
          putSortable: _0x3f5075,
          activeSortable: _0x31214e["active"],
          originalEvent: _0x3ca484,
          oldIndex: _0x43788e,
          oldDraggableIndex: _0x1acdbc,
          newIndex: _0x44bad5,
          newDraggableIndex: _0x4befe3,
          hideGhostForTarget: _0x54a880,
          unhideGhostForTarget: _0x37508b,
          cloneNowHidden: function () {
            _0x5687a1 = !0x0;
          },
          cloneNowShown: function () {
            _0x5687a1 = !0x1;
          },
          dispatchSortableEvent: function (_0x949b7a) {
            _0x28dcda({
              sortable: _0x116826,
              name: _0x949b7a,
              originalEvent: _0x3ca484,
            });
          },
        },
        _0x26415b,
      ),
    );
  }
  var _0x382a4c = ["evt"];
  function _0x28dcda(_0x3c08b0) {
    _0x45e685(
      _0x2c4f52(
        {
          putSortable: _0x3f5075,
          cloneEl: _0x525d7a,
          targetEl: _0x331fac,
          rootEl: _0x653a7c,
          oldIndex: _0x43788e,
          oldDraggableIndex: _0x1acdbc,
          newIndex: _0x44bad5,
          newDraggableIndex: _0x4befe3,
        },
        _0x3c08b0,
      ),
    );
  }
  var _0x331fac,
    _0x55267f,
    _0x1f0cdc,
    _0x653a7c,
    _0x4af5bc,
    _0x5ba633,
    _0x525d7a,
    _0x5687a1,
    _0x43788e,
    _0x44bad5,
    _0x1acdbc,
    _0x4befe3,
    _0x4a091b,
    _0x3f5075,
    _0x2d3217,
    _0x27fe72,
    _0x48eb5b,
    _0x3eb5f3,
    _0x512ff4,
    _0x4f7183,
    _0xf7577,
    _0x266b49,
    _0x2ade2c,
    _0x52a8b1,
    _0x2b74c2,
    _0xcf59fc = !0x1,
    _0x5e5f7d = !0x1,
    _0x40570c = [],
    _0x19048b = !0x1,
    _0x10c90c = !0x1,
    _0x468e9e = [],
    _0x5f3f1d = !0x1,
    _0x219a47 = [],
    _0x561a5b = "undefined" != typeof document,
    _0x4d2d51 = _0x2808c4,
    _0x51d0b1 = _0x4523c3 || _0x241510 ? "cssFloat" : "float",
    _0x287679 =
      _0x561a5b &&
      !_0x295c46 &&
      !_0x2808c4 &&
      "draggable" in document["createElement"]("div"),
    _0x3f0fc7 = (function () {
      if (_0x561a5b) {
        if (_0x241510) return !0x1;
        var _0x46a0c2 = document["createElement"]("x");
        return (
          (_0x46a0c2["style"]["cssText"] = "pointer-events:auto"),
          "auto" === _0x46a0c2["style"]["pointerEvents"]
        );
      }
    })(),
    _0x75018d = function (_0x43949e, _0x1714f3) {
      var _0xb6da4e = _0x5df889(_0x43949e),
        _0x100241 =
          parseInt(_0xb6da4e["width"]) -
          parseInt(_0xb6da4e["paddingLeft"]) -
          parseInt(_0xb6da4e["paddingRight"]) -
          parseInt(_0xb6da4e["borderLeftWidth"]) -
          parseInt(_0xb6da4e["borderRightWidth"]),
        _0x5b93b9 = _0x193fa3(_0x43949e, 0x0, _0x1714f3),
        _0x4b6c41 = _0x193fa3(_0x43949e, 0x1, _0x1714f3),
        _0x2eefdb = _0x5b93b9 && _0x5df889(_0x5b93b9),
        _0x187471 = _0x4b6c41 && _0x5df889(_0x4b6c41),
        _0x1c4284 =
          _0x2eefdb &&
          parseInt(_0x2eefdb["marginLeft"]) +
            parseInt(_0x2eefdb["marginRight"]) +
            _0x1250df(_0x5b93b9)["width"];
      _0x43949e =
        _0x187471 &&
        parseInt(_0x187471["marginLeft"]) +
          parseInt(_0x187471["marginRight"]) +
          _0x1250df(_0x4b6c41)["width"];
      if ("flex" === _0xb6da4e["display"])
        return "column" === _0xb6da4e["flexDirection"] ||
          "column-reverse" === _0xb6da4e["flexDirection"]
          ? "vertical"
          : "horizontal";
      if ("grid" === _0xb6da4e["display"])
        return _0xb6da4e["gridTemplateColumns"]["split"]("\x20")["length"] <=
          0x1
          ? "vertical"
          : "horizontal";
      if (_0x5b93b9 && _0x2eefdb["float"] && "none" !== _0x2eefdb["float"])
        return (
          (_0x1714f3 = "left" === _0x2eefdb["float"] ? "left" : "right"),
          !_0x4b6c41 ||
          ("both" !== _0x187471["clear"] && _0x187471["clear"] !== _0x1714f3)
            ? "horizontal"
            : "vertical"
        );
      return _0x5b93b9 &&
        ("block" === _0x2eefdb["display"] ||
          "flex" === _0x2eefdb["display"] ||
          "table" === _0x2eefdb["display"] ||
          "grid" === _0x2eefdb["display"] ||
          (_0x100241 <= _0x1c4284 && "none" === _0xb6da4e[_0x51d0b1]) ||
          (_0x4b6c41 &&
            "none" === _0xb6da4e[_0x51d0b1] &&
            _0x100241 < _0x1c4284 + _0x43949e))
        ? "vertical"
        : "horizontal";
    },
    _0x14ab7c = function (_0x14e9a7) {
      function _0x5c90fa(_0x397773, _0x130a2b) {
        return function (_0x1d0ac6, _0x5a3d98, _0x549d70, _0x2e462b) {
          var _0x398a83 =
            _0x1d0ac6["options"]["group"]["name"] &&
            _0x5a3d98["options"]["group"]["name"] &&
            _0x1d0ac6["options"]["group"]["name"] ===
              _0x5a3d98["options"]["group"]["name"];
          if (null == _0x397773 && (_0x130a2b || _0x398a83)) return !0x0;
          if (null == _0x397773 || !0x1 === _0x397773) return !0x1;
          if (_0x130a2b && "clone" === _0x397773) return _0x397773;
          if ("function" == typeof _0x397773)
            return _0x5c90fa(
              _0x397773(_0x1d0ac6, _0x5a3d98, _0x549d70, _0x2e462b),
              _0x130a2b,
            )(_0x1d0ac6, _0x5a3d98, _0x549d70, _0x2e462b);
          return (
            (_0x5a3d98 = (_0x130a2b ? _0x1d0ac6 : _0x5a3d98)["options"][
              "group"
            ]["name"]),
            !0x0 === _0x397773 ||
              ("string" == typeof _0x397773 && _0x397773 === _0x5a3d98) ||
              (_0x397773["join"] && -0x1 < _0x397773["indexOf"](_0x5a3d98))
          );
        };
      }
      var _0x2f6014 = {},
        _0x399b9d = _0x14e9a7["group"];
      ((_0x399b9d && "object" == _0x4953d2(_0x399b9d)) ||
        (_0x399b9d = { name: _0x399b9d }),
        (_0x2f6014["name"] = _0x399b9d["name"]),
        (_0x2f6014["checkPull"] = _0x5c90fa(_0x399b9d["pull"], !0x0)),
        (_0x2f6014["checkPut"] = _0x5c90fa(_0x399b9d["put"])),
        (_0x2f6014["revertClone"] = _0x399b9d["revertClone"]),
        (_0x14e9a7["group"] = _0x2f6014));
    },
    _0x54a880 = function () {
      !_0x3f0fc7 && _0x1f0cdc && _0x5df889(_0x1f0cdc, "display", "none");
    },
    _0x37508b = function () {
      !_0x3f0fc7 && _0x1f0cdc && _0x5df889(_0x1f0cdc, "display", "");
    };
  _0x561a5b &&
    document["addEventListener"](
      "click",
      function (_0x25b353) {
        if (_0x5e5f7d)
          return (
            _0x25b353["preventDefault"](),
            _0x25b353["stopPropagation"] && _0x25b353["stopPropagation"](),
            _0x25b353["stopImmediatePropagation"] &&
              _0x25b353["stopImmediatePropagation"](),
            (_0x5e5f7d = !0x1)
          );
      },
      !0x0,
    );
  function _0x3ce231(_0x421e85) {
    if (_0x331fac) {
      _0x421e85 = _0x421e85["touches"] ? _0x421e85["touches"][0x0] : _0x421e85;
      var _0x38b1fc =
        ((_0x1a1889 = _0x421e85["clientX"]),
        (_0x55b88d = _0x421e85["clientY"]),
        _0x40570c["some"](function (_0x59882b) {
          if (
            (_0x315080 =
              _0x59882b[_0x4459c5]["options"]["emptyInsertThreshold"]) &&
            !_0x545036(_0x59882b)
          ) {
            var _0x244879 = _0x1250df(_0x59882b),
              _0x17b2b2 =
                _0x1a1889 >= _0x244879["left"] - _0x315080 &&
                _0x1a1889 <= _0x244879["right"] + _0x315080,
              _0x315080 =
                _0x55b88d >= _0x244879["top"] - _0x315080 &&
                _0x55b88d <= _0x244879["bottom"] + _0x315080;
            return _0x17b2b2 && _0x315080 ? (_0x46f754 = _0x59882b) : void 0x0;
          }
        }),
        _0x46f754);
      if (_0x38b1fc) {
        var _0x1efe8e,
          _0x1ef1c5 = {};
        for (_0x1efe8e in _0x421e85)
          _0x421e85["hasOwnProperty"](_0x1efe8e) &&
            (_0x1ef1c5[_0x1efe8e] = _0x421e85[_0x1efe8e]);
        ((_0x1ef1c5["target"] = _0x1ef1c5["rootEl"] = _0x38b1fc),
          (_0x1ef1c5["preventDefault"] = void 0x0),
          (_0x1ef1c5["stopPropagation"] = void 0x0),
          _0x38b1fc[_0x4459c5]["_onDragOver"](_0x1ef1c5));
      }
    }
    var _0x1a1889, _0x55b88d, _0x46f754;
  }
  function _0xf63dce(_0x4c5130) {
    _0x331fac &&
      _0x331fac["parentNode"][_0x4459c5]["_isOutsideThisEl"](
        _0x4c5130["target"],
      );
  }
  function _0x31214e(_0x30084c, _0xe273) {
    if (!_0x30084c || !_0x30084c["nodeType"] || 0x1 !== _0x30084c["nodeType"])
      throw "Sortable:\x20`el`\x20must\x20be\x20an\x20HTMLElement,\x20not\x20"[
        "concat"
      ]({}["toString"]["call"](_0x30084c));
    ((this["el"] = _0x30084c),
      (this["options"] = _0xe273 = _0x355909({}, _0xe273)),
      (_0x30084c[_0x4459c5] = this));
    var _0x354f59,
      _0x471444,
      _0x379299 = {
        group: null,
        sort: !0x0,
        disabled: !0x1,
        store: null,
        handle: null,
        draggable: /^[uo]l$/i["test"](_0x30084c["nodeName"]) ? ">li" : ">*",
        swapThreshold: 0x1,
        invertSwap: !0x1,
        invertedSwapThreshold: null,
        removeCloneOnHide: !0x0,
        direction: function () {
          return _0x75018d(_0x30084c, this["options"]);
        },
        ghostClass: "sortable-ghost",
        chosenClass: "sortable-chosen",
        dragClass: "sortable-drag",
        ignore: "a,\x20img",
        filter: null,
        preventOnFilter: !0x0,
        animation: 0x0,
        easing: null,
        setData: function (_0x160f95, _0x1a6ac8) {
          _0x160f95["setData"]("Text", _0x1a6ac8["textContent"]);
        },
        dropBubble: !0x1,
        dragoverBubble: !0x1,
        dataIdAttr: "data-id",
        delay: 0x0,
        delayOnTouchOnly: !0x1,
        touchStartThreshold:
          (Number["parseInt"] ? Number : window)["parseInt"](
            window["devicePixelRatio"],
            0xa,
          ) || 0x1,
        forceFallback: !0x1,
        fallbackClass: "sortable-fallback",
        fallbackOnBody: !0x1,
        fallbackTolerance: 0x0,
        fallbackOffset: { x: 0x0, y: 0x0 },
        supportPointer:
          !0x1 !== _0x31214e["supportPointer"] &&
          "PointerEvent" in window &&
          !_0x3fd77c,
        emptyInsertThreshold: 0x5,
      };
    for (_0x354f59 in (_0x504264["initializePlugins"](
      this,
      _0x30084c,
      _0x379299,
    ),
    _0x379299))
      _0x354f59 in _0xe273 || (_0xe273[_0x354f59] = _0x379299[_0x354f59]);
    for (_0x471444 in (_0x14ab7c(_0xe273), this))
      "_" === _0x471444["charAt"](0x0) &&
        "function" == typeof this[_0x471444] &&
        (this[_0x471444] = this[_0x471444]["bind"](this));
    ((this["nativeDraggable"] = !_0xe273["forceFallback"] && _0x287679),
      this["nativeDraggable"] && (this["options"]["touchStartThreshold"] = 0x1),
      _0xe273["supportPointer"]
        ? _0x15866f(_0x30084c, "pointerdown", this["_onTapStart"])
        : (_0x15866f(_0x30084c, "mousedown", this["_onTapStart"]),
          _0x15866f(_0x30084c, "touchstart", this["_onTapStart"])),
      this["nativeDraggable"] &&
        (_0x15866f(_0x30084c, "dragover", this),
        _0x15866f(_0x30084c, "dragenter", this)),
      _0x40570c["push"](this["el"]),
      _0xe273["store"] &&
        _0xe273["store"]["get"] &&
        this["sort"](_0xe273["store"]["get"](this) || []),
      _0x355909(
        this,
        (function () {
          var _0x4caf59,
            _0x44b6fa = [];
          return {
            captureAnimationState: function () {
              ((_0x44b6fa = []),
                this["options"]["animation"] &&
                  []["slice"]
                    ["call"](this["el"]["children"])
                    ["forEach"](function (_0xa1e685) {
                      var _0x36c847, _0x556f06;
                      "none" !== _0x5df889(_0xa1e685, "display") &&
                        _0xa1e685 !== _0x31214e["ghost"] &&
                        (_0x44b6fa["push"]({
                          target: _0xa1e685,
                          rect: _0x1250df(_0xa1e685),
                        }),
                        (_0x36c847 = _0x2c4f52(
                          {},
                          _0x44b6fa[_0x44b6fa["length"] - 0x1]["rect"],
                        )),
                        !_0xa1e685["thisAnimationDuration"] ||
                          ((_0x556f06 = _0x9e6c8a(_0xa1e685, !0x0)) &&
                            ((_0x36c847["top"] -= _0x556f06["f"]),
                            (_0x36c847["left"] -= _0x556f06["e"]))),
                        (_0xa1e685["fromRect"] = _0x36c847));
                    }));
            },
            addAnimationState: function (_0xa53dc8) {
              _0x44b6fa["push"](_0xa53dc8);
            },
            removeAnimationState: function (_0x782a71) {
              _0x44b6fa["splice"](
                (function (_0x56be6d, _0x31610f) {
                  for (var _0x40a59f in _0x56be6d)
                    if (_0x56be6d["hasOwnProperty"](_0x40a59f)) {
                      for (var _0x2851ae in _0x31610f)
                        if (
                          _0x31610f["hasOwnProperty"](_0x2851ae) &&
                          _0x31610f[_0x2851ae] ===
                            _0x56be6d[_0x40a59f][_0x2851ae]
                        )
                          return Number(_0x40a59f);
                    }
                  return -0x1;
                })(_0x44b6fa, { target: _0x782a71 }),
                0x1,
              );
            },
            animateAll: function (_0x5eee5f) {
              var _0x113af6 = this;
              if (!this["options"]["animation"])
                return (
                  clearTimeout(_0x4caf59),
                  void ("function" == typeof _0x5eee5f && _0x5eee5f())
                );
              var _0x30292d = !0x1,
                _0x16d7a5 = 0x0;
              (_0x44b6fa["forEach"](function (_0x4dbd10) {
                var _0x539131 = 0x0,
                  _0x3f256c = _0x4dbd10["target"],
                  _0x3e95b4 = _0x3f256c["fromRect"],
                  _0x310e50 = _0x1250df(_0x3f256c),
                  _0x5502cb = _0x3f256c["prevFromRect"],
                  _0xefe83b = _0x3f256c["prevToRect"],
                  _0x53a6e0 = _0x4dbd10["rect"],
                  _0x4d4b35 = _0x9e6c8a(_0x3f256c, !0x0);
                (_0x4d4b35 &&
                  ((_0x310e50["top"] -= _0x4d4b35["f"]),
                  (_0x310e50["left"] -= _0x4d4b35["e"])),
                  (_0x3f256c["toRect"] = _0x310e50),
                  _0x3f256c["thisAnimationDuration"] &&
                    _0x23d408(_0x5502cb, _0x310e50) &&
                    !_0x23d408(_0x3e95b4, _0x310e50) &&
                    (_0x53a6e0["top"] - _0x310e50["top"]) /
                      (_0x53a6e0["left"] - _0x310e50["left"]) ==
                      (_0x3e95b4["top"] - _0x310e50["top"]) /
                        (_0x3e95b4["left"] - _0x310e50["left"]) &&
                    ((_0x4dbd10 = _0x53a6e0),
                    (_0x4d4b35 = _0x5502cb),
                    (_0x5502cb = _0xefe83b),
                    (_0xefe83b = _0x113af6["options"]),
                    (_0x539131 =
                      (Math["sqrt"](
                        Math["pow"](_0x4d4b35["top"] - _0x4dbd10["top"], 0x2) +
                          Math["pow"](
                            _0x4d4b35["left"] - _0x4dbd10["left"],
                            0x2,
                          ),
                      ) /
                        Math["sqrt"](
                          Math["pow"](
                            _0x4d4b35["top"] - _0x5502cb["top"],
                            0x2,
                          ) +
                            Math["pow"](
                              _0x4d4b35["left"] - _0x5502cb["left"],
                              0x2,
                            ),
                        )) *
                      _0xefe83b["animation"])),
                  _0x23d408(_0x310e50, _0x3e95b4) ||
                    ((_0x3f256c["prevFromRect"] = _0x3e95b4),
                    (_0x3f256c["prevToRect"] = _0x310e50),
                    (_0x539131 =
                      _0x539131 || _0x113af6["options"]["animation"]),
                    _0x113af6["animate"](
                      _0x3f256c,
                      _0x53a6e0,
                      _0x310e50,
                      _0x539131,
                    )),
                  _0x539131 &&
                    ((_0x30292d = !0x0),
                    (_0x16d7a5 = Math["max"](_0x16d7a5, _0x539131)),
                    clearTimeout(_0x3f256c["animationResetTimer"]),
                    (_0x3f256c["animationResetTimer"] = setTimeout(function () {
                      ((_0x3f256c["animationTime"] = 0x0),
                        (_0x3f256c["prevFromRect"] = null),
                        (_0x3f256c["fromRect"] = null),
                        (_0x3f256c["prevToRect"] = null),
                        (_0x3f256c["thisAnimationDuration"] = null));
                    }, _0x539131)),
                    (_0x3f256c["thisAnimationDuration"] = _0x539131)));
              }),
                clearTimeout(_0x4caf59),
                _0x30292d
                  ? (_0x4caf59 = setTimeout(function () {
                      "function" == typeof _0x5eee5f && _0x5eee5f();
                    }, _0x16d7a5))
                  : "function" == typeof _0x5eee5f && _0x5eee5f(),
                (_0x44b6fa = []));
            },
            animate: function (_0x11654e, _0x571224, _0x5d4b13, _0xf13bf5) {
              var _0x41c38a, _0x26714c;
              _0xf13bf5 &&
                (_0x5df889(_0x11654e, "transition", ""),
                _0x5df889(_0x11654e, "transform", ""),
                (_0x41c38a =
                  (_0x26714c = _0x9e6c8a(this["el"])) && _0x26714c["a"]),
                (_0x26714c = _0x26714c && _0x26714c["d"]),
                (_0x41c38a =
                  (_0x571224["left"] - _0x5d4b13["left"]) / (_0x41c38a || 0x1)),
                (_0x26714c =
                  (_0x571224["top"] - _0x5d4b13["top"]) / (_0x26714c || 0x1)),
                (_0x11654e["animatingX"] = !!_0x41c38a),
                (_0x11654e["animatingY"] = !!_0x26714c),
                _0x5df889(
                  _0x11654e,
                  "transform",
                  "translate3d(" + _0x41c38a + "px," + _0x26714c + "px,0)",
                ),
                (this["forRepaintDummy"] = _0x11654e["offsetWidth"]),
                _0x5df889(
                  _0x11654e,
                  "transition",
                  "transform\x20" +
                    _0xf13bf5 +
                    "ms" +
                    (this["options"]["easing"]
                      ? "\x20" + this["options"]["easing"]
                      : ""),
                ),
                _0x5df889(_0x11654e, "transform", "translate3d(0,0,0)"),
                "number" == typeof _0x11654e["animated"] &&
                  clearTimeout(_0x11654e["animated"]),
                (_0x11654e["animated"] = setTimeout(function () {
                  (_0x5df889(_0x11654e, "transition", ""),
                    _0x5df889(_0x11654e, "transform", ""),
                    (_0x11654e["animated"] = !0x1),
                    (_0x11654e["animatingX"] = !0x1),
                    (_0x11654e["animatingY"] = !0x1));
                }, _0xf13bf5)));
            },
          };
        })(),
      ));
  }
  function _0x4a0bf9(
    _0x3aed12,
    _0x3ba14c,
    _0x1851f2,
    _0x579f61,
    _0x4c1a85,
    _0x5000f7,
    _0x444c82,
    _0x2e1b6a,
  ) {
    var _0x31e3ff,
      _0x17755e = _0x3aed12[_0x4459c5],
      _0x311eb2 = _0x17755e["options"]["onMove"];
    return (
      !window["CustomEvent"] || _0x241510 || _0x4523c3
        ? (_0x31e3ff = document["createEvent"]("Event"))["initEvent"](
            "move",
            !0x0,
            !0x0,
          )
        : (_0x31e3ff = new CustomEvent("move", {
            bubbles: !0x0,
            cancelable: !0x0,
          })),
      (_0x31e3ff["to"] = _0x3ba14c),
      (_0x31e3ff["from"] = _0x3aed12),
      (_0x31e3ff["dragged"] = _0x1851f2),
      (_0x31e3ff["draggedRect"] = _0x579f61),
      (_0x31e3ff["related"] = _0x4c1a85 || _0x3ba14c),
      (_0x31e3ff["relatedRect"] = _0x5000f7 || _0x1250df(_0x3ba14c)),
      (_0x31e3ff["willInsertAfter"] = _0x2e1b6a),
      (_0x31e3ff["originalEvent"] = _0x444c82),
      _0x3aed12["dispatchEvent"](_0x31e3ff),
      _0x311eb2 ? _0x311eb2["call"](_0x17755e, _0x31e3ff, _0x444c82) : undefined
    );
  }
  function _0x41757a(_0x5ea813) {
    _0x5ea813["draggable"] = !0x1;
  }
  function _0x4e9835() {
    _0x5f3f1d = !0x1;
  }
  function _0x1c8ab5(_0x4db6b5) {
    return setTimeout(_0x4db6b5, 0x0);
  }
  function _0xc43f1b(_0x226d44) {
    return clearTimeout(_0x226d44);
  }
  ((_0x31214e["prototype"] = {
    constructor: _0x31214e,
    _isOutsideThisEl: function (_0x2706c2) {
      this["el"]["contains"](_0x2706c2) ||
        _0x2706c2 === this["el"] ||
        (_0x266b49 = null);
    },
    _getDirection: function (_0x608d6a, _0x16e042) {
      return "function" == typeof this["options"]["direction"]
        ? this["options"]["direction"]["call"](
            this,
            _0x608d6a,
            _0x16e042,
            _0x331fac,
          )
        : this["options"]["direction"];
    },
    _onTapStart: function (_0x5e0488) {
      if (_0x5e0488["cancelable"]) {
        var _0x562ff5 = this,
          _0xca1b15 = this["el"],
          _0x17d7a7 = this["options"],
          _0x430381 = _0x17d7a7["preventOnFilter"],
          _0x4a259b = _0x5e0488["type"],
          _0x1de397 =
            (_0x5e0488["touches"] && _0x5e0488["touches"][0x0]) ||
            (_0x5e0488["pointerType"] &&
              "touch" === _0x5e0488["pointerType"] &&
              _0x5e0488),
          _0x1bb9cf = (_0x1de397 || _0x5e0488)["target"],
          _0x500f91 =
            (_0x5e0488["target"]["shadowRoot"] &&
              ((_0x5e0488["path"] && _0x5e0488["path"][0x0]) ||
                (_0x5e0488["composedPath"] &&
                  _0x5e0488["composedPath"]()[0x0]))) ||
            _0x1bb9cf,
          _0x208a19 = _0x17d7a7["filter"];
        if (
          ((function (_0x5d5d5d) {
            _0x219a47["length"] = 0x0;
            var _0xaebd03 = _0x5d5d5d["getElementsByTagName"]("input"),
              _0xae4ce6 = _0xaebd03["length"];
            for (; _0xae4ce6--; ) {
              var _0x4a4389 = _0xaebd03[_0xae4ce6];
              _0x4a4389["checked"] && _0x219a47["push"](_0x4a4389);
            }
          })(_0xca1b15),
          !_0x331fac &&
            !(
              (/mousedown|pointerdown/["test"](_0x4a259b) &&
                0x0 !== _0x5e0488["button"]) ||
              _0x17d7a7["disabled"]
            ) &&
            !_0x500f91["isContentEditable"] &&
            (this["nativeDraggable"] ||
              !_0x3fd77c ||
              !_0x1bb9cf ||
              "SELECT" !== _0x1bb9cf["tagName"]["toUpperCase"]()) &&
            !(
              ((_0x1bb9cf = _0x1b7759(
                _0x1bb9cf,
                _0x17d7a7["draggable"],
                _0xca1b15,
                !0x1,
              )) &&
                _0x1bb9cf["animated"]) ||
              _0x5ba633 === _0x1bb9cf
            ))
        ) {
          if (
            ((_0x43788e = _0x493816(_0x1bb9cf)),
            (_0x1acdbc = _0x493816(_0x1bb9cf, _0x17d7a7["draggable"])),
            "function" == typeof _0x208a19)
          ) {
            if (_0x208a19["call"](this, _0x5e0488, _0x1bb9cf, this))
              return (
                _0x28dcda({
                  sortable: _0x562ff5,
                  rootEl: _0x500f91,
                  name: "filter",
                  targetEl: _0x1bb9cf,
                  toEl: _0xca1b15,
                  fromEl: _0xca1b15,
                }),
                _0x65a5d2("filter", _0x562ff5, { evt: _0x5e0488 }),
                void (
                  _0x430381 &&
                  _0x5e0488["cancelable"] &&
                  _0x5e0488["preventDefault"]()
                )
              );
          } else {
            if (
              (_0x208a19 =
                _0x208a19 &&
                _0x208a19["split"](",")["some"](function (_0x52ada7) {
                  if (
                    (_0x52ada7 = _0x1b7759(
                      _0x500f91,
                      _0x52ada7["trim"](),
                      _0xca1b15,
                      !0x1,
                    ))
                  )
                    return (
                      _0x28dcda({
                        sortable: _0x562ff5,
                        rootEl: _0x52ada7,
                        name: "filter",
                        targetEl: _0x1bb9cf,
                        fromEl: _0xca1b15,
                        toEl: _0xca1b15,
                      }),
                      _0x65a5d2("filter", _0x562ff5, { evt: _0x5e0488 }),
                      !0x0
                    );
                }))
            )
              return void (
                _0x430381 &&
                _0x5e0488["cancelable"] &&
                _0x5e0488["preventDefault"]()
              );
          }
          (_0x17d7a7["handle"] &&
            !_0x1b7759(_0x500f91, _0x17d7a7["handle"], _0xca1b15, !0x1)) ||
            this["_prepareDragStart"](_0x5e0488, _0x1de397, _0x1bb9cf);
        }
      }
    },
    _prepareDragStart: function (_0x12ce7c, _0x3c18d5, _0x53d0cc) {
      var _0x5090d2,
        _0x1ae393 = this,
        _0x152caa = _0x1ae393["el"],
        _0x190089 = _0x1ae393["options"],
        _0x3353a0 = _0x152caa["ownerDocument"];
      _0x53d0cc &&
        !_0x331fac &&
        _0x53d0cc["parentNode"] === _0x152caa &&
        ((_0x5090d2 = _0x1250df(_0x53d0cc)),
        (_0x653a7c = _0x152caa),
        (_0x55267f = (_0x331fac = _0x53d0cc)["parentNode"]),
        (_0x4af5bc = _0x331fac["nextSibling"]),
        (_0x5ba633 = _0x53d0cc),
        (_0x4a091b = _0x190089["group"]),
        (_0x2d3217 = {
          target: (_0x31214e["dragged"] = _0x331fac),
          clientX: (_0x3c18d5 || _0x12ce7c)["clientX"],
          clientY: (_0x3c18d5 || _0x12ce7c)["clientY"],
        }),
        (_0x512ff4 = _0x2d3217["clientX"] - _0x5090d2["left"]),
        (_0x4f7183 = _0x2d3217["clientY"] - _0x5090d2["top"]),
        (this["_lastX"] = (_0x3c18d5 || _0x12ce7c)["clientX"]),
        (this["_lastY"] = (_0x3c18d5 || _0x12ce7c)["clientY"]),
        (_0x331fac["style"]["will-change"] = "all"),
        (_0x5090d2 = function () {
          (_0x65a5d2("delayEnded", _0x1ae393, { evt: _0x12ce7c }),
            _0x31214e["eventCanceled"]
              ? _0x1ae393["_onDrop"]()
              : (_0x1ae393["_disableDelayedDragEvents"](),
                !_0x1c6d59 &&
                  _0x1ae393["nativeDraggable"] &&
                  (_0x331fac["draggable"] = !0x0),
                _0x1ae393["_triggerDragStart"](_0x12ce7c, _0x3c18d5),
                _0x28dcda({
                  sortable: _0x1ae393,
                  name: "choose",
                  originalEvent: _0x12ce7c,
                }),
                _0x27586c(_0x331fac, _0x190089["chosenClass"], !0x0)));
        }),
        _0x190089["ignore"]["split"](",")["forEach"](function (_0x104c4f) {
          _0x90411(_0x331fac, _0x104c4f["trim"](), _0x41757a);
        }),
        _0x15866f(_0x3353a0, "dragover", _0x3ce231),
        _0x15866f(_0x3353a0, "mousemove", _0x3ce231),
        _0x15866f(_0x3353a0, "touchmove", _0x3ce231),
        _0x15866f(_0x3353a0, "mouseup", _0x1ae393["_onDrop"]),
        _0x15866f(_0x3353a0, "touchend", _0x1ae393["_onDrop"]),
        _0x15866f(_0x3353a0, "touchcancel", _0x1ae393["_onDrop"]),
        _0x1c6d59 &&
          this["nativeDraggable"] &&
          ((this["options"]["touchStartThreshold"] = 0x4),
          (_0x331fac["draggable"] = !0x0)),
        _0x65a5d2("delayStart", this, { evt: _0x12ce7c }),
        !_0x190089["delay"] ||
        (_0x190089["delayOnTouchOnly"] && !_0x3c18d5) ||
        (this["nativeDraggable"] && (_0x4523c3 || _0x241510))
          ? _0x5090d2()
          : _0x31214e["eventCanceled"]
            ? this["_onDrop"]()
            : (_0x15866f(
                _0x3353a0,
                "mouseup",
                _0x1ae393["_disableDelayedDrag"],
              ),
              _0x15866f(
                _0x3353a0,
                "touchend",
                _0x1ae393["_disableDelayedDrag"],
              ),
              _0x15866f(
                _0x3353a0,
                "touchcancel",
                _0x1ae393["_disableDelayedDrag"],
              ),
              _0x15866f(
                _0x3353a0,
                "mousemove",
                _0x1ae393["_delayedDragTouchMoveHandler"],
              ),
              _0x15866f(
                _0x3353a0,
                "touchmove",
                _0x1ae393["_delayedDragTouchMoveHandler"],
              ),
              _0x190089["supportPointer"] &&
                _0x15866f(
                  _0x3353a0,
                  "pointermove",
                  _0x1ae393["_delayedDragTouchMoveHandler"],
                ),
              (_0x1ae393["_dragStartTimer"] = setTimeout(
                _0x5090d2,
                _0x190089["delay"],
              ))));
    },
    _delayedDragTouchMoveHandler: function (_0x4e27a5) {
      ((_0x4e27a5 = _0x4e27a5["touches"]
        ? _0x4e27a5["touches"][0x0]
        : _0x4e27a5),
        Math["max"](
          Math["abs"](_0x4e27a5["clientX"] - this["_lastX"]),
          Math["abs"](_0x4e27a5["clientY"] - this["_lastY"]),
        ) >=
          Math["floor"](
            this["options"]["touchStartThreshold"] /
              ((this["nativeDraggable"] && window["devicePixelRatio"]) || 0x1),
          ) && this["_disableDelayedDrag"]());
    },
    _disableDelayedDrag: function () {
      (_0x331fac && _0x41757a(_0x331fac),
        clearTimeout(this["_dragStartTimer"]),
        this["_disableDelayedDragEvents"]());
    },
    _disableDelayedDragEvents: function () {
      var _0x1bc018 = this["el"]["ownerDocument"];
      (_0x47ae28(_0x1bc018, "mouseup", this["_disableDelayedDrag"]),
        _0x47ae28(_0x1bc018, "touchend", this["_disableDelayedDrag"]),
        _0x47ae28(_0x1bc018, "touchcancel", this["_disableDelayedDrag"]),
        _0x47ae28(_0x1bc018, "mousemove", this["_delayedDragTouchMoveHandler"]),
        _0x47ae28(_0x1bc018, "touchmove", this["_delayedDragTouchMoveHandler"]),
        _0x47ae28(
          _0x1bc018,
          "pointermove",
          this["_delayedDragTouchMoveHandler"],
        ));
    },
    _triggerDragStart: function (_0x59ea27, _0x127dd7) {
      ((_0x127dd7 =
        _0x127dd7 || ("touch" == _0x59ea27["pointerType"] && _0x59ea27)),
        !this["nativeDraggable"] || _0x127dd7
          ? this["options"]["supportPointer"]
            ? _0x15866f(document, "pointermove", this["_onTouchMove"])
            : _0x15866f(
                document,
                _0x127dd7 ? "touchmove" : "mousemove",
                this["_onTouchMove"],
              )
          : (_0x15866f(_0x331fac, "dragend", this),
            _0x15866f(_0x653a7c, "dragstart", this["_onDragStart"])));
      try {
        document["selection"]
          ? _0x1c8ab5(function () {
              document["selection"]["empty"]();
            })
          : window["getSelection"]()["removeAllRanges"]();
      } catch (_0x45b4b1) {}
    },
    _dragStarted: function (_0x42f87d, _0x4c39d5) {
      var _0xfabce3;
      ((_0xcf59fc = !0x1),
        _0x653a7c && _0x331fac
          ? (_0x65a5d2("dragStarted", this, { evt: _0x4c39d5 }),
            this["nativeDraggable"] &&
              _0x15866f(document, "dragover", _0xf63dce),
            (_0xfabce3 = this["options"]),
            _0x42f87d || _0x27586c(_0x331fac, _0xfabce3["dragClass"], !0x1),
            _0x27586c(_0x331fac, _0xfabce3["ghostClass"], !0x0),
            (_0x31214e["active"] = this),
            _0x42f87d && this["_appendGhost"](),
            _0x28dcda({
              sortable: this,
              name: "start",
              originalEvent: _0x4c39d5,
            }))
          : this["_nulling"]());
    },
    _emulateDragOver: function () {
      if (_0x27fe72) {
        ((this["_lastX"] = _0x27fe72["clientX"]),
          (this["_lastY"] = _0x27fe72["clientY"]),
          _0x54a880());
        for (
          var _0x30d073 = document["elementFromPoint"](
              _0x27fe72["clientX"],
              _0x27fe72["clientY"],
            ),
            _0x15285c = _0x30d073;
          _0x30d073 &&
          _0x30d073["shadowRoot"] &&
          (_0x30d073 = _0x30d073["shadowRoot"]["elementFromPoint"](
            _0x27fe72["clientX"],
            _0x27fe72["clientY"],
          )) !== _0x15285c;

        )
          _0x15285c = _0x30d073;
        if (
          (_0x331fac["parentNode"][_0x4459c5]["_isOutsideThisEl"](_0x30d073),
          _0x15285c)
        )
          do {
            if (
              _0x15285c[_0x4459c5] &&
              _0x15285c[_0x4459c5]["_onDragOver"]({
                clientX: _0x27fe72["clientX"],
                clientY: _0x27fe72["clientY"],
                target: _0x30d073,
                rootEl: _0x15285c,
              }) &&
              !this["options"]["dragoverBubble"]
            )
              break;
          } while ((_0x15285c = (_0x30d073 = _0x15285c)["parentNode"]));
        _0x37508b();
      }
    },
    _onTouchMove: function (_0x12e84e) {
      if (_0x2d3217) {
        var _0x61fe81 = (_0x2d481f = this["options"])["fallbackTolerance"],
          _0x2d6536 = _0x2d481f["fallbackOffset"],
          _0x4e63b3 = _0x12e84e["touches"]
            ? _0x12e84e["touches"][0x0]
            : _0x12e84e,
          _0x19ef65 = _0x1f0cdc && _0x9e6c8a(_0x1f0cdc, !0x0),
          _0x315f49 = _0x1f0cdc && _0x19ef65 && _0x19ef65["a"],
          _0x8b145d = _0x1f0cdc && _0x19ef65 && _0x19ef65["d"],
          _0x2d481f = _0x4d2d51 && _0x2b74c2 && _0x2e0c24(_0x2b74c2);
        ((_0x315f49 =
          (_0x4e63b3["clientX"] - _0x2d3217["clientX"] + _0x2d6536["x"]) /
            (_0x315f49 || 0x1) +
          (_0x2d481f ? _0x2d481f[0x0] - _0x468e9e[0x0] : 0x0) /
            (_0x315f49 || 0x1)),
          (_0x8b145d =
            (_0x4e63b3["clientY"] - _0x2d3217["clientY"] + _0x2d6536["y"]) /
              (_0x8b145d || 0x1) +
            (_0x2d481f ? _0x2d481f[0x1] - _0x468e9e[0x1] : 0x0) /
              (_0x8b145d || 0x1)));
        if (!_0x31214e["active"] && !_0xcf59fc) {
          if (
            _0x61fe81 &&
            Math["max"](
              Math["abs"](_0x4e63b3["clientX"] - this["_lastX"]),
              Math["abs"](_0x4e63b3["clientY"] - this["_lastY"]),
            ) < _0x61fe81
          )
            return;
          this["_onDragStart"](_0x12e84e, !0x0);
        }
        (_0x1f0cdc &&
          (_0x19ef65
            ? ((_0x19ef65["e"] += _0x315f49 - (_0x48eb5b || 0x0)),
              (_0x19ef65["f"] += _0x8b145d - (_0x3eb5f3 || 0x0)))
            : (_0x19ef65 = {
                a: 0x1,
                b: 0x0,
                c: 0x0,
                d: 0x1,
                e: _0x315f49,
                f: _0x8b145d,
              }),
          (_0x19ef65 = "matrix("
            ["concat"](_0x19ef65["a"], ",")
            ["concat"](_0x19ef65["b"], ",")
            ["concat"](_0x19ef65["c"], ",")
            ["concat"](_0x19ef65["d"], ",")
            ["concat"](_0x19ef65["e"], ",")
            ["concat"](_0x19ef65["f"], ")")),
          _0x5df889(_0x1f0cdc, "webkitTransform", _0x19ef65),
          _0x5df889(_0x1f0cdc, "mozTransform", _0x19ef65),
          _0x5df889(_0x1f0cdc, "msTransform", _0x19ef65),
          _0x5df889(_0x1f0cdc, "transform", _0x19ef65),
          (_0x48eb5b = _0x315f49),
          (_0x3eb5f3 = _0x8b145d),
          (_0x27fe72 = _0x4e63b3)),
          _0x12e84e["cancelable"] && _0x12e84e["preventDefault"]());
      }
    },
    _appendGhost: function () {
      if (!_0x1f0cdc) {
        var _0x1b0cef = this["options"]["fallbackOnBody"]
            ? document["body"]
            : _0x653a7c,
          _0x501c37 = _0x1250df(_0x331fac, !0x0, _0x4d2d51, !0x0, _0x1b0cef),
          _0x2585fe = this["options"];
        if (_0x4d2d51) {
          for (
            _0x2b74c2 = _0x1b0cef;
            "static" === _0x5df889(_0x2b74c2, "position") &&
            "none" === _0x5df889(_0x2b74c2, "transform") &&
            _0x2b74c2 !== document;

          )
            _0x2b74c2 = _0x2b74c2["parentNode"];
          (_0x2b74c2 !== document["body"] &&
          _0x2b74c2 !== document["documentElement"]
            ? (_0x2b74c2 === document && (_0x2b74c2 = _0x2f148a()),
              (_0x501c37["top"] += _0x2b74c2["scrollTop"]),
              (_0x501c37["left"] += _0x2b74c2["scrollLeft"]))
            : (_0x2b74c2 = _0x2f148a()),
            (_0x468e9e = _0x2e0c24(_0x2b74c2)));
        }
        (_0x27586c(
          (_0x1f0cdc = _0x331fac["cloneNode"](!0x0)),
          _0x2585fe["ghostClass"],
          !0x1,
        ),
          _0x27586c(_0x1f0cdc, _0x2585fe["fallbackClass"], !0x0),
          _0x27586c(_0x1f0cdc, _0x2585fe["dragClass"], !0x0),
          _0x5df889(_0x1f0cdc, "transition", ""),
          _0x5df889(_0x1f0cdc, "transform", ""),
          _0x5df889(_0x1f0cdc, "box-sizing", "border-box"),
          _0x5df889(_0x1f0cdc, "margin", 0x0),
          _0x5df889(_0x1f0cdc, "top", _0x501c37["top"]),
          _0x5df889(_0x1f0cdc, "left", _0x501c37["left"]),
          _0x5df889(_0x1f0cdc, "width", _0x501c37["width"]),
          _0x5df889(_0x1f0cdc, "height", _0x501c37["height"]),
          _0x5df889(_0x1f0cdc, "opacity", "0.8"),
          _0x5df889(_0x1f0cdc, "position", _0x4d2d51 ? "absolute" : "fixed"),
          _0x5df889(_0x1f0cdc, "zIndex", "100000"),
          _0x5df889(_0x1f0cdc, "pointerEvents", "none"),
          (_0x31214e["ghost"] = _0x1f0cdc),
          _0x1b0cef["appendChild"](_0x1f0cdc),
          _0x5df889(
            _0x1f0cdc,
            "transform-origin",
            (_0x512ff4 / parseInt(_0x1f0cdc["style"]["width"])) * 0x64 +
              "%\x20" +
              (_0x4f7183 / parseInt(_0x1f0cdc["style"]["height"])) * 0x64 +
              "%",
          ));
      }
    },
    _onDragStart: function (_0x195ff7, _0x312b3b) {
      var _0x2889e1 = this,
        _0x5f3765 = _0x195ff7["dataTransfer"],
        _0x474ebe = _0x2889e1["options"];
      (_0x65a5d2("dragStart", this, { evt: _0x195ff7 }),
        _0x31214e["eventCanceled"]
          ? this["_onDrop"]()
          : (_0x65a5d2("setupClone", this),
            _0x31214e["eventCanceled"] ||
              (((_0x525d7a = _0x43ea8e(_0x331fac))["draggable"] = !0x1),
              (_0x525d7a["style"]["will-change"] = ""),
              this["_hideClone"](),
              _0x27586c(_0x525d7a, this["options"]["chosenClass"], !0x1),
              (_0x31214e["clone"] = _0x525d7a)),
            (_0x2889e1["cloneId"] = _0x1c8ab5(function () {
              (_0x65a5d2("clone", _0x2889e1),
                _0x31214e["eventCanceled"] ||
                  (_0x2889e1["options"]["removeCloneOnHide"] ||
                    _0x653a7c["insertBefore"](_0x525d7a, _0x331fac),
                  _0x2889e1["_hideClone"](),
                  _0x28dcda({ sortable: _0x2889e1, name: "clone" })));
            })),
            _0x312b3b || _0x27586c(_0x331fac, _0x474ebe["dragClass"], !0x0),
            _0x312b3b
              ? ((_0x5e5f7d = !0x0),
                (_0x2889e1["_loopId"] = setInterval(
                  _0x2889e1["_emulateDragOver"],
                  0x32,
                )))
              : (_0x47ae28(document, "mouseup", _0x2889e1["_onDrop"]),
                _0x47ae28(document, "touchend", _0x2889e1["_onDrop"]),
                _0x47ae28(document, "touchcancel", _0x2889e1["_onDrop"]),
                _0x5f3765 &&
                  ((_0x5f3765["effectAllowed"] = "move"),
                  _0x474ebe["setData"] &&
                    _0x474ebe["setData"]["call"](
                      _0x2889e1,
                      _0x5f3765,
                      _0x331fac,
                    )),
                _0x15866f(document, "drop", _0x2889e1),
                _0x5df889(_0x331fac, "transform", "translateZ(0)")),
            (_0xcf59fc = !0x0),
            (_0x2889e1["_dragStartId"] = _0x1c8ab5(
              _0x2889e1["_dragStarted"]["bind"](
                _0x2889e1,
                _0x312b3b,
                _0x195ff7,
              ),
            )),
            _0x15866f(document, "selectstart", _0x2889e1),
            (_0xf7577 = !0x0),
            _0x3fd77c && _0x5df889(document["body"], "user-select", "none")));
    },
    _onDragOver: function (_0x1bf0a5) {
      var _0xc03c43,
        _0x2ecdd3,
        _0x3d4aef,
        _0x44c0cd,
        _0x2bf5bd = this["el"],
        _0x530b6b = _0x1bf0a5["target"],
        _0x3b0afb = this["options"],
        _0x57ff7e = _0x3b0afb["group"],
        _0x423694 = _0x31214e["active"],
        _0xc72eea = _0x4a091b === _0x57ff7e,
        _0x337120 = _0x3b0afb["sort"],
        _0x30f5ed = _0x3f5075 || _0x423694,
        _0x5080f2 = this,
        _0x38eb2c = !0x1;
      if (!_0x5f3f1d) {
        if (
          (void 0x0 !== _0x1bf0a5["preventDefault"] &&
            _0x1bf0a5["cancelable"] &&
            _0x1bf0a5["preventDefault"](),
          (_0x530b6b = _0x1b7759(
            _0x530b6b,
            _0x3b0afb["draggable"],
            _0x2bf5bd,
            !0x0,
          )),
          _0x478fdd("dragOver"),
          _0x31214e["eventCanceled"])
        )
          return _0x38eb2c;
        if (
          _0x331fac["contains"](_0x1bf0a5["target"]) ||
          (_0x530b6b["animated"] &&
            _0x530b6b["animatingX"] &&
            _0x530b6b["animatingY"]) ||
          _0x5080f2["_ignoreWhileAnimating"] === _0x530b6b
        )
          return _0x3dbe08(!0x1);
        if (
          ((_0x5e5f7d = !0x1),
          _0x423694 &&
            !_0x3b0afb["disabled"] &&
            (_0xc72eea
              ? _0x337120 || (_0x2ecdd3 = _0x55267f !== _0x653a7c)
              : _0x3f5075 === this ||
                ((this["lastPutMode"] = _0x4a091b["checkPull"](
                  this,
                  _0x423694,
                  _0x331fac,
                  _0x1bf0a5,
                )) &&
                  _0x57ff7e["checkPut"](
                    this,
                    _0x423694,
                    _0x331fac,
                    _0x1bf0a5,
                  ))))
        ) {
          if (
            ((_0x3d4aef =
              "vertical" === this["_getDirection"](_0x1bf0a5, _0x530b6b)),
            (_0xc03c43 = _0x1250df(_0x331fac)),
            _0x478fdd("dragOverValid"),
            _0x31214e["eventCanceled"])
          )
            return _0x38eb2c;
          if (_0x2ecdd3)
            return (
              (_0x55267f = _0x653a7c),
              _0x4c5725(),
              this["_hideClone"](),
              _0x478fdd("revert"),
              _0x31214e["eventCanceled"] ||
                (_0x4af5bc
                  ? _0x653a7c["insertBefore"](_0x331fac, _0x4af5bc)
                  : _0x653a7c["appendChild"](_0x331fac)),
              _0x3dbe08(!0x0)
            );
          if (
            !(_0x2895f4 = _0x545036(_0x2bf5bd, _0x3b0afb["draggable"])) ||
            ((function (_0x52b17e, _0x450335, _0x45b217) {
              return (
                (_0x45b217 = _0x1250df(
                  _0x545036(_0x45b217["el"], _0x45b217["options"]["draggable"]),
                )),
                _0x450335
                  ? _0x52b17e["clientX"] > _0x45b217["right"] + 0xa ||
                    (_0x52b17e["clientX"] <= _0x45b217["right"] &&
                      _0x52b17e["clientY"] > _0x45b217["bottom"] &&
                      _0x52b17e["clientX"] >= _0x45b217["left"])
                  : (_0x52b17e["clientX"] > _0x45b217["right"] &&
                      _0x52b17e["clientY"] > _0x45b217["top"]) ||
                    (_0x52b17e["clientX"] <= _0x45b217["right"] &&
                      _0x52b17e["clientY"] > _0x45b217["bottom"] + 0xa)
              );
            })(_0x1bf0a5, _0x3d4aef, this) &&
              !_0x2895f4["animated"])
          ) {
            if (_0x2895f4 === _0x331fac) return _0x3dbe08(!0x1);
            if (
              ((_0x530b6b =
                _0x2895f4 && _0x2bf5bd === _0x1bf0a5["target"]
                  ? _0x2895f4
                  : _0x530b6b) && (_0x550506 = _0x1250df(_0x530b6b)),
              !0x1 !==
                _0x4a0bf9(
                  _0x653a7c,
                  _0x2bf5bd,
                  _0x331fac,
                  _0xc03c43,
                  _0x530b6b,
                  _0x550506,
                  _0x1bf0a5,
                  !!_0x530b6b,
                ))
            )
              return (
                _0x4c5725(),
                _0x2bf5bd["appendChild"](_0x331fac),
                (_0x55267f = _0x2bf5bd),
                _0x4c745b(),
                _0x3dbe08(!0x0)
              );
          } else {
            if (
              _0x2895f4 &&
              (function (_0x2020cb, _0x233a23, _0x5ed8d8) {
                return (
                  (_0x5ed8d8 = _0x1250df(
                    _0x193fa3(_0x5ed8d8["el"], 0x0, _0x5ed8d8["options"], !0x0),
                  )),
                  _0x233a23
                    ? _0x2020cb["clientX"] < _0x5ed8d8["left"] - 0xa ||
                      (_0x2020cb["clientY"] < _0x5ed8d8["top"] &&
                        _0x2020cb["clientX"] < _0x5ed8d8["right"])
                    : _0x2020cb["clientY"] < _0x5ed8d8["top"] - 0xa ||
                      (_0x2020cb["clientY"] < _0x5ed8d8["bottom"] &&
                        _0x2020cb["clientX"] < _0x5ed8d8["left"])
                );
              })(_0x1bf0a5, _0x3d4aef, this)
            ) {
              if (
                (_0x3f90a9 = _0x193fa3(_0x2bf5bd, 0x0, _0x3b0afb, !0x0)) ===
                _0x331fac
              )
                return _0x3dbe08(!0x1);
              if (
                ((_0x550506 = _0x1250df((_0x530b6b = _0x3f90a9))),
                !0x1 !==
                  _0x4a0bf9(
                    _0x653a7c,
                    _0x2bf5bd,
                    _0x331fac,
                    _0xc03c43,
                    _0x530b6b,
                    _0x550506,
                    _0x1bf0a5,
                    !0x1,
                  ))
              )
                return (
                  _0x4c5725(),
                  _0x2bf5bd["insertBefore"](_0x331fac, _0x3f90a9),
                  (_0x55267f = _0x2bf5bd),
                  _0x4c745b(),
                  _0x3dbe08(!0x0)
                );
            } else {
              if (_0x530b6b["parentNode"] === _0x2bf5bd) {
                var _0x4960e2,
                  _0x17b891,
                  _0x2c045c,
                  _0x2895f4,
                  _0x550506 = _0x1250df(_0x530b6b),
                  _0x3059fa = _0x331fac["parentNode"] !== _0x2bf5bd,
                  _0x51b826 =
                    ((_0x51b826 =
                      (_0x331fac["animated"] && _0x331fac["toRect"]) ||
                      _0xc03c43),
                    (_0x3a26e8 =
                      (_0x530b6b["animated"] && _0x530b6b["toRect"]) ||
                      _0x550506),
                    (_0x212e10 = (_0x44c0cd = _0x3d4aef)
                      ? _0x51b826["left"]
                      : _0x51b826["top"]),
                    (_0x57ff7e = _0x44c0cd
                      ? _0x51b826["right"]
                      : _0x51b826["bottom"]),
                    (_0x2895f4 = _0x44c0cd
                      ? _0x51b826["width"]
                      : _0x51b826["height"]),
                    (_0x3f90a9 = _0x44c0cd
                      ? _0x3a26e8["left"]
                      : _0x3a26e8["top"]),
                    (_0x51b826 = _0x44c0cd
                      ? _0x3a26e8["right"]
                      : _0x3a26e8["bottom"]),
                    (_0x3a26e8 = _0x44c0cd
                      ? _0x3a26e8["width"]
                      : _0x3a26e8["height"]),
                    !(
                      _0x212e10 === _0x3f90a9 ||
                      _0x57ff7e === _0x51b826 ||
                      _0x212e10 + _0x2895f4 / 0x2 ===
                        _0x3f90a9 + _0x3a26e8 / 0x2
                    )),
                  _0x212e10 = _0x3d4aef ? "top" : "left",
                  _0x3f90a9 = (_0x2895f4 =
                    _0x38db3b(_0x530b6b, "top", "top") ||
                    _0x38db3b(_0x331fac, "top", "top"))
                    ? _0x2895f4["scrollTop"]
                    : void 0x0;
                if (
                  (_0x266b49 !== _0x530b6b &&
                    ((_0x17b891 = _0x550506[_0x212e10]),
                    (_0x19048b = !0x1),
                    (_0x10c90c =
                      (!_0x51b826 && _0x3b0afb["invertSwap"]) || _0x3059fa)),
                  0x0 !==
                    (_0x4960e2 = (function (
                      _0x1f62fc,
                      _0x6cae42,
                      _0x212cb4,
                      _0x19d75f,
                      _0x222120,
                      _0x509a90,
                      _0x4736dc,
                      _0x477111,
                    ) {
                      var _0x434a1c = _0x19d75f
                          ? _0x1f62fc["clientY"]
                          : _0x1f62fc["clientX"],
                        _0x3693d0 = _0x19d75f
                          ? _0x212cb4["height"]
                          : _0x212cb4["width"];
                      ((_0x1f62fc = _0x19d75f
                        ? _0x212cb4["top"]
                        : _0x212cb4["left"]),
                        (_0x19d75f = _0x19d75f
                          ? _0x212cb4["bottom"]
                          : _0x212cb4["right"]),
                        (_0x212cb4 = !0x1));
                      if (!_0x4736dc) {
                        if (_0x477111 && _0x52a8b1 < _0x3693d0 * _0x222120) {
                          if (
                            (_0x19048b =
                              (!_0x19048b &&
                                (0x1 === _0x2ade2c
                                  ? _0x1f62fc + (_0x3693d0 * _0x509a90) / 0x2 <
                                    _0x434a1c
                                  : _0x434a1c <
                                    _0x19d75f -
                                      (_0x3693d0 * _0x509a90) / 0x2)) ||
                              _0x19048b)
                          )
                            _0x212cb4 = !0x0;
                          else {
                            if (
                              0x1 === _0x2ade2c
                                ? _0x434a1c < _0x1f62fc + _0x52a8b1
                                : _0x19d75f - _0x52a8b1 < _0x434a1c
                            )
                              return -_0x2ade2c;
                          }
                        } else {
                          if (
                            _0x1f62fc + (_0x3693d0 * (0x1 - _0x222120)) / 0x2 <
                              _0x434a1c &&
                            _0x434a1c <
                              _0x19d75f - (_0x3693d0 * (0x1 - _0x222120)) / 0x2
                          )
                            return (function (_0x54228e) {
                              return _0x493816(_0x331fac) < _0x493816(_0x54228e)
                                ? 0x1
                                : -0x1;
                            })(_0x6cae42);
                        }
                      }
                      return (_0x212cb4 = _0x212cb4 || _0x4736dc) &&
                        (_0x434a1c <
                          _0x1f62fc + (_0x3693d0 * _0x509a90) / 0x2 ||
                          _0x19d75f - (_0x3693d0 * _0x509a90) / 0x2 < _0x434a1c)
                        ? _0x1f62fc + _0x3693d0 / 0x2 < _0x434a1c
                          ? 0x1
                          : -0x1
                        : 0x0;
                    })(
                      _0x1bf0a5,
                      _0x530b6b,
                      _0x550506,
                      _0x3d4aef,
                      _0x51b826 ? 0x1 : _0x3b0afb["swapThreshold"],
                      null == _0x3b0afb["invertedSwapThreshold"]
                        ? _0x3b0afb["swapThreshold"]
                        : _0x3b0afb["invertedSwapThreshold"],
                      _0x10c90c,
                      _0x266b49 === _0x530b6b,
                    )))
                ) {
                  for (
                    var _0x295da5 = _0x493816(_0x331fac);
                    (_0x2c045c =
                      _0x55267f["children"][(_0x295da5 -= _0x4960e2)]) &&
                    ("none" === _0x5df889(_0x2c045c, "display") ||
                      _0x2c045c === _0x1f0cdc);

                  );
                }
                if (0x0 === _0x4960e2 || _0x2c045c === _0x530b6b)
                  return _0x3dbe08(!0x1);
                _0x2ade2c = _0x4960e2;
                var _0x3a26e8 = (_0x266b49 = _0x530b6b)["nextElementSibling"];
                _0x3059fa = !0x1;
                if (
                  !0x1 !==
                  (_0x51b826 = _0x4a0bf9(
                    _0x653a7c,
                    _0x2bf5bd,
                    _0x331fac,
                    _0xc03c43,
                    _0x530b6b,
                    _0x550506,
                    _0x1bf0a5,
                    (_0x3059fa = 0x1 === _0x4960e2),
                  ))
                )
                  return (
                    (0x1 !== _0x51b826 && -0x1 !== _0x51b826) ||
                      (_0x3059fa = 0x1 === _0x51b826),
                    (_0x5f3f1d = !0x0),
                    setTimeout(_0x4e9835, 0x1e),
                    _0x4c5725(),
                    _0x3059fa && !_0x3a26e8
                      ? _0x2bf5bd["appendChild"](_0x331fac)
                      : _0x530b6b["parentNode"]["insertBefore"](
                          _0x331fac,
                          _0x3059fa ? _0x3a26e8 : _0x530b6b,
                        ),
                    _0x2895f4 &&
                      _0x536a9b(
                        _0x2895f4,
                        0x0,
                        _0x3f90a9 - _0x2895f4["scrollTop"],
                      ),
                    (_0x55267f = _0x331fac["parentNode"]),
                    void 0x0 === _0x17b891 ||
                      _0x10c90c ||
                      (_0x52a8b1 = Math["abs"](
                        _0x17b891 - _0x1250df(_0x530b6b)[_0x212e10],
                      )),
                    _0x4c745b(),
                    _0x3dbe08(!0x0)
                  );
              }
            }
          }
          if (_0x2bf5bd["contains"](_0x331fac)) return _0x3dbe08(!0x1);
        }
        return !0x1;
      }
      function _0x478fdd(_0x3f97cf, _0x50c3e0) {
        _0x65a5d2(
          _0x3f97cf,
          _0x5080f2,
          _0x2c4f52(
            {
              evt: _0x1bf0a5,
              isOwner: _0xc72eea,
              axis: _0x3d4aef ? "vertical" : "horizontal",
              revert: _0x2ecdd3,
              dragRect: _0xc03c43,
              targetRect: _0x550506,
              canSort: _0x337120,
              fromSortable: _0x30f5ed,
              target: _0x530b6b,
              completed: _0x3dbe08,
              onMove: function (_0x357687, _0x1f0007) {
                return _0x4a0bf9(
                  _0x653a7c,
                  _0x2bf5bd,
                  _0x331fac,
                  _0xc03c43,
                  _0x357687,
                  _0x1250df(_0x357687),
                  _0x1bf0a5,
                  _0x1f0007,
                );
              },
              changed: _0x4c745b,
            },
            _0x50c3e0,
          ),
        );
      }
      function _0x4c5725() {
        (_0x478fdd("dragOverAnimationCapture"),
          _0x5080f2["captureAnimationState"](),
          _0x5080f2 !== _0x30f5ed && _0x30f5ed["captureAnimationState"]());
      }
      function _0x3dbe08(_0x53e33f) {
        return (
          _0x478fdd("dragOverCompleted", { insertion: _0x53e33f }),
          _0x53e33f &&
            (_0xc72eea
              ? _0x423694["_hideClone"]()
              : _0x423694["_showClone"](_0x5080f2),
            _0x5080f2 !== _0x30f5ed &&
              (_0x27586c(
                _0x331fac,
                (_0x3f5075 || _0x423694)["options"]["ghostClass"],
                !0x1,
              ),
              _0x27586c(_0x331fac, _0x3b0afb["ghostClass"], !0x0)),
            _0x3f5075 !== _0x5080f2 && _0x5080f2 !== _0x31214e["active"]
              ? (_0x3f5075 = _0x5080f2)
              : _0x5080f2 === _0x31214e["active"] &&
                _0x3f5075 &&
                (_0x3f5075 = null),
            _0x30f5ed === _0x5080f2 &&
              (_0x5080f2["_ignoreWhileAnimating"] = _0x530b6b),
            _0x5080f2["animateAll"](function () {
              (_0x478fdd("dragOverAnimationComplete"),
                (_0x5080f2["_ignoreWhileAnimating"] = null));
            }),
            _0x5080f2 !== _0x30f5ed &&
              (_0x30f5ed["animateAll"](),
              (_0x30f5ed["_ignoreWhileAnimating"] = null))),
          ((_0x530b6b === _0x331fac && !_0x331fac["animated"]) ||
            (_0x530b6b === _0x2bf5bd && !_0x530b6b["animated"])) &&
            (_0x266b49 = null),
          _0x3b0afb["dragoverBubble"] ||
            _0x1bf0a5["rootEl"] ||
            _0x530b6b === document ||
            (_0x331fac["parentNode"][_0x4459c5]["_isOutsideThisEl"](
              _0x1bf0a5["target"],
            ),
            _0x53e33f || _0x3ce231(_0x1bf0a5)),
          !_0x3b0afb["dragoverBubble"] &&
            _0x1bf0a5["stopPropagation"] &&
            _0x1bf0a5["stopPropagation"](),
          (_0x38eb2c = !0x0)
        );
      }
      function _0x4c745b() {
        ((_0x44bad5 = _0x493816(_0x331fac)),
          (_0x4befe3 = _0x493816(_0x331fac, _0x3b0afb["draggable"])),
          _0x28dcda({
            sortable: _0x5080f2,
            name: "change",
            toEl: _0x2bf5bd,
            newIndex: _0x44bad5,
            newDraggableIndex: _0x4befe3,
            originalEvent: _0x1bf0a5,
          }));
      }
    },
    _ignoreWhileAnimating: null,
    _offMoveEvents: function () {
      (_0x47ae28(document, "mousemove", this["_onTouchMove"]),
        _0x47ae28(document, "touchmove", this["_onTouchMove"]),
        _0x47ae28(document, "pointermove", this["_onTouchMove"]),
        _0x47ae28(document, "dragover", _0x3ce231),
        _0x47ae28(document, "mousemove", _0x3ce231),
        _0x47ae28(document, "touchmove", _0x3ce231));
    },
    _offUpEvents: function () {
      var _0x9f7522 = this["el"]["ownerDocument"];
      (_0x47ae28(_0x9f7522, "mouseup", this["_onDrop"]),
        _0x47ae28(_0x9f7522, "touchend", this["_onDrop"]),
        _0x47ae28(_0x9f7522, "pointerup", this["_onDrop"]),
        _0x47ae28(_0x9f7522, "touchcancel", this["_onDrop"]),
        _0x47ae28(document, "selectstart", this));
    },
    _onDrop: function (_0x486982) {
      var _0x5e8f8c = this["el"],
        _0xaf9531 = this["options"];
      ((_0x44bad5 = _0x493816(_0x331fac)),
        (_0x4befe3 = _0x493816(_0x331fac, _0xaf9531["draggable"])),
        _0x65a5d2("drop", this, { evt: _0x486982 }),
        (_0x55267f = _0x331fac && _0x331fac["parentNode"]),
        (_0x44bad5 = _0x493816(_0x331fac)),
        (_0x4befe3 = _0x493816(_0x331fac, _0xaf9531["draggable"])),
        _0x31214e["eventCanceled"] ||
          ((_0x19048b = _0x10c90c = _0xcf59fc = !0x1),
          clearInterval(this["_loopId"]),
          clearTimeout(this["_dragStartTimer"]),
          _0xc43f1b(this["cloneId"]),
          _0xc43f1b(this["_dragStartId"]),
          this["nativeDraggable"] &&
            (_0x47ae28(document, "drop", this),
            _0x47ae28(_0x5e8f8c, "dragstart", this["_onDragStart"])),
          this["_offMoveEvents"](),
          this["_offUpEvents"](),
          _0x3fd77c && _0x5df889(document["body"], "user-select", ""),
          _0x5df889(_0x331fac, "transform", ""),
          _0x486982 &&
            (_0xf7577 &&
              (_0x486982["cancelable"] && _0x486982["preventDefault"](),
              _0xaf9531["dropBubble"] || _0x486982["stopPropagation"]()),
            _0x1f0cdc &&
              _0x1f0cdc["parentNode"] &&
              _0x1f0cdc["parentNode"]["removeChild"](_0x1f0cdc),
            (_0x653a7c === _0x55267f ||
              (_0x3f5075 && "clone" !== _0x3f5075["lastPutMode"])) &&
              _0x525d7a &&
              _0x525d7a["parentNode"] &&
              _0x525d7a["parentNode"]["removeChild"](_0x525d7a),
            _0x331fac &&
              (this["nativeDraggable"] && _0x47ae28(_0x331fac, "dragend", this),
              _0x41757a(_0x331fac),
              (_0x331fac["style"]["will-change"] = ""),
              _0xf7577 &&
                !_0xcf59fc &&
                _0x27586c(
                  _0x331fac,
                  (_0x3f5075 || this)["options"]["ghostClass"],
                  !0x1,
                ),
              _0x27586c(_0x331fac, this["options"]["chosenClass"], !0x1),
              _0x28dcda({
                sortable: this,
                name: "unchoose",
                toEl: _0x55267f,
                newIndex: null,
                newDraggableIndex: null,
                originalEvent: _0x486982,
              }),
              _0x653a7c !== _0x55267f
                ? (0x0 <= _0x44bad5 &&
                    (_0x28dcda({
                      rootEl: _0x55267f,
                      name: "add",
                      toEl: _0x55267f,
                      fromEl: _0x653a7c,
                      originalEvent: _0x486982,
                    }),
                    _0x28dcda({
                      sortable: this,
                      name: "remove",
                      toEl: _0x55267f,
                      originalEvent: _0x486982,
                    }),
                    _0x28dcda({
                      rootEl: _0x55267f,
                      name: "sort",
                      toEl: _0x55267f,
                      fromEl: _0x653a7c,
                      originalEvent: _0x486982,
                    }),
                    _0x28dcda({
                      sortable: this,
                      name: "sort",
                      toEl: _0x55267f,
                      originalEvent: _0x486982,
                    })),
                  _0x3f5075 && _0x3f5075["save"]())
                : _0x44bad5 !== _0x43788e &&
                  0x0 <= _0x44bad5 &&
                  (_0x28dcda({
                    sortable: this,
                    name: "update",
                    toEl: _0x55267f,
                    originalEvent: _0x486982,
                  }),
                  _0x28dcda({
                    sortable: this,
                    name: "sort",
                    toEl: _0x55267f,
                    originalEvent: _0x486982,
                  })),
              _0x31214e["active"] &&
                ((null != _0x44bad5 && -0x1 !== _0x44bad5) ||
                  ((_0x44bad5 = _0x43788e), (_0x4befe3 = _0x1acdbc)),
                _0x28dcda({
                  sortable: this,
                  name: "end",
                  toEl: _0x55267f,
                  originalEvent: _0x486982,
                }),
                this["save"]())))),
        this["_nulling"]());
    },
    _nulling: function () {
      (_0x65a5d2("nulling", this),
        (_0x653a7c =
          _0x331fac =
          _0x55267f =
          _0x1f0cdc =
          _0x4af5bc =
          _0x525d7a =
          _0x5ba633 =
          _0x5687a1 =
          _0x2d3217 =
          _0x27fe72 =
          _0xf7577 =
          _0x44bad5 =
          _0x4befe3 =
          _0x43788e =
          _0x1acdbc =
          _0x266b49 =
          _0x2ade2c =
          _0x3f5075 =
          _0x4a091b =
          _0x31214e["dragged"] =
          _0x31214e["ghost"] =
          _0x31214e["clone"] =
          _0x31214e["active"] =
            null),
        _0x219a47["forEach"](function (_0x3e7976) {
          _0x3e7976["checked"] = !0x0;
        }),
        (_0x219a47["length"] = _0x48eb5b = _0x3eb5f3 = 0x0));
    },
    handleEvent: function (_0x59b785) {
      switch (_0x59b785["type"]) {
        case "drop":
        case "dragend":
          this["_onDrop"](_0x59b785);
          break;
        case "dragenter":
        case "dragover":
          _0x331fac &&
            (this["_onDragOver"](_0x59b785),
            (function (_0x5e585b) {
              (_0x5e585b["dataTransfer"] &&
                (_0x5e585b["dataTransfer"]["dropEffect"] = "move"),
                _0x5e585b["cancelable"] && _0x5e585b["preventDefault"]());
            })(_0x59b785));
          break;
        case "selectstart":
          _0x59b785["preventDefault"]();
      }
    },
    toArray: function () {
      for (
        var _0x1bc80d,
          _0x2fa38f = [],
          _0x4816c1 = this["el"]["children"],
          _0x5a1f42 = 0x0,
          _0x149230 = _0x4816c1["length"],
          _0x291801 = this["options"];
        _0x5a1f42 < _0x149230;
        _0x5a1f42++
      )
        _0x1b7759(
          (_0x1bc80d = _0x4816c1[_0x5a1f42]),
          _0x291801["draggable"],
          this["el"],
          !0x1,
        ) &&
          _0x2fa38f["push"](
            _0x1bc80d["getAttribute"](_0x291801["dataIdAttr"]) ||
              (function (_0x556638) {
                var _0x2f640f =
                    _0x556638["tagName"] +
                    _0x556638["className"] +
                    _0x556638["src"] +
                    _0x556638["href"] +
                    _0x556638["textContent"],
                  _0x776476 = _0x2f640f["length"],
                  _0x1a3c3d = 0x0;
                for (; _0x776476--; )
                  _0x1a3c3d += _0x2f640f["charCodeAt"](_0x776476);
                return _0x1a3c3d["toString"](0x24);
              })(_0x1bc80d),
          );
      return _0x2fa38f;
    },
    sort: function (_0x15e8c3, _0x1743a3) {
      var _0x4e58c0 = {},
        _0x1e481d = this["el"];
      (this["toArray"]()["forEach"](function (_0x7a87ed, _0x427afa) {
        _0x1b7759(
          (_0x427afa = _0x1e481d["children"][_0x427afa]),
          this["options"]["draggable"],
          _0x1e481d,
          !0x1,
        ) && (_0x4e58c0[_0x7a87ed] = _0x427afa);
      }, this),
        _0x1743a3 && this["captureAnimationState"](),
        _0x15e8c3["forEach"](function (_0xc3ea93) {
          _0x4e58c0[_0xc3ea93] &&
            (_0x1e481d["removeChild"](_0x4e58c0[_0xc3ea93]),
            _0x1e481d["appendChild"](_0x4e58c0[_0xc3ea93]));
        }),
        _0x1743a3 && this["animateAll"]());
    },
    save: function () {
      var _0x5d811c = this["options"]["store"];
      _0x5d811c && _0x5d811c["set"] && _0x5d811c["set"](this);
    },
    closest: function (_0x11fc49, _0xc4df17) {
      return _0x1b7759(
        _0x11fc49,
        _0xc4df17 || this["options"]["draggable"],
        this["el"],
        !0x1,
      );
    },
    option: function (_0x538260, _0x1db44e) {
      var _0x21cb24 = this["options"];
      if (void 0x0 === _0x1db44e) return _0x21cb24[_0x538260];
      var _0x347dc6 = _0x504264["modifyOption"](this, _0x538260, _0x1db44e);
      ((_0x21cb24[_0x538260] = void 0x0 !== _0x347dc6 ? _0x347dc6 : _0x1db44e),
        "group" === _0x538260 && _0x14ab7c(_0x21cb24));
    },
    destroy: function () {
      _0x65a5d2("destroy", this);
      var _0x300b06 = this["el"];
      ((_0x300b06[_0x4459c5] = null),
        _0x47ae28(_0x300b06, "mousedown", this["_onTapStart"]),
        _0x47ae28(_0x300b06, "touchstart", this["_onTapStart"]),
        _0x47ae28(_0x300b06, "pointerdown", this["_onTapStart"]),
        this["nativeDraggable"] &&
          (_0x47ae28(_0x300b06, "dragover", this),
          _0x47ae28(_0x300b06, "dragenter", this)),
        Array["prototype"]["forEach"]["call"](
          _0x300b06["querySelectorAll"]("[draggable]"),
          function (_0x456fc7) {
            _0x456fc7["removeAttribute"]("draggable");
          },
        ),
        this["_onDrop"](),
        this["_disableDelayedDragEvents"](),
        _0x40570c["splice"](_0x40570c["indexOf"](this["el"]), 0x1),
        (this["el"] = _0x300b06 = null));
    },
    _hideClone: function () {
      _0x5687a1 ||
        (_0x65a5d2("hideClone", this),
        _0x31214e["eventCanceled"] ||
          (_0x5df889(_0x525d7a, "display", "none"),
          this["options"]["removeCloneOnHide"] &&
            _0x525d7a["parentNode"] &&
            _0x525d7a["parentNode"]["removeChild"](_0x525d7a),
          (_0x5687a1 = !0x0)));
    },
    _showClone: function (_0x3b015f) {
      "clone" === _0x3b015f["lastPutMode"]
        ? _0x5687a1 &&
          (_0x65a5d2("showClone", this),
          _0x31214e["eventCanceled"] ||
            (_0x331fac["parentNode"] != _0x653a7c ||
            this["options"]["group"]["revertClone"]
              ? _0x4af5bc
                ? _0x653a7c["insertBefore"](_0x525d7a, _0x4af5bc)
                : _0x653a7c["appendChild"](_0x525d7a)
              : _0x653a7c["insertBefore"](_0x525d7a, _0x331fac),
            this["options"]["group"]["revertClone"] &&
              this["animate"](_0x331fac, _0x525d7a),
            _0x5df889(_0x525d7a, "display", ""),
            (_0x5687a1 = !0x1)))
        : this["_hideClone"]();
    },
  }),
    _0x561a5b &&
      _0x15866f(document, "touchmove", function (_0x5bb7e0) {
        (_0x31214e["active"] || _0xcf59fc) &&
          _0x5bb7e0["cancelable"] &&
          _0x5bb7e0["preventDefault"]();
      }),
    (_0x31214e["utils"] = {
      on: _0x15866f,
      off: _0x47ae28,
      css: _0x5df889,
      find: _0x90411,
      is: function (_0x173ae4, _0xd5054c) {
        return !!_0x1b7759(_0x173ae4, _0xd5054c, _0x173ae4, !0x1);
      },
      extend: function (_0x25f42d, _0x419732) {
        if (_0x25f42d && _0x419732) {
          for (var _0x1af70a in _0x419732)
            _0x419732["hasOwnProperty"](_0x1af70a) &&
              (_0x25f42d[_0x1af70a] = _0x419732[_0x1af70a]);
        }
        return _0x25f42d;
      },
      throttle: _0x5cd183,
      closest: _0x1b7759,
      toggleClass: _0x27586c,
      clone: _0x43ea8e,
      index: _0x493816,
      nextTick: _0x1c8ab5,
      cancelNextTick: _0xc43f1b,
      detectDirection: _0x75018d,
      getChild: _0x193fa3,
    }),
    (_0x31214e["get"] = function (_0x20cd57) {
      return _0x20cd57[_0x4459c5];
    }),
    (_0x31214e["mount"] = function () {
      for (
        var _0x59a3d9 = arguments["length"],
          _0x38e676 = new Array(_0x59a3d9),
          _0x3dece7 = 0x0;
        _0x3dece7 < _0x59a3d9;
        _0x3dece7++
      )
        _0x38e676[_0x3dece7] = arguments[_0x3dece7];
      (_0x38e676 =
        _0x38e676[0x0]["constructor"] === Array ? _0x38e676[0x0] : _0x38e676)[
        "forEach"
      ](function (_0x40bee5) {
        if (!_0x40bee5["prototype"] || !_0x40bee5["prototype"]["constructor"])
          throw "Sortable:\x20Mounted\x20plugin\x20must\x20be\x20a\x20constructor\x20function,\x20not\x20"[
            "concat"
          ]({}["toString"]["call"](_0x40bee5));
        (_0x40bee5["utils"] &&
          (_0x31214e["utils"] = _0x2c4f52(
            _0x2c4f52({}, _0x31214e["utils"]),
            _0x40bee5["utils"],
          )),
          _0x504264["mount"](_0x40bee5));
      });
    }),
    (_0x31214e["create"] = function (_0x3f1ad5, _0x12c1f1) {
      return new _0x31214e(_0x3f1ad5, _0x12c1f1);
    }));
  var _0x306473,
    _0x2bc688,
    _0x253c72,
    _0x4ff6e4,
    _0x570719,
    _0x46ba40,
    _0xc1b0c7 = [],
    _0x47db8d = !(_0x31214e["version"] = "1.14.0");
  function _0xbbd2de() {
    (_0xc1b0c7["forEach"](function (_0x1757db) {
      clearInterval(_0x1757db["pid"]);
    }),
      (_0xc1b0c7 = []));
  }
  function _0x40bb43() {
    clearInterval(_0x46ba40);
  }
  var _0x15e38f,
    _0x131634 = _0x5cd183(function (
      _0x3ed0e8,
      _0x369353,
      _0x2dfd43,
      _0x5fe5f5,
    ) {
      if (_0x369353["scroll"]) {
        var _0x42eabd,
          _0x1d7f59 = (
            _0x3ed0e8["touches"] ? _0x3ed0e8["touches"][0x0] : _0x3ed0e8
          )["clientX"],
          _0x7e03ed = (
            _0x3ed0e8["touches"] ? _0x3ed0e8["touches"][0x0] : _0x3ed0e8
          )["clientY"],
          _0x364eab = _0x369353["scrollSensitivity"],
          _0x59e0cb = _0x369353["scrollSpeed"],
          _0x55ec6a = _0x2f148a(),
          _0x39baf5 = !0x1;
        _0x2bc688 !== _0x2dfd43 &&
          ((_0x2bc688 = _0x2dfd43),
          _0xbbd2de(),
          (_0x306473 = _0x369353["scroll"]),
          (_0x42eabd = _0x369353["scrollFn"]),
          !0x0 === _0x306473 && (_0x306473 = _0x1fb3c0(_0x2dfd43, !0x0)));
        var _0x3f3f24 = 0x0,
          _0x3b3f46 = _0x306473;
        do {
          var _0x5fd04e = _0x3b3f46,
            _0x470ab4 = (_0x173389 = _0x1250df(_0x5fd04e))["top"],
            _0x533588 = _0x173389["bottom"],
            _0x3254e0 = _0x173389["left"],
            _0x1b6e24 = _0x173389["right"],
            _0x23a014 = _0x173389["width"],
            _0x3a8b8e = _0x173389["height"],
            _0x37c420 = void 0x0,
            _0x18b685 = _0x5fd04e["scrollWidth"],
            _0x447953 = _0x5fd04e["scrollHeight"],
            _0x23b98c = _0x5df889(_0x5fd04e),
            _0x8944d0 = _0x5fd04e["scrollLeft"],
            _0x173389 = _0x5fd04e["scrollTop"],
            _0x3706e8 =
              _0x5fd04e === _0x55ec6a
                ? ((_0x37c420 =
                    _0x23a014 < _0x18b685 &&
                    ("auto" === _0x23b98c["overflowX"] ||
                      "scroll" === _0x23b98c["overflowX"] ||
                      "visible" === _0x23b98c["overflowX"])),
                  _0x3a8b8e < _0x447953 &&
                    ("auto" === _0x23b98c["overflowY"] ||
                      "scroll" === _0x23b98c["overflowY"] ||
                      "visible" === _0x23b98c["overflowY"]))
                : ((_0x37c420 =
                    _0x23a014 < _0x18b685 &&
                    ("auto" === _0x23b98c["overflowX"] ||
                      "scroll" === _0x23b98c["overflowX"])),
                  _0x3a8b8e < _0x447953 &&
                    ("auto" === _0x23b98c["overflowY"] ||
                      "scroll" === _0x23b98c["overflowY"]));
          ((_0x8944d0 =
            _0x37c420 &&
            (Math["abs"](_0x1b6e24 - _0x1d7f59) <= _0x364eab &&
              _0x8944d0 + _0x23a014 < _0x18b685) -
              (Math["abs"](_0x3254e0 - _0x1d7f59) <= _0x364eab && !!_0x8944d0)),
            (_0x173389 =
              _0x3706e8 &&
              (Math["abs"](_0x533588 - _0x7e03ed) <= _0x364eab &&
                _0x173389 + _0x3a8b8e < _0x447953) -
                (Math["abs"](_0x470ab4 - _0x7e03ed) <= _0x364eab &&
                  !!_0x173389)));
          if (!_0xc1b0c7[_0x3f3f24]) {
            for (var _0x38b54e = 0x0; _0x38b54e <= _0x3f3f24; _0x38b54e++)
              _0xc1b0c7[_0x38b54e] || (_0xc1b0c7[_0x38b54e] = {});
          }
          ((_0xc1b0c7[_0x3f3f24]["vx"] == _0x8944d0 &&
            _0xc1b0c7[_0x3f3f24]["vy"] == _0x173389 &&
            _0xc1b0c7[_0x3f3f24]["el"] === _0x5fd04e) ||
            ((_0xc1b0c7[_0x3f3f24]["el"] = _0x5fd04e),
            (_0xc1b0c7[_0x3f3f24]["vx"] = _0x8944d0),
            (_0xc1b0c7[_0x3f3f24]["vy"] = _0x173389),
            clearInterval(_0xc1b0c7[_0x3f3f24]["pid"]),
            (0x0 == _0x8944d0 && 0x0 == _0x173389) ||
              ((_0x39baf5 = !0x0),
              (_0xc1b0c7[_0x3f3f24]["pid"] = setInterval(
                function () {
                  _0x5fe5f5 &&
                    0x0 === this["layer"] &&
                    _0x31214e["active"]["_onTouchMove"](_0x570719);
                  var _0x5d7eb4 = _0xc1b0c7[this["layer"]]["vy"]
                      ? _0xc1b0c7[this["layer"]]["vy"] * _0x59e0cb
                      : 0x0,
                    _0x17eed4 = _0xc1b0c7[this["layer"]]["vx"]
                      ? _0xc1b0c7[this["layer"]]["vx"] * _0x59e0cb
                      : 0x0;
                  ("function" == typeof _0x42eabd &&
                    "continue" !==
                      _0x42eabd["call"](
                        _0x31214e["dragged"]["parentNode"][_0x4459c5],
                        _0x17eed4,
                        _0x5d7eb4,
                        _0x3ed0e8,
                        _0x570719,
                        _0xc1b0c7[this["layer"]]["el"],
                      )) ||
                    _0x536a9b(
                      _0xc1b0c7[this["layer"]]["el"],
                      _0x17eed4,
                      _0x5d7eb4,
                    );
                }["bind"]({ layer: _0x3f3f24 }),
                0x18,
              )))),
            _0x3f3f24++);
        } while (
          _0x369353["bubbleScroll"] &&
          _0x3b3f46 !== _0x55ec6a &&
          (_0x3b3f46 = _0x1fb3c0(_0x3b3f46, !0x1))
        );
        _0x47db8d = _0x39baf5;
      }
    }, 0x1e);
  _0x2808c4 = function (_0x1346bc) {
    var _0x16b09c = _0x1346bc["originalEvent"],
      _0x23d7bb = _0x1346bc["putSortable"],
      _0x2b4616 = _0x1346bc["dragEl"],
      _0x1730fa = _0x1346bc["activeSortable"],
      _0x3f09d1 = _0x1346bc["dispatchSortableEvent"],
      _0x2e3e70 = _0x1346bc["hideGhostForTarget"];
    ((_0x1346bc = _0x1346bc["unhideGhostForTarget"]),
      _0x16b09c &&
        ((_0x1730fa = _0x23d7bb || _0x1730fa),
        _0x2e3e70(),
        (_0x16b09c =
          _0x16b09c["changedTouches"] && _0x16b09c["changedTouches"]["length"]
            ? _0x16b09c["changedTouches"][0x0]
            : _0x16b09c),
        (_0x16b09c = document["elementFromPoint"](
          _0x16b09c["clientX"],
          _0x16b09c["clientY"],
        )),
        _0x1346bc(),
        _0x1730fa &&
          !_0x1730fa["el"]["contains"](_0x16b09c) &&
          (_0x3f09d1("spill"),
          this["onSpill"]({ dragEl: _0x2b4616, putSortable: _0x23d7bb }))));
  };
  function _0x49a6da() {}
  function _0x37fe76() {}
  ((_0x49a6da["prototype"] = {
    startIndex: null,
    dragStart: function (_0x4d3494) {
      ((_0x4d3494 = _0x4d3494["oldDraggableIndex"]),
        (this["startIndex"] = _0x4d3494));
    },
    onSpill: function (_0x1217e0) {
      var _0x389b5b = _0x1217e0["dragEl"],
        _0x3b0cc1 = _0x1217e0["putSortable"];
      (this["sortable"]["captureAnimationState"](),
        _0x3b0cc1 && _0x3b0cc1["captureAnimationState"](),
        ((_0x1217e0 = _0x193fa3(
          this["sortable"]["el"],
          this["startIndex"],
          this["options"],
        ))
          ? this["sortable"]["el"]["insertBefore"](_0x389b5b, _0x1217e0)
          : this["sortable"]["el"]["appendChild"](_0x389b5b),
        this["sortable"]["animateAll"](),
        _0x3b0cc1 && _0x3b0cc1["animateAll"]()));
    },
    drop: _0x2808c4,
  }),
    _0x355909(_0x49a6da, { pluginName: "revertOnSpill" }),
    (_0x37fe76["prototype"] = {
      onSpill: function (_0xaa0d1b) {
        var _0x2788f3 = _0xaa0d1b["dragEl"];
        ((_0xaa0d1b = _0xaa0d1b["putSortable"] || this["sortable"])[
          "captureAnimationState"
        ](),
          _0x2788f3["parentNode"] &&
            _0x2788f3["parentNode"]["removeChild"](_0x2788f3),
          _0xaa0d1b["animateAll"]());
      },
      drop: _0x2808c4,
    }),
    _0x355909(_0x37fe76, { pluginName: "removeOnSpill" }));
  var _0x57063a,
    _0x3ab43a,
    _0xb7cbb4,
    _0x471a31,
    _0x356e0f,
    _0x92c99d = [],
    _0x1d4938 = [],
    _0x2d1a4a = !0x1,
    _0x684fc4 = !0x1,
    _0xdfe489 = !0x1;
  function _0xd4366f(_0xd777b4, _0x37adb7) {
    _0x1d4938["forEach"](function (_0x1bb11f, _0x283144) {
      (_0x283144 =
        _0x37adb7["children"][
          _0x1bb11f["sortableIndex"] + (_0xd777b4 ? Number(_0x283144) : 0x0)
        ])
        ? _0x37adb7["insertBefore"](_0x1bb11f, _0x283144)
        : _0x37adb7["appendChild"](_0x1bb11f);
    });
  }
  function _0x380b85() {
    _0x92c99d["forEach"](function (_0xeac22e) {
      _0xeac22e !== _0xb7cbb4 &&
        _0xeac22e["parentNode"] &&
        _0xeac22e["parentNode"]["removeChild"](_0xeac22e);
    });
  }
  return (
    _0x31214e["mount"](
      new (function () {
        function _0x4bb13c() {
          for (var _0x35425a in ((this["defaults"] = {
            scroll: !0x0,
            forceAutoScrollFallback: !0x1,
            scrollSensitivity: 0x1e,
            scrollSpeed: 0xa,
            bubbleScroll: !0x0,
          }),
          this))
            "_" === _0x35425a["charAt"](0x0) &&
              "function" == typeof this[_0x35425a] &&
              (this[_0x35425a] = this[_0x35425a]["bind"](this));
        }
        return (
          (_0x4bb13c["prototype"] = {
            dragStarted: function (_0x186fbd) {
              ((_0x186fbd = _0x186fbd["originalEvent"]),
                this["sortable"]["nativeDraggable"]
                  ? _0x15866f(document, "dragover", this["_handleAutoScroll"])
                  : this["options"]["supportPointer"]
                    ? _0x15866f(
                        document,
                        "pointermove",
                        this["_handleFallbackAutoScroll"],
                      )
                    : _0x186fbd["touches"]
                      ? _0x15866f(
                          document,
                          "touchmove",
                          this["_handleFallbackAutoScroll"],
                        )
                      : _0x15866f(
                          document,
                          "mousemove",
                          this["_handleFallbackAutoScroll"],
                        ));
            },
            dragOverCompleted: function (_0x3f794c) {
              ((_0x3f794c = _0x3f794c["originalEvent"]),
                this["options"]["dragOverBubble"] ||
                  _0x3f794c["rootEl"] ||
                  this["_handleAutoScroll"](_0x3f794c));
            },
            drop: function () {
              (this["sortable"]["nativeDraggable"]
                ? _0x47ae28(document, "dragover", this["_handleAutoScroll"])
                : (_0x47ae28(
                    document,
                    "pointermove",
                    this["_handleFallbackAutoScroll"],
                  ),
                  _0x47ae28(
                    document,
                    "touchmove",
                    this["_handleFallbackAutoScroll"],
                  ),
                  _0x47ae28(
                    document,
                    "mousemove",
                    this["_handleFallbackAutoScroll"],
                  )),
                _0x40bb43(),
                _0xbbd2de(),
                clearTimeout(_0x5230c4),
                (_0x5230c4 = void 0x0));
            },
            nulling: function () {
              ((_0x570719 =
                _0x2bc688 =
                _0x306473 =
                _0x47db8d =
                _0x46ba40 =
                _0x253c72 =
                _0x4ff6e4 =
                  null),
                (_0xc1b0c7["length"] = 0x0));
            },
            _handleFallbackAutoScroll: function (_0x272220) {
              this["_handleAutoScroll"](_0x272220, !0x0);
            },
            _handleAutoScroll: function (_0x5ca9aa, _0x3cf523) {
              var _0x107c7e,
                _0x4af486 = this,
                _0x5b117e = (
                  _0x5ca9aa["touches"] ? _0x5ca9aa["touches"][0x0] : _0x5ca9aa
                )["clientX"],
                _0x4d55d7 = (
                  _0x5ca9aa["touches"] ? _0x5ca9aa["touches"][0x0] : _0x5ca9aa
                )["clientY"],
                _0x376a5e = document["elementFromPoint"](_0x5b117e, _0x4d55d7);
              ((_0x570719 = _0x5ca9aa),
                _0x3cf523 ||
                this["options"]["forceAutoScrollFallback"] ||
                _0x4523c3 ||
                _0x241510 ||
                _0x3fd77c
                  ? (_0x131634(
                      _0x5ca9aa,
                      this["options"],
                      _0x376a5e,
                      _0x3cf523,
                    ),
                    (_0x107c7e = _0x1fb3c0(_0x376a5e, !0x0)),
                    !_0x47db8d ||
                      (_0x46ba40 &&
                        _0x5b117e === _0x253c72 &&
                        _0x4d55d7 === _0x4ff6e4) ||
                      (_0x46ba40 && _0x40bb43(),
                      (_0x46ba40 = setInterval(function () {
                        var _0x407cd0 = _0x1fb3c0(
                          document["elementFromPoint"](_0x5b117e, _0x4d55d7),
                          !0x0,
                        );
                        (_0x407cd0 !== _0x107c7e &&
                          ((_0x107c7e = _0x407cd0), _0xbbd2de()),
                          _0x131634(
                            _0x5ca9aa,
                            _0x4af486["options"],
                            _0x407cd0,
                            _0x3cf523,
                          ));
                      }, 0xa)),
                      (_0x253c72 = _0x5b117e),
                      (_0x4ff6e4 = _0x4d55d7)))
                  : this["options"]["bubbleScroll"] &&
                      _0x1fb3c0(_0x376a5e, !0x0) !== _0x2f148a()
                    ? _0x131634(
                        _0x5ca9aa,
                        this["options"],
                        _0x1fb3c0(_0x376a5e, !0x1),
                        !0x1,
                      )
                    : _0xbbd2de());
            },
          }),
          _0x355909(_0x4bb13c, {
            pluginName: "scroll",
            initializeByDefault: !0x0,
          })
        );
      })(),
    ),
    _0x31214e["mount"](_0x37fe76, _0x49a6da),
    _0x31214e["mount"](
      new (function () {
        function _0x33a70d() {
          this["defaults"] = { swapClass: "sortable-swap-highlight" };
        }
        return (
          (_0x33a70d["prototype"] = {
            dragStart: function (_0x211554) {
              ((_0x211554 = _0x211554["dragEl"]), (_0x15e38f = _0x211554));
            },
            dragOverValid: function (_0x55b663) {
              var _0xb768e5 = _0x55b663["completed"],
                _0x4ebcc8 = _0x55b663["target"],
                _0x42044a = _0x55b663["onMove"],
                _0x119ce4 = _0x55b663["activeSortable"],
                _0x1eb9df = _0x55b663["changed"],
                _0x1bb02d = _0x55b663["cancel"];
              _0x119ce4["options"]["swap"] &&
                ((_0x55b663 = this["sortable"]["el"]),
                (_0x119ce4 = this["options"]),
                _0x4ebcc8 &&
                  _0x4ebcc8 !== _0x55b663 &&
                  ((_0x55b663 = _0x15e38f),
                  (_0x15e38f =
                    !0x1 !== _0x42044a(_0x4ebcc8)
                      ? (_0x27586c(_0x4ebcc8, _0x119ce4["swapClass"], !0x0),
                        _0x4ebcc8)
                      : null),
                  _0x55b663 &&
                    _0x55b663 !== _0x15e38f &&
                    _0x27586c(_0x55b663, _0x119ce4["swapClass"], !0x1)),
                _0x1eb9df(),
                _0xb768e5(!0x0),
                _0x1bb02d());
            },
            drop: function (_0x59fb89) {
              var _0x49eb16,
                _0x4db7a4,
                _0x4964df = _0x59fb89["activeSortable"],
                _0x157c03 = _0x59fb89["putSortable"],
                _0x1e8b0c = _0x59fb89["dragEl"],
                _0x119bdd = _0x157c03 || this["sortable"],
                _0x518ebf = this["options"];
              (_0x15e38f && _0x27586c(_0x15e38f, _0x518ebf["swapClass"], !0x1),
                _0x15e38f &&
                  (_0x518ebf["swap"] ||
                    (_0x157c03 && _0x157c03["options"]["swap"])) &&
                  _0x1e8b0c !== _0x15e38f &&
                  (_0x119bdd["captureAnimationState"](),
                  _0x119bdd !== _0x4964df &&
                    _0x4964df["captureAnimationState"](),
                  (_0x4db7a4 = _0x15e38f),
                  (_0x59fb89 = (_0x49eb16 = _0x1e8b0c)["parentNode"]),
                  (_0x518ebf = _0x4db7a4["parentNode"]),
                  _0x59fb89 &&
                    _0x518ebf &&
                    !_0x59fb89["isEqualNode"](_0x4db7a4) &&
                    !_0x518ebf["isEqualNode"](_0x49eb16) &&
                    ((_0x157c03 = _0x493816(_0x49eb16)),
                    (_0x1e8b0c = _0x493816(_0x4db7a4)),
                    _0x59fb89["isEqualNode"](_0x518ebf) &&
                      _0x157c03 < _0x1e8b0c &&
                      _0x1e8b0c++,
                    _0x59fb89["insertBefore"](
                      _0x4db7a4,
                      _0x59fb89["children"][_0x157c03],
                    ),
                    _0x518ebf["insertBefore"](
                      _0x49eb16,
                      _0x518ebf["children"][_0x1e8b0c],
                    )),
                  _0x119bdd["animateAll"](),
                  _0x119bdd !== _0x4964df && _0x4964df["animateAll"]()));
            },
            nulling: function () {
              _0x15e38f = null;
            },
          }),
          _0x355909(_0x33a70d, {
            pluginName: "swap",
            eventProperties: function () {
              return { swapItem: _0x15e38f };
            },
          })
        );
      })(),
    ),
    _0x31214e["mount"](
      new (function () {
        function _0xdb8caa(_0x20a753) {
          for (var _0x5c2dd6 in this)
            "_" === _0x5c2dd6["charAt"](0x0) &&
              "function" == typeof this[_0x5c2dd6] &&
              (this[_0x5c2dd6] = this[_0x5c2dd6]["bind"](this));
          (_0x20a753["options"]["supportPointer"]
            ? _0x15866f(document, "pointerup", this["_deselectMultiDrag"])
            : (_0x15866f(document, "mouseup", this["_deselectMultiDrag"]),
              _0x15866f(document, "touchend", this["_deselectMultiDrag"])),
            _0x15866f(document, "keydown", this["_checkKeyDown"]),
            _0x15866f(document, "keyup", this["_checkKeyUp"]),
            (this["defaults"] = {
              selectedClass: "sortable-selected",
              multiDragKey: null,
              setData: function (_0xc32261, _0xec030d) {
                var _0x1f2843 = "";
                (_0x92c99d["length"] && _0x3ab43a === _0x20a753
                  ? _0x92c99d["forEach"](function (_0x36e602, _0x8bf2bc) {
                      _0x1f2843 +=
                        (_0x8bf2bc ? ",\x20" : "") + _0x36e602["textContent"];
                    })
                  : (_0x1f2843 = _0xec030d["textContent"]),
                  _0xc32261["setData"]("Text", _0x1f2843));
              },
            }));
        }
        return (
          (_0xdb8caa["prototype"] = {
            multiDragKeyDown: !0x1,
            isMultiDrag: !0x1,
            delayStartGlobal: function (_0x29ab91) {
              ((_0x29ab91 = _0x29ab91["dragEl"]), (_0xb7cbb4 = _0x29ab91));
            },
            delayEnded: function () {
              this["isMultiDrag"] = ~_0x92c99d["indexOf"](_0xb7cbb4);
            },
            setupClone: function (_0x3ee998) {
              var _0x5800f2 = _0x3ee998["sortable"];
              _0x3ee998 = _0x3ee998["cancel"];
              if (this["isMultiDrag"]) {
                for (
                  var _0x19d968 = 0x0;
                  _0x19d968 < _0x92c99d["length"];
                  _0x19d968++
                )
                  (_0x1d4938["push"](_0x43ea8e(_0x92c99d[_0x19d968])),
                    (_0x1d4938[_0x19d968]["sortableIndex"] =
                      _0x92c99d[_0x19d968]["sortableIndex"]),
                    (_0x1d4938[_0x19d968]["draggable"] = !0x1),
                    (_0x1d4938[_0x19d968]["style"]["will-change"] = ""),
                    _0x27586c(
                      _0x1d4938[_0x19d968],
                      this["options"]["selectedClass"],
                      !0x1,
                    ),
                    _0x92c99d[_0x19d968] === _0xb7cbb4 &&
                      _0x27586c(
                        _0x1d4938[_0x19d968],
                        this["options"]["chosenClass"],
                        !0x1,
                      ));
                (_0x5800f2["_hideClone"](), _0x3ee998());
              }
            },
            clone: function (_0xe97587) {
              var _0x2d9720 = _0xe97587["sortable"],
                _0x82bd85 = _0xe97587["rootEl"],
                _0x4a2dcb = _0xe97587["dispatchSortableEvent"];
              ((_0xe97587 = _0xe97587["cancel"]),
                this["isMultiDrag"] &&
                  (this["options"]["removeCloneOnHide"] ||
                    (_0x92c99d["length"] &&
                      _0x3ab43a === _0x2d9720 &&
                      (_0xd4366f(!0x0, _0x82bd85),
                      _0x4a2dcb("clone"),
                      _0xe97587()))));
            },
            showClone: function (_0x5a6c05) {
              var _0x33b1d2 = _0x5a6c05["cloneNowShown"],
                _0x408abc = _0x5a6c05["rootEl"];
              ((_0x5a6c05 = _0x5a6c05["cancel"]),
                this["isMultiDrag"] &&
                  (_0xd4366f(!0x1, _0x408abc),
                  _0x1d4938["forEach"](function (_0x416cd8) {
                    _0x5df889(_0x416cd8, "display", "");
                  }),
                  _0x33b1d2(),
                  (_0x356e0f = !0x1),
                  _0x5a6c05()));
            },
            hideClone: function (_0x14432e) {
              var _0x3472b8 = this,
                _0x6b6bc4 =
                  (_0x14432e["sortable"], _0x14432e["cloneNowHidden"]);
              ((_0x14432e = _0x14432e["cancel"]),
                this["isMultiDrag"] &&
                  (_0x1d4938["forEach"](function (_0x395ed9) {
                    (_0x5df889(_0x395ed9, "display", "none"),
                      _0x3472b8["options"]["removeCloneOnHide"] &&
                        _0x395ed9["parentNode"] &&
                        _0x395ed9["parentNode"]["removeChild"](_0x395ed9));
                  }),
                  _0x6b6bc4(),
                  (_0x356e0f = !0x0),
                  _0x14432e()));
            },
            dragStartGlobal: function (_0xbcfe09) {
              (_0xbcfe09["sortable"],
                (!this["isMultiDrag"] &&
                  _0x3ab43a &&
                  _0x3ab43a["multiDrag"]["_deselectMultiDrag"](),
                _0x92c99d["forEach"](function (_0x5e9ade) {
                  _0x5e9ade["sortableIndex"] = _0x493816(_0x5e9ade);
                }),
                (_0x92c99d = _0x92c99d["sort"](function (_0x20eba5, _0x1ed667) {
                  return (
                    _0x20eba5["sortableIndex"] - _0x1ed667["sortableIndex"]
                  );
                })),
                (_0xdfe489 = !0x0)));
            },
            dragStarted: function (_0x70b927) {
              var _0x28235e,
                _0x4dca49 = this;
              ((_0x70b927 = _0x70b927["sortable"]),
                this["isMultiDrag"] &&
                  (this["options"]["sort"] &&
                    (_0x70b927["captureAnimationState"](),
                    this["options"]["animation"] &&
                      (_0x92c99d["forEach"](function (_0x3542d0) {
                        _0x3542d0 !== _0xb7cbb4 &&
                          _0x5df889(_0x3542d0, "position", "absolute");
                      }),
                      (_0x28235e = _0x1250df(_0xb7cbb4, !0x1, !0x0, !0x0)),
                      _0x92c99d["forEach"](function (_0xab9d02) {
                        _0xab9d02 !== _0xb7cbb4 &&
                          _0x398747(_0xab9d02, _0x28235e);
                      }),
                      (_0x2d1a4a = _0x684fc4 = !0x0))),
                  _0x70b927["animateAll"](function () {
                    ((_0x2d1a4a = _0x684fc4 = !0x1),
                      _0x4dca49["options"]["animation"] &&
                        _0x92c99d["forEach"](function (_0x5999c3) {
                          _0x42e02d(_0x5999c3);
                        }),
                      _0x4dca49["options"]["sort"] && _0x380b85());
                  })));
            },
            dragOver: function (_0x255eb6) {
              var _0x2ea4f8 = _0x255eb6["target"],
                _0x5d5dac = _0x255eb6["completed"];
              ((_0x255eb6 = _0x255eb6["cancel"]),
                _0x684fc4 &&
                  ~_0x92c99d["indexOf"](_0x2ea4f8) &&
                  (_0x5d5dac(!0x1), _0x255eb6()));
            },
            revert: function (_0x21780d) {
              var _0x2fe5e2,
                _0x43eabe,
                _0x1ba511 = _0x21780d["fromSortable"],
                _0x37b0f7 = _0x21780d["rootEl"],
                _0x5a0a68 = _0x21780d["sortable"],
                _0x3897b1 = _0x21780d["dragRect"];
              0x1 < _0x92c99d["length"] &&
                (_0x92c99d["forEach"](function (_0x5dff76) {
                  (_0x5a0a68["addAnimationState"]({
                    target: _0x5dff76,
                    rect: _0x684fc4 ? _0x1250df(_0x5dff76) : _0x3897b1,
                  }),
                    _0x42e02d(_0x5dff76),
                    (_0x5dff76["fromRect"] = _0x3897b1),
                    _0x1ba511["removeAnimationState"](_0x5dff76));
                }),
                (_0x684fc4 = !0x1),
                (_0x2fe5e2 = !this["options"]["removeCloneOnHide"]),
                (_0x43eabe = _0x37b0f7),
                _0x92c99d["forEach"](function (_0x694e40, _0x1c5f15) {
                  (_0x1c5f15 =
                    _0x43eabe["children"][
                      _0x694e40["sortableIndex"] +
                        (_0x2fe5e2 ? Number(_0x1c5f15) : 0x0)
                    ])
                    ? _0x43eabe["insertBefore"](_0x694e40, _0x1c5f15)
                    : _0x43eabe["appendChild"](_0x694e40);
                }));
            },
            dragOverCompleted: function (_0x58ad0f) {
              var _0x380000,
                _0x1ff911 = _0x58ad0f["sortable"],
                _0x16859d = _0x58ad0f["isOwner"],
                _0xdad3d3 = _0x58ad0f["insertion"],
                _0x4451e3 = _0x58ad0f["activeSortable"],
                _0x2974a9 = _0x58ad0f["parentEl"],
                _0x46270e = _0x58ad0f["putSortable"];
              ((_0x58ad0f = this["options"]),
                _0xdad3d3 &&
                  (_0x16859d && _0x4451e3["_hideClone"](),
                  (_0x2d1a4a = !0x1),
                  _0x58ad0f["animation"] &&
                    0x1 < _0x92c99d["length"] &&
                    (_0x684fc4 ||
                      (!_0x16859d &&
                        !_0x4451e3["options"]["sort"] &&
                        !_0x46270e)) &&
                    ((_0x380000 = _0x1250df(_0xb7cbb4, !0x1, !0x0, !0x0)),
                    _0x92c99d["forEach"](function (_0x39b9c2) {
                      _0x39b9c2 !== _0xb7cbb4 &&
                        (_0x398747(_0x39b9c2, _0x380000),
                        _0x2974a9["appendChild"](_0x39b9c2));
                    }),
                    (_0x684fc4 = !0x0)),
                  _0x16859d ||
                    (_0x684fc4 || _0x380b85(),
                    0x1 < _0x92c99d["length"]
                      ? ((_0x16859d = _0x356e0f),
                        _0x4451e3["_showClone"](_0x1ff911),
                        _0x4451e3["options"]["animation"] &&
                          !_0x356e0f &&
                          _0x16859d &&
                          _0x1d4938["forEach"](function (_0x3e4974) {
                            (_0x4451e3["addAnimationState"]({
                              target: _0x3e4974,
                              rect: _0x471a31,
                            }),
                              (_0x3e4974["fromRect"] = _0x471a31),
                              (_0x3e4974["thisAnimationDuration"] = null));
                          }))
                      : _0x4451e3["_showClone"](_0x1ff911))));
            },
            dragOverAnimationCapture: function (_0x41dd50) {
              var _0x5eaefc = _0x41dd50["dragRect"],
                _0xd19cf = _0x41dd50["isOwner"];
              ((_0x41dd50 = _0x41dd50["activeSortable"]),
                (_0x92c99d["forEach"](function (_0x412482) {
                  _0x412482["thisAnimationDuration"] = null;
                }),
                _0x41dd50["options"]["animation"] &&
                  !_0xd19cf &&
                  _0x41dd50["multiDrag"]["isMultiDrag"] &&
                  ((_0x471a31 = _0x355909({}, _0x5eaefc)),
                  (_0x5eaefc = _0x9e6c8a(_0xb7cbb4, !0x0)),
                  (_0x471a31["top"] -= _0x5eaefc["f"]),
                  (_0x471a31["left"] -= _0x5eaefc["e"]))));
            },
            dragOverAnimationComplete: function () {
              _0x684fc4 && ((_0x684fc4 = !0x1), _0x380b85());
            },
            drop: function (_0x1d50fc) {
              var _0x25077b = _0x1d50fc["originalEvent"],
                _0x52162c = _0x1d50fc["rootEl"],
                _0x4dcb7d = _0x1d50fc["parentEl"],
                _0xfae007 = _0x1d50fc["sortable"],
                _0x20575a = _0x1d50fc["dispatchSortableEvent"],
                _0x37e0b9 = _0x1d50fc["oldIndex"],
                _0x4bffb3 = _0x1d50fc["putSortable"],
                _0x4affa6 = _0x4bffb3 || this["sortable"];
              if (_0x25077b) {
                var _0xe8787b,
                  _0x5bd847,
                  _0x114cf8,
                  _0x5e5d9f = this["options"],
                  _0xcb348c = _0x4dcb7d["children"];
                if (!_0xdfe489) {
                  if (
                    (_0x5e5d9f["multiDragKey"] &&
                      !this["multiDragKeyDown"] &&
                      this["_deselectMultiDrag"](),
                    _0x27586c(
                      _0xb7cbb4,
                      _0x5e5d9f["selectedClass"],
                      !~_0x92c99d["indexOf"](_0xb7cbb4),
                    ),
                    ~_0x92c99d["indexOf"](_0xb7cbb4))
                  )
                    (_0x92c99d["splice"](_0x92c99d["indexOf"](_0xb7cbb4), 0x1),
                      (_0x57063a = null),
                      _0x45e685({
                        sortable: _0xfae007,
                        rootEl: _0x52162c,
                        name: "deselect",
                        targetEl: _0xb7cbb4,
                        originalEvt: _0x25077b,
                      }));
                  else {
                    if (
                      (_0x92c99d["push"](_0xb7cbb4),
                      _0x45e685({
                        sortable: _0xfae007,
                        rootEl: _0x52162c,
                        name: "select",
                        targetEl: _0xb7cbb4,
                        originalEvt: _0x25077b,
                      }),
                      _0x25077b["shiftKey"] &&
                        _0x57063a &&
                        _0xfae007["el"]["contains"](_0x57063a))
                    ) {
                      var _0xcd7251 = _0x493816(_0x57063a);
                      _0x1d50fc = _0x493816(_0xb7cbb4);
                      if (~_0xcd7251 && ~_0x1d50fc && _0xcd7251 !== _0x1d50fc) {
                        for (
                          var _0x55306e,
                            _0xe6520f =
                              _0xcd7251 < _0x1d50fc
                                ? ((_0x55306e = _0xcd7251), _0x1d50fc)
                                : ((_0x55306e = _0x1d50fc), _0xcd7251 + 0x1);
                          _0x55306e < _0xe6520f;
                          _0x55306e++
                        )
                          ~_0x92c99d["indexOf"](_0xcb348c[_0x55306e]) ||
                            (_0x27586c(
                              _0xcb348c[_0x55306e],
                              _0x5e5d9f["selectedClass"],
                              !0x0,
                            ),
                            _0x92c99d["push"](_0xcb348c[_0x55306e]),
                            _0x45e685({
                              sortable: _0xfae007,
                              rootEl: _0x52162c,
                              name: "select",
                              targetEl: _0xcb348c[_0x55306e],
                              originalEvt: _0x25077b,
                            }));
                      }
                    } else _0x57063a = _0xb7cbb4;
                    _0x3ab43a = _0x4affa6;
                  }
                }
                (_0xdfe489 &&
                  this["isMultiDrag"] &&
                  ((_0x684fc4 = !0x1),
                  (_0x4dcb7d[_0x4459c5]["options"]["sort"] ||
                    _0x4dcb7d !== _0x52162c) &&
                    0x1 < _0x92c99d["length"] &&
                    ((_0xe8787b = _0x1250df(_0xb7cbb4)),
                    (_0x5bd847 = _0x493816(
                      _0xb7cbb4,
                      ":not(." + this["options"]["selectedClass"] + ")",
                    )),
                    !_0x2d1a4a &&
                      _0x5e5d9f["animation"] &&
                      (_0xb7cbb4["thisAnimationDuration"] = null),
                    _0x4affa6["captureAnimationState"](),
                    _0x2d1a4a ||
                      (_0x5e5d9f["animation"] &&
                        ((_0xb7cbb4["fromRect"] = _0xe8787b),
                        _0x92c99d["forEach"](function (_0x4368f9) {
                          var _0x3683e1;
                          ((_0x4368f9["thisAnimationDuration"] = null),
                            _0x4368f9 !== _0xb7cbb4 &&
                              ((_0x3683e1 = _0x684fc4
                                ? _0x1250df(_0x4368f9)
                                : _0xe8787b),
                              (_0x4368f9["fromRect"] = _0x3683e1),
                              _0x4affa6["addAnimationState"]({
                                target: _0x4368f9,
                                rect: _0x3683e1,
                              })));
                        })),
                      _0x380b85(),
                      _0x92c99d["forEach"](function (_0x49a614) {
                        (_0xcb348c[_0x5bd847]
                          ? _0x4dcb7d["insertBefore"](
                              _0x49a614,
                              _0xcb348c[_0x5bd847],
                            )
                          : _0x4dcb7d["appendChild"](_0x49a614),
                          _0x5bd847++);
                      }),
                      _0x37e0b9 === _0x493816(_0xb7cbb4) &&
                        ((_0x114cf8 = !0x1),
                        _0x92c99d["forEach"](function (_0x556f6d) {
                          _0x556f6d["sortableIndex"] !== _0x493816(_0x556f6d) &&
                            (_0x114cf8 = !0x0);
                        }),
                        _0x114cf8 && _0x20575a("update"))),
                    _0x92c99d["forEach"](function (_0x4369e1) {
                      _0x42e02d(_0x4369e1);
                    }),
                    _0x4affa6["animateAll"]()),
                  (_0x3ab43a = _0x4affa6)),
                  (_0x52162c === _0x4dcb7d ||
                    (_0x4bffb3 && "clone" !== _0x4bffb3["lastPutMode"])) &&
                    _0x1d4938["forEach"](function (_0x221d03) {
                      _0x221d03["parentNode"] &&
                        _0x221d03["parentNode"]["removeChild"](_0x221d03);
                    }));
              }
            },
            nullingGlobal: function () {
              ((this["isMultiDrag"] = _0xdfe489 = !0x1),
                (_0x1d4938["length"] = 0x0));
            },
            destroyGlobal: function () {
              (this["_deselectMultiDrag"](),
                _0x47ae28(document, "pointerup", this["_deselectMultiDrag"]),
                _0x47ae28(document, "mouseup", this["_deselectMultiDrag"]),
                _0x47ae28(document, "touchend", this["_deselectMultiDrag"]),
                _0x47ae28(document, "keydown", this["_checkKeyDown"]),
                _0x47ae28(document, "keyup", this["_checkKeyUp"]));
            },
            _deselectMultiDrag: function (_0x3c5931) {
              if (
                !(
                  (void 0x0 !== _0xdfe489 && _0xdfe489) ||
                  _0x3ab43a !== this["sortable"] ||
                  (_0x3c5931 &&
                    _0x1b7759(
                      _0x3c5931["target"],
                      this["options"]["draggable"],
                      this["sortable"]["el"],
                      !0x1,
                    )) ||
                  (_0x3c5931 && 0x0 !== _0x3c5931["button"])
                )
              )
                for (; _0x92c99d["length"]; ) {
                  var _0x491b41 = _0x92c99d[0x0];
                  (_0x27586c(_0x491b41, this["options"]["selectedClass"], !0x1),
                    _0x92c99d["shift"](),
                    _0x45e685({
                      sortable: this["sortable"],
                      rootEl: this["sortable"]["el"],
                      name: "deselect",
                      targetEl: _0x491b41,
                      originalEvt: _0x3c5931,
                    }));
                }
            },
            _checkKeyDown: function (_0x40a419) {
              _0x40a419["key"] === this["options"]["multiDragKey"] &&
                (this["multiDragKeyDown"] = !0x0);
            },
            _checkKeyUp: function (_0x65ace4) {
              _0x65ace4["key"] === this["options"]["multiDragKey"] &&
                (this["multiDragKeyDown"] = !0x1);
            },
          }),
          _0x355909(_0xdb8caa, {
            pluginName: "multiDrag",
            utils: {
              select: function (_0x40f8a5) {
                var _0x2916ad = _0x40f8a5["parentNode"][_0x4459c5];
                _0x2916ad &&
                  _0x2916ad["options"]["multiDrag"] &&
                  !~_0x92c99d["indexOf"](_0x40f8a5) &&
                  (_0x3ab43a &&
                    _0x3ab43a !== _0x2916ad &&
                    (_0x3ab43a["multiDrag"]["_deselectMultiDrag"](),
                    (_0x3ab43a = _0x2916ad)),
                  _0x27586c(
                    _0x40f8a5,
                    _0x2916ad["options"]["selectedClass"],
                    !0x0,
                  ),
                  _0x92c99d["push"](_0x40f8a5));
              },
              deselect: function (_0x16ebb4) {
                var _0x10e077 = _0x16ebb4["parentNode"][_0x4459c5],
                  _0x31ec68 = _0x92c99d["indexOf"](_0x16ebb4);
                _0x10e077 &&
                  _0x10e077["options"]["multiDrag"] &&
                  ~_0x31ec68 &&
                  (_0x27586c(
                    _0x16ebb4,
                    _0x10e077["options"]["selectedClass"],
                    !0x1,
                  ),
                  _0x92c99d["splice"](_0x31ec68, 0x1));
              },
            },
            eventProperties: function () {
              var _0x338ef1 = this,
                _0x35d2b6 = [],
                _0x9845dc = [];
              return (
                _0x92c99d["forEach"](function (_0x4d1b4f) {
                  var _0x31748d;
                  (_0x35d2b6["push"]({
                    multiDragElement: _0x4d1b4f,
                    index: _0x4d1b4f["sortableIndex"],
                  }),
                    (_0x31748d =
                      _0x684fc4 && _0x4d1b4f !== _0xb7cbb4
                        ? -0x1
                        : _0x684fc4
                          ? _0x493816(
                              _0x4d1b4f,
                              ":not(." +
                                _0x338ef1["options"]["selectedClass"] +
                                ")",
                            )
                          : _0x493816(_0x4d1b4f)),
                    _0x9845dc["push"]({
                      multiDragElement: _0x4d1b4f,
                      index: _0x31748d,
                    }));
                }),
                {
                  items: _0x4a6337(_0x92c99d),
                  clones: []["concat"](_0x1d4938),
                  oldIndicies: _0x35d2b6,
                  newIndicies: _0x9845dc,
                }
              );
            },
            optionListeners: {
              multiDragKey: function (_0xc9e268) {
                return (
                  "ctrl" === (_0xc9e268 = _0xc9e268["toLowerCase"]())
                    ? (_0xc9e268 = "Control")
                    : 0x1 < _0xc9e268["length"] &&
                      (_0xc9e268 =
                        _0xc9e268["charAt"](0x0)["toUpperCase"]() +
                        _0xc9e268["substr"](0x1)),
                  _0xc9e268
                );
              },
            },
          })
        );
      })(),
    ),
    _0x31214e
  );
});
var _0x212bde = async function (_0x166643 = "sniper-mark") {
  var _0x24e910 = document["createElement"]("img");
  return (
    (_0x24e910["id"] = _0x166643),
    _0x24e910["classList"]["add"]("sniper-mark"),
    (_0x24e910["src"] = await chrome["runtime"]["getURL"](
      "libraries/target-spin/target.png",
    )),
    _0x24e910
  );
};
function _0x1e9e5b() {
  var _0x3f58fc = document["querySelectorAll"](".sniper-mark");
  for (var _0x1d1f03 = 0x0; _0x1d1f03 < _0x3f58fc["length"]; _0x1d1f03++)
    _0x3f58fc[_0x1d1f03]["classList"]["add"]("spin");
}
function _0xc12f52() {
  var _0x5a957 = document["querySelectorAll"](".sniper-mark");
  for (var _0x1d59e8 = 0x0; _0x1d59e8 < _0x5a957["length"]; _0x1d59e8++)
    _0x5a957[_0x1d59e8]["classList"]["remove"]("spin");
}
function _0x3938a2() {
  var _0x156ad3 = document["querySelectorAll"](".sniper-mark");
  for (var _0x3ae192 = 0x0; _0x3ae192 < _0x156ad3["length"]; _0x3ae192++)
    _0x156ad3[_0x3ae192]["classList"]["add"]("flash");
}
function _0x419b85() {
  var _0x1b6975 = document["querySelectorAll"](".sniper-mark");
  for (var _0x102502 = 0x0; _0x102502 < _0x1b6975["length"]; _0x102502++)
    _0x1b6975[_0x102502]["classList"]["remove"]("flash");
}
function _0x46a1ac(_0x2816d9) {
  _0x2816d9["classList"]["add"]("spin");
}
function _0x16b331(_0xe18678) {
  _0xe18678["classList"]["remove"]("spin");
}
function _0x515bc5(_0x511933) {
  _0x511933["classList"]["add"]("flash");
}
function _0x44ce4c(_0x3b3e4a) {
  _0x3b3e4a["classList"]["remove"]("flash");
}
function _0x194976(_0x4c0f4c, _0x5c20b0) {
  console["log"]("flyInText:\x20started");
  const _0x5c0b76 = _0x4c0f4c["split"]("");
  ((_0x5c20b0["innerHTML"] = ""),
    console["log"]("flyInText:\x20finished\x20clearing\x20element"));
  const _0x36b719 = document["createElement"]("style");
  ((_0x36b719["innerHTML"] =
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20@keyframes\x20flyIn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20from\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateY(-100%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x200;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20to\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateY(0%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x201;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"),
    console["log"]("flyInText:\x20finished\x20creating\x20style"),
    document["head"]["appendChild"](_0x36b719),
    console["log"](
      "flyInText:\x20finished\x20appending\x20style\x20to\x20head",
    ),
    _0x5c0b76["forEach"]((_0x29ffe1, _0x142b6c) => {
      const _0x5918b6 = document["createElement"]("span");
      ((_0x5918b6["innerHTML"] = _0x29ffe1),
        (_0x5918b6["style"]["opacity"] = "0"),
        (_0x5918b6["style"]["animation"] =
          "flyIn\x200.1s\x20ease\x20forwards\x20" + _0x142b6c / 0x23 + "s"),
        _0x5c20b0["appendChild"](_0x5918b6));
    }),
    console["log"](
      "flyInText:\x20finished\x20appending\x20chars\x20to\x20element",
    ));
}
function _0x4074ca(_0x224ef8, screenWidth, screenHeight, _0x351fec) {
  const _0x1b951e = document["createElement"]("div");
  return (
    (_0x1b951e["style"]["position"] = "absolute"),
    (_0x1b951e["style"]["fontSize"] = _0x224ef8 + "px"),
    (_0x1b951e["style"]["zIndex"] = "9999999"),
    (_0x1b951e["speed"] = Math["random"]() * _0x351fec + 0x1),
    Math["random"]() > 0.5 &&
      (_0x1b951e["style"]["color"] =
        "#" + Math["floor"](0xffffff * Math["random"]())["toString"](0x10)),
    _0x32cd29(_0x1b951e, screenWidth, screenHeight),
    document["body"]["appendChild"](_0x1b951e),
    _0x1b951e
  );
}
function _0x32cd29(_0x1926f1, screenWidth, screenHeight) {
  ((_0x1926f1["style"]["top"] = Math["random"]() * -screenHeight + "px"),
    (_0x1926f1["style"]["left"] =
      Math["floor"](Math["random"]() * screenWidth) + "px"),
    (_0x1926f1["style"]["opacity"] = 0x1));
}
function _0x49f9c2(
  _0x29718d,
  _0x437733,
  _0x375e17,
  _0x119492,
  screenWidth,
  screenHeight,
  _0x2b5264,
) {
  const _0x405809 = performance["now"]() - _0x2b5264;
  (_0x29718d["forEach"]((_0x1033b8) => {
    const _0x36198c = parseFloat(_0x1033b8["style"]["top"]),
      _0x722166 = parseFloat(_0x1033b8["style"]["left"]),
      _0x47e1a7 = _0x1033b8["speed"];
    if (_0x36198c > screenHeight)
      _0x32cd29(_0x1033b8, screenWidth, screenHeight);
    else
      ((_0x1033b8["style"]["top"] =
        _0x36198c + _0x47e1a7 * (_0x405809 / 0x3e8) + "px"),
        (_0x1033b8["style"]["left"] =
          _0x722166 + 0x2 * Math["random"]() - 0x1 + "px"),
        (_0x1033b8["style"]["opacity"] = Math["max"](
          0x0,
          (_0x437733 - _0x405809) / _0x437733,
        )));
  }),
    _0x405809 < _0x437733
      ? requestAnimationFrame(() =>
          _0x49f9c2(
            _0x29718d,
            _0x437733,
            _0x375e17,
            _0x119492,
            screenWidth,
            screenHeight,
            _0x2b5264,
          ),
        )
      : _0x29718d["forEach"]((_0x3169ee) => {
          document["body"]["removeChild"](_0x3169ee);
        }));
}
var _0x3b1b49 = !0x1;
function _0x5ed84c(_0x2c1e94, _0x1dc439 = "image/x-icon") {
  var _0x1fa989 = "shortcut\x20icon";
  "image/gif" == _0x1dc439 || "image/png" == _0x1dc439
    ? (_0x1fa989 = "icon")
    : (_0x3b1b49 = !0x1);
  var _0x265b4d =
    document["querySelector"]("link[rel*=\x27icon\x27]") ||
    document["createElement"]("link");
  ((_0x265b4d["type"] = _0x1dc439),
    (_0x265b4d["rel"] = _0x1fa989),
    (_0x265b4d["href"] = _0x2c1e94),
    document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x265b4d));
}
function _0x4ea246(_0x3f0220, _0x1e11a7 = "image/x-icon") {
  let _0x1a794c =
      "image/gif" == _0x1e11a7 || "image/png" == _0x1e11a7
        ? "icon"
        : "shortcut\x20icon",
    _0x195552 = document["querySelectorAll"]("link[rel*=\x27icon\x27]");
  if (0x0 === _0x195552["length"]) {
    let _0x45f804 = document["createElement"]("link");
    ((_0x45f804["type"] = _0x1e11a7),
      (_0x45f804["rel"] = _0x1a794c),
      (_0x45f804["href"] = _0x3f0220),
      document["getElementsByTagName"]("head")[0x0]["appendChild"](_0x45f804));
    return;
  }
  for (let _0x130378 of _0x195552) {
    ((_0x130378["type"] = _0x1e11a7),
      (_0x130378["rel"] = _0x1a794c),
      (_0x130378["href"] = _0x3f0220));
  }
}
function _0x3bd558() {
  _0x3b1b49 = !0x0;
  var _0x6f4d4 = 0x0,
    _0x5a12ea = chrome["runtime"]["getURL"](
      "Favicons/Gifs/Gear/frame_" + _0x6f4d4 + "_delay-0.04s.gif",
    ),
    _0x273b25 = setInterval(function () {
      if (_0x3b1b49 && _0x6f4d4 < 0x1c)
        (_0x5ed84c(_0x5a12ea, "image/gif"),
          _0x6f4d4++,
          (_0x5a12ea = chrome["runtime"]["getURL"](
            "Favicons/Gifs/Gear/frame_" + _0x6f4d4 + "_delay-0.04s.gif",
          )));
      else {
        if (_0x3b1b49 && _0x6f4d4 >= 0x1c)
          ((_0x6f4d4 = 0x0),
            (_0x5a12ea = chrome["runtime"]["getURL"](
              "Favicons/Gifs/Gear/frame_" + _0x6f4d4 + "_delay-0.04s.gif",
            )));
        else clearInterval(_0x273b25);
      }
    }, 0x28);
}
function _0x5a43a1() {
  _0x3b1b49 = !0x0;
  var _0x4f211e = 0x0,
    _0x4cf663 = chrome["runtime"]["getURL"](
      "Favicons/Task_Bar/" + _0x4f211e + ".png",
    ),
    _0x2de1b4 = setInterval(function () {
      if (_0x3b1b49 && _0x4f211e < 0x1b)
        (_0x5ed84c(_0x4cf663, "image/gif"),
          _0x4f211e++,
          (_0x4cf663 = chrome["runtime"]["getURL"](
            "Favicons/Task_Bar/" + _0x4f211e + ".png",
          )));
      else {
        if (_0x3b1b49 && _0x4f211e >= 0x1b)
          ((_0x4f211e = 0x0),
            (_0x4cf663 = chrome["runtime"]["getURL"](
              "Favicons/Task_Bar/" + _0x4f211e + ".png",
            )));
        else clearInterval(_0x2de1b4);
      }
    }, 0x28);
}
function _0x44606f() {
  _0x3b1b49 = !0x0;
  var _0x3cb943 = 0x0,
    _0x139e90 = [0x2, 0x8, 0xe, 0x14, 0x1a, 0x1b],
    _0x1f3f1a = 0x28,
    _0x28a91e = "0.04s",
    _0x109181 = setInterval(function () {
      if (_0x3b1b49) {
        _0x28a91e = _0x139e90["includes"](_0x3cb943) ? "0.05s" : "0.04s";
        var _0x4574d2 =
          "frame_" +
          _0x3cb943["toString"]()["padStart"](0x2, "0") +
          "_delay-" +
          _0x28a91e +
          ".gif";
        (_0x5ed84c(
          chrome["runtime"]["getURL"]("Favicons/Sniper/" + _0x4574d2),
          "image/gif",
        ),
          ++_0x3cb943 >= 0x1b && (_0x3cb943 = 0x0),
          (_0x1f3f1a = "0.05s" === _0x28a91e ? 0x32 : 0x28));
      } else clearInterval(_0x109181);
    }, _0x1f3f1a);
}
async function _0x449080() {
  ((_0x3b1b49 = !0x1),
    await new Promise((_0xcd43b2) => setTimeout(_0xcd43b2, 0x7d0)));
}
async function _0x1c567b(_0x19fa94, _0x538e51) {
  return new Promise((_0x1427da, _0x146c25) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0x19fa94, data: _0x538e51 },
      function (_0x23eae5) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x538e51),
          console["log"]("fetchData\x20response", _0x23eae5),
          _0x1427da(_0x23eae5["data"]));
      },
    );
  });
}
async function _0x4bc582(_0xe21df0, _0x555ab0) {
  return new Promise((_0x2106fb, _0x57ffc5) => {
    chrome["runtime"]["sendMessage"](
      { type: "fetchData", url: _0xe21df0, data: _0x555ab0 },
      function (_0x460582) {
        (console["log"]("data\x20sent\x20to\x20fetch", _0x555ab0),
          console["log"]("fetchData\x20response", _0x460582),
          _0x460582["error"] && _0x57ffc5(_0x460582["error"]),
          _0x2106fb(_0x460582["data"]));
      },
    );
  });
}
async function fetchPrompt(_0x3df879) {
  var _0x364b87 = chrome["runtime"]["getURL"](_0x3df879),
    _0x1c830b = await fetch(_0x364b87);
  return await _0x1c830b["text"]();
}
function _0x32ceb3(_0x2b934f, _0x36e8d0 = 0.7, _0x4d36fe = "text-davinci-003") {
  return new Promise((_0x2decf9, _0xd9b6be) => {
    chrome["runtime"]["sendMessage"](
      {
        type: "request-openAi",
        prompt: _0x2b934f,
        temperature: _0x36e8d0,
        model: _0x4d36fe,
      },
      function (_0x5b9c2b) {
        _0x2decf9(_0x5b9c2b["response"]);
      },
    );
  });
}
function _0x43ecf4(_0x1a187d) {
  if (!_0x1a187d["error"]) return _0x1a187d;
  alert(
    "OpenAI:\x20" +
      _0x1a187d["error"]["message"] +
      "\x0aENTER\x20IN\x20NEW\x20API\x20KEY",
  );
}
function _0x34ab48(_0x581519, _0x33c905) {
  return (
    console["log"]("test\x20save\x20to\x20local\x20storage"),
    console["log"]("key\x20" + _0x581519 + ",\x20value\x20" + _0x33c905),
    new Promise((_0x175e93, _0x2bf6e7) => {
      chrome["storage"]["local"]["set"](
        { [_0x581519]: _0x33c905 },
        function () {
          (console["log"]("my\x20key", _0x581519),
            chrome["storage"]["local"]["get"](_0x581519, function (_0x131dad) {
              (console["log"](
                "the\x20Value\x20currently\x20is\x20",
                _0x131dad[_0x581519],
              ),
                _0x175e93());
            }));
        },
      );
    })
  );
}
function _0x29ffbe(_0x515b13) {
  return new Promise((_0x4e269d, _0xf41b0c) => {
    chrome["storage"]["local"]["get"](_0x515b13, function (_0x3a3c5e) {
      (console["log"]("Value\x20currently\x20is\x20", _0x3a3c5e[_0x515b13]),
        _0x4e269d(_0x3a3c5e[_0x515b13]));
    });
  });
}
function _0x6db927() {
  var _0x513a81 = document["createElement"]("table");
  return (
    _0x513a81["setAttribute"]("id", "listing-data-table"),
    _0x513a81["setAttribute"]("class", "styled-table"),
    _0x513a81["createTHead"]()["insertRow"](0x0),
    _0x513a81["createTBody"](),
    _0x513a81
  );
}
function _0x229aaf(_0x3a4856, _0xe9d75e) {
  var _0x3f565e = _0xe9d75e["headerName"],
    _0x3261e6 = _0x3f565e["toLowerCase"]()["replace"](/ /g, "-"),
    _0x22bc2b =
      _0x3a4856["querySelector"]("thead")["getElementsByTagName"]("tr")[0x0],
    _0x4d21c3 = document["createElement"]("th");
  ((_0x4d21c3["innerHTML"] = _0x3f565e),
    _0x4d21c3["setAttribute"]("class", _0x3261e6 + "-header"),
    _0x22bc2b["appendChild"](_0x4d21c3));
}
function _0x4d5a70(_0x5b2b92) {
  var _0x1e3552 = _0x5b2b92["toLowerCase"]()["replace"](/ /g, "-");
  return document["querySelector"]("." + _0x1e3552 + "-header")["cellIndex"];
}
function _0x3f0c05(_0x105aa4) {
  var _0x569714 = _0x105aa4["querySelector"]("thead")
      ["getElementsByTagName"]("tr")[0x0]
      ["getElementsByTagName"]("th"),
    _0x71f9ad =
      _0x105aa4["querySelector"]("tbody")["getElementsByTagName"]("tr"),
    _0x4162ee = _0x105aa4["querySelector"]("tbody")["insertRow"](
      _0x71f9ad["length"],
    );
  for (var _0x4ef66d = 0x0; _0x4ef66d < _0x569714["length"]; _0x4ef66d++)
    _0x4162ee["insertCell"](_0x4ef66d)["setAttribute"](
      "class",
      _0x569714[_0x4ef66d]["innerHTML"]["toLowerCase"]()["replace"](/ /g, "-") +
        "-cell",
    );
  return _0x71f9ad["length"];
}
function _0x5ebacb(_0x554fa1, _0x13cf6d) {
  var _0x1a33d3 = _0x13cf6d["rowNumber"],
    _0x2e047f = _0x13cf6d["headerName"],
    _0x5a8e6f = _0x13cf6d["cellValue"],
    _0x24bdcc = _0x2e047f["toLowerCase"]()["replace"](/ /g, "-");
  _0x554fa1["querySelector"](
    "tbody\x20tr:nth-child(" + _0x1a33d3 + ")\x20td." + _0x24bdcc + "-cell",
  )["innerHTML"] = _0x5a8e6f;
}
function _0x2963eb(_0x1dcd6a, _0x5f34f2) {
  var _0x501360 = _0x5f34f2["button"],
    _0x27bcbf = _0x5f34f2["rowNumber"],
    _0x46661c = _0x5f34f2["headerName"]["toLowerCase"]()["replace"](/ /g, "-");
  _0x1dcd6a["querySelector"](
    "tbody\x20tr:nth-child(" + _0x27bcbf + ")\x20td." + _0x46661c + "-cell",
  )["appendChild"](_0x501360);
}
function _0x5a2276(_0x304348, _0x27e104) {
  var _0x5e484e, _0x24744e, _0xdd038d, _0x33305b, _0xb2619e, _0x2c4042;
  ((_0x304348 = document["getElementById"](_0x304348)), (_0x24744e = !0x0));
  for (; _0x24744e; ) {
    ((_0x24744e = !0x1),
      (_0x5e484e = _0x304348["getElementsByTagName"]("tr")),
      console["log"]("sortTable\x20rows", _0x5e484e));
    for (_0xdd038d = 0x1; _0xdd038d < _0x5e484e["length"] - 0x1; _0xdd038d++) {
      _0x2c4042 = !0x1;
      var _0x5e187e = _0x5e484e[_0xdd038d];
      (console["log"]("xRow", _0x5e187e),
        (_0x33305b =
          _0x5e484e[_0xdd038d]["getElementsByTagName"]("td")[
            _0x4d5a70(_0x27e104)
          ]),
        (_0xb2619e =
          _0x5e484e[_0xdd038d + 0x1]["getElementsByTagName"]("td")[
            _0x4d5a70(_0x27e104)
          ]),
        console["log"]("sortTable\x20x", _0x33305b),
        console["log"]("sortTable\x20y", _0xb2619e));
      if (
        _0x33305b["innerHTML"]["toLowerCase"]() >
        _0xb2619e["innerHTML"]["toLowerCase"]()
      ) {
        _0x2c4042 = !0x0;
        break;
      }
    }
    _0x2c4042 &&
      (_0x5e484e[_0xdd038d]["parentNode"]["insertBefore"](
        _0x5e484e[_0xdd038d + 0x1],
        _0x5e484e[_0xdd038d],
      ),
      (_0x24744e = !0x0));
  }
}
function _0x326740(_0x373bb8) {
  var _0x38d5f7 = _0x373bb8["buttonInnerText"],
    _0x338d36 = _0x373bb8["textAreaSelector"],
    _0x449d3d = _0x373bb8["valueToSet"],
    _0x20cf4e = _0x373bb8["callback"],
    _0xeac8b2 = document["createElement"]("button");
  return (
    (_0xeac8b2["innerText"] = _0x38d5f7),
    (_0xeac8b2["onclick"] = function () {
      ((document["querySelector"](_0x338d36)["value"] = _0x449d3d),
        _0x20cf4e && _0x20cf4e());
    }),
    _0xeac8b2
  );
}
console["log"]("Sanitizer\x20loading");
var _0x40cf16 = new (function () {
  var _0x551690 = {
      A: !0x0,
      ABBR: !0x0,
      B: !0x0,
      BLOCKQUOTE: !0x0,
      BODY: !0x0,
      BR: !0x0,
      CENTER: !0x0,
      CODE: !0x0,
      DIV: !0x0,
      EM: !0x0,
      FONT: !0x0,
      H1: !0x0,
      H2: !0x0,
      H3: !0x0,
      H4: !0x0,
      H5: !0x0,
      H6: !0x0,
      HR: !0x0,
      I: !0x0,
      LABEL: !0x0,
      LI: !0x0,
      OL: !0x0,
      P: !0x0,
      PRE: !0x0,
      SMALL: !0x0,
      SOURCE: !0x0,
      SPAN: !0x0,
      STRONG: !0x0,
      TABLE: !0x0,
      TBODY: !0x0,
      TR: !0x0,
      TD: !0x0,
      TH: !0x0,
      THEAD: !0x0,
      UL: !0x0,
      U: !0x0,
      VIDEO: !0x0,
    },
    _0x45f41c = { FORM: !0x0 },
    _0x5051ea = {
      align: !0x0,
      color: !0x0,
      controls: !0x0,
      height: !0x0,
      src: !0x0,
      style: !0x0,
      target: !0x0,
      title: !0x0,
      type: !0x0,
      width: !0x0,
    },
    _0x2c7d1a = {
      color: !0x0,
      "background-color": !0x0,
      "font-size": !0x0,
      "text-align": !0x0,
      "text-decoration": !0x0,
      "font-weight": !0x0,
    },
    _0xfe2f02 = [""],
    _0x1e1973 = { href: !0x0, action: !0x0 };
  this["SanitizeHtml"] = function (_0x1a439b) {
    if ("" == (_0x1a439b = _0x1a439b["trim"]())) return "";
    if ("<br>" == _0x1a439b) return "";
    var _0x405e50 = document["createElement"]("iframe");
    if (void 0x0 === _0x405e50["sandbox"])
      return (
        alert(
          "Your\x20browser\x20does\x20not\x20support\x20sandboxed\x20iframes.\x20Please\x20upgrade\x20to\x20a\x20modern\x20browser.",
        ),
        ""
      );
    ((_0x405e50["sandbox"] = "allow-same-origin"),
      (_0x405e50["style"]["display"] = "none"),
      document["body"]["appendChild"](_0x405e50));
    var _0x5b0f07 =
      _0x405e50["contentDocument"] || _0x405e50["contentWindow"]["document"];
    (null == _0x5b0f07["body"] && _0x5b0f07["write"]("<body></body>"),
      (_0x5b0f07["body"]["innerHTML"] = _0x1a439b));
    var _0x4824ab = (function _0x39c339(_0x4e101a) {
      if (_0x4e101a["nodeType"] == Node["TEXT_NODE"])
        var _0x2029b4 = _0x4e101a["cloneNode"](!0x0);
      else {
        if (
          _0x4e101a["nodeType"] == Node["ELEMENT_NODE"] &&
          (_0x551690[_0x4e101a["tagName"]] || _0x45f41c[_0x4e101a["tagName"]])
        ) {
          if (
            ("SPAN" == _0x4e101a["tagName"] ||
              "B" == _0x4e101a["tagName"] ||
              "I" == _0x4e101a["tagName"] ||
              "U" == _0x4e101a["tagName"]) &&
            "" == _0x4e101a["innerHTML"]["trim"]()
          )
            return document["createDocumentFragment"]();
          _0x2029b4 = _0x45f41c[_0x4e101a["tagName"]]
            ? _0x5b0f07["createElement"]("DIV")
            : _0x5b0f07["createElement"](_0x4e101a["tagName"]);
          for (
            var _0x12c3a4 = 0x0;
            _0x12c3a4 < _0x4e101a["attributes"]["length"];
            _0x12c3a4++
          ) {
            var _0x25899d = _0x4e101a["attributes"][_0x12c3a4];
            if (_0x5051ea[_0x25899d["name"]]) {
              if ("style" == _0x25899d["name"])
                for (s = 0x0; s < _0x4e101a["style"]["length"]; s++) {
                  var _0x378d51 = _0x4e101a["style"][s];
                  _0x2c7d1a[_0x378d51] &&
                    _0x2029b4["style"]["setProperty"](
                      _0x378d51,
                      _0x4e101a["style"]["getPropertyValue"](_0x378d51),
                    );
                }
              else {
                if (
                  _0x1e1973[_0x25899d["name"]] &&
                  _0x25899d["value"]["indexOf"](":") > -0x1 &&
                  !_0x507525(_0x25899d["value"], _0xfe2f02)
                )
                  continue;
                _0x2029b4["setAttribute"](
                  _0x25899d["name"],
                  _0x25899d["value"],
                );
              }
            }
          }
          for (
            _0x12c3a4 = 0x0;
            _0x12c3a4 < _0x4e101a["childNodes"]["length"];
            _0x12c3a4++
          ) {
            var _0x5e5076 = _0x39c339(_0x4e101a["childNodes"][_0x12c3a4]);
            _0x2029b4["appendChild"](_0x5e5076, !0x1);
          }
        } else _0x2029b4 = document["createDocumentFragment"]();
      }
      return _0x2029b4;
    })(_0x5b0f07["body"]);
    return (
      document["body"]["removeChild"](_0x405e50),
      _0x4824ab["innerHTML"]
        ["replace"](/<br[^>]*>(\S)/g, "<br>\x0a$1")
        ["replace"](/div><div/g, "div>\x0a<div")
    );
  };
  function _0x507525(_0x3a5ade, _0x173433) {
    for (var _0x4f3b0c = 0x0; _0x4f3b0c < _0x173433["length"]; _0x4f3b0c++)
      if (0x0 == _0x3a5ade["indexOf"](_0x173433[_0x4f3b0c])) return !0x0;
    return !0x1;
  }
  ((this["AllowedTags"] = _0x551690),
    (this["AllowedAttributes"] = _0x5051ea),
    (this["AllowedCssStyles"] = _0x2c7d1a),
    (this["AllowedSchemas"] = _0xfe2f02));
})();
function _0x46e7ff(_0x42e451, find, _0x300f83) {
  try {
    var _0x4f3866,
      _0x5935ee = "",
      _0x39d811 = _0x42e451,
      _0xf3d4ff = find["toLowerCase"]();
    for (
      ;
      -0x1 !== (_0x4f3866 = _0x39d811["toLowerCase"]()["indexOf"](_0xf3d4ff));

    ) {
      ((_0x5935ee += _0x39d811["substr"](0x0, _0x4f3866) + _0x300f83),
        (_0x39d811 = _0x39d811["substr"](_0x4f3866 + find["length"])));
    }
    return _0x5935ee + _0x39d811;
  } catch (_0x24e5f0) {
    return _0x42e451;
  }
}
function _0x2fa952(_0x3be96f) {
  return _0x3be96f["charAt"](0x0)["toUpperCase"]() + _0x3be96f["slice"](0x1);
}
var _0x379f5d = (_0x173a02, _0x4e60c8) => {
    console["log"]("test\x20waitUntilElementExists");
    var _0x57f21c = document["querySelector"](_0x173a02);
    console["log"]("Checking");
    if (_0x57f21c) return (console["log"]("Found"), _0x4e60c8(_0x57f21c));
    setTimeout(() => _0x379f5d(_0x173a02, _0x4e60c8), 0x1f4);
  },
  _0x27dd37 = (_0xebfeae, _0x25b4ff) => {
    console["log"]("test");
    var _0x365393 = document["querySelectorAll"](_0xebfeae)[0x0];
    console["log"]("Checking");
    if (_0x365393) return (console["log"]("Found"), _0x25b4ff(_0x365393));
    setTimeout(() => _0x27dd37(_0xebfeae, _0x25b4ff), 0x1f4);
  };
_0x379f5d = (_0xf60ee, _0x2a2927) => {
  var _0x30f4f1 = document["querySelector"](_0xf60ee);
  console["log"]("Checking");
  if (_0x30f4f1) return (console["log"]("Found"), _0x2a2927(_0x30f4f1));
  setTimeout(() => _0x379f5d(_0xf60ee, _0x2a2927), 0x1f4);
};
function _0x30e734(_0x41d614, _0x26304b = 0x32, _0x19d5fc = 0x64) {
  const _0x2bff9e = document["querySelector"](_0x41d614);
  !window["__" + _0x41d614] &&
    ((window["__" + _0x41d614] = 0x0),
    (window["__" + _0x41d614 + "__delay"] = _0x26304b),
    (window["__" + _0x41d614 + "__tries"] = _0x19d5fc));
  if (null === _0x2bff9e) {
    if (window["__" + _0x41d614] >= window["__" + _0x41d614 + "__tries"])
      return ((window["__" + _0x41d614] = 0x0), Promise["resolve"](null));
    return new Promise((_0x3e33f6) => {
      (window["__" + _0x41d614]++,
        setTimeout(_0x3e33f6, window["__" + _0x41d614 + "__delay"]));
    })["then"](() => _0x30e734(_0x41d614));
  }
  return Promise["resolve"](_0x2bff9e);
}
function _0x2d610d(
  _0x58711e = document,
  _0x5d66c5,
  _0x5d1e15 = 0x32,
  _0xeda38c = 0x64,
) {
  const _0x26f93d = _0x58711e["querySelector"](_0x5d66c5);
  !window["__" + _0x5d66c5] &&
    ((window["__" + _0x5d66c5] = 0x0),
    (window["__" + _0x5d66c5 + "__delay"] = _0x5d1e15),
    (window["__" + _0x5d66c5 + "__tries"] = _0xeda38c));
  if (null === _0x26f93d) {
    if (window["__" + _0x5d66c5] >= window["__" + _0x5d66c5 + "__tries"])
      return ((window["__" + _0x5d66c5] = 0x0), Promise["resolve"](null));
    return new Promise((_0x5f1379) => {
      (window["__" + _0x5d66c5]++,
        setTimeout(_0x5f1379, window["__" + _0x5d66c5 + "__delay"]));
    })["then"](() => _0x30e734(_0x5d66c5));
  }
  return Promise["resolve"](_0x26f93d);
}
const _0x17fa35 = { URL: "URL", BASE_64: "BASE_64" };
console["log"]("image_utils.js");
async function _0x52d13d(_0x5ea52e) {
  if (!_0x5ea52e) throw new Error("Image\x20URL\x20is\x20required");
  var _0x5ae999 = (_0x5ae999 = await _0x47e53d(_0x5ea52e))["b64Image"];
  return await _0x2a8417(_0x5ae999);
}
function _0x47e53d(_0x4fe810) {
  return new Promise((_0x5425ba, _0x4f485d) => {
    chrome["runtime"]["sendMessage"](
      { type: "url-to-b64", url: _0x4fe810 },
      (_0x2982d8) => {
        _0x2982d8 && _0x2982d8["error"]
          ? _0x4f485d(new Error(_0x2982d8["error"]))
          : _0x5425ba(_0x2982d8);
      },
    );
  });
}
const _0x18b31f = (_0x1b7db4, _0x4930e3) => {
    ((trimmedString = _0x1b7db4),
      _0x1b7db4["startsWith"]("data") &&
        (trimmedString = _0x1b7db4["split"](",")[0x1]));
    const _0xb4d81f = atob(trimmedString),
      _0x32bce4 = new ArrayBuffer(_0xb4d81f["length"]),
      _0x199fad = new Uint8Array(_0x32bce4);
    for (let _0x162af6 = 0x0; _0x162af6 < _0xb4d81f["length"]; _0x162af6++)
      _0x199fad[_0x162af6] = _0xb4d81f["charCodeAt"](_0x162af6);
    const _0x3c17be = new Blob([_0x32bce4], { type: "image/jpeg" });
    return new File([_0x3c17be], _0x4930e3, {
      lastModified: new Date()["getTime"](),
      type: "image/jpeg",
    });
  },
  _0x262964 = (_0x1baf22, _0x5c06a4) => {
    const _0x4c683e = new DataTransfer();
    (_0x4c683e["items"]["add"](_0x1baf22),
      (_0x5c06a4["files"] = _0x4c683e["files"]));
    const _0xe1cac6 = new Event("change", { bubbles: !0x0 });
    _0x5c06a4["dispatchEvent"](_0xe1cac6);
  };
var _0x580176 = async (_0x148f35, _0x12a0d0, _0x3cd838, _0x32ee84) => {
  let _0x410327;
  if (_0x32ee84 == _0x17fa35["URL"]) {
    const { b64Image: _0x2c145f } = await _0x47e53d(_0x148f35);
    _0x410327 = _0x18b31f(_0x2c145f, _0x3cd838);
  }
  _0x32ee84 == _0x17fa35["BASE_64"] &&
    (_0x410327 = _0x18b31f(_0x148f35, _0x3cd838));
  var _0x237e1c = document["querySelector"](_0x12a0d0);
  _0x262964(_0x410327, _0x237e1c);
};
async function _0x2efd30(
  _0x461c78,
  _0x159fd9,
  _0xaf3186,
  _0x4a4f3a,
  _0x216b4f,
  _0x1103f1,
  _0x4be2b7,
  _0x40980a,
) {
  var _0xf90b7c = await _0x52d13d(_0x461c78);
  _0xf90b7c = await _0x94e810(_0xf90b7c, _0x216b4f, _0x1103f1);
  var _0x19a61b = await _0x52d13d(_0xaf3186);
  ((_0x19a61b = await _0x94e810(_0x19a61b, 0.45 * _0x1103f1, 0.45 * _0x216b4f)),
    (_0xf90b7c = await _0x3b1e22(_0xf90b7c, _0x19a61b, 0.75)));
  var _0x239628 = await _0x52d13d(_0x159fd9);
  return (
    (_0x239628 = await _0x94e810(
      _0x239628,
      0.45 * _0x1103f1,
      0.45 * _0x216b4f,
    )),
    await _0x3f9f31(_0xf90b7c, _0x239628, 0.95)
  );
}
async function _0x50d9e4(
  _0x1a9e34,
  _0x2c8bf8,
  _0x1429ed,
  _0x10fdbf,
  _0x3d870b,
  _0x384447,
  _0x5e6206,
) {
  var _0x42fcb6 = await _0x52d13d(_0x1a9e34);
  _0x42fcb6 = await _0x3cadab(_0x42fcb6, _0x10fdbf, _0x3d870b);
  var _0x3b534f = await _0x52d13d(_0x2c8bf8);
  return (
    (_0x3b534f = await _0x3cadab(
      _0x3b534f,
      0.45 * _0x3d870b,
      0.45 * _0x10fdbf,
    )),
    (_0x42fcb6 = await _0x267896(_0x42fcb6, _0x3b534f, "right")),
    (_0x3b534f = await _0x3cadab(_0x3b534f, 0.4 * _0x3d870b, 0.4 * _0x10fdbf)),
    await _0x57f2c5(_0x42fcb6, _0x3b534f, 0.7, _0x2c8bf8)
  );
}
async function _0x38604(_0x22ab9f) {
  var _0x42ffdb = _0x22ab9f["imageSource"],
    _0x3a9aae = _0x22ab9f["waterMarkUrl"],
    _0xb14e87 = await _0x52d13d(_0x42ffdb);
  ((_0xb14e87 = await _0x20059f(_0xb14e87)),
    (_0xb14e87 = await _0x1aa8bc(_0xb14e87)));
  var _0xd67b77 = await _0x52d13d(_0x3a9aae);
  return (
    (_0xd67b77 = await _0x3cadab(
      _0xd67b77,
      0.2 * _0xb14e87["height"],
      0.2 * _0xb14e87["width"],
    )),
    (_0xd67b77 = await _0x20059f(_0xd67b77)),
    (_0xd67b77 = await _0x1aa8bc(_0xd67b77)),
    (_0xb14e87 = await _0x267896(_0xb14e87, _0xd67b77, "right")),
    (_0xb14e87 = await _0x57f2c5(_0xb14e87, _0xd67b77, 0.7))["width"] >
    _0xb14e87["height"]
      ? (_0xb14e87 = await _0x2994ac({
          imageObject: _0xb14e87,
          padding: _0xb14e87["width"] - _0xb14e87["height"],
          paddingDirection: "height",
        }))
      : (_0xb14e87["width"] < _0xb14e87["height"] ||
          _0xb14e87["width"] == _0xb14e87["height"]) &&
        (_0xb14e87 = await _0x2994ac({
          imageObject: _0xb14e87,
          padding: _0xb14e87["height"] - _0xb14e87["width"],
          paddingDirection: "width",
        })),
    _0xb14e87
  );
}
async function _0x1682ab(_0x494037, _0x4878f9 = "Look", _0x2de34d = "Inside") {
  var _0x57e6b7 = _0x494037["imageSource"],
    _0x4c5ed3 = _0x494037["waterMarkUrl"],
    _0x2d5322 = await _0x52d13d(_0x57e6b7);
  ((_0x2d5322 = await _0x20059f(_0x2d5322)),
    (_0x2d5322 = await _0x1aa8bc(_0x2d5322)));
  var _0x8a2285 = await _0x52d13d(_0x4c5ed3);
  ((_0x8a2285 = await _0x3cadab(
    _0x8a2285,
    0.2 * _0x2d5322["height"],
    0.2 * _0x2d5322["width"],
  )),
    (_0x8a2285 = await _0x20059f(_0x8a2285)),
    (_0x8a2285 = await _0x1aa8bc(_0x8a2285)));
  var _0x55ca42 = getProductDescriptionAndFeatures(),
    _0x4e80b6 = getFilteredTitle() + "\x0a\x0a" + _0x55ca42,
    _0xb53422 = await _0x1c567b(
      "http://1.1.1.66:1102/api/ItemSpecifics/GetBuyerIntent",
      { request_type: "get_buyer_intent", productDescription: _0x4e80b6 },
    );
  console["log"]("twoWordBuyerIntent", _0xb53422);
  var _0x10939e = _0xb53422["split"]("\x20");
  _0x4878f9 = _0x10939e[0x0];
  for (var _0x6ef01 = 0x1; _0x6ef01 < _0x10939e["length"]; _0x6ef01++)
    _0x2de34d += "\x20" + _0x10939e[_0x6ef01];
  return (
    (_0x2de34d = _0x2de34d["trim"]()),
    (_0x4878f9 = _0x4878f9["trim"]()),
    (_0x2d5322 = await _0x1e4ac5(_0x2d5322, _0x4878f9, _0x2de34d)),
    (_0x2d5322 = await _0x267896(_0x2d5322, _0x8a2285, "right")),
    (_0x2d5322 = await _0xe4c42c(_0x2d5322)),
    await _0x57f2c5(_0x2d5322, _0x8a2285, 0.7)
  );
}
async function _0x2292eb(_0x1d6816) {
  var _0x4895e9 = _0x1d6816["imageSource"],
    _0x9217cf = _0x1d6816["waterMarkUrl"],
    _0x2592ba = await _0x52d13d(_0x4895e9);
  ((_0x2592ba = await _0x20059f(_0x2592ba)),
    (_0x2592ba = await _0x1aa8bc(_0x2592ba)));
  var _0x822407 = await _0x52d13d(_0x9217cf);
  return (
    (_0x822407 = await _0x3cadab(
      _0x822407,
      0.2 * _0x2592ba["height"],
      0.2 * _0x2592ba["width"],
    )),
    (_0x822407 = await _0x20059f(_0x822407)),
    (_0x822407 = await _0x1aa8bc(_0x822407)),
    (_0x2592ba = await _0x267896(_0x2592ba, _0x822407, "right")),
    (_0x2592ba = await _0xe4c42c(_0x2592ba)),
    (_0x2592ba = await _0x57f2c5(_0x2592ba, _0x822407, 0.7)),
    await _0x2db71b(_0x2592ba, 0x1f4, 0x1f4)
  );
}
function _0x5d49fb(_0x11e596) {
  ((imgWidth = _0x11e596["width"]), (imgHeight = _0x11e596["height"]));
  var _0x4fbd8d = document["createElement"]("canvas");
  (_0x4fbd8d["setAttribute"]("width", imgWidth),
    _0x4fbd8d["setAttribute"]("height", imgHeight));
  var _0x3f5be7 = _0x4fbd8d["getContext"]("2d");
  _0x3f5be7["drawImage"](_0x11e596, 0x0, 0x0);
  var _0x44f8bd = _0x3f5be7["getImageData"](0x0, 0x0, imgWidth, imgHeight)[
      "data"
    ],
    _0x54e9c9 = function (_0x4c7550, _0x4c5dc7) {
      var _0x2ce264 = imgWidth * _0x4c5dc7 + _0x4c7550;
      return {
        red: _0x44f8bd[0x4 * _0x2ce264],
        green: _0x44f8bd[0x4 * _0x2ce264 + 0x1],
        blue: _0x44f8bd[0x4 * _0x2ce264 + 0x2],
        opacity: _0x44f8bd[0x4 * _0x2ce264 + 0x3],
      };
    },
    _0x2ad406 = function (_0x583577) {
      return (
        _0x583577["red"] > 0xc8 &&
        _0x583577["green"] > 0xc8 &&
        _0x583577["blue"] > 0xc8
      );
    },
    _0x13e5ab = function (_0x4d919e) {
      var _0x2976bf = _0x4d919e ? 0x1 : -0x1;
      for (
        var _0x594aa1 = _0x4d919e ? 0x0 : imgHeight - 0x1;
        _0x4d919e ? _0x594aa1 < imgHeight : _0x594aa1 > -0x1;
        _0x594aa1 += _0x2976bf
      )
        for (var _0x193a9a = 0x0; _0x193a9a < imgWidth; _0x193a9a++) {
          var _0x2bdb6b = _0x54e9c9(_0x193a9a, _0x594aa1);
          if (!_0x2ad406(_0x2bdb6b))
            return _0x4d919e
              ? _0x594aa1
              : Math["min"](_0x594aa1 + 0x1, imgHeight);
        }
      return null;
    },
    _0x5ae257 = function (_0x1ab6ce) {
      var _0x1765ff = _0x1ab6ce ? 0x1 : -0x1;
      for (
        var _0x42214c = _0x1ab6ce ? 0x0 : imgWidth - 0x1;
        _0x1ab6ce ? _0x42214c < imgWidth : _0x42214c > -0x1;
        _0x42214c += _0x1765ff
      )
        for (var _0x2eacfc = 0x0; _0x2eacfc < imgHeight; _0x2eacfc++) {
          var _0x24e1f4 = _0x54e9c9(_0x42214c, _0x2eacfc);
          if (!_0x2ad406(_0x24e1f4))
            return _0x1ab6ce
              ? _0x42214c
              : Math["min"](_0x42214c + 0x1, imgWidth);
        }
      return null;
    },
    _0x32c437 = _0x13e5ab(!0x0),
    _0x1a4651 = _0x13e5ab(!0x1),
    _0xe16b5d = _0x5ae257(!0x0),
    _0x19138f = _0x5ae257(!0x1) - _0xe16b5d,
    _0xe821a0 = _0x1a4651 - _0x32c437;
  return (
    _0x4fbd8d["setAttribute"]("width", _0x19138f),
    _0x4fbd8d["setAttribute"]("height", _0xe821a0),
    _0x4fbd8d["getContext"]("2d")["drawImage"](
      _0x11e596,
      _0xe16b5d,
      _0x32c437,
      _0x19138f,
      _0xe821a0,
      0x0,
      0x0,
      _0x19138f,
      _0xe821a0,
    ),
    _0x4fbd8d["toDataURL"]()
  );
}
async function _0x17dbd8(_0x106ede) {
  var _0x5ed7c7 = _0x106ede["imageSource"],
    _0x4f0852 = await _0x52d13d(_0x5ed7c7);
  ((_0x4f0852 = await _0x2994ac({
    imageObject: _0x4f0852,
    padding: _0x4f0852["width"] - _0x4f0852["height"],
    paddingDirection: "height",
  })),
    (_0x4f0852 = await _0x27e504(_0x4f0852, "black", "30px")),
    document["body"]["prepend"](_0x4f0852));
}
function _0x2994ac(_0x150cbc) {
  return new Promise((_0x5b25ac, _0x188797) => {
    var _0x49d5f0 = _0x150cbc["imageObject"],
      _0x483d00 = _0x150cbc["padding"],
      _0x52f91b = _0x150cbc["paddingDirection"] || "all",
      _0x40d92d = document["createElement"]("canvas");
    _0x40d92d["id"] = "myCanvas";
    var _0xe047b1 = _0x40d92d["getContext"]("2d");
    "all" == _0x52f91b &&
      ((_0x40d92d["width"] = _0x49d5f0["width"] + _0x483d00),
      (_0x40d92d["height"] = _0x49d5f0["height"] + _0x483d00),
      (_0xe047b1["fillStyle"] = "white"),
      _0xe047b1["fillRect"](0x0, 0x0, _0x40d92d["width"], _0x40d92d["height"]),
      _0xe047b1["drawImage"](_0x49d5f0, _0x483d00 / 0x2, _0x483d00 / 0x2));
    "height" == _0x52f91b &&
      ((_0x40d92d["width"] = _0x49d5f0["width"]),
      (_0x40d92d["height"] = _0x49d5f0["height"] + _0x483d00),
      (_0xe047b1["fillStyle"] = "white"),
      _0xe047b1["fillRect"](0x0, 0x0, _0x40d92d["width"], _0x40d92d["height"]),
      _0xe047b1["drawImage"](_0x49d5f0, 0x0, _0x483d00 / 0x2));
    "width" == _0x52f91b &&
      ((_0x40d92d["width"] = _0x49d5f0["width"] + _0x483d00),
      (_0x40d92d["height"] = _0x49d5f0["height"]),
      (_0xe047b1["fillStyle"] = "white"),
      _0xe047b1["fillRect"](0x0, 0x0, _0x40d92d["width"], _0x40d92d["height"]),
      _0xe047b1["drawImage"](_0x49d5f0, _0x483d00 / 0x2, 0x0));
    var _0x5207d4 = new Image();
    ((_0x5207d4["onload"] = function () {
      _0x5b25ac(_0x5207d4);
    }),
      (_0x5207d4["src"] = _0x40d92d["toDataURL"]()));
  });
}
async function _0x5c3ac2(
  _0x4c0e47,
  _0x39d1f9,
  _0x399906,
  _0x6b34fc,
  _0x19cf2f,
  _0x27e5bb,
  _0x116874,
  _0x570df9,
) {
  var _0x5c8db7 = await _0x52d13d(_0x4c0e47);
  ((_0x5c8db7 = await _0x3cadab(_0x5c8db7, _0x19cf2f, _0x27e5bb)),
    (_0x5c8db7 = await _0x20059f(_0x5c8db7)));
  var _0x36ca93 = await _0x52d13d(_0x399906);
  ((_0x36ca93 = await _0x20059f(_0x36ca93)),
    (_0x36ca93 = await _0x3cadab(
      _0x36ca93,
      0.45 * _0x27e5bb,
      0.45 * _0x19cf2f,
    )));
  var _0x4df50a = await _0x52d13d(_0x39d1f9);
  return (
    (_0x4df50a = await _0x3cadab(
      _0x4df50a,
      0.45 * _0x27e5bb,
      0.45 * _0x19cf2f,
    )),
    (_0x5c8db7 = await _0x267896(_0x5c8db7, _0x4df50a, "right")),
    (_0x4df50a = await _0x3cadab(_0x4df50a, 0.4 * _0x19cf2f, 0.4 * _0x27e5bb)),
    (_0x5c8db7 = await _0x347fe4(_0x5c8db7, _0x4df50a, 0x1, 0xc)),
    (_0x36ca93 = await _0x464df3(
      _0x36ca93,
      0.65 * _0x4df50a["width"],
      0.65 * _0x4df50a["height"],
    )),
    (_0x36ca93 = await _0x1aa8bc(_0x36ca93)),
    (_0x5c8db7 = await _0x57f2c5(_0x5c8db7, _0x36ca93, 0.7)),
    (_0x5c8db7 = await _0xe4c42c(_0x5c8db7)),
    await _0x2db71b(_0x5c8db7, 0x1f4, 0x1f4)
  );
}
async function _0x136fd5(
  _0x191f56,
  _0x287792,
  _0x37d837,
  _0x45e55b,
  _0x412f85,
  _0x50f65b,
  _0x735b43,
  _0x14c113,
) {
  var _0x4e2e4c = await _0x52d13d(_0x191f56);
  ((_0x4e2e4c = await _0x3cadab(_0x4e2e4c, _0x412f85, _0x50f65b)),
    (_0x4e2e4c = await _0x20059f(_0x4e2e4c)));
  var _0x4842d7 = await _0x52d13d(_0x37d837);
  ((_0x4842d7 = await _0x3cadab(_0x4842d7, 0.45 * _0x50f65b, 0.45 * _0x412f85)),
    (waterMarkImg = await _0x20059f(_0x4842d7)),
    (waterMarkImg = await _0x1aa8bc(_0x4842d7)));
  var _0x39983e = await _0x52d13d(_0x287792);
  return (
    (_0x39983e = await _0x3cadab(
      _0x39983e,
      0.45 * _0x50f65b,
      0.45 * _0x412f85,
    )),
    (_0x4e2e4c = await _0x267896(_0x4e2e4c, _0x39983e, "right")),
    (_0x4842d7 = await _0x464df3(
      _0x4842d7,
      0.65 * _0x39983e["width"],
      0.65 * _0x39983e["height"],
    )),
    (_0x4842d7 = await _0x1aa8bc(_0x4842d7)),
    (_0x4e2e4c = await _0x57f2c5(_0x4e2e4c, _0x4842d7, 0.7)),
    (_0x4e2e4c = await _0xe4c42c(_0x4e2e4c)),
    (_0x39983e = await _0x3cadab(_0x39983e, 0.4 * _0x412f85, 0.4 * _0x50f65b)),
    (_0x4e2e4c = await _0x347fe4(_0x4e2e4c, _0x39983e, 0x1, 0xc)),
    await _0x2db71b(_0x4e2e4c, 0x1f4, 0x1f4)
  );
}
async function _0x1c63eb(
  _0x349379,
  _0x2a8cec,
  _0xb07edb,
  _0x3b0452,
  _0x416ce0,
  _0x1f6588,
  _0x11f5dc,
  _0x4a9783,
) {
  var _0x149857 = await _0x52d13d(_0x349379);
  ((_0x149857 = await _0x3cadab(_0x149857, _0x416ce0, _0x1f6588)),
    (_0x149857 = await _0x20059f(_0x149857)));
  var _0x5d2125 = await _0x52d13d(_0xb07edb);
  ((_0x5d2125 = await _0x3cadab(_0x5d2125, 0.45 * _0x1f6588, 0.45 * _0x416ce0)),
    (waterMarkImg = await _0x20059f(_0x5d2125)),
    (waterMarkImg = await _0x1aa8bc(_0x5d2125)));
  var _0x34d5cc = await _0x52d13d(_0x2a8cec);
  return (
    (_0x34d5cc = await _0x3cadab(
      _0x34d5cc,
      0.45 * _0x1f6588,
      0.45 * _0x416ce0,
    )),
    (_0x149857 = await _0x267896(_0x149857, _0x34d5cc, "right")),
    (_0x149857 = await _0xe4c42c(_0x149857)),
    (_0x5d2125 = await _0x464df3(
      _0x5d2125,
      0.65 * _0x34d5cc["width"],
      0.65 * _0x34d5cc["height"],
    )),
    (_0x5d2125 = await _0x1aa8bc(_0x5d2125)),
    (_0x149857 = await _0x57f2c5(_0x149857, _0x5d2125, 0.7)),
    (_0x34d5cc = await _0x3cadab(_0x34d5cc, 0.4 * _0x416ce0, 0.4 * _0x1f6588)),
    (_0x149857 = await _0x347fe4(_0x149857, _0x34d5cc, 0x1, 0xc)),
    (_0x149857 = await _0x5ee413(_0x149857)),
    (_0x149857 = await _0x3b8f7a(_0x149857)),
    await _0x2db71b(_0x149857, 0x1f4, 0x1f4)
  );
}
function _0x2e7cc7(_0x583ea9, _0x565779, _0x30fb88) {
  return new Promise(async (_0x2df885, _0x12c051) => {
    let _0x2dd4d1 = document["createElement"]("canvas");
    ((_0x2dd4d1["width"] = _0x583ea9["width"]),
      (_0x2dd4d1["height"] = _0x583ea9["height"]));
    let _0x550650 = _0x2dd4d1["getContext"]("2d");
    ((_0x550650["fillStyle"] = _0x30fb88),
      _0x550650["fillRect"](0x0, 0x0, _0x2dd4d1["width"], _0x2dd4d1["height"]),
      _0x550650["drawImage"](
        _0x583ea9,
        0x0,
        0x0,
        _0x583ea9["width"],
        _0x583ea9["height"],
      ));
    var _0x592aa8 = new Image();
    ((_0x592aa8["onload"] = function () {
      _0x2df885(_0x592aa8);
    }),
      (_0x592aa8["src"] = _0x2dd4d1["toDataURL"]()));
  });
}
async function _0xf661c7(
  _0x3393e0,
  _0x56724,
  _0x4e2f94,
  _0x30295e,
  _0x3f3b5a,
  _0x3eacfd,
  _0x3bc635,
  _0xc1ffe,
) {
  var _0x2a4c57 = await _0x52d13d(_0x3393e0);
  ((_0x2a4c57 = await _0x3cadab(_0x2a4c57, _0x3f3b5a, _0x3eacfd)),
    (_0x2a4c57 = await _0x20059f(_0x2a4c57)));
  var _0x57c80d = await _0x52d13d(_0x4e2f94);
  _0x57c80d = await _0x3cadab(_0x57c80d, 0.45 * _0x3eacfd, 0.45 * _0x3f3b5a);
  var _0x45e71d = await _0x52d13d(_0x56724);
  return (
    (_0x45e71d = await _0x3cadab(
      _0x45e71d,
      0.45 * _0x3eacfd,
      0.45 * _0x3f3b5a,
    )),
    (_0x45e71d = await _0x1aa8bc(_0x45e71d)),
    (_0x45e71d = await _0x2e7cc7(_0x45e71d, _0x56724, "beige")),
    (_0x2a4c57 = await _0x267896(_0x2a4c57, _0x45e71d, "right")),
    (_0x45e71d = await _0x3cadab(_0x45e71d, 0.4 * _0x3f3b5a, 0.4 * _0x3eacfd)),
    (_0x2a4c57 = await _0x347fe4(_0x2a4c57, _0x45e71d, 0x1, 0xc)),
    (_0x57c80d = await _0x20059f(_0x57c80d)),
    (_0x57c80d = await _0x464df3(
      _0x57c80d,
      _0x45e71d["width"],
      _0x45e71d["height"],
    )),
    (_0x57c80d = await _0x1aa8bc(_0x57c80d)),
    (_0x2a4c57 = await _0x57f2c5(_0x2a4c57, _0x57c80d, 0.7, _0x4e2f94)),
    (_0x2a4c57 = await _0xe4c42c(_0x2a4c57)),
    (_0x2a4c57 = await _0x5ee413(_0x2a4c57)),
    (_0x2a4c57 = await _0x3b8f7a(_0x2a4c57)),
    await _0x2db71b(_0x2a4c57, 0x1f4, 0x1f4)
  );
}
async function _0x55858d(
  _0x1484a0,
  _0x40caa3,
  _0x251029,
  _0x5a0811,
  _0x15a184,
  _0x5a375f,
  _0x2ae70c,
  _0x147c3d,
  _0x2c74b8,
  _0x35b011,
) {
  var _0x15afdb = await _0x52d13d(_0x1484a0);
  _0x15afdb = await _0x94e810(_0x15afdb, _0x2ae70c, _0x147c3d);
  var _0x2f39b1 = await _0x52d13d(_0x251029);
  _0x2f39b1 = await _0x3cadab(_0x2f39b1, 0.45 * _0x147c3d, 0.45 * _0x2ae70c);
  var _0xf38c4c = await _0x52d13d(_0x40caa3);
  ((_0xf38c4c = await _0x3cadab(_0xf38c4c, 0.45 * _0x147c3d, 0.45 * _0x2ae70c)),
    (_0x15afdb = await _0x267896(_0x15afdb, _0xf38c4c, "right")),
    (_0xf38c4c = await _0x3cadab(_0xf38c4c, 0.4 * _0x147c3d, 0.4 * _0x2ae70c)),
    (_0x2f39b1 = await _0x3cadab(_0x2f39b1, 0.4 * _0x147c3d, 0.4 * _0x2ae70c)),
    (_0x15afdb = await _0x347fe4(_0x15afdb, _0xf38c4c, 0x1, 0xc)),
    (_0x2f39b1 = await _0x1aa8bc(_0x2f39b1)),
    (_0x15afdb = await _0x57f2c5(_0x15afdb, _0x2f39b1, 0.7)));
  var _0x505db1 = await _0x52d13d(_0x5a0811);
  ((_0x505db1 = await _0x45ee1d(_0x505db1)),
    (_0x505db1 = await _0x3cadab(
      _0x505db1,
      0.45 * _0x147c3d,
      0.45 * _0x2ae70c,
    )));
  var _0x1da379 = await _0x52d13d(_0x15a184);
  _0x1da379 = await _0x45ee1d(_0x1da379);
  if (
    (_0x1da379 = await _0x3cadab(
      _0x1da379,
      0.45 * _0x147c3d,
      0.45 * _0x2ae70c,
    ))["width"] >= _0x505db1["width"]
  )
    ((_0x15afdb = await _0x267896(_0x15afdb, _0x1da379, "left")),
      (_0x1da379 = await _0x3cadab(
        _0x1da379,
        0.4 * _0x147c3d,
        0.4 * _0x2ae70c,
      )),
      (_0x505db1 = await _0x3cadab(
        _0x505db1,
        0.4 * _0x147c3d,
        0.4 * _0x2ae70c,
      )),
      (_0x15afdb = await _0x38a26e(_0x15afdb, _0x1da379, 0x1, 0xc)),
      (_0x15afdb = await _0x39cbd4(_0x15afdb, _0x505db1, 0x1)));
  else
    _0x505db1["width"] > _0x1da379["width"] &&
      ((_0x15afdb = await _0x267896(_0x15afdb, _0x505db1, "left")),
      (_0x1da379 = await _0x3cadab(
        _0x1da379,
        0.4 * _0x147c3d,
        0.4 * _0x2ae70c,
      )),
      (_0x505db1 = await _0x3cadab(
        _0x505db1,
        0.4 * _0x147c3d,
        0.4 * _0x2ae70c,
      )),
      (_0x15afdb = await _0x39cbd4(_0x15afdb, _0x505db1, 0x1)),
      (_0x15afdb = await _0x38a26e(_0x15afdb, _0x1da379, 0x1, 0xc)));
  return await _0x2db71b(_0x15afdb, 0x1f4, 0x1f4);
}
function _0x27e504(_0x466757, _0x2ed0a6, _0xcd1d82) {
  return new Promise((_0x483bdd, _0x65b6fc) => {
    var _0x54c5d2 = document["createElement"]("canvas");
    ((_0x54c5d2["width"] = _0x466757["width"]),
      (_0x54c5d2["height"] = _0x466757["height"]));
    var _0x5938d0 = _0x54c5d2["getContext"]("2d");
    (_0x5938d0["drawImage"](_0x466757, 0x0, 0x0),
      (_0x5938d0["strokeStyle"] = _0x2ed0a6),
      (_0x5938d0["lineWidth"] = _0xcd1d82),
      _0x5938d0["strokeRect"](
        0x0,
        0x0,
        _0x54c5d2["width"],
        _0x54c5d2["height"],
      ));
    var _0x2c0501 = new Image();
    ((_0x2c0501["onload"] = function () {
      _0x483bdd(_0x2c0501);
    }),
      (_0x2c0501["src"] = _0x54c5d2["toDataURL"]()));
  });
}
async function _0x3ca617(
  _0x521fe3,
  _0x36c1e6,
  _0x332d48,
  _0x1c495e,
  _0x282331,
  _0x3f6afa,
  _0xed06a4,
) {
  var _0x2687f1 = await _0x52d13d(_0x521fe3);
  _0x2687f1 = await _0x94e810(_0x2687f1, _0x1c495e, _0x282331);
  var _0x496b1c = await _0x52d13d(
    "https://centreforinquiry.ca/wp-content/uploads/2020/05/68353859-canadian-map-with-canada-flag.jpg",
  );
  ((_0x496b1c = await _0x94e810(_0x496b1c, 0.45 * _0x282331, 0.45 * _0x1c495e)),
    (_0x2687f1 = await _0x3b1e22(_0x2687f1, _0x496b1c, 0.75)));
  var _0x19f92e = await _0x52d13d(_0x36c1e6);
  return (
    (_0x19f92e = await _0x45ee1d(_0x19f92e)),
    (_0x19f92e = await _0x512ce1(_0x19f92e)),
    (_0x19f92e = await _0x3c2184(_0x19f92e, 0xa)),
    (_0x19f92e = await _0x94e810(
      _0x19f92e,
      0.45 * _0x282331,
      0.45 * _0x1c495e,
    )),
    (_0x2687f1 = await _0x3f9f31(_0x2687f1, _0x19f92e, 0.95)),
    (_0x2687f1 = await _0x36d1f2(_0x2687f1, _0x332d48, _0x3f6afa, _0xed06a4)),
    await _0x45ee1d(_0x2687f1)
  );
}
function _0x45ee1d(_0x88b159) {
  return new Promise(function (_0x29d08f, _0x10d13a) {
    let _0x4863f6 = document["createElement"]("canvas");
    ((_0x4863f6["width"] = _0x88b159["width"]),
      (_0x4863f6["height"] = _0x88b159["height"]));
    let _0x2e1e85 = _0x4863f6["getContext"]("2d");
    ((_0x2e1e85["fillStyle"] = "white"),
      _0x2e1e85["fillRect"](0x0, 0x0, _0x4863f6["width"], _0x4863f6["height"]),
      _0x2e1e85["drawImage"](
        _0x88b159,
        0x0,
        0x0,
        _0x4863f6["width"],
        _0x4863f6["height"],
      ),
      (_0x2e1e85["strokeStyle"] = "black"),
      (_0x2e1e85["lineWidth"] = 0x1e),
      _0x2e1e85["strokeRect"](
        0x0,
        0x0,
        _0x4863f6["width"],
        _0x4863f6["height"],
      ));
    var _0x221f08 = new Image();
    ((_0x221f08["onload"] = function () {
      _0x29d08f(_0x221f08);
    }),
      (_0x221f08["src"] = _0x4863f6["toDataURL"]()));
  });
}
function _0x3f9f31(_0xd314de, _0x208a79, _0x56c784) {
  return new Promise(function (_0x8a6625, _0x1db8ba) {
    let _0x2f765a = document["createElement"]("canvas");
    ((_0x2f765a["width"] = _0xd314de["width"]),
      (_0x2f765a["height"] = _0xd314de["height"]));
    let _0x9ef8a4 = _0x2f765a["getContext"]("2d");
    ((_0x9ef8a4["fillStyle"] = "white"),
      _0x9ef8a4["fillRect"](0x0, 0x0, _0x2f765a["width"], _0x2f765a["height"]),
      _0x9ef8a4["drawImage"](_0xd314de, 0x0, 0x0),
      (_0x9ef8a4["globalAlpha"] = _0x56c784));
    var _0x1ffd18 =
        _0x2f765a["width"] - _0x208a79["width"] - _0x2f765a["width"] / 0x32,
      _0x1e4da5 =
        _0x2f765a["height"] - _0x208a79["height"] - _0x2f765a["height"] / 0xc;
    _0x9ef8a4["drawImage"](_0x208a79, _0x1ffd18, _0x1e4da5);
    var _0x7377ba = new Image();
    ((_0x7377ba["onload"] = function () {
      _0x8a6625(_0x7377ba);
    }),
      (_0x7377ba["src"] = _0x2f765a["toDataURL"]()));
  });
}
async function _0x5d695a(
  _0x241a91,
  _0x3ba3ea,
  _0x53a2cc,
  _0x2e6849,
  _0x435fef,
) {
  var _0x51a8cf = localStorage["getItem"]("waterMarkUrl"),
    _0x22071c = await _0x52d13d(_0x241a91);
  _0x22071c = await _0x94e810(_0x22071c, _0x2e6849, _0x435fef);
  var _0x1ac2b5 = await _0x52d13d(_0x51a8cf);
  ((_0x1ac2b5 = await _0x94e810(_0x1ac2b5, 0.4 * _0x435fef, 0.4 * _0x2e6849)),
    (_0x22071c = await _0x3b1e22(_0x22071c, _0x1ac2b5, 0.75)),
    (_0x22071c = await _0x36d1f2(_0x22071c, _0x3ba3ea)),
    upload(_0x22071c["src"], _0x3ba3ea, _0x53a2cc));
}
async function _0x18200b(
  _0xb3fb80,
  _0x3f93bf,
  _0x17edb9,
  _0x37b9bd,
  _0x105e9a,
) {
  localStorage["getItem"]("waterMarkUrl");
  var _0x33e195 = await _0x52d13d(_0xb3fb80);
  ((_0x33e195 = await _0x3c2184(_0x33e195, 0x0)),
    (_0x33e195 = await _0x94e810(_0x33e195, _0x37b9bd, _0x105e9a)),
    upload(_0x33e195["src"], _0x3f93bf, _0x17edb9));
}
function _0xbdc0d8(_0x3998ee) {
  var _0xc69163 = document["createElement"]("img");
  ((_0xc69163["src"] = _0x3998ee),
    document["getElementsByTagName"]("html")[0x0]["appendChild"](_0xc69163));
}
function _0x2d1a1b(_0x47b558) {
  return new Promise(function (_0x343385, _0x5ecbf7) {
    var _0xed72f9 = new Image();
    ((_0xed72f9["src"] = _0x47b558),
      (_0xed72f9["crossOrigin"] = "anonymous"),
      (_0xed72f9["onload"] = function () {
        _0x343385(_0xed72f9);
      }));
  });
}
async function _0x36d1f2(_0x29e6d3, _0x1a326d, _0x49f4db, _0x4c6787) {
  var _0x30f022 = await _0x454514(_0x29e6d3, _0x1a326d, _0x49f4db, _0x4c6787);
  return await _0x373166(_0x29e6d3, _0x1a326d, _0x30f022, _0x49f4db, _0x4c6787);
}
function _0x373166(_0x2baf5d, _0x5e0cac, _0x45d05a, _0x42bc1e, _0x2ecddf) {
  return new Promise(function (_0x362879, _0xf7c1a3) {
    var _0x30ae40 = document["createElement"]("canvas");
    _0x30ae40["id"] = "myCanvas";
    var _0x388dd4 = (_0x2baf5d["height"] / 0xa) * 0.45,
      _0x1f36e3 = _0x388dd4 + _0x388dd4 / 0x2,
      _0x2fcc57 = _0x388dd4;
    ((_0x30ae40["width"] = _0x2baf5d["width"]),
      (_0x30ae40["height"] = _0x2baf5d["height"] + _0x1f36e3 * _0x45d05a));
    var _0x41eee2 = _0x30ae40["getContext"]("2d");
    ((_0x41eee2["fillStyle"] = "white"),
      _0x41eee2["fillRect"](0x0, 0x0, _0x30ae40["width"], _0x30ae40["height"]));
    var _0x4e9b08 = _0x30ae40["width"],
      _0x54600f = _0x30ae40["height"] * (0x46 / 0x5dc);
    ((_0x41eee2["fillStyle"] = _0x42bc1e),
      (_0x41eee2["font"] = _0x388dd4 + "px\x20" + _0x2ecddf),
      _0x56c39e(_0x41eee2, _0x5e0cac, 0x0, _0x2fcc57, _0x4e9b08, _0x54600f),
      _0x41eee2["drawImage"](_0x2baf5d, 0x0, _0x1f36e3 * _0x45d05a));
    let _0x549482 = new Image();
    ((_0x549482["crossOrigin"] = "anonymous"),
      (_0x549482["src"] = _0x30ae40["toDataURL"]()),
      (_0x549482["onload"] = function () {
        _0x362879(_0x549482);
      }));
  });
}
function _0x2dc597(_0x5b6cb0) {
  var _0x23dd2d = (_0x5b6cb0["height"] / 0xa) * 1.5,
    _0x5a16a0 = _0x23dd2d + _0x23dd2d / 0x2,
    _0xd0bace = _0x23dd2d;
  return new Promise(function (_0x2b91b3, _0x57364b) {
    var _0x4ce376 = document["createElement"]("canvas");
    ((_0x4ce376["id"] = "myCanvas"),
      (_0x4ce376["width"] = _0x5b6cb0["width"]),
      (_0x4ce376["height"] = _0x5b6cb0["height"] + 0x1 * _0x5a16a0));
    var _0xdac094 = _0x4ce376["getContext"]("2d");
    ((_0xdac094["fillStyle"] = "white"),
      _0xdac094["fillRect"](0x0, 0x0, _0x4ce376["width"], _0x4ce376["height"]),
      _0x4ce376["width"],
      (_0xdac094["fillStyle"] = "#F79148"),
      (_0xdac094["font"] = "bold\x20" + _0x23dd2d + "px\x20Arial"),
      _0xdac094["fillText"]("Look\x20", 0x0, _0xd0bace));
    var _0x227b7c = _0xdac094["measureText"]("Look\x20")["width"];
    ((_0xdac094["fillStyle"] = "#34B8FF"),
      (_0xdac094["font"] = "bold\x20" + _0x23dd2d + "px\x20Arial"),
      _0xdac094["fillText"]("Inside\x20⤸", 0x0 + _0x227b7c, _0xd0bace),
      _0xdac094["drawImage"](_0x5b6cb0, 0x0, 0x1 * _0x5a16a0));
    var _0x18fc31 = new Image();
    ((_0x18fc31["crossOrigin"] = "anonymous"),
      (_0x18fc31["src"] = _0x4ce376["toDataURL"]()),
      (_0x18fc31["onload"] = function () {
        _0x2b91b3(_0x18fc31);
      }));
  });
}
function _0x1e4ac5(_0x489905, _0x4d26b1, _0xa3bf7d) {
  _0xa3bf7d += "\x20⤸";
  var _0x520b98 = _0x489905["width"],
    _0x238878 = _0x489905["width"] / 0xa,
    _0x59d8bc = _0x238878 + _0x238878 / 0x2,
    _0x260d67 = _0x238878;
  return new Promise(function (_0x2acd24, _0x4b1996) {
    var _0x4adfd5 = document["createElement"]("canvas");
    ((_0x4adfd5["id"] = "myCanvas"),
      (_0x4adfd5["width"] = _0x489905["width"]),
      (_0x4adfd5["height"] = _0x489905["height"] + 0x1 * _0x59d8bc));
    var _0x7ff636 = _0x4adfd5["getContext"]("2d");
    ((_0x7ff636["fillStyle"] = "white"),
      _0x7ff636["fillRect"](0x0, 0x0, _0x4adfd5["width"], _0x4adfd5["height"]),
      (_0x7ff636["fillStyle"] = "#34B8FF"),
      (_0x7ff636["font"] = "bold\x20" + _0x238878 + "px\x20Arial"),
      _0x7ff636["fillText"](_0x4d26b1, 0x0, _0x260d67));
    var _0x1fbe83 = _0x7ff636["measureText"](_0x4d26b1)["width"],
      _0x1d7de7 = ((_0x520b98 - _0x1fbe83) / _0xa3bf7d["length"]) * 0x2;
    ((_0x7ff636["fillStyle"] = "#F79148"),
      (_0x7ff636["font"] = "bold\x20" + _0x1d7de7 + "px\x20Arial"),
      _0x7ff636["fillText"](_0xa3bf7d, 0x0 + _0x1fbe83, _0x260d67),
      _0x7ff636["drawImage"](_0x489905, 0x0, 0x1 * _0x59d8bc));
    var _0x1f18b9 = new Image();
    ((_0x1f18b9["crossOrigin"] = "anonymous"),
      (_0x1f18b9["src"] = _0x4adfd5["toDataURL"]()),
      (_0x1f18b9["onload"] = function () {
        _0x2acd24(_0x1f18b9);
      }));
  });
}
function _0x454514(_0x324965, _0x498695, _0x498888, _0x2ebc5a) {
  return new Promise((_0x6c3e40) => {
    var _0x4e9926 = document["createElement"]("canvas");
    _0x4e9926["id"] = "myCanvas";
    var _0x149a86 = (_0x324965["height"] / 0xa) * 0.45,
      _0x35981b = _0x149a86;
    ((_0x4e9926["width"] = _0x324965["width"]),
      (_0x4e9926["height"] = _0x324965["height"]));
    var _0x4e6efb = _0x4e9926["getContext"]("2d");
    ((_0x4e6efb["fillStyle"] = "white"),
      _0x4e6efb["fillRect"](0x0, 0x0, _0x4e9926["width"], _0x4e9926["height"]));
    var _0x3e44f8 = _0x4e9926["width"],
      _0x5e235b = _0x4e9926["height"] * (0x46 / 0x5dc);
    ((_0x4e6efb["fillStyle"] = _0x498888),
      (_0x4e6efb["font"] = _0x149a86 + "px\x20" + _0x2ebc5a));
    var _0x42538e = 0x1,
      _0x3747a9 = _0x498695["split"]("\x20"),
      _0x4caa20 = "";
    for (var _0x3dbe34 = 0x0; _0x3dbe34 < _0x3747a9["length"]; _0x3dbe34++) {
      var _0xbc29f0 = _0x4caa20 + _0x3747a9[_0x3dbe34] + "\x20";
      if (
        _0x4e6efb["measureText"](_0xbc29f0)["width"] > _0x3e44f8 &&
        _0x3dbe34 > 0x0
      )
        (_0x42538e++,
          _0x4e6efb["fillText"](_0x4caa20, 0x0, _0x35981b),
          (_0x4caa20 = _0x3747a9[_0x3dbe34] + "\x20"),
          (_0x35981b += _0x5e235b));
      else _0x4caa20 = _0xbc29f0;
    }
    _0x6c3e40(_0x42538e);
  });
}
function _0x56c39e(
  _0xe95f02,
  _0x2283ef,
  _0x1dffaf,
  _0x48a0e7,
  _0x488d47,
  _0x55874b,
) {
  var _0x3bcf7a = _0x2283ef["split"]("\x20"),
    _0x14bd73 = "";
  for (var _0x4290a3 = 0x0; _0x4290a3 < _0x3bcf7a["length"]; _0x4290a3++) {
    var _0x1fe98c = _0x14bd73 + _0x3bcf7a[_0x4290a3] + "\x20";
    if (
      _0xe95f02["measureText"](_0x1fe98c)["width"] > _0x488d47 &&
      _0x4290a3 > 0x0
    )
      (_0xe95f02["fillText"](_0x14bd73, _0x1dffaf, _0x48a0e7),
        (_0x14bd73 = _0x3bcf7a[_0x4290a3] + "\x20"),
        (_0x48a0e7 += _0x55874b));
    else _0x14bd73 = _0x1fe98c;
  }
  _0xe95f02["fillText"](_0x14bd73, _0x1dffaf, _0x48a0e7);
}
function _0x512ce1(_0x206be8) {
  return new Promise(function (_0x235f03, _0x590316) {
    var _0x1f05d3 = document["createElement"]("canvas");
    ((_0x1f05d3["id"] = "myCanvas"),
      (_0x1f05d3["width"] = _0x206be8["width"]),
      (_0x1f05d3["height"] = _0x206be8["height"]));
    var _0x3ddfd2 = _0x1f05d3["getContext"]("2d");
    ((_0x3ddfd2["fillStyle"] = "white"),
      _0x3ddfd2["fillRect"](0x0, 0x0, _0x1f05d3["width"], _0x1f05d3["height"]),
      _0x3ddfd2["translate"](_0x1f05d3["width"], 0x0),
      _0x3ddfd2["scale"](-0x1, 0x1),
      _0x3ddfd2["drawImage"](_0x206be8, 0x0, 0x0));
    let _0x143722 = new Image();
    ((_0x143722["crossOrigin"] = "anonymous"),
      (_0x143722["src"] = _0x1f05d3["toDataURL"]()),
      (_0x143722["onload"] = function () {
        _0x235f03(_0x143722);
      }));
  });
}
function _0x94e810(_0x379101, _0x109cf5, _0x303ce5) {
  return new Promise(function (_0x2a442a, _0x4092bc) {
    var _0x1df36c = document["createElement"]("canvas");
    ((_0x1df36c["id"] = "myCanvas"),
      (_0x1df36c["width"] = _0x109cf5),
      (_0x1df36c["height"] = _0x303ce5));
    var _0x4edf0c = _0x1df36c["getContext"]("2d");
    ((_0x4edf0c["fillStyle"] = "white"),
      _0x4edf0c["fillRect"](0x0, 0x0, _0x1df36c["width"], _0x1df36c["height"]));
    var _0x50f5a5 = _0x109cf5 / 0x2,
      _0x59464e = _0x303ce5 / 0x2,
      _0x4e03d0 = 0x1;
    (_0x379101["width"] > _0x379101["height"] &&
      (_0x4e03d0 = _0x109cf5 / _0x379101["width"]),
      _0x379101["width"] < _0x379101["height"] &&
        (_0x4e03d0 = _0x109cf5 / _0x379101["height"]),
      _0x379101["width"] === _0x379101["height"] &&
        (_0x4e03d0 = _0x109cf5 / _0x379101["height"]));
    var _0xd71f99 = _0x379101["width"] * _0x4e03d0,
      _0x327a7b = _0x379101["height"] * _0x4e03d0;
    ((_0x4edf0c["globalAlpha"] = 0x1),
      _0x4edf0c["drawImage"](
        _0x379101,
        _0x50f5a5 - _0xd71f99 / 0x2,
        _0x59464e - _0x327a7b / 0x2,
        _0xd71f99,
        _0x327a7b,
      ));
    let _0x56dbfc = new Image();
    ((_0x56dbfc["crossOrigin"] = "anonymous"),
      (_0x56dbfc["src"] = _0x1df36c["toDataURL"]()),
      (_0x56dbfc["onload"] = function () {
        _0x2a442a(_0x56dbfc);
      }));
  });
}
function _0x3cadab(_0x357ff3, _0x468c69, _0x1181c0) {
  return new Promise(function (_0x4b4ab9, _0x41a2d3) {
    var _0x31abb8 = 0x1;
    (_0x357ff3["width"] > _0x357ff3["height"] &&
      (_0x31abb8 = _0x468c69 / _0x357ff3["width"]),
      _0x357ff3["width"] < _0x357ff3["height"] &&
        (_0x31abb8 = _0x468c69 / _0x357ff3["height"]),
      _0x357ff3["width"] === _0x357ff3["height"] &&
        (_0x31abb8 = _0x468c69 / _0x357ff3["height"]));
    var _0x280b26 = _0x357ff3["width"] * _0x31abb8,
      _0x404bbc = _0x357ff3["height"] * _0x31abb8,
      _0x30638f = document["createElement"]("canvas");
    ((_0x30638f["id"] = "myCanvas"),
      (_0x30638f["width"] = _0x280b26),
      (_0x30638f["height"] = _0x404bbc),
      (_0x30638f["style"] = "border:2px\x20solid\x20black;"));
    var _0x11766b = _0x30638f["getContext"]("2d");
    ((_0x11766b["fillStyle"] = "white"),
      _0x11766b["fillRect"](0x0, 0x0, _0x30638f["width"], _0x30638f["height"]),
      (_0x11766b["globalAlpha"] = 0x1),
      _0x11766b["drawImage"](_0x357ff3, 0x0, 0x0, _0x280b26, _0x404bbc));
    let _0x484288 = new Image();
    ((_0x484288["crossOrigin"] = "anonymous"),
      (_0x484288["src"] = _0x30638f["toDataURL"]()),
      (_0x484288["onload"] = function () {
        _0x4b4ab9(_0x484288);
      }));
  });
}
function _0x18447a(_0x58220a) {
  return new Promise(function (_0x66aa67, _0x13aed6) {
    const _0x2bae1b = Math["max"](_0x58220a["width"], _0x58220a["height"]),
      _0x495945 = document["createElement"]("canvas");
    ((_0x495945["width"] = _0x2bae1b), (_0x495945["height"] = _0x2bae1b));
    const _0x291bad = _0x495945["getContext"]("2d");
    ((_0x291bad["fillStyle"] = "white"),
      _0x291bad["fillRect"](0x0, 0x0, _0x495945["width"], _0x495945["height"]));
    const _0x6f99e0 = (_0x2bae1b - _0x58220a["width"]) / 0x2,
      _0x5a3bff = (_0x2bae1b - _0x58220a["height"]) / 0x2;
    _0x291bad["drawImage"](
      _0x58220a,
      _0x6f99e0,
      _0x5a3bff,
      _0x58220a["width"],
      _0x58220a["height"],
    );
    const _0x32579e = new Image();
    ((_0x32579e["onload"] = function () {
      _0x66aa67(_0x32579e);
    }),
      (_0x32579e["src"] = _0x495945["toDataURL"]()));
  });
}
function _0x2db71b(_0x19fda0, _0xa19d2d, _0x389097) {
  return new Promise(function (_0x1f2067, _0x3e378e) {
    var _0x4006a2 = _0x19fda0["width"],
      _0x2b8507 = _0x19fda0["height"];
    if (_0x4006a2 < _0xa19d2d || _0x2b8507 < _0x389097) {
      var _0x4d5edf = document["createElement"]("canvas"),
        _0x369a3d = _0x4d5edf["getContext"]("2d"),
        _0x14d689 = Math["max"](_0xa19d2d / _0x4006a2, _0x389097 / _0x2b8507);
      ((_0x4006a2 *= _0x14d689),
        (_0x2b8507 *= _0x14d689),
        (_0x4d5edf["width"] = _0x4006a2),
        (_0x4d5edf["height"] = _0x2b8507),
        _0x369a3d["drawImage"](_0x19fda0, 0x0, 0x0, _0x4006a2, _0x2b8507));
      var _0x50da9b = new Image();
      ((_0x50da9b["src"] = _0x4d5edf["toDataURL"]()),
        (_0x50da9b["onload"] = function () {
          _0x1f2067(_0x50da9b);
        }));
    } else _0x1f2067(_0x19fda0);
  });
}
function _0x464df3(_0x50eb59, _0xe8e984, _0x1c9cc8) {
  return new Promise(function (_0x12ba0b, _0x4c4a6e) {
    var _0x49906c = 0x1;
    (_0x50eb59["width"] > _0x50eb59["height"] &&
      (_0x49906c = _0xe8e984 / _0x50eb59["width"]),
      _0x50eb59["width"] < _0x50eb59["height"] &&
        (_0x49906c = _0xe8e984 / _0x50eb59["height"]),
      _0x50eb59["width"] === _0x50eb59["height"] &&
        (_0x49906c = _0xe8e984 / _0x50eb59["height"]));
    var _0x5bff92 = _0x50eb59["width"] * _0x49906c,
      _0x4ac789 = _0x50eb59["height"] * _0x49906c,
      _0x6116e2 = 0x1;
    for (; _0x5bff92 > _0xe8e984; ) {
      ((_0x5bff92 = _0x50eb59["width"] * _0x6116e2),
        (_0x4ac789 = _0x50eb59["height"] * _0x6116e2),
        (_0x6116e2 -= 0.01));
    }
    var _0x3a1a05 = document["createElement"]("canvas");
    ((_0x3a1a05["id"] = "myCanvas"),
      (_0x3a1a05["width"] = _0x5bff92),
      (_0x3a1a05["height"] = _0x4ac789),
      (_0x3a1a05["style"] = "border:2px\x20solid\x20black;"));
    var _0x2e62f3 = _0x3a1a05["getContext"]("2d");
    ((_0x2e62f3["fillStyle"] = "white"),
      _0x2e62f3["fillRect"](0x0, 0x0, _0x3a1a05["width"], _0x3a1a05["height"]),
      (_0x2e62f3["globalAlpha"] = 0x1),
      _0x2e62f3["drawImage"](_0x50eb59, 0x0, 0x0, _0x5bff92, _0x4ac789));
    let _0x4e5013 = new Image();
    ((_0x4e5013["crossOrigin"] = "anonymous"),
      (_0x4e5013["src"] = _0x3a1a05["toDataURL"]()),
      (_0x4e5013["onload"] = function () {
        _0x12ba0b(_0x4e5013);
      }));
  });
}
function _0x2a8417(_0x3bfb89) {
  return new Promise((_0x41ccf3, _0x2a493b) => {
    var _0x4425a2 = document["createElement"]("canvas")["getContext"]("2d"),
      _0x4c5ddd = new Image();
    ((_0x4c5ddd["onload"] = function () {
      (_0x4425a2["drawImage"](_0x4c5ddd, 0x0, 0x0), _0x41ccf3(_0x4c5ddd));
    }),
      (_0x4c5ddd["src"] = _0x3bfb89));
  });
}
function _0x3b1e22(_0x4dd1a3, _0x32110b, _0x1d3fcd) {
  return new Promise(function (_0x49962e, _0x2a1729) {
    let _0x3906e9 = document["createElement"]("canvas");
    ((_0x3906e9["width"] = _0x4dd1a3["width"] + _0x32110b["width"]),
      (_0x3906e9["height"] = _0x4dd1a3["height"]));
    let _0x4f8bc0 = _0x3906e9["getContext"]("2d");
    ((_0x4f8bc0["fillStyle"] = "white"),
      _0x4f8bc0["fillRect"](0x0, 0x0, _0x3906e9["width"], _0x3906e9["height"]),
      _0x4f8bc0["drawImage"](_0x4dd1a3, 0x0, 0x0),
      (_0x4f8bc0["globalAlpha"] = _0x1d3fcd));
    var _0x217fa3 = 0.9 * _0x32110b["width"],
      _0x52660c = 0.9 * _0x32110b["height"];
    _0x4f8bc0["drawImage"](
      _0x32110b,
      _0x3906e9["width"] - _0x217fa3,
      0x0,
      _0x217fa3,
      _0x52660c,
    );
    var _0x22830b = new Image();
    ((_0x22830b["onload"] = function () {
      _0x49962e(_0x22830b);
    }),
      (_0x22830b["src"] = _0x3906e9["toDataURL"]()));
  });
}
function _0x3c2184(_0x172f0c, _0x9ce9ef) {
  return new Promise(function (_0x3ba526, _0x380531) {
    var _0x43d1fa = document["createElement"]("canvas"),
      _0x4d3474 = _0x43d1fa["getContext"]("2d");
    ((_0x4d3474["fillStyle"] = "white"),
      _0x4d3474["fillRect"](0x0, 0x0, _0x43d1fa["width"], _0x43d1fa["height"]));
    var _0x229c89 = (_0x9ce9ef * Math["PI"]) / 0xb4,
      _0x104a71 = Math["cos"](_0x229c89),
      _0x48ad5e = Math["sin"](_0x229c89);
    (_0x48ad5e < 0x0 && (_0x48ad5e = -_0x48ad5e),
      _0x104a71 < 0x0 && (_0x104a71 = -_0x104a71),
      (_0x43d1fa["width"] =
        _0x172f0c["height"] * _0x48ad5e + _0x172f0c["width"] * _0x104a71),
      (_0x43d1fa["height"] =
        _0x172f0c["height"] * _0x104a71 + _0x172f0c["width"] * _0x48ad5e));
    var _0x91e3b1 = _0x172f0c["width"],
      _0x992180 = _0x172f0c["height"],
      _0x842fb0 = _0x43d1fa["width"] / 0x2,
      _0x539934 = _0x43d1fa["height"] / 0x2,
      _0x127e0e = Math["PI"] / 0xb4;
    (_0x4d3474["translate"](_0x842fb0, _0x539934),
      _0x4d3474["rotate"](_0x9ce9ef * _0x127e0e),
      _0x4d3474["drawImage"](
        _0x172f0c,
        -_0x91e3b1 / 0x2,
        -_0x992180 / 0x2,
        _0x91e3b1,
        _0x992180,
      ));
    var _0x21db35 = new Image();
    ((_0x21db35["onload"] = function () {
      _0x3ba526(_0x21db35);
    }),
      (_0x21db35["src"] = _0x43d1fa["toDataURL"]()));
  });
}
function _0x267896(_0x5e0c40, _0x2f745f, _0x16b66a) {
  return new Promise(function (_0x6ae2be, _0x4590be) {
    let _0x471ce0 = document["createElement"]("canvas");
    ((_0x471ce0["width"] = _0x5e0c40["width"] + _0x2f745f["width"]),
      (_0x471ce0["height"] = _0x5e0c40["height"]));
    let _0x3e71c9 = _0x471ce0["getContext"]("2d");
    ((_0x3e71c9["fillStyle"] = "white"),
      _0x3e71c9["fillRect"](0x0, 0x0, _0x471ce0["width"], _0x471ce0["height"]));
    var _0x260c32 = _0x2f745f["width"];
    (_0x2f745f["height"],
      "left" === _0x16b66a
        ? _0x3e71c9["drawImage"](_0x5e0c40, _0x260c32, 0x0)
        : "right" === _0x16b66a && _0x3e71c9["drawImage"](_0x5e0c40, 0x0, 0x0));
    var _0x5daf46 = new Image();
    ((_0x5daf46["onload"] = function () {
      _0x6ae2be(_0x5daf46);
    }),
      (_0x5daf46["src"] = _0x471ce0["toDataURL"]()));
  });
}
function _0x52ffcf(_0x179bbe, _0x25c1ba, _0x7e682b) {
  return new Promise(function (_0x5e5358, _0x5981e6) {
    let _0x465392 = document["createElement"]("canvas");
    ((_0x465392["width"] = _0x179bbe["width"] + _0x25c1ba),
      (_0x465392["height"] = _0x179bbe["height"]));
    let _0xc1e729 = _0x465392["getContext"]("2d");
    ((_0xc1e729["fillStyle"] = "white"),
      _0xc1e729["fillRect"](0x0, 0x0, _0x465392["width"], _0x465392["height"]));
    var _0x33e9a2 = _0x25c1ba;
    "top" === _0x7e682b
      ? _0xc1e729["drawImage"](_0x179bbe, 0x0, _0x33e9a2)
      : "botttom" === _0x7e682b && _0xc1e729["drawImage"](_0x179bbe, 0x0, 0x0);
    var _0x1a51b8 = new Image();
    ((_0x1a51b8["onload"] = function () {
      _0x5e5358(_0x1a51b8);
    }),
      (_0x1a51b8["src"] = _0x465392["toDataURL"]()));
  });
}
function _0xe4c42c(_0x3b65c4) {
  return new Promise(function (_0x366bb1, _0x52dc42) {
    let _0x4e19fa = document["createElement"]("canvas");
    console["log"]("Making\x20image\x20aspect\x20same");
    if (_0x3b65c4["width"] > _0x3b65c4["height"])
      ((_0x4e19fa["width"] = _0x3b65c4["width"]),
        (_0x4e19fa["height"] =
          _0x3b65c4["height"] + (_0x3b65c4["width"] - _0x3b65c4["height"])));
    else
      _0x3b65c4["width"] < _0x3b65c4["height"]
        ? ((_0x4e19fa["height"] = _0x3b65c4["height"]),
          (_0x4e19fa["width"] =
            _0x3b65c4["width"] + (_0x3b65c4["height"] - _0x3b65c4["width"])))
        : (console["log"]("Image\x20is\x20already\x20a\x20square"),
          _0x366bb1(_0x3b65c4));
    console["log"]("Done\x20making\x20image\x20aspect\x20same");
    let _0x6780e7 = _0x4e19fa["getContext"]("2d");
    ((_0x6780e7["fillStyle"] = "white"),
      _0x6780e7["fillRect"](0x0, 0x0, _0x4e19fa["width"], _0x4e19fa["height"]),
      _0x6780e7["drawImage"](
        _0x3b65c4,
        (_0x4e19fa["width"] - _0x3b65c4["width"]) / 0x2,
        (_0x4e19fa["height"] - _0x3b65c4["height"]) / 0x2,
      ));
    var _0x3abcb4 = new Image();
    ((_0x3abcb4["onload"] = function () {
      _0x366bb1(_0x3abcb4);
    }),
      (_0x3abcb4["src"] = _0x4e19fa["toDataURL"]()));
  });
}
function _0x39cbd4(_0x2ab617, _0x2b1bf7, _0x104ca7) {
  return new Promise(function (_0x4f5cad, _0x4b6423) {
    let _0x8b5197 = document["createElement"]("canvas");
    ((_0x8b5197["width"] = _0x2ab617["width"]),
      (_0x8b5197["height"] = _0x2ab617["height"]));
    let _0x42a088 = _0x8b5197["getContext"]("2d");
    ((_0x42a088["fillStyle"] = "white"),
      _0x42a088["fillRect"](0x0, 0x0, _0x8b5197["width"], _0x8b5197["height"]));
    var _0x3c7f4d = _0x2b1bf7["width"],
      _0x5ead8f = _0x2b1bf7["height"];
    (_0x42a088["drawImage"](_0x2ab617, 0x0, 0x0),
      (_0x42a088["globalAlpha"] = _0x104ca7));
    var _0x2df6c6 = 0x0 + _0x8b5197["width"] / 0x32;
    _0x42a088["drawImage"](_0x2b1bf7, _0x2df6c6, 0x0, _0x3c7f4d, _0x5ead8f);
    var _0x3d12f7 = new Image();
    ((_0x3d12f7["onload"] = function () {
      _0x4f5cad(_0x3d12f7);
    }),
      (_0x3d12f7["src"] = _0x8b5197["toDataURL"]()));
  });
}
function _0x57f2c5(_0x2724a4, _0x502705, _0x28e76d) {
  return new Promise(async function (_0x250171, _0x56b582) {
    let _0x550b73 = document["createElement"]("canvas");
    ((_0x550b73["width"] = _0x2724a4["width"]),
      (_0x550b73["height"] = _0x2724a4["height"]));
    let _0x1761ab = _0x550b73["getContext"]("2d");
    ((_0x1761ab["fillStyle"] = "white"),
      _0x1761ab["fillRect"](0x0, 0x0, _0x550b73["width"], _0x550b73["height"]),
      _0x1761ab["drawImage"](_0x2724a4, 0x0, 0x0),
      (_0x1761ab["globalAlpha"] = _0x28e76d),
      _0x1761ab["drawImage"](
        _0x502705,
        _0x550b73["width"] - _0x502705["width"],
        0x0,
        _0x502705["width"],
        _0x502705["height"],
      ));
    var _0x291114 = new Image();
    ((_0x291114["onload"] = function () {
      _0x250171(_0x291114);
    }),
      (_0x291114["src"] = _0x550b73["toDataURL"]()));
  });
}
function _0x140013(_0x209042, _0x3ba940, _0x256f1f) {
  return new Promise(function (_0x2cf8fd, _0x5c97f7) {
    let _0x1f6825 = document["createElement"]("canvas");
    ((_0x1f6825["width"] = _0x209042["width"]),
      (_0x1f6825["height"] = _0x209042["height"]));
    let _0x555bc1 = _0x1f6825["getContext"]("2d");
    ((_0x555bc1["fillStyle"] = "white"),
      _0x555bc1["fillRect"](0x0, 0x0, _0x1f6825["width"], _0x1f6825["height"]),
      _0x555bc1["drawImage"](_0x209042, 0x0, 0x0),
      (_0x555bc1["globalAlpha"] = _0x256f1f));
    var _0x18be2a = _0x3ba940["width"],
      _0x481c7e = _0x3ba940["height"];
    _0x555bc1["drawImage"](
      _0x3ba940,
      _0x1f6825["width"] - _0x18be2a,
      0x0,
      _0x18be2a,
      _0x481c7e,
    );
    var _0x4b7929 = new Image();
    ((_0x4b7929["onload"] = function () {
      _0x2cf8fd(_0x4b7929);
    }),
      (_0x4b7929["src"] = _0x1f6825["toDataURL"]()));
  });
}
function _0x41c12a(
  _0xf49fbe,
  _0x52a48d,
  _0x4134c4,
  _0x44b6b7,
  _0x17a487,
  _0x1514d3,
) {
  (_0xf49fbe["beginPath"](),
    _0xf49fbe["moveTo"](_0x52a48d + _0x1514d3, _0x4134c4),
    _0xf49fbe["lineTo"](_0x52a48d + _0x44b6b7 - _0x1514d3, _0x4134c4),
    _0xf49fbe["quadraticCurveTo"](
      _0x52a48d + _0x44b6b7,
      _0x4134c4,
      _0x52a48d + _0x44b6b7,
      _0x4134c4 + _0x1514d3,
    ),
    _0xf49fbe["lineTo"](
      _0x52a48d + _0x44b6b7,
      _0x4134c4 + _0x17a487 - _0x1514d3,
    ),
    _0xf49fbe["quadraticCurveTo"](
      _0x52a48d + _0x44b6b7,
      _0x4134c4 + _0x17a487,
      _0x52a48d + _0x44b6b7 - _0x1514d3,
      _0x4134c4 + _0x17a487,
    ),
    _0xf49fbe["lineTo"](_0x52a48d + _0x1514d3, _0x4134c4 + _0x17a487),
    _0xf49fbe["quadraticCurveTo"](
      _0x52a48d,
      _0x4134c4 + _0x17a487,
      _0x52a48d,
      _0x4134c4 + _0x17a487 - _0x1514d3,
    ),
    _0xf49fbe["lineTo"](_0x52a48d, _0x4134c4 + _0x1514d3),
    _0xf49fbe["quadraticCurveTo"](
      _0x52a48d,
      _0x4134c4,
      _0x52a48d + _0x1514d3,
      _0x4134c4,
    ),
    _0xf49fbe["closePath"]());
}
function _0x347fe4(_0x23ac90, _0x46cb86, _0x5dd848, _0x59eb37) {
  return new Promise(function (_0x3f8265, _0xb52eac) {
    let _0x593834 = document["createElement"]("canvas");
    ((_0x593834["width"] = _0x23ac90["width"]),
      (_0x593834["height"] = _0x23ac90["height"]));
    let _0x29a23f = _0x593834["getContext"]("2d");
    ((_0x29a23f["fillStyle"] = "white"),
      _0x29a23f["fillRect"](0x0, 0x0, _0x593834["width"], _0x593834["height"]),
      _0x29a23f["drawImage"](_0x23ac90, 0x0, 0x0),
      (_0x29a23f["globalAlpha"] = _0x5dd848));
    var _0x27c784 =
        _0x593834["width"] - _0x46cb86["width"] - _0x593834["width"] / 0x32,
      _0x16c700 =
        _0x593834["height"] -
        _0x46cb86["height"] -
        _0x593834["height"] / _0x59eb37;
    (_0x41c12a(
      _0x29a23f,
      _0x27c784,
      _0x16c700,
      _0x46cb86["width"],
      _0x46cb86["height"],
      0xa,
    ),
      _0x29a23f["clip"](),
      _0x29a23f["drawImage"](_0x46cb86, _0x27c784, _0x16c700));
    var _0x5686a6 = new Image();
    ((_0x5686a6["onload"] = function () {
      _0x3f8265(_0x5686a6);
    }),
      (_0x5686a6["src"] = _0x593834["toDataURL"]()));
  });
}
function _0x38a26e(_0x235cf1, _0x13c3c7, _0x44d53e, _0xd5af4e) {
  return new Promise(function (_0x2e0604, _0x5c2713) {
    let _0xed1cab = document["createElement"]("canvas");
    ((_0xed1cab["width"] = _0x235cf1["width"]),
      (_0xed1cab["height"] = _0x235cf1["height"]));
    let _0x2e3c98 = _0xed1cab["getContext"]("2d");
    ((_0x2e3c98["fillStyle"] = "white"),
      _0x2e3c98["fillRect"](0x0, 0x0, _0xed1cab["width"], _0xed1cab["height"]),
      _0x2e3c98["drawImage"](_0x235cf1, 0x0, 0x0),
      (_0x2e3c98["globalAlpha"] = _0x44d53e));
    var _0x42b657 = 0x0 + _0xed1cab["width"] / 0x32,
      _0x4c8f15 =
        _0xed1cab["height"] -
        _0x13c3c7["height"] -
        _0xed1cab["height"] / _0xd5af4e;
    _0x2e3c98["drawImage"](_0x13c3c7, _0x42b657, _0x4c8f15);
    var _0x4a1faa = new Image();
    ((_0x4a1faa["onload"] = function () {
      _0x2e0604(_0x4a1faa);
    }),
      (_0x4a1faa["src"] = _0xed1cab["toDataURL"]()));
  });
}
function _0x9ca584(_0x573933, _0x174bed, _0x5bf1a0) {
  return new Promise(function (_0x59fcb7, _0x2e2ff7) {
    let _0x19eb35 = document["createElement"]("canvas");
    ((_0x19eb35["width"] = _0x573933["width"]),
      (_0x19eb35["height"] = _0x573933["height"]));
    let _0x5cf43e = _0x19eb35["getContext"]("2d");
    ((_0x5cf43e["fillStyle"] = "white"),
      _0x5cf43e["fillRect"](0x0, 0x0, _0x19eb35["width"], _0x19eb35["height"]),
      _0x5cf43e["drawImage"](_0x573933, 0x0, 0x0),
      _0x5cf43e["drawImage"](
        _0x174bed,
        _0x5bf1a0,
        _0x19eb35["height"] - _0x174bed["height"],
      ));
    var _0x2a125d = new Image();
    ((_0x2a125d["onload"] = function () {
      _0x59fcb7(_0x2a125d);
    }),
      (_0x2a125d["src"] = _0x19eb35["toDataURL"]()));
  });
}
function _0x50553b(_0x373062, _0x25ccdb) {
  return new Promise(function (_0x2567ab, _0x5d7c83) {
    let _0x434c77 = document["createElement"]("canvas");
    ((_0x434c77["width"] = _0x373062["width"]),
      (_0x434c77["height"] = _0x373062["height"]));
    let _0x39edae = _0x434c77["getContext"]("2d");
    ((_0x39edae["fillStyle"] = "white"),
      _0x39edae["fillRect"](0x0, 0x0, _0x434c77["width"], _0x434c77["height"]),
      (_0x39edae["globalAlpha"] = _0x25ccdb),
      _0x39edae["drawImage"](_0x373062, 0x0, 0x0));
    var _0x36f7fa = new Image();
    ((_0x36f7fa["onload"] = function () {
      _0x2567ab(_0x36f7fa);
    }),
      (_0x36f7fa["src"] = _0x434c77["toDataURL"]()));
  });
}
function _0x55fd14(_0x41be1e, _0x26919b) {
  return new Promise(function (_0x421934, _0x3c9fd6) {
    let _0x16264c = document["createElement"]("canvas");
    ((_0x16264c["width"] = _0x41be1e["width"] + imgWatermark["width"]),
      (_0x16264c["height"] = _0x41be1e["height"]));
    let _0x4b5e81 = _0x16264c["getContext"]("2d");
    ((_0x4b5e81["fillStyle"] = "white"),
      _0x4b5e81["fillRect"](0x0, 0x0, _0x16264c["width"], _0x16264c["height"]),
      (_0x4b5e81["globalAlpha"] = _0x26919b),
      _0x4b5e81["drawImage"](_0x41be1e, 0x0, 0x0));
    var _0x11a2d3 = 0.9 * imgWatermark["width"],
      _0x23872e = 0.9 * imgWatermark["height"];
    _0x4b5e81["drawImage"](
      imgWatermark,
      _0x16264c["width"] - _0x11a2d3,
      0x0,
      _0x11a2d3,
      _0x23872e,
    );
    var _0x4b1b9b = new Image();
    ((_0x4b1b9b["onload"] = function () {
      _0x421934(_0x4b1b9b);
    }),
      (_0x4b1b9b["src"] = _0x16264c["toDataURL"]()));
  });
}
function _0x5d5549(_0x20fbf9) {
  return new Promise((_0x4238f4, _0x3ce805) => {
    var _0x1b6989 = document["createElement"]("canvas"),
      _0xe4ddfc = _0x1b6989["getContext"]("2d");
    ((_0x1b6989["width"] = _0x20fbf9["width"]),
      (_0x1b6989["height"] = _0x20fbf9["height"]));
    var _0x291e42 = new Image();
    ((_0x291e42["onload"] = function () {
      (_0xe4ddfc["drawImage"](_0x20fbf9, 0x0, 0x0), _0x4238f4(_0x1b6989));
    }),
      (_0x291e42["src"] = _0x20fbf9["src"]));
  });
}
function _0x26187b(_0x38d0f0) {
  return new Promise((_0x385e5b, _0x54a122) => {
    var _0x39558f = new Image();
    ((_0x39558f["onload"] = function () {
      _0x385e5b(_0x39558f);
    }),
      (_0x39558f["src"] = _0x38d0f0["toDataURL"]()));
  });
}
function _0x20059f(_0x1b3f95) {
  return new Promise((_0x5db57f, _0x44b9b4) => {
    var _0x32b2b4 = new Image(),
      _0x51777d = document["createElement"]("canvas"),
      _0x141144 = _0x51777d["getContext"]("2d"),
      _0x4b69ed = {};
    ((_0x32b2b4["onload"] = function () {
      ((_0x51777d["width"] = _0x32b2b4["width"]),
        (_0x51777d["height"] = _0x32b2b4["height"]),
        _0x141144["drawImage"](
          _0x32b2b4,
          0x0,
          0x0,
          _0x32b2b4["width"],
          _0x32b2b4["height"],
        ),
        (_0x4b69ed = _0x141144["getImageData"](
          0x0,
          0x0,
          _0x32b2b4["width"],
          _0x32b2b4["height"],
        )["data"]));
      var _0x4a42e7 = _0x49e164(!0x0, _0x32b2b4, _0x4b69ed),
        _0x5ecb41 = _0x49e164(!0x1, _0x32b2b4, _0x4b69ed),
        _0x4de4c2 = _0x35c2eb(!0x0, _0x32b2b4, _0x4b69ed),
        _0x40d5b0 = _0x35c2eb(!0x1, _0x32b2b4, _0x4b69ed) - _0x4de4c2,
        _0x5d91dc = _0x5ecb41 - _0x4a42e7;
      ((_0x51777d["width"] = _0x40d5b0),
        (_0x51777d["height"] = _0x5d91dc),
        _0x141144["drawImage"](
          _0x32b2b4,
          _0x4de4c2,
          _0x4a42e7,
          _0x40d5b0,
          _0x5d91dc,
          0x0,
          0x0,
          _0x40d5b0,
          _0x5d91dc,
        ));
      let _0x32bcc5 = new Image();
      ((_0x32bcc5["crossOrigin"] = "anonymous"),
        (_0x32bcc5["onload"] = function () {
          _0x5db57f(_0x32bcc5);
        }),
        (_0x32bcc5["src"] = _0x51777d["toDataURL"]()));
    }),
      (_0x32b2b4["src"] = _0x1b3f95["src"]));
  });
}
function _0x35c2eb(_0x35524b, _0x23a16b, _0x132fa8) {
  var _0x1586c0 = _0x35524b ? 0x1 : -0x1;
  for (
    var _0x5dc1d5 = _0x35524b ? 0x0 : _0x23a16b["width"] - 0x1;
    _0x35524b ? _0x5dc1d5 < _0x23a16b["width"] : _0x5dc1d5 > -0x1;
    _0x5dc1d5 += _0x1586c0
  )
    for (var _0x5d2ec2 = 0x0; _0x5d2ec2 < _0x23a16b["height"]; _0x5d2ec2++)
      if (!_0x36c50b(_0x1b1446(_0x5dc1d5, _0x5d2ec2, _0x132fa8, _0x23a16b)))
        return _0x5dc1d5;
  return null;
}
function _0x49e164(_0x5a143b, _0x1f70d5, _0x182b97) {
  var _0x16f206 = _0x5a143b ? 0x1 : -0x1;
  for (
    var _0x28ae81 = _0x5a143b ? 0x0 : _0x1f70d5["height"] - 0x1;
    _0x5a143b ? _0x28ae81 < _0x1f70d5["height"] : _0x28ae81 > -0x1;
    _0x28ae81 += _0x16f206
  )
    for (var _0x4f73f3 = 0x0; _0x4f73f3 < _0x1f70d5["width"]; _0x4f73f3++)
      if (!_0x36c50b(_0x1b1446(_0x4f73f3, _0x28ae81, _0x182b97, _0x1f70d5)))
        return _0x28ae81;
  return null;
}
function _0x36c50b(_0x52a527) {
  return (
    0xff == _0x52a527["red"] &&
    0xff == _0x52a527["green"] &&
    0xff == _0x52a527["blue"]
  );
}
function _0x1b1446(_0x1b5966, _0x1d987c, _0x1b913f, _0x42a268) {
  return {
    red: _0x1b913f[0x4 * (_0x42a268["width"] * _0x1d987c + _0x1b5966)],
    green: _0x1b913f[0x4 * (_0x42a268["width"] * _0x1d987c + _0x1b5966) + 0x1],
    blue: _0x1b913f[0x4 * (_0x42a268["width"] * _0x1d987c + _0x1b5966) + 0x2],
  };
}
function _0x1aa8bc(_0x4ecfb7) {
  return new Promise((_0x393cc9, _0x5efa93) => {
    var _0x41b40d = document["createElement"]("canvas"),
      _0x233df8 = _0x41b40d["getContext"]("2d");
    ((_0x41b40d["width"] = _0x4ecfb7["width"]),
      (_0x41b40d["height"] = _0x4ecfb7["height"]),
      _0x233df8["drawImage"](
        _0x4ecfb7,
        0x0,
        0x0,
        _0x4ecfb7["width"],
        _0x4ecfb7["height"],
      ));
    let _0x4c6f06 = _0x233df8["getImageData"](
      0x0,
      0x0,
      _0x4ecfb7["width"],
      _0x4ecfb7["height"],
    );
    var _0x2dbd36 = _0x4c6f06["data"];
    for (let _0x5f2bb8 = 0x0; _0x5f2bb8 < _0x2dbd36["length"]; _0x5f2bb8 += 0x4)
      [
        _0x2dbd36[_0x5f2bb8],
        _0x2dbd36[_0x5f2bb8 + 0x1],
        _0x2dbd36[_0x5f2bb8 + 0x2],
      ]["every"]((_0x6814b6) => _0x6814b6 < 0x100 && _0x6814b6 > 0xf5) &&
        (_0x2dbd36[_0x5f2bb8 + 0x3] = 0x0);
    _0x233df8["putImageData"](_0x4c6f06, 0x0, 0x0);
    var _0x4ac872 = new Image();
    ((_0x4ac872["onload"] = function () {
      _0x393cc9(_0x4ac872);
    }),
      (_0x4ac872["src"] = _0x41b40d["toDataURL"]()));
  });
}
async function _0x5ee413(
  _0xd35395,
  _0x64e4c1 = "/Image_Badges/Best_Seller.png",
) {
  var _0x5a8436 = chrome["runtime"]["getURL"](_0x64e4c1),
    _0x454dac = await _0x52d13d(_0x5a8436),
    _0x264dec = document["createElement"]("canvas"),
    _0x520cb4 = _0x264dec["getContext"]("2d");
  ((_0x264dec["width"] = _0xd35395["width"]),
    (_0x264dec["height"] = _0xd35395["height"] + _0x454dac["height"]),
    (_0x520cb4["fillStyle"] = "white"),
    _0x520cb4["fillRect"](0x0, 0x0, _0x264dec["width"], _0x264dec["height"]),
    _0x520cb4["drawImage"](_0xd35395, 0x0, _0x454dac["height"]),
    _0x520cb4["drawImage"](
      _0x454dac,
      0x0,
      0x0,
      _0x454dac["width"],
      _0x454dac["height"],
    ));
  var _0x26b5ad = new Image();
  return ((_0x26b5ad["src"] = _0x264dec["toDataURL"]()), _0x26b5ad);
}
async function _0x3b8f7a(
  _0x343f4a,
  _0x56f4ae = "/Image_Badges/Limited-Time-Deal-Badge.jpg",
) {
  var _0x55e8ab = chrome["runtime"]["getURL"](_0x56f4ae),
    _0x507b49 = await _0x52d13d(_0x55e8ab),
    _0x422ea8 = document["createElement"]("canvas"),
    _0x53720f = _0x422ea8["getContext"]("2d");
  ((_0x422ea8["width"] = _0x343f4a["width"]),
    (_0x422ea8["height"] = _0x343f4a["height"]),
    (_0x53720f["fillStyle"] = "white"),
    _0x53720f["fillRect"](0x0, 0x0, _0x422ea8["width"], _0x422ea8["height"]),
    _0x53720f["drawImage"](_0x343f4a, 0x0, 0x0));
  var _0x6dcd42 = _0x343f4a["width"] / 2.5,
    _0x428cf4 = _0x507b49["height"] * (_0x6dcd42 / _0x507b49["width"]);
  _0x53720f["drawImage"](
    _0x507b49,
    _0x343f4a["width"] - _0x6dcd42,
    _0x343f4a["height"] - _0x428cf4,
    _0x6dcd42,
    _0x428cf4,
  );
  var _0x12e161 = new Image();
  return ((_0x12e161["src"] = _0x422ea8["toDataURL"]()), _0x12e161);
}
async function _0x22c0f6(
  _0x57e087,
  _0x18b5cf,
  _0x2bc39e,
  _0x48b277,
  _0x31c9f9,
  _0x50c9c2,
  _0x23d565,
  _0x27cc1a,
  _0x222aa4,
  _0x357a0f,
  _0x22de11 = !0x1,
) {
  (console["log"]("Creating\x20multi\x20image\x20V2"),
    console["log"]("imageSource", _0x57e087));
  var _0x4a99bc = await _0x52d13d(_0x57e087);
  ((_0x4a99bc = await _0x3cadab(_0x4a99bc, _0x23d565, _0x27cc1a)),
    (_0x4a99bc = await _0x20059f(_0x4a99bc)));
  var _0x3b96cd = await _0x52d13d(_0x18b5cf),
    _0x59cbb8 = await _0x52d13d(_0x48b277),
    _0x23777d = await _0x52d13d(_0x31c9f9);
  ((_0x3b96cd = await _0x3cadab(_0x3b96cd, 0.45 * _0x23d565, 0.45 * _0x27cc1a)),
    (_0x59cbb8 = await _0x3cadab(
      _0x59cbb8,
      0.45 * _0x23d565,
      0.45 * _0x27cc1a,
    )),
    (_0x23777d = await _0x3cadab(
      _0x23777d,
      0.45 * _0x23d565,
      0.45 * _0x27cc1a,
    )));
  var _0x10409f = Math["max"](
    _0x3b96cd["width"],
    _0x59cbb8["width"],
    _0x23777d["width"],
  );
  ((_0x4a99bc = await _0x16f2b1(_0x4a99bc, _0x10409f, "right")),
    (_0x4a99bc = await _0xe4c42c(_0x4a99bc)),
    (_0x3b96cd = await _0x3cadab(_0x3b96cd, 0.4 * _0x23d565, 0.4 * _0x27cc1a)),
    (_0x59cbb8 = await _0x3cadab(_0x59cbb8, 0.4 * _0x23d565, 0.4 * _0x27cc1a)),
    (_0x23777d = await _0x3cadab(_0x23777d, 0.4 * _0x23d565, 0.4 * _0x27cc1a)));
  var _0x10dd1f = 0x0;
  ((_0x4a99bc = await _0x1bbbf4(_0x4a99bc, _0x3b96cd, _0x10dd1f)),
    (_0x10dd1f += _0x3b96cd["height"] + _0x4a99bc["height"] / 0x19),
    (_0x4a99bc = await _0x1bbbf4(_0x4a99bc, _0x59cbb8, _0x10dd1f)),
    (_0x10dd1f += _0x59cbb8["height"] + _0x4a99bc["height"] / 0x19),
    (_0x4a99bc = await _0x1bbbf4(_0x4a99bc, _0x23777d, _0x10dd1f)));
  var _0x2f554e = await _0x52d13d(_0x2bc39e);
  _0x2f554e = await _0x3cadab(
    _0x2f554e,
    0.2 * _0x4a99bc["height"],
    0.2 * _0x4a99bc["width"],
  );
  var _0xb6b7f7 = _0x4a99bc["height"],
    _0x33a6bc = chrome["runtime"]["getURL"]("/Image_Badges/Best_Seller.png"),
    _0x566b44 = await _0x52d13d(_0x33a6bc),
    _0x384ba9 = _0x4a99bc["height"] / 0x5,
    _0x42d5c2 = _0x566b44["width"] * (_0x384ba9 / _0x566b44["height"]);
  _0x566b44 = await _0x3cadab(_0x566b44, _0x42d5c2, _0x384ba9);
  if (_0x22de11) {
    _0x4a99bc = await _0x5ee413(_0x4a99bc);
    var _0x572bb1 =
      (_0x4a99bc = await _0x3b8f7a(_0x4a99bc))["height"] - _0xb6b7f7;
    ((_0x2f554e = await _0x3cadab(
      _0x2f554e,
      _0x572bb1,
      0.2 * _0x4a99bc["width"],
    )),
      (_0x4a99bc = await _0x59a737(_0x4a99bc, _0x2f554e, 0.7)));
  }
  return await _0x2db71b(_0x4a99bc, 0x1f4, 0x1f4);
}
function _0x3b294d(_0x516ba3, _0x467add, _0x3f1d39, _0x57a45b = 0x1) {
  return new Promise(function (_0x241fbe, _0x51176f) {
    let _0x36fb16 = document["createElement"]("canvas");
    ((_0x36fb16["width"] = _0x516ba3["width"]),
      (_0x36fb16["height"] = _0x516ba3["height"]));
    let _0x4d6d3f = _0x36fb16["getContext"]("2d");
    ((_0x4d6d3f["fillStyle"] = "white"),
      _0x4d6d3f["fillRect"](0x0, 0x0, _0x36fb16["width"], _0x36fb16["height"]),
      _0x4d6d3f["drawImage"](_0x516ba3, 0x0, 0x0));
    var _0x16da28 = _0x3f1d39;
    (_0x41c12a(
      _0x4d6d3f,
      0x0,
      _0x16da28,
      _0x467add["width"],
      _0x467add["height"],
      0xa,
    ),
      (_0x4d6d3f["globalAlpha"] = _0x57a45b),
      _0x4d6d3f["drawImage"](_0x467add, 0x0, _0x16da28));
    let _0x39a422 = new Image();
    ((_0x39a422["src"] = _0x36fb16["toDataURL"]()), _0x241fbe(_0x39a422));
  });
}
function _0x1bbbf4(_0x57b2d5, _0x3bc781, _0x192440) {
  return new Promise(function (_0x1064de, _0x147b97) {
    let _0x275289 = document["createElement"]("canvas");
    ((_0x275289["width"] = _0x57b2d5["width"]),
      (_0x275289["height"] = _0x57b2d5["height"]));
    let _0x368652 = _0x275289["getContext"]("2d");
    ((_0x368652["fillStyle"] = "white"),
      _0x368652["fillRect"](0x0, 0x0, _0x275289["width"], _0x275289["height"]),
      _0x368652["drawImage"](_0x57b2d5, 0x0, 0x0),
      (_0x368652["globalAlpha"] = 0.9));
    var _0x4e85b6 =
        _0x275289["width"] - _0x3bc781["width"] - _0x275289["width"] / 0x32,
      _0x56dce2 = _0x192440;
    (_0x41c12a(
      _0x368652,
      _0x4e85b6,
      _0x56dce2,
      _0x3bc781["width"],
      _0x3bc781["height"],
      0xa,
    ),
      _0x368652["clip"](),
      _0x368652["drawImage"](_0x3bc781, _0x4e85b6, _0x56dce2));
    var _0x1620da = new Image();
    ((_0x1620da["onload"] = function () {
      _0x1064de(_0x1620da);
    }),
      (_0x1620da["src"] = _0x275289["toDataURL"]()));
  });
}
function _0x16f2b1(_0x4c3f6d, _0x4ac932, _0x2e239c) {
  return new Promise(function (_0x26f712, _0x2c039f) {
    let _0x5bcf27 = document["createElement"]("canvas");
    ((_0x5bcf27["width"] = _0x4c3f6d["width"] + _0x4ac932),
      (_0x5bcf27["height"] = _0x4c3f6d["height"]));
    let _0x63a716 = _0x5bcf27["getContext"]("2d");
    ((_0x63a716["fillStyle"] = "white"),
      _0x63a716["fillRect"](0x0, 0x0, _0x5bcf27["width"], _0x5bcf27["height"]));
    var _0x3b4198 = _0x4ac932;
    "left" === _0x2e239c
      ? _0x63a716["drawImage"](_0x4c3f6d, _0x3b4198, 0x0)
      : "right" === _0x2e239c && _0x63a716["drawImage"](_0x4c3f6d, 0x0, 0x0);
    var _0x257b5c = new Image();
    ((_0x257b5c["onload"] = function () {
      _0x26f712(_0x257b5c);
    }),
      (_0x257b5c["src"] = _0x5bcf27["toDataURL"]()));
  });
}
function _0x401ce8(_0x387fcd, _0x5c7594, _0x5e746e) {
  return new Promise(function (_0x38bcdb, _0x5f36d6) {
    let _0x666667 = document["createElement"]("canvas");
    ((_0x666667["width"] = _0x387fcd["width"]),
      (_0x666667["height"] = _0x387fcd["height"] + _0x5c7594));
    let _0x41ff7a = _0x666667["getContext"]("2d");
    ((_0x41ff7a["fillStyle"] = "white"),
      _0x41ff7a["fillRect"](0x0, 0x0, _0x666667["width"], _0x666667["height"]));
    var _0x158865 = _0x5c7594;
    "top" === _0x5e746e
      ? _0x41ff7a["drawImage"](_0x387fcd, 0x0, _0x158865)
      : "bottom" === _0x5e746e && _0x41ff7a["drawImage"](_0x387fcd, 0x0, 0x0);
    var _0x4d7e3c = new Image();
    ((_0x4d7e3c["onload"] = function () {
      _0x38bcdb(_0x4d7e3c);
    }),
      (_0x4d7e3c["src"] = _0x666667["toDataURL"]()));
  });
}
function _0x59a737(_0x174da6, _0x204b64, _0x40c136) {
  return new Promise(async function (_0x5d559f, _0x22f035) {
    let _0x123670 = document["createElement"]("canvas");
    ((_0x123670["width"] = _0x174da6["width"]),
      (_0x123670["height"] = _0x174da6["height"]));
    let _0x2ae38a = _0x123670["getContext"]("2d");
    ((_0x2ae38a["fillStyle"] = "white"),
      _0x2ae38a["fillRect"](0x0, 0x0, _0x123670["width"], _0x123670["height"]),
      _0x2ae38a["drawImage"](_0x174da6, 0x0, 0x0),
      (_0x2ae38a["globalAlpha"] = _0x40c136),
      _0x2ae38a["drawImage"](
        _0x204b64,
        _0x123670["width"] - _0x204b64["width"],
        0x0,
        _0x204b64["width"],
        _0x204b64["height"],
      ));
    var _0x47b1f6 = new Image();
    ((_0x47b1f6["onload"] = function () {
      _0x5d559f(_0x47b1f6);
    }),
      (_0x47b1f6["src"] = _0x123670["toDataURL"]()));
  });
}
function _0x541a3d(_0x51d935) {
  return new Promise(function (_0x174125, _0x1bc3ce) {
    let _0x55cb21 = document["createElement"]("canvas");
    (_0x51d935["width"], _0x51d935["height"]);
    if (_0x51d935["width"] > _0x51d935["height"])
      ((_0x55cb21["width"] = _0x51d935["width"]),
        (_0x55cb21["height"] =
          _0x51d935["height"] + (_0x51d935["width"] - _0x51d935["height"])));
    else {
      if (!(_0x51d935["width"] < _0x51d935["height"])) return _0x51d935;
      ((_0x55cb21["height"] = _0x51d935["height"]),
        (_0x55cb21["width"] =
          _0x51d935["width"] + (_0x51d935["height"] - _0x51d935["width"])));
    }
    let _0x4f91c2 = _0x55cb21["getContext"]("2d");
    ((_0x4f91c2["fillStyle"] = "white"),
      _0x4f91c2["fillRect"](0x0, 0x0, _0x55cb21["width"], _0x55cb21["height"]),
      _0x4f91c2["drawImage"](
        _0x51d935,
        _0x55cb21["width"] - _0x51d935["width"],
        _0x55cb21["height"] - _0x51d935["height"],
      ));
    var _0x10b702 = new Image();
    ((_0x10b702["onload"] = function () {
      _0x174125(_0x10b702);
    }),
      (_0x10b702["src"] = _0x55cb21["toDataURL"]()));
  });
}
async function _0x23c8ff(_0x43c816, _0x1e328e) {
  var _0x3c0c64 = await _0x52d13d(_0x43c816);
  _0x3c0c64 = await _0x3cadab(_0x3c0c64, 0x5dc, 0x5dc);
  var _0x4377de = [];
  for (var _0x8b938 = 0x0; _0x8b938 < _0x1e328e["length"]; _0x8b938++) {
    var _0x2dfd2a = await _0x52d13d(_0x1e328e[_0x8b938]);
    ((_0x2dfd2a = await _0x3cadab(
      _0x2dfd2a,
      _0x3c0c64["width"] / _0x1e328e["length"],
      _0x3c0c64["height"] / _0x1e328e["length"],
    )),
      _0x4377de["push"](_0x2dfd2a));
  }
  var _0x581d67 = _0x4377de[0x0];
  for (_0x8b938 = 0x0; _0x8b938 < _0x4377de["length"]; _0x8b938++)
    _0x4377de[_0x8b938]["width"] > _0x581d67["width"] &&
      (_0x581d67 = _0x4377de[_0x8b938]);
  _0x3c0c64 = await _0x401ce8(_0x3c0c64, _0x581d67["height"], "bottom");
  for (_0x8b938 = 0x0; _0x8b938 < _0x4377de["length"]; _0x8b938++)
    _0x3c0c64 = await _0x9ca584(
      _0x3c0c64,
      _0x4377de[_0x8b938],
      _0x8b938 * (_0x3c0c64["width"] / _0x4377de["length"]),
    );
  return _0x3c0c64;
}
async function _0x2df9d2(_0x6ce202, _0x520a30, _0x7942f3) {
  ((_0x6ce202 = await _0x3cadab(_0x6ce202, 0x5dc, 0x5dc)),
    (_0x6ce202 = await _0x20059f(_0x6ce202)));
  var _0x467f1d = await _0x52d13d(_0x7942f3);
  ((_0x467f1d = await _0x20059f(_0x467f1d)),
    (_0x467f1d = await _0x3cadab(_0x467f1d, 0x2a3, 0x2a3)));
  var _0x4aecad = await _0x52d13d(_0x520a30);
  return (
    (_0x4aecad = await _0x3cadab(_0x4aecad, 0x2a3, 0x2a3)),
    (_0x6ce202 = await _0x267896(_0x6ce202, _0x4aecad, "right")),
    (_0x4aecad = await _0x3cadab(_0x4aecad, 0x258, 0x258)),
    (_0x6ce202 = await _0x347fe4(_0x6ce202, _0x4aecad, 0x1, 0xc)),
    (_0x467f1d = await _0x464df3(
      _0x467f1d,
      0.65 * _0x4aecad["width"],
      0.65 * _0x4aecad["height"],
    )),
    (_0x467f1d = await _0x1aa8bc(_0x467f1d)),
    (_0x6ce202 = await _0x57f2c5(_0x6ce202, _0x467f1d, 0.7)),
    (_0x6ce202 = await _0xe4c42c(_0x6ce202)),
    await _0x2db71b(_0x6ce202, 0x1f4, 0x1f4)
  );
}
function _0x1c6400(_0x1eb126, _0x51d23) {
  return new Promise((_0xec4a3, _0x493823) => {
    const _0x281110 = _0x1eb126,
      _0x323436 = document["createElement"]("canvas");
    ((_0x323436["width"] = _0x281110["width"]),
      (_0x323436["height"] = _0x281110["height"]));
    const _0x3791ce = _0x323436["getContext"]("2d");
    (_0x3791ce["clearRect"](0x0, 0x0, _0x323436["width"], _0x323436["height"]),
      _0x3791ce["save"](),
      _0x3791ce["beginPath"](),
      _0x3791ce["moveTo"](_0x51d23, 0x0),
      _0x3791ce["lineTo"](_0x323436["width"] - _0x51d23, 0x0),
      _0x3791ce["quadraticCurveTo"](
        _0x323436["width"],
        0x0,
        _0x323436["width"],
        _0x51d23,
      ),
      _0x3791ce["lineTo"](_0x323436["width"], _0x323436["height"] - _0x51d23),
      _0x3791ce["quadraticCurveTo"](
        _0x323436["width"],
        _0x323436["height"],
        _0x323436["width"] - _0x51d23,
        _0x323436["height"],
      ),
      _0x3791ce["lineTo"](_0x51d23, _0x323436["height"]),
      _0x3791ce["quadraticCurveTo"](
        0x0,
        _0x323436["height"],
        0x0,
        _0x323436["height"] - _0x51d23,
      ),
      _0x3791ce["lineTo"](0x0, _0x51d23),
      _0x3791ce["quadraticCurveTo"](0x0, 0x0, _0x51d23, 0x0),
      _0x3791ce["clip"](),
      _0x3791ce["drawImage"](
        _0x281110,
        0x0,
        0x0,
        _0x323436["width"],
        _0x323436["height"],
      ),
      _0x3791ce["restore"]());
    const _0x524f01 = new Image();
    ((_0x524f01["onload"] = () => {
      _0xec4a3(_0x524f01);
    }),
      (_0x524f01["src"] = _0x323436["toDataURL"]()));
  });
}
async function _0x4762d8(_0x3e82fc, _0x1f41a6) {
  var _0x30c1c8 = document["createElement"]("canvas");
  ((_0x30c1c8["width"] = 0x1f4), (_0x30c1c8["height"] = 0x1f4));
  var _0x540d96 = _0x30c1c8["getContext"]("2d");
  ((_0x540d96["fillStyle"] = "#E53238"),
    _0x540d96["fillRect"](0x0, 0x0, _0x30c1c8["width"], 0x14),
    (_0x540d96["fillStyle"] = "#0074E8"),
    _0x540d96["fillRect"](
      _0x30c1c8["width"] - 0x14,
      0x0,
      0x14,
      _0x30c1c8["height"],
    ),
    (_0x540d96["fillStyle"] = "#F5AF02"),
    _0x540d96["fillRect"](
      0x0,
      _0x30c1c8["height"] - 0x14,
      _0x30c1c8["width"],
      0x14,
    ),
    (_0x540d96["fillStyle"] = "#86B817"),
    _0x540d96["fillRect"](0x0, 0x0, 0x14, _0x30c1c8["height"]));
  var innerWidth = _0x30c1c8["width"] - 0x28,
    innerHeight = _0x30c1c8["height"] - 0x28;
  ((_0x540d96["fillStyle"] = "#ffffff"),
    _0x540d96["fillRect"](0x14, 0x14, innerWidth, innerHeight));
  var _0x2f5aea = "Informationen\x20zur\x20Produktsicherheit";
  ((_0x540d96["font"] = "bold\x2024px\x20Arial"),
    (_0x540d96["fillStyle"] = "#000"));
  var _0x26c7b9 =
    0x14 + (innerWidth - _0x540d96["measureText"](_0x2f5aea)["width"]) / 0x2;
  (_0x540d96["fillText"](_0x2f5aea, _0x26c7b9, 0x28),
    (_0x540d96["strokeStyle"] = "#cccccc"),
    (_0x540d96["lineWidth"] = 0x1),
    _0x540d96["beginPath"](),
    _0x540d96["moveTo"](0x1e, 0x4b),
    _0x540d96["lineTo"](0x14 + innerWidth - 0xa, 0x4b),
    _0x540d96["stroke"]());
  var _0x22f4bf = 0x14 + innerHeight - 0xa;
  function _0x52d376(
    _0x101ea5,
    _0x7f4372,
    _0x5755af,
    _0x24a31f,
    _0x1572e7,
    _0x4ff950,
    _0x496ac1,
  ) {
    ((_0x101ea5["fillStyle"] = "#000"),
      (_0x101ea5["font"] = "bold\x2016px\x20Arial"),
      (_0x101ea5["textBaseline"] = "top"),
      _0x101ea5["fillText"](_0x1572e7, _0x7f4372 + 0x8, _0x5755af),
      (_0x5755af += 0x14),
      (_0x101ea5["font"] = "14px\x20Arial"));
    var _0x1cce45 = (function (_0x3fb20d, _0x124d1b, _0x4c6bdb) {
      var _0x2f2127 = _0x124d1b["split"]("\x0a"),
        _0x4d47fa = [];
      for (var _0x220811 = 0x0; _0x220811 < _0x2f2127["length"]; _0x220811++) {
        var _0x57c10e = _0x2f2127[_0x220811]["split"]("\x20"),
          _0x14bab8 = "";
        for (
          var _0x1d9f97 = 0x0;
          _0x1d9f97 < _0x57c10e["length"];
          _0x1d9f97++
        ) {
          var _0x2d836a = _0x14bab8 + _0x57c10e[_0x1d9f97] + "\x20";
          if (
            _0x3fb20d["measureText"](_0x2d836a)["width"] > _0x4c6bdb &&
            _0x1d9f97 > 0x0
          )
            (_0x4d47fa["push"](_0x14bab8["trim"]()),
              (_0x14bab8 = _0x57c10e[_0x1d9f97] + "\x20"));
          else _0x14bab8 = _0x2d836a;
        }
        _0x4d47fa["push"](_0x14bab8["trim"]());
      }
      return _0x4d47fa;
    })(_0x101ea5, _0x4ff950, _0x24a31f - 0x10);
    for (
      var _0x483d23 = 0x0;
      _0x483d23 < _0x1cce45["length"] && !(_0x5755af + 0x10 > _0x496ac1);
      _0x483d23++
    ) {
      (_0x101ea5["fillText"](_0x1cce45[_0x483d23], _0x7f4372 + 0x8, _0x5755af),
        (_0x5755af += 0x10));
    }
    return _0x5755af;
  }
  var _0x528583 = _0x52d376(
    _0x540d96,
    0x14,
    0x55,
    innerWidth,
    "Hersteller:",
    _0x3e82fc,
    0x55 + (0x14 + innerHeight - 0x55 - 0xa) / 0x2,
  );
  return (
    _0x52d376(
      _0x540d96,
      0x14,
      (_0x528583 += 0xa),
      innerWidth,
      "EU\x20Verantwortliche\u00a0Person:",
      _0x1f41a6,
      _0x22f4bf,
    ),
    (_0x540d96["strokeStyle"] = "#eeeeee"),
    (_0x540d96["lineWidth"] = 0x2),
    _0x540d96["strokeRect"](0x14, 0x14, innerWidth, innerHeight),
    new Promise(function (_0x379604) {
      var _0x52b3b7 = new Image();
      ((_0x52b3b7["src"] = _0x30c1c8["toDataURL"]("image/png")),
        (_0x52b3b7["onload"] = function () {
          _0x379604(_0x52b3b7);
        }));
    })
  );
}
console["log"]("pre_list_display.js\x20loaded");
function _0x145661(_0x1dfc29) {
  var _0x106f3c = document["createElement"]("h2");
  return (
    (_0x106f3c["id"] = "title_ecom_sniper"),
    (_0x106f3c["textContent"] = _0x1dfc29),
    _0x106f3c
  );
}
function _0x3f599d(_0x372063) {
  var _0x3e177f = document["createElement"]("div");
  _0x3e177f["id"] = "listTitleContainer";
  var _0x41e3cc = document["createElement"]("textarea");
  ((_0x41e3cc["id"] = "listTitle"),
    (_0x41e3cc["rows"] = "1"),
    (_0x41e3cc["cols"] = "50"),
    (_0x41e3cc["placeholder"] = "Input\x20new\x20title\x20here..."),
    (_0x41e3cc["textContent"] = _0x372063));
  var _0x31591e = document["createElement"]("div");
  return (
    (_0x31591e["id"] = "charCount"),
    (_0x31591e["textContent"] =
      "Characters:\x20" + _0x41e3cc["value"]["length"] + "/80"),
    _0x41e3cc["addEventListener"]("input", function () {
      _0x31591e["textContent"] =
        "Characters:\x20" + _0x41e3cc["value"]["length"] + "/80";
    }),
    _0x3e177f["appendChild"](_0x41e3cc),
    _0x3e177f["appendChild"](_0x31591e),
    _0x3e177f
  );
}
function _0x13fe72(_0xea2135) {
  var _0x1d0d28 = document["createElement"]("div");
  _0x1d0d28["id"] = "listDescriptionContainer";
  var _0x578131 = document["createElement"]("h2");
  ((_0x578131["textContent"] = "Scraped\x20Description"),
    _0x1d0d28["appendChild"](_0x578131));
  var _0x5a92e2 = document["createElement"]("p");
  return (
    (_0x5a92e2["id"] = "listDescription"),
    (_0x5a92e2["contentEditable"] = "true"),
    (_0x5a92e2["innerHTML"] = _0xea2135),
    _0x1d0d28["appendChild"](_0x5a92e2),
    _0x1d0d28
  );
}
function _0x2015b3(_0x4ca14a) {
  var _0x5c9b95 = document["createDocumentFragment"]();
  for (var _0x47de5d = 0x0; _0x47de5d < _0x4ca14a["length"]; _0x47de5d++) {
    var _0x4b7371 = document["createElement"]("div");
    _0x4b7371["classList"]["add"]("imageContainer");
    var _0x4e0a84 = document["createElement"]("img");
    ((_0x4e0a84["src"] = _0x4ca14a[_0x47de5d]),
      (_0x4e0a84["width"] = "100"),
      (_0x4e0a84["height"] = "100"));
    var _0x33ac61 = document["createElement"]("span");
    ((_0x33ac61["textContent"] = "x"),
      _0x33ac61["classList"]["add"]("deleteButton"),
      _0x33ac61["addEventListener"]("click", function (_0x175e1f) {
        (_0x175e1f["stopPropagation"](), this["parentNode"]["remove"]());
      }),
      _0x4e0a84["addEventListener"]("click", function () {
        var _0x33882c = document["querySelectorAll"](".highlight");
        for (var _0x31673a = 0x0; _0x31673a < _0x33882c["length"]; _0x31673a++)
          _0x33882c[_0x31673a]["classList"]["remove"]("highlight");
        this["classList"]["add"]("highlight");
      }),
      _0x4e0a84["addEventListener"]("dblclick", _0x342dcc),
      _0x4b7371["appendChild"](_0x4e0a84),
      _0x4b7371["appendChild"](_0x33ac61),
      _0x5c9b95["appendChild"](_0x4b7371));
  }
  return _0x5c9b95;
}
async function _0x4f35a4(_0x501a9b, _0x59d543) {
  console["log"]("mainImage:\x20" + _0x501a9b);
  var _0x1860dd = await _0x23c8ff(_0x501a9b, _0x59d543),
    _0x4cfa8b = document["createElement"]("div");
  _0x4cfa8b["classList"]["add"]("imageContainer");
  var _0x31448d = document["createElement"]("img");
  ((_0x31448d["src"] = _0x1860dd["src"]),
    (_0x31448d["width"] = "100"),
    (_0x31448d["height"] = "100"));
  var _0x5dedbf = document["createElement"]("span");
  return (
    (_0x5dedbf["textContent"] = "x"),
    _0x5dedbf["classList"]["add"]("deleteButton"),
    _0x5dedbf["addEventListener"]("click", function (_0x168235) {
      (_0x168235["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x31448d["addEventListener"]("click", function () {
      var _0x388802 = document["querySelectorAll"](".highlight");
      for (var _0x24a39d = 0x0; _0x24a39d < _0x388802["length"]; _0x24a39d++)
        _0x388802[_0x24a39d]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x31448d["addEventListener"]("dblclick", _0x342dcc),
    _0x4cfa8b["appendChild"](_0x31448d),
    _0x4cfa8b["appendChild"](_0x5dedbf),
    _0x4cfa8b
  );
}
async function _0x18c27f(_0x322e66, _0x5574c5, _0x37b203) {
  console["log"]("mainImage:\x20" + _0x322e66);
  var _0x5469f8 = await _0x23c8ff(_0x322e66, _0x37b203),
    _0x31fd4f = await _0x2df9d2(
      _0x5469f8,
      _0x5574c5,
      "https://i.imgur.com/DMwAoOA.png",
    ),
    _0x4c6583 = document["createElement"]("div");
  _0x4c6583["classList"]["add"]("imageContainer");
  var _0xc498cb = document["createElement"]("img");
  ((_0xc498cb["src"] = _0x31fd4f["src"]),
    (_0xc498cb["width"] = "100"),
    (_0xc498cb["height"] = "100"));
  var _0x3baace = document["createElement"]("span");
  return (
    (_0x3baace["textContent"] = "x"),
    _0x3baace["classList"]["add"]("deleteButton"),
    _0x3baace["addEventListener"]("click", function (_0x320c69) {
      (_0x320c69["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0xc498cb["addEventListener"]("click", function () {
      var _0x1f21b1 = document["querySelectorAll"](".highlight");
      for (var _0x2a0701 = 0x0; _0x2a0701 < _0x1f21b1["length"]; _0x2a0701++)
        _0x1f21b1[_0x2a0701]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0xc498cb["addEventListener"]("dblclick", _0x342dcc),
    _0xc498cb["classList"]["add"]("highlight"),
    _0x4c6583["appendChild"](_0xc498cb),
    _0x4c6583["appendChild"](_0x3baace),
    _0x4c6583
  );
}
async function _0x1940e5(_0x311b89, _0x435cc7, _0x57d843, _0x9091f3) {
  var { watermark_url: _0x1d905b } =
      await chrome["storage"]["local"]["get"]("watermark_url"),
    _0x157d87 = await _0x22c0f6(
      _0x311b89,
      _0x435cc7,
      _0x1d905b,
      _0x57d843,
      _0x9091f3,
      "imageTitle",
      0x5dc,
      0x5dc,
      "black",
      "arial",
      !0x0,
    ),
    _0x32f146 = document["createElement"]("div");
  _0x32f146["classList"]["add"]("imageContainer");
  var _0x272be0 = document["createElement"]("img");
  _0x272be0["src"] = _0x157d87["src"];
  var _0x17a374 = document["createElement"]("span");
  return (
    (_0x17a374["textContent"] = "x"),
    _0x17a374["classList"]["add"]("deleteButton"),
    _0x17a374["addEventListener"]("click", function (_0x1a2467) {
      (_0x1a2467["stopPropagation"](), this["parentNode"]["remove"]());
    }),
    _0x272be0["addEventListener"]("click", function () {
      var _0x4baeda = document["querySelectorAll"](".highlight");
      for (var _0x1f526d = 0x0; _0x1f526d < _0x4baeda["length"]; _0x1f526d++)
        _0x4baeda[_0x1f526d]["classList"]["remove"]("highlight");
      this["classList"]["add"]("highlight");
    }),
    _0x272be0["addEventListener"]("dblclick", _0x342dcc),
    _0x272be0["classList"]["add"]("highlight"),
    _0x32f146["appendChild"](_0x272be0),
    _0x32f146["appendChild"](_0x17a374),
    _0x32f146
  );
}
function _0x342dcc(_0x5012be) {
  var _0x1a1bc2 = document["getElementById"]("myModal"),
    _0x1e3560 = document["getElementById"]("img01");
  ((_0x1a1bc2["style"]["display"] = "block"), (_0x1e3560["src"] = this["src"]));
}
function _0x189005() {
  document["getElementById"]("myModal")["style"]["display"] = "none";
}
function _0x4a2578(_0x5c1dae) {
  var _0x22ec65 = document["getElementById"]("myModal");
  _0x5c1dae["target"] == _0x22ec65 && _0x189005();
}
function _0x1b62b8(_0x1551c8) {
  var _0x2a7796 = document["createElement"]("h3");
  return (
    (_0x2a7796["textContent"] = "Scraped\x20Price:\x20$" + _0x1551c8),
    _0x2a7796
  );
}
function _0x584ce0(_0x244b27) {
  var _0x142112 = document["createElement"]("h3");
  return (
    (_0x142112["id"] = "listSku"),
    (_0x142112["textContent"] = _0x244b27),
    _0x142112
  );
}
function _0x23b566(_0x5dbe99) {
  var _0x373984 = document["createElement"]("div");
  _0x373984["id"] = "listPriceContainer";
  var _0x2b7ae5 = document["createElement"]("label");
  ((_0x2b7ae5["htmlFor"] = "newPrice"),
    (_0x2b7ae5["textContent"] = "Price\x20to\x20be\x20listed\x20on\x20eBay:"));
  var _0x500516 = document["createElement"]("input");
  return (
    (_0x500516["id"] = "listPrice"),
    (_0x500516["type"] = "number"),
    (_0x500516["placeholder"] = "Input\x20new\x20price\x20here..."),
    (_0x500516["value"] = _0x5dbe99),
    _0x373984["appendChild"](_0x2b7ae5),
    _0x373984["appendChild"](_0x500516),
    _0x373984
  );
}
function _0x1f910c() {
  var _0x2e61b3 = document["createElement"]("button");
  return (
    (_0x2e61b3["id"] = "listOnEbayButton"),
    (_0x2e61b3["textContent"] = "List\x20on\x20eBay"),
    _0x2e61b3["addEventListener"]("click", function () {
      _0x3d845d();
    }),
    _0x2e61b3
  );
}
function _0x343966() {
  const _0x41a2c0 = document["createElement"]("button");
  return (
    (_0x41a2c0["innerHTML"] = "<b>Snipe\x20Title</b>"),
    (_0x41a2c0["id"] = "create-title-v4"),
    _0x41a2c0["classList"]["add"]("create-title-v4"),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      function (_0x32e892) {
        console["log"]("createSnipeTitleButton\x20response:\x20", _0x32e892);
        if (_0x32e892["creditsAvailable"])
          _0x41a2c0["onclick"] = function () {
            (console["log"]("clicked\x20button"),
              chrome["runtime"]["sendMessage"](
                { type: "checkCredits" },
                async function (_0x5a6d44) {
                  console["log"]("response:\x20", _0x5a6d44);
                  if (_0x5a6d44["creditsAvailable"]) {
                    chrome["runtime"]["sendMessage"]({
                      type: "deductCredits",
                      amount: 0,
                    });
                    var _0x53aeac =
                        document["querySelector"]("#listTitle")["textContent"],
                      _0x53a9ce = document["querySelector"](
                        "#listDescriptionContainer\x20p",
                      )["innerText"];
                    await _0x23a868(_0x53aeac, _0x53a9ce);
                  } else
                    alert(
                      "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits.",
                    );
                },
              ));
          };
        else
          ((_0x41a2c0["disabled"] = !0x0),
            (_0x41a2c0["innerHTML"] =
              "<b>Snipe\x20Title</b>\x20(No\x20Credits)"),
            (_0x41a2c0["style"]["backgroundColor"] = "grey"));
      },
    ),
    _0x41a2c0
  );
}
async function _0x42ccb2() {
  var _0x4b4ebd = document["querySelector"]("#create-title-v4");
  ((_0x4b4ebd["disabled"] = !0x0),
    (_0x4b4ebd["style"]["backgroundColor"] = "grey"),
    (_0x4b4ebd["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    _0x449080(),
    _0x1e9e5b(),
    (document["title"] = "Creating\x20The\x20Perfect\x20Title\x20-\x20"),
    _0x44606f());
  var _0x100f99 =
      document["querySelector"]("#listTitle")["textContent"] +
      "\x0a" +
      document["querySelector"]("#listDescriptionContainer\x20p")["innerText"],
    _0x254bca = await _0x1c567b(
      "https://ebaysnipertitlebuilder.ngrok.io/api/TitleBuilder/BuildTitle",
      { request_type: "build_title", product_description: _0x100f99 },
    );
  console["log"]("getAiTitleFromApi\x20data:\x20", _0x254bca);
  var _0x45ee89 = _0x254bca["title"];
  (console["log"](
    "\x20createTitleV4AndAppendToTable\x20ai_title:\x20",
    _0x45ee89,
  ),
    _0x5ed84c(chrome["runtime"]["getURL"]("Favicons/Completed/received.png")),
    await new Promise((_0x53a68e) => setTimeout(_0x53a68e, 0x3e8)),
    console["log"]("finished\x20waiting\x201\x20second"),
    (document["title"] = "Received\x20Title:\x20\x22" + _0x45ee89 + "\x22"),
    _0x3ee769(_0x45ee89, "Perfect\x20Title"),
    console["log"]("finished\x20createCellWithTitle"));
  var _0x40587b = document["getElementById"]("listing-data-table"),
    _0x41f1b4 =
      _0x40587b["rows"][_0x40587b["rows"]["length"] - 0x1]["querySelector"](
        ".title-cell",
      );
  (console["log"]("finished\x20tableRow.querySelector(.title-cell);"),
    _0x45ee89 || (_0x45ee89 = "undefined"),
    _0x194976(_0x45ee89, _0x41f1b4),
    console["log"]("finished\x20flyInText"));
  var _0x5dd452 = document["querySelector"]("#listTitle");
  return (
    (_0x5dd452["value"] = _0x45ee89),
    _0x5dd452["dispatchEvent"](new Event("input", { bubbles: !0x0 })),
    console["log"]("finished\x20textArea.value\x20=\x20ai_title;"),
    _0xc12f52(),
    _0x3938a2(),
    await new Promise((_0xa1aa01) => setTimeout(_0xa1aa01, 0x7d0)),
    _0x419b85(),
    (_0x4b4ebd["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x4b4ebd["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x4b4ebd["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x4b4ebd["disabled"] = !0x1));
    }, 0x7d0),
    _0x45ee89
  );
}
async function _0x23a868(_0xbc2996, _0x4c28a7) {
  var _0x20944e = document["querySelector"]("#create-title-v4");
  ((_0x20944e["disabled"] = !0x0),
    (_0x20944e["style"]["backgroundColor"] = "grey"),
    (_0x20944e["innerHTML"] = "<b>Sniping\x20Title...</b>"),
    _0x449080(),
    _0x1e9e5b(),
    console["log"]("create10TitlesV3AndAppendToTable"),
    _0xbc2996 || (_0xbc2996 = getFilteredTitle()),
    _0x4c28a7 || (_0x4c28a7 = getProductDescriptionAndFeatures()));
  var _0x17f756 = await _0x1c567b(
    "https://suggest-optimized-titles-2-djybcnnsgq-uc.a.run.app",
    {
      request_type: "generate_10_titles",
      product_description: _0x4c28a7,
      product_title: _0xbc2996,
    },
  );
  console["log"]("create10TitlesV3AndAppendToTable\x20data:\x20", _0x17f756);
  var _0x1c5c70 = _0x17f756;
  if (!_0x1c5c70)
    return (
      _0x3ee769("Error\x20-\x20Try\x20Again", "Perfect\x20Title"),
      _0xc12f52(),
      _0x3938a2(),
      await new Promise((_0x3c4cda) => setTimeout(_0x3c4cda, 0x7d0)),
      _0x419b85(),
      (_0x20944e["innerHTML"] = "<b>Sniped\x20Title!</b>"),
      (_0x20944e["style"]["backgroundColor"] = "#3a86ff"),
      setTimeout(function () {
        ((_0x20944e["innerHTML"] = "<b>Snipe\x20Title</b>"),
          (_0x20944e["disabled"] = !0x1));
      }, 0x7d0),
      null
    );
  (Array["isArray"](_0x1c5c70) || (_0x1c5c70 = [_0x1c5c70]),
    (_0x1c5c70 = _0x1c5c70["filter"](function (_0x38ecc9) {
      return _0x38ecc9["trim"]()["length"] > 0x0;
    })["map"](function (_0x2ca46d) {
      return _0x2ca46d["trim"]();
    })));
  var _0x3eeda0 = "";
  for (var _0x5e120e = 0x0; _0x5e120e < _0x1c5c70["length"]; _0x5e120e++)
    (_0xbc2996 = _0x1c5c70[_0x5e120e])["length"] > _0x3eeda0["length"] &&
      _0xbc2996["length"] <= 0x50 &&
      (_0x3eeda0 = _0xbc2996);
  0x0 == _0x3eeda0["length"] && (_0x3eeda0 = _0x1c5c70[0x0]);
  for (_0x5e120e = 0x0; _0x5e120e < _0x1c5c70["length"]; _0x5e120e++) {
    ((_0xbc2996 = _0x1c5c70[_0x5e120e]),
      console["log"]("title:\x20", _0xbc2996));
    if (!(_0xbc2996["length"] > 0x5a)) {
      _0x3ee769(
        _0xbc2996,
        _0x3eeda0 == _0xbc2996 ? "Perfect\x20Title" : "Great\x20Title",
      );
      var _0x5e14b4 = document["getElementById"]("listing-data-table");
      (_0x194976(
        _0xbc2996,
        _0x5e14b4["rows"][_0x5e14b4["rows"]["length"] - 0x1]["querySelector"](
          ".title-cell",
        ),
      ),
        _0x3938a2(),
        await new Promise((_0x1ab782) => setTimeout(_0x1ab782, 0x12c)),
        _0x419b85());
    }
  }
  var _0x2160e4 = document["querySelector"]("#the-textarea");
  (_0x2160e4 || (_0x2160e4 = document["querySelector"]("#listTitle")),
    (_0x2160e4["value"] = _0x3eeda0));
  try {
    updateTheCharacterCountOnTextArea();
  } catch (_0x1cff53) {}
  return (
    _0xc12f52(),
    _0x3938a2(),
    await new Promise((_0x7f60a8) => setTimeout(_0x7f60a8, 0x7d0)),
    _0x419b85(),
    (_0x20944e["innerHTML"] = "<b>Sniped\x20Title!</b>"),
    (_0x20944e["style"]["backgroundColor"] = "#3a86ff"),
    setTimeout(function () {
      ((_0x20944e["innerHTML"] = "<b>Snipe\x20Title</b>"),
        (_0x20944e["disabled"] = !0x1));
    }, 0x7d0),
    _0x3eeda0
  );
}
async function _0x3ee769(_0x36315e, _0x18ecb8) {
  var _0x35306c = document["getElementById"]("listing-data-table"),
    _0x40522f = _0x3f0c05(_0x35306c);
  (_0x5ebacb(_0x35306c, {
    rowNumber: _0x40522f,
    cellValue: _0x40522f,
    headerName: "Rank",
  }),
    _0x5ebacb(_0x35306c, {
      rowNumber: _0x40522f,
      cellValue: _0x36315e,
      headerName: "Title",
    }),
    _0x5ebacb(_0x35306c, {
      rowNumber: _0x40522f,
      cellValue: _0x18ecb8,
      headerName: "Type",
    }),
    _0x5ebacb(_0x35306c, {
      rowNumber: _0x40522f,
      cellValue: _0x36315e["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x28f60c = document["createElement"]("button");
  ((_0x28f60c["innerHTML"] = "Change"),
    (_0x28f60c["onclick"] = function () {
      var _0x3309d6 = document["querySelector"]("#listTitle");
      ((_0x3309d6["value"] = _0x36315e),
        _0x3309d6["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
    }),
    _0x2963eb(_0x35306c, {
      button: _0x28f60c,
      rowNumber: _0x40522f,
      headerName: "Action",
    }));
}
async function _0x288bca() {
  _0x1e9e5b();
  var _0x2dd0e0 = document["querySelectorAll"](".imageContainer\x20img"),
    _0x24b2f7 = [];
  for (var _0x1d1293 = 0x0; _0x1d1293 < _0x2dd0e0["length"]; _0x1d1293++)
    _0x24b2f7["push"](_0x2dd0e0[_0x1d1293]["src"]);
  if (_0x24b2f7["length"] < 0x4)
    (alert(
      "You\x20need\x204\x20images\x20to\x20generate\x20a\x20quad\x20image",
    ),
      _0xc12f52());
  else {
    var _0xbd9ebe = await _0x1940e5(
      _0x24b2f7[0x0],
      _0x24b2f7[0x1],
      _0x24b2f7[0x2],
      _0x24b2f7[0x3],
    );
    (document["querySelector"]("#imagesContainer")["appendChild"](_0xbd9ebe),
      _0xc12f52(),
      _0x3938a2(),
      await new Promise((_0x4dadb4) => setTimeout(_0x4dadb4, 0x7d0)),
      _0x419b85());
  }
}
async function _0x2d20a0() {
  _0x1e9e5b();
  var _0x3b26c5 = document["querySelectorAll"](".imageContainer\x20img"),
    _0x2cc76f = [];
  for (var _0x367c90 = 0x0; _0x367c90 < _0x3b26c5["length"]; _0x367c90++)
    _0x2cc76f["push"](_0x3b26c5[_0x367c90]["src"]);
  var _0x58e355 = await _0x4f35a4(_0x2cc76f[0x0], _0x2cc76f);
  (document["querySelector"]("#imagesContainer")["appendChild"](_0x58e355),
    _0xc12f52(),
    _0x3938a2(),
    await new Promise((_0x2d9079) => setTimeout(_0x2d9079, 0x7d0)),
    _0x419b85());
}
async function _0xd2b0a6(_0x156242) {
  var _0x3faf2e = _0x156242["images"],
    _0x186e83 = _0x156242["title"],
    _0x114c76 = _0x156242["price"],
    _0x3ed78d = _0x156242["description"];
  _0x114c76 = _0x156242["price"];
  var _0x58e690 = _0x156242["sku"];
  _0x156242["attributeImages"];
  var _0x162e0f = _0x343966(),
    _0x12cc0b = _0x212bde();
  _0x2d0cbf();
  var _0x3225a2 = document["createElement"]("div");
  _0x3225a2["id"] = "data-box";
  var _0x14925d = document["createElement"]("div");
  _0x14925d["id"] = "imagesContainer";
  var _0x3a4566 = _0x2015b3(_0x3faf2e);
  (_0x14925d["appendChild"](_0x3a4566), _0x3225a2["appendChild"](_0x14925d));
  var _0xcaa94d = document["createElement"]("div");
  _0xcaa94d["id"] = "buttonContainer";
  var _0x48cc59 = document["createElement"]("button");
  ((_0x48cc59["innerHTML"] = "Generate\x20Quad\x20Image"),
    (_0x48cc59["id"] = "generateQuadImageButton"),
    (_0x48cc59["onclick"] = async function (_0xcee502) {
      (_0xcee502["preventDefault"](),
        (_0x48cc59["disabled"] = !0x0),
        (_0x48cc59["style"]["backgroundColor"] = "grey"),
        await _0x288bca(),
        (_0x48cc59["disabled"] = !0x1),
        (_0x48cc59["style"]["backgroundColor"] = "#4CAF50"));
    }));
  var _0x4f48e2 = document["createElement"]("button");
  ((_0x4f48e2["innerHTML"] = "Create\x20Multi\x20Image"),
    (_0x4f48e2["id"] = "createMultiImageButton"),
    (_0x4f48e2["onclick"] = async function (_0x3d4339) {
      (_0x3d4339["preventDefault"](),
        (_0x4f48e2["disabled"] = !0x0),
        (_0x4f48e2["style"]["backgroundColor"] = "grey"),
        await _0x2d20a0(),
        (_0x4f48e2["disabled"] = !0x1),
        (_0x4f48e2["style"]["backgroundColor"] = "#4CAF50"));
    }));
  var _0x3c6207 = _0x12cc0b["cloneNode"](!0x0);
  (_0xcaa94d["appendChild"](_0x3c6207),
    _0xcaa94d["appendChild"](_0x48cc59),
    _0xcaa94d["appendChild"](_0x4f48e2),
    _0x3225a2["appendChild"](_0xcaa94d),
    _0x3225a2["appendChild"](_0x145661(_0x186e83)),
    _0x3225a2["appendChild"](_0x3f599d(_0x186e83)),
    _0x3225a2["appendChild"](_0x23b566(_0x114c76)),
    _0x3225a2["appendChild"](_0x12cc0b),
    _0x3225a2["appendChild"](_0x162e0f),
    _0x3225a2["appendChild"](_0x1f910c()));
  var _0x4d26e5 = _0x6db927();
  (_0x3225a2["appendChild"](_0x4d26e5),
    _0x229aaf(_0x4d26e5, { headerName: "Rank" }),
    _0x229aaf(_0x4d26e5, { headerName: "Type" }),
    _0x229aaf(_0x4d26e5, { headerName: "Title" }),
    _0x229aaf(_0x4d26e5, { headerName: "Total\x20Characters" }),
    _0x229aaf(_0x4d26e5, { headerName: "Action" }));
  var _0xbdcfcc = _0x3f0c05(_0x4d26e5);
  (_0x5ebacb(_0x4d26e5, {
    rowNumber: _0xbdcfcc,
    cellValue: _0xbdcfcc,
    headerName: "Rank",
  }),
    _0x5ebacb(_0x4d26e5, {
      rowNumber: _0xbdcfcc,
      cellValue: _0x186e83,
      headerName: "Title",
    }),
    _0x5ebacb(_0x4d26e5, {
      rowNumber: _0xbdcfcc,
      cellValue: "Filtered",
      headerName: "Type",
    }),
    _0x5ebacb(_0x4d26e5, {
      rowNumber: _0xbdcfcc,
      cellValue: _0x186e83["length"],
      headerName: "Total\x20Characters",
    }));
  var _0x46dfbd = document["createElement"]("button");
  ((_0x46dfbd["innerHTML"] = "Change"),
    (_0x46dfbd["onclick"] = function () {
      var _0x2fcff4 = document["querySelector"]("#listTitle");
      ((_0x2fcff4["value"] = _0x186e83),
        _0x2fcff4["dispatchEvent"](new Event("input", { bubbles: !0x0 })));
    }),
    _0x2963eb(_0x4d26e5, {
      button: _0x46dfbd,
      rowNumber: _0xbdcfcc,
      headerName: "Action",
    }),
    _0x3225a2["appendChild"](_0x13fe72(_0x3ed78d)),
    _0x3225a2["appendChild"](_0x1b62b8(_0x114c76)),
    _0x3225a2["appendChild"](_0x584ce0(_0x58e690)));
  var _0x2c6961 = document["createElement"]("span");
  ((_0x2c6961["innerHTML"] = "&times;"),
    _0x2c6961["classList"]["add"]("close-button"),
    (_0x2c6961["onclick"] = function () {
      _0x3225a2["remove"]();
    }),
    _0x3225a2["appendChild"](_0x2c6961),
    document["body"]["insertBefore"](_0x3225a2, document["body"]["firstChild"]),
    document["querySelector"](".imageContainer")
      ["querySelector"]("img")
      ["click"](),
    _0x17cd25());
}
function _0x17cd25() {
  var _0x514892 = document["getElementById"]("imagesContainer");
  new Sortable(_0x514892, {
    animation: 0x96,
    chosenClass: "sortable-chosen",
    dragClass: "sortable-drag",
  });
}
function _0x3d845d() {
  (_0x5ed84c(chrome["runtime"]["getURL"]("Favicons/Completed/right_arrow.png")),
    chrome["runtime"]["sendMessage"](
      { type: "checkCredits" },
      async function (_0x528a68) {
        console["log"]("response:\x20", _0x528a68);
        if (_0x528a68["creditsAvailable"]) {
          chrome["runtime"]["sendMessage"]({
            type: "deductCredits",
            amount: 0,
          });
          var _0x4c8ad2 = document["querySelectorAll"](
              ".imageContainer\x20img",
            ),
            _0x384adc = [];
          for (
            var _0x42b58b = 0x0;
            _0x42b58b < _0x4c8ad2["length"];
            _0x42b58b++
          )
            _0x384adc["push"](_0x4c8ad2[_0x42b58b]["src"]);
          var _0x109c06 = document["querySelector"](
              ".imageContainer\x20img.highlight",
            )["src"],
            _0x4ccf72 = await _0x52d13d(_0x109c06),
            _0x23945a = {
              title:
                document["querySelector"]("#title_ecom_sniper")["innerText"],
              custom_title: document["querySelector"]("#listTitle")["value"],
              custom_price: document["querySelector"]("#listPrice")["value"],
              descriptionHTML:
                document["querySelector"]("#listDescription")["innerHTML"],
              descriptionText:
                document["querySelector"]("#listDescription")["innerText"],
              main_hd_images: _0x384adc,
              main_sd_images: [],
              selected_image: _0x4ccf72["src"],
              listingType: "paid2",
              sku: document["querySelector"]("#listSku")["innerText"],
            };
          chrome["runtime"]["sendMessage"](
            { type: "list_to_ebay", product_data: _0x23945a },
            function (_0x20e302) {
              console["log"](_0x20e302["farewell"]);
            },
          );
        } else
          alert(
            "You\x20have\x20no\x20credits\x20left.\x20Please\x20purchase\x20more\x20credits\x20to\x20continue\x20listing.",
          );
      },
    ));
}
function _0x2d0cbf() {
  const _0xf05eab = document["createElement"]("div");
  ((_0xf05eab["id"] = "myModal"), _0xf05eab["classList"]["add"]("modal"));
  const _0x2326a = document["createElement"]("span");
  (_0x2326a["classList"]["add"]("close"),
    (_0x2326a["innerHTML"] = "&times;"),
    _0xf05eab["appendChild"](_0x2326a));
  const _0x283e39 = document["createElement"]("img");
  (_0x283e39["classList"]["add"]("modal-content"),
    (_0x283e39["id"] = "img01"),
    _0xf05eab["appendChild"](_0x283e39),
    document["body"]["appendChild"](_0xf05eab),
    document["getElementsByClassName"]("close")[0x0]["addEventListener"](
      "click",
      _0x189005,
    ),
    window["addEventListener"]("click", _0x4a2578));
}
async function _0x36f529(_0x1cbfc1) {
  var { markupPrice: _0x5204b8 } =
    await chrome["storage"]["local"]["get"]("markupPrice");
  let _0x5bccb7 = _0x1cbfc1 * (0x1 + _0x5204b8 / 0x64);
  _0x5bccb7 = Math["ceil"](_0x5bccb7);
  var { end_price: _0x2df5fd } =
      await chrome["storage"]["local"]["get"]("end_price"),
    _0x1a8711 = 0x1 - (_0x2df5fd = parseFloat(_0x2df5fd));
  return (
    0x1 == _0x1a8711 && (_0x1a8711 = 0x0),
    (_0x5bccb7 -= _0x1a8711),
    _0x5bccb7
  );
}
console["log"]("functions.js\x20loaded");
function _0x4a15f0() {
  return document["querySelector"]("[data-buy-box-listing-title]")["innerText"];
}
function _0x37b2b6() {
  var _0x3d3aa0 = document["querySelector"](
    "[data-selector=\x27price-only\x27]",
  )["innerText"];
  return (
    (_0x3d3aa0 = _0x3d3aa0["match"](/\d+\.\d+/)[0x0]),
    parseFloat(_0x3d3aa0)
  );
}
function _0x487a40() {
  return document["querySelector"](
    "#wt-content-toggle-product-details-read-more",
  )["innerText"];
}
function _0x13c525() {
  var _0x17e84a = document["querySelectorAll"](
      "#listing-right-column\x20[data-src-zoom-image]",
    ),
    _0x51834b = [];
  for (var _0x452136 = 0x0; _0x452136 < _0x17e84a["length"]; _0x452136++) {
    var _0x3cdb34 = _0x17e84a[_0x452136]["src"];
    (_0x3cdb34["includes"]("http://") || _0x3cdb34["includes"]("https://")) &&
      _0x51834b["push"](_0x3cdb34);
  }
  return _0x51834b;
}
function _0x15832a() {
  return document["querySelector"]("[data-listing-id]")["getAttribute"](
    "data-listing-id",
  );
}
console["log"]("content.js\x20loaded");
async function _0xda5df5() {
  var _0x18d21b = _0x4a15f0();
  console["log"]("title", _0x18d21b);
  var _0x817bd2 = _0x37b2b6();
  console["log"]("price", _0x817bd2);
  var _0x303958 = _0x487a40();
  console["log"]("description", _0x303958);
  var _0x26eeb0 = _0x13c525();
  console["log"]("images", _0x26eeb0);
  var _0x1540b2 = _0x15832a();
  console["log"]("sku", _0x1540b2);
  var _0x3f17cf = {
    title: _0x18d21b,
    description: _0x303958,
    images: _0x26eeb0,
    price: await _0x36f529(_0x817bd2),
    sku: _0x1540b2,
  };
  (console["log"]("options", _0x3f17cf), _0xd2b0a6(_0x3f17cf));
}
document["addEventListener"]("DOMContentLoaded", async function () {
  _0xda5df5();
});
